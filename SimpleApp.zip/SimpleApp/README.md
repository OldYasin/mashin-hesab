# Simple App
1. این پوشه رو توی یه ریپوی GitHub آپلود کن (شاخه main).
2. تب Actions → Build APK (خودکار با push اجرا میشه یا Run workflow بزن).
3. بعد از اتمام، از بخش Artifacts فایل APK رو دانلود کن.
