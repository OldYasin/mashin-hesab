package com.yasin.simpleapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(48, 48, 48, 48);

        final TextView text = new TextView(this);
        text.setText("سلام! تعداد: 0");
        text.setTextSize(28);
        text.setGravity(Gravity.CENTER);

        Button button = new Button(this);
        button.setText("کلیک کن");
        button.setOnClickListener(v -> {
            count++;
            text.setText("سلام! تعداد: " + count);
        });

        layout.addView(text);
        layout.addView(button);
        setContentView(layout);
    }
}
