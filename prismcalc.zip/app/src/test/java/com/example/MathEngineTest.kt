package com.example

import com.example.engine.AngleUnit
import com.example.engine.EvalErrorType
import com.example.engine.EvalResult
import com.example.engine.MathEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MathEngineTest {

  @Test
  fun testBasicArithmeticAndPrecedence() {
    val res = MathEngine.evaluate("2+3×4−6÷2")
    assertTrue(res is EvalResult.Success)
    assertEquals("11", (res as EvalResult.Success).formatted)
  }

  @Test
  fun testFloatingPointPrecisionClean() {
    val res = MathEngine.evaluate("0.1+0.2")
    assertTrue(res is EvalResult.Success)
    assertEquals("0.3", (res as EvalResult.Success).formatted)
  }

  @Test
  fun testCalculatorPercentage() {
    val res = MathEngine.evaluate("200+15%")
    assertTrue(res is EvalResult.Success)
    assertEquals("230", (res as EvalResult.Success).formatted)
  }

  @Test
  fun testImplicitMultiplicationAndTrig() {
    val res = MathEngine.evaluate("2sin(30)+√(16)", AngleUnit.DEG)
    assertTrue(res is EvalResult.Success)
    assertEquals("5", (res as EvalResult.Success).formatted)
  }

  @Test
  fun testDivisionByZeroReturnsError() {
    val res = MathEngine.evaluate("42÷0")
    assertTrue(res is EvalResult.Error)
    assertEquals(EvalErrorType.DIVISION_BY_ZERO, (res as EvalResult.Error).type)
  }

  @Test
  fun testAllowIncompletePreview() {
    val res = MathEngine.evaluate("12+8×", allowIncomplete = true)
    assertTrue(res is EvalResult.Success)
    assertEquals("20", (res as EvalResult.Success).formatted)
  }
}
