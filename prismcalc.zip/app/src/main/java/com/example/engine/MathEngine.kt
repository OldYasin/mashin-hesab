package com.example.engine

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

enum class AngleUnit {
  DEG,
  RAD,
}

enum class EvalErrorType {
  DIVISION_BY_ZERO,
  SYNTAX,
  DOMAIN,
}

sealed interface EvalResult {
  data class Success(val value: Double, val formatted: String) : EvalResult

  data object Incomplete : EvalResult

  data class Error(val type: EvalErrorType) : EvalResult
}

object MathEngine {

  private sealed interface Token {
    data class Number(val value: Double) : Token

    data class Constant(val value: Double) : Token

    data class Operator(val symbol: Char) : Token

    data class Function(val name: String) : Token

    data object LeftParen : Token

    data object RightParen : Token

    data object Percent : Token

    data object Factorial : Token
  }

  fun evaluate(
    rawExpression: String,
    angleUnit: AngleUnit = AngleUnit.DEG,
    allowIncomplete: Boolean = false,
  ): EvalResult {
    val expr = rawExpression.trim()
    if (expr.isEmpty()) return EvalResult.Incomplete

    return try {
      val tokens = tokenize(expr)
      if (tokens.isEmpty()) return EvalResult.Incomplete

      val balancedTokens =
        if (allowIncomplete) {
          trimTrailingOperatorsAndBalance(tokens)
        } else {
          balanceParentheses(tokens)
        }

      if (balancedTokens.isEmpty()) return EvalResult.Incomplete

      val parser = Parser(balancedTokens, angleUnit)
      val value = parser.parseExpression()
      if (!parser.isAtEnd()) {
        return if (allowIncomplete) EvalResult.Incomplete else EvalResult.Error(EvalErrorType.SYNTAX)
      }

      if (value.isNaN()) {
        return EvalResult.Error(EvalErrorType.DOMAIN)
      }
      if (value.isInfinite()) {
        return EvalResult.Error(EvalErrorType.DIVISION_BY_ZERO)
      }

      EvalResult.Success(value = value, formatted = formatNumber(value))
    } catch (_: DivisionByZeroException) {
      EvalResult.Error(EvalErrorType.DIVISION_BY_ZERO)
    } catch (_: DomainException) {
      EvalResult.Error(EvalErrorType.DOMAIN)
    } catch (_: SyntaxException) {
      if (allowIncomplete) EvalResult.Incomplete else EvalResult.Error(EvalErrorType.SYNTAX)
    }
  }

  private class DivisionByZeroException : RuntimeException()

  private class DomainException : RuntimeException()

  private class SyntaxException : RuntimeException()

  private fun tokenize(input: String): List<Token> {
    val raw = mutableListOf<Token>()
    var i = 0
    val n = input.length

    while (i < n) {
      val c = input[i]
      when {
        c.isWhitespace() || c == ',' -> i++
        c.isDigit() || c == '.' -> {
          val start = i
          var dotCount = 0
          while (i < n && (input[i].isDigit() || input[i] == '.')) {
            if (input[i] == '.') dotCount++
            i++
          }
          if (i < n && (input[i] == 'E' || input[i] == 'e')) {
            // Support scientific notation numbers like 1.5E-4 if typed from result
            val expLookahead = i + 1
            if (
              expLookahead < n &&
                (input[expLookahead].isDigit() ||
                  input[expLookahead] == '+' ||
                  input[expLookahead] == '-')
            ) {
              i++
              if (input[i] == '+' || input[i] == '-') i++
              val expDigitsStart = i
              while (i < n && input[i].isDigit()) i++
              if (i == expDigitsStart) throw SyntaxException()
            }
          }
          if (dotCount > 1) throw SyntaxException()
          val numStr = input.substring(start, i)
          val num = numStr.toDoubleOrNull() ?: throw SyntaxException()
          raw.add(Token.Number(num))
        }
        c == '+' || c == '-' || c == '−' || c == '*' || c == '×' || c == '/' || c == '÷' || c == '^' -> {
          val normalized =
            when (c) {
              '−' -> '-'
              '×' -> '*'
              '÷' -> '/'
              else -> c
            }
          raw.add(Token.Operator(normalized))
          i++
        }
        c == '(' -> {
          raw.add(Token.LeftParen)
          i++
        }
        c == ')' -> {
          raw.add(Token.RightParen)
          i++
        }
        c == '%' -> {
          raw.add(Token.Percent)
          i++
        }
        c == '!' -> {
          raw.add(Token.Factorial)
          i++
        }
        c == 'π' -> {
          raw.add(Token.Constant(PI))
          i++
        }
        c == '√' -> {
          raw.add(Token.Function("sqrt"))
          i++
        }
        c.isLetter() -> {
          val start = i
          while (i < n && input[i].isLetter()) i++
          val word = input.substring(start, i).lowercase()
          when (word) {
            "pi" -> raw.add(Token.Constant(PI))
            "e" -> raw.add(Token.Constant(exp(1.0)))
            "sin", "cos", "tan", "asin", "acos", "atan", "ln", "log", "sqrt", "abs" ->
              raw.add(Token.Function(word))
            else -> throw SyntaxException()
          }
        }
        else -> throw SyntaxException()
      }
    }

    // Insert implicit multiplication tokens where appropriate:
    // e.g. 2(, )2, )(, 2π, 2sin, π(, %2, !2
    val result = mutableListOf<Token>()
    for (idx in raw.indices) {
      val curr = raw[idx]
      if (result.isNotEmpty()) {
        val prev = result.last()
        val prevEndsValue =
          prev is Token.Number ||
            prev is Token.Constant ||
            prev is Token.RightParen ||
            prev is Token.Percent ||
            prev is Token.Factorial
        val currStartsValue =
          curr is Token.Number ||
            curr is Token.Constant ||
            curr is Token.LeftParen ||
            curr is Token.Function
        if (prevEndsValue && currStartsValue) {
          result.add(Token.Operator('*'))
        }
      }
      result.add(curr)
    }
    return result
  }

  private fun trimTrailingOperatorsAndBalance(tokens: List<Token>): List<Token> {
    val list = tokens.toMutableList()
    while (list.isNotEmpty()) {
      val last = list.last()
      if (last is Token.Operator || last is Token.LeftParen || last is Token.Function) {
        list.removeAt(list.lastIndex)
      } else {
        break
      }
    }
    return balanceParentheses(list)
  }

  private fun balanceParentheses(tokens: List<Token>): List<Token> {
    var open = 0
    for (t in tokens) {
      if (t is Token.LeftParen) open++
      else if (t is Token.RightParen) {
        if (open > 0) open-- else throw SyntaxException()
      }
    }
    if (open == 0) return tokens
    return tokens + List(open) { Token.RightParen }
  }

  private class Parser(
    private val tokens: List<Token>,
    private val angleUnit: AngleUnit,
  ) {
    private var pos = 0

    fun isAtEnd(): Boolean = pos >= tokens.size

    private fun peek(): Token? = tokens.getOrNull(pos)

    private fun consume(): Token = tokens[pos++]

    fun parseExpression(): Double {
      var left = parseTerm()
      while (true) {
        val op = peek() as? Token.Operator ?: break
        if (op.symbol != '+' && op.symbol != '-') break
        consume()
        val rightTerm = parseTermRaw()
        val value =
          if (rightTerm.hasTrailingPercent && !rightTerm.consumedIntoMulDiv) {
            left * (rightTerm.value / 100.0)
          } else if (rightTerm.hasTrailingPercent) {
            rightTerm.value / 100.0
          } else {
            rightTerm.value
          }
        left = if (op.symbol == '+') left + value else left - value
      }
      return left
    }

    private data class TermResult(
      val value: Double,
      val hasTrailingPercent: Boolean,
      val consumedIntoMulDiv: Boolean,
    )

    private fun parseTerm(): Double {
      val res = parseTermRaw()
      return if (res.hasTrailingPercent && !res.consumedIntoMulDiv) {
        res.value / 100.0
      } else {
        res.value
      }
    }

    private fun parseTermRaw(): TermResult {
      val first = parseFactorWithPostfix()
      var left = first.value
      var trailingPercent = first.hasTrailingPercent
      var consumed = false

      while (true) {
        val op = peek() as? Token.Operator ?: break
        if (op.symbol != '*' && op.symbol != '/') break
        if (trailingPercent) {
          left /= 100.0
          trailingPercent = false
        }
        consume()
        val right = parseFactorWithPostfix()
        val rightVal = if (right.hasTrailingPercent) right.value / 100.0 else right.value
        left =
          if (op.symbol == '*') {
            left * rightVal
          } else {
            if (rightVal == 0.0) throw DivisionByZeroException()
            left / rightVal
          }
        consumed = true
      }
      return TermResult(left, trailingPercent, consumed)
    }

    private data class PostfixResult(val value: Double, val hasTrailingPercent: Boolean)

    private fun parseFactorWithPostfix(): PostfixResult {
      var value = parseUnary()
      var hasPercent = false

      while (true) {
        when (peek()) {
          is Token.Percent -> {
            consume()
            if (hasPercent) {
              value /= 100.0
            } else {
              hasPercent = true
            }
          }
          is Token.Factorial -> {
            consume()
            if (hasPercent) {
              value /= 100.0
              hasPercent = false
            }
            value = factorial(value)
          }
          else -> break
        }
      }

      if (peek() is Token.Operator && (peek() as Token.Operator).symbol == '^') {
        if (hasPercent) {
          value /= 100.0
          hasPercent = false
        }
        consume()
        val exponent = parseUnaryPower()
        val res = value.pow(exponent)
        if (res.isNaN()) throw DomainException()
        return PostfixResult(res, false)
      }

      return PostfixResult(value, hasPercent)
    }

    private fun parseUnaryPower(): Double {
      val res = parseFactorWithPostfix()
      return if (res.hasTrailingPercent) res.value / 100.0 else res.value
    }

    private fun parseUnary(): Double {
      val op = peek() as? Token.Operator
      if (op != null && (op.symbol == '+' || op.symbol == '-')) {
        consume()
        val inner = parseUnary()
        return if (op.symbol == '-') -inner else inner
      }
      return parsePrimary()
    }

    private fun parsePrimary(): Double {
      return when (val token = peek()) {
        is Token.Number -> {
          consume()
          token.value
        }
        is Token.Constant -> {
          consume()
          token.value
        }
        is Token.LeftParen -> {
          consume()
          val inside = parseExpression()
          if (peek() is Token.RightParen) {
            consume()
          } else {
            throw SyntaxException()
          }
          inside
        }
        is Token.Function -> {
          consume()
          val arg =
            if (peek() is Token.LeftParen) {
              consume()
              val inner = parseExpression()
              if (peek() is Token.RightParen) consume() else throw SyntaxException()
              inner
            } else {
              parseUnary()
            }
          applyFunction(token.name, arg)
        }
        else -> throw SyntaxException()
      }
    }

    private fun applyFunction(name: String, arg: Double): Double {
      val rad = if (angleUnit == AngleUnit.DEG) Math.toRadians(arg) else arg
      return when (name) {
        "sin" -> cleanTrig(sin(rad))
        "cos" -> cleanTrig(cos(rad))
        "tan" -> {
          val c = cleanTrig(cos(rad))
          if (abs(c) < 1e-15) throw DomainException()
          cleanTrig(tan(rad))
        }
        "asin" -> {
          if (arg < -1.0 || arg > 1.0) throw DomainException()
          val res = asin(arg)
          if (angleUnit == AngleUnit.DEG) Math.toDegrees(res) else res
        }
        "acos" -> {
          if (arg < -1.0 || arg > 1.0) throw DomainException()
          val res = acos(arg)
          if (angleUnit == AngleUnit.DEG) Math.toDegrees(res) else res
        }
        "atan" -> {
          val res = atan(arg)
          if (angleUnit == AngleUnit.DEG) Math.toDegrees(res) else res
        }
        "sqrt" -> {
          if (arg < 0.0) throw DomainException()
          sqrt(arg)
        }
        "ln" -> {
          if (arg <= 0.0) throw DomainException()
          ln(arg)
        }
        "log" -> {
          if (arg <= 0.0) throw DomainException()
          log10(arg)
        }
        "abs" -> abs(arg)
        else -> throw SyntaxException()
      }
    }

    private fun cleanTrig(v: Double): Double = if (abs(v) < 1e-14) 0.0 else v

    private fun factorial(v: Double): Double {
      if (v < 0.0 || v > 170.0 || v != floor(v)) throw DomainException()
      var acc = 1.0
      for (k in 2..v.toInt()) {
        acc *= k
      }
      return acc
    }
  }

  fun formatNumber(value: Double): String {
    if (value == 0.0) return "0"
    val absVal = abs(value)
    if (absVal >= 1e12 || (absVal > 0 && absVal < 1e-8)) {
      val bd = BigDecimal.valueOf(value).round(MathContext(9, RoundingMode.HALF_UP))
      return bd.stripTrailingZeros().toString()
    }
    val bd =
      BigDecimal.valueOf(value)
        .round(MathContext(12, RoundingMode.HALF_UP))
        .stripTrailingZeros()
    val plain = bd.toPlainString()
    return addThousandsSeparators(plain)
  }

  private fun addThousandsSeparators(plain: String): String {
    val isNeg = plain.startsWith("-")
    val unsigned = if (isNeg) plain.substring(1) else plain
    val dotIndex = unsigned.indexOf('.')
    val intPart = if (dotIndex >= 0) unsigned.substring(0, dotIndex) else unsigned
    val fracPart = if (dotIndex >= 0) unsigned.substring(dotIndex) else ""

    val grouped =
      buildString {
        var count = 0
        for (i in intPart.length - 1 downTo 0) {
          append(intPart[i])
          count++
          if (count % 3 == 0 && i != 0) {
            append(',')
          }
        }
      }.reversed()

    return (if (isNeg) "-" else "") + grouped + fracPart
  }
}
