package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.engine.AngleUnit
import com.example.ui.theme.CalculatorThemeStyle
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.calculatorDataStore by preferencesDataStore(name = "prismcalc_prefs")

data class HistoryEntry(
  val id: Long,
  val expression: String,
  val result: String,
)

data class StoredPreferences(
  val themeStyle: CalculatorThemeStyle = CalculatorThemeStyle.CERAMIC,
  val isScientific: Boolean = false,
  val angleUnit: AngleUnit = AngleUnit.DEG,
  val parallaxEnabled: Boolean = false,
  val hapticsEnabled: Boolean = true,
  val soundEnabled: Boolean = true,
  val depthFactor: Float = 1.0f,
  val history: List<HistoryEntry> = emptyList(),
)

class CalculatorPreferences(private val context: Context) {

  private object Keys {
    val THEME_ID = stringPreferencesKey("theme_id")
    val IS_SCIENTIFIC = booleanPreferencesKey("is_scientific")
    val ANGLE_UNIT = stringPreferencesKey("angle_unit")
    val PARALLAX_ENABLED = booleanPreferencesKey("parallax_enabled")
    val HAPTICS_ENABLED = booleanPreferencesKey("haptics_enabled")
    val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
    val DEPTH_FACTOR = floatPreferencesKey("depth_factor")
    val HISTORY = stringPreferencesKey("history_records")
  }

  suspend fun loadInitial(): StoredPreferences =
    context.calculatorDataStore.data
      .map { prefs ->
        val rawTheme = prefs[Keys.THEME_ID]
        val theme =
          if (rawTheme == null) CalculatorThemeStyle.CERAMIC
          else CalculatorThemeStyle.fromId(rawTheme)
        StoredPreferences(
          themeStyle = theme,
          isScientific = prefs[Keys.IS_SCIENTIFIC] ?: false,
          angleUnit =
            if (prefs[Keys.ANGLE_UNIT] == AngleUnit.RAD.name) AngleUnit.RAD else AngleUnit.DEG,
          parallaxEnabled = prefs[Keys.PARALLAX_ENABLED] ?: false,
          hapticsEnabled = prefs[Keys.HAPTICS_ENABLED] ?: true,
          soundEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
          depthFactor = (prefs[Keys.DEPTH_FACTOR] ?: 1.0f).coerceIn(0.5f, 1.4f),
          history = decodeHistory(prefs[Keys.HISTORY]),
        )
      }
      .first()

  suspend fun setTheme(style: CalculatorThemeStyle) {
    context.calculatorDataStore.edit { it[Keys.THEME_ID] = style.id }
  }

  suspend fun setScientific(enabled: Boolean) {
    context.calculatorDataStore.edit { it[Keys.IS_SCIENTIFIC] = enabled }
  }

  suspend fun setAngleUnit(unit: AngleUnit) {
    context.calculatorDataStore.edit { it[Keys.ANGLE_UNIT] = unit.name }
  }

  suspend fun setParallaxEnabled(enabled: Boolean) {
    context.calculatorDataStore.edit { it[Keys.PARALLAX_ENABLED] = enabled }
  }

  suspend fun setHapticsEnabled(enabled: Boolean) {
    context.calculatorDataStore.edit { it[Keys.HAPTICS_ENABLED] = enabled }
  }

  suspend fun setSoundEnabled(enabled: Boolean) {
    context.calculatorDataStore.edit { it[Keys.SOUND_ENABLED] = enabled }
  }

  suspend fun setDepthFactor(factor: Float) {
    context.calculatorDataStore.edit { it[Keys.DEPTH_FACTOR] = factor.coerceIn(0.5f, 1.4f) }
  }

  suspend fun saveHistory(entries: List<HistoryEntry>) {
    val trimmed = entries.take(40)
    context.calculatorDataStore.edit { it[Keys.HISTORY] = encodeHistory(trimmed) }
  }

  private fun encodeHistory(entries: List<HistoryEntry>): String =
    entries.joinToString(separator = "\n") { entry ->
      val safeExpr = entry.expression.replace("\n", " ").replace("\t", " ")
      val safeRes = entry.result.replace("\n", " ").replace("\t", " ")
      "${entry.id}\t$safeExpr\t$safeRes"
    }

  private fun decodeHistory(raw: String?): List<HistoryEntry> {
    if (raw.isNullOrBlank()) return emptyList()
    return raw.lines().mapNotNull { line ->
      val parts = line.split("\t")
      if (parts.size < 3) return@mapNotNull null
      val id = parts[0].toLongOrNull() ?: return@mapNotNull null
      HistoryEntry(id = id, expression = parts[1], result = parts[2])
    }
  }
}
