package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.engine.AngleUnit
import com.example.sensor.TiltState
import com.example.ui.theme.CalculatorMaterialPalette
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SpaceGroteskFontFamily
import com.example.ui.theme.VazirmatnFontFamily
import kotlinx.coroutines.launch

@Composable
fun DisplayBezel3D(
  expression: String,
  livePreview: String,
  justEvaluated: Boolean,
  errorMessageRes: Int?,
  angleUnit: AngleUnit,
  isScientific: Boolean,
  palette: CalculatorMaterialPalette,
  tiltState: TiltState,
  onToggleAngleUnit: () -> Unit,
  onCopyResult: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val exprScroll = rememberScrollState()
  val scope = rememberCoroutineScope()
  val dragAnimX = remember { Animatable(0f) }
  val dragAnimY = remember { Animatable(0f) }

  LaunchedEffect(expression) {
    exprScroll.scrollTo(exprScroll.maxValue)
  }

  val shape = RoundedCornerShape(24.dp)

  Box(
    modifier =
      modifier
        .testTag("calculator_display_bezel")
        .clip(shape)
        .pointerInput(tiltState) {
          detectDragGestures(
            onDragEnd = {
              scope.launch {
                launch {
                  dragAnimX.snapTo(tiltState.dragX)
                  dragAnimX.animateTo(0f, spring(dampingRatio = 0.65f, stiffness = 320f)) {
                    tiltState.dragX = value
                  }
                }
                launch {
                  dragAnimY.snapTo(tiltState.dragY)
                  dragAnimY.animateTo(0f, spring(dampingRatio = 0.65f, stiffness = 320f)) {
                    tiltState.dragY = value
                  }
                }
              }
            },
            onDragCancel = {
              tiltState.dragX = 0f
              tiltState.dragY = 0f
            },
          ) { change, dragAmount ->
            change.consume()
            tiltState.dragX = (tiltState.dragX + dragAmount.x / 240f).coerceIn(-0.85f, 0.85f)
            tiltState.dragY = (tiltState.dragY + dragAmount.y / 240f).coerceIn(-0.85f, 0.85f)
          }
        }
        .drawWithCache {
          val cornerPx = 24.dp.toPx()
          val corner = CornerRadius(cornerPx, cornerPx)
          val bgBrush =
            Brush.verticalGradient(
              colors = listOf(palette.displayTop, palette.displayBottom),
            )
          val sheenAlpha = if (palette.isDark) 0.055f else 0.25f
          val sheenBrush =
            Brush.linearGradient(
              colors = listOf(Color.Transparent, Color.White.copy(alpha = sheenAlpha), Color.Transparent),
              start = Offset(0f, 0f),
              end = Offset(size.width * 0.85f, size.height),
            )
          val innerShadowBrush =
            Brush.verticalGradient(
              colors = listOf(palette.displayBorderDark.copy(alpha = 0.55f), Color.Transparent),
              startY = 0f,
              endY = 12.dp.toPx(),
            )
          val borderBrush =
            Brush.verticalGradient(
              colors = listOf(palette.displayBorderDark, palette.displayBorderLight),
            )
          val borderStroke = Stroke(width = 1.5.dp.toPx())
          val innerShadowSize = Size(size.width, 14.dp.toPx())

          onDrawBehind {
            drawRoundRect(brush = bgBrush, cornerRadius = corner)
            drawRoundRect(brush = sheenBrush, cornerRadius = corner)
            drawRoundRect(brush = innerShadowBrush, size = innerShadowSize, cornerRadius = corner)
            drawRoundRect(brush = borderBrush, style = borderStroke, cornerRadius = corner)
          }
        }
        .padding(horizontal = 18.dp, vertical = 14.dp),
  ) {
    Column(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          if (isScientific) {
            Box(
              modifier =
                Modifier.testTag("angle_unit_pill")
                  .clip(RoundedCornerShape(10.dp))
                  .background(palette.accent.copy(alpha = 0.16f))
                  .border(1.dp, palette.accent.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                  .clickable(onClick = onToggleAngleUnit)
                  .padding(horizontal = 10.dp, vertical = 4.dp),
            ) {
              Text(
                text =
                  if (angleUnit == AngleUnit.DEG) stringResource(R.string.angle_deg)
                  else stringResource(R.string.angle_rad),
                color = palette.accent,
                style = MaterialTheme.typography.labelMedium,
                fontFamily = SpaceGroteskFontFamily,
              )
            }
          } else {
            Text(
              text = "PRISM 3D",
              color = palette.displaySecondaryText.copy(alpha = 0.65f),
              style = MaterialTheme.typography.labelMedium,
              letterSpacing = 1.4.sp,
            )
          }
        }

        if (expression.isNotEmpty()) {
          IconButton(
            onClick = onCopyResult,
            modifier =
              Modifier.minimumInteractiveComponentSize().size(36.dp).testTag("copy_result_button"),
          ) {
            Icon(
              imageVector = Icons.Rounded.ContentCopy,
              contentDescription = stringResource(R.string.action_copy_result),
              tint = palette.displaySecondaryText,
              modifier = Modifier.size(18.dp),
            )
          }
        } else {
          Spacer(modifier = Modifier.height(36.dp))
        }
      }

      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.End,
        ) {
          val displayText = expression.ifEmpty { "0" }
          val dynamicFontSize =
            when {
              displayText.length <= 8 -> 46.sp
              displayText.length <= 12 -> 38.sp
              displayText.length <= 16 -> 30.sp
              else -> 25.sp
            }

          Box(
            modifier = Modifier.fillMaxWidth().horizontalScroll(exprScroll),
            contentAlignment = Alignment.CenterEnd,
          ) {
            Text(
              text = displayText,
              modifier = Modifier.testTag("display_expression"),
              color =
                if (expression.isEmpty()) {
                  palette.displaySecondaryText.copy(alpha = 0.55f)
                } else if (justEvaluated) {
                  palette.accent
                } else {
                  palette.displayPrimaryText
                },
              style =
                TextStyle(
                  fontFamily = JetBrainsMonoFontFamily,
                  fontWeight = if (justEvaluated) FontWeight.Bold else FontWeight.SemiBold,
                  fontSize = dynamicFontSize,
                  fontFeatureSettings = "tnum",
                ),
              maxLines = 1,
              softWrap = false,
              textAlign = TextAlign.End,
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Box(
            modifier = Modifier.fillMaxWidth().height(26.dp),
            contentAlignment = Alignment.CenterEnd,
          ) {
            when {
              errorMessageRes != null -> {
                Text(
                  text = stringResource(errorMessageRes),
                  modifier = Modifier.testTag("display_error"),
                  color = palette.displayErrorText,
                  fontFamily = VazirmatnFontFamily,
                  fontWeight = FontWeight.Medium,
                  fontSize = 14.sp,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
              livePreview.isNotEmpty() -> {
                Text(
                  text = "= $livePreview",
                  modifier = Modifier.testTag("display_live_preview"),
                  color = palette.displaySecondaryText,
                  style =
                    TextStyle(
                      fontFamily = JetBrainsMonoFontFamily,
                      fontWeight = FontWeight.Medium,
                      fontSize = 19.sp,
                      fontFeatureSettings = "tnum",
                    ),
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
            }
          }
        }
      }
    }
  }
}
