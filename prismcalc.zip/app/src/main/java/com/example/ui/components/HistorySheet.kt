package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.History
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.HistoryEntry
import com.example.ui.theme.CalculatorMaterialPalette
import com.example.ui.theme.JetBrainsMonoFontFamily

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistorySheet(
  history: List<HistoryEntry>,
  palette: CalculatorMaterialPalette,
  onDismiss: () -> Unit,
  onSelectEntry: (HistoryEntry, Boolean) -> Unit,
  onClearHistory: () -> Unit,
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = palette.surfaceSheet,
    contentColor = palette.onSurfaceSheet,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = stringResource(R.string.title_history),
            style = MaterialTheme.typography.titleLarge,
            color = palette.onSurfaceSheet,
          )
          if (history.isNotEmpty()) {
            Text(
              text = stringResource(R.string.history_tap_hint),
              style = MaterialTheme.typography.bodyMedium,
              fontSize = 12.sp,
              color = palette.mutedText,
            )
          }
        }
        if (history.isNotEmpty()) {
          TextButton(
            onClick = onClearHistory,
            modifier = Modifier.testTag("clear_history_button"),
          ) {
            Icon(
              imageVector = Icons.Rounded.DeleteOutline,
              contentDescription = null,
              tint = palette.accent,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.size(4.dp))
            Text(
              text = stringResource(R.string.action_clear_history),
              color = palette.accent,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (history.isEmpty()) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(vertical = 36.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Box(
            modifier =
              Modifier.size(56.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(palette.accent.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Rounded.History,
              contentDescription = null,
              tint = palette.accent,
              modifier = Modifier.size(28.dp),
            )
          }
          Spacer(modifier = Modifier.height(14.dp))
          Text(
            text = stringResource(R.string.history_empty_title),
            style = MaterialTheme.typography.titleLarge,
            fontSize = 16.sp,
            color = palette.onSurfaceSheet,
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = stringResource(R.string.history_empty_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = palette.mutedText,
            textAlign = TextAlign.Center,
          )
        }
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxWidth().height(340.dp),
          contentPadding = PaddingValues(bottom = 20.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          items(history, key = { it.id }) { entry ->
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
              Column(
                modifier =
                  Modifier.fillMaxWidth()
                    .testTag("history_item_${entry.id}")
                    .clip(RoundedCornerShape(16.dp))
                    .background(palette.chassisTop)
                    .border(
                      1.dp,
                      palette.chassisBorderLight.copy(alpha = 0.35f),
                      RoundedCornerShape(16.dp),
                    )
                    .clickable {
                      onSelectEntry(entry, true)
                      onDismiss()
                    }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.End,
              ) {
                Text(
                  text = entry.expression,
                  color = palette.mutedText,
                  fontFamily = JetBrainsMonoFontFamily,
                  fontSize = 14.sp,
                  modifier =
                    Modifier.clickable {
                      onSelectEntry(entry, false)
                      onDismiss()
                    },
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "= ${entry.result}",
                  color = palette.accent,
                  fontFamily = JetBrainsMonoFontFamily,
                  fontWeight = FontWeight.Bold,
                  fontSize = 20.sp,
                )
              }
            }
          }
        }
      }
    }
  }
}
