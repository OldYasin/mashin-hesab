package com.example.ui

import android.app.Application
import androidx.annotation.StringRes
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.CalculatorPreferences
import com.example.data.HistoryEntry
import com.example.engine.AngleUnit
import com.example.engine.EvalErrorType
import com.example.engine.EvalResult
import com.example.engine.MathEngine
import com.example.ui.theme.CalculatorThemeStyle
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@Immutable
data class CalculatorUiState(
  val expression: String = "",
  val livePreview: String = "",
  val justEvaluated: Boolean = false,
  @StringRes val errorMessageRes: Int? = null,
  val isScientific: Boolean = false,
  val angleUnit: AngleUnit = AngleUnit.DEG,
  val themeStyle: CalculatorThemeStyle = CalculatorThemeStyle.OBSIDIAN,
  val parallaxEnabled: Boolean = true,
  val hapticsEnabled: Boolean = true,
  val soundEnabled: Boolean = true,
  val depthFactor: Float = 1.0f,
  val history: List<HistoryEntry> = emptyList(),
)

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

  private val preferences = CalculatorPreferences(application.applicationContext)

  private val _uiState = MutableStateFlow(CalculatorUiState())
  val uiState: StateFlow<CalculatorUiState> = _uiState.asStateFlow()

  init {
    viewModelScope.launch {
      preferences.preferencesFlow.collect { stored ->
        _uiState.update { current ->
          val preview =
            computeLivePreview(current.expression, stored.angleUnit, current.justEvaluated)
          current.copy(
            themeStyle = stored.themeStyle,
            isScientific = stored.isScientific,
            angleUnit = stored.angleUnit,
            parallaxEnabled = stored.parallaxEnabled,
            hapticsEnabled = stored.hapticsEnabled,
            soundEnabled = stored.soundEnabled,
            depthFactor = stored.depthFactor,
            history = stored.history,
            livePreview = preview,
          )
        }
      }
    }
  }

  fun onDigit(digit: String) {
    _uiState.update { state ->
      val base = if (state.justEvaluated) "" else state.expression
      val nextExpr =
        if (base == "0" && digit != ".") {
          digit
        } else {
          base + digit
        }
      updateExpression(state, nextExpr, justEvaluated = false)
    }
  }

  fun onDecimalPoint() {
    _uiState.update { state ->
      val base = if (state.justEvaluated) "" else state.expression
      if (base.isEmpty() || isOperatorChar(base.last()) || base.last() == '(') {
        updateExpression(state, base + "0.", justEvaluated = false)
      } else {
        // Prevent multiple dots inside the same number token
        var i = base.lastIndex
        var hasDot = false
        while (i >= 0 && (base[i].isDigit() || base[i] == '.')) {
          if (base[i] == '.') {
            hasDot = true
            break
          }
          i--
        }
        if (hasDot) {
          state
        } else if (base.last().isDigit()) {
          updateExpression(state, "$base.", justEvaluated = false)
        } else {
          updateExpression(state, "${base}0.", justEvaluated = false)
        }
      }
    }
  }

  fun onOperator(opSymbol: String) {
    _uiState.update { state ->
      val base = state.expression.replace(",", "")
      if (base.isEmpty()) {
        if (opSymbol == "−") {
          updateExpression(state, "−", justEvaluated = false)
        } else {
          state
        }
      } else {
        val last = base.last()
        val nextExpr =
          when {
            last == '(' && opSymbol == "−" -> "$base−"
            last == '(' -> base
            isOperatorChar(last) -> {
              if (opSymbol == "−" && (last == '×' || last == '÷' || last == '^')) {
                "$base−"
              } else if (base.length >= 2 && isOperatorChar(base[base.lastIndex - 1]) && last == '−') {
                base.dropLast(2) + opSymbol
              } else if (base.length == 1 && last == '−') {
                base
              } else {
                base.dropLast(1) + opSymbol
              }
            }
            else -> base + opSymbol
          }
        updateExpression(state, nextExpr, justEvaluated = false)
      }
    }
  }

  fun onSmartParenthesis() {
    _uiState.update { state ->
      val base = if (state.justEvaluated) "" else state.expression
      val openCount = base.count { it == '(' }
      val closeCount = base.count { it == ')' }
      val last = base.lastOrNull()
      val canClose =
        openCount > closeCount &&
          last != null &&
          (last.isDigit() || last == ')' || last == 'π' || last == 'e' || last == '%' || last == '!')
      val nextExpr = if (canClose) "$base)" else "$base("
      updateExpression(state, nextExpr, justEvaluated = false)
    }
  }

  fun onPercent() {
    _uiState.update { state ->
      val base = state.expression.replace(",", "")
      val last = base.lastOrNull() ?: return@update state
      if (last.isDigit() || last == ')' || last == 'π' || last == 'e') {
        updateExpression(state, "$base%", justEvaluated = false)
      } else {
        state
      }
    }
  }

  fun onFunction(fnToken: String) {
    _uiState.update { state ->
      val base = if (state.justEvaluated && state.expression.isNotEmpty()) {
        // Wrap or apply after previous result
        ""
      } else {
        state.expression
      }
      val nextExpr =
        when (fnToken) {
          "x²" -> {
            val source = state.expression.replace(",", "")
            if (source.isEmpty() || isOperatorChar(source.last()) || source.last() == '(') {
              state.expression
            } else {
              "$source^2"
            }
          }
          "!" -> {
            val source = state.expression.replace(",", "")
            if (source.isEmpty() || isOperatorChar(source.last()) || source.last() == '(') {
              state.expression
            } else {
              "$source!"
            }
          }
          "π", "e" -> base + fnToken
          else -> "$base$fnToken("
        }
      updateExpression(state, nextExpr, justEvaluated = false)
    }
  }

  fun onToggleSign() {
    _uiState.update { state ->
      val expr = state.expression.replace(",", "")
      if (expr.isEmpty()) {
        return@update updateExpression(state, "−", justEvaluated = false)
      }
      if (expr == "−") {
        return@update updateExpression(state, "", justEvaluated = false)
      }
      // Toggle leading minus if entire expression is a single number
      val isSingleNumber =
        expr.all { it.isDigit() || it == '.' } ||
          (expr.startsWith("−") && expr.drop(1).all { it.isDigit() || it == '.' })
      val nextExpr =
        if (isSingleNumber) {
          if (expr.startsWith("−")) expr.drop(1) else "−$expr"
        } else {
          if (expr.startsWith("−(") && expr.endsWith(")")) {
            expr.substring(2, expr.length - 1)
          } else {
            "−($expr)"
          }
        }
      updateExpression(state, nextExpr, justEvaluated = false)
    }
  }

  fun onBackspace() {
    _uiState.update { state ->
      if (state.expression.isEmpty()) return@update state
      if (state.justEvaluated) {
        return@update updateExpression(state, "", justEvaluated = false)
      }
      val trimmed = removeLastToken(state.expression)
      updateExpression(state, trimmed, justEvaluated = false)
    }
  }

  fun onClear() {
    _uiState.update {
      it.copy(
        expression = "",
        livePreview = "",
        justEvaluated = false,
        errorMessageRes = null,
      )
    }
  }

  fun onEquals() {
    val current = _uiState.value
    val expr = current.expression.trim()
    if (expr.isEmpty()) return

    val cleanExpr = expr.replace(",", "")
    when (val res = MathEngine.evaluate(cleanExpr, current.angleUnit, allowIncomplete = false)) {
      is EvalResult.Success -> {
        val rawResult = res.formatted.replace(",", "")
        val shouldRecord = cleanExpr != rawResult && expr != res.formatted
        val newHistory =
          if (shouldRecord) {
            val entry =
              HistoryEntry(
                id = System.currentTimeMillis(),
                expression = expr,
                result = res.formatted,
              )
            (listOf(entry) + current.history).take(40)
          } else {
            current.history
          }

        _uiState.update {
          it.copy(
            expression = res.formatted,
            livePreview = "",
            justEvaluated = true,
            errorMessageRes = null,
            history = newHistory,
          )
        }
        if (shouldRecord) {
          viewModelScope.launch { preferences.saveHistory(newHistory) }
        }
      }
      is EvalResult.Error -> {
        val errRes =
          when (res.type) {
            EvalErrorType.DIVISION_BY_ZERO -> R.string.error_division_by_zero
            EvalErrorType.DOMAIN -> R.string.error_domain
            EvalErrorType.SYNTAX -> R.string.error_syntax
          }
        _uiState.update { it.copy(errorMessageRes = errRes) }
      }
      EvalResult.Incomplete -> Unit
    }
  }

  fun onRestoreHistory(entry: HistoryEntry, useResultOnly: Boolean) {
    _uiState.update { state ->
      val next = if (useResultOnly) entry.result else entry.expression
      updateExpression(state, next, justEvaluated = useResultOnly)
    }
  }

  fun onClearHistory() {
    _uiState.update { it.copy(history = emptyList()) }
    viewModelScope.launch { preferences.saveHistory(emptyList()) }
  }

  fun onToggleScientific() {
    val next = !_uiState.value.isScientific
    _uiState.update { it.copy(isScientific = next) }
    viewModelScope.launch { preferences.setScientific(next) }
  }

  fun onToggleAngleUnit() {
    val next = if (_uiState.value.angleUnit == AngleUnit.DEG) AngleUnit.RAD else AngleUnit.DEG
    _uiState.update { state ->
      val preview = computeLivePreview(state.expression, next, state.justEvaluated)
      state.copy(angleUnit = next, livePreview = preview)
    }
    viewModelScope.launch { preferences.setAngleUnit(next) }
  }

  fun onSelectTheme(style: CalculatorThemeStyle) {
    _uiState.update { it.copy(themeStyle = style) }
    viewModelScope.launch { preferences.setTheme(style) }
  }

  fun onSetParallaxEnabled(enabled: Boolean) {
    _uiState.update { it.copy(parallaxEnabled = enabled) }
    viewModelScope.launch { preferences.setParallaxEnabled(enabled) }
  }

  fun onSetHapticsEnabled(enabled: Boolean) {
    _uiState.update { it.copy(hapticsEnabled = enabled) }
    viewModelScope.launch { preferences.setHapticsEnabled(enabled) }
  }

  fun onSetSoundEnabled(enabled: Boolean) {
    _uiState.update { it.copy(soundEnabled = enabled) }
    viewModelScope.launch { preferences.setSoundEnabled(enabled) }
  }

  fun onSetDepthFactor(factor: Float) {
    val clamped = factor.coerceIn(0.5f, 1.4f)
    _uiState.update { it.copy(depthFactor = clamped) }
    viewModelScope.launch { preferences.setDepthFactor(clamped) }
  }

  private fun updateExpression(
    state: CalculatorUiState,
    nextExpr: String,
    justEvaluated: Boolean,
  ): CalculatorUiState {
    val preview = computeLivePreview(nextExpr, state.angleUnit, justEvaluated)
    return state.copy(
      expression = nextExpr,
      livePreview = preview,
      justEvaluated = justEvaluated,
      errorMessageRes = null,
    )
  }

  private fun computeLivePreview(
    expression: String,
    angleUnit: AngleUnit,
    justEvaluated: Boolean,
  ): String {
    if (justEvaluated || expression.isBlank()) return ""
    val clean = expression.replace(",", "")
    if (clean.all { it.isDigit() || it == '.' || it == '−' }) return ""
    return when (val res = MathEngine.evaluate(clean, angleUnit, allowIncomplete = true)) {
      is EvalResult.Success -> if (res.formatted == expression) "" else res.formatted
      else -> ""
    }
  }

  private fun isOperatorChar(c: Char): Boolean =
    c == '+' || c == '−' || c == '-' || c == '×' || c == '*' || c == '÷' || c == '/' || c == '^'

  private fun removeLastToken(expr: String): String {
    val functionSuffixes = listOf("asin(", "acos(", "atan(", "sqrt(", "sin(", "cos(", "tan(", "log(", "ln(", "√(")
    for (fn in functionSuffixes) {
      if (expr.endsWith(fn)) {
        return expr.dropLast(fn.length)
      }
    }
    return expr.dropLast(1)
  }
}
