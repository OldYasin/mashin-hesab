package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.CalculatorMaterialPalette
import com.example.ui.theme.ShabnamFontFamily
import com.example.ui.theme.SpaceGroteskFontFamily

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
  palette: CalculatorMaterialPalette,
  parallaxEnabled: Boolean,
  hapticsEnabled: Boolean,
  soundEnabled: Boolean,
  depthFactor: Float,
  onToggleParallax: (Boolean) -> Unit,
  onToggleHaptics: (Boolean) -> Unit,
  onToggleSound: (Boolean) -> Unit,
  onDepthChange: (Float) -> Unit,
  onDepthCommit: () -> Unit,
  onDismiss: () -> Unit,
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val context = LocalContext.current
  val telegramId = stringResource(R.string.telegram_id)
  var copiedBadgeVisible by remember { mutableStateOf(false) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = palette.surfaceSheet,
    contentColor = palette.onSurfaceSheet,
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .navigationBarsPadding()
          .padding(horizontal = 20.dp)
          .padding(bottom = 26.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Text(
        text = stringResource(R.string.settings_section_title),
        style = MaterialTheme.typography.titleLarge,
        color = palette.onSurfaceSheet,
      )

      SettingToggleRow(
        title = stringResource(R.string.settings_haptic_title),
        subtitle = stringResource(R.string.settings_haptic_desc),
        checked = hapticsEnabled,
        palette = palette,
        testTag = "switch_haptics",
        onCheckedChange = onToggleHaptics,
      )

      SettingToggleRow(
        title = stringResource(R.string.settings_sound_title),
        subtitle = stringResource(R.string.settings_sound_desc),
        checked = soundEnabled,
        palette = palette,
        testTag = "switch_sound",
        onCheckedChange = onToggleSound,
      )

      SettingToggleRow(
        title = stringResource(R.string.settings_parallax_title),
        subtitle = stringResource(R.string.settings_parallax_desc),
        checked = parallaxEnabled,
        palette = palette,
        testTag = "switch_parallax",
        onCheckedChange = onToggleParallax,
      )

      Column(
        modifier =
          Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(palette.chassisTop)
            .border(1.dp, palette.chassisBorderLight.copy(alpha = 0.55f), RoundedCornerShape(18.dp))
            .padding(horizontal = 16.dp, vertical = 14.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = stringResource(R.string.settings_depth_title),
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium,
            color = palette.onSurfaceSheet,
          )
          Text(
            text = "${(depthFactor * 100).toInt()}%",
            fontFamily = SpaceGroteskFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = palette.accent,
          )
        }
        Slider(
          value = depthFactor,
          onValueChange = onDepthChange,
          onValueChangeFinished = onDepthCommit,
          valueRange = 0.5f..1.4f,
          modifier = Modifier.testTag("slider_3d_depth"),
          colors =
            SliderDefaults.colors(
              thumbColor = palette.accent,
              activeTrackColor = palette.accent,
              inactiveTrackColor = palette.keySocket,
            ),
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = stringResource(R.string.depth_low),
            style = MaterialTheme.typography.labelMedium,
            color = palette.mutedText,
          )
          Text(
            text = stringResource(R.string.depth_mid),
            style = MaterialTheme.typography.labelMedium,
            color = palette.mutedText,
          )
          Text(
            text = stringResource(R.string.depth_high),
            style = MaterialTheme.typography.labelMedium,
            color = palette.mutedText,
          )
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = stringResource(R.string.about_section_title),
        style = MaterialTheme.typography.titleLarge,
        color = palette.onSurfaceSheet,
      )

      // About Me Card (درباره من: سازنده vicious cycle و لینک مستقیم تلگرام @WhrAmIGoing)
      Column(
        modifier =
          Modifier.fillMaxWidth()
            .testTag("about_me_card")
            .clip(RoundedCornerShape(20.dp))
            .background(palette.chassisTop)
            .border(1.dp, palette.accent.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Box(
              modifier =
                Modifier.size(38.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .background(palette.accent.copy(alpha = 0.16f)),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Rounded.Calculate,
                contentDescription = null,
                tint = palette.accent,
                modifier = Modifier.size(22.dp),
              )
            }
            Column {
              Text(
                text = stringResource(R.string.app_name),
                fontFamily = ShabnamFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = palette.onSurfaceSheet,
              )
              Text(
                text = stringResource(R.string.app_version_badge),
                fontFamily = ShabnamFontFamily,
                fontSize = 12.sp,
                color = palette.mutedText,
              )
            }
          }
        }

        HorizontalDivider(color = palette.chassisBorderLight.copy(alpha = 0.4f))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Rounded.Person,
              contentDescription = null,
              tint = palette.accent,
              modifier = Modifier.size(18.dp),
            )
            Text(
              text = stringResource(R.string.developer_label),
              fontFamily = ShabnamFontFamily,
              fontWeight = FontWeight.Medium,
              fontSize = 14.sp,
              color = palette.mutedText,
            )
          }

          Text(
            text = stringResource(R.string.developer_name),
            fontFamily = SpaceGroteskFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = palette.onSurfaceSheet,
          )
        }

        // Clickable Telegram Launch Pill + Copy Button
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            modifier =
              Modifier.weight(1f)
                .testTag("telegram_link_button")
                .minimumInteractiveComponentSize()
                .clip(RoundedCornerShape(14.dp))
                .background(palette.accent.copy(alpha = 0.14f))
                .border(1.dp, palette.accent.copy(alpha = 0.42f), RoundedCornerShape(14.dp))
                .clickable { openTelegramProfile(context, "WhrAmIGoing") }
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Rounded.Send,
                contentDescription = null,
                tint = palette.accent,
                modifier = Modifier.size(18.dp),
              )
              Text(
                text = telegramId,
                fontFamily = SpaceGroteskFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = palette.accent,
              )
            }

            Row(
              horizontalArrangement = Arrangement.spacedBy(4.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text =
                  if (copiedBadgeVisible) stringResource(R.string.telegram_copied)
                  else stringResource(R.string.telegram_open_hint),
                fontFamily = ShabnamFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp,
                color = palette.accent,
              )
              Icon(
                imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                contentDescription = null,
                tint = palette.accent,
                modifier = Modifier.size(15.dp),
              )
            }
          }

          IconButton(
            onClick = {
              val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
              cm?.setPrimaryClip(ClipData.newPlainText("Telegram ID", telegramId))
              copiedBadgeVisible = true
            },
            modifier =
              Modifier.testTag("copy_telegram_button")
                .minimumInteractiveComponentSize()
                .clip(RoundedCornerShape(14.dp))
                .background(palette.keySocket.copy(alpha = 0.45f))
                .border(1.dp, palette.chassisBorderLight.copy(alpha = 0.45f), RoundedCornerShape(14.dp)),
          ) {
            Icon(
              imageVector = Icons.Rounded.ContentCopy,
              contentDescription = stringResource(R.string.cd_copy_telegram),
              tint = palette.onSurfaceSheet,
              modifier = Modifier.size(18.dp),
            )
          }
        }
      }
    }
  }
}

private fun openTelegramProfile(context: Context, username: String) {
  val tgIntent = Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?domain=$username")).apply {
    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
  }
  try {
    context.startActivity(tgIntent)
  } catch (_: Exception) {
    val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/$username")).apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    try {
      context.startActivity(webIntent)
    } catch (_: Exception) {
      // No browser or Telegram client installed
    }
  }
}

@Composable
private fun SettingToggleRow(
  title: String,
  subtitle: String,
  checked: Boolean,
  palette: CalculatorMaterialPalette,
  testTag: String,
  onCheckedChange: (Boolean) -> Unit,
) {
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(18.dp))
        .background(palette.chassisTop)
        .border(1.dp, palette.chassisBorderLight.copy(alpha = 0.55f), RoundedCornerShape(18.dp))
        .clickable { onCheckedChange(!checked) }
        .padding(horizontal = 16.dp, vertical = 12.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
      Text(
        text = title,
        style = MaterialTheme.typography.bodyLarge,
        fontWeight = FontWeight.Medium,
        color = palette.onSurfaceSheet,
      )
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodyMedium,
        color = palette.mutedText,
      )
    }
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      modifier = Modifier.testTag(testTag),
      colors =
        SwitchDefaults.colors(
          checkedThumbColor = palette.onAccent,
          checkedTrackColor = palette.accent,
          uncheckedThumbColor = palette.mutedText,
          uncheckedTrackColor = palette.keySocket,
        ),
    )
  }
}
