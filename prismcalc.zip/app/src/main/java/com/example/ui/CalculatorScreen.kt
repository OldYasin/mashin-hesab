package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.sensor.TiltState
import com.example.sensor.rememberTiltState
import com.example.ui.components.DisplayBezel3D
import com.example.ui.components.HistorySheet
import com.example.ui.components.SettingsSheet
import com.example.ui.components.TactileKey3D
import com.example.ui.components.TopControlBar
import com.example.ui.theme.CalculatorMaterialPalette
import com.example.ui.theme.LocalCalculatorPalette
import kotlinx.coroutines.launch

@Composable
fun CalculatorScreen(
  uiState: CalculatorUiState,
  viewModel: CalculatorViewModel,
  modifier: Modifier = Modifier,
) {
  val palette = LocalCalculatorPalette.current
  val tiltState = rememberTiltState(enabled = uiState.parallaxEnabled)
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()
  val context = LocalContext.current
  val copiedMsg = stringResource(R.string.copied_snackbar)

  var showHistory by remember { mutableStateOf(false) }
  var showSettings by remember { mutableStateOf(false) }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    containerColor = Color.Transparent,
    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
  ) { _ ->
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(
            Brush.verticalGradient(
              colors = listOf(palette.backdropTop, palette.backdropBottom),
            )
          )
          .windowInsetsPadding(WindowInsets.safeDrawing),
      contentAlignment = Alignment.Center,
    ) {
      BoxWithConstraints(
        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
      ) {
        val isWideLayout = maxWidth >= 600.dp && maxWidth > maxHeight * 0.95f

        if (isWideLayout) {
          Wide3DCalculatorLayout(
            uiState = uiState,
            palette = palette,
            tiltState = tiltState,
            viewModel = viewModel,
            onOpenHistory = { showHistory = true },
            onOpenSettings = { showSettings = true },
            onCopyResult = {
              copyToClipboard(context, uiState.expression)
              scope.launch { snackbarHostState.showSnackbar(copiedMsg) }
            },
          )
        } else {
          Compact3DCalculatorLayout(
            uiState = uiState,
            palette = palette,
            tiltState = tiltState,
            viewModel = viewModel,
            onOpenHistory = { showHistory = true },
            onOpenSettings = { showSettings = true },
            onCopyResult = {
              copyToClipboard(context, uiState.expression)
              scope.launch { snackbarHostState.showSnackbar(copiedMsg) }
            },
          )
        }
      }
    }
  }

  if (showHistory) {
    HistorySheet(
      history = uiState.history,
      palette = palette,
      onDismiss = { showHistory = false },
      onSelectEntry = { entry, useResultOnly ->
        viewModel.onRestoreHistory(entry, useResultOnly)
      },
      onClearHistory = viewModel::onClearHistory,
    )
  }

  if (showSettings) {
    SettingsSheet(
      palette = palette,
      parallaxEnabled = uiState.parallaxEnabled,
      hapticsEnabled = uiState.hapticsEnabled,
      soundEnabled = uiState.soundEnabled,
      depthFactor = uiState.depthFactor,
      onToggleParallax = viewModel::onSetParallaxEnabled,
      onToggleHaptics = viewModel::onSetHapticsEnabled,
      onToggleSound = viewModel::onSetSoundEnabled,
      onDepthChange = viewModel::onSetDepthFactor,
      onDepthCommit = viewModel::onCommitDepthFactor,
      onDismiss = { showSettings = false },
    )
  }
}

@Composable
private fun Compact3DCalculatorLayout(
  uiState: CalculatorUiState,
  palette: CalculatorMaterialPalette,
  tiltState: TiltState,
  viewModel: CalculatorViewModel,
  onOpenHistory: () -> Unit,
  onOpenSettings: () -> Unit,
  onCopyResult: () -> Unit,
) {
  Column(
    modifier =
      Modifier.fillMaxHeight()
        .widthIn(max = 520.dp)
        .fillMaxWidth()
        .graphicsLayer {
          val tx = tiltState.x
          val ty = tiltState.y
          if (tx != 0f || ty != 0f) {
            rotationX = -ty * 3.5f
            rotationY = tx * 3.5f
            cameraDistance = 18f * density
          }
        }
        .chassis3DBackground(palette)
        .padding(horizontal = 14.dp, vertical = 14.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    TopControlBar(
      palette = palette,
      activeTheme = uiState.themeStyle,
      isScientific = uiState.isScientific,
      historyCount = uiState.history.size,
      onToggleScientific = viewModel::onToggleScientific,
      onOpenHistory = onOpenHistory,
      onSelectTheme = viewModel::onSelectTheme,
      onOpenSettings = onOpenSettings,
    )

    DisplayBezel3D(
      expression = uiState.expression,
      livePreview = uiState.livePreview,
      justEvaluated = uiState.justEvaluated,
      errorMessageRes = uiState.errorMessageRes,
      angleUnit = uiState.angleUnit,
      isScientific = uiState.isScientific,
      palette = palette,
      tiltState = tiltState,
      onToggleAngleUnit = viewModel::onToggleAngleUnit,
      onCopyResult = onCopyResult,
      modifier = Modifier.fillMaxWidth().weight(0.29f),
    )

    Column(
      modifier = Modifier.fillMaxWidth().weight(0.71f),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      AnimatedVisibility(
        visible = uiState.isScientific,
        enter =
          expandVertically(animationSpec = spring(dampingRatio = 0.8f, stiffness = 700f)) +
            fadeIn(),
        exit =
          shrinkVertically(animationSpec = spring(dampingRatio = 0.85f, stiffness = 700f)) +
            fadeOut(),
      ) {
        ScientificKeypadSection(
          uiState = uiState,
          palette = palette,
          viewModel = viewModel,
          rowHeight = 52.dp,
          modifier = Modifier.fillMaxWidth().padding(bottom = 2.dp),
        )
      }

      MainKeypadGrid(
        uiState = uiState,
        palette = palette,
        viewModel = viewModel,
        modifier = Modifier.fillMaxWidth().weight(1f),
      )
    }
  }
}

@Composable
private fun Wide3DCalculatorLayout(
  uiState: CalculatorUiState,
  palette: CalculatorMaterialPalette,
  tiltState: TiltState,
  viewModel: CalculatorViewModel,
  onOpenHistory: () -> Unit,
  onOpenSettings: () -> Unit,
  onCopyResult: () -> Unit,
) {
  Column(
    modifier =
      Modifier.widthIn(max = 960.dp)
        .fillMaxSize()
        .graphicsLayer {
          val tx = tiltState.x
          val ty = tiltState.y
          if (tx != 0f || ty != 0f) {
            rotationX = -ty * 2.8f
            rotationY = tx * 2.8f
            cameraDistance = 20f * density
          }
        }
        .chassis3DBackground(palette)
        .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    TopControlBar(
      palette = palette,
      activeTheme = uiState.themeStyle,
      isScientific = uiState.isScientific,
      historyCount = uiState.history.size,
      onToggleScientific = viewModel::onToggleScientific,
      onOpenHistory = onOpenHistory,
      onSelectTheme = viewModel::onSelectTheme,
      onOpenSettings = onOpenSettings,
    )

    Row(
      modifier = Modifier.fillMaxWidth().weight(1f),
      horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Column(
        modifier = Modifier.weight(0.46f).fillMaxHeight(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        DisplayBezel3D(
          expression = uiState.expression,
          livePreview = uiState.livePreview,
          justEvaluated = uiState.justEvaluated,
          errorMessageRes = uiState.errorMessageRes,
          angleUnit = uiState.angleUnit,
          isScientific = uiState.isScientific,
          palette = palette,
          tiltState = tiltState,
          onToggleAngleUnit = viewModel::onToggleAngleUnit,
          onCopyResult = onCopyResult,
          modifier = Modifier.fillMaxWidth().weight(1f),
        )

        if (uiState.isScientific) {
          ScientificKeypadSection(
            uiState = uiState,
            palette = palette,
            viewModel = viewModel,
            rowHeight = 52.dp,
            modifier = Modifier.fillMaxWidth(),
          )
        }
      }

      MainKeypadGrid(
        uiState = uiState,
        palette = palette,
        viewModel = viewModel,
        modifier = Modifier.weight(0.54f).fillMaxHeight(),
      )
    }
  }
}

@Composable
private fun ScientificKeypadSection(
  uiState: CalculatorUiState,
  palette: CalculatorMaterialPalette,
  viewModel: CalculatorViewModel,
  rowHeight: Dp,
  modifier: Modifier = Modifier,
) {
  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
    Column(
      modifier = modifier,
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth().height(rowHeight),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        val row1 =
          listOf(
            "sin" to { viewModel.onFunction("sin") },
            "cos" to { viewModel.onFunction("cos") },
            "tan" to { viewModel.onFunction("tan") },
            "ln" to { viewModel.onFunction("ln") },
            "log" to { viewModel.onFunction("log") },
          )
        row1.forEach { (label, action) ->
          TactileKey3D(
            label = label,
            colors = palette.scientificKey,
            socketColor = palette.keySocket,
            depthFactor = uiState.depthFactor * 0.85f,
            hapticsEnabled = uiState.hapticsEnabled,
            soundEnabled = uiState.soundEnabled,
            onClick = action,
            fontSize = 15.sp,
            cornerRadius = 15.dp,
            modifier = Modifier.weight(1f).fillMaxHeight(),
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth().height(rowHeight),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        val row2 =
          listOf(
            "√" to { viewModel.onFunction("√") },
            "^" to { viewModel.onOperator("^") },
            "x²" to { viewModel.onFunction("x²") },
            "π" to { viewModel.onFunction("π") },
            "!" to { viewModel.onFunction("!") },
          )
        row2.forEach { (label, action) ->
          TactileKey3D(
            label = label,
            colors = palette.scientificKey,
            socketColor = palette.keySocket,
            depthFactor = uiState.depthFactor * 0.85f,
            hapticsEnabled = uiState.hapticsEnabled,
            soundEnabled = uiState.soundEnabled,
            onClick = action,
            fontSize = 16.sp,
            cornerRadius = 15.dp,
            modifier = Modifier.weight(1f).fillMaxHeight(),
          )
        }
      }
    }
  }
}

@Composable
private fun MainKeypadGrid(
  uiState: CalculatorUiState,
  palette: CalculatorMaterialPalette,
  viewModel: CalculatorViewModel,
  modifier: Modifier = Modifier,
) {
  val clearCd = stringResource(R.string.cd_clear)
  val backspaceCd = stringResource(R.string.cd_backspace)
  val equalsCd = stringResource(R.string.cd_equals)

  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
    Column(
      modifier = modifier,
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth().weight(1f),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        TactileKey3D(
          label = "AC",
          colors = palette.clearKey,
          socketColor = palette.keySocket,
          depthFactor = uiState.depthFactor,
          hapticsEnabled = uiState.hapticsEnabled,
          soundEnabled = uiState.soundEnabled,
          onClick = viewModel::onClear,
          testTag = "key_clear",
          contentDescriptionText = clearCd,
          fontSize = 20.sp,
          modifier = Modifier.weight(1f).fillMaxHeight(),
        )
        TactileKey3D(
          label = "( )",
          colors = palette.functionKey,
          socketColor = palette.keySocket,
          depthFactor = uiState.depthFactor,
          hapticsEnabled = uiState.hapticsEnabled,
          soundEnabled = uiState.soundEnabled,
          onClick = viewModel::onSmartParenthesis,
          testTag = "key_paren",
          fontSize = 20.sp,
          modifier = Modifier.weight(1f).fillMaxHeight(),
        )
        TactileKey3D(
          label = "%",
          colors = palette.functionKey,
          socketColor = palette.keySocket,
          depthFactor = uiState.depthFactor,
          hapticsEnabled = uiState.hapticsEnabled,
          soundEnabled = uiState.soundEnabled,
          onClick = viewModel::onPercent,
          testTag = "key_percent",
          fontSize = 22.sp,
          modifier = Modifier.weight(1f).fillMaxHeight(),
        )
        TactileKey3D(
          label = "÷",
          colors = palette.operatorKey,
          socketColor = palette.keySocket,
          depthFactor = uiState.depthFactor,
          hapticsEnabled = uiState.hapticsEnabled,
          soundEnabled = uiState.soundEnabled,
          onClick = { viewModel.onOperator("÷") },
          testTag = "key_divide",
          fontSize = 27.sp,
          modifier = Modifier.weight(1f).fillMaxHeight(),
        )
      }

      DigitOperatorRow(
        digits = listOf("7", "8", "9"),
        operatorLabel = "×",
        operatorTag = "key_multiply",
        uiState = uiState,
        palette = palette,
        onDigit = viewModel::onDigit,
        onOperator = { viewModel.onOperator("×") },
        modifier = Modifier.fillMaxWidth().weight(1f),
      )

      DigitOperatorRow(
        digits = listOf("4", "5", "6"),
        operatorLabel = "−",
        operatorTag = "key_subtract",
        uiState = uiState,
        palette = palette,
        onDigit = viewModel::onDigit,
        onOperator = { viewModel.onOperator("−") },
        modifier = Modifier.fillMaxWidth().weight(1f),
      )

      DigitOperatorRow(
        digits = listOf("1", "2", "3"),
        operatorLabel = "+",
        operatorTag = "key_add",
        uiState = uiState,
        palette = palette,
        onDigit = viewModel::onDigit,
        onOperator = { viewModel.onOperator("+") },
        modifier = Modifier.fillMaxWidth().weight(1f),
      )

      Row(
        modifier = Modifier.fillMaxWidth().weight(1f),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        TactileKey3D(
          label = "0",
          colors = palette.digitKey,
          socketColor = palette.keySocket,
          depthFactor = uiState.depthFactor,
          hapticsEnabled = uiState.hapticsEnabled,
          soundEnabled = uiState.soundEnabled,
          onClick = { viewModel.onDigit("0") },
          testTag = "key_0",
          fontSize = 24.sp,
          modifier = Modifier.weight(1f).fillMaxHeight(),
        )
        TactileKey3D(
          label = ".",
          colors = palette.digitKey,
          socketColor = palette.keySocket,
          depthFactor = uiState.depthFactor,
          hapticsEnabled = uiState.hapticsEnabled,
          soundEnabled = uiState.soundEnabled,
          onClick = viewModel::onDecimalPoint,
          testTag = "key_dot",
          fontSize = 26.sp,
          modifier = Modifier.weight(1f).fillMaxHeight(),
        )
        TactileKey3D(
          label = "⌫",
          icon = Icons.AutoMirrored.Rounded.Backspace,
          colors = palette.functionKey,
          socketColor = palette.keySocket,
          depthFactor = uiState.depthFactor,
          hapticsEnabled = uiState.hapticsEnabled,
          soundEnabled = uiState.soundEnabled,
          onClick = viewModel::onBackspace,
          testTag = "key_backspace",
          contentDescriptionText = backspaceCd,
          modifier = Modifier.weight(1f).fillMaxHeight(),
        )
        TactileKey3D(
          label = "=",
          colors = palette.equalsKey,
          socketColor = palette.keySocket,
          depthFactor = uiState.depthFactor,
          hapticsEnabled = uiState.hapticsEnabled,
          soundEnabled = uiState.soundEnabled,
          onClick = viewModel::onEquals,
          testTag = "key_equals",
          contentDescriptionText = equalsCd,
          fontSize = 28.sp,
          isAccentHero = true,
          modifier = Modifier.weight(1f).fillMaxHeight(),
        )
      }
    }
  }
}

@Composable
private fun DigitOperatorRow(
  digits: List<String>,
  operatorLabel: String,
  operatorTag: String,
  uiState: CalculatorUiState,
  palette: CalculatorMaterialPalette,
  onDigit: (String) -> Unit,
  onOperator: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier,
    horizontalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    digits.forEach { d ->
      TactileKey3D(
        label = d,
        colors = palette.digitKey,
        socketColor = palette.keySocket,
        depthFactor = uiState.depthFactor,
        hapticsEnabled = uiState.hapticsEnabled,
        soundEnabled = uiState.soundEnabled,
        onClick = { onDigit(d) },
        testTag = "key_$d",
        fontSize = 24.sp,
        modifier = Modifier.weight(1f).fillMaxHeight(),
      )
    }
    TactileKey3D(
      label = operatorLabel,
      colors = palette.operatorKey,
      socketColor = palette.keySocket,
      depthFactor = uiState.depthFactor,
      hapticsEnabled = uiState.hapticsEnabled,
      soundEnabled = uiState.soundEnabled,
      onClick = onOperator,
      testTag = operatorTag,
      fontSize = 27.sp,
      modifier = Modifier.weight(1f).fillMaxHeight(),
    )
  }
}

private fun Modifier.chassis3DBackground(palette: CalculatorMaterialPalette): Modifier =
  this.drawWithCache {
    val cornerPx = 32.dp.toPx()
    val corner = CornerRadius(cornerPx, cornerPx)
    val shadowColor = Color.Black.copy(alpha = if (palette.isDark) 0.48f else 0.18f)
    val shadowOffset = Offset(0f, 8.dp.toPx())
    val bodyBrush =
      Brush.verticalGradient(
        colors = listOf(palette.chassisTop, palette.chassisBottom),
      )
    val borderBrush =
      Brush.verticalGradient(
        colors = listOf(palette.chassisBorderLight, palette.chassisBorderDark),
      )
    val borderStroke = Stroke(width = 1.75.dp.toPx())

    onDrawBehind {
      drawRoundRect(
        color = shadowColor,
        topLeft = shadowOffset,
        size = Size(size.width, size.height),
        cornerRadius = corner,
      )
      drawRoundRect(brush = bodyBrush, cornerRadius = corner)
      drawRoundRect(brush = borderBrush, style = borderStroke, cornerRadius = corner)
    }
  }

private fun copyToClipboard(context: Context, text: String) {
  if (text.isBlank()) return
  val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
  clipboard.setPrimaryClip(ClipData.newPlainText("PrismCalc Result", text))
}
