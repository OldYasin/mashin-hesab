package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf

val LocalCalculatorPalette = staticCompositionLocalOf { ObsidianPalette }

@Composable
fun PrismCalcTheme(
  palette: CalculatorMaterialPalette = ObsidianPalette,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    if (palette.isDark) {
      darkColorScheme(
        primary = palette.accent,
        onPrimary = palette.onAccent,
        background = palette.backdropTop,
        onBackground = palette.displayPrimaryText,
        surface = palette.surfaceSheet,
        onSurface = palette.onSurfaceSheet,
        surfaceVariant = palette.chassisTop,
        onSurfaceVariant = palette.mutedText,
      )
    } else {
      lightColorScheme(
        primary = palette.accent,
        onPrimary = palette.onAccent,
        background = palette.backdropTop,
        onBackground = palette.displayPrimaryText,
        surface = palette.surfaceSheet,
        onSurface = palette.onSurfaceSheet,
        surfaceVariant = palette.chassisTop,
        onSurfaceVariant = palette.mutedText,
      )
    }

  CompositionLocalProvider(LocalCalculatorPalette provides palette) {
    MaterialTheme(colorScheme = colorScheme, typography = AppTypography, content = content)
  }
}
