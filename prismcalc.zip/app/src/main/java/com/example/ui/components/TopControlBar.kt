package com.example.ui.components

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.CalculatorMaterialPalette
import com.example.ui.theme.CalculatorThemeStyle
import com.example.ui.theme.SpaceGroteskFontFamily

@Composable
fun TopControlBar(
  palette: CalculatorMaterialPalette,
  activeTheme: CalculatorThemeStyle,
  isScientific: Boolean,
  historyCount: Int,
  onToggleScientific: () -> Unit,
  onOpenHistory: () -> Unit,
  onSelectTheme: (CalculatorThemeStyle) -> Unit,
  onOpenSettings: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val view = LocalView.current

  Row(
    modifier = modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Row(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      val sciBg =
        if (isScientific) palette.accent.copy(alpha = 0.2f)
        else palette.chassisTop.copy(alpha = 0.9f)
      val sciTint = if (isScientific) palette.accent else palette.mutedText

      Row(
        modifier =
          Modifier.testTag("scientific_toggle_button")
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(14.dp))
            .background(sciBg)
            .border(
              1.dp,
              if (isScientific) palette.accent.copy(alpha = 0.5f)
              else palette.chassisBorderLight.copy(alpha = 0.5f),
              RoundedCornerShape(14.dp),
            )
            .clickable(
              interactionSource = remember { MutableInteractionSource() },
              indication = null,
            ) {
              view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
              onToggleScientific()
            }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
      ) {
        Icon(
          painter = painterResource(R.drawable.ic_functions),
          contentDescription = stringResource(R.string.cd_scientific_toggle),
          tint = sciTint,
          modifier = Modifier.size(18.dp),
        )
        Text(
          text = "fx",
          color = sciTint,
          fontFamily = SpaceGroteskFontFamily,
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp,
        )
      }

      Box(
        modifier =
          Modifier.testTag("history_button")
            .minimumInteractiveComponentSize()
            .size(44.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(palette.chassisTop.copy(alpha = 0.9f))
            .border(1.dp, palette.chassisBorderLight.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
            .clickable(
              interactionSource = remember { MutableInteractionSource() },
              indication = null,
            ) {
              view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
              onOpenHistory()
            },
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          painter = painterResource(R.drawable.ic_history),
          contentDescription = stringResource(R.string.cd_history_button),
          tint = if (historyCount > 0) palette.displayPrimaryText else palette.mutedText,
          modifier = Modifier.size(20.dp),
        )
      }
    }

    Row(
      modifier =
        Modifier.testTag("theme_selector_bar")
          .clip(RoundedCornerShape(20.dp))
          .background(palette.keySocket.copy(alpha = 0.65f))
          .border(1.dp, palette.chassisBorderLight.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
          .padding(horizontal = 8.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      ThemeOrb(
        style = CalculatorThemeStyle.CERAMIC,
        selected = activeTheme == CalculatorThemeStyle.CERAMIC,
        topColor = Color(0xFFF3F5F8),
        accentDot = Color(0xFFE65100),
        ringColor = palette.accent,
        onClick = {
          view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
          onSelectTheme(CalculatorThemeStyle.CERAMIC)
        },
      )
      ThemeOrb(
        style = CalculatorThemeStyle.OBSIDIAN,
        selected = activeTheme == CalculatorThemeStyle.OBSIDIAN,
        topColor = Color(0xFF2D3340),
        accentDot = Color(0xFFFF6B2B),
        ringColor = palette.accent,
        onClick = {
          view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
          onSelectTheme(CalculatorThemeStyle.OBSIDIAN)
        },
      )
      ThemeOrb(
        style = CalculatorThemeStyle.CYBER_MINT,
        selected = activeTheme == CalculatorThemeStyle.CYBER_MINT,
        topColor = Color(0xFF133642),
        accentDot = Color(0xFF00E5B0),
        ringColor = palette.accent,
        onClick = {
          view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
          onSelectTheme(CalculatorThemeStyle.CYBER_MINT)
        },
      )
      ThemeOrb(
        style = CalculatorThemeStyle.AMBER_BRASS,
        selected = activeTheme == CalculatorThemeStyle.AMBER_BRASS,
        topColor = Color(0xFF3E3024),
        accentDot = Color(0xFFF5B041),
        ringColor = palette.accent,
        onClick = {
          view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
          onSelectTheme(CalculatorThemeStyle.AMBER_BRASS)
        },
      )
    }

    Box(
      modifier =
        Modifier.testTag("settings_button")
          .minimumInteractiveComponentSize()
          .size(44.dp)
          .clip(RoundedCornerShape(14.dp))
          .background(palette.chassisTop.copy(alpha = 0.9f))
          .border(1.dp, palette.chassisBorderLight.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
          .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
          ) {
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            onOpenSettings()
          },
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        painter = painterResource(R.drawable.ic_tune),
        contentDescription = stringResource(R.string.cd_settings_button),
        tint = palette.displayPrimaryText,
        modifier = Modifier.size(20.dp),
      )
    }
  }
}

@Composable
private fun ThemeOrb(
  style: CalculatorThemeStyle,
  selected: Boolean,
  topColor: Color,
  accentDot: Color,
  ringColor: Color,
  onClick: () -> Unit,
) {
  val brush = remember(topColor, accentDot) {
    Brush.linearGradient(listOf(topColor, accentDot.copy(alpha = 0.85f)))
  }
  Box(
    modifier =
      Modifier.testTag("theme_orb_${style.id}")
        .size(30.dp)
        .clip(CircleShape)
        .clickable(
          interactionSource = remember { MutableInteractionSource() },
          indication = null,
          onClick = onClick,
        ),
    contentAlignment = Alignment.Center,
  ) {
    Box(
      modifier =
        Modifier.size(24.dp)
          .graphicsLayer {
            val s = if (selected) 1.12f else 0.92f
            scaleX = s
            scaleY = s
          }
          .clip(CircleShape)
          .background(brush)
          .then(
            if (selected) Modifier.border(2.dp, ringColor, CircleShape)
            else Modifier.border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
          ),
    )
  }
}
