package com.example.ui.components

import android.view.HapticFeedbackConstants
import android.view.SoundEffectConstants
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sensor.TiltState
import com.example.ui.theme.KeyCapColors
import com.example.ui.theme.SpaceGroteskFontFamily
import kotlinx.coroutines.launch

/**
 * Hardware-accelerated 3D tactile keycap.
 * All press & tilt animations execute strictly in the Draw/RenderLayer phase (zero recomposition),
 * guaranteeing buttery 60/120fps responsiveness across rapid multi-key typing.
 */
@Composable
fun TactileKey3D(
  label: String,
  colors: KeyCapColors,
  socketColor: Color,
  tiltState: TiltState,
  depthFactor: Float,
  hapticsEnabled: Boolean,
  soundEnabled: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  testTag: String = "key_$label",
  contentDescriptionText: String = label,
  icon: ImageVector? = null,
  fontSize: TextUnit = 24.sp,
  cornerRadius: Dp = 20.dp,
  isAccentHero: Boolean = false,
) {
  val view = LocalView.current
  val scope = rememberCoroutineScope()

  val pressAnim = remember { Animatable(0f) }
  val fingerTiltX = remember { Animatable(0f) }
  val fingerTiltY = remember { Animatable(0f) }

  val pressSpring = remember {
    spring<Float>(dampingRatio = 0.72f, stiffness = 1800f)
  }
  val releaseSpring = remember {
    spring<Float>(dampingRatio = 0.56f, stiffness = Spring.StiffnessMedium)
  }

  Box(
    modifier =
      modifier
        .testTag(testTag)
        .semantics {
          role = Role.Button
          contentDescription = contentDescriptionText
        }
        .pointerInput(onClick, hapticsEnabled, soundEnabled) {
          awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            down.consume()

            if (hapticsEnabled) {
              view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            }
            if (soundEnabled) {
              view.playSoundEffect(SoundEffectConstants.CLICK)
            }

            // Compute normalized offset inside keycap (-1..1) for subtle physical key rock
            val w = size.width.toFloat().coerceAtLeast(1f)
            val h = size.height.toFloat().coerceAtLeast(1f)
            val normX = ((down.position.x / w) - 0.5f) * 2f
            val normY = ((down.position.y / h) - 0.5f) * 2f

            scope.launch { pressAnim.animateTo(1f, pressSpring) }
            scope.launch { fingerTiltY.animateTo(normX * 4.5f, pressSpring) }
            scope.launch { fingerTiltX.animateTo(-normY * 4.5f, pressSpring) }

            val up = waitForUpOrCancellation()
            if (up != null) {
              up.consume()
              onClick()
            }

            scope.launch { pressAnim.animateTo(0f, releaseSpring) }
            scope.launch { fingerTiltX.animateTo(0f, releaseSpring) }
            scope.launch { fingerTiltY.animateTo(0f, releaseSpring) }
          }
        }
        .drawBehind {
          val p = pressAnim.value.coerceIn(0f, 1f)
          val radiusPx = cornerRadius.toPx()
          val corner = CornerRadius(radiusPx, radiusPx)
          val maxTravel = (6.5.dp.toPx() * depthFactor).coerceAtLeast(2.dp.toPx())
          val travel = maxTravel * p
          val capHeight = (size.height - maxTravel).coerceAtLeast(size.height * 0.75f)
          val capSize = Size(size.width, capHeight)

          // 1. Recessed chassis socket well
          drawRoundRect(
            color = socketColor,
            topLeft = Offset(0f, maxTravel * 0.35f),
            size = Size(size.width, size.height - maxTravel * 0.35f),
            cornerRadius = corner,
          )

          // 2. Soft ambient ground shadow underneath key skirt (tightens on press)
          val shadowAlpha = (1f - p * 0.65f) * (if (isAccentHero) 0.45f else 0.32f)
          val shadowColor = if (isAccentHero) colors.glow else Color.Black
          drawRoundRect(
            color = shadowColor.copy(alpha = shadowAlpha),
            topLeft = Offset(1.dp.toPx(), travel + 3.dp.toPx()),
            size = Size(size.width - 2.dp.toPx(), capHeight + (maxTravel - travel) + 2.dp.toPx()),
            cornerRadius = corner,
          )

          // 3. 3D Extruded skirt / plinth wall
          val skirtHeight = (maxTravel - travel).coerceAtLeast(1.2.dp.toPx())
          val skirtBrush =
            Brush.verticalGradient(
              colors = listOf(colors.skirtTop, colors.skirtBottom),
              startY = travel,
              endY = travel + capHeight + skirtHeight,
            )
          drawRoundRect(
            brush = skirtBrush,
            topLeft = Offset(0f, travel + 1.dp.toPx()),
            size = Size(size.width, capHeight + skirtHeight - 1.dp.toPx()),
            cornerRadius = corner,
          )

          // 4. Sculpted top keycap face with dynamic parallax directional lighting
          val lightShiftX = tiltState.x * size.width * 0.18f
          val lightShiftY = tiltState.y * size.height * 0.18f
          val topFaceBrush =
            Brush.linearGradient(
              colors = listOf(colors.topStart, colors.topEnd),
              start = Offset(lightShiftX, travel + lightShiftY),
              end = Offset(size.width + lightShiftX, travel + capHeight + lightShiftY),
            )
          drawRoundRect(
            brush = topFaceBrush,
            topLeft = Offset(0f, travel),
            size = capSize,
            cornerRadius = corner,
          )

          // 5. Crisp top bevel specular rim highlight
          val rimAlpha = 1f - p * 0.35f
          drawRoundRect(
            brush =
              Brush.verticalGradient(
                colors =
                  listOf(
                    colors.rimHighlight.copy(alpha = colors.rimHighlight.alpha * rimAlpha),
                    Color.Transparent,
                  ),
                startY = travel,
                endY = travel + capHeight * 0.55f,
              ),
            topLeft = Offset(0.75.dp.toPx(), travel + 0.75.dp.toPx()),
            size = Size(size.width - 1.5.dp.toPx(), capHeight - 1.5.dp.toPx()),
            cornerRadius = CornerRadius((radiusPx - 1f).coerceAtLeast(2f)),
            style = Stroke(width = 1.25.dp.toPx()),
          )

          // 6. Subtle tactile depression glow when pressed
          if (p > 0.01f) {
            drawRoundRect(
              color = colors.glow.copy(alpha = p * 0.24f),
              topLeft = Offset(0f, travel),
              size = capSize,
              cornerRadius = corner,
            )
          }
        },
    contentAlignment = Alignment.Center,
  ) {
    // Keycap glyph moves strictly with GPU graphicsLayer (zero recomposition!)
    Box(
      modifier =
        Modifier.fillMaxSize()
          .padding(bottom = 5.dp)
          .graphicsLayer {
            val p = pressAnim.value
            val maxTravelPx = (6.5.dp.toPx() * depthFactor).coerceAtLeast(2.dp.toPx())
            translationY = maxTravelPx * p
            val s = 1f - (p * 0.035f)
            scaleX = s
            scaleY = s
            rotationX = fingerTiltX.value + tiltState.y * 2.5f
            rotationY = fingerTiltY.value - tiltState.x * 2.5f
            cameraDistance = 12f * density
          },
      contentAlignment = Alignment.Center,
    ) {
      if (icon != null) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = colors.text,
        )
      } else {
        Text(
          text = label,
          color = colors.text,
          fontFamily = SpaceGroteskFontFamily,
          fontWeight = if (isAccentHero) FontWeight.Bold else FontWeight.SemiBold,
          fontSize = fontSize,
          maxLines = 1,
          softWrap = false,
          overflow = TextOverflow.Clip,
        )
      }
    }
  }
}
