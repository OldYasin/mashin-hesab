package com.example.ui.components

import android.view.HapticFeedbackConstants
import android.view.SoundEffectConstants
import androidx.annotation.DrawableRes
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.KeyCapColors
import com.example.ui.theme.SpaceGroteskFontFamily
import kotlinx.coroutines.launch

@Composable
fun TactileKey3D(
  label: String,
  colors: KeyCapColors,
  socketColor: Color,
  depthFactor: Float,
  hapticsEnabled: Boolean,
  soundEnabled: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  testTag: String = "key_$label",
  contentDescriptionText: String = label,
  @DrawableRes iconRes: Int? = null,
  fontSize: TextUnit = 24.sp,
  cornerRadius: Dp = 20.dp,
  isAccentHero: Boolean = false,
) {
  val view = LocalView.current
  val scope = rememberCoroutineScope()
  val pressAnim = remember { Animatable(0f) }

  val currentOnClick by rememberUpdatedState(onClick)
  val currentHaptics by rememberUpdatedState(hapticsEnabled)
  val currentSound by rememberUpdatedState(soundEnabled)

  val pressSpec = remember { tween<Float>(durationMillis = 16, easing = LinearOutSlowInEasing) }
  val releaseSpec = remember { spring<Float>(dampingRatio = 0.65f, stiffness = 1450f) }

  Box(
    modifier =
      modifier
        .testTag(testTag)
        .semantics {
          role = Role.Button
          contentDescription = contentDescriptionText
        }
        .pointerInput(Unit) {
          awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            down.consume()

            if (currentHaptics) {
              view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            }
            if (currentSound) {
              view.playSoundEffect(SoundEffectConstants.CLICK)
            }

            scope.launch { pressAnim.animateTo(1f, pressSpec) }

            val up = waitForUpOrCancellation()
            if (up != null) {
              up.consume()
              currentOnClick()
            }

            scope.launch { pressAnim.animateTo(0f, releaseSpec) }
          }
        }
        .drawWithCache {
          val radiusPx = cornerRadius.toPx()
          val corner = CornerRadius(radiusPx, radiusPx)
          val maxTravel = (6.dp.toPx() * depthFactor).coerceAtLeast(2.dp.toPx())
          val capHeight = (size.height - maxTravel).coerceAtLeast(size.height * 0.76f)
          val shadowAlpha = if (isAccentHero) 0.32f else 0.22f
          val shadowColor = (if (isAccentHero) colors.glow else Color.Black).copy(alpha = shadowAlpha)
          val skirtBrush =
            Brush.verticalGradient(
              colors = listOf(colors.skirtTop, colors.skirtBottom),
              startY = maxTravel * 0.4f,
              endY = size.height,
            )

          onDrawBehind {
            drawRoundRect(
              color = socketColor,
              topLeft = Offset(0f, maxTravel * 0.3f),
              size = Size(size.width, size.height - maxTravel * 0.3f),
              cornerRadius = corner,
            )
            drawRoundRect(
              color = shadowColor,
              topLeft = Offset(1.dp.toPx(), 2.5.dp.toPx()),
              size = Size(size.width - 2.dp.toPx(), size.height - 1.dp.toPx()),
              cornerRadius = corner,
            )
            drawRoundRect(
              brush = skirtBrush,
              topLeft = Offset(0f, maxTravel * 0.4f),
              size = Size(size.width, capHeight + maxTravel * 0.6f),
              cornerRadius = corner,
            )
          }
        },
    contentAlignment = Alignment.TopCenter,
  ) {
    Box(
      modifier =
        Modifier.fillMaxSize()
          .padding(bottom = (6f * depthFactor).coerceAtLeast(2f).dp)
          .graphicsLayer {
            val p = pressAnim.value
            val maxTravelPx = (5.5.dp.toPx() * depthFactor).coerceAtLeast(2.dp.toPx())
            translationY = maxTravelPx * p
            val s = 1f - (p * 0.025f)
            scaleX = s
            scaleY = s
          }
          .drawWithCache {
            val radiusPx = cornerRadius.toPx()
            val corner = CornerRadius(radiusPx, radiusPx)
            val topFaceBrush =
              Brush.linearGradient(
                colors = listOf(colors.topStart, colors.topEnd),
                start = Offset.Zero,
                end = Offset(size.width, size.height),
              )
            val rimBrush =
              Brush.verticalGradient(
                colors = listOf(colors.rimHighlight, Color.Transparent),
                startY = 0f,
                endY = size.height * 0.55f,
              )
            val rimStroke = Stroke(width = 1.25.dp.toPx())
            val inset = 0.75.dp.toPx()
            val rimCorner = CornerRadius((radiusPx - 1f).coerceAtLeast(2f))

            onDrawBehind {
              drawRoundRect(brush = topFaceBrush, cornerRadius = corner)
              drawRoundRect(
                brush = rimBrush,
                topLeft = Offset(inset, inset),
                size = Size(size.width - inset * 2f, size.height - inset * 2f),
                cornerRadius = rimCorner,
                style = rimStroke,
              )
            }
          },
      contentAlignment = Alignment.Center,
    ) {
      if (iconRes != null) {
        Icon(
          painter = painterResource(iconRes),
          contentDescription = null,
          tint = colors.text,
          modifier = Modifier.size(22.dp),
        )
      } else {
        Text(
          text = label,
          color = colors.text,
          fontFamily = SpaceGroteskFontFamily,
          fontWeight = if (isAccentHero) FontWeight.Bold else FontWeight.SemiBold,
          fontSize = fontSize,
          maxLines = 1,
          softWrap = false,
          overflow = TextOverflow.Clip,
        )
      }
    }
  }
}
