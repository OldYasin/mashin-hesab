package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color

enum class CalculatorThemeStyle(val id: String) {
  OBSIDIAN("obsidian"),
  CERAMIC("ceramic"),
  CYBER_MINT("cyber"),
  AMBER_BRASS("amber");

  companion object {
    fun fromId(id: String?): CalculatorThemeStyle =
      entries.firstOrNull { it.id == id } ?: OBSIDIAN
  }
}

@Immutable
data class KeyCapColors(
  val topStart: Color,
  val topEnd: Color,
  val skirtTop: Color,
  val skirtBottom: Color,
  val rimHighlight: Color,
  val text: Color,
  val glow: Color,
)

@Immutable
data class CalculatorMaterialPalette(
  val style: CalculatorThemeStyle,
  val isDark: Boolean,
  val backdropTop: Color,
  val backdropBottom: Color,
  val chassisTop: Color,
  val chassisBottom: Color,
  val chassisBorderLight: Color,
  val chassisBorderDark: Color,
  val keySocket: Color,
  val displayTop: Color,
  val displayBottom: Color,
  val displayBorderLight: Color,
  val displayBorderDark: Color,
  val displayPrimaryText: Color,
  val displaySecondaryText: Color,
  val displayErrorText: Color,
  val accent: Color,
  val onAccent: Color,
  val surfaceSheet: Color,
  val onSurfaceSheet: Color,
  val mutedText: Color,
  val digitKey: KeyCapColors,
  val functionKey: KeyCapColors,
  val scientificKey: KeyCapColors,
  val operatorKey: KeyCapColors,
  val equalsKey: KeyCapColors,
  val clearKey: KeyCapColors,
)

val ObsidianPalette =
  CalculatorMaterialPalette(
    style = CalculatorThemeStyle.OBSIDIAN,
    isDark = true,
    backdropTop = Color(0xFF0A0C10),
    backdropBottom = Color(0xFF141820),
    chassisTop = Color(0xFF1B1F28),
    chassisBottom = Color(0xFF11141B),
    chassisBorderLight = Color(0xFF333B4B),
    chassisBorderDark = Color(0xFF07080B),
    keySocket = Color(0xFF0B0D12),
    displayTop = Color(0xFF0D1117),
    displayBottom = Color(0xFF151C25),
    displayBorderLight = Color(0xFF2B3444),
    displayBorderDark = Color(0xFF06080C),
    displayPrimaryText = Color(0xFFF4F7FB),
    displaySecondaryText = Color(0xFF8C9AB0),
    displayErrorText = Color(0xFFFF6B6B),
    accent = Color(0xFFFF6B2B),
    onAccent = Color(0xFFFFFFFF),
    surfaceSheet = Color(0xFF181C24),
    onSurfaceSheet = Color(0xFFF1F5F9),
    mutedText = Color(0xFF8D99AE),
    digitKey =
      KeyCapColors(
        topStart = Color(0xFF2E3441),
        topEnd = Color(0xFF222732),
        skirtTop = Color(0xFF181C24),
        skirtBottom = Color(0xFF0F1218),
        rimHighlight = Color(0x55FFFFFF),
        text = Color(0xFFF5F7FA),
        glow = Color(0x3370A1FF),
      ),
    functionKey =
      KeyCapColors(
        topStart = Color(0xFF3A4252),
        topEnd = Color(0xFF2B313E),
        skirtTop = Color(0xFF1E232D),
        skirtBottom = Color(0xFF13161D),
        rimHighlight = Color(0x4DFFFFFF),
        text = Color(0xFFD6E0F0),
        glow = Color(0x3393C5FD),
      ),
    scientificKey =
      KeyCapColors(
        topStart = Color(0xFF252B37),
        topEnd = Color(0xFF1C2029),
        skirtTop = Color(0xFF14171E),
        skirtBottom = Color(0xFF0B0D11),
        rimHighlight = Color(0x38FFFFFF),
        text = Color(0xFFAAB8CC),
        glow = Color(0x3360A5FA),
      ),
    operatorKey =
      KeyCapColors(
        topStart = Color(0xFF34435A),
        topEnd = Color(0xFF243042),
        skirtTop = Color(0xFF192230),
        skirtBottom = Color(0xFF101620),
        rimHighlight = Color(0x55A5C4FF),
        text = Color(0xFF7CC4FF),
        glow = Color(0x4438BDF8),
      ),
    equalsKey =
      KeyCapColors(
        topStart = Color(0xFFFF834D),
        topEnd = Color(0xFFE55317),
        skirtTop = Color(0xFFB53B0B),
        skirtBottom = Color(0xFF7A2404),
        rimHighlight = Color(0x88FFE0D0),
        text = Color(0xFFFFFFFF),
        glow = Color(0x88FF6B2B),
      ),
    clearKey =
      KeyCapColors(
        topStart = Color(0xFF4D2B32),
        topEnd = Color(0xFF3B2026),
        skirtTop = Color(0xFF29151A),
        skirtBottom = Color(0xFF1A0C10),
        rimHighlight = Color(0x44FFB4B4),
        text = Color(0xFFFF8A8A),
        glow = Color(0x44FF5C5C),
      ),
  )

val CeramicPalette =
  CalculatorMaterialPalette(
    style = CalculatorThemeStyle.CERAMIC,
    isDark = false,
    backdropTop = Color(0xFFDCE1E8),
    backdropBottom = Color(0xFFC8CFD8),
    chassisTop = Color(0xFFF3F5F8),
    chassisBottom = Color(0xFFE1E5EC),
    chassisBorderLight = Color(0xFFFFFFFF),
    chassisBorderDark = Color(0xFFB7C0CD),
    keySocket = Color(0xFFC5CCD6),
    displayTop = Color(0xFFD6E0D6),
    displayBottom = Color(0xFFC6D3C7),
    displayBorderLight = Color(0xFF9EAAB8),
    displayBorderDark = Color(0xFFFFFFFF),
    displayPrimaryText = Color(0xFF1B241E),
    displaySecondaryText = Color(0xFF4F5E53),
    displayErrorText = Color(0xFFC62828),
    accent = Color(0xFFE65100),
    onAccent = Color(0xFFFFFFFF),
    surfaceSheet = Color(0xFFF5F7FA),
    onSurfaceSheet = Color(0xFF1D232A),
    mutedText = Color(0xFF64707D),
    digitKey =
      KeyCapColors(
        topStart = Color(0xFFFFFFFF),
        topEnd = Color(0xFFEDF0F5),
        skirtTop = Color(0xFFD2D8E1),
        skirtBottom = Color(0xFFB4BDC9),
        rimHighlight = Color(0xFFFFFFFF),
        text = Color(0xFF1F2630),
        glow = Color(0x3364748B),
      ),
    functionKey =
      KeyCapColors(
        topStart = Color(0xFFE4E8EF),
        topEnd = Color(0xFFD4DAE4),
        skirtTop = Color(0xFFB8C0CE),
        skirtBottom = Color(0xFF9AA4B4),
        rimHighlight = Color(0xEEFFFFFF),
        text = Color(0xFF2E3846),
        glow = Color(0x3364748B),
      ),
    scientificKey =
      KeyCapColors(
        topStart = Color(0xFFEAEEF4),
        topEnd = Color(0xFFDCE2EB),
        skirtTop = Color(0xFFC1C9D6),
        skirtBottom = Color(0xFFA3AEBE),
        rimHighlight = Color(0xEEFFFFFF),
        text = Color(0xFF3D4959),
        glow = Color(0x2864748B),
      ),
    operatorKey =
      KeyCapColors(
        topStart = Color(0xFF39424E),
        topEnd = Color(0xFF282F38),
        skirtTop = Color(0xFF1C2128),
        skirtBottom = Color(0xFF111419),
        rimHighlight = Color(0x55FFFFFF),
        text = Color(0xFFF8FAFC),
        glow = Color(0x333B82F6),
      ),
    equalsKey =
      KeyCapColors(
        topStart = Color(0xFFFF7235),
        topEnd = Color(0xFFDF4D11),
        skirtTop = Color(0xFFB33807),
        skirtBottom = Color(0xFF812402),
        rimHighlight = Color(0x99FFE6D9),
        text = Color(0xFFFFFFFF),
        glow = Color(0x77FF6B2B),
      ),
    clearKey =
      KeyCapColors(
        topStart = Color(0xFFFDE8E8),
        topEnd = Color(0xFFF8D2D2),
        skirtTop = Color(0xFFE2AEAE),
        skirtBottom = Color(0xFFC78D8D),
        rimHighlight = Color(0xEEFFFFFF),
        text = Color(0xFFB91C1C),
        glow = Color(0x44EF4444),
      ),
  )

val CyberMintPalette =
  CalculatorMaterialPalette(
    style = CalculatorThemeStyle.CYBER_MINT,
    isDark = true,
    backdropTop = Color(0xFF061014),
    backdropBottom = Color(0xFF0A1B22),
    chassisTop = Color(0xFF0F232B),
    chassisBottom = Color(0xFF09171D),
    chassisBorderLight = Color(0xFF214957),
    chassisBorderDark = Color(0xFF040A0D),
    keySocket = Color(0xFF061014),
    displayTop = Color(0xFF07161B),
    displayBottom = Color(0xFF0D232B),
    displayBorderLight = Color(0xFF1E4F5E),
    displayBorderDark = Color(0xFF03090B),
    displayPrimaryText = Color(0xFFE6FFF9),
    displaySecondaryText = Color(0xFF69B5A8),
    displayErrorText = Color(0xFFFF6E7F),
    accent = Color(0xFF00E5B0),
    onAccent = Color(0xFF031F18),
    surfaceSheet = Color(0xFF0D2027),
    onSurfaceSheet = Color(0xFFE4FFF9),
    mutedText = Color(0xFF6EA39C),
    digitKey =
      KeyCapColors(
        topStart = Color(0xFF17343F),
        topEnd = Color(0xFF10252E),
        skirtTop = Color(0xFF0B1A20),
        skirtBottom = Color(0xFF060F13),
        rimHighlight = Color(0x445EEAD4),
        text = Color(0xFFEAFEF9),
        glow = Color(0x4414B8A6),
      ),
    functionKey =
      KeyCapColors(
        topStart = Color(0xFF1D4450),
        topEnd = Color(0xFF14313A),
        skirtTop = Color(0xFF0D2229),
        skirtBottom = Color(0xFF071419),
        rimHighlight = Color(0x557CFCE6),
        text = Color(0xFF99F6E4),
        glow = Color(0x442DD4BF),
      ),
    scientificKey =
      KeyCapColors(
        topStart = Color(0xFF132B34),
        topEnd = Color(0xFF0D1F26),
        skirtTop = Color(0xFF09161B),
        skirtBottom = Color(0xFF050D10),
        rimHighlight = Color(0x385EEAD4),
        text = Color(0xFF81C7C0),
        glow = Color(0x332DD4BF),
      ),
    operatorKey =
      KeyCapColors(
        topStart = Color(0xFF1A4B5C),
        topEnd = Color(0xFF113542),
        skirtTop = Color(0xFF0B242D),
        skirtBottom = Color(0xFF06151B),
        rimHighlight = Color(0x6667E8F9),
        text = Color(0xFF38BDF8),
        glow = Color(0x5506B6D4),
      ),
    equalsKey =
      KeyCapColors(
        topStart = Color(0xFF2FFFD0),
        topEnd = Color(0xFF00C896),
        skirtTop = Color(0xFF00916D),
        skirtBottom = Color(0xFF005C45),
        rimHighlight = Color(0xAAFFFFFF),
        text = Color(0xFF03221A),
        glow = Color(0x8800E5B0),
      ),
    clearKey =
      KeyCapColors(
        topStart = Color(0xFF472030),
        topEnd = Color(0xFF341623),
        skirtTop = Color(0xFF230E17),
        skirtBottom = Color(0xFF14070D),
        rimHighlight = Color(0x55FDA4AF),
        text = Color(0xFFFF859D),
        glow = Color(0x44F43F5E),
      ),
  )

val AmberBrassPalette =
  CalculatorMaterialPalette(
    style = CalculatorThemeStyle.AMBER_BRASS,
    isDark = true,
    backdropTop = Color(0xFF120E0B),
    backdropBottom = Color(0xFF1D1712),
    chassisTop = Color(0xFF261E18),
    chassisBottom = Color(0xFF19130F),
    chassisBorderLight = Color(0xFF4A3B2E),
    chassisBorderDark = Color(0xFF0A0705),
    keySocket = Color(0xFF0F0B08),
    displayTop = Color(0xFF17120E),
    displayBottom = Color(0xFF221A14),
    displayBorderLight = Color(0xFF4B3B2D),
    displayBorderDark = Color(0xFF090705),
    displayPrimaryText = Color(0xFFFFF4E0),
    displaySecondaryText = Color(0xFFC2A886),
    displayErrorText = Color(0xFFFF7A6B),
    accent = Color(0xFFF5B041),
    onAccent = Color(0xFF241604),
    surfaceSheet = Color(0xFF221B15),
    onSurfaceSheet = Color(0xFFFFF4E0),
    mutedText = Color(0xFFB59E82),
    digitKey =
      KeyCapColors(
        topStart = Color(0xFF3A2F26),
        topEnd = Color(0xFF2B221B),
        skirtTop = Color(0xFF1E1813),
        skirtBottom = Color(0xFF120E0B),
        rimHighlight = Color(0x4DFFE4B8),
        text = Color(0xFFFFF6E8),
        glow = Color(0x33F59E0B),
      ),
    functionKey =
      KeyCapColors(
        topStart = Color(0xFF4B3C2F),
        topEnd = Color(0xFF382C22),
        skirtTop = Color(0xFF271E17),
        skirtBottom = Color(0xFF18120E),
        rimHighlight = Color(0x55FFE6B5),
        text = Color(0xFFFDE6BE),
        glow = Color(0x38FBBF24),
      ),
    scientificKey =
      KeyCapColors(
        topStart = Color(0xFF30261E),
        topEnd = Color(0xFF241C16),
        skirtTop = Color(0xFF19130F),
        skirtBottom = Color(0xFF0E0A08),
        rimHighlight = Color(0x38FFE4B8),
        text = Color(0xFFD6BC9C),
        glow = Color(0x33D97706),
      ),
    operatorKey =
      KeyCapColors(
        topStart = Color(0xFF5C4529),
        topEnd = Color(0xFF45331D),
        skirtTop = Color(0xFF302313),
        skirtBottom = Color(0xFF1D150B),
        rimHighlight = Color(0x66FDE68A),
        text = Color(0xFFFCD34D),
        glow = Color(0x55F59E0B),
      ),
    equalsKey =
      KeyCapColors(
        topStart = Color(0xFFFFCB66),
        topEnd = Color(0xFFE0961F),
        skirtTop = Color(0xFFA86B0D),
        skirtBottom = Color(0xFF6B4204),
        rimHighlight = Color(0xAAFFFBEB),
        text = Color(0xFF241604),
        glow = Color(0x88F5B041),
      ),
    clearKey =
      KeyCapColors(
        topStart = Color(0xFF562B28),
        topEnd = Color(0xFF401E1C),
        skirtTop = Color(0xFF2C1412),
        skirtBottom = Color(0xFF1A0B0A),
        rimHighlight = Color(0x4DFFB8B0),
        text = Color(0xFFFF968A),
        glow = Color(0x44EF4444),
      ),
  )

fun paletteFor(style: CalculatorThemeStyle): CalculatorMaterialPalette =
  when (style) {
    CalculatorThemeStyle.OBSIDIAN -> ObsidianPalette
    CalculatorThemeStyle.CERAMIC -> CeramicPalette
    CalculatorThemeStyle.CYBER_MINT -> CyberMintPalette
    CalculatorThemeStyle.AMBER_BRASS -> AmberBrassPalette
  }
