package com.example.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlin.math.abs

/**
 * Holds normalized 3D tilt coordinates in [-1f, 1f].
 * Reading [x] and [y] strictly inside graphicsLayer {} or DrawScope avoids Compose recompositions,
 * keeping 60/120fps animations completely lag-free.
 */
@Stable
class TiltState {
  var sensorX by mutableFloatStateOf(0f)
  var sensorY by mutableFloatStateOf(0f)
  var dragX by mutableFloatStateOf(0f)
  var dragY by mutableFloatStateOf(0f)

  val x: Float
    get() = (sensorX + dragX).coerceIn(-1f, 1f)

  val y: Float
    get() = (sensorY + dragY).coerceIn(-1f, 1f)
}

@Composable
fun rememberTiltState(enabled: Boolean): TiltState {
  val context = LocalContext.current
  val tiltState = remember { TiltState() }

  DisposableEffect(context, enabled) {
    if (!enabled) {
      tiltState.sensorX = 0f
      tiltState.sensorY = 0f
      return@DisposableEffect onDispose {}
    }

    val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    val sensor =
      sensorManager?.getDefaultSensor(Sensor.TYPE_GRAVITY)
        ?: sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    if (sensorManager == null || sensor == null) {
      tiltState.sensorX = 0f
      tiltState.sensorY = 0f
      return@DisposableEffect onDispose {}
    }

    var baselineY: Float? = null
    val alpha = 0.14f

    val listener =
      object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
          val rawX = (event.values[0] / 5.5f).coerceIn(-1f, 1f)
          // Calibrate vertical resting tilt smoothly around initial holding angle
          val rawGravityY = event.values[1]
          if (baselineY == null) {
            baselineY = rawGravityY
          }
          val normalizedY = ((rawGravityY - (baselineY ?: rawGravityY)) / 4.5f).coerceIn(-1f, 1f)
          // Slowly adapt baseline so holding phone upright or flat feels natural
          baselineY = baselineY!! * 0.992f + rawGravityY * 0.008f

          val nextX = tiltState.sensorX + alpha * (-rawX - tiltState.sensorX)
          val nextY = tiltState.sensorY + alpha * (normalizedY - tiltState.sensorY)

          tiltState.sensorX = if (abs(nextX) < 0.002f) 0f else nextX
          tiltState.sensorY = if (abs(nextY) < 0.002f) 0f else nextY
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
      }

    sensorManager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)

    onDispose {
      sensorManager.unregisterListener(listener)
    }
  }

  return tiltState
}
