package com.example.core.logging

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Lightweight aggregator so the exported log starts with a readable DIAGNOSIS block
 * (timings, failure counters, per-ProxyIP health, automatic verdict) instead of
 * thousands of noisy lines.
 */
object TunnelStats {

    @Volatile private var startMs = System.currentTimeMillis()
    private val counters = ConcurrentHashMap<String, AtomicInteger>()
    private val samples = ConcurrentHashMap<String, MutableList<Long>>()
    private const val MAX_SAMPLES = 3000

    fun reset() {
        startMs = System.currentTimeMillis()
        counters.clear()
        samples.clear()
    }

    fun inc(key: String): Int = counters.getOrPut(key) { AtomicInteger(0) }.incrementAndGet()

    fun get(key: String): Int = counters[key]?.get() ?: 0

    fun sample(name: String, ms: Long) {
        if (ms < 0) return
        val list = samples.getOrPut(name) { java.util.Collections.synchronizedList(ArrayList()) }
        synchronized(list) {
            if (list.size >= MAX_SAMPLES) list.removeAt(0)
            list.add(ms)
        }
    }

    private fun pct(sorted: List<Long>, p: Double): Long =
        if (sorted.isEmpty()) 0L else sorted[((sorted.size - 1) * p).toInt()]

    private fun timing(name: String, label: String): String {
        val list = samples[name] ?: return "$label: n=0"
        val s = synchronized(list) { list.sorted() }
        if (s.isEmpty()) return "$label: n=0"
        return "$label: n=${s.size} p50=${pct(s, 0.5)}ms p90=${pct(s, 0.9)}ms max=${s.last()}ms"
    }

    private fun top(prefix: String, limit: Int = 6): List<Pair<String, Int>> =
        counters.entries.filter { it.key.startsWith(prefix) }
            .map { it.key.removePrefix(prefix) to it.value.get() }
            .sortedByDescending { it.second }
            .take(limit)

    private fun med(name: String): Long {
        val list = samples[name] ?: return 0L
        val s = synchronized(list) { list.sorted() }
        return pct(s, 0.5)
    }

    fun report(): String {
        val sb = StringBuilder()
        val secs = (System.currentTimeMillis() - startMs) / 1000
        val total = get("conn.total")
        val ok = get("conn.ok")
        val fallback = get("conn.fallback")
        val zero = get("conn.zeroRx")
        val warm = get("pool.warm")
        val cold = get("pool.cold")
        val viaProxy = get("route.proxy")
        val direct = get("route.direct")

        sb.appendLine("##### DIAGNOSIS (since session start, ${secs}s) #####")
        sb.appendLine("Connections: total=$total ok=$ok fallback-to-direct=$fallback zero-reply=$zero ws-failures=${get("ws.fail")}")
        sb.appendLine("Pool: warm-hit=$warm cold=$cold discarded=${get("pool.discard")} ws-opened=${get("ws.opened")}")
        sb.appendLine("Route (worker->dest): direct=$direct via-ProxyIP=$viaProxy")
        sb.appendLine(timing("t.open", "WS open (cold only)  "))
        sb.appendLine(timing("t.connect", "Worker->dest connect "))
        sb.appendLine(timing("t.ttfb", "First reply after send"))
        sb.appendLine(timing("t.total", "Connection lifetime   "))
        sb.appendLine("UDP/QUIC answered with ICMP-unreachable: ${get("udp.icmp")} | filtered-DNS drops: ${get("drop.filtered")} | DoH answers: ${get("dns.ok")} (poisoned blocked: ${get("dns.poison")})")

        val proxies = top("proxy.ok:", 8)
        val deadProxies = top("proxy.dead:", 8)
        if (proxies.isNotEmpty() || deadProxies.isNotEmpty()) {
            sb.appendLine("ProxyIP health:")
            proxies.forEach { sb.appendLine("  OK   x${it.second}  ${it.first}") }
            deadProxies.forEach { sb.appendLine("  DEAD x${it.second}  ${it.first}  (connected but no reply)") }
        }
        val directFails = top("direct.fail:", 5)
        if (directFails.isNotEmpty()) {
            sb.appendLine("Direct connect failures (worker could not reach dest, ProxyIP used):")
            directFails.forEach { sb.appendLine("  x${it.second}  ${it.first}") }
        }
        val wsErrs = top("ws.err:", 5)
        if (wsErrs.isNotEmpty()) {
            sb.appendLine("WebSocket errors:")
            wsErrs.forEach { sb.appendLine("  x${it.second}  ${it.first}") }
        }
        val wErrs = top("worker.err:", 5)
        if (wErrs.isNotEmpty()) {
            sb.appendLine("Worker errors:")
            wErrs.forEach { sb.appendLine("  x${it.second}  ${it.first}") }
        }
        val zeroDst = top("zero.", 6)
        if (zeroDst.isNotEmpty()) {
            sb.appendLine("Destinations that sent NO reply (TX>0, RX=0):")
            zeroDst.forEach { sb.appendLine("  x${it.second}  ${it.first}") }
        }
        val sites = top("site:", 10)
        if (sites.isNotEmpty()) {
            sb.appendLine("Top sites (SNI): ok=got reply, noreply=sent but nothing came back")
            sites.forEach { sb.appendLine("  x${it.second}  ${it.first}  ok=${get("siteRx:" + it.first)} noreply=${get("siteNoRx:" + it.first)}") }
        }
        sb.appendLine("Geo-forced (Google/Gemini/AI via foreign ProxyIP): ${get("geo.forced")}")
        val alerts = top("tls.alert:", 6)
        if (alerts.isNotEmpty()) {
            sb.appendLine("Dest answered with only a TLS alert (RX<=12B) = wrong/blocked path:")
            alerts.forEach { sb.appendLine("  x${it.second}  ${it.first}") }
        }
        val ends = top("end.", 6)
        if (ends.isNotEmpty()) {
            sb.appendLine("Connection end reasons: " + ends.joinToString(", ") { "${it.first}=${it.second}" })
        }

        sb.appendLine("--- VERDICT ---")
        val hints = mutableListOf<String>()
        if (total == 0) hints += "هنوز اتصالی ثبت نشده؛ بعد از چند دقیقه استفاده، لاگ رو دوباره Export کن."
        if (total > 0 && fallback * 100 / total >= 5) hints += "فال‌بک مستقیم زیاده (${fallback}/$total): ورکر یا WebSocket وصل نمی‌شه؛ IP واقعی لو می‌ره. ورژن ورکر و کلین‌آی‌پی رو چک کن."
        if (get("ws.fail") > 0) hints += "WebSocket خطا داره (${get("ws.fail")}): کلین‌آی‌پی کلودفلر یا اینترنت ناپایداره؛ یه کلین‌آی‌پی دیگه امتحان کن."
        if (cold > 0 && med("t.open") > 700) hints += "باز شدن WebSocket کنده (p50=${med("t.open")}ms): کلین‌آی‌پی کلودفلر ضعیفه، اسکن مجدد بزن."
        if (warm + cold > 5 && warm * 100 / (warm + cold) < 50) hints += "استخر WebSocket آماده کم می‌آره (warm=${warm}/${warm + cold}): تعداد اتصال‌ها بیشتر از سرعت پر شدن استخره."
        if (med("t.connect") > 800) hints += "ورکر دیر به مقصد وصل می‌شه (p50=${med("t.connect")}ms): معمولاً ProxyIP کنده؛ کشور دیگه یا ProxyIP دلخواه بذار."
        if (med("t.ttfb") > 1500) hints += "اولین جواب مقصد دیر میاد (p50=${med("t.ttfb")}ms): مسیر ورکر←مقصد کنده."
        if (total > 10 && zero * 100 / total >= 12) hints += "اتصال بی‌جواب زیاده (${zero}/$total): ProxyIP مرده یا مقصد از ورکر بلاکه؛ بخش ProxyIP health رو ببین."
        if (deadProxies.isNotEmpty()) hints += "ProxyIPهای مرده: " + deadProxies.joinToString { it.first } + " — اینا رو توی فیلد دلخواه ننویس."
        if (viaProxy + direct > 0 && viaProxy * 100 / (viaProxy + direct) > 40) hints += "بیشتر ترافیک از ProxyIP رد می‌شه (${viaProxy}/${viaProxy + direct}): طبیعیه اگه سایت‌ها پشت کلودفلرن، ولی ProxyIP سریع‌تر تأثیر مستقیم داره."
        if (alerts.isNotEmpty()) hints += "جواب فقط ۷ بایت (TLS alert) یعنی اون مسیر اصلاً به مقصد نمی‌رسه (ProxyIP فقط به سایت‌های پشت کلودفلر وصل میشه، نه گوگل)."
        if (false && get("geo.forced") == 0 && total > 0) hints += "هیچ اتصال گوگل/جمنای شناسایی نشد (SNI دیده نشد). اگه جمنای رو باز کردی و اینجا خالیه، مرورگر از DoH/QUIC/ECH استفاده می‌کنه؛ QUIC و Secure-DNS مرورگر رو خاموش کن."
        if (false && get("geo.forced") > 0) hints += "ترافیک گوگل/AI از ProxyIP خارجی رفت (${get("geo.forced")} اتصال)؛ اگه هنوز جمنای بلاکه ProxyIP کشور دیگه‌ای (مثلاً DE/NL) توی تنظیمات انتخاب کن."
        if (hints.isEmpty() && total > 0) hints += "مشکل واضحی دیده نشد؛ اگه هنوز کنده، زمان‌ها رو با p50/p90 بالا مقایسه کن."
        hints.forEach { sb.appendLine("* $it") }
        sb.appendLine("#####################################################")
        return sb.toString()
    }
}
