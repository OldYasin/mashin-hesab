package com.example

import com.example.core.logging.LogCategory
import com.example.core.logging.LogLevel
import com.example.core.logging.TunnelLogger
import com.example.network.MtProtoHttpBridge
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MtProtoHttpBridgeTest {

    @Test
    fun fullPacketEncodeDecodeRoundtrip() {
        val payload1 = byteArrayOf(0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08)
        val payload2 = byteArrayOf(0x11, 0x22, 0x33, 0x44)
        val enc1 = MtProtoHttpBridge.encodeFullPacket(payload1, seqNo = 0)
        val enc2 = MtProtoHttpBridge.encodeFullPacket(payload2, seqNo = 1)

        val decoded = MtProtoHttpBridge.decodeFullPackets(enc1 + enc2)
        assertNotNull(decoded)
        assertEquals(2, decoded!!.size)
        assertArrayEquals(payload1, decoded[0])
        assertArrayEquals(payload2, decoded[1])
    }

    @Test
    fun fullPacketRejectsCorruptedCrc() {
        val payload = byteArrayOf(1, 2, 3, 4)
        val enc = MtProtoHttpBridge.encodeFullPacket(payload, seqNo = 0)
        enc[enc.size - 1] = (enc.last().toInt() xor 0xFF).toByte()
        assertNull(MtProtoHttpBridge.decodeFullPackets(enc))
    }

    @Test
    fun paddedIntermediateStripsTrailingPadding() {
        // Encrypted packet: 8-byte authKeyId (!=0) + 16-byte msgKey + 16-byte block + 5-byte padding = 45 bytes
        val pkt = ByteArray(45) { it.toByte() }
        pkt[0] = 0x42
        val stripped = MtProtoHttpBridge.stripPaddedIntermediatePadding(pkt)
        assertEquals(40, stripped.size)
        assertArrayEquals(pkt.copyOfRange(0, 40), stripped)
    }

    @Test
    fun tunnelLoggerDeduplicatesBurstSpam() {
        TunnelLogger.dedupEnabled = true
        TunnelLogger.clear()
        repeat(100) {
            TunnelLogger.w(LogCategory.VPN, "SOCKS5", "تست اسپم تکراری")
        }
        val entries = TunnelLogger.snapshot()
        assertEquals(1, entries.size)
        assertTrue(entries.first().level == LogLevel.WARN)
    }
}
