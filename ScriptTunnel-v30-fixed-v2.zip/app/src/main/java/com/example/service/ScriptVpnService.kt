package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.net.VpnService
import android.os.Build
import android.os.PowerManager
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.core.AppContainer
import com.example.core.logging.LogCategory
import com.example.core.logging.TunnelLogger
import com.example.data.local.ConnectionReportEntity
import com.example.data.model.TunnelConnectionState
import com.example.network.BypassOkHttpFactory
import com.example.network.LocalSocks5Server
import com.example.network.TunTcpProxy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import com.example.core.logging.TunnelStats

class ScriptVpnService : VpnService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tunInterface: ParcelFileDescriptor? = null
    private var packetLoopJob: Job? = null
    private var notificationJob: Job? = null
    private var healthJob: Job? = null
    private var settingsJob: Job? = null
    private val running = AtomicBoolean(false)
    private var socksServer: LocalSocks5Server? = null
    private var tunTcpProxy: TunTcpProxy? = null
    @Volatile private var latestSettings = com.example.data.model.BypassSettings()

    private var sessionStartMs: Long = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_DISCONNECT) {
            stopTunnel()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_MARK) {
            recordUserMark()
            return START_STICKY
        }

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("در حال برقراری تونل امن..."))
        startTunnel()
        return START_STICKY
    }

    private fun startTunnel() {
        val container = AppContainer.get(applicationContext)
        val engine = container.tunnelEngine
        sessionStartMs = System.currentTimeMillis()
        running.set(true)
        engine.setConnectionState(TunnelConnectionState.CONNECTING)

        serviceScope.launch {
            val settings = container.settingsRepository.settingsFlow.first()
            latestSettings = settings
            settingsJob?.cancel()
            settingsJob = serviceScope.launch {
                container.settingsRepository.settingsFlow.collect { updated ->
                    latestSettings = updated
                    engine.updatePoolAndSettings(container.tunnelRepository.getAllServersOnce(), updated)
                }
            }
            val servers = container.tunnelRepository.getAllServersOnce()
            engine.updatePoolAndSettings(servers, settings)
            TunnelLogger.sessionContext = buildSessionContext(settings, servers)

            BypassOkHttpFactory.socketProtector = { socket -> this@ScriptVpnService.protect(socket) }
            BypassOkHttpFactory.datagramProtector = { ds -> this@ScriptVpnService.protect(ds) }

            // Start real RFC 1928 Local SOCKS5 Server
            TunnelLogger.i(LogCategory.VPN, "SOCKS5", "راه‌اندازی پروکسی محلی 127.0.0.1:${settings.localSocksPort}")
            socksServer = LocalSocks5Server(engine).also { it.start(settings) }

            val dnsttActive = servers.firstOrNull {
                it.isParallelActive && it.endpointType == com.example.data.model.EndpointType.DNSTT
            }
            if (settings.protocol == com.example.data.model.TunnelProtocol.DNSTT_TUNNEL ||
                (dnsttActive != null && settings.protocol != com.example.data.model.TunnelProtocol.PLAIN_DNS_ONLY)
            ) {
                if (dnsttActive != null) {
                    com.example.network.DnsttProcessManager.start(applicationContext, dnsttActive)
                }
            }

            val effectiveDoh = settings.dohEnabled || settings.protocol == com.example.data.model.TunnelProtocol.PLAIN_DNS_ONLY
            if (settings.vpnModeEnabled) {
                val established = establishTun(effectiveDoh)
                if (established == null) {
                    TunnelLogger.e(LogCategory.VPN, "TUN-ERR", "ایجاد رابط VPN ناموفق بود")
                    engine.setConnectionState(TunnelConnectionState.ERROR, "امکان ایجاد رابط VPN وجود نداشت")
                    stopSelf()
                    return@launch
                }
                TunnelLogger.i(LogCategory.VPN, "TUN-OK", "رابط VPN برقرار شد (MTU=1500, DoH=${settings.dohEnabled})")
                tunInterface = established
                startTunPacketLoop(established)
            }

            engine.startTelemetrySession(TunnelConnectionState.CONNECTED)
            startNotificationUpdater()
            startHealthMonitor()
            startNetworkMonitor()
        }
    }

    private fun establishTun(dohEnabled: Boolean): ParcelFileDescriptor? {
        return runCatching {
            val builder = Builder()
                .setSession(getString(R.string.app_name))
                .setMtu(1500)
                .addAddress("10.88.0.2", 24)
                .addRoute("0.0.0.0", 0)
                .addDnsServer(if (dohEnabled) "10.88.0.1" else "8.8.8.8")
                .addDisallowedApplication(packageName)

            // Background system chatter (analytics, ads, cloud sync) has no reason to use the tunnel.
            // Not installed -> ignored. Delete a line to put that app back inside the tunnel.
            NOISY_SYSTEM_PACKAGES.forEach { pkg ->
                runCatching { builder.addDisallowedApplication(pkg) }
            }

            builder.establish()
        }.getOrNull()
    }

    // ---- Underlying network monitor: logs wifi/cellular switches, loss and signal bucket changes ----
    private var netCallback: android.net.ConnectivityManager.NetworkCallback? = null
    @Volatile private var lastNetDesc = "?"

    private fun describeNet(caps: android.net.NetworkCapabilities?): String {
        if (caps == null) return "?"
        val transport = when {
            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) -> "CELLULAR"
            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETHERNET"
            else -> "OTHER"
        }
        val validated = if (caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)) "validated" else "NOT-validated"
        var signal = ""
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val dbm = caps.signalStrength
            if (dbm != Int.MIN_VALUE) {
                val wifi = transport == "WIFI"
                val bucket = when {
                    dbm >= (if (wifi) -60 else -95) -> "good"
                    dbm >= (if (wifi) -75 else -110) -> "mid"
                    else -> "WEAK"
                }
                signal = " signal=$bucket"
            }
        }
        return "$transport $validated$signal"
    }

    private fun startNetworkMonitor() {
        val cm = getSystemService(android.net.ConnectivityManager::class.java) ?: return
        stopNetworkMonitor()
        val req = android.net.NetworkRequest.Builder()
            .addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        val cb = object : android.net.ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: android.net.Network) {
                TunnelStats.inc("net.change")
                TunnelLogger.w(LogCategory.SYSTEM, "NET", "شبکه زیرین وصل شد: ${describeNet(cm.getNetworkCapabilities(network))}")
            }
            override fun onLost(network: android.net.Network) {
                TunnelStats.inc("net.change")
                TunnelLogger.w(LogCategory.SYSTEM, "NET", "شبکه زیرین قطع شد")
            }
            override fun onCapabilitiesChanged(network: android.net.Network, caps: android.net.NetworkCapabilities) {
                val d = describeNet(caps)
                if (d != lastNetDesc) {
                    val prev = lastNetDesc
                    lastNetDesc = d
                    if (prev != "?") {
                        TunnelStats.inc("net.change")
                        TunnelLogger.i(LogCategory.SYSTEM, "NET", "تغییر وضعیت شبکه: $prev -> $d")
                    }
                }
            }
        }
        runCatching { cm.registerNetworkCallback(req, cb); netCallback = cb }
    }

    private fun stopNetworkMonitor() {
        val cb = netCallback ?: return
        netCallback = null
        runCatching { getSystemService(android.net.ConnectivityManager::class.java)?.unregisterNetworkCallback(cb) }
    }

    /** Notification button: drops a marker line into the log so the exact moment of a glitch can be found. */
    private fun recordUserMark() {
        val t = AppContainer.get(applicationContext).tunnelEngine.telemetry.value
        val n = TunnelStats.inc("user.mark")
        val b = recordBattery()
        TunnelLogger.w(
            LogCategory.SYSTEM, "USER-MARK",
            "علامت دستی #$n: کاربر مشکل/قطعی رو ثبت کرد | streams=${t.activeTcpStreams} | stalls=${TunnelStats.get("stall.total")} abort=${TunnelStats.get("stall.abort")} | " +
                "ws.fail=${TunnelStats.get("ws.fail")} noreply=${TunnelStats.get("conn.zeroRx")} | net=$lastNetDesc changes=${TunnelStats.get("net.change")}" +
                (if (b != null) " | bat=${"%.1f".format(b.tempC)}C" else "")
        )
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            android.widget.Toast.makeText(applicationContext, "علامت ثبت شد ✓", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private val appLabelCache = java.util.concurrent.ConcurrentHashMap<Int, String>()

    /** Package name of the app that owns a TCP connection going through the TUN (Android 10+). */
    private fun resolveConnectionApp(srcIp: ByteArray, srcPort: Int, dstIp: ByteArray, dstPort: Int): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "?"
        val cm = getSystemService(android.net.ConnectivityManager::class.java) ?: return "?"
        val uid = runCatching {
            cm.getConnectionOwnerUid(
                android.system.OsConstants.IPPROTO_TCP,
                java.net.InetSocketAddress(java.net.InetAddress.getByAddress(srcIp), srcPort),
                java.net.InetSocketAddress(java.net.InetAddress.getByAddress(dstIp), dstPort)
            )
        }.getOrDefault(-1)
        if (uid < 0) return "?"
        return appLabelCache.getOrPut(uid) {
            runCatching { packageManager.getPackagesForUid(uid)?.firstOrNull() }.getOrNull() ?: "uid$uid"
        }
    }

    private fun startTunPacketLoop(pfd: ParcelFileDescriptor) {
        val engine = AppContainer.get(applicationContext).tunnelEngine
        packetLoopJob?.cancel()
        packetLoopJob = serviceScope.launch {
            val input = FileInputStream(pfd.fileDescriptor)
            val output = FileOutputStream(pfd.fileDescriptor)
            val tcpProxy = TunTcpProxy(engine, output, { latestSettings }, ::resolveConnectionApp, AppContainer.get(applicationContext).mitmCa)
            tunTcpProxy?.closeAll()
            tunTcpProxy = tcpProxy
            val packetBuf = ByteArray(32767)

            while (isActive) {
                val len = runCatching { input.read(packetBuf) }.getOrDefault(-1)
                if (len <= 0) {
                    if (len < 0) break
                    continue
                }
                val ipVersion = (packetBuf[0].toInt() ushr 4) and 0x0F
                if (ipVersion != 4 || len < 20) continue

                val ihl = (packetBuf[0].toInt() and 0x0F) * 4
                if (len < ihl) continue
                val protocol = packetBuf[9].toInt() and 0xFF

                // Intercept UDP port 53 (DNS) and resolve via DoH / GAS tunnel
                if (protocol == 17 && len >= ihl + 8) {
                    val dstPort = ((packetBuf[ihl + 2].toInt() and 0xFF) shl 8) or
                        (packetBuf[ihl + 3].toInt() and 0xFF)
                    if (dstPort == 53) {
                        val dnsQuery = packetBuf.copyOfRange(ihl + 8, len)
                        val reqCopy = packetBuf.copyOf(len)
                        launch {
                            val dnsAnswer = engine.resolveDohPacket(dnsQuery)
                            if (dnsAnswer != null) {
                                val replyPacket = buildUdpIpv4Reply(reqCopy, ihl, dnsAnswer)
                                synchronized(output) {
                                    runCatching { output.write(replyPacket) }
                                }
                            }
                        }
                    } else {
                        // Non-DNS UDP (QUIC/HTTP3, STUN...) can't go through the tunnel.
                        // Answer with ICMP "port unreachable" so apps fall back to TCP instantly
                        // instead of waiting for a multi-second QUIC timeout.
                        com.example.core.logging.TunnelStats.inc("udp.icmp")
                        val icmp = buildIcmpPortUnreachable(packetBuf, len, ihl)
                        synchronized(output) {
                            runCatching { output.write(icmp) }
                        }
                    }
                } else if (protocol == 6) {
                    tcpProxy.handleOutboundTcpPacket(packetBuf, len)
                } else {
                    engine.recordTraffic(upBytes = len.toLong(), downBytes = 0L)
                }
            }
        }
    }

    private fun buildUdpIpv4Reply(reqPacket: ByteArray, reqIhl: Int, payload: ByteArray): ByteArray {
        val ipHeaderLen = 20
        val udpHeaderLen = 8
        val totalLen = ipHeaderLen + udpHeaderLen + payload.size
        val out = ByteArray(totalLen)

        // IPv4 Header
        out[0] = 0x45.toByte()
        out[1] = 0x00
        out[2] = ((totalLen ushr 8) and 0xFF).toByte()
        out[3] = (totalLen and 0xFF).toByte()
        out[4] = reqPacket[4]
        out[5] = reqPacket[5]
        out[6] = 0x40.toByte()
        out[7] = 0x00
        out[8] = 64.toByte() // TTL
        out[9] = 17.toByte() // UDP
        // Swap src and dst IP
        System.arraycopy(reqPacket, 16, out, 12, 4)
        System.arraycopy(reqPacket, 12, out, 16, 4)

        val ipChecksum = computeChecksum(out, 0, ipHeaderLen)
        out[10] = ((ipChecksum ushr 8) and 0xFF).toByte()
        out[11] = (ipChecksum and 0xFF).toByte()

        // UDP Header (swap ports)
        out[20] = reqPacket[reqIhl + 2]
        out[21] = reqPacket[reqIhl + 3]
        out[22] = reqPacket[reqIhl]
        out[23] = reqPacket[reqIhl + 1]
        val udpLen = udpHeaderLen + payload.size
        out[24] = ((udpLen ushr 8) and 0xFF).toByte()
        out[25] = (udpLen and 0xFF).toByte()
        out[26] = 0
        out[27] = 0

        System.arraycopy(payload, 0, out, 28, payload.size)
        return out
    }

    private fun buildIcmpPortUnreachable(req: ByteArray, reqLen: Int, reqIhl: Int): ByteArray {
        val quoted = minOf(reqLen, reqIhl + 8)
        val totalLen = 20 + 8 + quoted
        val out = ByteArray(totalLen)
        out[0] = 0x45.toByte()
        out[2] = ((totalLen ushr 8) and 0xFF).toByte()
        out[3] = (totalLen and 0xFF).toByte()
        out[8] = 64.toByte()
        out[9] = 1.toByte() // ICMP
        System.arraycopy(req, 16, out, 12, 4) // src = original dst
        System.arraycopy(req, 12, out, 16, 4) // dst = original src
        val ipSum = computeChecksum(out, 0, 20)
        out[10] = ((ipSum ushr 8) and 0xFF).toByte()
        out[11] = (ipSum and 0xFF).toByte()
        out[20] = 3 // destination unreachable
        out[21] = 3 // port unreachable
        System.arraycopy(req, 0, out, 28, quoted)
        val icmpSum = computeChecksum(out, 20, 8 + quoted)
        out[22] = ((icmpSum ushr 8) and 0xFF).toByte()
        out[23] = (icmpSum and 0xFF).toByte()
        return out
    }

    private fun computeChecksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + length - 1) {
            val word = ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
            sum += word
            i += 2
        }
        if (length % 2 == 1) {
            sum += (data[offset + length - 1].toInt() and 0xFF) shl 8
        }
        while ((sum ushr 16) != 0L) {
            sum = (sum and 0xFFFF) + (sum ushr 16)
        }
        return (sum.inv() and 0xFFFF).toInt()
    }

    private fun buildSessionContext(
        settings: com.example.data.model.BypassSettings,
        servers: List<com.example.data.local.ServerEndpointEntity>
    ): String {
        val sb = StringBuilder()
        sb.appendLine("Build  : v30-diag | Device=${Build.MANUFACTURER} ${Build.MODEL} | Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
        sb.appendLine("Mode   : protocol=${settings.protocol.name} lb=${settings.loadBalanceMode.name} vpn=${settings.vpnModeEnabled} doh=${settings.dohEnabled} compression=${settings.compressionLevel.name}")
        sb.appendLine("Tuning : tlsFragmentation=${settings.tlsFragmentation} http2=${settings.mitmHttp2Enabled} thermalGuard=${settings.thermalGuardEnabled} cleanIpBinding=${settings.cleanIpBinding} keepAlive=${settings.adaptiveKeepAlive} proxyIp=${settings.proxyIpCountry}${if (settings.proxyIpCustom.isNotBlank()) "+custom" else ""}")
        sb.append("Servers: " + servers.joinToString(" | ") { "${it.name}[${it.endpointType.badge}]${if (it.isParallelActive) "*" else ""}" })
        return sb.toString()
    }

    private data class BatterySample(val tempC: Float, val level: Int, val charging: Boolean)

    private fun readBattery(): BatterySample? {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        if (t == Int.MIN_VALUE) return null
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        return BatterySample(t / 10f, if (lvl < 0) -1 else lvl * 100 / scale, plugged)
    }

    private fun readSystemThermalStatus(): Int? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return runCatching {
            (getSystemService(Context.POWER_SERVICE) as? PowerManager)?.currentThermalStatus
        }.getOrNull()
    }

    private fun recordBattery(): BatterySample? {
        val b = readBattery() ?: return null
        TunnelStats.gauge("bat.temp", b.tempC.toDouble())
        TunnelStats.gauge("bat.level", b.level.toDouble())
        return b
    }

    /**
     * One compact line every 15s: connection rate, pool churn, throughput and battery temperature.
     * Reading the PULSE lines in order shows exactly WHEN the load (and the heat) started.
     */
    private fun startHealthMonitor() {
        val engine = AppContainer.get(applicationContext).tunnelEngine
        healthJob?.cancel()
        healthJob = serviceScope.launch {
            val keys = listOf(
                "conn.total", "conn.zeroRx", "conn.fallback", "ws.opened", "ws.fail",
                "pool.warm", "pool.cold", "pool.discard", "bypass.direct", "udp.icmp"
            )
            var prev = keys.associateWith { TunnelStats.get(it) }
            var prevDown = engine.telemetry.value.totalDownloadBytes
            var prevUp = engine.telemetry.value.totalUploadBytes
            recordBattery()?.let { engine.updateThermalReading(it.tempC, it.charging) }
            readSystemThermalStatus()?.let { engine.updateSystemThermalStatus(it) }
            val periodS = 15
            while (isActive) {
                repeat(3) {
                    delay(5000L)
                    readBattery()?.let { engine.updateThermalReading(it.tempC, it.charging) }
                    readSystemThermalStatus()?.let { engine.updateSystemThermalStatus(it) }
                }
                val cur = keys.associateWith { TunnelStats.get(it) }
                fun d(k: String) = ((cur[k] ?: 0) - (prev[k] ?: 0)).coerceAtLeast(0)
                val t = engine.telemetry.value
                val downKb = ((t.totalDownloadBytes - prevDown).coerceAtLeast(0L) / 1024f / periodS)
                val upKb = ((t.totalUploadBytes - prevUp).coerceAtLeast(0L) / 1024f / periodS)
                prev = cur; prevDown = t.totalDownloadBytes; prevUp = t.totalUploadBytes

                val b = recordBattery()
                val connPerMin = d("conn.total") * 60.0 / periodS
                TunnelStats.gauge("conn.perMin", connPerMin)
                TunnelStats.gauge("streams", t.activeTcpStreams.toDouble())

                val warmPhone = b != null && b.tempC >= 42f
                // HOT only means "tunnel is hot" if the tunnel actually carried load in this window
                val busy = (downKb + upKb) > 50f || d("conn.total") > 10
                val hot = warmPhone && busy
                if (warmPhone) TunnelStats.inc(if (busy) "pulse.hotBusy" else "pulse.hotIdle")
                val churn = d("ws.opened") > d("conn.total") * 2 + 3
                val bad = d("conn.zeroRx") > 0 || d("ws.fail") > 0 || d("conn.fallback") > 0
                val level = if (hot || churn || bad) com.example.core.logging.LogLevel.WARN else com.example.core.logging.LogLevel.INFO
                val flags = buildList {
                    if (hot) add("HOT") else if (warmPhone) add("PHONE-WARM(idle-tunnel)")
                    if (churn) add("POOL-CHURN")
                    if (d("conn.zeroRx") > 0) add("NO-REPLY")
                    if (d("ws.fail") > 0) add("WS-FAIL")
                    if (d("conn.fallback") > 0) add("FALLBACK")
                }.joinToString(",").let { if (it.isEmpty()) "" else "  <<< $it" }
                val bat = if (b == null) "bat=?" else "bat=${"%.1f".format(b.tempC)}C ${b.level}%${if (b.charging) " charging" else ""}"
                TunnelLogger.log(
                    level, LogCategory.SYSTEM, "PULSE",
                    "${periodS}s | conn +${d("conn.total")} (${"%.0f".format(connPerMin)}/min) noreply=${d("conn.zeroRx")} fail=${d("ws.fail")} fb=${d("conn.fallback")} | " +
                        "ws-opened +${d("ws.opened")} discarded +${d("pool.discard")} warm/cold +${d("pool.warm")}/${d("pool.cold")} | " +
                        "domestic-direct +${d("bypass.direct")} icmp +${d("udp.icmp")} | streams=${t.activeTcpStreams} | " +
                        "down=${"%.0f".format(downKb)}KB/s up=${"%.0f".format(upKb)}KB/s | $bat$flags"
                )
            }
        }
    }

    private fun startNotificationUpdater() {
        val engine = AppContainer.get(applicationContext).tunnelEngine
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationJob?.cancel()
        notificationJob = serviceScope.launch {
            var lastNotifyMs = 0L
            engine.telemetry.collect { t ->
                // Rebuilding + posting the notification every second keeps the CPU/radio awake.
                val nowMs = System.currentTimeMillis()
                if (nowMs - lastNotifyMs < 5_000L) return@collect
                lastNotifyMs = nowMs
                val text = "پایداری ${t.stabilityScore.toInt()}% • ↓ ${"%.1f".format(t.downloadKbps)} KB/s • ↑ ${"%.1f".format(t.uploadKbps)} KB/s"
                nm.notify(NOTIFICATION_ID, buildNotification(text))
            }
        }
    }

    private fun stopTunnel() {
        // onStartCommand(DISCONNECT) and onDestroy() both call this: only run it once per session
        // (the old build logged "session stopped" twice and saved two reports).
        if (!running.compareAndSet(true, false)) return
        healthJob?.cancel()
        healthJob = null
        settingsJob?.cancel()
        settingsJob = null
        stopNetworkMonitor()
        val container = AppContainer.get(applicationContext)
        val engine = container.tunnelEngine
        val t = engine.telemetry.value

        if (sessionStartMs > 0L) {
            val started = sessionStartMs
            sessionStartMs = 0L
            serviceScope.launch {
                val settings = container.settingsRepository.settingsFlow.first()
            latestSettings = settings
                val isOnline = container.networkSyncManager.syncStatus.value.isOnline
                val savedBytes = (t.rawBytesProcessed - t.compressedBytesSent).coerceAtLeast(0L)
                container.tunnelRepository.recordConnectionReport(
                    ConnectionReportEntity(
                        startedAtMs = started,
                        endedAtMs = System.currentTimeMillis(),
                        protocolName = settings.protocol.titleFa,
                        endpointSummary = t.activeEndpointLabel,
                        avgLatencyMs = t.currentLatencyMs,
                        jitterMs = t.jitterMs,
                        stabilityScore = t.stabilityScore,
                        packetLossPercent = t.packetLossPercent,
                        downloadBytes = t.totalDownloadBytes,
                        uploadBytes = t.totalUploadBytes,
                        compressionSavedBytes = savedBytes,
                        notes = "تعداد سرورهای موازی: ${t.activeEndpointCount}"
                    ),
                    isOnline = isOnline
                )
            }
        }

        notificationJob?.cancel()
        packetLoopJob?.cancel()
        tunTcpProxy?.closeAll()
        tunTcpProxy = null
        com.example.network.DnsttProcessManager.stop()
        socksServer?.stop()
        socksServer = null
        BypassOkHttpFactory.socketProtector = null
        BypassOkHttpFactory.datagramProtector = null
        runCatching { tunInterface?.close() }
        tunInterface = null
        engine.stopTelemetrySession()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopTunnel()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.vpn_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.vpn_channel_desc)
            }
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(contentText: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val disconnectIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, ScriptVpnService::class.java).apply { action = ACTION_DISCONNECT },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val markIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, ScriptVpnService::class.java).apply { action = ACTION_MARK },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(getString(R.string.vpn_notification_title))
            .setContentText(contentText)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, getString(R.string.vpn_action_disconnect), disconnectIntent)
            .addAction(0, getString(R.string.vpn_action_mark), markIntent)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "script_tunnel_vpn_channel"
        const val NOTIFICATION_ID = 4102
        const val ACTION_CONNECT = "com.example.action.CONNECT"
        const val ACTION_DISCONNECT = "com.example.action.DISCONNECT"
        const val ACTION_MARK = "com.example.action.MARK"
        private val NOISY_SYSTEM_PACKAGES = listOf(
            "com.miui.analytics",
            "com.miui.msa.global",
            "com.miui.systemAdSolution",
            "com.xiaomi.xmsf",
            "com.miui.cloudservice",
            "com.xiaomi.mipicks"
        )
    }
}
