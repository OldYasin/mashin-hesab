package com.example.core.logging

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

enum class LogLevel(val shortLabel: String, val titleFa: String) {
    DEBUG("DBG", "دیباگ"),
    INFO("INF", "اطلاعات"),
    WARN("WRN", "هشدار"),
    ERROR("ERR", "خطا")
}

enum class LogCategory(val badge: String, val titleFa: String) {
    GAS("GAS", "گوگل اسکریپت"),
    TLS_IP("TLS", "اسکن و SSL"),
    CF_WS("WS", "کلودفلر"),
    DNS_DOH("DOH", "دی‌ان‌اس"),
    VPN("VPN", "سرویس VPN"),
    SYNC("SYNC", "همگام‌سازی"),
    SYSTEM("SYS", "سیستم")
}

data class TunnelLogEntry(
    val id: Long,
    val timestampMs: Long,
    val level: LogLevel,
    val category: LogCategory,
    val tag: String,
    val message: String,
    val details: String? = null
)

object TunnelLogger {

    private const val MAX_ENTRIES = 1500
    private val idGen = AtomicLong(1L)
    private val lock = Any()
    private val buffer = ArrayDeque<TunnelLogEntry>(MAX_ENTRIES)

    private val _logs = MutableStateFlow<List<TunnelLogEntry>>(emptyList())
    val logs: StateFlow<List<TunnelLogEntry>> = _logs.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    fun togglePause() {
        val next = !_isPaused.value
        _isPaused.value = next
        if (!next) {
            synchronized(lock) {
                _logs.value = buffer.reversed()
            }
        }
    }

    fun log(
        level: LogLevel,
        category: LogCategory,
        tag: String,
        message: String,
        details: String? = null
    ) {
        val entry = TunnelLogEntry(
            id = idGen.getAndIncrement(),
            timestampMs = System.currentTimeMillis(),
            level = level,
            category = category,
            tag = tag,
            message = message,
            details = details?.takeIf { it.isNotBlank() }
        )
        synchronized(lock) {
            if (buffer.size >= MAX_ENTRIES) {
                buffer.removeFirst()
            }
            buffer.addLast(entry)
            if (!_isPaused.value) {
                _logs.value = buffer.reversed()
            }
        }
    }

    fun d(category: LogCategory, tag: String, message: String, details: String? = null) =
        log(LogLevel.DEBUG, category, tag, message, details)

    fun i(category: LogCategory, tag: String, message: String, details: String? = null) =
        log(LogLevel.INFO, category, tag, message, details)

    fun w(category: LogCategory, tag: String, message: String, details: String? = null) =
        log(LogLevel.WARN, category, tag, message, details)

    fun e(category: LogCategory, tag: String, message: String, details: String? = null) =
        log(LogLevel.ERROR, category, tag, message, details)

    fun clear() {
        synchronized(lock) {
            buffer.clear()
            _logs.value = emptyList()
        }
    }

    fun exportAsText(entries: List<TunnelLogEntry> = _logs.value): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
        val errCount = entries.count { it.level == LogLevel.ERROR }
        val warnCount = entries.count { it.level == LogLevel.WARN }
        val infoCount = entries.count { it.level == LogLevel.INFO }
        val dbgCount = entries.count { it.level == LogLevel.DEBUG }

        val sb = StringBuilder()
        sb.appendLine("=== ScriptTunnel Diagnostic Logs ===")
        sb.appendLine("Exported: ${fmt.format(Date())}")
        sb.appendLine("Summary : Total=${entries.size} | ERR=$errCount | WRN=$warnCount | INF=$infoCount | DBG=$dbgCount")
        sb.appendLine("====================================")
        entries.reversed().forEach { entry ->
            sb.append("[${fmt.format(Date(entry.timestampMs))}] ")
            sb.append("[${entry.level.shortLabel}] ")
            sb.append("[${entry.category.badge}/${entry.tag}] ")
            sb.appendLine(entry.message)
            if (!entry.details.isNullOrBlank()) {
                entry.details.lines().forEach { line ->
                    sb.appendLine("    | $line")
                }
            }
        }
        return sb.toString()
    }
}
