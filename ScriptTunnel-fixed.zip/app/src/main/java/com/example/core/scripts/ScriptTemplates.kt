package com.example.core.scripts

import android.util.Base64
import com.example.data.local.ServerEndpointEntity
import com.example.data.model.EndpointType
import org.json.JSONObject

object ScriptTemplates {

    fun generateGoogleAppsScript(
        secretKey: String,
        enableEncryption: Boolean = true,
        enableGzip: Boolean = true
    ): String = """
/**
 * ScriptTunnel v2 - Google Apps Script Encrypted & Compressed Relay
 * Deploy as: Web App -> Execute as: Me -> Who has access: Anyone
 * No VPS Required | Parallel Multi-Script Ready | DoH + HTTP/HTTPS Relay
 */
const TUNNEL_SECRET = "$secretKey";
const ENFORCE_ENCRYPTION = $enableEncryption;
const ENABLE_GZIP_RESPONSE = $enableGzip;

function doGet(e) {
  const params = (e && e.parameter) ? e.parameter : {};
  if (params.ping === "1") {
    if (params.token && params.token !== TUNNEL_SECRET) {
      return jsonOut({ ok: false, error: "unauthorized" });
    }
    return jsonOut({
      ok: true,
      edge: "google-apps-script",
      ts: Date.now(),
      enc: ENFORCE_ENCRYPTION,
      gzip: ENABLE_GZIP_RESPONSE
    });
  }
  return jsonOut({ ok: true, service: "ScriptTunnel Relay Active" });
}

function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) {
      return jsonOut({ ok: false, error: "empty_body" });
    }
    const envelope = JSON.parse(e.postData.contents);
    let payloadBytes;

    if (envelope.enc === true && envelope.data) {
      const rawPacket = Utilities.base64Decode(envelope.data);
      const decrypted = decryptStreamHmac(rawPacket, TUNNEL_SECRET);
      if (!decrypted) {
        return jsonOut({ ok: false, error: "hmac_auth_failed" });
      }
      payloadBytes = decrypted;
    } else if (!ENFORCE_ENCRYPTION && envelope.token === TUNNEL_SECRET && envelope.data) {
      payloadBytes = Utilities.base64Decode(envelope.data);
    } else {
      return jsonOut({ ok: false, error: "invalid_auth_or_encryption" });
    }

    if (envelope.comp === "gzip") {
      payloadBytes = Utilities.ungzip(Utilities.newBlob(payloadBytes, "application/x-gzip")).getBytes();
    }

    const req = JSON.parse(Utilities.newBlob(payloadBytes).getDataAsString("UTF-8"));

    // Action 1: DNS-over-HTTPS Query
    if (req.action === "doh" && req.dnsB64) {
      const dnsWire = Utilities.base64Decode(req.dnsB64);
      const dohRes = UrlFetchApp.fetch("https://dns.google/dns-query", {
        method: "post",
        contentType: "application/dns-message",
        headers: { "Accept": "application/dns-message" },
        payload: dnsWire,
        muteHttpExceptions: true
      });
      return respondEncrypted({
        ok: true,
        status: dohRes.getResponseCode(),
        dnsB64: Utilities.base64Encode(dohRes.getContent())
      });
    }

    // Action 2: Telemetry Sync Echo (Offline Queue Sync)
    if (req.action === "sync_ack") {
      return respondEncrypted({ ok: true, syncedAt: Date.now(), count: req.count || 0 });
    }

    // Action 3: HTTP/HTTPS Relay
    if (!req.url) {
      return jsonOut({ ok: false, error: "missing_url" });
    }

    const fetchOpts = {
      method: (req.method || "get").toLowerCase(),
      headers: req.headers || {},
      muteHttpExceptions: true,
      followRedirects: req.followRedirects !== false
    };
    if (req.bodyB64 && fetchOpts.method !== "get" && fetchOpts.method !== "head") {
      fetchOpts.payload = Utilities.base64Decode(req.bodyB64);
    }

    const res = UrlFetchApp.fetch(req.url, fetchOpts);
    const bodyBytes = res.getContent();
    return respondEncrypted({
      ok: true,
      status: res.getResponseCode(),
      headers: res.getAllHeaders(),
      bodyB64: Utilities.base64Encode(bodyBytes)
    });
  } catch (err) {
    return jsonOut({ ok: false, error: String(err) });
  }
}

function respondEncrypted(obj) {
  let rawBytes = Utilities.newBlob(JSON.stringify(obj)).getBytes();
  let compMode = "none";
  if (ENABLE_GZIP_RESPONSE && rawBytes.length > 64) {
    const gz = Utilities.gzip(Utilities.newBlob(rawBytes)).getBytes();
    if (gz.length < rawBytes.length) {
      rawBytes = gz;
      compMode = "gzip";
    }
  }
  const encrypted = encryptStreamHmac(rawBytes, TUNNEL_SECRET);
  return jsonOut({
    ok: true,
    enc: true,
    comp: compMode,
    data: Utilities.base64Encode(encrypted)
  });
}

function jsonOut(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function sha256Bytes(bytes) {
  return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, bytes);
}

function encryptStreamHmac(plain, secret) {
  const key = sha256Bytes(Utilities.newBlob(secret).getBytes());
  const nonce = [];
  for (let i = 0; i < 16; i++) nonce.push(Math.floor(Math.random() * 256) - 128);
  const cipher = xorKeyStream(plain, key, nonce);
  const macInput = nonce.concat(cipher);
  const tag = Utilities.computeHmacSha256Signature(macInput, key);
  return nonce.concat(tag).concat(cipher);
}

function decryptStreamHmac(packet, secret) {
  if (!packet || packet.length < 48) return null;
  const key = sha256Bytes(Utilities.newBlob(secret).getBytes());
  const nonce = packet.slice(0, 16);
  const tag = packet.slice(16, 48);
  const cipher = packet.slice(48);
  const expected = Utilities.computeHmacSha256Signature(nonce.concat(cipher), key);
  for (let i = 0; i < 32; i++) {
    if ((tag[i] & 0xff) !== (expected[i] & 0xff)) return null;
  }
  return xorKeyStream(cipher, key, nonce);
}

function xorKeyStream(input, key, nonce) {
  const out = new Array(input.length);
  let counter = 0;
  let offset = 0;
  while (offset < input.length) {
    const cBytes = [
      (counter >>> 24) & 0xff,
      (counter >>> 16) & 0xff,
      (counter >>> 8) & 0xff,
      counter & 0xff
    ].map(b => b > 127 ? b - 256 : b);
    const block = sha256Bytes(key.concat(nonce).concat(cBytes));
    const n = Math.min(block.length, input.length - offset);
    for (let i = 0; i < n; i++) {
      out[offset + i] = ((input[offset + i] & 0xff) ^ (block[i] & 0xff));
      if (out[offset + i] > 127) out[offset + i] -= 256;
    }
    offset += n;
    counter++;
  }
  return out;
}
""".trimIndent()

    fun generateCloudflareWorkerScript(secretKey: String): String = """
/**
 * ScriptTunnel v2 - Cloudflare Worker Full-Duplex TCP over WebSocket
 * Supports ALL TCP protocols (SOCKS5, Telegram, SSH, HTTPS, APIs)
 * Uses cloudflare:sockets connect() + Early-Data + KeepAlive
 */
import { connect } from 'cloudflare:sockets';

const TUNNEL_SECRET = "$secretKey";

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const upgradeHeader = request.headers.get("Upgrade");

    // Health check endpoint
    if (url.pathname === "/ping") {
      return new Response(JSON.stringify({ ok: true, edge: "cf-worker-ws", ts: Date.now() }), {
        headers: { "content-type": "application/json" }
      });
    }

    if (!upgradeHeader || upgradeHeader.toLowerCase() !== "websocket") {
      return new Response("ScriptTunnel CF-Worker Active", { status: 200 });
    }

    const authToken = request.headers.get("X-Tunnel-Auth") || url.searchParams.get("token");
    if (authToken !== TUNNEL_SECRET) {
      return new Response("Unauthorized", { status: 403 });
    }

    const webSocketPair = new WebSocketPair();
    const [client, server] = Object.values(webSocketPair);
    server.accept();

    let remoteSocket = null;
    let remoteWriter = null;
    let closed = false;

    const cleanup = () => {
      if (closed) return;
      closed = true;
      try { remoteWriter?.releaseLock(); } catch {}
      try { remoteSocket?.close(); } catch {}
      try { server.close(); } catch {}
    };

    server.addEventListener("message", async (event) => {
      try {
        if (typeof event.data === "string") {
          const ctrl = JSON.parse(event.data);
          if (ctrl.type === "PING") {
            server.send(JSON.stringify({ type: "PONG", ts: Date.now() }));
            return;
          }
          if (ctrl.type === "CONNECT" && ctrl.host && ctrl.port && !remoteSocket) {
            remoteSocket = connect({ hostname: ctrl.host, port: Number(ctrl.port) });
            await remoteSocket.opened;
            remoteWriter = remoteSocket.writable.getWriter();
            server.send(JSON.stringify({ type: "CONNECTED" }));

            // Pipe remote TCP -> WebSocket
            (async () => {
              const reader = remoteSocket.readable.getReader();
              try {
                while (true) {
                  const { value, done } = await reader.read();
                  if (done) break;
                  if (value && value.byteLength > 0) {
                    server.send(value);
                  }
                }
              } catch (e) {
                // ignore read close
              } finally {
                cleanup();
              }
            })();
          }
        } else if (remoteWriter && typeof event.data !== "string") {
          const bytes = event.data instanceof ArrayBuffer
            ? new Uint8Array(event.data)
            : ArrayBuffer.isView(event.data)
              ? new Uint8Array(event.data.buffer, event.data.byteOffset, event.data.byteLength)
              : new Uint8Array(await event.data.arrayBuffer());
          await remoteWriter.ready;
          await remoteWriter.write(bytes);
        }
      } catch (err) {
        try {
          server.send(JSON.stringify({ type: "ERROR", message: String(err) }));
        } catch {}
        cleanup();
      }
    });

    server.addEventListener("close", cleanup);
    server.addEventListener("error", cleanup);

    return new Response(null, { status: 101, webSocket: client });
  }
};
""".trimIndent()

    fun encodeShareUri(endpoint: ServerEndpointEntity): String {
        val json = JSONObject().apply {
            put("v", 2)
            put("name", endpoint.name)
            put("url", endpoint.url)
            put("key", endpoint.secretKey)
            put("type", endpoint.type)
            put("sni", endpoint.customSniHost)
            put("ip", endpoint.customCleanIp)
            put("w", endpoint.weight)
        }.toString()
        val b64 = Base64.encodeToString(json.toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.URL_SAFE)
        return "scriptvpn://$b64"
    }

    fun decodeShareUri(raw: String): ServerEndpointEntity? {
        val trimmed = raw.trim()
        val jsonStr = when {
            trimmed.startsWith("scriptvpn://") -> {
                val b64 = trimmed.removePrefix("scriptvpn://")
                runCatching {
                    String(Base64.decode(b64, Base64.URL_SAFE or Base64.DEFAULT), Charsets.UTF_8)
                }.getOrNull() ?: return null
            }
            trimmed.startsWith("{") -> trimmed
            else -> return null
        }
        return runCatching {
            val obj = JSONObject(jsonStr)
            val url = obj.getString("url").trim()
            val typeStr = obj.optString("type", EndpointType.GAS_SCRIPT.name)
            ServerEndpointEntity(
                name = obj.optString("name", "سرور واردشده"),
                url = url,
                secretKey = obj.optString("key", ""),
                type = typeStr,
                customSniHost = obj.optString("sni", ""),
                customCleanIp = obj.optString("ip", ""),
                weight = obj.optInt("w", 1),
                isParallelActive = true
            )
        }.getOrNull()
    }
}
