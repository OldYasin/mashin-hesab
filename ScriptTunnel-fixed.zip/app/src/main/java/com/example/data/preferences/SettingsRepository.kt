package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.BypassSettings
import com.example.data.model.CompressionLevel
import com.example.data.model.LoadBalanceMode
import com.example.data.model.TunnelProtocol
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "script_tunnel_prefs")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val PROTOCOL = stringPreferencesKey("protocol")
        val LOAD_BALANCE = stringPreferencesKey("load_balance")
        val COMPRESSION = stringPreferencesKey("compression")
        val TLS_FRAG = booleanPreferencesKey("tls_frag")
        val CLEAN_IP_BIND = booleanPreferencesKey("clean_ip_bind")
        val PAYLOAD_ENC = booleanPreferencesKey("payload_enc")
        val RANDOM_PADDING = booleanPreferencesKey("random_padding")
        val ADAPTIVE_KEEPALIVE = booleanPreferencesKey("adaptive_keepalive")
        val DOH_ENABLED = booleanPreferencesKey("doh_enabled")
        val DOH_URL = stringPreferencesKey("doh_url")
        val SOCKS_PORT = intPreferencesKey("socks_port")
        val VPN_MODE = booleanPreferencesKey("vpn_mode")
        val CLEAN_GOOGLE_IP = stringPreferencesKey("clean_google_ip")
        val CLEAN_CF_IP = stringPreferencesKey("clean_cf_ip")
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val GENERATED_SECRET = stringPreferencesKey("generated_secret")
        val LAST_SYNC_MS = longPreferencesKey("last_sync_ms")
    }

    val settingsFlow: Flow<BypassSettings> = context.dataStore.data.map { prefs ->
        BypassSettings(
            protocol = prefs[Keys.PROTOCOL]?.let {
                runCatching { TunnelProtocol.valueOf(it) }.getOrNull()
            } ?: TunnelProtocol.HYBRID_SMART,
            loadBalanceMode = prefs[Keys.LOAD_BALANCE]?.let {
                runCatching { LoadBalanceMode.valueOf(it) }.getOrNull()
            } ?: LoadBalanceMode.ADAPTIVE_LATENCY,
            compressionLevel = prefs[Keys.COMPRESSION]?.let {
                runCatching { CompressionLevel.valueOf(it) }.getOrNull()
            } ?: CompressionLevel.ULTRA_GZIP,
            tlsFragmentation = prefs[Keys.TLS_FRAG] ?: true,
            cleanIpBinding = prefs[Keys.CLEAN_IP_BIND] ?: true,
            payloadEncryption = prefs[Keys.PAYLOAD_ENC] ?: true,
            randomPadding = prefs[Keys.RANDOM_PADDING] ?: true,
            adaptiveKeepAlive = prefs[Keys.ADAPTIVE_KEEPALIVE] ?: true,
            dohEnabled = prefs[Keys.DOH_ENABLED] ?: true,
            dohUrl = prefs[Keys.DOH_URL] ?: "https://dns.google/dns-query",
            localSocksPort = prefs[Keys.SOCKS_PORT] ?: 10808,
            vpnModeEnabled = prefs[Keys.VPN_MODE] ?: true,
            activeCleanGoogleIp = prefs[Keys.CLEAN_GOOGLE_IP] ?: "",
            activeCleanCfIp = prefs[Keys.CLEAN_CF_IP] ?: "",
            darkTheme = prefs[Keys.DARK_THEME] ?: true
        )
    }

    val generatedSecretFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.GENERATED_SECRET] ?: "st_key_9f4a2c8e1d7b6035a4f9e2c1"
    }

    val lastSyncTimeFlow: Flow<Long> = context.dataStore.data.map { prefs ->
        prefs[Keys.LAST_SYNC_MS] ?: 0L
    }

    suspend fun updateSettings(transform: (BypassSettings) -> BypassSettings) {
        context.dataStore.edit { prefs ->
            val current = BypassSettings(
                protocol = prefs[Keys.PROTOCOL]?.let { runCatching { TunnelProtocol.valueOf(it) }.getOrNull() }
                    ?: TunnelProtocol.HYBRID_SMART,
                loadBalanceMode = prefs[Keys.LOAD_BALANCE]?.let { runCatching { LoadBalanceMode.valueOf(it) }.getOrNull() }
                    ?: LoadBalanceMode.ADAPTIVE_LATENCY,
                compressionLevel = prefs[Keys.COMPRESSION]?.let { runCatching { CompressionLevel.valueOf(it) }.getOrNull() }
                    ?: CompressionLevel.ULTRA_GZIP,
                tlsFragmentation = prefs[Keys.TLS_FRAG] ?: true,
                cleanIpBinding = prefs[Keys.CLEAN_IP_BIND] ?: true,
                payloadEncryption = prefs[Keys.PAYLOAD_ENC] ?: true,
                randomPadding = prefs[Keys.RANDOM_PADDING] ?: true,
                adaptiveKeepAlive = prefs[Keys.ADAPTIVE_KEEPALIVE] ?: true,
                dohEnabled = prefs[Keys.DOH_ENABLED] ?: true,
                dohUrl = prefs[Keys.DOH_URL] ?: "https://dns.google/dns-query",
                localSocksPort = prefs[Keys.SOCKS_PORT] ?: 10808,
                vpnModeEnabled = prefs[Keys.VPN_MODE] ?: true,
                activeCleanGoogleIp = prefs[Keys.CLEAN_GOOGLE_IP] ?: "",
                activeCleanCfIp = prefs[Keys.CLEAN_CF_IP] ?: "",
                darkTheme = prefs[Keys.DARK_THEME] ?: true
            )
            val updated = transform(current)
            prefs[Keys.PROTOCOL] = updated.protocol.name
            prefs[Keys.LOAD_BALANCE] = updated.loadBalanceMode.name
            prefs[Keys.COMPRESSION] = updated.compressionLevel.name
            prefs[Keys.TLS_FRAG] = updated.tlsFragmentation
            prefs[Keys.CLEAN_IP_BIND] = updated.cleanIpBinding
            prefs[Keys.PAYLOAD_ENC] = updated.payloadEncryption
            prefs[Keys.RANDOM_PADDING] = updated.randomPadding
            prefs[Keys.ADAPTIVE_KEEPALIVE] = updated.adaptiveKeepAlive
            prefs[Keys.DOH_ENABLED] = updated.dohEnabled
            prefs[Keys.DOH_URL] = updated.dohUrl
            prefs[Keys.SOCKS_PORT] = updated.localSocksPort
            prefs[Keys.VPN_MODE] = updated.vpnModeEnabled
            prefs[Keys.CLEAN_GOOGLE_IP] = updated.activeCleanGoogleIp
            prefs[Keys.CLEAN_CF_IP] = updated.activeCleanCfIp
            prefs[Keys.DARK_THEME] = updated.darkTheme
        }
    }

    suspend fun saveGeneratedSecret(secret: String) {
        context.dataStore.edit { it[Keys.GENERATED_SECRET] = secret }
    }

    suspend fun updateLastSyncTime(timeMs: Long) {
        context.dataStore.edit { it[Keys.LAST_SYNC_MS] = timeMs }
    }
}
