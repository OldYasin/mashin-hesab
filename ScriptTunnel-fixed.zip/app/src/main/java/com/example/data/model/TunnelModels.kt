package com.example.data.model

enum class EndpointType(val labelFa: String, val badge: String) {
    GAS_SCRIPT("اسکریپت گوگل", "GAS"),
    CF_WORKER_WS("وب‌سوکت کلودفلر", "CF-WS"),
    HYBRID_BRIDGE("پل ترکیبی", "HYBRID")
}

enum class TunnelProtocol(val titleFa: String, val subtitleFa: String) {
    GAS_PARALLEL("تونل موازی گوگل", "ارسال هم‌زمان روی چند اسکریپت بدون نیاز به VPS"),
    CF_WEBSOCKET("وب‌سوکت کلودفلر", "پشتیبانی کامل از تمام پروتکل‌ها و SOCKS5"),
    HYBRID_SMART("ترکیبی هوشمند", "کنترل و DoH با گوگل + استریم TCP با وب‌سوکت"),
    SOCKS5_LOCAL("پروکسی محلی SOCKS5", "پورت اختصاصی 127.0.0.1 برای اتصال ابزارهای جانبی")
}

enum class LoadBalanceMode(val titleFa: String, val descFa: String) {
    ADAPTIVE_LATENCY("موازی هوشمند (کمترین پینگ)", "توزیع پویا بر اساس پینگ لحظه‌ای و سلامت سرور"),
    PARALLEL_ROUND_ROBIN("چرخشی موازی", "تقسیم مساوی درخواست‌ها بین همه اسکریپت‌های فعال"),
    FAILOVER("پشتیبان خودکار", "استفاده از بهترین سرور و سوئیچ آنی در صورت اختلال")
}

enum class CompressionLevel(val titleFa: String) {
    OFF("غیرفعال"),
    FAST_DEFLATE("فشرده‌سازی سریع (Deflate)"),
    ULTRA_GZIP("فشرده‌سازی پیشرفته (GZIP)")
}

enum class SyncStatus(val titleFa: String) {
    SYNCED("همگام‌سازی شده"),
    PENDING_SYNC("در صف همگام‌سازی"),
    OFFLINE_DRAFT("ذخیره آفلاین")
}

enum class TunnelConnectionState(val titleFa: String) {
    DISCONNECTED("قطع است"),
    CONNECTING("در حال برقراری تونل..."),
    CONNECTED("متصل و رمزنگاری شده"),
    RECONNECTING("در حال بازیابی پایدار اتصال..."),
    ERROR("خطا در اتصال")
}

enum class IpProvider(val titleFa: String) {
    GOOGLE("گوگل (Apps Script)"),
    CLOUDFLARE("کلودفلر (Worker WS)")
}

data class BypassSettings(
    val protocol: TunnelProtocol = TunnelProtocol.HYBRID_SMART,
    val loadBalanceMode: LoadBalanceMode = LoadBalanceMode.ADAPTIVE_LATENCY,
    val compressionLevel: CompressionLevel = CompressionLevel.ULTRA_GZIP,
    val tlsFragmentation: Boolean = true,
    val cleanIpBinding: Boolean = true,
    val payloadEncryption: Boolean = true,
    val randomPadding: Boolean = true,
    val adaptiveKeepAlive: Boolean = true,
    val dohEnabled: Boolean = true,
    val dohUrl: String = "https://dns.google/dns-query",
    val localSocksPort: Int = 10808,
    val vpnModeEnabled: Boolean = true,
    val activeCleanGoogleIp: String = "",
    val activeCleanCfIp: String = "",
    val darkTheme: Boolean = true
)

data class SpeedSample(
    val timestampMs: Long,
    val downloadKbps: Float,
    val uploadKbps: Float,
    val stabilityPercent: Float
)

data class TunnelTelemetry(
    val connectionState: TunnelConnectionState = TunnelConnectionState.DISCONNECTED,
    val downloadKbps: Float = 0f,
    val uploadKbps: Float = 0f,
    val totalDownloadBytes: Long = 0L,
    val totalUploadBytes: Long = 0L,
    val rawBytesProcessed: Long = 0L,
    val compressedBytesSent: Long = 0L,
    val stabilityScore: Float = 100f,
    val currentLatencyMs: Int = 0,
    val jitterMs: Int = 0,
    val packetLossPercent: Float = 0f,
    val activeEndpointCount: Int = 0,
    val activeEndpointLabel: String = "—",
    val activeSocksAddress: String = "127.0.0.1:10808",
    val connectedSinceMs: Long = 0L,
    val activeTcpStreams: Int = 0,
    val speedHistory: List<SpeedSample> = emptyList(),
    val lastErrorMessage: String? = null
) {
    val compressionSavingsPercent: Int
        get() = if (rawBytesProcessed <= 0L) 0
        else (((rawBytesProcessed - compressedBytesSent).coerceAtLeast(0L) * 100) / rawBytesProcessed).toInt()
}

data class NetworkSyncStatus(
    val isOnline: Boolean = true,
    val isSyncing: Boolean = false,
    val pendingTaskCount: Int = 0,
    val lastSyncTimeMs: Long = 0L,
    val lastSyncSummary: String = "آماده همگام‌سازی"
)
