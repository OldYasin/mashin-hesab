package com.example.network

import android.util.Base64
import com.example.core.crypto.TunnelCrypto
import com.example.core.logging.LogCategory
import com.example.core.logging.TunnelLogger
import com.example.data.local.ServerEndpointEntity
import com.example.data.model.BypassSettings
import com.example.data.model.CompressionLevel
import com.example.data.model.EndpointType
import com.example.data.model.LoadBalanceMode
import com.example.data.model.SpeedSample
import com.example.data.model.TunnelConnectionState
import com.example.data.model.TunnelProtocol
import com.example.data.model.TunnelTelemetry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.net.ssl.SSLException
import javax.net.ssl.SSLPeerUnverifiedException
import kotlin.math.abs

data class PingResult(
    val endpointId: Long,
    val isHealthy: Boolean,
    val latencyMs: Int,
    val message: String
)

data class GasRelayResponse(
    val ok: Boolean,
    val statusCode: Int,
    val bodyBytes: ByteArray,
    val error: String? = null
)

class ParallelTunnelEngine {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val roundRobinIndex = AtomicInteger(0)
    private val dnsCache = ConcurrentHashMap<String, Pair<Long, ByteArray>>()

    private val intervalDownBytes = AtomicLong(0L)
    private val intervalUpBytes = AtomicLong(0L)
    private val totalDownBytes = AtomicLong(0L)
    private val totalUpBytes = AtomicLong(0L)
    private val rawBytes = AtomicLong(0L)
    private val compressedBytes = AtomicLong(0L)
    private val totalRequests = AtomicInteger(0)
    private val failedRequests = AtomicInteger(0)
    private val activeStreams = AtomicInteger(0)

    @Volatile
    private var lastLatencyMs = 0

    @Volatile
    private var lastJitterMs = 0

    @Volatile
    private var activePool: List<ServerEndpointEntity> = emptyList()

    @Volatile
    private var currentSettings: BypassSettings = BypassSettings()

    private var telemetryJob: Job? = null

    private val _telemetry = MutableStateFlow(TunnelTelemetry())
    val telemetry: StateFlow<TunnelTelemetry> = _telemetry.asStateFlow()

    fun updatePoolAndSettings(endpoints: List<ServerEndpointEntity>, settings: BypassSettings) {
        activePool = endpoints.filter { it.isParallelActive }
        currentSettings = settings
        _telemetry.update {
            it.copy(
                activeEndpointCount = activePool.size,
                activeSocksAddress = "127.0.0.1:${settings.localSocksPort}",
                activeEndpointLabel = buildPoolLabel(activePool)
            )
        }
    }

    fun startTelemetrySession(state: TunnelConnectionState = TunnelConnectionState.CONNECTED) {
        totalDownBytes.set(0L)
        totalUpBytes.set(0L)
        rawBytes.set(0L)
        compressedBytes.set(0L)
        totalRequests.set(0)
        failedRequests.set(0)
        val startedAt = System.currentTimeMillis()
        _telemetry.update {
            it.copy(
                connectionState = state,
                connectedSinceMs = startedAt,
                lastErrorMessage = null,
                speedHistory = emptyList()
            )
        }
        TunnelLogger.i(
            LogCategory.SYSTEM,
            "SESSION",
            "جلسه تله‌متری تونل آغاز شد (${activePool.size} سرور فعال)",
            "Pool=${buildPoolLabel(activePool)}, Protocol=${currentSettings.protocol.name}"
        )
        telemetryJob?.cancel()
        telemetryJob = scope.launch {
            while (isActive) {
                delay(1000L)
                val downDelta = intervalDownBytes.getAndSet(0L)
                val upDelta = intervalUpBytes.getAndSet(0L)
                val downKbps = (downDelta / 1024f)
                val upKbps = (upDelta / 1024f)

                val reqCount = totalRequests.get()
                val failCount = failedRequests.get()
                val lossPct = if (reqCount == 0) 0f else (failCount * 100f) / reqCount
                val stability = computeStabilityScore(lastLatencyMs, lastJitterMs, lossPct, activePool.size)

                val sample = SpeedSample(
                    timestampMs = System.currentTimeMillis(),
                    downloadKbps = downKbps,
                    uploadKbps = upKbps,
                    stabilityPercent = stability
                )
                _telemetry.update { prev ->
                    val history = (prev.speedHistory + sample).takeLast(60)
                    prev.copy(
                        downloadKbps = downKbps,
                        uploadKbps = upKbps,
                        totalDownloadBytes = totalDownBytes.get(),
                        totalUploadBytes = totalUpBytes.get(),
                        rawBytesProcessed = rawBytes.get(),
                        compressedBytesSent = compressedBytes.get(),
                        stabilityScore = stability,
                        currentLatencyMs = lastLatencyMs,
                        jitterMs = lastJitterMs,
                        packetLossPercent = lossPct,
                        activeTcpStreams = activeStreams.get(),
                        activeEndpointCount = activePool.size,
                        activeEndpointLabel = buildPoolLabel(activePool),
                        speedHistory = history
                    )
                }
            }
        }
    }

    fun setConnectionState(state: TunnelConnectionState, errorMessage: String? = null) {
        _telemetry.update {
            it.copy(
                connectionState = state,
                lastErrorMessage = errorMessage
            )
        }
        if (errorMessage != null) {
            TunnelLogger.e(LogCategory.SYSTEM, "STATE", "وضعیت اتصال: ${state.titleFa}", errorMessage)
        } else {
            TunnelLogger.i(LogCategory.SYSTEM, "STATE", "وضعیت اتصال: ${state.titleFa}")
        }
    }

    fun stopTelemetrySession() {
        telemetryJob?.cancel()
        telemetryJob = null
        TunnelLogger.i(
            LogCategory.SYSTEM,
            "SESSION",
            "جلسه تونل متوقف شد",
            "Down=${totalDownBytes.get()}B, Up=${totalUpBytes.get()}B"
        )
        _telemetry.update {
            it.copy(
                connectionState = TunnelConnectionState.DISCONNECTED,
                downloadKbps = 0f,
                uploadKbps = 0f,
                activeTcpStreams = 0,
                connectedSinceMs = 0L
            )
        }
    }

    fun recordTraffic(upBytes: Long, downBytes: Long, rawPayload: Long = 0L, compressedPayload: Long = 0L) {
        if (upBytes > 0) {
            intervalUpBytes.addAndGet(upBytes)
            totalUpBytes.addAndGet(upBytes)
        }
        if (downBytes > 0) {
            intervalDownBytes.addAndGet(downBytes)
            totalDownBytes.addAndGet(downBytes)
        }
        if (rawPayload > 0) {
            rawBytes.addAndGet(rawPayload)
            compressedBytes.addAndGet(if (compressedPayload > 0) compressedPayload else rawPayload)
        }
    }

    fun incrementStreams() = activeStreams.incrementAndGet()
    fun decrementStreams() = activeStreams.updateAndGet { (it - 1).coerceAtLeast(0) }

    suspend fun pingEndpoint(
        endpoint: ServerEndpointEntity,
        settings: BypassSettings
    ): PingResult = withContext(Dispatchers.IO) {
        val cleanIp = endpoint.customCleanIp.ifBlank {
            if (endpoint.endpointType == EndpointType.CF_WORKER_WS) settings.activeCleanCfIp
            else settings.activeCleanGoogleIp
        }.trim()

        val normalizedUrl = normalizeHttpUrl(endpoint.url)
        val pingUrl = when (endpoint.endpointType) {
            EndpointType.CF_WORKER_WS -> {
                val base = normalizedUrl.trimEnd('/')
                "$base/ping"
            }
            else -> {
                val sep = if (normalizedUrl.contains("?")) "&" else "?"
                "${normalizedUrl}${sep}ping=1&token=${endpoint.secretKey}"
            }
        }

        if (endpoint.endpointType == EndpointType.GAS_SCRIPT && normalizedUrl.contains("/dev")) {
            TunnelLogger.w(
                LogCategory.GAS,
                "GAS-URL",
                "لینک «${endpoint.name}» به /dev ختم شده است؛ برای اجرا باید لینک /exec باشد",
                "URL=$normalizedUrl"
            )
        }

        val firstAttempt = executePingAttempt(
            endpoint = endpoint,
            settings = settings,
            pingUrl = pingUrl,
            cleanIp = cleanIp,
            disableCleanIp = false
        )

        // Automatic fallback to System DNS if Clean IP failed due to SSL Hostname / network error
        if (!firstAttempt.result.isHealthy && firstAttempt.shouldRetryDirect && cleanIp.isNotBlank()) {
            TunnelLogger.w(
                LogCategory.GAS,
                "PING-FALLBACK",
                "تلاش مجدد پینگ «${endpoint.name}» بدون آی‌پی تمیز ($cleanIp) با DNS مستقیم",
                "Reason=${firstAttempt.result.message}"
            )
            val fallback = executePingAttempt(
                endpoint = endpoint,
                settings = settings,
                pingUrl = pingUrl,
                cleanIp = "",
                disableCleanIp = true
            )
            return@withContext fallback.result
        }

        return@withContext firstAttempt.result
    }

    private data class PingAttemptOutcome(
        val result: PingResult,
        val shouldRetryDirect: Boolean = false
    )

    private fun executePingAttempt(
        endpoint: ServerEndpointEntity,
        settings: BypassSettings,
        pingUrl: String,
        cleanIp: String,
        disableCleanIp: Boolean
    ): PingAttemptOutcome {
        val logCat = if (endpoint.endpointType == EndpointType.CF_WORKER_WS) LogCategory.CF_WS else LogCategory.GAS
        val client = BypassOkHttpFactory.createClient(
            settings = settings,
            overrideCleanIp = cleanIp,
            connectTimeoutMs = 7_000L,
            readTimeoutMs = 10_000L,
            disableCleanIp = disableCleanIp
        )

        val req = Request.Builder()
            .url(pingUrl)
            .get()
            .apply {
                // Only apply custom Host header for CF Worker custom domains; never override Host for script.google.com
                if (endpoint.endpointType == EndpointType.CF_WORKER_WS && endpoint.customSniHost.isNotBlank()) {
                    header("Host", endpoint.customSniHost.trim())
                }
            }
            .build()

        val t0 = System.nanoTime()
        return try {
            client.newCall(req).execute().use { res ->
                val rtt = ((System.nanoTime() - t0) / 1_000_000L).toInt().coerceAtLeast(1)
                val body = res.body?.string().orEmpty()
                val finalUrl = res.request.url.toString()

                if (res.code == 403 || res.code == 401) {
                    val diag = build403Diagnostic(finalUrl, body)
                    TunnelLogger.e(
                        logCat,
                        "PING-${res.code}",
                        "خطای ${res.code} برای «${endpoint.name}»: $diag",
                        "URL=$pingUrl\nFinalURL=$finalUrl\nCleanIP=${cleanIp.ifBlank { "system-dns" }}\nResponse=${body.take(300)}"
                    )
                    return PingAttemptOutcome(PingResult(endpoint.id, false, -1, diag), shouldRetryDirect = false)
                }

                if (finalUrl.contains("accounts.google.com", ignoreCase = true) ||
                    (body.trimStart().startsWith("<") && !body.contains("\"ok\":true"))
                ) {
                    val msg = "صفحه ورود گوگل برگشت داده شد؛ در Deploy گزینه Who has access را روی Anyone بگذارید"
                    TunnelLogger.e(
                        logCat,
                        "PING-AUTH",
                        "خطای دسترسی برای «${endpoint.name}»: $msg",
                        "HTTP=${res.code}, FinalURL=$finalUrl\nSnippet=${body.take(240)}"
                    )
                    return PingAttemptOutcome(PingResult(endpoint.id, false, -1, msg), shouldRetryDirect = false)
                }

                if (body.contains("\"error\":\"unauthorized\"")) {
                    val msg = "کلید امنیتی (TUNNEL_SECRET) با اسکریپت گوگل مطابقت ندارد"
                    TunnelLogger.e(
                        logCat,
                        "PING-SECRET",
                        "عدم تطابق کلید امنیتی در «${endpoint.name}»",
                        "HTTP=${res.code}, Body=$body"
                    )
                    return PingAttemptOutcome(PingResult(endpoint.id, false, -1, msg), shouldRetryDirect = false)
                }

                val ok = res.isSuccessful && (body.contains("\"ok\":true") || body.contains("ScriptTunnel") || res.code in 200..299)
                if (ok) {
                    updateLatencyStats(rtt)
                    TunnelLogger.i(
                        logCat,
                        "PING-OK",
                        "پینگ موفق «${endpoint.name}» (${rtt}ms • HTTP ${res.code})",
                        "FinalURL=$finalUrl, CleanIP=${cleanIp.ifBlank { "system-dns" }}"
                    )
                    PingAttemptOutcome(PingResult(endpoint.id, true, rtt, "پینگ موفق (${rtt}ms)"))
                } else {
                    TunnelLogger.e(
                        logCat,
                        "PING-FAIL",
                        "پینگ ناموفق «${endpoint.name}» (HTTP ${res.code})",
                        "FinalURL=$finalUrl\nCleanIP=${cleanIp.ifBlank { "system-dns" }}\nBody=${body.take(240)}"
                    )
                    PingAttemptOutcome(PingResult(endpoint.id, false, -1, "کد خطا: ${res.code}"))
                }
            }
        } catch (e: SSLPeerUnverifiedException) {
            if (cleanIp.isNotBlank()) BypassOkHttpFactory.markBadCleanIp(cleanIp)
            val msg = "خطای گواهی SSL روی آی‌پی ${cleanIp.ifBlank { "پیش‌فرض" }} (عدم تطابق دامنه)"
            TunnelLogger.e(
                logCat,
                "PING-SSL",
                "خطای تایید دامنه SSL برای «${endpoint.name}»",
                "CleanIP=$cleanIp\nError=${e.localizedMessage}"
            )
            PingAttemptOutcome(PingResult(endpoint.id, false, -1, msg), shouldRetryDirect = true)
        } catch (e: SSLException) {
            val msg = "خطای TLS/SSL: ${e.localizedMessage ?: "Handshake failed"}"
            TunnelLogger.e(
                logCat,
                "PING-TLS",
                "خطای هندشیک TLS برای «${endpoint.name}»",
                "CleanIP=$cleanIp\nError=${e.javaClass.simpleName}: ${e.localizedMessage}"
            )
            PingAttemptOutcome(PingResult(endpoint.id, false, -1, msg), shouldRetryDirect = true)
        } catch (e: Exception) {
            val msg = e.localizedMessage ?: "خطای شبکه"
            TunnelLogger.e(
                logCat,
                "PING-ERR",
                "خطای اتصال به «${endpoint.name}»: $msg",
                "CleanIP=${cleanIp.ifBlank { "system-dns" }}\nException=${e.javaClass.simpleName}: ${e.message}"
            )
            PingAttemptOutcome(PingResult(endpoint.id, false, -1, msg), shouldRetryDirect = cleanIp.isNotBlank())
        }
    }

    private fun build403Diagnostic(finalUrl: String, body: String): String {
        return when {
            finalUrl.contains("/dev") -> "لینک /dev مجاز نیست؛ از لینک Deploy شده (/exec) استفاده کنید"
            body.contains("Access denied", ignoreCase = true) || body.contains("Permission", ignoreCase = true) ->
                "خطای 403 گوگل: در Deploy گزینه Who has access را روی Anyone بگذارید"
            else -> "خطای 403 گوگل: دسترسی Web App را روی Anyone قرار دهید و لینک /exec را بررسی کنید"
        }
    }

    fun selectOrderedCandidates(preferredType: EndpointType? = null): List<ServerEndpointEntity> {
        val pool = if (preferredType != null) {
            val matching = activePool.filter { it.endpointType == preferredType }
            matching.ifEmpty { activePool }
        } else {
            activePool
        }
        if (pool.isEmpty()) return emptyList()

        return when (currentSettings.loadBalanceMode) {
            LoadBalanceMode.PARALLEL_ROUND_ROBIN -> {
                val start = abs(roundRobinIndex.getAndIncrement()) % pool.size
                (0 until pool.size).map { i -> pool[(start + i) % pool.size] }
            }
            LoadBalanceMode.ADAPTIVE_LATENCY -> {
                pool.sortedWith(compareBy<ServerEndpointEntity> { !it.isHealthy }
                    .thenBy { if (it.lastLatencyMs > 0) it.lastLatencyMs else 9999 }
                    .thenByDescending { it.weight })
            }
            LoadBalanceMode.FAILOVER -> {
                pool.sortedWith(compareByDescending<ServerEndpointEntity> { it.isHealthy }
                    .thenByDescending { it.weight }
                    .thenBy { if (it.lastLatencyMs > 0) it.lastLatencyMs else 9999 })
            }
        }
    }

    suspend fun relayHttpViaGasPool(
        targetUrl: String,
        method: String = "GET",
        headers: Map<String, String> = emptyMap(),
        bodyBytes: ByteArray? = null
    ): GasRelayResponse = withContext(Dispatchers.IO) {
        val candidates = selectOrderedCandidates(EndpointType.GAS_SCRIPT)
        if (candidates.isEmpty()) {
            TunnelLogger.w(LogCategory.GAS, "RELAY-SKIP", "هیچ اسکریپت گوگل فعالی برای رله وجود ندارد")
            return@withContext GasRelayResponse(false, 503, ByteArray(0), "هیچ اسکریپت فعالی انتخاب نشده است")
        }

        val settings = currentSettings
        var lastErr = "خطا در تمام اسکریپت‌های موازی"
        for (node in candidates) {
            totalRequests.incrementAndGet()
            val t0 = System.nanoTime()
            val cleanIp = node.customCleanIp.ifBlank { settings.activeCleanGoogleIp }.trim()
            try {
                val innerJson = JSONObject().apply {
                    put("action", "relay")
                    put("url", targetUrl)
                    put("method", method)
                    put("headers", JSONObject(headers))
                    if (bodyBytes != null && bodyBytes.isNotEmpty()) {
                        put("bodyB64", Base64.encodeToString(bodyBytes, Base64.NO_WRAP))
                    }
                    if (settings.randomPadding) {
                        put("pad", TunnelCrypto.randomPaddingString())
                    }
                }.toString().toByteArray(Charsets.UTF_8)

                val compLevel = if (settings.compressionLevel == CompressionLevel.OFF) CompressionLevel.OFF else CompressionLevel.ULTRA_GZIP
                val compressed = TunnelCrypto.compress(innerJson, compLevel)
                val encryptedBytes = TunnelCrypto.encryptStreamHmac(compressed.bytes, node.secretKey)

                val envelope = JSONObject().apply {
                    put("enc", true)
                    put("comp", if (compLevel == CompressionLevel.ULTRA_GZIP && compressed.compressedSize < compressed.rawSize) "gzip" else "none")
                    put("data", Base64.encodeToString(encryptedBytes, Base64.NO_WRAP))
                }.toString()

                val envelopeBytes = envelope.toByteArray(Charsets.UTF_8)
                recordTraffic(
                    upBytes = envelopeBytes.size.toLong(),
                    downBytes = 0L,
                    rawPayload = innerJson.size.toLong(),
                    compressedPayload = compressed.compressedSize.toLong()
                )

                val response = executeGasPostWithFallback(
                    nodeUrl = normalizeHttpUrl(node.url),
                    envelopeBytes = envelopeBytes,
                    settings = settings,
                    cleanIp = cleanIp,
                    nodeName = node.name
                )

                response.use { res ->
                    val respText = res.body?.string().orEmpty()
                    val rtt = ((System.nanoTime() - t0) / 1_000_000L).toInt().coerceAtLeast(1)
                    recordTraffic(upBytes = 0L, downBytes = respText.toByteArray().size.toLong())
                    if (!res.isSuccessful) {
                        lastErr = if (res.code == 403 || res.code == 401) {
                            build403Diagnostic(res.request.url.toString(), respText)
                        } else {
                            "HTTP ${res.code}"
                        }
                        TunnelLogger.e(
                            LogCategory.GAS,
                            "RELAY-${res.code}",
                            "خطای رله روی «${node.name}»: $lastErr",
                            "Target=$targetUrl\nFinalURL=${res.request.url}\nSnippet=${respText.take(250)}"
                        )
                        failedRequests.incrementAndGet()
                        continue
                    }
                    if (respText.trimStart().startsWith("<")) {
                        lastErr = "پاسخ HTML غیرمنتظره از گوگل (دسترسی Web App را روی Anyone بگذارید)"
                        TunnelLogger.e(
                            LogCategory.GAS,
                            "RELAY-HTML",
                            "پاسخ غیر JSON از «${node.name}»",
                            "FinalURL=${res.request.url}\nSnippet=${respText.take(250)}"
                        )
                        failedRequests.incrementAndGet()
                        continue
                    }
                    val outer = JSONObject(respText)
                    if (!outer.optBoolean("ok", false)) {
                        lastErr = outer.optString("error", "gas_error")
                        TunnelLogger.e(LogCategory.GAS, "RELAY-ERR", "خطای اسکریپت «${node.name}»: $lastErr", "Target=$targetUrl")
                        failedRequests.incrementAndGet()
                        continue
                    }
                    val respDataB64 = outer.optString("data", "")
                    var decoded = Base64.decode(respDataB64, Base64.DEFAULT)
                    if (outer.optBoolean("enc", false)) {
                        decoded = TunnelCrypto.decryptStreamHmac(decoded, node.secretKey)
                            ?: throw IllegalStateException("HMAC verification failed")
                    }
                    val rawRespSize = decoded.size
                    if (outer.optString("comp") == "gzip") {
                        decoded = TunnelCrypto.decompressGzip(decoded)
                    }
                    recordTraffic(upBytes = 0L, downBytes = 0L, rawPayload = decoded.size.toLong(), compressedPayload = rawRespSize.toLong())
                    val innerResp = JSONObject(String(decoded, Charsets.UTF_8))
                    val statusCode = innerResp.optInt("status", 200)
                    val outBody = Base64.decode(innerResp.optString("bodyB64", ""), Base64.DEFAULT)
                    updateLatencyStats(rtt)
                    TunnelLogger.i(
                        LogCategory.GAS,
                        "RELAY-OK",
                        "رله موفق از «${node.name}» (${rtt}ms • $statusCode)",
                        "Target=$targetUrl, Raw=${innerJson.size}B -> Comp=${compressed.compressedSize}B, Resp=${outBody.size}B"
                    )
                    return@withContext GasRelayResponse(true, statusCode, outBody)
                }
            } catch (e: Exception) {
                failedRequests.incrementAndGet()
                lastErr = e.localizedMessage ?: "خطای انتقال"
                TunnelLogger.e(
                    LogCategory.GAS,
                    "RELAY-EXC",
                    "استثنا در رله «${node.name}»: $lastErr",
                    "Target=$targetUrl\nCleanIP=${cleanIp.ifBlank { "system-dns" }}\nException=${e.javaClass.simpleName}: ${e.message}"
                )
            }
        }
        GasRelayResponse(false, 502, ByteArray(0), lastErr)
    }

    private fun executeGasPostWithFallback(
        nodeUrl: String,
        envelopeBytes: ByteArray,
        settings: BypassSettings,
        cleanIp: String,
        nodeName: String
    ): okhttp3.Response {
        val req = Request.Builder()
            .url(nodeUrl)
            .post(envelopeBytes.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        val client = BypassOkHttpFactory.createClient(settings = settings, overrideCleanIp = cleanIp)
        return try {
            client.newCall(req).execute()
        } catch (e: SSLPeerUnverifiedException) {
            if (cleanIp.isNotBlank()) BypassOkHttpFactory.markBadCleanIp(cleanIp)
            if (cleanIp.isBlank()) throw e
            TunnelLogger.w(
                LogCategory.GAS,
                "RELAY-FALLBACK",
                "آی‌پی تمیز ($cleanIp) خطای SSL داد؛ تلاش مجدد «$nodeName» با DNS مستقیم",
                e.localizedMessage
            )
            val fallbackClient = BypassOkHttpFactory.createClient(settings = settings, disableCleanIp = true)
            fallbackClient.newCall(req).execute()
        }
    }

    suspend fun resolveDohPacket(dnsQueryWire: ByteArray): ByteArray? = withContext(Dispatchers.IO) {
        if (dnsQueryWire.size < 12) return@withContext null
        val cacheKey = Base64.encodeToString(dnsQueryWire.copyOfRange(12, dnsQueryWire.size), Base64.NO_WRAP)
        val cached = dnsCache[cacheKey]
        if (cached != null && System.currentTimeMillis() - cached.first < 90_000L) {
            val copy = cached.second.copyOf()
            if (copy.size >= 2) {
                copy[0] = dnsQueryWire[0]
                copy[1] = dnsQueryWire[1]
            }
            return@withContext copy
        }

        val settings = currentSettings
        // 1. Try GAS DoH first whenever any GAS_SCRIPT endpoint is active (unpoisoned Google-side DNS)
        val gasNodes = selectOrderedCandidates(EndpointType.GAS_SCRIPT)
            .filter { it.endpointType == EndpointType.GAS_SCRIPT }
        for (node in gasNodes) {
            runCatching {
                val inner = JSONObject().apply {
                    put("action", "doh")
                    put("dnsB64", Base64.encodeToString(dnsQueryWire, Base64.NO_WRAP))
                }.toString().toByteArray(Charsets.UTF_8)
                val encrypted = TunnelCrypto.encryptStreamHmac(inner, node.secretKey)
                val env = JSONObject().apply {
                    put("enc", true)
                    put("comp", "none")
                    put("data", Base64.encodeToString(encrypted, Base64.NO_WRAP))
                }.toString()
                val cleanIp = node.customCleanIp.ifBlank { settings.activeCleanGoogleIp }.trim()
                executeGasPostWithFallback(
                    nodeUrl = normalizeHttpUrl(node.url),
                    envelopeBytes = env.toByteArray(Charsets.UTF_8),
                    settings = settings,
                    cleanIp = cleanIp,
                    nodeName = node.name
                ).use { res ->
                    val bodyStr = res.body?.string().orEmpty()
                    if (res.isSuccessful && !bodyStr.trimStart().startsWith("<")) {
                        val outer = JSONObject(bodyStr)
                        if (outer.optBoolean("ok", false)) {
                            var bytes = Base64.decode(outer.getString("data"), Base64.DEFAULT)
                            bytes = TunnelCrypto.decryptStreamHmac(bytes, node.secretKey) ?: return@use
                            if (outer.optString("comp") == "gzip") bytes = TunnelCrypto.decompressGzip(bytes)
                            val parsed = JSONObject(String(bytes, Charsets.UTF_8))
                            val ans = Base64.decode(parsed.getString("dnsB64"), Base64.DEFAULT)
                            if (!containsPoisonedIranIp(ans)) {
                                recordTraffic(env.length.toLong(), ans.size.toLong())
                                dnsCache[cacheKey] = System.currentTimeMillis() to ans.copyOf()
                                TunnelLogger.d(LogCategory.DNS_DOH, "DOH-GAS", "پاسخ DoH از «${node.name}» (${ans.size}B)")
                                return@withContext ans
                            }
                        } else {
                            TunnelLogger.w(LogCategory.DNS_DOH, "DOH-GAS-FAIL", "پاسخ ناموفق DoH از «${node.name}»", outer.optString("error"))
                        }
                    } else {
                        TunnelLogger.w(LogCategory.DNS_DOH, "DOH-GAS-HTTP", "خطای DoH در «${node.name}»: HTTP ${res.code}")
                    }
                }
            }.onFailure { err ->
                TunnelLogger.w(LogCategory.DNS_DOH, "DOH-GAS-ERR", "خطای DoH در «${node.name}»", err.localizedMessage)
            }
        }

        // 2. Try Direct DoH by IP (8.8.8.8 & 1.1.1.1) + settings.dohUrl with TLS Fragmentation
        val dohTargets = listOf("https://8.8.8.8/dns-query", "https://1.1.1.1/dns-query", settings.dohUrl).distinct()
        for (url in dohTargets) {
            val ans = runCatching {
                val client = BypassOkHttpFactory.createClient(
                    settings = settings,
                    connectTimeoutMs = 3_500L,
                    readTimeoutMs = 4_500L,
                    disableCleanIp = url.contains("8.8.8.8") || url.contains("1.1.1.1")
                )
                val req = Request.Builder()
                    .url(url)
                    .header("Accept", "application/dns-message")
                    .post(dnsQueryWire.toRequestBody("application/dns-message".toMediaType()))
                    .build()
                client.newCall(req).execute().use { res ->
                    if (res.isSuccessful) res.body?.bytes() else null
                }
            }.getOrNull()

            if (ans != null && ans.size >= 12 && !containsPoisonedIranIp(ans)) {
                recordTraffic(dnsQueryWire.size.toLong(), ans.size.toLong())
                dnsCache[cacheKey] = System.currentTimeMillis() to ans.copyOf()
                TunnelLogger.d(LogCategory.DNS_DOH, "DOH-IP", "پاسخ DoH از $url (${ans.size}B)")
                return@withContext ans
            }
        }

        // 3. Last resort: UDP 8.8.8.8:53 (rejecting 10.10.34.* poisoned responses)
        val udpAns = resolveUdpDnsFallback(dnsQueryWire, "8.8.8.8")
        if (udpAns != null) {
            dnsCache[cacheKey] = System.currentTimeMillis() to udpAns.copyOf()
        }
        return@withContext udpAns
    }

    private fun resolveUdpDnsFallback(dnsQueryWire: ByteArray, dnsServerIp: String): ByteArray? {
        return runCatching {
            DatagramSocket().use { sock ->
                BypassOkHttpFactory.datagramProtector?.invoke(sock)
                sock.soTimeout = 3_000
                val addr = InetAddress.getByName(dnsServerIp)
                sock.send(DatagramPacket(dnsQueryWire, dnsQueryWire.size, addr, 53))
                val buf = ByteArray(2048)
                val resp = DatagramPacket(buf, buf.size)
                sock.receive(resp)
                val ans = buf.copyOf(resp.length)
                if (containsPoisonedIranIp(ans)) {
                    TunnelLogger.w(LogCategory.DNS_DOH, "DNS-POISON", "پاسخ جعلی 10.10.34.x از $dnsServerIp مسدود شد")
                    return@runCatching null
                }
                recordTraffic(dnsQueryWire.size.toLong(), ans.size.toLong())
                TunnelLogger.d(LogCategory.DNS_DOH, "DNS-8888", "پاسخ DNS از $dnsServerIp (${ans.size}B)")
                ans
            }
        }.onFailure { err ->
            TunnelLogger.w(LogCategory.DNS_DOH, "DNS-UDP-ERR", "خطای DNS $dnsServerIp", err.localizedMessage)
        }.getOrNull()
    }

    private fun containsPoisonedIranIp(dnsWire: ByteArray): Boolean {
        // Detect 10.10.34.x (0x0A 0x0A 0x22 xx) anywhere in RDATA of A records
        for (i in 12 until dnsWire.size - 3) {
            if (dnsWire[i] == 10.toByte() && dnsWire[i + 1] == 10.toByte() && dnsWire[i + 2] == 34.toByte()) {
                return true
            }
        }
        return false
    }

    fun openWorkerWebSocket(
        endpoint: ServerEndpointEntity,
        listener: WebSocketListener
    ): WebSocket {
        val settings = currentSettings
        val wsUrl = normalizeWsUrl(endpoint.url)
        val cleanIp = endpoint.customCleanIp.ifBlank { settings.activeCleanCfIp }
        TunnelLogger.d(
            LogCategory.CF_WS,
            "WS-OPEN",
            "باز کردن WebSocket به «${endpoint.name}»",
            "URL=$wsUrl, CleanIP=${cleanIp.ifBlank { "system-dns" }}"
        )
        val client = BypassOkHttpFactory.createClient(settings, overrideCleanIp = cleanIp, connectTimeoutMs = 8_000L, readTimeoutMs = 0L)
        val req = Request.Builder()
            .url(wsUrl)
            .header("X-Tunnel-Auth", endpoint.secretKey)
            .apply {
                if (endpoint.customSniHost.isNotBlank()) {
                    header("Host", endpoint.customSniHost.trim())
                }
            }
            .build()
        return client.newWebSocket(req, listener)
    }

    private fun updateLatencyStats(newRtt: Int) {
        val prev = lastLatencyMs
        lastJitterMs = if (prev == 0) 0 else abs(newRtt - prev)
        lastLatencyMs = if (prev == 0) newRtt else ((prev * 0.7f) + (newRtt * 0.3f)).toInt()
    }

    private fun computeStabilityScore(
        latencyMs: Int,
        jitterMs: Int,
        lossPct: Float,
        activeCount: Int
    ): Float {
        if (activeCount == 0) return 0f
        val latencyPenalty = (latencyMs / 25f).coerceAtMost(30f)
        val jitterPenalty = (jitterMs / 10f).coerceAtMost(20f)
        val lossPenalty = (lossPct * 1.5f).coerceAtMost(45f)
        val redundancyBonus = ((activeCount - 1) * 3f).coerceAtMost(9f)
        return (100f - latencyPenalty - jitterPenalty - lossPenalty + redundancyBonus).coerceIn(5f, 100f)
    }

    private fun buildPoolLabel(pool: List<ServerEndpointEntity>): String {
        return when {
            pool.isEmpty() -> "بدون سرور فعال"
            pool.size == 1 -> pool.first().name
            else -> "${pool.first().name} + ${pool.size - 1} موازی"
        }
    }

    private fun normalizeHttpUrl(raw: String): String {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("wss://") -> "https://" + trimmed.removePrefix("wss://")
            trimmed.startsWith("ws://") -> "http://" + trimmed.removePrefix("ws://")
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            else -> "https://$trimmed"
        }
    }

    private fun normalizeWsUrl(raw: String): String {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("https://") -> "wss://" + trimmed.removePrefix("https://")
            trimmed.startsWith("http://") -> "ws://" + trimmed.removePrefix("http://")
            trimmed.startsWith("wss://") || trimmed.startsWith("ws://") -> trimmed
            else -> "wss://$trimmed"
        }
    }
}
