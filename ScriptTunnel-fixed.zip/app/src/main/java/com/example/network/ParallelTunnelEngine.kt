package com.example.network

import android.util.Base64
import com.example.core.crypto.TunnelCrypto
import com.example.data.local.ServerEndpointEntity
import com.example.data.model.BypassSettings
import com.example.data.model.CompressionLevel
import com.example.data.model.EndpointType
import com.example.data.model.LoadBalanceMode
import com.example.data.model.SpeedSample
import com.example.data.model.TunnelConnectionState
import com.example.data.model.TunnelProtocol
import com.example.data.model.TunnelTelemetry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

data class PingResult(
    val endpointId: Long,
    val isHealthy: Boolean,
    val latencyMs: Int,
    val message: String
)

data class GasRelayResponse(
    val ok: Boolean,
    val statusCode: Int,
    val bodyBytes: ByteArray,
    val error: String? = null
)

class ParallelTunnelEngine {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val roundRobinIndex = AtomicInteger(0)

    private val intervalDownBytes = AtomicLong(0L)
    private val intervalUpBytes = AtomicLong(0L)
    private val totalDownBytes = AtomicLong(0L)
    private val totalUpBytes = AtomicLong(0L)
    private val rawBytes = AtomicLong(0L)
    private val compressedBytes = AtomicLong(0L)
    private val totalRequests = AtomicInteger(0)
    private val failedRequests = AtomicInteger(0)
    private val activeStreams = AtomicInteger(0)

    @Volatile
    private var lastLatencyMs = 0

    @Volatile
    private var lastJitterMs = 0

    @Volatile
    private var activePool: List<ServerEndpointEntity> = emptyList()

    @Volatile
    private var currentSettings: BypassSettings = BypassSettings()

    private var telemetryJob: Job? = null

    private val _telemetry = MutableStateFlow(TunnelTelemetry())
    val telemetry: StateFlow<TunnelTelemetry> = _telemetry.asStateFlow()

    fun updatePoolAndSettings(endpoints: List<ServerEndpointEntity>, settings: BypassSettings) {
        activePool = endpoints.filter { it.isParallelActive }
        currentSettings = settings
        _telemetry.update {
            it.copy(
                activeEndpointCount = activePool.size,
                activeSocksAddress = "127.0.0.1:${settings.localSocksPort}",
                activeEndpointLabel = buildPoolLabel(activePool)
            )
        }
    }

    fun startTelemetrySession(state: TunnelConnectionState = TunnelConnectionState.CONNECTED) {
        totalDownBytes.set(0L)
        totalUpBytes.set(0L)
        rawBytes.set(0L)
        compressedBytes.set(0L)
        totalRequests.set(0)
        failedRequests.set(0)
        val startedAt = System.currentTimeMillis()
        _telemetry.update {
            it.copy(
                connectionState = state,
                connectedSinceMs = startedAt,
                lastErrorMessage = null,
                speedHistory = emptyList()
            )
        }
        telemetryJob?.cancel()
        telemetryJob = scope.launch {
            while (isActive) {
                delay(1000L)
                val downDelta = intervalDownBytes.getAndSet(0L)
                val upDelta = intervalUpBytes.getAndSet(0L)
                val downKbps = (downDelta / 1024f)
                val upKbps = (upDelta / 1024f)

                val reqCount = totalRequests.get()
                val failCount = failedRequests.get()
                val lossPct = if (reqCount == 0) 0f else (failCount * 100f) / reqCount
                val stability = computeStabilityScore(lastLatencyMs, lastJitterMs, lossPct, activePool.size)

                val sample = SpeedSample(
                    timestampMs = System.currentTimeMillis(),
                    downloadKbps = downKbps,
                    uploadKbps = upKbps,
                    stabilityPercent = stability
                )
                _telemetry.update { prev ->
                    val history = (prev.speedHistory + sample).takeLast(60)
                    prev.copy(
                        downloadKbps = downKbps,
                        uploadKbps = upKbps,
                        totalDownloadBytes = totalDownBytes.get(),
                        totalUploadBytes = totalUpBytes.get(),
                        rawBytesProcessed = rawBytes.get(),
                        compressedBytesSent = compressedBytes.get(),
                        stabilityScore = stability,
                        currentLatencyMs = lastLatencyMs,
                        jitterMs = lastJitterMs,
                        packetLossPercent = lossPct,
                        activeTcpStreams = activeStreams.get(),
                        activeEndpointCount = activePool.size,
                        activeEndpointLabel = buildPoolLabel(activePool),
                        speedHistory = history
                    )
                }
            }
        }
    }

    fun setConnectionState(state: TunnelConnectionState, errorMessage: String? = null) {
        _telemetry.update {
            it.copy(
                connectionState = state,
                lastErrorMessage = errorMessage
            )
        }
    }

    fun stopTelemetrySession() {
        telemetryJob?.cancel()
        telemetryJob = null
        _telemetry.update {
            it.copy(
                connectionState = TunnelConnectionState.DISCONNECTED,
                downloadKbps = 0f,
                uploadKbps = 0f,
                activeTcpStreams = 0,
                connectedSinceMs = 0L
            )
        }
    }

    fun recordTraffic(upBytes: Long, downBytes: Long, rawPayload: Long = 0L, compressedPayload: Long = 0L) {
        if (upBytes > 0) {
            intervalUpBytes.addAndGet(upBytes)
            totalUpBytes.addAndGet(upBytes)
        }
        if (downBytes > 0) {
            intervalDownBytes.addAndGet(downBytes)
            totalDownBytes.addAndGet(downBytes)
        }
        if (rawPayload > 0) {
            rawBytes.addAndGet(rawPayload)
            compressedBytes.addAndGet(if (compressedPayload > 0) compressedPayload else rawPayload)
        }
    }

    fun incrementStreams() = activeStreams.incrementAndGet()
    fun decrementStreams() = activeStreams.updateAndGet { (it - 1).coerceAtLeast(0) }

    suspend fun pingEndpoint(
        endpoint: ServerEndpointEntity,
        settings: BypassSettings
    ): PingResult = withContext(Dispatchers.IO) {
        val cleanIp = endpoint.customCleanIp.ifBlank {
            if (endpoint.endpointType == EndpointType.CF_WORKER_WS) settings.activeCleanCfIp
            else settings.activeCleanGoogleIp
        }
        val client = BypassOkHttpFactory.createClient(settings, overrideCleanIp = cleanIp, connectTimeoutMs = 6_000L, readTimeoutMs = 8_000L)
        val normalizedUrl = normalizeHttpUrl(endpoint.url)
        val pingUrl = when (endpoint.endpointType) {
            EndpointType.CF_WORKER_WS -> {
                val base = normalizedUrl.trimEnd('/')
                "$base/ping"
            }
            else -> {
                val sep = if (normalizedUrl.contains("?")) "&" else "?"
                "${normalizedUrl}${sep}ping=1&token=${endpoint.secretKey}"
            }
        }

        val req = Request.Builder()
            .url(pingUrl)
            .get()
            .apply {
                if (endpoint.customSniHost.isNotBlank()) {
                    header("Host", endpoint.customSniHost)
                }
            }
            .build()

        val t0 = System.nanoTime()
        return@withContext try {
            client.newCall(req).execute().use { res ->
                val rtt = ((System.nanoTime() - t0) / 1_000_000L).toInt().coerceAtLeast(1)
                val body = res.body?.string().orEmpty()
                val ok = res.isSuccessful && (body.contains("\"ok\":true") || body.contains("ScriptTunnel") || res.code in 200..299)
                if (ok) {
                    updateLatencyStats(rtt)
                    PingResult(endpoint.id, true, rtt, "پینگ موفق (${rtt}ms)")
                } else {
                    PingResult(endpoint.id, false, -1, "کد خطا: ${res.code}")
                }
            }
        } catch (e: Exception) {
            PingResult(endpoint.id, false, -1, e.localizedMessage ?: "خطای شبکه")
        }
    }

    fun selectOrderedCandidates(preferredType: EndpointType? = null): List<ServerEndpointEntity> {
        val pool = if (preferredType != null) {
            val matching = activePool.filter { it.endpointType == preferredType }
            matching.ifEmpty { activePool }
        } else {
            activePool
        }
        if (pool.isEmpty()) return emptyList()

        return when (currentSettings.loadBalanceMode) {
            LoadBalanceMode.PARALLEL_ROUND_ROBIN -> {
                val start = abs(roundRobinIndex.getAndIncrement()) % pool.size
                (0 until pool.size).map { i -> pool[(start + i) % pool.size] }
            }
            LoadBalanceMode.ADAPTIVE_LATENCY -> {
                pool.sortedWith(compareBy<ServerEndpointEntity> { !it.isHealthy }
                    .thenBy { if (it.lastLatencyMs > 0) it.lastLatencyMs else 9999 }
                    .thenByDescending { it.weight })
            }
            LoadBalanceMode.FAILOVER -> {
                pool.sortedWith(compareByDescending<ServerEndpointEntity> { it.isHealthy }
                    .thenByDescending { it.weight }
                    .thenBy { if (it.lastLatencyMs > 0) it.lastLatencyMs else 9999 })
            }
        }
    }

    suspend fun relayHttpViaGasPool(
        targetUrl: String,
        method: String = "GET",
        headers: Map<String, String> = emptyMap(),
        bodyBytes: ByteArray? = null
    ): GasRelayResponse = withContext(Dispatchers.IO) {
        val candidates = selectOrderedCandidates(EndpointType.GAS_SCRIPT)
        if (candidates.isEmpty()) {
            return@withContext GasRelayResponse(false, 503, ByteArray(0), "هیچ اسکریپت فعالی انتخاب نشده است")
        }

        val settings = currentSettings
        var lastErr = "خطا در تمام اسکریپت‌های موازی"
        for (node in candidates) {
            totalRequests.incrementAndGet()
            val t0 = System.nanoTime()
            try {
                val innerJson = JSONObject().apply {
                    put("action", "relay")
                    put("url", targetUrl)
                    put("method", method)
                    put("headers", JSONObject(headers))
                    if (bodyBytes != null && bodyBytes.isNotEmpty()) {
                        put("bodyB64", Base64.encodeToString(bodyBytes, Base64.NO_WRAP))
                    }
                    if (settings.randomPadding) {
                        put("pad", TunnelCrypto.randomPaddingString())
                    }
                }.toString().toByteArray(Charsets.UTF_8)

                val compLevel = if (settings.compressionLevel == CompressionLevel.OFF) CompressionLevel.OFF else CompressionLevel.ULTRA_GZIP
                val compressed = TunnelCrypto.compress(innerJson, compLevel)
                // Always encrypt for GAS: the script accepts enc=true in every mode,
                // while plaintext is rejected when the script enforces encryption.
                val encryptedBytes = TunnelCrypto.encryptStreamHmac(compressed.bytes, node.secretKey)

                val envelope = JSONObject().apply {
                    put("enc", true)
                    put("comp", if (compLevel == CompressionLevel.ULTRA_GZIP && compressed.compressedSize < compressed.rawSize) "gzip" else "none")
                    put("data", Base64.encodeToString(encryptedBytes, Base64.NO_WRAP))
                }.toString()

                val envelopeBytes = envelope.toByteArray(Charsets.UTF_8)
                recordTraffic(
                    upBytes = envelopeBytes.size.toLong(),
                    downBytes = 0L,
                    rawPayload = innerJson.size.toLong(),
                    compressedPayload = compressed.compressedSize.toLong()
                )

                val client = BypassOkHttpFactory.createClient(
                    settings = settings,
                    overrideCleanIp = node.customCleanIp.ifBlank { settings.activeCleanGoogleIp }
                )
                val req = Request.Builder()
                    .url(normalizeHttpUrl(node.url))
                    .post(envelopeBytes.toRequestBody("application/json; charset=utf-8".toMediaType()))
                    .build()

                client.newCall(req).execute().use { res ->
                    val respText = res.body?.string().orEmpty()
                    val rtt = ((System.nanoTime() - t0) / 1_000_000L).toInt().coerceAtLeast(1)
                    recordTraffic(upBytes = 0L, downBytes = respText.toByteArray().size.toLong())
                    if (!res.isSuccessful) {
                        lastErr = "HTTP ${res.code}"
                        failedRequests.incrementAndGet()
                        continue
                    }
                    val outer = JSONObject(respText)
                    if (!outer.optBoolean("ok", false)) {
                        lastErr = outer.optString("error", "gas_error")
                        failedRequests.incrementAndGet()
                        continue
                    }
                    val respDataB64 = outer.optString("data", "")
                    var decoded = Base64.decode(respDataB64, Base64.DEFAULT)
                    if (outer.optBoolean("enc", false)) {
                        decoded = TunnelCrypto.decryptStreamHmac(decoded, node.secretKey)
                            ?: throw IllegalStateException("HMAC verification failed")
                    }
                    val rawRespSize = decoded.size
                    if (outer.optString("comp") == "gzip") {
                        decoded = TunnelCrypto.decompressGzip(decoded)
                    }
                    recordTraffic(upBytes = 0L, downBytes = 0L, rawPayload = decoded.size.toLong(), compressedPayload = rawRespSize.toLong())
                    val innerResp = JSONObject(String(decoded, Charsets.UTF_8))
                    val statusCode = innerResp.optInt("status", 200)
                    val outBody = Base64.decode(innerResp.optString("bodyB64", ""), Base64.DEFAULT)
                    updateLatencyStats(rtt)
                    return@withContext GasRelayResponse(true, statusCode, outBody)
                }
            } catch (e: Exception) {
                failedRequests.incrementAndGet()
                lastErr = e.localizedMessage ?: "خطای انتقال"
            }
        }
        GasRelayResponse(false, 502, ByteArray(0), lastErr)
    }

    suspend fun resolveDohPacket(dnsQueryWire: ByteArray): ByteArray? = withContext(Dispatchers.IO) {
        val settings = currentSettings
        // If GAS script exists and protocol is GAS_PARALLEL or HYBRID_SMART, try GAS DoH first or direct DoH via Clean IP
        if (settings.protocol == TunnelProtocol.GAS_PARALLEL) {
            val gasNodes = selectOrderedCandidates(EndpointType.GAS_SCRIPT)
            for (node in gasNodes) {
                runCatching {
                    val inner = JSONObject().apply {
                        put("action", "doh")
                        put("dnsB64", Base64.encodeToString(dnsQueryWire, Base64.NO_WRAP))
                    }.toString().toByteArray(Charsets.UTF_8)
                    val encrypted = TunnelCrypto.encryptStreamHmac(inner, node.secretKey)
                    val env = JSONObject().apply {
                        put("enc", true)
                        put("comp", "none")
                        put("data", Base64.encodeToString(encrypted, Base64.NO_WRAP))
                    }.toString()
                    val client = BypassOkHttpFactory.createClient(settings, overrideCleanIp = node.customCleanIp.ifBlank { settings.activeCleanGoogleIp })
                    val req = Request.Builder()
                        .url(normalizeHttpUrl(node.url))
                        .post(env.toRequestBody("application/json".toMediaType()))
                        .build()
                    client.newCall(req).execute().use { res ->
                        if (res.isSuccessful) {
                            val outer = JSONObject(res.body?.string().orEmpty())
                            if (outer.optBoolean("ok", false)) {
                                var bytes = Base64.decode(outer.getString("data"), Base64.DEFAULT)
                                bytes = TunnelCrypto.decryptStreamHmac(bytes, node.secretKey) ?: return@use
                                if (outer.optString("comp") == "gzip") bytes = TunnelCrypto.decompressGzip(bytes)
                                val parsed = JSONObject(String(bytes, Charsets.UTF_8))
                                val ans = Base64.decode(parsed.getString("dnsB64"), Base64.DEFAULT)
                                recordTraffic(env.length.toLong(), ans.size.toLong())
                                return@withContext ans
                            }
                        }
                    }
                }
            }
        }

        // Direct DoH through Clean Google/CF IP + TLS Fragmentation
        return@withContext runCatching {
            val client = BypassOkHttpFactory.createClient(settings)
            val req = Request.Builder()
                .url(settings.dohUrl)
                .header("Accept", "application/dns-message")
                .post(dnsQueryWire.toRequestBody("application/dns-message".toMediaType()))
                .build()
            client.newCall(req).execute().use { res ->
                if (res.isSuccessful) {
                    val ans = res.body?.bytes()
                    if (ans != null) recordTraffic(dnsQueryWire.size.toLong(), ans.size.toLong())
                    ans
                } else null
            }
        }.getOrNull()
    }

    fun openWorkerWebSocket(
        endpoint: ServerEndpointEntity,
        listener: WebSocketListener
    ): WebSocket {
        val settings = currentSettings
        val wsUrl = normalizeWsUrl(endpoint.url)
        val cleanIp = endpoint.customCleanIp.ifBlank { settings.activeCleanCfIp }
        val client = BypassOkHttpFactory.createClient(settings, overrideCleanIp = cleanIp, connectTimeoutMs = 8_000L, readTimeoutMs = 0L)
        val req = Request.Builder()
            .url(wsUrl)
            .header("X-Tunnel-Auth", endpoint.secretKey)
            .apply {
                if (endpoint.customSniHost.isNotBlank()) {
                    header("Host", endpoint.customSniHost)
                }
            }
            .build()
        return client.newWebSocket(req, listener)
    }

    private fun updateLatencyStats(newRtt: Int) {
        val prev = lastLatencyMs
        lastJitterMs = if (prev == 0) 0 else abs(newRtt - prev)
        lastLatencyMs = if (prev == 0) newRtt else ((prev * 0.7f) + (newRtt * 0.3f)).toInt()
    }

    private fun computeStabilityScore(
        latencyMs: Int,
        jitterMs: Int,
        lossPct: Float,
        activeCount: Int
    ): Float {
        if (activeCount == 0) return 0f
        val latencyPenalty = (latencyMs / 25f).coerceAtMost(30f)
        val jitterPenalty = (jitterMs / 10f).coerceAtMost(20f)
        val lossPenalty = (lossPct * 1.5f).coerceAtMost(45f)
        val redundancyBonus = ((activeCount - 1) * 3f).coerceAtMost(9f)
        return (100f - latencyPenalty - jitterPenalty - lossPenalty + redundancyBonus).coerceIn(5f, 100f)
    }

    private fun buildPoolLabel(pool: List<ServerEndpointEntity>): String {
        return when {
            pool.isEmpty() -> "بدون سرور فعال"
            pool.size == 1 -> pool.first().name
            else -> "${pool.first().name} + ${pool.size - 1} موازی"
        }
    }

    private fun normalizeHttpUrl(raw: String): String {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("wss://") -> "https://" + trimmed.removePrefix("wss://")
            trimmed.startsWith("ws://") -> "http://" + trimmed.removePrefix("ws://")
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            else -> "https://$trimmed"
        }
    }

    private fun normalizeWsUrl(raw: String): String {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("https://") -> "wss://" + trimmed.removePrefix("https://")
            trimmed.startsWith("http://") -> "ws://" + trimmed.removePrefix("http://")
            trimmed.startsWith("wss://") || trimmed.startsWith("ws://") -> trimmed
            else -> "wss://$trimmed"
        }
    }
}
