package com.example.network

import com.example.data.local.CleanIpEntity
import com.example.data.model.IpProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLParameters
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.math.abs
import kotlin.random.Random

data class ScanProgress(
    val isScanning: Boolean = false,
    val scannedCount: Int = 0,
    val totalCount: Int = 0,
    val foundCount: Int = 0,
    val provider: IpProvider = IpProvider.GOOGLE
)

object CleanIpScanner {

    private val googleCidrPrefixes = listOf(
        "142.250.184", "142.250.185", "142.250.186", "142.250.72", "142.250.74",
        "172.217.16", "172.217.18", "172.217.22", "172.217.168",
        "216.58.208", "216.58.210", "216.58.212",
        "108.177.14", "108.177.15", "74.125.133", "74.125.206"
    )

    private val cloudflareCidrPrefixes = listOf(
        "104.16.120", "104.16.132", "104.17.64", "104.18.10", "104.19.20",
        "104.21.48", "104.22.12", "104.24.100", "104.26.10",
        "172.64.140", "172.67.150", "172.67.180",
        "162.159.135", "162.159.138", "188.114.96", "188.114.97"
    )

    fun generateCandidates(
        provider: IpProvider,
        customPrefix: String = "",
        sampleCount: Int = 40
    ): List<String> {
        val prefixes = if (customPrefix.isNotBlank()) {
            listOf(customPrefix.trim().trimEnd('.'))
        } else {
            when (provider) {
                IpProvider.GOOGLE -> googleCidrPrefixes
                IpProvider.CLOUDFLARE -> cloudflareCidrPrefixes
            }
        }
        val candidates = LinkedHashSet<String>()
        var attempts = 0
        while (candidates.size < sampleCount && attempts < sampleCount * 4) {
            attempts++
            val prefix = prefixes[attempts % prefixes.size]
            val parts = prefix.split('.')
            val ip = when (parts.size) {
                3 -> "$prefix.${Random.nextInt(1, 254)}"
                2 -> "$prefix.${Random.nextInt(1, 254)}.${Random.nextInt(1, 254)}"
                4 -> prefix
                else -> "$prefix.${Random.nextInt(1, 254)}"
            }
            candidates.add(ip)
        }
        return candidates.toList()
    }

    suspend fun scanCleanIps(
        provider: IpProvider,
        customPrefix: String = "",
        sampleCount: Int = 36,
        onProgress: (ScanProgress) -> Unit
    ): List<CleanIpEntity> = withContext(Dispatchers.IO) {
        val candidates = generateCandidates(provider, customPrefix, sampleCount)
        val total = candidates.size
        val semaphore = Semaphore(10)
        var scanned = 0
        val found = mutableListOf<CleanIpEntity>()
        val sniHost = when (provider) {
            IpProvider.GOOGLE -> "script.google.com"
            IpProvider.CLOUDFLARE -> "cloudflare.com"
        }

        onProgress(ScanProgress(isScanning = true, scannedCount = 0, totalCount = total, foundCount = 0, provider = provider))

        coroutineScope {
            candidates.map { ip ->
                async {
                    semaphore.withPermit {
                        val result = probeIpWithTls(ip, sniHost, provider)
                        synchronized(found) {
                            scanned++
                            if (result != null) found.add(result)
                            onProgress(
                                ScanProgress(
                                    isScanning = true,
                                    scannedCount = scanned,
                                    totalCount = total,
                                    foundCount = found.size,
                                    provider = provider
                                )
                            )
                        }
                        result
                    }
                }
            }.awaitAll()
        }

        val sorted = found.sortedBy { it.latencyMs }
        onProgress(
            ScanProgress(
                isScanning = false,
                scannedCount = total,
                totalCount = total,
                foundCount = sorted.size,
                provider = provider
            )
        )
        sorted
    }

    private fun probeIpWithTls(
        ip: String,
        sniHost: String,
        provider: IpProvider
    ): CleanIpEntity? {
        val rtts = mutableListOf<Int>()
        var tlsVerified = false
        repeat(2) { attempt ->
            val sock = Socket()
            try {
                BypassOkHttpFactory.socketProtector?.invoke(sock)
                val t0 = System.nanoTime()
                sock.connect(InetSocketAddress(ip, 443), 1600)
                val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
                val ssl = sslFactory.createSocket(sock, sniHost, 443, true) as SSLSocket
                ssl.soTimeout = 1800
                val params: SSLParameters = ssl.sslParameters
                params.serverNames = listOf(SNIHostName(sniHost))
                ssl.sslParameters = params
                ssl.startHandshake()
                val elapsedMs = ((System.nanoTime() - t0) / 1_000_000L).toInt().coerceAtLeast(1)
                rtts.add(elapsedMs)
                tlsVerified = true
                ssl.close()
            } catch (_: Exception) {
                runCatching { sock.close() }
                if (attempt == 0) return null
            }
        }
        if (rtts.isEmpty()) return null
        val avg = rtts.average().toInt()
        val jitter = if (rtts.size >= 2) abs(rtts[0] - rtts[1]) else 0
        return CleanIpEntity(
            ip = ip,
            provider = provider.name,
            latencyMs = avg,
            jitterMs = jitter,
            tlsVerified = tlsVerified,
            isSelected = false,
            lastTestedMs = System.currentTimeMillis()
        )
    }
}
