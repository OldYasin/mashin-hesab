package com.example.network

import com.example.data.model.BypassSettings
import okhttp3.Dns
import okhttp3.OkHttpClient
import java.io.FilterOutputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit
import javax.net.SocketFactory
import kotlin.random.Random

object BypassOkHttpFactory {

    @Volatile
    var socketProtector: ((Socket) -> Boolean)? = null

    fun createClient(
        settings: BypassSettings,
        overrideCleanIp: String = "",
        connectTimeoutMs: Long = 8_000L,
        readTimeoutMs: Long = 20_000L
    ): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(connectTimeoutMs, TimeUnit.MILLISECONDS)
            .readTimeout(readTimeoutMs, TimeUnit.MILLISECONDS)
            .writeTimeout(15_000L, TimeUnit.MILLISECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)

        if (settings.adaptiveKeepAlive) {
            builder.pingInterval(20, TimeUnit.SECONDS)
        }

        val customDns = createBypassDns(settings, overrideCleanIp)
        builder.dns(customDns)

        val fragmentEnabled = settings.tlsFragmentation
        builder.socketFactory(BypassSocketFactory(fragmentEnabled))

        return builder.build()
    }

    private fun createBypassDns(settings: BypassSettings, overrideCleanIp: String): Dns {
        return object : Dns {
            override fun lookup(hostname: String): List<InetAddress> {
                val cleanIp = when {
                    overrideCleanIp.isNotBlank() -> overrideCleanIp.trim()
                    !settings.cleanIpBinding -> ""
                    hostname.contains("google", ignoreCase = true) ||
                        hostname.contains("gstatic", ignoreCase = true) -> settings.activeCleanGoogleIp.trim()
                    else -> settings.activeCleanCfIp.trim()
                }

                if (cleanIp.isNotBlank()) {
                    val parsed = runCatching { InetAddress.getByName(cleanIp) }.getOrNull()
                    if (parsed != null) {
                        return listOf(parsed)
                    }
                }
                return Dns.SYSTEM.lookup(hostname)
            }
        }
    }

    private class BypassSocketFactory(
        private val fragmentFirstWrite: Boolean
    ) : SocketFactory() {

        override fun createSocket(): Socket {
            return ProtectedFragmentSocket(fragmentFirstWrite)
        }

        override fun createSocket(host: String?, port: Int): Socket {
            return ProtectedFragmentSocket(fragmentFirstWrite).apply {
                connect(InetSocketAddress(host, port))
            }
        }

        override fun createSocket(host: String?, port: Int, localHost: InetAddress?, localPort: Int): Socket {
            return ProtectedFragmentSocket(fragmentFirstWrite).apply {
                bind(InetSocketAddress(localHost, localPort))
                connect(InetSocketAddress(host, port))
            }
        }

        override fun createSocket(host: InetAddress?, port: Int): Socket {
            return ProtectedFragmentSocket(fragmentFirstWrite).apply {
                connect(InetSocketAddress(host, port))
            }
        }

        override fun createSocket(address: InetAddress?, port: Int, localAddress: InetAddress?, localPort: Int): Socket {
            return ProtectedFragmentSocket(fragmentFirstWrite).apply {
                bind(InetSocketAddress(localAddress, localPort))
                connect(InetSocketAddress(address, port))
            }
        }
    }

    private class ProtectedFragmentSocket(
        private val fragmentFirstWrite: Boolean
    ) : Socket() {

        @Volatile
        private var firstWriteDone = false

        override fun connect(endpoint: java.net.SocketAddress?, timeout: Int) {
            socketProtector?.invoke(this)
            super.connect(endpoint, timeout)
            runCatching { tcpNoDelay = true }
        }

        override fun getOutputStream(): OutputStream {
            val raw = super.getOutputStream()
            if (!fragmentFirstWrite) return raw
            return object : FilterOutputStream(raw) {
                override fun write(b: ByteArray, off: Int, len: Int) {
                    if (!firstWriteDone && len > 32) {
                        firstWriteDone = true
                        var cursor = off
                        val end = off + len
                        while (cursor < end) {
                            val chunk = Random.nextInt(14, 34).coerceAtMost(end - cursor)
                            out.write(b, cursor, chunk)
                            out.flush()
                            cursor += chunk
                            if (cursor < end) {
                                runCatching { Thread.sleep(2L) }
                            }
                        }
                    } else {
                        out.write(b, off, len)
                    }
                }
            }
        }
    }
}
