package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.ConnectionReportEntity
import com.example.data.local.PendingSyncTaskEntity
import com.example.data.model.NetworkSyncStatus
import com.example.data.model.SyncStatus
import com.example.ui.components.AppIcons
import com.example.ui.components.formatBytesHuman
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.RoseError
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReportsScreen(
    reports: List<ConnectionReportEntity>,
    pendingTasks: List<PendingSyncTaskEntity>,
    syncStatus: NetworkSyncStatus,
    onManualSync: () -> Unit,
    onClearReports: () -> Unit,
    modifier: Modifier = Modifier
) {
    val avgStability = if (reports.isEmpty()) 100f else reports.map { it.stabilityScore }.average().toFloat()
    val totalSaved = reports.sumOf { it.compressionSavedBytes }
    val totalTraffic = reports.sumOf { it.downloadBytes + it.uploadBytes }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Summary KPI Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ReportKpiCard(
                    title = "میانگین پایداری",
                    value = "${avgStability.toInt()}%",
                    accent = EmeraldPrimary,
                    modifier = Modifier.weight(1f)
                )
                ReportKpiCard(
                    title = "صرفه‌جویی فشرده‌سازی",
                    value = formatBytesHuman(totalSaved),
                    accent = CyanSecondary,
                    modifier = Modifier.weight(1f)
                )
                ReportKpiCard(
                    title = "کل ترافیک",
                    value = formatBytesHuman(totalTraffic),
                    accent = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Graphical Session Stability History
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "نمودار پایداری جلسات اخیر",
                        style = MaterialTheme.typography.titleMedium
                    )
                    if (reports.isEmpty()) {
                        Text(
                            text = "هنوز گزارشی ثبت نشده است؛ پس از قطع هر اتصال، گزارش دقیق پایداری در دیتابیس محلی ذخیره می‌شود.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        val recent = reports.take(12).reversed()
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(110.dp)
                        ) {
                            val barCount = recent.size.coerceAtLeast(1)
                            val gap = 8.dp.toPx()
                            val barWidth = ((size.width - gap * (barCount - 1)) / barCount).coerceAtLeast(6f)
                            recent.forEachIndexed { idx, rep ->
                                val frac = (rep.stabilityScore / 100f).coerceIn(0.08f, 1f)
                                val barH = size.height * frac
                                val x = idx * (barWidth + gap)
                                val color = when {
                                    rep.stabilityScore >= 80f -> EmeraldPrimary
                                    rep.stabilityScore >= 55f -> AmberWarning
                                    else -> RoseError
                                }
                                drawRoundRect(
                                    color = color,
                                    topLeft = Offset(x, size.height - barH),
                                    size = Size(barWidth, barH),
                                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                                )
                            }
                        }
                    }
                }
            }
        }

        // Offline DB & Auto-Sync Engine Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (syncStatus.isOnline) AppIcons.CloudDone else AppIcons.CloudOff,
                                contentDescription = null,
                                tint = if (syncStatus.isOnline) EmeraldPrimary else AmberWarning
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "دیتابیس آفلاین و همگام‌سازی خودکار",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = syncStatus.lastSyncSummary,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "عملیات در صف انتظار: ${pendingTasks.size} مورد",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Button(
                            onClick = onManualSync,
                            enabled = !syncStatus.isSyncing,
                            modifier = Modifier.testTag("manual_sync_button")
                        ) {
                            Icon(AppIcons.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (syncStatus.isSyncing) "در حال همگام‌سازی" else "همگام‌سازی فوری")
                        }
                    }

                    if (pendingTasks.isNotEmpty()) {
                        pendingTasks.take(4).forEach { task ->
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = when (task.taskType) {
                                            "VERIFY_ENDPOINT" -> "تایید سلامت سرور آفلاین #${task.targetId}"
                                            "SYNC_REPORT" -> "همگام‌سازی گزارش جلسه #${task.targetId}"
                                            else -> task.taskType
                                        },
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                    Text(
                                        text = "تلاش: ${task.retryCount}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = AmberWarning
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Session Logs Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(AppIcons.Assessment, contentDescription = null, tint = CyanSecondary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "گزارش دقیق جلسات (${reports.size})",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
                if (reports.isNotEmpty()) {
                    IconButton(onClick = onClearReports) {
                        Icon(AppIcons.Delete, contentDescription = "پاک کردن تاریخچه گزارش‌ها", tint = RoseError)
                    }
                }
            }
        }

        items(reports, key = { it.id }) { report ->
            val scoreColor = when {
                report.stabilityScore >= 80f -> EmeraldPrimary
                report.stabilityScore >= 55f -> AmberWarning
                else -> RoseError
            }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${report.protocolName} • ${report.endpointSummary}",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f)
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = scoreColor.copy(alpha = 0.16f)
                        ) {
                            Text(
                                text = "پایداری ${report.stabilityScore.toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                color = scoreColor,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Text(
                        text = "${formatTimestamp(report.startedAtMs)} • ${report.notes}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "پینگ: ${report.avgLatencyMs}ms • نوسان: ${report.jitterMs}ms",
                            style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily)
                        )
                        Text(
                            text = if (report.syncStatusEnum == SyncStatus.SYNCED) "همگام‌سازی شده" else "در انتظار شبکه",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (report.syncStatusEnum == SyncStatus.SYNCED) EmeraldPrimary else AmberWarning
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "↓ ${formatBytesHuman(report.downloadBytes)}  ↑ ${formatBytesHuman(report.uploadBytes)}",
                            style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = CyanSecondary
                        )
                        Text(
                            text = "صرفه‌جویی: ${formatBytesHuman(report.compressionSavedBytes)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportKpiCard(
    title: String,
    value: String,
    accent: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }
    }
}

private fun formatTimestamp(ms: Long): String {
    return SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(ms))
}
