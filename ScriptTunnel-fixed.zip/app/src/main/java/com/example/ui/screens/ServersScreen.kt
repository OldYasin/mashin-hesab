package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.core.scripts.ScriptTemplates
import com.example.data.local.CleanIpEntity
import com.example.data.local.ServerEndpointEntity
import com.example.data.model.BypassSettings
import com.example.data.model.EndpointType
import com.example.data.model.IpProvider
import com.example.data.model.LoadBalanceMode
import com.example.data.model.SyncStatus
import com.example.network.ScanProgress
import com.example.ui.components.AppIcons
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.RoseError

@Composable
fun ServersScreen(
    servers: List<ServerEndpointEntity>,
    cleanIps: List<CleanIpEntity>,
    settings: BypassSettings,
    defaultSecret: String,
    scanProgress: ScanProgress,
    isTestingPool: Boolean,
    onLoadBalanceChange: (LoadBalanceMode) -> Unit,
    onAddOrUpdateServer: (Long, String, String, String, EndpointType, String, String, Int) -> Unit,
    onImportConfig: (String) -> Unit,
    onToggleParallel: (ServerEndpointEntity) -> Unit,
    onPingServer: (ServerEndpointEntity) -> Unit,
    onTestAllServers: () -> Unit,
    onDeleteServer: (Long) -> Unit,
    onStartCleanIpScan: (IpProvider, String) -> Unit,
    onStopCleanIpScan: () -> Unit,
    onApplyCleanIp: (String, IpProvider) -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var editingServer by remember { mutableStateOf<ServerEndpointEntity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var showImportDialog by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxSize()) {
        SingleChoiceSegmentedButtonRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            SegmentedButton(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                modifier = Modifier.testTag("tab_servers_pool")
            ) {
                Text("سرورهای موازی (${servers.size})")
            }
            SegmentedButton(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                modifier = Modifier.testTag("tab_clean_ip_scanner")
            ) {
                Text("اسکنر آی‌پی گوگل")
            }
        }

        if (selectedTab == 0) {
            ServersPoolContent(
                servers = servers,
                settings = settings,
                isTestingPool = isTestingPool,
                onLoadBalanceChange = onLoadBalanceChange,
                onAddClick = {
                    editingServer = null
                    showAddDialog = true
                },
                onImportClick = { showImportDialog = true },
                onTestAllClick = onTestAllServers,
                onEditServer = {
                    editingServer = it
                    showAddDialog = true
                },
                onToggleParallel = onToggleParallel,
                onPingServer = onPingServer,
                onDeleteServer = onDeleteServer,
                onShowMessage = onShowMessage
            )
        } else {
            CleanIpScannerContent(
                cleanIps = cleanIps,
                settings = settings,
                scanProgress = scanProgress,
                onStartScan = onStartCleanIpScan,
                onStopScan = onStopCleanIpScan,
                onApplyCleanIp = onApplyCleanIp
            )
        }
    }

    if (showAddDialog) {
        AddEditServerDialog(
            initial = editingServer,
            defaultSecret = defaultSecret,
            onDismiss = { showAddDialog = false },
            onSave = { id, name, url, secret, type, sni, cleanIp, weight ->
                onAddOrUpdateServer(id, name, url, secret, type, sni, cleanIp, weight)
                showAddDialog = false
            }
        )
    }

    if (showImportDialog) {
        ImportConfigDialog(
            onDismiss = { showImportDialog = false },
            onImport = { raw ->
                onImportConfig(raw)
                showImportDialog = false
            }
        )
    }
}

@Composable
private fun ServersPoolContent(
    servers: List<ServerEndpointEntity>,
    settings: BypassSettings,
    isTestingPool: Boolean,
    onLoadBalanceChange: (LoadBalanceMode) -> Unit,
    onAddClick: () -> Unit,
    onImportClick: () -> Unit,
    onTestAllClick: () -> Unit,
    onEditServer: (ServerEndpointEntity) -> Unit,
    onToggleParallel: (ServerEndpointEntity) -> Unit,
    onPingServer: (ServerEndpointEntity) -> Unit,
    onDeleteServer: (Long) -> Unit,
    onShowMessage: (String) -> Unit
) {
    val clipboard = LocalClipboardManager.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Action Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onAddClick,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("add_server_button")
                ) {
                    Icon(AppIcons.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("افزودن اسکریپت")
                }
                OutlinedButton(
                    onClick = onImportClick,
                    modifier = Modifier.testTag("import_config_button")
                ) {
                    Icon(AppIcons.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ایمپورت")
                }
                OutlinedButton(
                    onClick = onTestAllClick,
                    enabled = !isTestingPool,
                    modifier = Modifier.testTag("test_all_servers_button")
                ) {
                    Icon(AppIcons.Speed, contentDescription = null, modifier = Modifier.size(18.dp))
                }
            }
        }

        // Load Balancing Selector
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "استراتژی مصرف موازی چند اسکریپت",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LoadBalanceMode.entries.forEach { mode ->
                            FilterChip(
                                selected = settings.loadBalanceMode == mode,
                                onClick = { onLoadBalanceChange(mode) },
                                label = { Text(mode.titleFa) }
                            )
                        }
                    }
                    Text(
                        text = settings.loadBalanceMode.descFa,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (isTestingPool) {
            item {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
        }

        if (servers.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = AppIcons.ShieldOutlined,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(40.dp)
                        )
                        Text(
                            text = "هنوز اسکریپت یا ورکری اضافه نشده است",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "از تب «کد و راهنما» کد اسکریپت گوگل را کپی کرده و پس از دیپلوی، لینک آن را اینجا اضافه کنید. می‌توانید چند اسکریپت را هم‌زمان موازی مصرف کنید.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(servers, key = { it.id }) { server ->
                val badgeColor = if (server.endpointType == EndpointType.CF_WORKER_WS) CyanSecondary else EmeraldPrimary
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(
                        1.dp,
                        if (server.isParallelActive) badgeColor.copy(alpha = 0.45f)
                        else MaterialTheme.colorScheme.outline
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = badgeColor.copy(alpha = 0.16f)
                                ) {
                                    Text(
                                        text = server.endpointType.badge,
                                        style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                                        color = badgeColor,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = server.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        Text(
                                            text = server.url,
                                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                            Switch(
                                checked = server.isParallelActive,
                                onCheckedChange = { onToggleParallel(server) }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                val pingText = if (server.lastLatencyMs > 0) "${server.lastLatencyMs} ms" else "تست‌نشده"
                                val pingColor = when {
                                    server.lastLatencyMs <= 0 -> MaterialTheme.colorScheme.onSurfaceVariant
                                    server.isHealthy && server.lastLatencyMs < 350 -> EmeraldPrimary
                                    server.isHealthy -> AmberWarning
                                    else -> RoseError
                                }
                                Text(
                                    text = pingText,
                                    style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                    color = pingColor
                                )
                                Text(
                                    text = "• آپتایم ${server.uptimePercent}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "• ${server.syncStatusEnum.titleFa}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (server.syncStatusEnum == SyncStatus.SYNCED) EmeraldPrimary else AmberWarning
                                )
                            }

                            Row {
                                IconButton(onClick = { onPingServer(server) }) {
                                    Icon(AppIcons.Speed, contentDescription = "تست پینگ", modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = {
                                    clipboard.setText(AnnotatedString(ScriptTemplates.encodeShareUri(server)))
                                    onShowMessage("لینک اشتراک scriptvpn:// کپی شد")
                                }) {
                                    Icon(AppIcons.Share, contentDescription = "کپی کانفیگ اشتراک", modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { onEditServer(server) }) {
                                    Icon(AppIcons.Edit, contentDescription = "ویرایش سرور", modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { onDeleteServer(server.id) }) {
                                    Icon(AppIcons.Delete, contentDescription = "حذف سرور", tint = RoseError, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CleanIpScannerContent(
    cleanIps: List<CleanIpEntity>,
    settings: BypassSettings,
    scanProgress: ScanProgress,
    onStartScan: (IpProvider, String) -> Unit,
    onStopScan: () -> Unit,
    onApplyCleanIp: (String, IpProvider) -> Unit
) {
    var selectedProvider by remember { mutableStateOf(IpProvider.GOOGLE) }
    var customPrefix by remember { mutableStateOf("") }

    val filteredIps = remember(cleanIps, selectedProvider) {
        cleanIps.filter { it.providerEnum == selectedProvider }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "استخراج خودکار آی‌پی تمیز",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "برنامه به صورت هم‌زمان رنج‌های رسمی گوگل و کلودفلر را با هندشیک واقعی TLS SNI اسکن کرده و سریع‌ترین آی‌پی بدون فیلتر را جایگزین می‌کند.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IpProvider.entries.forEach { prov ->
                            FilterChip(
                                selected = selectedProvider == prov,
                                onClick = { selectedProvider = prov },
                                label = { Text(prov.titleFa) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = customPrefix,
                        onValueChange = { customPrefix = it },
                        label = { Text("پیشوند رنج دلخواه (اختیاری، مثلاً 142.250.185)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (scanProgress.isScanning) onStopScan()
                                else onStartScan(selectedProvider, customPrefix)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("scan_clean_ip_button")
                        ) {
                            Icon(AppIcons.Radar, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (scanProgress.isScanning) "توقف اسکن" else "شروع استخراج آی‌پی تمیز")
                        }
                    }

                    if (scanProgress.isScanning) {
                        val frac = if (scanProgress.totalCount > 0) {
                            scanProgress.scannedCount.toFloat() / scanProgress.totalCount.toFloat()
                        } else 0f
                        LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
                        Text(
                            text = "بررسی ${scanProgress.scannedCount} از ${scanProgress.totalCount} آی‌پی • یافت‌شده سالم: ${scanProgress.foundCount}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanSecondary
                        )
                    }

                    val activeIp = if (selectedProvider == IpProvider.GOOGLE) settings.activeCleanGoogleIp else settings.activeCleanCfIp
                    if (activeIp.isNotBlank()) {
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "آی‌پی فعال فعلی:",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                    Text(
                                        text = activeIp,
                                        style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        items(filteredIps, key = { it.ip }) { item ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onApplyCleanIp(item.ip, selectedProvider) },
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(
                    1.dp,
                    if (item.isSelected) EmeraldPrimary else MaterialTheme.colorScheme.outline
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(
                            imageVector = AppIcons.CheckCircle,
                            contentDescription = null,
                            tint = if (item.isSelected) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                Text(
                                    text = item.ip,
                                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Text(
                                text = "نوسان ${item.jitterMs} ms • TLS SNI تاییدشده",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "${item.latencyMs} ms",
                            style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = if (item.latencyMs < 220) EmeraldPrimary else AmberWarning
                        )
                        if (!item.isSelected) {
                            TextButton(onClick = { onApplyCleanIp(item.ip, selectedProvider) }) {
                                Text("اعمال")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddEditServerDialog(
    initial: ServerEndpointEntity?,
    defaultSecret: String,
    onDismiss: () -> Unit,
    onSave: (Long, String, String, String, EndpointType, String, String, Int) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var url by remember { mutableStateOf(initial?.url ?: "") }
    var secret by remember { mutableStateOf(initial?.secretKey ?: defaultSecret) }
    var type by remember { mutableStateOf(initial?.endpointType ?: EndpointType.GAS_SCRIPT) }
    var sni by remember { mutableStateOf(initial?.customSniHost ?: "") }
    var cleanIp by remember { mutableStateOf(initial?.customCleanIp ?: "") }
    var weightText by remember { mutableStateOf((initial?.weight ?: 1).toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "افزودن اسکریپت یا ورکر" else "ویرایش سرور") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(EndpointType.GAS_SCRIPT, EndpointType.CF_WORKER_WS).forEach { t ->
                        FilterChip(
                            selected = type == t,
                            onClick = { type = t },
                            label = { Text(t.labelFa) }
                        )
                    }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("نام دلخواه (مثلاً اسکریپت ۱)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = {
                        Text(
                            if (type == EndpointType.GAS_SCRIPT) "لینک Web App گوگل (.../exec)"
                            else "آدرس ورکر کلودفلر (wss://...workers.dev)"
                        )
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = secret,
                    onValueChange = { secret = it },
                    label = { Text("کلید امنیتی (TUNNEL_SECRET)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = cleanIp,
                    onValueChange = { cleanIp = it },
                    label = { Text("آی‌پی تمیز اختصاصی (اختیاری)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sni,
                        onValueChange = { sni = it },
                        label = { Text("SNI/Host (اختیاری)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = weightText,
                        onValueChange = { weightText = it.filter { c -> c.isDigit() } },
                        label = { Text("وزن موازی") },
                        singleLine = true,
                        modifier = Modifier.width(90.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        initial?.id ?: 0L,
                        name,
                        url,
                        secret,
                        type,
                        sni,
                        cleanIp,
                        weightText.toIntOrNull() ?: 1
                    )
                }
            ) {
                Text("ذخیره")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@Composable
private fun ImportConfigDialog(
    onDismiss: () -> Unit,
    onImport: (String) -> Unit
) {
    var raw by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("وارد کردن کانفیگ اشتراک") },
        text = {
            OutlinedTextField(
                value = raw,
                onValueChange = { raw = it },
                label = { Text("رشته scriptvpn:// یا JSON را جایگذاری کنید") },
                minLines = 3,
                maxLines = 5,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(onClick = { onImport(raw) }) { Text("افزودن") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("لغو") }
        }
    )
}
