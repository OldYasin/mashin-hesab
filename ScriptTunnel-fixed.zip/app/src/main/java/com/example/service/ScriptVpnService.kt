package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.core.AppContainer
import com.example.data.local.ConnectionReportEntity
import com.example.data.model.TunnelConnectionState
import com.example.network.BypassOkHttpFactory
import com.example.network.LocalSocks5Server
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer

class ScriptVpnService : VpnService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tunInterface: ParcelFileDescriptor? = null
    private var packetLoopJob: Job? = null
    private var notificationJob: Job? = null
    private var socksServer: LocalSocks5Server? = null

    private var sessionStartMs: Long = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_DISCONNECT) {
            stopTunnel()
            return START_NOT_STICKY
        }

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("در حال برقراری تونل امن..."))
        startTunnel()
        return START_STICKY
    }

    private fun startTunnel() {
        val container = AppContainer.get(applicationContext)
        val engine = container.tunnelEngine
        sessionStartMs = System.currentTimeMillis()
        engine.setConnectionState(TunnelConnectionState.CONNECTING)

        serviceScope.launch {
            val settings = container.settingsRepository.settingsFlow.first()
            val servers = container.tunnelRepository.getAllServersOnce()
            engine.updatePoolAndSettings(servers, settings)

            BypassOkHttpFactory.socketProtector = { socket -> this@ScriptVpnService.protect(socket) }

            // Start real RFC 1928 Local SOCKS5 Server
            socksServer = LocalSocks5Server(engine).also { it.start(settings) }

            if (settings.vpnModeEnabled) {
                val established = establishTun(settings.dohEnabled)
                if (established == null) {
                    engine.setConnectionState(TunnelConnectionState.ERROR, "امکان ایجاد رابط VPN وجود نداشت")
                    stopSelf()
                    return@launch
                }
                tunInterface = established
                startTunPacketLoop(established)
            }

            engine.startTelemetrySession(TunnelConnectionState.CONNECTED)
            startNotificationUpdater()
        }
    }

    private fun establishTun(dohEnabled: Boolean): ParcelFileDescriptor? {
        return runCatching {
            val builder = Builder()
                .setSession(getString(R.string.app_name))
                .setMtu(1500)
                .addAddress("10.88.0.2", 24)
                .addRoute("0.0.0.0", 0)
                .addDnsServer(if (dohEnabled) "10.88.0.1" else "1.1.1.1")
                .addDisallowedApplication(packageName)

            builder.establish()
        }.getOrNull()
    }

    private fun startTunPacketLoop(pfd: ParcelFileDescriptor) {
        val engine = AppContainer.get(applicationContext).tunnelEngine
        packetLoopJob?.cancel()
        packetLoopJob = serviceScope.launch {
            val input = FileInputStream(pfd.fileDescriptor)
            val output = FileOutputStream(pfd.fileDescriptor)
            val packetBuf = ByteArray(32767)

            while (isActive) {
                val len = runCatching { input.read(packetBuf) }.getOrDefault(-1)
                if (len <= 0) {
                    if (len < 0) break
                    continue
                }
                val ipVersion = (packetBuf[0].toInt() ushr 4) and 0x0F
                if (ipVersion != 4 || len < 20) continue

                val ihl = (packetBuf[0].toInt() and 0x0F) * 4
                if (len < ihl) continue
                val protocol = packetBuf[9].toInt() and 0xFF

                // Intercept UDP port 53 (DNS) and resolve via DoH / GAS tunnel
                if (protocol == 17 && len >= ihl + 8) {
                    val dstPort = ((packetBuf[ihl + 2].toInt() and 0xFF) shl 8) or
                        (packetBuf[ihl + 3].toInt() and 0xFF)
                    if (dstPort == 53) {
                        val dnsQuery = packetBuf.copyOfRange(ihl + 8, len)
                        val reqCopy = packetBuf.copyOf(len)
                        launch {
                            val dnsAnswer = engine.resolveDohPacket(dnsQuery)
                            if (dnsAnswer != null) {
                                val replyPacket = buildUdpIpv4Reply(reqCopy, ihl, dnsAnswer)
                                synchronized(output) {
                                    runCatching { output.write(replyPacket) }
                                }
                            }
                        }
                    }
                } else {
                    // Record outbound packet telemetry
                    engine.recordTraffic(upBytes = len.toLong(), downBytes = 0L)
                }
            }
        }
    }

    private fun buildUdpIpv4Reply(reqPacket: ByteArray, reqIhl: Int, payload: ByteArray): ByteArray {
        val ipHeaderLen = 20
        val udpHeaderLen = 8
        val totalLen = ipHeaderLen + udpHeaderLen + payload.size
        val out = ByteArray(totalLen)

        // IPv4 Header
        out[0] = 0x45.toByte()
        out[1] = 0x00
        out[2] = ((totalLen ushr 8) and 0xFF).toByte()
        out[3] = (totalLen and 0xFF).toByte()
        out[4] = reqPacket[4]
        out[5] = reqPacket[5]
        out[6] = 0x40.toByte()
        out[7] = 0x00
        out[8] = 64.toByte() // TTL
        out[9] = 17.toByte() // UDP
        // Swap src and dst IP
        System.arraycopy(reqPacket, 16, out, 12, 4)
        System.arraycopy(reqPacket, 12, out, 16, 4)

        val ipChecksum = computeChecksum(out, 0, ipHeaderLen)
        out[10] = ((ipChecksum ushr 8) and 0xFF).toByte()
        out[11] = (ipChecksum and 0xFF).toByte()

        // UDP Header (swap ports)
        out[20] = reqPacket[reqIhl + 2]
        out[21] = reqPacket[reqIhl + 3]
        out[22] = reqPacket[reqIhl]
        out[23] = reqPacket[reqIhl + 1]
        val udpLen = udpHeaderLen + payload.size
        out[24] = ((udpLen ushr 8) and 0xFF).toByte()
        out[25] = (udpLen and 0xFF).toByte()
        out[26] = 0
        out[27] = 0

        System.arraycopy(payload, 0, out, 28, payload.size)
        return out
    }

    private fun computeChecksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + length - 1) {
            val word = ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
            sum += word
            i += 2
        }
        if (length % 2 == 1) {
            sum += (data[offset + length - 1].toInt() and 0xFF) shl 8
        }
        while ((sum ushr 16) != 0L) {
            sum = (sum and 0xFFFF) + (sum ushr 16)
        }
        return (sum.inv() and 0xFFFF).toInt()
    }

    private fun startNotificationUpdater() {
        val engine = AppContainer.get(applicationContext).tunnelEngine
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationJob?.cancel()
        notificationJob = serviceScope.launch {
            engine.telemetry.collect { t ->
                val text = "پایداری ${t.stabilityScore.toInt()}% • ↓ ${"%.1f".format(t.downloadKbps)} KB/s • ↑ ${"%.1f".format(t.uploadKbps)} KB/s"
                nm.notify(NOTIFICATION_ID, buildNotification(text))
            }
        }
    }

    private fun stopTunnel() {
        val container = AppContainer.get(applicationContext)
        val engine = container.tunnelEngine
        val t = engine.telemetry.value

        if (sessionStartMs > 0L) {
            val started = sessionStartMs
            sessionStartMs = 0L
            serviceScope.launch {
                val settings = container.settingsRepository.settingsFlow.first()
                val isOnline = container.networkSyncManager.syncStatus.value.isOnline
                val savedBytes = (t.rawBytesProcessed - t.compressedBytesSent).coerceAtLeast(0L)
                container.tunnelRepository.recordConnectionReport(
                    ConnectionReportEntity(
                        startedAtMs = started,
                        endedAtMs = System.currentTimeMillis(),
                        protocolName = settings.protocol.titleFa,
                        endpointSummary = t.activeEndpointLabel,
                        avgLatencyMs = t.currentLatencyMs,
                        jitterMs = t.jitterMs,
                        stabilityScore = t.stabilityScore,
                        packetLossPercent = t.packetLossPercent,
                        downloadBytes = t.totalDownloadBytes,
                        uploadBytes = t.totalUploadBytes,
                        compressionSavedBytes = savedBytes,
                        notes = "تعداد سرورهای موازی: ${t.activeEndpointCount}"
                    ),
                    isOnline = isOnline
                )
            }
        }

        notificationJob?.cancel()
        packetLoopJob?.cancel()
        socksServer?.stop()
        socksServer = null
        BypassOkHttpFactory.socketProtector = null
        runCatching { tunInterface?.close() }
        tunInterface = null
        engine.stopTelemetrySession()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopTunnel()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.vpn_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.vpn_channel_desc)
            }
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(contentText: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val disconnectIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, ScriptVpnService::class.java).apply { action = ACTION_DISCONNECT },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(getString(R.string.vpn_notification_title))
            .setContentText(contentText)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, getString(R.string.vpn_action_disconnect), disconnectIntent)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "script_tunnel_vpn_channel"
        const val NOTIFICATION_ID = 4102
        const val ACTION_CONNECT = "com.example.action.CONNECT"
        const val ACTION_DISCONNECT = "com.example.action.DISCONNECT"
    }
}
