package com.example.network

import com.example.core.logging.LogCategory
import com.example.core.logging.TunnelLogger
import com.example.data.local.CleanIpEntity
import com.example.data.model.IpProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLParameters
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.math.abs
import kotlin.random.Random

data class ScanProgress(
    val isScanning: Boolean = false,
    val scannedCount: Int = 0,
    val totalCount: Int = 0,
    val foundCount: Int = 0,
    val provider: IpProvider = IpProvider.GOOGLE
)

object CleanIpScanner {

    // Official Google IPv4 CIDR ranges (Google Frontend / Apps Script / Search)
    private val googleCidrs = listOf(
        "142.250.0.0/15",
        "172.217.0.0/16",
        "216.58.192.0/19",
        "172.253.0.0/16",
        "74.125.0.0/16",
        "108.177.0.0/17",
        "209.85.128.0/17",
        "64.233.160.0/19"
    )

    // Official Cloudflare IPv4 CIDR ranges
    private val cloudflareCidrs = listOf(
        "104.16.0.0/13",
        "104.24.0.0/14",
        "172.64.0.0/13",
        "162.158.0.0/15",
        "188.114.96.0/20",
        "198.41.128.0/17",
        "141.101.64.0/18",
        "108.162.192.0/18"
    )

    private val autoScanLock = Any()
    @Volatile
    private var cachedAutoGoogleIp: String? = null
    @Volatile
    private var cachedAutoGoogleIpAtMs: Long = 0L
    private const val AUTO_IP_TTL_MS = 15 * 60_000L
    private val badAutoIps = ConcurrentHashMap.newKeySet<String>()

    fun invalidateAutoGoogleIp(ip: String) {
        val trimmed = ip.trim()
        if (trimmed.isNotBlank()) badAutoIps.add(trimmed)
        if (cachedAutoGoogleIp == trimmed) {
            cachedAutoGoogleIp = null
            cachedAutoGoogleIpAtMs = 0L
        }
    }

    /**
     * Used when system DNS (and 8.8.8.8) fails during total internet blackouts:
     * runs a fast, single-flight parallel TLS+HTTP scan across Google CIDRs to find a live IP.
     */
    fun quickDiscoverGoogleIpBlocking(): String? {
        val now = System.currentTimeMillis()
        val existing = cachedAutoGoogleIp
        if (existing != null && existing !in badAutoIps && now - cachedAutoGoogleIpAtMs < AUTO_IP_TTL_MS) {
            return existing
        }
        synchronized(autoScanLock) {
            val recheck = cachedAutoGoogleIp
            val now2 = System.currentTimeMillis()
            if (recheck != null && recheck !in badAutoIps && now2 - cachedAutoGoogleIpAtMs < AUTO_IP_TTL_MS) {
                return recheck
            }
            val found = runBlocking(Dispatchers.IO) {
                scanCleanIps(
                    provider = IpProvider.GOOGLE,
                    customPrefix = "",
                    sampleCount = 28,
                    onProgress = {}
                ).firstOrNull { it.ip !in badAutoIps }
            }
            if (found != null) {
                cachedAutoGoogleIp = found.ip
                cachedAutoGoogleIpAtMs = System.currentTimeMillis()
                TunnelLogger.i(
                    LogCategory.TLS_IP,
                    "AUTO-SCAN",
                    "آی‌پی سالم گوگل با اسکن خودکار پیدا شد: ${found.ip} (${found.latencyMs}ms)"
                )
                return found.ip
            }
            return null
        }
    }

    fun generateCandidates(
        provider: IpProvider,
        customPrefix: String = "",
        sampleCount: Int = 60
    ): List<String> {
        val ranges = if (customPrefix.isNotBlank()) {
            customPrefix.split(',', ';', '\n')
                .map { it.trim() }
                .filter { it.isNotBlank() }
        } else {
            when (provider) {
                IpProvider.GOOGLE -> googleCidrs
                IpProvider.CLOUDFLARE -> cloudflareCidrs
            }
        }
        if (ranges.isEmpty()) return emptyList()

        val candidates = LinkedHashSet<String>()
        var attempts = 0
        val maxAttempts = sampleCount * 6
        while (candidates.size < sampleCount && attempts < maxAttempts) {
            val range = ranges[attempts % ranges.size]
            attempts++
            val ip = sampleIpFromRange(range)
            if (ip != null) candidates.add(ip)
        }
        return candidates.toList()
    }

    private fun sampleIpFromRange(raw: String): String? {
        val trimmed = raw.trim().trimEnd('.')
        if (trimmed.contains('/')) {
            val parts = trimmed.split('/', limit = 2)
            val baseInt = ipv4ToInt(parts[0].trim()) ?: return null
            val prefixLen = parts[1].trim().toIntOrNull()?.coerceIn(8, 32) ?: return null
            if (prefixLen == 32) return intToIpv4(baseInt)
            val hostBits = 32 - prefixLen
            val mask = (-1L shl hostBits).toInt()
            val network = baseInt and mask
            val span = 1 shl hostBits
            val offset = if (span <= 2) Random.nextInt(0, span) else Random.nextInt(1, span - 1)
            val candidateInt = network or offset
            val lastOctet = candidateInt and 0xFF
            if (lastOctet == 0 || lastOctet == 255) return null
            return intToIpv4(candidateInt)
        }
        val parts = trimmed.split('.')
        return when (parts.size) {
            4 -> trimmed
            3 -> "$trimmed.${Random.nextInt(1, 254)}"
            2 -> "$trimmed.${Random.nextInt(1, 254)}.${Random.nextInt(1, 254)}"
            1 -> "${parts[0]}.${Random.nextInt(1, 254)}.${Random.nextInt(1, 254)}.${Random.nextInt(1, 254)}"
            else -> null
        }
    }

    private fun ipv4ToInt(ip: String): Int? {
        val parts = ip.split('.')
        if (parts.size != 4) return null
        var acc = 0
        for (p in parts) {
            val oct = p.toIntOrNull() ?: return null
            if (oct < 0 || oct > 255) return null
            acc = (acc shl 8) or oct
        }
        return acc
    }

    private fun intToIpv4(value: Int): String {
        return "${(value ushr 24) and 0xFF}.${(value ushr 16) and 0xFF}.${(value ushr 8) and 0xFF}.${value and 0xFF}"
    }

    suspend fun scanCleanIps(
        provider: IpProvider,
        customPrefix: String = "",
        sampleCount: Int = 60,
        onProgress: (ScanProgress) -> Unit
    ): List<CleanIpEntity> = withContext(Dispatchers.IO) {
        val candidates = generateCandidates(provider, customPrefix, sampleCount)
        val total = candidates.size
        val semaphore = Semaphore(20)
        var scanned = 0
        val found = mutableListOf<CleanIpEntity>()
        val sniHost = when (provider) {
            IpProvider.GOOGLE -> "script.google.com"
            IpProvider.CLOUDFLARE -> "cloudflare.com"
        }

        TunnelLogger.i(
            LogCategory.TLS_IP,
            "SCAN-START",
            "شروع اسکن حرفه‌ای ${provider.titleFa} ($total کاندید)",
            "SNI=$sniHost, customPrefix=${customPrefix.ifBlank { "official-cidrs" }}"
        )

        onProgress(ScanProgress(isScanning = true, scannedCount = 0, totalCount = total, foundCount = 0, provider = provider))

        coroutineScope {
            candidates.map { ip ->
                async {
                    semaphore.withPermit {
                        val result = probeIpProfessional(ip, sniHost, provider)
                        synchronized(found) {
                            scanned++
                            if (result != null) found.add(result)
                            onProgress(
                                ScanProgress(
                                    isScanning = true,
                                    scannedCount = scanned,
                                    totalCount = total,
                                    foundCount = found.size,
                                    provider = provider
                                )
                            )
                        }
                        result
                    }
                }
            }.awaitAll()
        }

        // Rank by latency + jitter penalty so stable IPs win over spiky ones
        val sorted = found.sortedBy { it.latencyMs + (it.jitterMs / 2) }
        if (sorted.isNotEmpty()) {
            val top = sorted.first()
            TunnelLogger.i(
                LogCategory.TLS_IP,
                "SCAN-DONE",
                "اسکن ${provider.titleFa} پایان یافت: ${sorted.size} آی‌پی معتبر (بهترین: ${top.ip} با ${top.latencyMs}ms)",
                sorted.take(5).joinToString("\n") { "${it.ip} -> ${it.latencyMs}ms (jitter ${it.jitterMs}ms)" }
            )
        } else {
            TunnelLogger.w(
                LogCategory.TLS_IP,
                "SCAN-EMPTY",
                "هیچ آی‌پی تمیز معتبری برای ${provider.titleFa} در این رنج یافت نشد",
                "Total probed: $total, SNI=$sniHost"
            )
        }

        onProgress(
            ScanProgress(
                isScanning = false,
                scannedCount = total,
                totalCount = total,
                foundCount = sorted.size,
                provider = provider
            )
        )
        sorted
    }

    /**
     * 3-sample TLS + real HTTP probe:
     * 1) Sample 0 verifies TCP + TLS + SAN/CN + secondary SNI (script.googleusercontent.com) + real HTTP response.
     * 2) Samples 1 & 2 measure real HTTP-over-TLS RTT and jitter; rejects flaky IPs with <2/3 successes.
     */
    private fun probeIpProfessional(
        ip: String,
        sniHost: String,
        provider: IpProvider
    ): CleanIpEntity? {
        val rtts = mutableListOf<Int>()
        for (attempt in 0 until 3) {
            val rtt = singleHttpOverTlsProbe(
                ip = ip,
                sniHost = sniHost,
                provider = provider,
                verifySecondarySni = (attempt == 0)
            )
            if (rtt != null) {
                rtts.add(rtt)
            } else if (attempt == 0) {
                // Fail fast on first probe if TCP/TLS/HTTP fails
                return null
            }
        }
        if (rtts.size < 2) return null
        val avg = rtts.average().toInt()
        val jitter = (rtts.maxOrNull()!! - rtts.minOrNull()!!)
        return CleanIpEntity(
            ip = ip,
            provider = provider.name,
            latencyMs = avg,
            jitterMs = jitter,
            tlsVerified = true,
            isSelected = false,
            lastTestedMs = System.currentTimeMillis()
        )
    }

    private fun singleHttpOverTlsProbe(
        ip: String,
        sniHost: String,
        provider: IpProvider,
        verifySecondarySni: Boolean
    ): Int? {
        val verifier = HttpsURLConnection.getDefaultHostnameVerifier()
        val sock = Socket()
        var ssl: SSLSocket? = null
        try {
            BypassOkHttpFactory.socketProtector?.invoke(sock)
            val t0 = System.nanoTime()
            sock.connect(InetSocketAddress(ip, 443), 1500)
            val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
            ssl = sslFactory.createSocket(sock, sniHost, 443, true) as SSLSocket
            ssl.soTimeout = 1800
            val params: SSLParameters = ssl.sslParameters
            params.serverNames = listOf(SNIHostName(sniHost))
            params.endpointIdentificationAlgorithm = "HTTPS"
            ssl.sslParameters = params
            ssl.startHandshake()

            if (!verifier.verify(sniHost, ssl.session)) {
                runCatching { ssl.close() }
                return null
            }

            // Send real HTTP request over the verified TLS socket to reject dead/honeypot/throttled IPs
            val httpPath = if (provider == IpProvider.CLOUDFLARE) "/cdn-cgi/trace" else "/"
            val httpMethod = if (provider == IpProvider.CLOUDFLARE) "GET" else "HEAD"
            val reqBytes = (
                "$httpMethod $httpPath HTTP/1.1\r\n" +
                    "Host: $sniHost\r\n" +
                    "User-Agent: Mozilla/5.0\r\n" +
                    "Connection: close\r\n\r\n"
                ).toByteArray(Charsets.US_ASCII)
            val out = ssl.outputStream
            out.write(reqBytes)
            out.flush()

            val reader = BufferedReader(InputStreamReader(ssl.inputStream, Charsets.US_ASCII))
            val statusLine = reader.readLine()
            if (statusLine == null || !statusLine.startsWith("HTTP/1.")) {
                runCatching { ssl.close() }
                return null
            }
            val code = statusLine.split(' ').getOrNull(1)?.toIntOrNull() ?: 0
            if (code !in 200..499) {
                runCatching { ssl.close() }
                return null
            }
            if (provider == IpProvider.CLOUDFLARE && code != 200) {
                runCatching { ssl.close() }
                return null
            }

            val elapsedMs = ((System.nanoTime() - t0) / 1_000_000L).toInt().coerceAtLeast(1)
            runCatching { ssl.close() }

            if (verifySecondarySni && provider == IpProvider.GOOGLE) {
                if (!verifyAdditionalSni(ip, "script.googleusercontent.com")) {
                    return null
                }
            }
            return elapsedMs
        } catch (_: Exception) {
            runCatching { ssl?.close() }
            runCatching { sock.close() }
            return null
        }
    }

    private fun verifyAdditionalSni(ip: String, host: String): Boolean {
        val sock = Socket()
        var ssl: SSLSocket? = null
        return try {
            BypassOkHttpFactory.socketProtector?.invoke(sock)
            sock.connect(InetSocketAddress(ip, 443), 1400)
            val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
            ssl = sslFactory.createSocket(sock, host, 443, true) as SSLSocket
            ssl.soTimeout = 1600
            val params: SSLParameters = ssl.sslParameters
            params.serverNames = listOf(SNIHostName(host))
            params.endpointIdentificationAlgorithm = "HTTPS"
            ssl.sslParameters = params
            ssl.startHandshake()
            HttpsURLConnection.getDefaultHostnameVerifier().verify(host, ssl.session)
        } catch (_: Exception) {
            false
        } finally {
            runCatching { ssl?.close() }
            runCatching { sock.close() }
        }
    }
}
