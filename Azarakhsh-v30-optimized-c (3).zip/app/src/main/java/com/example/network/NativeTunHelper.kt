package com.example.network

/**
 * Native C (JNI) acceleration for TUN packet framing and IPv4/TCP/UDP checksums.
 * Automatically falls back to pure Kotlin if the native library is unavailable (e.g. JVM unit tests).
 */
object NativeTunHelper {
    val isNativeAvailable: Boolean = try {
        System.loadLibrary("tun_native")
        true
    } catch (_: UnsatisfiedLinkError) {
        false
    }

    private external fun nativeOnesComplementSum(
        data: ByteArray,
        offset: Int,
        length: Int,
        initial: Long
    ): Int

    private external fun nativeBuildTcpPacket(
        out: ByteArray,
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        seq: Long,
        ack: Long,
        flags: Int,
        window: Int,
        mss: Int,
        payload: ByteArray?,
        payloadOffset: Int,
        payloadLength: Int
    ): Int

    private external fun nativeBuildUdpReply(
        out: ByteArray,
        reqPacket: ByteArray,
        reqIhl: Int,
        payload: ByteArray,
        payloadLength: Int
    ): Int

    fun onesComplementSum(data: ByteArray, offset: Int, length: Int, initial: Long = 0L): Int {
        if (isNativeAvailable) {
            return nativeOnesComplementSum(data, offset, length, initial)
        }
        var sum = initial
        var i = offset
        while (i < offset + length - 1) {
            sum += ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (length % 2 == 1) {
            sum += (data[offset + length - 1].toInt() and 0xFF) shl 8
        }
        while ((sum ushr 16) != 0L) {
            sum = (sum and 0xFFFF) + (sum ushr 16)
        }
        return (sum.inv() and 0xFFFF).toInt()
    }

    fun buildTcpPacket(
        out: ByteArray,
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        seq: Long,
        ack: Long,
        flags: Int,
        window: Int,
        mss: Int = 0,
        payload: ByteArray? = null,
        payloadOffset: Int = 0,
        payloadLength: Int = 0
    ): Int {
        if (isNativeAvailable) {
            val len = nativeBuildTcpPacket(
                out, srcIp, dstIp, srcPort, dstPort, seq, ack, flags, window, mss,
                payload, payloadOffset, payloadLength
            )
            if (len > 0) return len
        }
        return buildTcpPacketKotlin(
            out, srcIp, dstIp, srcPort, dstPort, seq, ack, flags, window, mss,
            payload, payloadOffset, payloadLength
        )
    }

    fun buildUdpReply(
        out: ByteArray,
        reqPacket: ByteArray,
        reqIhl: Int,
        payload: ByteArray
    ): Int {
        if (isNativeAvailable) {
            val len = nativeBuildUdpReply(out, reqPacket, reqIhl, payload, payload.size)
            if (len > 0) return len
        }
        val totalLen = 28 + payload.size
        out.fill(0, 0, 28)
        out[0] = 0x45.toByte()
        out[2] = ((totalLen ushr 8) and 0xFF).toByte()
        out[3] = (totalLen and 0xFF).toByte()
        out[4] = reqPacket[4]
        out[5] = reqPacket[5]
        out[6] = 0x40.toByte()
        out[8] = 64.toByte()
        out[9] = 17.toByte()
        System.arraycopy(reqPacket, 16, out, 12, 4)
        System.arraycopy(reqPacket, 12, out, 16, 4)
        val ipSum = onesComplementSum(out, 0, 20, 0L)
        out[10] = ((ipSum ushr 8) and 0xFF).toByte()
        out[11] = (ipSum and 0xFF).toByte()
        out[20] = reqPacket[reqIhl + 2]
        out[21] = reqPacket[reqIhl + 3]
        out[22] = reqPacket[reqIhl]
        out[23] = reqPacket[reqIhl + 1]
        val udpLen = 8 + payload.size
        out[24] = ((udpLen ushr 8) and 0xFF).toByte()
        out[25] = (udpLen and 0xFF).toByte()
        if (payload.isNotEmpty()) {
            System.arraycopy(payload, 0, out, 28, payload.size)
        }
        return totalLen
    }

    private fun buildTcpPacketKotlin(
        out: ByteArray,
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        seq: Long,
        ack: Long,
        flags: Int,
        window: Int,
        mss: Int,
        payload: ByteArray?,
        payloadOffset: Int,
        payloadLength: Int
    ): Int {
        val optLen = if (mss > 0) 4 else 0
        val tcpHeaderLen = 20 + optLen
        val totalLen = 20 + tcpHeaderLen + payloadLength
        out.fill(0, 0, 20 + tcpHeaderLen)

        out[0] = 0x45.toByte()
        out[2] = ((totalLen ushr 8) and 0xFF).toByte()
        out[3] = (totalLen and 0xFF).toByte()
        out[6] = 0x40.toByte()
        out[8] = 64.toByte()
        out[9] = 6.toByte()
        System.arraycopy(dstIp, 0, out, 12, 4)
        System.arraycopy(srcIp, 0, out, 16, 4)

        out[20] = ((dstPort ushr 8) and 0xFF).toByte()
        out[21] = (dstPort and 0xFF).toByte()
        out[22] = ((srcPort ushr 8) and 0xFF).toByte()
        out[23] = (srcPort and 0xFF).toByte()
        out[24] = ((seq ushr 24) and 0xFF).toByte()
        out[25] = ((seq ushr 16) and 0xFF).toByte()
        out[26] = ((seq ushr 8) and 0xFF).toByte()
        out[27] = (seq and 0xFF).toByte()
        out[28] = ((ack ushr 24) and 0xFF).toByte()
        out[29] = ((ack ushr 16) and 0xFF).toByte()
        out[30] = ((ack ushr 8) and 0xFF).toByte()
        out[31] = (ack and 0xFF).toByte()
        out[32] = (((tcpHeaderLen / 4) shl 4) and 0xF0).toByte()
        out[33] = (flags and 0x3F).toByte()
        out[34] = ((window ushr 8) and 0xFF).toByte()
        out[35] = (window and 0xFF).toByte()
        if (mss > 0) {
            out[40] = 0x02
            out[41] = 0x04
            out[42] = ((mss ushr 8) and 0xFF).toByte()
            out[43] = (mss and 0xFF).toByte()
        }
        if (payload != null && payloadLength > 0) {
            System.arraycopy(payload, payloadOffset, out, 40, payloadLength)
        }

        val ipSum = onesComplementSum(out, 0, 20, 0L)
        out[10] = ((ipSum ushr 8) and 0xFF).toByte()
        out[11] = (ipSum and 0xFF).toByte()

        var pseudoSum = 0L
        for (i in 12 until 20 step 2) {
            pseudoSum += ((out[i].toInt() and 0xFF) shl 8) or (out[i + 1].toInt() and 0xFF)
        }
        pseudoSum += 6L
        pseudoSum += (tcpHeaderLen + payloadLength).toLong()
        val tcpSum = onesComplementSum(out, 20, tcpHeaderLen + payloadLength, pseudoSum)
        out[36] = ((tcpSum ushr 8) and 0xFF).toByte()
        out[37] = (tcpSum and 0xFF).toByte()
        return totalLen
    }
}
