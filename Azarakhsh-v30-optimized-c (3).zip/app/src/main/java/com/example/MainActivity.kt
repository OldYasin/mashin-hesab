package com.example

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.TunnelConnectionState
import com.example.ui.components.AppIcons
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.ScriptsGuideScreen
import com.example.ui.screens.ServersScreen
import com.example.ui.theme.ScriptTunnelTheme
import com.example.ui.viewmodel.MainViewModel

private enum class AppTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    CONNECT("dashboard", "اتصال", AppIcons.ShieldFilled, AppIcons.ShieldOutlined),
    SERVERS("servers", "سرورها", AppIcons.Hub, AppIcons.Hub),
    REPORTS("reports", "گزارش‌ها و لاگ", AppIcons.Assessment, AppIcons.Assessment),
    GUIDE("guide", "کد و راهنما", AppIcons.Code, AppIcons.Code)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ScriptTunnelApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScriptTunnelApp(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsStateWithLifecycle()
    val telemetry by vm.telemetry.collectAsStateWithLifecycle()
    val servers by vm.servers.collectAsStateWithLifecycle()
    val cleanIps by vm.cleanIps.collectAsStateWithLifecycle()
    val reports by vm.reports.collectAsStateWithLifecycle()
    val scanProgress by vm.scanProgress.collectAsStateWithLifecycle()
    val isTestingPool by vm.isTestingPool.collectAsStateWithLifecycle()
    val secretKey by vm.generatedSecret.collectAsStateWithLifecycle()
    val banner by vm.banner.collectAsStateWithLifecycle()
    val logs by vm.logs.collectAsStateWithLifecycle()
    val isLogsPaused by vm.isLogsPaused.collectAsStateWithLifecycle()
    val isMitmCaInstalled by vm.isMitmCaInstalled.collectAsStateWithLifecycle()
    val isProbing by vm.isProbing.collectAsStateWithLifecycle()

    var currentTab by rememberSaveable { mutableStateOf(AppTab.CONNECT) }
    val snackbarHostState = remember { SnackbarHostState() }

    val caInstallLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        vm.refreshMitmCaStatus()
    }

    // VPN system consent launcher
    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            vm.startVpnTunnel()
        } else {
            vm.showMessage("مجوز VPN توسط سیستم تایید نشد.", isError = true)
        }
    }

    // Notification runtime permission launcher (Android 13+)
    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        val prepareIntent = if (settings.vpnModeEnabled) VpnService.prepare(context) else null
        if (prepareIntent != null) {
            vpnPermissionLauncher.launch(prepareIntent)
        } else {
            vm.startVpnTunnel()
        }
    }

    fun requestStartOrStopTunnel() {
        val state = telemetry.connectionState
        if (state == TunnelConnectionState.CONNECTED ||
            state == TunnelConnectionState.CONNECTING ||
            state == TunnelConnectionState.RECONNECTING
        ) {
            vm.stopVpnTunnel()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }

        val prepareIntent = if (settings.vpnModeEnabled) VpnService.prepare(context) else null
        if (prepareIntent != null) {
            vpnPermissionLauncher.launch(prepareIntent)
        } else {
            vm.startVpnTunnel()
        }
    }

    LaunchedEffect(banner) {
        val msg = banner
        if (msg != null) {
            snackbarHostState.showSnackbar(msg.text)
            vm.clearBanner()
        }
    }

    BackHandler(enabled = currentTab != AppTab.CONNECT) {
        currentTab = AppTab.CONNECT
    }

    ScriptTunnelTheme(darkTheme = settings.darkTheme) {
        val view = LocalView.current
        if (!view.isInEditMode) {
            val statusColor = MaterialTheme.colorScheme.background.toArgb()
            val navColor = MaterialTheme.colorScheme.surface.toArgb()
            SideEffect {
                val window = (view.context as? android.app.Activity)?.window ?: return@SideEffect
                @Suppress("DEPRECATION")
                window.statusBarColor = statusColor
                @Suppress("DEPRECATION")
                window.navigationBarColor = navColor
                val ctrl = WindowCompat.getInsetsController(window, view)
                ctrl.isAppearanceLightStatusBars = !settings.darkTheme
                ctrl.isAppearanceLightNavigationBars = !settings.darkTheme
            }
        }
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavRail = maxWidth >= 600.dp

            Scaffold(
                modifier = Modifier.fillMaxSize(),
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                topBar = {
                    CenterAlignedTopAppBar(
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background
                        ),
                        navigationIcon = {
                            IconButton(
                                onClick = { vm.toggleDarkTheme() },
                                modifier = Modifier.testTag("theme_toggle_button")
                            ) {
                                Icon(
                                    imageVector = if (settings.darkTheme) AppIcons.LightMode else AppIcons.DarkMode,
                                    contentDescription = "تغییر تم روشن یا تیره"
                                )
                            }
                        },
                        title = {
                            Text(
                                text = "Azarakhsh",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                        colors = listOf(
                                            androidx.compose.ui.graphics.Color(0xFF7B5CFF),
                                            androidx.compose.ui.graphics.Color(0xFF2DD4FF)
                                        )
                                    )
                                ),
                                fontWeight = FontWeight.ExtraBold
                            )
                        },
                    )
                },
                bottomBar = {
                    if (!useNavRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            AppTab.entries.forEach { tab ->
                                val selected = currentTab == tab
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentTab = tab },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label, style = MaterialTheme.typography.labelMedium) },
                                    colors = androidx.compose.material3.NavigationBarItemDefaults.colors(
                                        selectedIconColor = com.example.ui.theme.CyanSecondary,
                                        selectedTextColor = com.example.ui.theme.CyanSecondary,
                                        indicatorColor = com.example.ui.theme.VioletTertiary.copy(alpha = 0.22f),
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.testTag("nav_tab_${tab.route}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useNavRail) {
                        NavigationRail(
                            modifier = Modifier.fillMaxHeight(),
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            AppTab.entries.forEach { tab ->
                                val selected = currentTab == tab
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { currentTab = tab },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label) },
                                    modifier = Modifier.testTag("nav_rail_${tab.route}")
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        val contentModifier = Modifier.widthIn(max = 760.dp)
                        when (currentTab) {
                            AppTab.CONNECT -> DashboardScreen(
                                telemetry = telemetry,
                                settings = settings,
                                onPowerClick = { requestStartOrStopTunnel() },
                                onProtocolSelected = vm::updateProtocol,
                                onToggleTlsFrag = vm::toggleTlsFragmentation,
                                onToggleMitmHttp2 = vm::toggleMitmHttp2,
                                onToggleMtProtoHttpBridge = vm::toggleMtProtoHttpBridge,
                                onToggleLogDedup = vm::toggleLogDedup,
                                onToggleThermalGuard = vm::toggleThermalGuard,
                                onToggleCleanIp = vm::toggleCleanIpBinding,
                                onToggleKeepAlive = vm::toggleAdaptiveKeepAlive,
                                onToggleDoh = vm::toggleDoh,
                                onToggleVpnMode = vm::toggleVpnMode,
                                isProbing = isProbing,
                                onProbeTunnel = vm::runLiveSpeedAndDohProbe,
                                isCaInstalled = isMitmCaInstalled,
                                onInstallCaClick = {
                                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                                        // Android 11+: the system refuses in-app CA installs, so save the file
                                        // to Downloads and open Security settings for a manual install.
                                        vm.exportCaForManualInstall { ok ->
                                            if (ok) {
                                                vm.showMessage("فایل ScriptTunnel-CA.crt در Downloads ذخیره شد. در تنظیمات: Security ← Encryption & credentials ← Install a certificate ← CA certificate را بزنید و همان فایل را انتخاب کنید.")
                                                runCatching {
                                                    caInstallLauncher.launch(android.content.Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS))
                                                }
                                            } else {
                                                vm.showMessage("ذخیره فایل گواهی ناموفق بود", isError = true)
                                            }
                                        }
                                    } else {
                                        runCatching {
                                            caInstallLauncher.launch(vm.createCaInstallIntent())
                                        }.onFailure {
                                            vm.showMessage("امکان باز کردن نصب گواهی وجود نداشت: ${it.localizedMessage}", isError = true)
                                        }
                                    }
                                },
                                onNavigateToServers = { currentTab = AppTab.SERVERS },
                                onShowMessage = { vm.showMessage(it) },
                                modifier = contentModifier
                            )

                            AppTab.SERVERS -> ServersScreen(
                                servers = servers,
                                cleanIps = cleanIps,
                                settings = settings,
                                defaultSecret = secretKey,
                                scanProgress = scanProgress,
                                isTestingPool = isTestingPool,
                                onLoadBalanceChange = vm::updateLoadBalanceMode,
                                onAddOrUpdateServer = vm::addOrUpdateServer,
                                onImportConfig = vm::importShareConfig,
                                onToggleParallel = vm::toggleServerParallel,
                                onPingServer = vm::pingSingleServer,
                                onTestAllServers = vm::testAllServers,
                                onDeleteServer = vm::deleteServer,
                                dnsResults = vm.dnsTestResults.collectAsStateWithLifecycle().value,
                                isTestingDns = vm.isTestingDns.collectAsStateWithLifecycle().value,
                                onTestDnsResolvers = vm::testDnsResolvers,
                                onExportBundle = vm::exportAllBundle,
                                onTestTelegramHttp = vm::testTelegramHttp,
                                onStartCleanIpScan = vm::startCleanIpScan,
                                onStopCleanIpScan = vm::stopCleanIpScan,
                                onApplyCleanIp = vm::applyCleanIp,
                                onSetProxyIp = vm::setProxyIp,
                                onShowMessage = { vm.showMessage(it) },
                                modifier = contentModifier
                            )

                            AppTab.REPORTS -> ReportsScreen(
                                reports = reports,
                                logs = logs,
                                isLogsPaused = isLogsPaused,
                                onTogglePause = vm::toggleLogsPause,
                                onClearLogs = vm::clearLogs,
                                onClearReports = vm::clearReports,
                                onShowMessage = { vm.showMessage(it) },
                                modifier = contentModifier
                            )

                            AppTab.GUIDE -> ScriptsGuideScreen(
                                secretKey = secretKey,
                                onRegenerateSecret = vm::regenerateSecretKey,
                                onShowMessage = { vm.showMessage(it) },
                                modifier = contentModifier
                            )
                        }
                    }
                }
            }
        }
    }
}
