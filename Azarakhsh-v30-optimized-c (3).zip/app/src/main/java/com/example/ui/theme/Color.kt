package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Azarakhsh Night-Electric Palette
val ObsidianBg = Color(0xFF0B0F1A)             // Night blue-black
val ObsidianSurface = Color(0xFF141B2D)        // Dark navy card surface
val ObsidianSurfaceVariant = Color(0xFF1B243B)
val ObsidianBorder = Color(0xFF25304D)

val EmeraldPrimary = Color(0xFFFFD60A)         // Electric yellow (Primary / Connect)
val EmeraldOnPrimary = Color(0xFF0B0F1A)       // Connect button text
val EmeraldContainer = Color(0xFF2E2712)

val CyanSecondary = Color(0xFF2DD4FF)          // Neon blue (Accent)
val CyanOnSecondary = Color(0xFF0B0F1A)
val CyanContainer = Color(0xFF112D42)

val VioletTertiary = Color(0xFF7B5CFF)         // Electric purple (Secondary)
val AzarakhshSuccess = Color(0xFF22E58B)       // Connected
val AmberWarning = Color(0xFFFFD60A)
val RoseError = Color(0xFFFF4D5E)              // Disconnected / Error

val DarkTextPrimary = Color(0xFFE8ECF5)        // Blue-tinted white
val DarkTextSecondary = Color(0xFF8A94A9)      // Blue-gray

// Clean Light Palette (kept for theme toggle)
val LightBg = Color(0xFFF4F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE9EFF8)
val LightBorder = Color(0xFFD2DCEB)

val LightEmeraldPrimary = Color(0xFFD9A700)
val LightEmeraldContainer = Color(0xFFFFF4C2)
val LightCyanSecondary = Color(0xFF0284C7)
val LightCyanContainer = Color(0xFFD9F0FC)

val LightTextPrimary = Color(0xFF0B0F1A)
val LightTextSecondary = Color(0xFF475569)
