package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NetworkSyncStatus
import com.example.data.model.SpeedSample
import com.example.data.model.TunnelConnectionState
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.RoseError
import java.util.Locale
import kotlin.math.max

@Composable
fun PowerConnectOrb(
    state: TunnelConnectionState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isConnected = state == TunnelConnectionState.CONNECTED
    val isBusy = state == TunnelConnectionState.CONNECTING || state == TunnelConnectionState.RECONNECTING
    val isError = state == TunnelConnectionState.ERROR

    val electricYellow = Color(0xFFFFD60A)
    val electricPurple = Color(0xFF7B5CFF)
    val neonBlue = Color(0xFF2DD4FF)
    val successGreen = Color(0xFF22E58B)
    val errorRed = Color(0xFFFF4D5E)
    val nightInk = Color(0xFF0B0F1A)

    val ringScale by animateFloatAsState(
        targetValue = if (isConnected) 1.04f else 1f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 280f),
        label = "orbScale"
    )

    val infinite = rememberInfiniteTransition(label = "azarakhshOrb")
    val spinDeg by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isBusy) 900 else 3600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spinDeg"
    )
    val breathe by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathe"
    )

    Box(
        modifier = modifier.size(152.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val outerR = size.minDimension / 2f - 4.dp.toPx()

            when {
                isConnected -> {
                    // Connected Glow (#FFD60A) + Success Ring (#22E58B)
                    val glowAlpha = 0.24f + 0.16f * breathe
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                electricYellow.copy(alpha = glowAlpha),
                                successGreen.copy(alpha = glowAlpha * 0.45f),
                                Color.Transparent
                            ),
                            center = center,
                            radius = outerR
                        ),
                        radius = outerR,
                        center = center
                    )
                    drawCircle(
                        brush = Brush.sweepGradient(
                            colors = listOf(electricYellow, successGreen, neonBlue, electricYellow),
                            center = center
                        ),
                        radius = outerR - 6.dp.toPx(),
                        center = center,
                        style = Stroke(width = 2.6.dp.toPx())
                    )
                }
                isBusy -> {
                    val arcR = outerR - 6.dp.toPx()
                    val topLeft = Offset(center.x - arcR, center.y - arcR)
                    val arcSize = Size(arcR * 2f, arcR * 2f)
                    drawCircle(
                        color = electricPurple.copy(alpha = 0.22f),
                        radius = arcR,
                        center = center,
                        style = Stroke(width = 2.5.dp.toPx())
                    )
                    drawArc(
                        brush = Brush.sweepGradient(
                            0.0f to Color.Transparent,
                            0.45f to electricPurple,
                            0.8f to neonBlue,
                            1.0f to electricYellow
                        ),
                        startAngle = spinDeg,
                        sweepAngle = 240f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = 3.2.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
                else -> {
                    // Gradient energy ring (#7B5CFF -> #2DD4FF) or Error (#FF4D5E)
                    drawCircle(
                        brush = Brush.sweepGradient(
                            colors = if (isError) {
                                listOf(errorRed.copy(alpha = 0.7f), errorRed.copy(alpha = 0.25f), errorRed.copy(alpha = 0.7f))
                            } else {
                                listOf(electricPurple.copy(alpha = 0.55f), neonBlue.copy(alpha = 0.55f), electricPurple.copy(alpha = 0.55f))
                            },
                            center = center
                        ),
                        radius = outerR - 6.dp.toPx(),
                        center = center,
                        style = Stroke(width = 1.8.dp.toPx())
                    )
                }
            }
        }

        val containerColor by animateColorAsState(
            targetValue = when {
                isConnected -> electricYellow
                isBusy -> Color(0xFF141B2D)
                isError -> errorRed.copy(alpha = 0.16f)
                else -> electricYellow
            },
            animationSpec = tween(260),
            label = "azBtnColor"
        )

        Surface(
            modifier = Modifier
                .size(114.dp)
                .scale(ringScale)
                .clip(CircleShape)
                .clickable(onClick = onClick)
                .testTag("power_connect_button"),
            shape = CircleShape,
            color = containerColor,
            border = BorderStroke(
                width = 2.dp,
                brush = Brush.linearGradient(
                    colors = when {
                        isConnected -> listOf(successGreen, electricYellow)
                        isBusy -> listOf(electricPurple, neonBlue)
                        isError -> listOf(errorRed, errorRed.copy(alpha = 0.6f))
                        else -> listOf(electricPurple, neonBlue)
                    }
                )
            ),
            tonalElevation = 6.dp
        ) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                // Signature Azarakhsh lightning bolt glyph behind/above label
                Canvas(modifier = Modifier.size(44.dp)) {
                    val w = size.width
                    val h = size.height
                    val bolt = Path().apply {
                        moveTo(w * 0.61f, h * 0.06f)
                        lineTo(w * 0.24f, h * 0.56f)
                        lineTo(w * 0.48f, h * 0.56f)
                        lineTo(w * 0.37f, h * 0.94f)
                        lineTo(w * 0.76f, h * 0.42f)
                        lineTo(w * 0.52f, h * 0.42f)
                        close()
                    }
                    val boltColor = when {
                        isConnected -> nightInk.copy(alpha = 0.22f)
                        isBusy -> electricYellow.copy(alpha = 0.24f)
                        isError -> errorRed.copy(alpha = 0.28f)
                        else -> nightInk.copy(alpha = 0.16f)
                    }
                    drawPath(bolt, color = boltColor)
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = AppIcons.Power,
                        contentDescription = "دکمه اتصال یا قطع آذرخش",
                        tint = when {
                            isConnected -> nightInk
                            isBusy -> neonBlue
                            isError -> errorRed
                            else -> nightInk
                        },
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = when {
                            isConnected -> "متصل"
                            isBusy -> "صبر..."
                            isError -> "تلاش مجدد"
                            else -> "اتصال"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = when {
                            isConnected -> nightInk
                            isBusy -> Color(0xFFE8ECF5)
                            isError -> errorRed
                            else -> nightInk
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun RealTimeSpeedChart(
    samples: List<SpeedSample>,
    currentDownKbps: Float,
    currentUpKbps: Float,
    modifier: Modifier = Modifier
) {
    val surfaceBorder = MaterialTheme.colorScheme.outline
    val textSecondary = MaterialTheme.colorScheme.onSurfaceVariant

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, surfaceBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "نمودار سرعت لحظه‌ای",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SpeedLegendChip(label = "دانلود", value = formatSpeedKbps(currentDownKbps), color = CyanSecondary)
                    SpeedLegendChip(label = "آپلود", value = formatSpeedKbps(currentUpKbps), color = EmeraldPrimary)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            val maxVal = max(
                10f,
                samples.maxOfOrNull { max(it.downloadKbps, it.uploadKbps) } ?: 10f
            ) * 1.15f

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(84.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val dash = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                    listOf(0.25f, 0.5f, 0.75f, 1f).forEach { frac ->
                        val y = h * frac
                        drawLine(
                            color = surfaceBorder.copy(alpha = 0.55f),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = dash
                        )
                    }

                    if (samples.size >= 2) {
                        drawSmoothSeries(
                            values = samples.map { it.downloadKbps },
                            maxVal = maxVal,
                            strokeColor = CyanSecondary,
                            w = w,
                            h = h
                        )
                        drawSmoothSeries(
                            values = samples.map { it.uploadKbps },
                            maxVal = maxVal,
                            strokeColor = EmeraldPrimary,
                            w = w,
                            h = h
                        )
                    }
                }

                if (samples.size < 2) {
                    Text(
                        text = "با برقراری اتصال، نمودار ترافیک زنده ترسیم می‌شود",
                        style = MaterialTheme.typography.bodyMedium,
                        color = textSecondary,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSmoothSeries(
    values: List<Float>,
    maxVal: Float,
    strokeColor: Color,
    w: Float,
    h: Float
) {
    if (values.size < 2) return
    val stepX = w / (values.size - 1).coerceAtLeast(1)
    val points = values.mapIndexed { idx, v ->
        val x = idx * stepX
        val y = h - ((v / maxVal).coerceIn(0f, 1f) * (h - 6.dp.toPx())) - 3.dp.toPx()
        Offset(x, y)
    }

    val linePath = Path().apply {
        moveTo(points.first().x, points.first().y)
        for (i in 0 until points.size - 1) {
            val p0 = points[i]
            val p1 = points[i + 1]
            val cx = (p0.x + p1.x) / 2f
            cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
        }
    }

    val fillPath = Path().apply {
        addPath(linePath)
        lineTo(points.last().x, h)
        lineTo(points.first().x, h)
        close()
    }

    drawPath(
        path = fillPath,
        brush = Brush.verticalGradient(
            colors = listOf(strokeColor.copy(alpha = 0.28f), strokeColor.copy(alpha = 0.0f)),
            startY = 0f,
            endY = h
        )
    )
    drawPath(
        path = linePath,
        color = strokeColor,
        style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round)
    )
}

@Composable
private fun SpeedLegendChip(label: String, value: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = "$label ",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun StabilityArcGauge(
    score: Float,
    latencyMs: Int,
    jitterMs: Int,
    lossPercent: Float,
    modifier: Modifier = Modifier
) {
    val gaugeColor = when {
        score >= 80f -> EmeraldPrimary
        score >= 55f -> AmberWarning
        else -> RoseError
    }
    val trackColor = MaterialTheme.colorScheme.surfaceVariant
    val animatedSweep by animateFloatAsState(
        targetValue = (score.coerceIn(0f, 100f) / 100f) * 240f,
        animationSpec = tween(450),
        label = "stabilitySweep"
    )

    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(
            modifier = Modifier.size(94.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val stroke = 8.dp.toPx()
                val arcSize = Size(size.width - stroke, size.height - stroke)
                val topLeft = Offset(stroke / 2f, stroke / 2f)
                drawArc(
                    color = trackColor,
                    startAngle = 150f,
                    sweepAngle = 240f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
                drawArc(
                    color = gaugeColor,
                    startAngle = 150f,
                    sweepAngle = animatedSweep,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "${score.toInt()}%",
                    style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                    fontWeight = FontWeight.Bold,
                    color = gaugeColor
                )
                Text(
                    text = "پایداری",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricMiniRow("پینگ تاخیر", if (latencyMs > 0) "${latencyMs} ms" else "—")
            MetricMiniRow("نوسان (Jitter)", if (jitterMs > 0) "${jitterMs} ms" else "0 ms")
            MetricMiniRow("اتلاف بسته", String.format(Locale.US, "%.1f%%", lossPercent))
        }
    }
}

@Composable
private fun MetricMiniRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

fun formatSpeedKbps(kbps: Float): String {
    return if (kbps >= 1024f) {
        String.format(Locale.US, "%.1f MB/s", kbps / 1024f)
    } else {
        String.format(Locale.US, "%.1f KB/s", kbps)
    }
}

fun formatBytesHuman(bytes: Long): String {
    return when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> String.format(Locale.US, "%.1f KB", bytes / 1024f)
        bytes < 1024L * 1024L * 1024L -> String.format(Locale.US, "%.2f MB", bytes / (1024f * 1024f))
        else -> String.format(Locale.US, "%.2f GB", bytes / (1024f * 1024f * 1024f))
    }
}
