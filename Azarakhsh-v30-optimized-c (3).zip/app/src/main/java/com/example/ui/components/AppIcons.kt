package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

object AppIcons {
    val Add: ImageVector = Icons.Filled.Add
    val CheckCircle: ImageVector = Icons.Filled.CheckCircle
    val Delete: ImageVector = Icons.Filled.Delete
    val Edit: ImageVector = Icons.Filled.Edit
    val ExpandMore: ImageVector = Icons.Filled.KeyboardArrowDown
    val ExpandLess: ImageVector = Icons.Filled.KeyboardArrowUp
    val Lock: ImageVector = Icons.Filled.Lock
    val MoreVert: ImageVector by lazy {
        vec("MoreVert") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 6f); curveTo(13.1f, 6f, 14f, 5.1f, 14f, 4f); curveTo(14f, 2.9f, 13.1f, 2f, 12f, 2f)
                curveTo(10.9f, 2f, 10f, 2.9f, 10f, 4f); curveTo(10f, 5.1f, 10.9f, 6f, 12f, 6f); close()
                moveTo(12f, 14f); curveTo(13.1f, 14f, 14f, 13.1f, 14f, 12f); curveTo(14f, 10.9f, 13.1f, 10f, 12f, 10f)
                curveTo(10.9f, 10f, 10f, 10.9f, 10f, 12f); curveTo(10f, 13.1f, 10.9f, 14f, 12f, 14f); close()
                moveTo(12f, 22f); curveTo(13.1f, 22f, 14f, 21.1f, 14f, 20f); curveTo(14f, 18.9f, 13.1f, 18f, 12f, 18f)
                curveTo(10.9f, 18f, 10f, 18.9f, 10f, 20f); curveTo(10f, 21.1f, 10.9f, 22f, 12f, 22f); close()
            }
        }
    }
    val Share: ImageVector = Icons.Filled.Share
    val Sync: ImageVector = Icons.Filled.Refresh

    val Power: ImageVector by lazy {
        vec("Power") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(13f, 3f)
                horizontalLineTo(11f)
                verticalLineTo(13f)
                horizontalLineTo(13f)
                verticalLineTo(3f)
                close()
                moveTo(17.83f, 5.17f)
                lineTo(16.41f, 6.59f)
                curveTo(17.99f, 7.86f, 19f, 9.81f, 19f, 12f)
                curveTo(19f, 15.87f, 15.87f, 19f, 12f, 19f)
                curveTo(8.13f, 19f, 5f, 15.87f, 5f, 12f)
                curveTo(5f, 9.81f, 6.01f, 7.86f, 7.58f, 6.58f)
                lineTo(6.17f, 5.17f)
                curveTo(4.23f, 6.82f, 3f, 9.26f, 3f, 12f)
                curveTo(3f, 16.97f, 7.03f, 21f, 12f, 21f)
                curveTo(16.97f, 21f, 21f, 16.97f, 21f, 12f)
                curveTo(21f, 9.26f, 19.77f, 6.82f, 17.83f, 5.17f)
                close()
            }
        }
    }

    val ShieldFilled: ImageVector by lazy {
        vec("ShieldFilled") {
            path(fill = SolidColor(Color.Black), pathFillType = androidx.compose.ui.graphics.PathFillType.EvenOdd) {
                moveTo(12f, 2f)
                lineTo(4f, 5.2f)
                verticalLineTo(11.2f)
                curveTo(4f, 16.2f, 7.4f, 20.8f, 12f, 22f)
                curveTo(16.6f, 20.8f, 20f, 16.2f, 20f, 11.2f)
                verticalLineTo(5.2f)
                lineTo(12f, 2f)
                close()
                // Inner Azarakhsh bolt cutout
                moveTo(13.2f, 6.5f)
                lineTo(8.8f, 12.6f)
                horizontalLineTo(11.6f)
                lineTo(10.6f, 17.5f)
                lineTo(15.2f, 11.2f)
                horizontalLineTo(12.3f)
                close()
            }
        }
    }

    val ShieldOutlined: ImageVector by lazy {
        vec("ShieldOutlined") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 2f)
                lineTo(4f, 5f)
                verticalLineTo(11.09f)
                curveTo(4f, 16.14f, 7.41f, 20.85f, 12f, 22f)
                curveTo(16.59f, 20.85f, 20f, 16.14f, 20f, 11.09f)
                verticalLineTo(5f)
                lineTo(12f, 2f)
                close()
                moveTo(18f, 11.09f)
                curveTo(18f, 15.09f, 15.45f, 18.79f, 12f, 19.92f)
                curveTo(8.55f, 18.79f, 6f, 15.1f, 6f, 11.09f)
                verticalLineTo(6.39f)
                lineTo(12f, 4.14f)
                lineTo(18f, 6.39f)
                verticalLineTo(11.09f)
                close()
            }
        }
    }

    val Hub: ImageVector by lazy {
        vec("Hub") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 9f)
                arcToRelative(3f, 3f, 0f, true, false, 0f, 6f)
                arcToRelative(3f, 3f, 0f, true, false, 0f, -6f)
                close()
                moveTo(5f, 5f)
                arcToRelative(2f, 2f, 0f, true, false, 0f, 4f)
                arcToRelative(2f, 2f, 0f, true, false, 0f, -4f)
                close()
                moveTo(19f, 5f)
                arcToRelative(2f, 2f, 0f, true, false, 0f, 4f)
                arcToRelative(2f, 2f, 0f, true, false, 0f, -4f)
                close()
                moveTo(12f, 18f)
                arcToRelative(2f, 2f, 0f, true, false, 0f, 4f)
                arcToRelative(2f, 2f, 0f, true, false, 0f, -4f)
                close()
                moveTo(6.7f, 7.6f)
                lineTo(10.1f, 10.2f)
                lineTo(9.1f, 11.5f)
                lineTo(5.7f, 8.9f)
                close()
                moveTo(17.3f, 7.6f)
                lineTo(18.3f, 8.9f)
                lineTo(14.9f, 11.5f)
                lineTo(13.9f, 10.2f)
                close()
                moveTo(11.2f, 14.5f)
                horizontalLineTo(12.8f)
                verticalLineTo(18.5f)
                horizontalLineTo(11.2f)
                close()
            }
        }
    }

    val Assessment: ImageVector by lazy {
        vec("Assessment") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(19f, 3f)
                horizontalLineTo(5f)
                curveTo(3.9f, 3f, 3f, 3.9f, 3f, 5f)
                verticalLineTo(19f)
                curveTo(3f, 20.1f, 3.9f, 21f, 5f, 21f)
                horizontalLineTo(19f)
                curveTo(20.1f, 21f, 21f, 20.1f, 21f, 19f)
                verticalLineTo(5f)
                curveTo(21f, 3.9f, 20.1f, 3f, 19f, 3f)
                close()
                moveTo(9f, 17f)
                horizontalLineTo(7f)
                verticalLineTo(10f)
                horizontalLineTo(9f)
                verticalLineTo(17f)
                close()
                moveTo(13f, 17f)
                horizontalLineTo(11f)
                verticalLineTo(7f)
                horizontalLineTo(13f)
                verticalLineTo(17f)
                close()
                moveTo(17f, 17f)
                horizontalLineTo(15f)
                verticalLineTo(13f)
                horizontalLineTo(17f)
                verticalLineTo(17f)
                close()
            }
        }
    }

    val Code: ImageVector by lazy {
        vec("Code") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(9.4f, 16.6f)
                lineTo(4.8f, 12f)
                lineTo(9.4f, 7.4f)
                lineTo(8f, 6f)
                lineTo(2f, 12f)
                lineTo(8f, 18f)
                lineTo(9.4f, 16.6f)
                close()
                moveTo(14.6f, 16.6f)
                lineTo(19.2f, 12f)
                lineTo(14.6f, 7.4f)
                lineTo(16f, 6f)
                lineTo(22f, 12f)
                lineTo(16f, 18f)
                lineTo(14.6f, 16.6f)
                close()
            }
        }
    }

    val CloudDone: ImageVector by lazy {
        vec("CloudDone") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(19.35f, 10.04f)
                curveTo(18.67f, 6.59f, 15.64f, 4f, 12f, 4f)
                curveTo(9.11f, 4f, 6.6f, 5.64f, 5.35f, 8.04f)
                curveTo(2.34f, 8.36f, 0f, 10.91f, 0f, 14f)
                curveTo(0f, 17.31f, 2.69f, 20f, 6f, 20f)
                horizontalLineTo(19f)
                curveTo(21.76f, 20f, 24f, 17.76f, 24f, 15f)
                curveTo(24f, 12.36f, 21.95f, 10.22f, 19.35f, 10.04f)
                close()
                moveTo(10f, 17f)
                lineTo(6.5f, 13.5f)
                lineTo(7.91f, 12.09f)
                lineTo(10f, 14.17f)
                lineTo(15.18f, 8.99f)
                lineTo(16.59f, 10.41f)
                lineTo(10f, 17f)
                close()
            }
        }
    }

    val CloudOff: ImageVector by lazy {
        vec("CloudOff") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(19.35f, 10.04f)
                curveTo(18.67f, 6.59f, 15.64f, 4f, 12f, 4f)
                curveTo(10.52f, 4f, 9.15f, 4.43f, 7.98f, 5.17f)
                lineTo(9.45f, 6.64f)
                curveTo(10.24f, 6.23f, 11.1f, 6f, 12f, 6f)
                curveTo(15.04f, 6f, 17.5f, 8.46f, 17.5f, 11.5f)
                verticalLineTo(12f)
                horizontalLineTo(19f)
                curveTo(20.66f, 12f, 22f, 13.34f, 22f, 15f)
                curveTo(22f, 16.13f, 21.37f, 17.11f, 20.44f, 17.62f)
                lineTo(21.89f, 19.07f)
                curveTo(23.16f, 18.18f, 24f, 16.69f, 24f, 15f)
                curveTo(24f, 12.36f, 21.95f, 10.22f, 19.35f, 10.04f)
                close()
                moveTo(3f, 5.27f)
                lineTo(5.75f, 8.02f)
                curveTo(2.56f, 8.15f, 0f, 10.77f, 0f, 14f)
                curveTo(0f, 17.31f, 2.69f, 20f, 6f, 20f)
                horizontalLineTo(17.73f)
                lineTo(19.73f, 22f)
                lineTo(21f, 20.73f)
                lineTo(4.27f, 4f)
                lineTo(3f, 5.27f)
                close()
            }
        }
    }

    val ContentCopy: ImageVector by lazy {
        vec("ContentCopy") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(16f, 1f)
                horizontalLineTo(4f)
                curveTo(2.9f, 1f, 2f, 1.9f, 2f, 3f)
                verticalLineTo(17f)
                horizontalLineTo(4f)
                verticalLineTo(3f)
                horizontalLineTo(16f)
                verticalLineTo(1f)
                close()
                moveTo(19f, 5f)
                horizontalLineTo(8f)
                curveTo(6.9f, 5f, 6f, 5.9f, 6f, 7f)
                verticalLineTo(21f)
                curveTo(6f, 22.1f, 6.9f, 23f, 8f, 23f)
                horizontalLineTo(19f)
                curveTo(20.1f, 23f, 21f, 22.1f, 21f, 21f)
                verticalLineTo(7f)
                curveTo(21f, 5.9f, 20.1f, 5f, 19f, 5f)
                close()
                moveTo(19f, 21f)
                horizontalLineTo(8f)
                verticalLineTo(7f)
                horizontalLineTo(19f)
                verticalLineTo(21f)
                close()
            }
        }
    }

    val Speed: ImageVector by lazy {
        vec("Speed") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(20.38f, 8.57f)
                lineTo(18.92f, 10.77f)
                curveTo(19.61f, 12.1f, 19.79f, 13.62f, 19.45f, 15.07f)
                horizontalLineTo(17.34f)
                curveTo(17.75f, 12.69f, 16.5f, 10.22f, 14.23f, 9.21f)
                curveTo(11.97f, 8.21f, 9.31f, 8.85f, 7.75f, 10.77f)
                curveTo(6.2f, 12.69f, 6.13f, 15.42f, 7.57f, 17.41f)
                horizontalLineTo(5.16f)
                curveTo(3.49f, 14.43f, 4.13f, 10.63f, 6.72f, 8.4f)
                curveTo(9.31f, 6.17f, 13.15f, 6.08f, 15.84f, 8.17f)
                lineTo(17.85f, 5.14f)
                lineTo(20.38f, 8.57f)
                close()
                moveTo(10.59f, 15.41f)
                curveTo(11.37f, 16.19f, 12.64f, 16.19f, 13.42f, 15.41f)
                lineTo(17.5f, 10f)
                lineTo(10.59f, 12.59f)
                curveTo(9.81f, 13.37f, 9.81f, 14.63f, 10.59f, 15.41f)
                close()
            }
        }
    }

    val Radar: ImageVector by lazy {
        vec("Radar") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 2f)
                curveTo(6.48f, 2f, 2f, 6.48f, 2f, 12f)
                curveTo(2f, 17.52f, 6.48f, 22f, 12f, 22f)
                curveTo(17.52f, 22f, 22f, 17.52f, 22f, 12f)
                curveTo(22f, 6.48f, 17.52f, 2f, 12f, 2f)
                close()
                moveTo(12f, 20f)
                curveTo(7.59f, 20f, 4f, 16.41f, 4f, 12f)
                curveTo(4f, 7.59f, 7.59f, 4f, 12f, 4f)
                curveTo(16.41f, 4f, 20f, 7.59f, 20f, 12f)
                curveTo(20f, 16.41f, 16.41f, 20f, 12f, 20f)
                close()
                moveTo(12f, 7f)
                curveTo(9.24f, 7f, 7f, 9.24f, 7f, 12f)
                curveTo(7f, 14.76f, 9.24f, 17f, 12f, 17f)
                curveTo(14.76f, 17f, 17f, 14.76f, 17f, 12f)
                horizontalLineTo(15f)
                curveTo(15f, 13.66f, 13.66f, 15f, 12f, 15f)
                curveTo(10.34f, 15f, 9f, 13.66f, 9f, 12f)
                curveTo(9f, 10.34f, 10.34f, 9f, 12f, 9f)
                verticalLineTo(7f)
                close()
                moveTo(12f, 10.5f)
                arcToRelative(1.5f, 1.5f, 0f, true, false, 0f, 3f)
                arcToRelative(1.5f, 1.5f, 0f, true, false, 0f, -3f)
                close()
            }
        }
    }

    val Dns: ImageVector by lazy {
        vec("Dns") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(20f, 13f)
                horizontalLineTo(4f)
                curveTo(3.45f, 13f, 3f, 13.45f, 3f, 14f)
                verticalLineTo(20f)
                curveTo(3f, 20.55f, 3.45f, 21f, 4f, 21f)
                horizontalLineTo(20f)
                curveTo(20.55f, 21f, 21f, 20.55f, 21f, 20f)
                verticalLineTo(14f)
                curveTo(21f, 13.45f, 20.55f, 13f, 20f, 13f)
                close()
                moveTo(7f, 19f)
                curveTo(5.9f, 19f, 5f, 18.1f, 5f, 17f)
                curveTo(5f, 15.9f, 5.9f, 15f, 7f, 15f)
                curveTo(8.1f, 15f, 9f, 15.9f, 9f, 17f)
                curveTo(9f, 18.1f, 8.1f, 19f, 7f, 19f)
                close()
                moveTo(20f, 3f)
                horizontalLineTo(4f)
                curveTo(3.45f, 3f, 3f, 3.45f, 3f, 4f)
                verticalLineTo(10f)
                curveTo(3f, 10.55f, 3.45f, 11f, 4f, 11f)
                horizontalLineTo(20f)
                curveTo(20.55f, 11f, 21f, 10.55f, 21f, 10f)
                verticalLineTo(4f)
                curveTo(21f, 3.45f, 20.55f, 3f, 20f, 3f)
                close()
                moveTo(7f, 9f)
                curveTo(5.9f, 9f, 5f, 8.1f, 5f, 7f)
                curveTo(5f, 5.9f, 5.9f, 5f, 7f, 5f)
                curveTo(8.1f, 5f, 9f, 5.9f, 9f, 7f)
                curveTo(9f, 8.1f, 8.1f, 9f, 7f, 9f)
                close()
            }
        }
    }

    val Bolt: ImageVector by lazy {
        vec("Bolt") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(11f, 21f)
                horizontalLineTo(10f)
                lineTo(11f, 14f)
                horizontalLineTo(7.5f)
                curveTo(6.62f, 14f, 6.23f, 13.02f, 6.72f, 12.28f)
                lineTo(13f, 3f)
                horizontalLineTo(14f)
                lineTo(13f, 10f)
                horizontalLineTo(16.5f)
                curveTo(17.38f, 10f, 17.77f, 10.98f, 17.28f, 11.72f)
                lineTo(11f, 21f)
                close()
            }
        }
    }

    val Tune: ImageVector by lazy {
        vec("Tune") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(3f, 17f)
                verticalLineTo(19f)
                horizontalLineTo(9f)
                verticalLineTo(17f)
                horizontalLineTo(3f)
                close()
                moveTo(3f, 5f)
                verticalLineTo(7f)
                horizontalLineTo(13f)
                verticalLineTo(5f)
                horizontalLineTo(3f)
                close()
                moveTo(13f, 21f)
                verticalLineTo(19f)
                horizontalLineTo(21f)
                verticalLineTo(17f)
                horizontalLineTo(13f)
                verticalLineTo(15f)
                horizontalLineTo(11f)
                verticalLineTo(21f)
                horizontalLineTo(13f)
                close()
                moveTo(7f, 9f)
                verticalLineTo(11f)
                horizontalLineTo(3f)
                verticalLineTo(13f)
                horizontalLineTo(7f)
                verticalLineTo(15f)
                horizontalLineTo(9f)
                verticalLineTo(9f)
                horizontalLineTo(7f)
                close()
                moveTo(21f, 13f)
                verticalLineTo(11f)
                horizontalLineTo(11f)
                verticalLineTo(13f)
                horizontalLineTo(21f)
                close()
                moveTo(15f, 9f)
                horizontalLineTo(17f)
                verticalLineTo(7f)
                horizontalLineTo(21f)
                verticalLineTo(5f)
                horizontalLineTo(17f)
                verticalLineTo(3f)
                horizontalLineTo(15f)
                verticalLineTo(9f)
                close()
            }
        }
    }

    val Compress: ImageVector by lazy {
        vec("Compress") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(8f, 19f)
                horizontalLineTo(11f)
                verticalLineTo(22f)
                horizontalLineTo(13f)
                verticalLineTo(19f)
                horizontalLineTo(16f)
                lineTo(12f, 15f)
                lineTo(8f, 19f)
                close()
                moveTo(16f, 5f)
                horizontalLineTo(13f)
                verticalLineTo(2f)
                horizontalLineTo(11f)
                verticalLineTo(5f)
                horizontalLineTo(8f)
                lineTo(12f, 9f)
                lineTo(16f, 5f)
                close()
                moveTo(4f, 13f)
                horizontalLineTo(20f)
                verticalLineTo(11f)
                horizontalLineTo(4f)
                verticalLineTo(13f)
                close()
            }
        }
    }

    val VpnKey: ImageVector by lazy {
        vec("VpnKey") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12.65f, 10f)
                curveTo(11.83f, 7.67f, 9.61f, 6f, 7f, 6f)
                curveTo(3.69f, 6f, 1f, 8.69f, 1f, 12f)
                curveTo(1f, 15.31f, 3.69f, 18f, 7f, 18f)
                curveTo(9.61f, 18f, 11.83f, 16.33f, 12.65f, 14f)
                horizontalLineTo(17f)
                verticalLineTo(18f)
                horizontalLineTo(21f)
                verticalLineTo(14f)
                horizontalLineTo(23f)
                verticalLineTo(10f)
                horizontalLineTo(12.65f)
                close()
                moveTo(7f, 14f)
                curveTo(5.9f, 14f, 5f, 13.1f, 5f, 12f)
                curveTo(5f, 10.9f, 5.9f, 10f, 7f, 10f)
                curveTo(8.1f, 10f, 9f, 10.9f, 9f, 12f)
                curveTo(9f, 13.1f, 8.1f, 14f, 7f, 14f)
                close()
            }
        }
    }

    val DarkMode: ImageVector by lazy {
        vec("DarkMode") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 3f)
                curveTo(7.03f, 3f, 3f, 7.03f, 3f, 12f)
                curveTo(3f, 16.97f, 7.03f, 21f, 12f, 21f)
                curveTo(16.97f, 21f, 21f, 16.97f, 21f, 12f)
                curveTo(21f, 11.54f, 20.96f, 11.08f, 20.9f, 10.64f)
                curveTo(19.92f, 12.01f, 18.32f, 12.9f, 16.5f, 12.9f)
                curveTo(13.52f, 12.9f, 11.1f, 10.48f, 11.1f, 7.5f)
                curveTo(11.1f, 5.69f, 11.99f, 4.08f, 13.36f, 3.1f)
                curveTo(12.92f, 3.04f, 12.46f, 3f, 12f, 3f)
                close()
            }
        }
    }

    val LightMode: ImageVector by lazy {
        vec("LightMode") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 7f)
                curveTo(9.24f, 7f, 7f, 9.24f, 7f, 12f)
                curveTo(7f, 14.76f, 9.24f, 17f, 12f, 17f)
                curveTo(14.76f, 17f, 17f, 14.76f, 17f, 12f)
                curveTo(17f, 9.24f, 14.76f, 7f, 12f, 7f)
                close()
                moveTo(11f, 1f)
                horizontalLineTo(13f)
                verticalLineTo(4f)
                horizontalLineTo(11f)
                close()
                moveTo(11f, 20f)
                horizontalLineTo(13f)
                verticalLineTo(23f)
                horizontalLineTo(11f)
                close()
                moveTo(1f, 11f)
                horizontalLineTo(4f)
                verticalLineTo(13f)
                horizontalLineTo(1f)
                close()
                moveTo(20f, 11f)
                horizontalLineTo(23f)
                verticalLineTo(13f)
                horizontalLineTo(20f)
                close()
            }
        }
    }

    val FileDownload: ImageVector by lazy {
        vec("FileDownload") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(19f, 9f)
                horizontalLineTo(15f)
                verticalLineTo(3f)
                horizontalLineTo(9f)
                verticalLineTo(9f)
                horizontalLineTo(5f)
                lineTo(12f, 16f)
                lineTo(19f, 9f)
                close()
                moveTo(5f, 18f)
                verticalLineTo(20f)
                horizontalLineTo(19f)
                verticalLineTo(18f)
                horizontalLineTo(5f)
                close()
            }
        }
    }

    val AutoFix: ImageVector by lazy {
        vec("AutoFix") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(7.5f, 5.6f)
                lineTo(10f, 7f)
                lineTo(8.6f, 4.5f)
                lineTo(10f, 2f)
                lineTo(7.5f, 3.4f)
                lineTo(5f, 2f)
                lineTo(6.4f, 4.5f)
                lineTo(5f, 7f)
                close()
                moveTo(19.5f, 15.4f)
                lineTo(17f, 14f)
                lineTo(18.4f, 16.5f)
                lineTo(17f, 19f)
                lineTo(19.5f, 17.6f)
                lineTo(22f, 19f)
                lineTo(20.6f, 16.5f)
                lineTo(22f, 14f)
                close()
                moveTo(14.37f, 7.29f)
                lineTo(2.29f, 19.37f)
                lineTo(4.63f, 21.71f)
                lineTo(16.71f, 9.63f)
                close()
            }
        }
    }

    val MenuBook: ImageVector by lazy {
        vec("MenuBook") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(21f, 5f)
                curveTo(19.89f, 4.65f, 18.67f, 4.5f, 17.5f, 4.5f)
                curveTo(15.55f, 4.5f, 13.45f, 4.9f, 12f, 6f)
                curveTo(10.55f, 4.9f, 8.45f, 4.5f, 6.5f, 4.5f)
                curveTo(4.55f, 4.5f, 2.45f, 4.9f, 1f, 6f)
                verticalLineTo(20.65f)
                curveTo(1f, 20.9f, 1.25f, 21.15f, 1.5f, 21.15f)
                curveTo(1.6f, 21.15f, 1.65f, 21.1f, 1.75f, 21.1f)
                curveTo(3.1f, 20.45f, 5.05f, 20f, 6.5f, 20f)
                curveTo(8.45f, 20f, 10.55f, 20.4f, 12f, 21.5f)
                curveTo(13.35f, 20.65f, 15.8f, 20f, 17.5f, 20f)
                curveTo(19.15f, 20f, 20.85f, 20.3f, 22.25f, 21.05f)
                curveTo(22.35f, 21.1f, 22.4f, 21.1f, 22.5f, 21.1f)
                curveTo(22.75f, 21.1f, 23f, 20.85f, 23f, 20.6f)
                verticalLineTo(6f)
                curveTo(22.4f, 5.55f, 21.75f, 5.25f, 21f, 5f)
                close()
                moveTo(21f, 18.5f)
                curveTo(19.9f, 18.15f, 18.7f, 18f, 17.5f, 18f)
                curveTo(15.8f, 18f, 13.35f, 18.65f, 12f, 19.5f)
                verticalLineTo(8f)
                curveTo(13.35f, 7.15f, 15.8f, 6.5f, 17.5f, 6.5f)
                curveTo(18.7f, 6.5f, 19.9f, 6.65f, 21f, 7f)
                verticalLineTo(18.5f)
                close()
            }
        }
    }


    val Terminal: ImageVector by lazy {
        vec("Terminal") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(20f, 4f)
                horizontalLineTo(4f)
                curveTo(2.89f, 4f, 2f, 4.9f, 2f, 6f)
                verticalLineTo(18f)
                curveTo(2f, 19.1f, 2.89f, 20f, 4f, 20f)
                horizontalLineTo(20f)
                curveTo(21.1f, 20f, 22f, 19.1f, 22f, 18f)
                verticalLineTo(6f)
                curveTo(22f, 4.9f, 21.1f, 4f, 20f, 4f)
                close()
                moveTo(20f, 18f)
                horizontalLineTo(4f)
                verticalLineTo(8f)
                horizontalLineTo(20f)
                verticalLineTo(18f)
                close()
                moveTo(18f, 17f)
                horizontalLineTo(12f)
                verticalLineTo(15f)
                horizontalLineTo(18f)
                verticalLineTo(17f)
                close()
                moveTo(7.5f, 17f)
                lineTo(6.09f, 15.59f)
                lineTo(8.67f, 13f)
                lineTo(6.09f, 10.41f)
                lineTo(7.5f, 9f)
                lineTo(11.5f, 13f)
                lineTo(7.5f, 17f)
                close()
            }
        }
    }

    val Search: ImageVector by lazy {
        vec("Search") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(15.5f, 14f)
                horizontalLineTo(14.71f)
                lineTo(14.43f, 13.73f)
                curveTo(15.41f, 12.59f, 16f, 11.11f, 16f, 9.5f)
                curveTo(16f, 5.91f, 13.09f, 3f, 9.5f, 3f)
                reflectiveCurveTo(3f, 5.91f, 3f, 9.5f)
                reflectiveCurveTo(5.91f, 16f, 9.5f, 16f)
                curveTo(11.11f, 16f, 12.59f, 15.41f, 13.73f, 14.43f)
                lineTo(14f, 14.71f)
                verticalLineTo(15.5f)
                lineTo(19f, 20.49f)
                lineTo(20.49f, 19f)
                lineTo(15.5f, 14f)
                close()
                moveTo(9.5f, 14f)
                curveTo(7.01f, 14f, 5f, 11.99f, 5f, 9.5f)
                reflectiveCurveTo(7.01f, 5f, 9.5f, 5f)
                reflectiveCurveTo(14f, 7.01f, 14f, 9.5f)
                reflectiveCurveTo(11.99f, 14f, 9.5f, 14f)
                close()
            }
        }
    }

    val Close: ImageVector by lazy {
        vec("Close") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(19f, 6.41f)
                lineTo(17.59f, 5f)
                lineTo(12f, 10.59f)
                lineTo(6.41f, 5f)
                lineTo(5f, 6.41f)
                lineTo(10.59f, 12f)
                lineTo(5f, 17.59f)
                lineTo(6.41f, 19f)
                lineTo(12f, 13.41f)
                lineTo(17.59f, 19f)
                lineTo(19f, 17.59f)
                lineTo(13.41f, 12f)
                close()
            }
        }
    }

    private fun vec(name: String, block: ImageVector.Builder.() -> Unit): ImageVector {
        return ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply(block).build()
    }
}
