package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.logging.LogLevel
import com.example.core.logging.TunnelLogEntry
import com.example.core.logging.TunnelLogger
import com.example.core.logging.TunnelStats
import com.example.data.local.ConnectionReportEntity
import com.example.ui.components.AppIcons
import com.example.ui.components.formatBytesHuman
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.AzarakhshSuccess
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.VioletTertiary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.RoseError
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class ReportSection(val label: String) {
    SESSIONS("جلسه‌ها"),
    DIAGNOSIS("تشخیص"),
    PROBLEMS("مشکل‌ها"),
    ALL("لاگ‌ها")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    reports: List<ConnectionReportEntity>,
    logs: List<TunnelLogEntry>,
    isLogsPaused: Boolean,
    onTogglePause: () -> Unit,
    onClearLogs: () -> Unit,
    onClearReports: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var section by rememberSaveable { mutableStateOf(ReportSection.SESSIONS) }
    val problemCount = remember(logs) { logs.count { it.level == LogLevel.WARN || it.level == LogLevel.ERROR } }
    val hasErrors = remember(logs) { logs.any { it.level == LogLevel.ERROR } }

    Column(modifier = modifier.fillMaxSize()) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ReportSection.entries.forEach { sec ->
                    val selected = section == sec
                    val title = if (sec == ReportSection.PROBLEMS && problemCount > 0) {
                        "${sec.label} ($problemCount)"
                    } else sec.label
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { section = sec }
                            .testTag("report_section_${sec.name.lowercase()}"),
                        shape = MaterialTheme.shapes.small,
                        color = if (selected) VioletTertiary.copy(alpha = 0.25f) else Color.Transparent,
                        border = if (selected) BorderStroke(1.dp, CyanSecondary.copy(alpha = 0.5f)) else null
                    ) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            color = when {
                                selected -> CyanSecondary
                                sec == ReportSection.PROBLEMS && problemCount > 0 -> if (hasErrors) RoseError else AmberWarning
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 2.dp)
                        )
                    }
                }
            }
        }

        when (section) {
            ReportSection.SESSIONS -> SessionsPanel(reports, onClearReports, Modifier.weight(1f))
            ReportSection.DIAGNOSIS -> DiagnosisPanel(logs.size, onShowMessage, Modifier.weight(1f))
            ReportSection.PROBLEMS -> {
                val problemLogs = remember(logs) {
                    logs.filter { it.level == LogLevel.WARN || it.level == LogLevel.ERROR }
                }
                LogsPanel(
                    logs = problemLogs,
                    isPaused = isLogsPaused,
                    onTogglePause = onTogglePause,
                    onClearLogs = onClearLogs,
                    onShowMessage = onShowMessage,
                    modifier = Modifier.weight(1f)
                )
            }
            ReportSection.ALL -> {
                LogsPanel(
                    logs = logs,
                    isPaused = isLogsPaused,
                    onTogglePause = onTogglePause,
                    onClearLogs = onClearLogs,
                    onShowMessage = onShowMessage,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun DiagnosisPanel(logCount: Int, onShowMessage: (String) -> Unit, modifier: Modifier = Modifier) {
    val clipboard = LocalClipboardManager.current
    var refreshKey by remember { mutableIntStateOf(0) }
    val report = remember(logCount, refreshKey) { TunnelStats.report() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = { refreshKey++ },
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Icon(AppIcons.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("بروزرسانی", style = MaterialTheme.typography.labelLarge)
            }
            OutlinedButton(
                onClick = {
                    clipboard.setText(AnnotatedString(TunnelLogger.exportAsText()))
                    onShowMessage("گزارش کامل + لاگ‌ها کپی شد")
                },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Icon(AppIcons.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("کپی گزارش کامل", style = MaterialTheme.typography.labelLarge)
            }
        }

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                SelectionContainer {
                    Text(
                        text = report,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            lineHeight = 16.sp
                        ),
                        modifier = Modifier
                            .verticalScroll(rememberScrollState())
                            .padding(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SessionsPanel(
    reports: List<ConnectionReportEntity>,
    onClearReports: () -> Unit,
    modifier: Modifier = Modifier
) {
    val avgStability = if (reports.isEmpty()) 100f else reports.map { it.stabilityScore }.average().toFloat()
    val totalTraffic = reports.sumOf { it.downloadBytes + it.uploadBytes }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ReportKpiCard(
                    title = "پایداری",
                    value = "${avgStability.toInt()}%",
                    accent = EmeraldPrimary,
                    modifier = Modifier.weight(1f)
                )
                ReportKpiCard(
                    title = "جلسه‌ها",
                    value = "${reports.size}",
                    accent = CyanSecondary,
                    modifier = Modifier.weight(1f)
                )
                ReportKpiCard(
                    title = "کل ترافیک",
                    value = formatBytesHuman(totalTraffic),
                    accent = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "نمودار پایداری جلسات اخیر",
                        style = MaterialTheme.typography.titleSmall
                    )
                    if (reports.isEmpty()) {
                        Text(
                            text = "هنوز گزارشی ثبت نشده است؛ پس از قطع هر اتصال، خلاصه آن این‌جا ذخیره می‌شود.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        val recent = reports.take(8).reversed()
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(92.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                            verticalAlignment = Alignment.Bottom
                        ) {
                            recent.forEach { rep ->
                                val frac = (rep.stabilityScore / 100f).coerceIn(0.12f, 1f)
                                val barColor = when {
                                    rep.stabilityScore >= 80f -> AzarakhshSuccess
                                    rep.stabilityScore >= 50f -> AmberWarning
                                    else -> RoseError
                                }
                                Column(
                                    modifier = Modifier
                                        .weight(1f, fill = false)
                                        .widthIn(min = 24.dp, max = 38.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Bottom
                                ) {
                                    Text(
                                        text = "${rep.stabilityScore.toInt()}%",
                                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily, fontSize = 10.sp),
                                        color = barColor
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .width(22.dp)
                                            .height(64.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant),
                                        contentAlignment = Alignment.BottomCenter
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .fillMaxHeight(frac)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(barColor)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(AppIcons.Assessment, contentDescription = null, tint = CyanSecondary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تاریخچه جلسات (${reports.size})",
                        style = MaterialTheme.typography.titleSmall
                    )
                }
                if (reports.isNotEmpty()) {
                    IconButton(onClick = onClearReports, modifier = Modifier.size(32.dp)) {
                        Icon(AppIcons.Delete, contentDescription = "پاک کردن تاریخچه گزارش‌ها", tint = RoseError, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        items(reports, key = { it.id }) { report ->
            val scoreColor = when {
                report.stabilityScore >= 80f -> EmeraldPrimary
                report.stabilityScore >= 55f -> AmberWarning
                else -> RoseError
            }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${report.protocolName} • ${report.endpointSummary}",
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = scoreColor.copy(alpha = 0.16f)
                        ) {
                            Text(
                                text = "${report.stabilityScore.toInt()}%",
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                fontWeight = FontWeight.Bold,
                                color = scoreColor,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = formatTimestamp(report.startedAtMs),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(
                                text = "${report.avgLatencyMs}ms • ↓${formatBytesHuman(report.downloadBytes)} ↑${formatBytesHuman(report.uploadBytes)}",
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = CyanSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportKpiCard(
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                    fontWeight = FontWeight.Bold,
                    color = accent,
                    maxLines = 1
                )
            }
        }
    }
}

private fun formatTimestamp(ms: Long): String {
    return SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(ms))
}
