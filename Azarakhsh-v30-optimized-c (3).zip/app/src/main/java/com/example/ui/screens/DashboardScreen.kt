package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.data.model.BypassSettings
import com.example.data.model.TunnelConnectionState
import com.example.data.model.TunnelProtocol
import com.example.data.model.TunnelTelemetry
import com.example.ui.components.AppIcons
import com.example.ui.components.PowerConnectOrb
import com.example.ui.components.RealTimeSpeedChart
import com.example.ui.components.formatBytesHuman
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.AzarakhshSuccess
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.VioletTertiary
import com.example.ui.theme.JetBrainsMonoFontFamily
import kotlinx.coroutines.delay

@Composable
fun DashboardScreen(
    telemetry: TunnelTelemetry,
    settings: BypassSettings,
    isProbing: Boolean = false,
    onPowerClick: () -> Unit,
    onProtocolSelected: (TunnelProtocol) -> Unit,
    onToggleTlsFrag: (Boolean) -> Unit,
    onToggleMitmHttp2: (Boolean) -> Unit,
    onToggleMtProtoHttpBridge: (Boolean) -> Unit,
    onToggleLogDedup: (Boolean) -> Unit,
    onToggleThermalGuard: (Boolean) -> Unit,
    onToggleCleanIp: (Boolean) -> Unit,
    onToggleKeepAlive: (Boolean) -> Unit,
    onToggleDoh: (Boolean) -> Unit,
    onToggleVpnMode: (Boolean) -> Unit,
    onProbeTunnel: () -> Unit,
    isCaInstalled: Boolean = false,
    onInstallCaClick: () -> Unit = {},
    onNavigateToServers: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboard = LocalClipboardManager.current
    var showAdvancedBypass by remember { mutableStateOf(false) }

    val isConnected = telemetry.connectionState == TunnelConnectionState.CONNECTED

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Compact Hero Connection Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.extraLarge,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp, horizontal = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    PowerConnectOrb(
                        state = telemetry.connectionState,
                        onClick = onPowerClick
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = telemetry.connectionState.titleFa,
                            style = MaterialTheme.typography.titleSmall,
                            color = if (isConnected) AzarakhshSuccess else MaterialTheme.colorScheme.onSurface
                        )
                        if (isConnected && telemetry.connectedSinceMs > 0L) {
                            ConnectionDurationText(connectedSinceMs = telemetry.connectedSinceMs)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable(onClick = onNavigateToServers),
                            shape = MaterialTheme.shapes.medium,
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = AppIcons.Hub,
                                    contentDescription = null,
                                    tint = EmeraldPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "سرورها (${telemetry.activeEndpointCount})",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = telemetry.activeEndpointLabel,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    clipboard.setText(AnnotatedString(telemetry.activeSocksAddress))
                                    onShowMessage("آدرس SOCKS5 کپی شد")
                                },
                            shape = MaterialTheme.shapes.medium,
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "SOCKS5 محلی",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        Text(
                                            text = telemetry.activeSocksAddress,
                                            style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                                            color = CyanSecondary,
                                            maxLines = 1
                                        )
                                    }
                                }
                                Icon(
                                    imageVector = AppIcons.ContentCopy,
                                    contentDescription = "کپی آدرس ساکس۵",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Compact Protocol + MITM CA Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.background
                    ) {
                        @OptIn(ExperimentalLayoutApi::class)
                        FlowRow(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(6.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            TunnelProtocol.entries.forEach { proto ->
                                val selected = settings.protocol == proto
                                val shortLabel = when (proto) {
                                    TunnelProtocol.GAS_PARALLEL -> "موازی گوگل"
                                    TunnelProtocol.CF_WEBSOCKET -> "کلودفلر WS"
                                    TunnelProtocol.HYBRID_SMART -> "هوشمند"
                                    else -> proto.titleFa
                                }
                                Surface(
                                    modifier = Modifier
                                        .clickable { onProtocolSelected(proto) }
                                        .testTag("protocol_chip_${proto.name.lowercase()}"),
                                    shape = MaterialTheme.shapes.small,
                                    color = if (selected) VioletTertiary.copy(alpha = 0.24f) else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(
                                        1.dp,
                                        if (selected) CyanSecondary.copy(alpha = 0.65f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                                    )
                                ) {
                                    Text(
                                        text = shortLabel,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (selected) CyanSecondary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(vertical = 7.dp, horizontal = 10.dp)
                                    )
                                }
                            }
                        }
                    }

                    Text(
                        text = settings.protocol.subtitleFa,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (settings.protocol == TunnelProtocol.GAS_PARALLEL || settings.protocol == TunnelProtocol.HYBRID_SMART) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                        if (isCaInstalled) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(AppIcons.CheckCircle, contentDescription = null, tint = AzarakhshSuccess, modifier = Modifier.size(16.dp))
                                    Text("گواهی HTTPS (MITM) نصب و آماده است", style = MaterialTheme.typography.labelSmall, color = AzarakhshSuccess)
                                }
                                Text(
                                    text = "نصب مجدد",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyanSecondary,
                                    modifier = Modifier
                                        .clickable(onClick = onInstallCaClick)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                        .testTag("install_mitm_ca_button")
                                )
                            }
                        } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isCaInstalled) AppIcons.CheckCircle else AppIcons.Lock,
                                    contentDescription = null,
                                    tint = if (isCaInstalled) EmeraldPrimary else CyanSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "گواهی رله گوگل (MITM)",
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                    Text(
                                        text = if (isCaInstalled) "نصب‌شده • آماده رله HTTPS" else "برای باز شدن سایت‌ها گواهی را نصب کنید",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            OutlinedButton(
                                onClick = onInstallCaClick,
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("install_mitm_ca_button")
                            ) {
                                Text(
                                    text = "نصب گواهی",
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                        }
                    }
                }
            }
        }

        // 3. Speed Chart + Compact Stats + Live Probe
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                RealTimeSpeedChart(
                    samples = telemetry.speedHistory,
                    currentDownKbps = telemetry.downloadKbps,
                    currentUpKbps = telemetry.uploadKbps
                )

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TrafficStatMini("دریافت", formatBytesHuman(telemetry.totalDownloadBytes))
                            TrafficStatMini("ارسال", formatBytesHuman(telemetry.totalUploadBytes))
                            TrafficStatMini(
                                "پینگ",
                                if (telemetry.currentLatencyMs > 0) "${telemetry.currentLatencyMs}ms" else "—"
                            )
                            TrafficStatMini("پایداری", "${telemetry.stabilityScore.toInt()}%")
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val gasLabel = if (telemetry.gasUrlFetches > telemetry.gasRequests) {
                                "${telemetry.gasRequests} (${telemetry.gasUrlFetches})"
                            } else {
                                "${telemetry.gasRequests}"
                            }
                            TrafficStatMini("درخواست گوگل", gasLabel)
                            TrafficStatMini("صرفه‌جویی کش", "${telemetry.gasSavedRequests}")
                            TrafficStatMini("درخواست کلودفلر", "${telemetry.cfRequests}")
                            val tempLabel = if (telemetry.batteryTempC > 0f) {
                                val ch = if (telemetry.batteryCharging) "⚡" else ""
                                val th = if (telemetry.thermalThrottled) " • خنک‌سازی" else ""
                                "${"%.1f".format(telemetry.batteryTempC)}°C$ch$th"
                            } else {
                                "—"
                            }
                            TrafficStatMini("دمای گوشی", tempLabel)
                        }

                        OutlinedButton(
                            onClick = onProbeTunnel,
                            enabled = !isProbing,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("live_probe_button")
                        ) {
                            if (isProbing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("در حال تست زنده...")
                            } else {
                                Icon(AppIcons.Speed, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تست زنده تونل و DoH")
                            }
                        }
                    }
                }
            }
        }

        // 4. Collapsible Bypass Settings
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showAdvancedBypass = !showAdvancedBypass },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = AppIcons.Tune,
                                contentDescription = null,
                                tint = CyanSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "تنظیمات دور زدن فیلترینگ",
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = buildString {
                                        append(if (settings.vpnModeEnabled) "VPN" else "SOCKS5")
                                        if (settings.tlsFragmentation) append(" • Fragment")
                                        if (settings.cleanIpBinding) append(" • CleanIP")
                                        if (settings.dohEnabled) append(" • DoH")
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Icon(
                            imageVector = if (showAdvancedBypass) AppIcons.ExpandLess else AppIcons.ExpandMore,
                            contentDescription = "باز و بسته کردن تنظیمات"
                        )
                    }

                    AnimatedVisibility(visible = showAdvancedBypass) {
                        Column(
                            modifier = Modifier.padding(top = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

                            BypassToggleRow(
                                icon = AppIcons.VpnKey,
                                title = "حالت VPN سراسری دستگاه",
                                subtitle = "در صورت خاموش بودن، فقط SOCKS5 اجرا می‌شود",
                                checked = settings.vpnModeEnabled,
                                onCheckedChange = { next ->
                                    onToggleVpnMode(next)
                                    if (isConnected) onShowMessage("برای اعمال حالت VPN، اتصال را قطع و وصل کنید")
                                }
                            )
                            BypassToggleRow(
                                icon = AppIcons.Tune,
                                title = "تکه‌تکه‌سازی TLS (Fragment)",
                                subtitle = "عبور از فیلترینگ SNI در مسیر مستقیم",
                                checked = settings.tlsFragmentation,
                                onCheckedChange = onToggleTlsFrag
                            )
                            BypassToggleRow(
                                icon = AppIcons.Bolt,
                                title = "پروتکل HTTP/2 در MITM",
                                subtitle = "رفع سقف ۶ اتصال هم‌زمان مرورگر (آزمایشی)",
                                checked = settings.mitmHttp2Enabled,
                                onCheckedChange = onToggleMitmHttp2
                            )
                            BypassToggleRow(
                                icon = AppIcons.Bolt,
                                title = "پل HTTP به MTProto تلگرام (GAS)",
                                subtitle = "عبور ترافیک تلگرام روی SOCKS5 از گوگل اسکریپت با دو متود (/apiw1 و /api)",
                                checked = settings.mtProtoHttpBridgeEnabled,
                                onCheckedChange = onToggleMtProtoHttpBridge
                            )
                            BypassToggleRow(
                                icon = AppIcons.Tune,
                                title = "ضد اسپم لاگ (خلاصه‌سازی تکرارها)",
                                subtitle = "جلوگیری از ثبت هزاران لاگ تکراری در بازه ۵ ثانیه‌ای",
                                checked = settings.logDedupEnabled,
                                onCheckedChange = onToggleLogDedup
                            )
                            BypassToggleRow(
                                icon = AppIcons.Speed,
                                title = "کنترل هوشمند دما (Thermal Guard)",
                                subtitle = "کاهش هم‌زمانی و فشرده‌سازی هنگام داغ شدن گوشی (>42°C)",
                                checked = settings.thermalGuardEnabled,
                                onCheckedChange = onToggleThermalGuard
                            )
                            BypassToggleRow(
                                icon = AppIcons.Dns,
                                title = "اتصال با آی‌پی تمیز",
                                subtitle = "استفاده از سریع‌ترین آی‌پی گوگل و کلودفلر",
                                checked = settings.cleanIpBinding,
                                onCheckedChange = onToggleCleanIp
                            )
                            BypassToggleRow(
                                icon = AppIcons.Bolt,
                                title = "نگهدارنده اتصال (Keep-Alive)",
                                subtitle = "پایش دوره‌ای و سوئیچ به سرور سالم",
                                checked = settings.adaptiveKeepAlive,
                                onCheckedChange = onToggleKeepAlive
                            )
                            BypassToggleRow(
                                icon = AppIcons.Dns,
                                title = "DNS رمزنگاری‌شده (DoH)",
                                subtitle = "جلوگیری از مسمومیت DNS",
                                checked = settings.dohEnabled,
                                onCheckedChange = { next ->
                                    onToggleDoh(next)
                                    if (isConnected) onShowMessage("برای تغییر سرور DNS تونل، اتصال را قطع و وصل کنید")
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TrafficStatMini(label: String, value: String) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(2.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun BypassToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.bodyMedium)
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = null)
    }
}

private fun formatTimer(totalSeconds: Long): String {
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return String.format("%02d:%02d:%02d", h, m, s)
}

@Composable
private fun ConnectionDurationText(connectedSinceMs: Long) {
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(connectedSinceMs) {
        while (true) {
            nowMs = System.currentTimeMillis()
            delay(1000L)
        }
    }
    val elapsedSec = ((nowMs - connectedSinceMs) / 1000L).coerceAtLeast(0L)
    if (elapsedSec > 0L) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(
                text = formatTimer(elapsedSec),
                style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
