cmake_minimum_required(VERSION 3.22.1)
project("tun_native" C)

add_library(
    tun_native
    SHARED
    tun_native.c
)

target_compile_options(tun_native PRIVATE -O3 -Wall -Wextra)

find_library(log-lib log)
target_link_libraries(tun_native ${log-lib})
