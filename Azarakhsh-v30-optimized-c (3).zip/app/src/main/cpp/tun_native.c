#include <jni.h>
#include <stdint.h>
#include <string.h>

static inline uint32_t fold_sum(uint64_t sum) {
    while (sum >> 16) {
        sum = (sum & 0xFFFFu) + (sum >> 16);
    }
    return (uint32_t)(~sum & 0xFFFFu);
}

static uint64_t ones_complement_acc(const uint8_t *data, int offset, int length, uint64_t initial) {
    uint64_t sum = initial;
    const uint8_t *p = data + offset;
    int i = 0;
    while (i + 1 < length) {
        sum += ((uint32_t)p[i] << 8) | (uint32_t)p[i + 1];
        i += 2;
    }
    if (i < length) {
        sum += ((uint32_t)p[i] << 8);
    }
    return sum;
}

JNIEXPORT jint JNICALL
Java_com_example_network_NativeTunHelper_nativeOnesComplementSum(
        JNIEnv *env,
        jobject thiz,
        jbyteArray data,
        jint offset,
        jint length,
        jlong initial) {
    (void)thiz;
    if (!data || offset < 0 || length < 0) return 0;
    jsize arr_len = (*env)->GetArrayLength(env, data);
    if (offset + length > arr_len) return 0;

    jbyte *buf = (*env)->GetPrimitiveArrayCritical(env, data, NULL);
    if (!buf) return 0;
    uint64_t sum = ones_complement_acc((const uint8_t *)buf, offset, length, (uint64_t)initial);
    (*env)->ReleasePrimitiveArrayCritical(env, data, buf, JNI_ABORT);
    return (jint)fold_sum(sum);
}

JNIEXPORT jint JNICALL
Java_com_example_network_NativeTunHelper_nativeBuildTcpPacket(
        JNIEnv *env,
        jobject thiz,
        jbyteArray out_arr,
        jbyteArray src_ip_arr,
        jbyteArray dst_ip_arr,
        jint src_port,
        jint dst_port,
        jlong seq,
        jlong ack,
        jint flags,
        jint window,
        jint mss,
        jbyteArray payload_arr,
        jint payload_off,
        jint payload_len) {
    (void)thiz;
    if (!out_arr || !src_ip_arr || !dst_ip_arr) return -1;
    if (payload_len < 0 || payload_off < 0) return -1;

    int include_mss = (mss > 0) ? 1 : 0;
    int opt_len = include_mss ? 4 : 0;
    int tcp_header_len = 20 + opt_len;
    int total_len = 20 + tcp_header_len + payload_len;

    jsize out_cap = (*env)->GetArrayLength(env, out_arr);
    if (total_len > out_cap) return -1;

    uint8_t *out = (uint8_t *)(*env)->GetPrimitiveArrayCritical(env, out_arr, NULL);
    if (!out) return -1;

    jbyte *src_ip = (*env)->GetPrimitiveArrayCritical(env, src_ip_arr, NULL);
    jbyte *dst_ip = (*env)->GetPrimitiveArrayCritical(env, dst_ip_arr, NULL);
    jbyte *payload = NULL;
    if (payload_arr && payload_len > 0) {
        payload = (*env)->GetPrimitiveArrayCritical(env, payload_arr, NULL);
    }

    if (!src_ip || !dst_ip || (payload_len > 0 && payload_arr && !payload)) {
        if (payload) (*env)->ReleasePrimitiveArrayCritical(env, payload_arr, (jbyte *)payload, JNI_ABORT);
        if (dst_ip) (*env)->ReleasePrimitiveArrayCritical(env, dst_ip_arr, dst_ip, JNI_ABORT);
        if (src_ip) (*env)->ReleasePrimitiveArrayCritical(env, src_ip_arr, src_ip, JNI_ABORT);
        (*env)->ReleasePrimitiveArrayCritical(env, out_arr, (jbyte *)out, JNI_ABORT);
        return -1;
    }

    // Zero only the fixed 40-byte header (+ 4 bytes if MSS)
    memset(out, 0, (size_t)(20 + tcp_header_len));

    // IPv4 Header
    out[0] = 0x45;
    out[1] = 0x00;
    out[2] = (uint8_t)((total_len >> 8) & 0xFF);
    out[3] = (uint8_t)(total_len & 0xFF);
    out[6] = 0x40; // DF
    out[8] = 64;   // TTL
    out[9] = 6;    // TCP
    memcpy(out + 12, dst_ip, 4); // src = remote dstIpBytes
    memcpy(out + 16, src_ip, 4); // dst = local srcIpBytes

    // TCP Header
    out[20] = (uint8_t)((dst_port >> 8) & 0xFF);
    out[21] = (uint8_t)(dst_port & 0xFF);
    out[22] = (uint8_t)((src_port >> 8) & 0xFF);
    out[23] = (uint8_t)(src_port & 0xFF);

    uint32_t u_seq = (uint32_t)seq;
    uint32_t u_ack = (uint32_t)ack;
    out[24] = (uint8_t)((u_seq >> 24) & 0xFF);
    out[25] = (uint8_t)((u_seq >> 16) & 0xFF);
    out[26] = (uint8_t)((u_seq >> 8) & 0xFF);
    out[27] = (uint8_t)(u_seq & 0xFF);

    out[28] = (uint8_t)((u_ack >> 24) & 0xFF);
    out[29] = (uint8_t)((u_ack >> 16) & 0xFF);
    out[30] = (uint8_t)((u_ack >> 8) & 0xFF);
    out[31] = (uint8_t)(u_ack & 0xFF);

    out[32] = (uint8_t)(((tcp_header_len / 4) << 4) & 0xF0);
    out[33] = (uint8_t)(flags & 0x3F);
    out[34] = (uint8_t)((window >> 8) & 0xFF);
    out[35] = (uint8_t)(window & 0xFF);

    if (include_mss) {
        out[40] = 0x02;
        out[41] = 0x04;
        out[42] = (uint8_t)((mss >> 8) & 0xFF);
        out[43] = (uint8_t)(mss & 0xFF);
    }

    if (payload && payload_len > 0) {
        memcpy(out + 40, ((const uint8_t *)payload) + payload_off, (size_t)payload_len);
    }

    // Release input arrays before checksum (we already copied them into out)
    if (payload) (*env)->ReleasePrimitiveArrayCritical(env, payload_arr, (jbyte *)payload, JNI_ABORT);
    (*env)->ReleasePrimitiveArrayCritical(env, dst_ip_arr, dst_ip, JNI_ABORT);
    (*env)->ReleasePrimitiveArrayCritical(env, src_ip_arr, src_ip, JNI_ABORT);

    // IPv4 checksum
    uint32_t ip_sum = fold_sum(ones_complement_acc(out, 0, 20, 0));
    out[10] = (uint8_t)((ip_sum >> 8) & 0xFF);
    out[11] = (uint8_t)(ip_sum & 0xFF);

    // TCP pseudo-header + TCP checksum
    int tcp_len = tcp_header_len + payload_len;
    uint64_t pseudo = 0;
    for (int i = 12; i < 20; i += 2) {
        pseudo += ((uint32_t)out[i] << 8) | (uint32_t)out[i + 1];
    }
    pseudo += 6u;
    pseudo += (uint64_t)tcp_len;
    uint32_t tcp_sum = fold_sum(ones_complement_acc(out, 20, tcp_len, pseudo));
    out[20 + 16] = (uint8_t)((tcp_sum >> 8) & 0xFF);
    out[20 + 17] = (uint8_t)(tcp_sum & 0xFF);

    (*env)->ReleasePrimitiveArrayCritical(env, out_arr, (jbyte *)out, 0);
    return total_len;
}

JNIEXPORT jint JNICALL
Java_com_example_network_NativeTunHelper_nativeBuildUdpReply(
        JNIEnv *env,
        jobject thiz,
        jbyteArray out_arr,
        jbyteArray req_arr,
        jint req_ihl,
        jbyteArray payload_arr,
        jint payload_len) {
    (void)thiz;
    if (!out_arr || !req_arr || !payload_arr || payload_len < 0) return -1;
    int total_len = 28 + payload_len;
    if (total_len > (*env)->GetArrayLength(env, out_arr)) return -1;

    uint8_t *out = (uint8_t *)(*env)->GetPrimitiveArrayCritical(env, out_arr, NULL);
    uint8_t *req = (uint8_t *)(*env)->GetPrimitiveArrayCritical(env, req_arr, NULL);
    uint8_t *payload = (uint8_t *)(*env)->GetPrimitiveArrayCritical(env, payload_arr, NULL);
    if (!out || !req || !payload) {
        if (payload) (*env)->ReleasePrimitiveArrayCritical(env, payload_arr, (jbyte *)payload, JNI_ABORT);
        if (req) (*env)->ReleasePrimitiveArrayCritical(env, req_arr, (jbyte *)req, JNI_ABORT);
        if (out) (*env)->ReleasePrimitiveArrayCritical(env, out_arr, (jbyte *)out, JNI_ABORT);
        return -1;
    }

    memset(out, 0, 28);
    out[0] = 0x45;
    out[2] = (uint8_t)((total_len >> 8) & 0xFF);
    out[3] = (uint8_t)(total_len & 0xFF);
    out[4] = req[4];
    out[5] = req[5];
    out[6] = 0x40;
    out[8] = 64;
    out[9] = 17; // UDP
    memcpy(out + 12, req + 16, 4);
    memcpy(out + 16, req + 12, 4);

    out[20] = req[req_ihl + 2];
    out[21] = req[req_ihl + 3];
    out[22] = req[req_ihl];
    out[23] = req[req_ihl + 1];
    int udp_len = 8 + payload_len;
    out[24] = (uint8_t)((udp_len >> 8) & 0xFF);
    out[25] = (uint8_t)(udp_len & 0xFF);

    if (payload_len > 0) {
        memcpy(out + 28, payload, (size_t)payload_len);
    }

    (*env)->ReleasePrimitiveArrayCritical(env, payload_arr, (jbyte *)payload, JNI_ABORT);
    (*env)->ReleasePrimitiveArrayCritical(env, req_arr, (jbyte *)req, JNI_ABORT);

    uint32_t ip_sum = fold_sum(ones_complement_acc(out, 0, 20, 0));
    out[10] = (uint8_t)((ip_sum >> 8) & 0xFF);
    out[11] = (uint8_t)(ip_sum & 0xFF);

    (*env)->ReleasePrimitiveArrayCritical(env, out_arr, (jbyte *)out, 0);
    return total_len;
}
