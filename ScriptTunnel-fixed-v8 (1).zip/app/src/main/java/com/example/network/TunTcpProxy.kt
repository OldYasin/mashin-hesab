package com.example.network

import com.example.core.logging.LogCategory
import com.example.core.logging.TunnelLogger
import com.example.data.model.BypassSettings
import com.example.data.model.EndpointType
import com.example.data.model.TunnelProtocol
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

class TunTcpProxy(
    private val engine: ParallelTunnelEngine,
    private val tunOutput: OutputStream,
    private val settingsProvider: () -> BypassSettings
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val sessions = ConcurrentHashMap<TcpKey, TcpSession>()

    private data class TcpKey(
        val srcIp: Int,
        val srcPort: Int,
        val dstIp: Int,
        val dstPort: Int
    )

    fun handleOutboundTcpPacket(packet: ByteArray, length: Int) {
        if (length < 40) return
        val ihl = (packet[0].toInt() and 0x0F) * 4
        if (length < ihl + 20) return

        val srcIp = readInt(packet, 12)
        val dstIp = readInt(packet, 16)
        val srcPort = readUShort(packet, ihl)
        val dstPort = readUShort(packet, ihl + 2)
        val seq = readUInt(packet, ihl + 4)
        val ack = readUInt(packet, ihl + 8)
        val dataOffset = ((packet[ihl + 12].toInt() ushr 4) and 0x0F) * 4
        if (length < ihl + dataOffset) return

        val flags = packet[ihl + 13].toInt() and 0x3F
        val isFin = (flags and 0x01) != 0
        val isSyn = (flags and 0x02) != 0
        val isRst = (flags and 0x04) != 0
        val isAck = (flags and 0x10) != 0

        val payloadOffset = ihl + dataOffset
        val payloadLen = (length - payloadOffset).coerceAtLeast(0)
        val key = TcpKey(srcIp, srcPort, dstIp, dstPort)

        if (isRst) {
            sessions.remove(key)?.close(sendRst = false)
            return
        }

        if (isSyn && !isAck) {
            sessions.remove(key)?.close(sendRst = false)
            val session = TcpSession(
                key = key,
                clientInitialSeq = seq,
                srcIpBytes = packet.copyOfRange(12, 16),
                dstIpBytes = packet.copyOfRange(16, 20)
            )
            sessions[key] = session
            session.start()
            return
        }

        val session = sessions[key] ?: return

        if (payloadLen > 0) {
            val data = packet.copyOfRange(payloadOffset, payloadOffset + payloadLen)
            session.onClientData(seq, data)
        }

        if (isFin) {
            session.onClientFin(seq + payloadLen.toLong())
        } else if (isAck) {
            session.onClientAck(ack)
        }
    }

    fun closeAll() {
        sessions.values.forEach { it.close(sendRst = false) }
        sessions.clear()
        scope.cancel()
    }

    private inner class TcpSession(
        private val key: TcpKey,
        clientInitialSeq: Long,
        private val srcIpBytes: ByteArray,
        private val dstIpBytes: ByteArray
    ) {
        private val closed = AtomicBoolean(false)
        // 1024 x ~1.4KB ≈ 1.4MB of headroom for fast uploads (Gemini/Drive); see onClientData for overflow handling
        private val outboundChannel = Channel<ByteArray>(capacity = 1024)
        private var clientNextSeq: Long = (clientInitialSeq + 1L) and 0xFFFFFFFFL
        private var serverSeq: Long = (Random.nextInt(100_000, 9_000_000).toLong()) and 0xFFFFFFFFL
        private var workerJob: Job? = null
        private val startedAtMs = System.currentTimeMillis()
        private val txBytes = AtomicLong(0L)
        // upload flow control: bytes ACKed but not yet handed to the WebSocket / ws send-queue size
        private val pendingUp = AtomicLong(0L)
        @Volatile private var wsQueued = 0L
        @Volatile private var lastAdvWindow = 65535
        private val rxBytes = AtomicLong(0L)

        private val dstHost: String = InetAddress.getByAddress(dstIpBytes).hostAddress ?: "0.0.0.0"

        fun start() {
            if (dstHost.startsWith("10.10.34.")) {
                com.example.core.logging.TunnelStats.inc("drop.filtered")
                close(sendRst = true)
                return
            }

            // Send SYN-ACK immediately to complete local TUN TCP handshake
            sendTcpControlPacket(
                flags = 0x12, // SYN | ACK
                seq = serverSeq,
                ack = clientNextSeq,
                includeMss = true
            )
            serverSeq = (serverSeq + 1L) and 0xFFFFFFFFL

            workerJob = scope.launch {
                val settings = settingsProvider()
                val wsNodes = engine.selectOrderedCandidates(EndpointType.CF_WORKER_WS)
                    .filter { it.endpointType == EndpointType.CF_WORKER_WS }
                val gasNodes = engine.selectOrderedCandidates(EndpointType.GAS_SCRIPT)
                    .filter { it.endpointType == EndpointType.GAS_SCRIPT }

                val useWs = wsNodes.isNotEmpty() &&
                    (settings.protocol == TunnelProtocol.CF_WEBSOCKET ||
                        settings.protocol == TunnelProtocol.HYBRID_SMART ||
                        settings.protocol == TunnelProtocol.SOCKS5_LOCAL)

                when {
                    useWs -> runViaWorkerWebSocket(wsNodes.first(), settings)
                    key.dstPort == 80 && gasNodes.isNotEmpty() -> runHttpViaGasRelay(settings)
                    else -> runViaProtectedDirectSocket(settings)
                }
            }
        }

        fun onClientData(seq: Long, data: ByteArray) {
            if (closed.get()) return
            if (seq != clientNextSeq) {
                sendTcpControlPacket(flags = 0x10, seq = serverSeq, ack = clientNextSeq)
                return
            }
            // FIX(upload): previously we ACKed first and used trySend() afterwards. When the queue was
            // full the segment was silently dropped although the phone had already been told it
            // arrived -> the TLS stream got a hole, the server answered with an alert and closed
            // (RX≈2.6KB, end=ws-failure/dest-closed) and every big upload failed.
            // Now we only ACK what we really queued; otherwise we send a duplicate ACK and the
            // phone retransmits the segment later (natural TCP backpressure).
            if (outboundChannel.trySend(data).isFailure) {
                com.example.core.logging.TunnelStats.inc("up.windowDrop")
                sendTcpControlPacket(flags = 0x10, seq = serverSeq, ack = clientNextSeq)
                return
            }
            val backlog = pendingUp.addAndGet(data.size.toLong())
            com.example.core.logging.TunnelStats.gauge("up.backlogKB", backlog / 1024.0)
            clientNextSeq = (clientNextSeq + data.size.toLong()) and 0xFFFFFFFFL
            sendTcpControlPacket(flags = 0x10, seq = serverSeq, ack = clientNextSeq)
            txBytes.addAndGet(data.size.toLong())
            engine.recordTraffic(upBytes = data.size.toLong(), downBytes = 0L)
        }

        fun onClientAck(@Suppress("UNUSED_PARAMETER") ack: Long) {
            // Keepalive/ACK tracked
        }

        fun onClientFin(finSeq: Long) {
            if (closed.get()) return
            clientNextSeq = (finSeq + 1L) and 0xFFFFFFFFL
            sendTcpControlPacket(flags = 0x11, seq = serverSeq, ack = clientNextSeq) // FIN | ACK
            serverSeq = (serverSeq + 1L) and 0xFFFFFFFFL
            close(sendRst = false)
        }

        private suspend fun runHttpViaGasRelay(settings: BypassSettings) {
            engine.incrementStreams()
            try {
                val firstChunk = withTimeoutOrNull(5_000L) { outboundChannel.receive() }?.also { pendingUp.addAndGet(-it.size.toLong()) }
                if (firstChunk == null) {
                    close(sendRst = false)
                    return
                }
                val raw = String(firstChunk, Charsets.ISO_8859_1)
                val lines = raw.split("\r\n")
                val reqLine = lines.firstOrNull().orEmpty().split(" ")
                if (reqLine.size >= 2 && reqLine[0] in listOf("GET", "POST", "PUT", "DELETE", "HEAD")) {
                    val method = reqLine[0]
                    val path = reqLine[1]
                    var hostHeader = dstHost
                    val headers = mutableMapOf<String, String>()
                    for (line in lines.drop(1)) {
                        if (line.isBlank()) break
                        val idx = line.indexOf(':')
                        if (idx > 0) {
                            val k = line.substring(0, idx).trim()
                            val v = line.substring(idx + 1).trim()
                            if (k.equals("Host", ignoreCase = true)) {
                                hostHeader = v
                            } else if (!k.equals("Connection", ignoreCase = true)) {
                                headers[k] = v
                            }
                        }
                    }
                    val fullUrl = if (path.startsWith("http")) path else "http://$hostHeader$path"
                    TunnelLogger.i(LogCategory.GAS, "TCP-GAS", "رله HTTP از گوگل اسکریپت: $method $hostHeader$path")
                    val res = engine.relayHttpViaGasPool(fullUrl, method, headers, null)
                    val respHeader = "HTTP/1.1 ${res.statusCode} OK\r\nContent-Length: ${res.bodyBytes.size}\r\nConnection: close\r\n\r\n"
                    sendServerPayloadToTun(respHeader.toByteArray(Charsets.ISO_8859_1))
                    if (res.bodyBytes.isNotEmpty()) {
                        sendServerPayloadToTun(res.bodyBytes)
                    }
                    close(sendRst = false)
                } else {
                    runViaProtectedDirectSocket(settings, initialChunk = firstChunk)
                }
            } catch (e: Exception) {
                if (e !is CancellationException) {
                    TunnelLogger.d(LogCategory.GAS, "TCP-GAS-ERR", "خطای رله HTTP به $dstHost", e.localizedMessage)
                }
                close(sendRst = true)
            } finally {
                engine.decrementStreams()
            }
        }

        private suspend fun runViaWorkerWebSocket(workerNode: com.example.data.local.ServerEndpointEntity, settings: BypassSettings) {
            val stats = com.example.core.logging.TunnelStats
            engine.incrementStreams()
            stats.inc("conn.total")
            val connectedSignal = CompletableDeferred<Boolean>()
            val incoming = Channel<ByteArray>(capacity = 64)

            val tAcquire = System.currentTimeMillis()
            var tOpened = 0L
            var tConnectSent = 0L
            var tConnected = 0L
            var tFirstTx = 0L
            var tFirstRx = 0L
            var warm = false
            var route = "?"
            var via = ""
            var directFail = ""
            var endReason = "client-closed"
            val dst = "$dstHost:${key.dstPort}"

            // Read the first client chunk (TLS ClientHello) first so we know the site name (SNI).
            var firstRaw: ByteArray? = withTimeoutOrNull(150L) { outboundChannel.receiveCatching().getOrNull() }?.also { pendingUp.addAndGet(-it.size.toLong()) }
            val fr = firstRaw
            if (fr != null && fr.size > 5 && fr[0].toInt() == 0x16 && com.example.core.net.TlsSni.parse(fr) == null) {
                // big ClientHello (post-quantum key share) split over two segments: glue the next one
                val more = withTimeoutOrNull(120L) { outboundChannel.receiveCatching().getOrNull() }?.also { pendingUp.addAndGet(-it.size.toLong()) }
                if (more != null) firstRaw = fr + more
            }
            val firstOut: ByteArray? = firstRaw
            val sni: String? = firstOut?.let { com.example.core.net.TlsSni.parse(it) }
            val forceForeign = com.example.core.net.GeoRoute.needsForeignExit(sni)
            val siteLabel = sni ?: "-"
            stats.inc("site:" + siteLabel)
            if (forceForeign) {
                stats.inc("geo.forced")
                TunnelLogger.i(LogCategory.CF_WS, "GEO-ROUTE", "$siteLabel ($dst) -> اجبار مسیر از ProxyIP خارجی (دور زدن بلاک کشوری)")
            }

            if (com.example.core.net.DirectRoute.shouldGoDirect(sni)) {
                stats.inc("bypass.direct")
                engine.decrementStreams()
                runViaProtectedDirectSocket(settings.copy(tlsFragmentation = false), initialChunk = firstOut)
                return
            }

            // Cloudflare egress gets no reply from 8.8.4.4 (DoH); 8.8.8.8 serves the same dns.google cert.
            val connectHost = if (dstHost == "8.8.4.4" && sni == "dns.google") "8.8.8.8" else dstHost

            val sendConnect: (WebSocket) -> Unit = { webSocket ->
                tConnectSent = System.currentTimeMillis()
                val ctrl = JSONObject().apply {
                    put("type", "CONNECT")
                    put("host", connectHost)
                    put("port", key.dstPort)
                    if (sni != null) put("sni", sni)
                    if (forceForeign) put("forceProxy", true)
                    val pip = com.example.data.model.ProxyIpCatalog.resolve(settings)
                    if (pip.isNotEmpty()) put("proxyip", pip)
                }.toString()
                webSocket.send(ctrl)
            }

            val wsListener = object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    tOpened = System.currentTimeMillis()
                    sendConnect(webSocket)
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    val obj = runCatching { JSONObject(text) }.getOrNull() ?: return
                    when (obj.optString("type")) {
                        "CONNECTED" -> {
                            tConnected = System.currentTimeMillis()
                            route = obj.optString("route", "?")
                            via = obj.optString("via", "")
                            directFail = obj.optString("directFail", "")
                            stats.inc(if (route == "proxy") "route.proxy" else "route.direct")
                            if (route == "proxy" && via.isNotEmpty()) stats.inc("proxy.ok:$via")
                            if (directFail.isNotEmpty()) stats.inc("direct.fail:${directFail.take(90)}")
                            val workerMs = obj.optLong("ms", -1L)
                            if (workerMs >= 0) stats.sample("t.connect", workerMs)
                            connectedSignal.complete(true)
                        }
                        "INFO" -> {
                            val ev = obj.optString("event")
                            val proxy = obj.optString("proxy")
                            when (ev) {
                                "proxy-dead" -> {
                                    stats.inc("proxy.dead:$proxy")
                                    TunnelLogger.w(
                                        LogCategory.CF_WS,
                                        "PROXYIP-DEAD",
                                        "ProxyIP «$proxy» وصل شد ولی جواب نداد؛ ورکر بعدی رو امتحان می‌کنه ($dst)"
                                    )
                                }
                                "remote-end" -> {
                                    if (obj.optLong("rx", 0L) == 0L) endReason = "dest-closed-no-reply"
                                    else endReason = "dest-closed"
                                }
                            }
                        }
                        "ERROR" -> {
                            val msg = obj.optString("message")
                            stats.inc("worker.err:${msg.take(110)}")
                            TunnelLogger.e(
                                LogCategory.CF_WS,
                                "CFWS-WORKER-ERR",
                                "خطای ورکر کلودفلر برای $dst",
                                msg
                            )
                            endReason = "worker-error"
                            connectedSignal.complete(false)
                        }
                    }
                }

                override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                    if (tFirstRx == 0L) tFirstRx = System.currentTimeMillis()
                    // FIX(download): trySend() silently dropped chunks when the queue was full -> hole in the
                    // TLS stream. Now we block the OkHttp reader thread instead (TCP backpressure to Cloudflare).
                    val arr = bytes.toByteArray()
                    if (incoming.trySend(arr).isFailure) {
                        runCatching { kotlinx.coroutines.runBlocking { incoming.send(arr) } }
                    }
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    if (endReason == "client-closed") endReason = "worker-closed($code)"
                    incoming.close()
                    connectedSignal.complete(false)
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    val what = "${t.javaClass.simpleName}: ${t.localizedMessage}"
                    stats.inc("ws.fail")
                    stats.inc("ws.err:${what.take(90)}")
                    endReason = "ws-failure"
                    // only log the first few; the DIAGNOSIS block carries the counts
                    if (stats.get("ws.fail") <= 5) {
                        TunnelLogger.e(
                            LogCategory.CF_WS,
                            "CFWS-FAIL",
                            "خطای اتصال WebSocket به «${workerNode.name}» (HTTP ${response?.code ?: "-"}) برای $dst",
                            what
                        )
                    }
                    incoming.close()
                    connectedSignal.complete(false)
                }
            }
            val ws = engine.acquireWorkerWebSocket(workerNode, wsListener) { w ->
                warm = true
                sendConnect(w)
            }

            // Pipelining: send the first client chunk (usually the TLS ClientHello) right behind CONNECT.
            // The worker buffers it until the remote socket is open, so the first byte no longer waits
            // for a CONNECT->CONNECTED round trip.
            if (firstOut != null) {
                tFirstTx = System.currentTimeMillis()
                ws.send(firstOut.toByteString(0, firstOut.size))
            }

            val ready = withTimeoutOrNull(8_000L) { connectedSignal.await() } ?: false
            if (!ready) {
                stats.inc("conn.fallback")
                TunnelLogger.w(
                    LogCategory.CF_WS,
                    "TCP-CFWS-FALLBACK",
                    "فال‌بک به مسیر مستقیم برای $dst (علت: $endReason، ${if (warm) "warm" else "cold"}، ${System.currentTimeMillis() - tAcquire}ms)"
                )
                ws.cancel()
                engine.decrementStreams()
                runViaProtectedDirectSocket(settings, initialChunk = firstOut)
                return
            }

            val readerJob = scope.launch {
                for (chunk in incoming) {
                    sendServerPayloadToTun(chunk)
                }
                close(sendRst = false)
            }

            try {
                for (first in outboundChannel) {
                    if (tFirstTx == 0L) tFirstTx = System.currentTimeMillis()
                    // FIX(upload): merge many ~1.3KB TUN segments into one WS frame (<=48KB).
                    // 1MB upload = ~25 frames instead of ~800, so the Worker isn't flooded with
                    // message events (CPU/memory limit -> connection killed -> EOFException).
                    val chunk = coalesceOutbound(first)
                    // Backpressure: don't let OkHttp's send queue grow without bound.
                    var waited = 0
                    while (ws.queueSize() > 768 * 1024L && waited < 4000) { delay(10); waited += 10 }
                    if (!ws.send(chunk.toByteString(0, chunk.size))) break
                    pendingUp.addAndGet(-chunk.size.toLong())
                    wsQueued = ws.queueSize()
                    com.example.core.logging.TunnelStats.gauge("up.wsQueueKB", wsQueued / 1024.0)
                    // window update: tell the phone it may send again once we drained
                    if (lastAdvWindow < 16384) sendTcpControlPacket(flags = 0x10, seq = serverSeq, ack = clientNextSeq)
                }
            } catch (_: Exception) {
                // ignore
            } finally {
                readerJob.cancel()
                ws.close(1000, "EOF")
                engine.decrementStreams()
                val now = System.currentTimeMillis()
                val tx = txBytes.get()
                val rx = rxBytes.get()
                val openMs = if (!warm && tOpened > 0) tOpened - tAcquire else -1L
                val connectMs = if (tConnected > 0 && tConnectSent > 0) tConnected - tConnectSent else -1L
                val ttfbMs = if (tFirstRx > 0 && tFirstTx > 0) tFirstRx - tFirstTx else -1L
                val total = now - startedAtMs
                if (openMs >= 0) stats.sample("t.open", openMs)
                if (ttfbMs >= 0) stats.sample("t.ttfb", ttfbMs)
                stats.sample("t.total", total)
                stats.inc("conn.ok")
                stats.inc("end.$endReason")
                if (rx > 0) stats.inc("siteRx:" + siteLabel) else stats.inc("siteNoRx:" + siteLabel)
                if (tx > 0 && rx in 1..12) stats.inc("tls.alert:" + siteLabel + " route=" + route + (if (via.isNotEmpty()) "(" + via + ")" else ""))
                val zeroReply = tx > 0 && rx == 0L
                if (zeroReply) {
                    stats.inc("conn.zeroRx")
                    stats.inc("zero.$siteLabel $dst route=$route${if (via.isNotEmpty()) "($via)" else ""}")
                }
                val slow = (connectMs > 2000) || (ttfbMs > 2000)
                if (slow) stats.inc("slow:$siteLabel route=$route")
                val tlsAlert = tx > 0 && rx in 1..12
                val oddEnd = endReason != "client-closed" && endReason != "dest-closed" && !endReason.startsWith("worker-closed(1000)")
                // Healthy connections are DEBUG (kept for export but easy to filter); anything
                // suspicious is INFO/WARN so the problem lines stand out.
                val level = when {
                    zeroReply || tlsAlert || oddEnd -> com.example.core.logging.LogLevel.WARN
                    slow || route == "proxy" -> com.example.core.logging.LogLevel.INFO
                    else -> com.example.core.logging.LogLevel.DEBUG
                }
                TunnelLogger.log(
                    level,
                    LogCategory.CF_WS,
                    "CONN",
                    "$siteLabel $dst route=$route${if (via.isNotEmpty()) "($via)" else ""}${if (forceForeign) " [geo-forced]" else ""} pool=${if (warm) "warm" else "cold"} " +
                        "open=${openMs}ms connect=${connectMs}ms ttfb=${ttfbMs}ms total=${total}ms TX=${tx}B RX=${rx}B end=$endReason" +
                        (if (zeroReply) "  <<< NO REPLY" else "") +
                        (if (tlsAlert) "  <<< TLS-ALERT-ONLY (path blocked)" else "") +
                        (if (slow) "  <<< SLOW" else "") +
                        (if (directFail.isNotEmpty()) "\n  direct-failed: $directFail" else "")
                )
                close(sendRst = false)
            }
        }

        private suspend fun runViaProtectedDirectSocket(
            settings: BypassSettings,
            initialChunk: ByteArray? = null
        ) {
            engine.incrementStreams()
            val socket = Socket()
            try {
                BypassOkHttpFactory.socketProtector?.invoke(socket)
                socket.soTimeout = 30_000
                socket.tcpNoDelay = true
                socket.connect(InetSocketAddress(dstHost, key.dstPort), 7_000)

                TunnelLogger.d(
                    LogCategory.VPN,
                    "TCP-DIRECT",
                    "مسیر مستقیم (DPI Frag) به $dstHost:${key.dstPort}",
                    "بدون CF-WS؛ آی‌پی مبدا همان آی‌پی دستگاه است"
                )

                val sockIn = socket.getInputStream()
                val sockOut = socket.getOutputStream()

                val readerJob = scope.launch {
                    val buf = ByteArray(4096)
                    try {
                        while (!closed.get()) {
                            val n = sockIn.read(buf)
                            if (n <= 0) break
                            sendServerPayloadToTun(buf.copyOf(n))
                        }
                    } catch (_: Exception) {
                        // EOF
                    } finally {
                        close(sendRst = false)
                    }
                }

                var firstWrite = true
                suspend fun writeChunk(chunk: ByteArray) {
                    if (firstWrite && settings.tlsFragmentation && chunk.size > 32 && key.dstPort == 443) {
                        firstWrite = false
                        var off = 0
                        while (off < chunk.size) {
                            val part = Random.nextInt(14, 32).coerceAtMost(chunk.size - off)
                            sockOut.write(chunk, off, part)
                            sockOut.flush()
                            off += part
                            if (off < chunk.size) Thread.sleep(2L)
                        }
                    } else {
                        firstWrite = false
                        sockOut.write(chunk)
                        sockOut.flush()
                    }
                }

                if (initialChunk != null) writeChunk(initialChunk)
                for (chunk in outboundChannel) {
                    writeChunk(chunk)
                    pendingUp.addAndGet(-chunk.size.toLong())
                    if (lastAdvWindow < 16384) sendTcpControlPacket(flags = 0x10, seq = serverSeq, ack = clientNextSeq)
                }
                readerJob.cancel()
            } catch (e: Exception) {
                if (e !is CancellationException) {
                    TunnelLogger.d(
                        LogCategory.VPN,
                        "TCP-ERR",
                        "خطای اتصال به $dstHost:${key.dstPort}",
                        e.localizedMessage
                    )
                }
                close(sendRst = true)
            } finally {
                runCatching { socket.close() }
                engine.decrementStreams()
            }
        }

        private fun coalesceOutbound(first: ByteArray, maxBytes: Int = 48 * 1024): ByteArray {
            if (first.size >= maxBytes) return first
            var total = first.size
            var parts: ArrayList<ByteArray>? = null
            while (total < maxBytes) {
                val next = outboundChannel.tryReceive().getOrNull() ?: break
                if (parts == null) { parts = ArrayList(); parts.add(first) }
                parts.add(next)
                total += next.size
            }
            if (parts == null) return first
            val out = ByteArray(total)
            var off = 0
            for (p in parts) { System.arraycopy(p, 0, out, off, p.size); off += p.size }
            return out
        }

        private fun sendServerPayloadToTun(data: ByteArray) {
            if (closed.get() || data.isEmpty()) return
            rxBytes.addAndGet(data.size.toLong())
            engine.recordTraffic(upBytes = 0L, downBytes = data.size.toLong())
            val maxChunk = 1340
            var offset = 0
            while (offset < data.size && !closed.get()) {
                val len = (data.size - offset).coerceAtMost(maxChunk)
                val slice = data.copyOfRange(offset, offset + len)
                sendTcpDataPacket(slice, serverSeq, clientNextSeq)
                serverSeq = (serverSeq + len.toLong()) and 0xFFFFFFFFL
                offset += len
            }
        }

        fun close(sendRst: Boolean) {
            if (!closed.compareAndSet(false, true)) return
            sessions.remove(key)
            outboundChannel.close()
            if (sendRst) {
                sendTcpControlPacket(flags = 0x14, seq = serverSeq, ack = clientNextSeq) // RST | ACK
            } else {
                sendTcpControlPacket(flags = 0x11, seq = serverSeq, ack = clientNextSeq) // FIN | ACK
            }
            workerJob?.cancel()
        }

        private fun sendTcpControlPacket(
            flags: Int,
            seq: Long,
            ack: Long,
            includeMss: Boolean = false
        ) {
            val optLen = if (includeMss) 4 else 0
            val tcpHeaderLen = 20 + optLen
            val totalLen = 20 + tcpHeaderLen
            val out = ByteArray(totalLen)
            writeIpAndTcpHeaders(out, totalLen, tcpHeaderLen, flags, seq, ack)
            if (includeMss) {
                out[40] = 0x02
                out[41] = 0x04
                out[42] = 0x05
                out[43] = 0x78 // MSS 1400
            }
            finalizeChecksums(out, 20, tcpHeaderLen)
            synchronized(tunOutput) {
                runCatching { tunOutput.write(out) }
            }
        }

        private fun sendTcpDataPacket(payload: ByteArray, seq: Long, ack: Long) {
            val tcpHeaderLen = 20
            val totalLen = 20 + tcpHeaderLen + payload.size
            val out = ByteArray(totalLen)
            writeIpAndTcpHeaders(out, totalLen, tcpHeaderLen, 0x18, seq, ack) // PSH | ACK
            System.arraycopy(payload, 0, out, 40, payload.size)
            finalizeChecksums(out, 20, tcpHeaderLen + payload.size)
            synchronized(tunOutput) {
                runCatching { tunOutput.write(out) }
            }
        }

        private fun writeIpAndTcpHeaders(
            out: ByteArray,
            totalLen: Int,
            tcpHeaderLen: Int,
            flags: Int,
            seq: Long,
            ack: Long
        ) {
            out[0] = 0x45.toByte()
            out[1] = 0x00
            out[2] = ((totalLen ushr 8) and 0xFF).toByte()
            out[3] = (totalLen and 0xFF).toByte()
            out[4] = 0x00
            out[5] = 0x00
            out[6] = 0x40.toByte()
            out[7] = 0x00
            out[8] = 64.toByte() // TTL
            out[9] = 6.toByte() // TCP
            System.arraycopy(dstIpBytes, 0, out, 12, 4)
            System.arraycopy(srcIpBytes, 0, out, 16, 4)

            out[20] = ((key.dstPort ushr 8) and 0xFF).toByte()
            out[21] = (key.dstPort and 0xFF).toByte()
            out[22] = ((key.srcPort ushr 8) and 0xFF).toByte()
            out[23] = (key.srcPort and 0xFF).toByte()
            writeUInt(out, 24, seq)
            writeUInt(out, 28, ack)
            out[32] = (((tcpHeaderLen / 4) shl 4) and 0xF0).toByte()
            out[33] = (flags and 0x3F).toByte()
            val win = (65535L - pendingUp.get() - wsQueued / 8).coerceIn(0L, 65535L).toInt()
            lastAdvWindow = win
            out[34] = ((win ushr 8) and 0xFF).toByte()
            out[35] = (win and 0xFF).toByte()
        }

        private fun finalizeChecksums(packet: ByteArray, ipLen: Int, tcpLen: Int) {
            val ipSum = onesComplementSum(packet, 0, ipLen)
            packet[10] = ((ipSum ushr 8) and 0xFF).toByte()
            packet[11] = (ipSum and 0xFF).toByte()

            var pseudoSum = 0L
            for (i in 12 until 20 step 2) {
                pseudoSum += ((packet[i].toInt() and 0xFF) shl 8) or (packet[i + 1].toInt() and 0xFF)
            }
            pseudoSum += 6L
            pseudoSum += tcpLen.toLong()
            val tcpSum = onesComplementSum(packet, ipLen, tcpLen, initial = pseudoSum)
            packet[ipLen + 16] = ((tcpSum ushr 8) and 0xFF).toByte()
            packet[ipLen + 17] = (tcpSum and 0xFF).toByte()
        }
    }

    private fun onesComplementSum(data: ByteArray, offset: Int, length: Int, initial: Long = 0L): Int {
        var sum = initial
        var i = offset
        while (i < offset + length - 1) {
            sum += ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (length % 2 == 1) {
            sum += (data[offset + length - 1].toInt() and 0xFF) shl 8
        }
        while ((sum ushr 16) != 0L) {
            sum = (sum and 0xFFFF) + (sum ushr 16)
        }
        return (sum.inv() and 0xFFFF).toInt()
    }

    private fun readUShort(b: ByteArray, off: Int): Int =
        ((b[off].toInt() and 0xFF) shl 8) or (b[off + 1].toInt() and 0xFF)

    private fun readInt(b: ByteArray, off: Int): Int =
        ((b[off].toInt() and 0xFF) shl 24) or
            ((b[off + 1].toInt() and 0xFF) shl 16) or
            ((b[off + 2].toInt() and 0xFF) shl 8) or
            (b[off + 3].toInt() and 0xFF)

    private fun readUInt(b: ByteArray, off: Int): Long =
        readInt(b, off).toLong() and 0xFFFFFFFFL

    private fun writeUInt(b: ByteArray, off: Int, v: Long) {
        b[off] = ((v ushr 24) and 0xFF).toByte()
        b[off + 1] = ((v ushr 16) and 0xFF).toByte()
        b[off + 2] = ((v ushr 8) and 0xFF).toByte()
        b[off + 3] = (v and 0xFF).toByte()
    }
}
