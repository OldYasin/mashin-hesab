package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.AppContainer
import com.example.core.logging.LogCategory
import com.example.core.logging.TunnelLogEntry
import com.example.core.logging.TunnelLogger
import com.example.core.crypto.TunnelCrypto
import com.example.core.scripts.ScriptTemplates
import com.example.data.local.CleanIpEntity
import com.example.data.local.ConnectionReportEntity
import com.example.data.local.PendingSyncTaskEntity
import com.example.data.local.ServerEndpointEntity
import com.example.data.model.BypassSettings
import com.example.data.model.CompressionLevel
import com.example.data.model.EndpointType
import com.example.data.model.IpProvider
import com.example.data.model.LoadBalanceMode
import com.example.data.model.NetworkSyncStatus
import com.example.data.model.TunnelConnectionState
import com.example.data.model.TunnelProtocol
import com.example.data.model.TunnelTelemetry
import com.example.network.CleanIpScanner
import com.example.network.ScanProgress
import com.example.service.ScriptVpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class UiBannerMessage(
    val text: String,
    val isError: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val container = AppContainer.get(application)
    private val repository = container.tunnelRepository
    private val settingsRepo = container.settingsRepository
    private val engine = container.tunnelEngine
    private val syncManager = container.networkSyncManager
    private val mitmCa by lazy { container.mitmCa } // key generation happens off the main thread

    val settings: StateFlow<BypassSettings> = settingsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BypassSettings())

    val generatedSecret: StateFlow<String> = settingsRepo.generatedSecretFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "st_key_9f4a2c8e1d7b6035a4f9e2c1")

    val servers: StateFlow<List<ServerEndpointEntity>> = repository.serversFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cleanIps: StateFlow<List<CleanIpEntity>> = repository.cleanIpsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reports: StateFlow<List<ConnectionReportEntity>> = repository.reportsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingSyncTasks: StateFlow<List<PendingSyncTaskEntity>> = repository.pendingSyncTasksFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val telemetry: StateFlow<TunnelTelemetry> = engine.telemetry
    val logs: StateFlow<List<TunnelLogEntry>> = TunnelLogger.logs
    val isLogsPaused: StateFlow<Boolean> = TunnelLogger.isPaused
    val syncStatus: StateFlow<NetworkSyncStatus> = syncManager.syncStatus

    private val _scanProgress = MutableStateFlow(ScanProgress())
    val scanProgress: StateFlow<ScanProgress> = _scanProgress.asStateFlow()

    private val _isTestingPool = MutableStateFlow(false)
    val isTestingPool: StateFlow<Boolean> = _isTestingPool.asStateFlow()

    private val _isProbing = MutableStateFlow(false)
    val isProbing: StateFlow<Boolean> = _isProbing.asStateFlow()

    private val _banner = MutableStateFlow<UiBannerMessage?>(null)
    val banner: StateFlow<UiBannerMessage?> = _banner.asStateFlow()

    private val _isMitmCaInstalled = MutableStateFlow(false)
    val isMitmCaInstalled: StateFlow<Boolean> = _isMitmCaInstalled.asStateFlow()

    private var scanJob: Job? = null
    private var keepAliveProbeJob: Job? = null

    init {
        refreshMitmCaStatus()
        viewModelScope.launch {
            combine(servers, settings) { list, cfg -> list to cfg }
                .collect { (list, cfg) ->
                    engine.updatePoolAndSettings(list, cfg)
                }
        }
    }

    fun refreshMitmCaStatus() {
        viewModelScope.launch(Dispatchers.IO) {
            _isMitmCaInstalled.value = mitmCa.isCaInstalled()
        }
    }

    fun createCaInstallIntent(): Intent = mitmCa.createInstallIntent()

    fun exportCaForManualInstall(onResult: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = mitmCa.exportCaToDownloads()
            kotlinx.coroutines.withContext(Dispatchers.Main) { onResult(ok) }
        }
    }

    fun clearBanner() {
        _banner.value = null
    }

    fun toggleLogsPause() {
        TunnelLogger.togglePause()
    }

    fun clearLogs() {
        TunnelLogger.clear()
        showMessage("لاگ‌ها پاک شدند")
    }

    fun showMessage(text: String, isError: Boolean = false) {
        _banner.value = UiBannerMessage(text, isError)
    }

    fun startVpnTunnel() {
        val activeServers = servers.value.filter { it.isParallelActive }
        if (activeServers.isEmpty()) {
            showMessage("ابتدا حداقل یک لینک اسکریپت گوگل یا ورکر کلودفلر اضافه و فعال کنید.", isError = true)
            return
        }
        val ctx = getApplication<Application>()
        val intent = Intent(ctx, ScriptVpnService::class.java).apply {
            action = ScriptVpnService.ACTION_CONNECT
        }
        ContextCompat.startForegroundService(ctx, intent)
        startAdaptiveProbeLoop()
    }

    fun stopVpnTunnel() {
        keepAliveProbeJob?.cancel()
        keepAliveProbeJob = null
        val ctx = getApplication<Application>()
        val intent = Intent(ctx, ScriptVpnService::class.java).apply {
            action = ScriptVpnService.ACTION_DISCONNECT
        }
        ctx.startService(intent)
    }

    private fun startAdaptiveProbeLoop() {
        keepAliveProbeJob?.cancel()
        keepAliveProbeJob = viewModelScope.launch(Dispatchers.IO) {
            delay(1500L)
            while (isActive && telemetry.value.connectionState == TunnelConnectionState.CONNECTED) {
                val cfg = settings.value
                val activeNodes = servers.value.filter { it.isParallelActive }
                if (activeNodes.isNotEmpty() && cfg.adaptiveKeepAlive) {
                    val candidate = engine.selectOrderedCandidates().firstOrNull()
                    if (candidate != null) {
                        val ping = engine.pingEndpoint(candidate, cfg)
                        repository.updateServerHealth(candidate.id, ping.latencyMs, ping.isHealthy)
                        if (!ping.isHealthy && activeNodes.size > 1) {
                            engine.setConnectionState(TunnelConnectionState.RECONNECTING)
                            val backup = activeNodes.firstOrNull { it.id != candidate.id }
                            if (backup != null) {
                                val backupPing = engine.pingEndpoint(backup, cfg)
                                repository.updateServerHealth(backup.id, backupPing.latencyMs, backupPing.isHealthy)
                            }
                            engine.setConnectionState(TunnelConnectionState.CONNECTED)
                        }
                    }
                }
                delay(12_000L)
            }
        }
    }

    fun runLiveSpeedAndDohProbe() {
        if (_isProbing.value) return
        viewModelScope.launch(Dispatchers.IO) {
            val active = servers.value.filter { it.isParallelActive }
            if (active.isEmpty()) {
                showMessage("سرور فعالی برای تست وجود ندارد.", isError = true)
                return@launch
            }
            _isProbing.value = true
            try {
                val dnsSample = byteArrayOf(
                    0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                    0x06, 'g'.code.toByte(), 'o'.code.toByte(), 'o'.code.toByte(), 'g'.code.toByte(), 'l'.code.toByte(), 'e'.code.toByte(),
                    0x03, 'c'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte(), 0x00,
                    0x00, 0x01, 0x00, 0x01
                )
                val dnsAnswer = engine.resolveDohPacket(dnsSample)
                val gasNodes = active.filter { it.endpointType == EndpointType.GAS_SCRIPT }
                if (gasNodes.isNotEmpty()) {
                    val res = engine.relayHttpViaGasPool("https://www.gstatic.com/generate_204", "GET")
                    if (res.ok) {
                        showMessage("تست زنده موفق بود (DoH: ${if (dnsAnswer != null) "فعال" else "پشتیبان"})")
                    } else {
                        showMessage("پاسخ رله گوگل: ${res.error ?: res.statusCode}", isError = true)
                    }
                } else {
                    val cfg = settings.value
                    var healthy = 0
                    var bestMs = Int.MAX_VALUE
                    active.forEach { node ->
                        val ping = engine.pingEndpoint(node, cfg)
                        repository.updateServerHealth(node.id, ping.latencyMs, ping.isHealthy)
                        if (ping.isHealthy) {
                            healthy++
                            if (ping.latencyMs in 1 until bestMs) bestMs = ping.latencyMs
                        }
                    }
                    val msLabel = if (bestMs < Int.MAX_VALUE) "${bestMs}ms" else "—"
                    showMessage(
                        if (healthy > 0) "تست زنده موفق: $healthy/${active.size} سرور سالم ($msLabel) • DoH: ${if (dnsAnswer != null) "فعال" else "ناموفق"}"
                        else "سرورها پاسخ ندادند • DoH: ${if (dnsAnswer != null) "فعال" else "ناموفق"}",
                        isError = healthy == 0
                    )
                }
            } finally {
                _isProbing.value = false
            }
        }
    }

    fun updateProtocol(protocol: TunnelProtocol) {
        viewModelScope.launch {
            settingsRepo.updateSettings { it.copy(protocol = protocol) }
        }
    }

    fun updateLoadBalanceMode(mode: LoadBalanceMode) {
        viewModelScope.launch {
            settingsRepo.updateSettings { it.copy(loadBalanceMode = mode) }
        }
    }

    fun updateCompression(level: CompressionLevel) {
        viewModelScope.launch {
            settingsRepo.updateSettings { it.copy(compressionLevel = level) }
        }
    }

    fun toggleTlsFragmentation(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.updateSettings { it.copy(tlsFragmentation = enabled) } }
    }

    fun toggleMitmHttp2(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.updateSettings { it.copy(mitmHttp2Enabled = enabled) } }
    }

    fun toggleCleanIpBinding(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.updateSettings { it.copy(cleanIpBinding = enabled) } }
    }

    fun togglePayloadEncryption(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.updateSettings { it.copy(payloadEncryption = enabled) } }
    }

    fun toggleRandomPadding(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.updateSettings { it.copy(randomPadding = enabled) } }
    }

    fun toggleAdaptiveKeepAlive(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.updateSettings { it.copy(adaptiveKeepAlive = enabled) } }
    }

    fun toggleDoh(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.updateSettings { it.copy(dohEnabled = enabled) } }
    }

    fun setProxyIp(country: String, custom: String) {
        viewModelScope.launch {
            settingsRepo.updateSettings { it.copy(proxyIpCountry = country, proxyIpCustom = custom.trim()) }
            showMessage("ProxyIP ذخیره شد")
        }
    }

    fun toggleVpnMode(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.updateSettings { it.copy(vpnModeEnabled = enabled) } }
    }

    fun toggleDarkTheme() {
        viewModelScope.launch { settingsRepo.updateSettings { it.copy(darkTheme = !it.darkTheme) } }
    }

    fun addOrUpdateServer(
        existingId: Long = 0L,
        name: String,
        url: String,
        secretKey: String,
        type: EndpointType,
        customSni: String,
        customCleanIp: String,
        weight: Int
    ) {
        if (name.isBlank() || url.isBlank()) {
            showMessage("نام و آدرس اسکریپت یا ورکر الزامی است.", isError = true)
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val isOnline = syncStatus.value.isOnline
            val entity = ServerEndpointEntity(
                id = existingId,
                name = name.trim(),
                url = url.trim(),
                secretKey = secretKey.trim().ifBlank { generatedSecret.value },
                type = type.name,
                customSniHost = customSni.trim(),
                customCleanIp = customCleanIp.trim(),
                isParallelActive = true,
                weight = weight.coerceIn(1, 10)
            )
            val cleanIpLabel = entity.customCleanIp.ifBlank { "auto" }
            TunnelLogger.i(LogCategory.SYSTEM, "SERVER-SAVE", "ذخیره سرور «${entity.name}» (${entity.endpointType.badge})", "URL=${entity.url}, CleanIP=$cleanIpLabel")
            if (type == EndpointType.CF_WORKER_WS && settings.value.protocol == TunnelProtocol.GAS_PARALLEL) {
                settingsRepo.updateSettings { it.copy(protocol = TunnelProtocol.HYBRID_SMART) }
            }
            val savedId = repository.addOrUpdateServer(entity, isOnline)
            if (isOnline) {
                val ping = engine.pingEndpoint(entity.copy(id = savedId), settings.value)
                repository.updateServerHealth(savedId, ping.latencyMs, ping.isHealthy)
                showMessage(if (ping.isHealthy) "سرور ذخیره و متصل شد (${ping.latencyMs}ms)" else "سرور ذخیره شد: ${ping.message}", isError = !ping.isHealthy)
            } else {
                showMessage("حالت آفلاین: سرور ذخیره و در صف همگام‌سازی خودکار قرار گرفت")
            }
        }
    }

    fun importShareConfig(raw: String) {
        val decoded = ScriptTemplates.decodeShareUri(raw)
        if (decoded == null) {
            showMessage("فرمت کانفیگ scriptvpn:// یا JSON معتبر نیست.", isError = true)
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val isOnline = syncStatus.value.isOnline
            val savedId = repository.addOrUpdateServer(decoded, isOnline)
            if (isOnline) {
                val ping = engine.pingEndpoint(decoded.copy(id = savedId), settings.value)
                repository.updateServerHealth(savedId, ping.latencyMs, ping.isHealthy)
            }
            showMessage("سرور «${decoded.name}» با موفقیت وارد شد")
        }
    }

    fun toggleServerParallel(endpoint: ServerEndpointEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleServerParallelActive(endpoint)
            if (!endpoint.isParallelActive && endpoint.endpointType == EndpointType.CF_WORKER_WS && settings.value.protocol == TunnelProtocol.GAS_PARALLEL) {
                settingsRepo.updateSettings { it.copy(protocol = TunnelProtocol.HYBRID_SMART) }
            }
        }
    }

    fun deleteServer(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteServer(id)
            showMessage("سرور حذف شد")
        }
    }

    fun pingSingleServer(endpoint: ServerEndpointEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            if (!syncStatus.value.isOnline) {
                showMessage("اتصال اینترنت برقرار نیست؛ تست به صف همگام‌سازی اضافه شد.", isError = true)
                return@launch
            }
            val ping = engine.pingEndpoint(endpoint, settings.value)
            repository.updateServerHealth(endpoint.id, ping.latencyMs, ping.isHealthy)
            showMessage("${endpoint.name}: ${ping.message}", isError = !ping.isHealthy)
        }
    }

    fun testAllServers() {
        val list = servers.value
        if (list.isEmpty()) {
            showMessage("هیچ سروری برای تست وجود ندارد.", isError = true)
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _isTestingPool.value = true
            val cfg = settings.value
            var healthy = 0
            list.forEach { node ->
                val ping = engine.pingEndpoint(node, cfg)
                repository.updateServerHealth(node.id, ping.latencyMs, ping.isHealthy)
                if (ping.isHealthy) healthy++
            }
            _isTestingPool.value = false
            showMessage("تست موازی تکمیل شد: $healthy از ${list.size} سرور در دسترس است")
        }
    }

    fun startCleanIpScan(provider: IpProvider, customPrefix: String = "") {
        scanJob?.cancel()
        scanJob = viewModelScope.launch(Dispatchers.IO) {
            val results = CleanIpScanner.scanCleanIps(
                provider = provider,
                customPrefix = customPrefix,
                sampleCount = 60
            ) { progress ->
                _scanProgress.value = progress
            }
            if (results.isNotEmpty()) {
                val top = results.first()
                val marked = results.mapIndexed { idx, item -> item.copy(isSelected = idx == 0) }
                repository.saveCleanIps(provider, marked)
                applyCleanIp(top.ip, provider)
                showMessage("${results.size} آی‌پی تمیز یافت شد • سریع‌ترین: ${top.ip} (${top.latencyMs}ms)")
            } else {
                showMessage("آی‌پی تمیز در این رنج یافت نشد. رنج دستی یا فیلترشکن پایه را بررسی کنید.", isError = true)
            }
        }
    }

    fun stopCleanIpScan() {
        scanJob?.cancel()
        _scanProgress.value = _scanProgress.value.copy(isScanning = false)
    }

    fun applyCleanIp(ip: String, provider: IpProvider) {
        viewModelScope.launch(Dispatchers.IO) {
            TunnelLogger.i(LogCategory.TLS_IP, "CLEAN-IP", "اعمال آی‌پی تمیز $ip برای ${provider.titleFa}")
            repository.selectCleanIp(ip, provider)
            settingsRepo.updateSettings { cfg ->
                when (provider) {
                    IpProvider.GOOGLE -> cfg.copy(activeCleanGoogleIp = ip, cleanIpBinding = true)
                    IpProvider.CLOUDFLARE -> cfg.copy(activeCleanCfIp = ip, cleanIpBinding = true)
                }
            }
            showMessage("آی‌پی تمیز $ip روی تونل اعمال شد")
        }
    }

    fun regenerateSecretKey() {
        viewModelScope.launch {
            settingsRepo.saveGeneratedSecret(TunnelCrypto.generateStrongSecret())
            showMessage("کلید امنیتی جدید ۲۵۶ بیتی تولید شد")
        }
    }

    fun triggerManualSync() {
        syncManager.triggerSync("همگام‌سازی دستی")
    }

    fun clearReports() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearReports()
            showMessage("تاریخچه گزارش‌ها پاک شد")
        }
    }
}
