package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.SavedFolderEntity
import com.example.data.local.TvProfileEntity
import com.example.data.local.TvProfilePresets
import com.example.data.local.UserPreferencesRepository
import com.example.data.local.UserSettings
import com.example.data.local.YouTubeBookmarkEntity
import com.example.hardware.HardwareConnectionState
import com.example.hardware.TvHardwareMonitor
import com.example.media.FolderScanner
import com.example.media.ParsedSubtitleResult
import com.example.media.ScannedVideoItem
import com.example.media.SubtitleEngine
import com.example.media.TranscodeJobState
import com.example.media.TvVideoTranscoder
import com.example.media.YouTubeMetadataClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SubtitleWorkspaceState(
    val selectedVideo: ScannedVideoItem? = null,
    val parsedSubtitle: ParsedSubtitleResult? = null,
    val customSubtitleUri: String? = null,
    val statusMessage: String? = null,
    val isProcessing: Boolean = false
)

data class YouTubeInputState(
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val activeBrowserVideoId: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val db = AppDatabase.getInstance(appContext)
    private val tvProfileDao = db.tvProfileDao()
    private val folderDao = db.savedFolderDao()
    private val youtubeDao = db.youtubeBookmarkDao()
    private val prefsRepo = UserPreferencesRepository(appContext)

    val hardwareMonitor = TvHardwareMonitor(appContext)
    private val transcoder = TvVideoTranscoder(appContext, viewModelScope)

    val hardwareState: StateFlow<HardwareConnectionState> = hardwareMonitor.state

    val userSettings: StateFlow<UserSettings> = prefsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    val tvProfiles: StateFlow<List<TvProfileEntity>> = tvProfileDao.getAllProfiles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TvProfilePresets.builtInProfiles)

    val activeProfile: StateFlow<TvProfileEntity> = combine(tvProfiles, userSettings) { profiles, settings ->
        profiles.firstOrNull { it.id == settings.selectedProfileId }
            ?: profiles.firstOrNull()
            ?: TvProfilePresets.builtInProfiles.first()
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        TvProfilePresets.builtInProfiles.first()
    )

    val savedFolders: StateFlow<List<SavedFolderEntity>> = folderDao.getAllFolders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val youtubeBookmarks: StateFlow<List<YouTubeBookmarkEntity>> = youtubeDao.getAllBookmarks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _scannedVideos = MutableStateFlow<List<ScannedVideoItem>>(emptyList())
    val scannedVideos: StateFlow<List<ScannedVideoItem>> = _scannedVideos.asStateFlow()

    private val _isScanningFolders = MutableStateFlow(false)
    val isScanningFolders: StateFlow<Boolean> = _isScanningFolders.asStateFlow()

    private val _transcodeJob = MutableStateFlow(TranscodeJobState())
    val transcodeJob: StateFlow<TranscodeJobState> = _transcodeJob.asStateFlow()

    private val _subtitleState = MutableStateFlow(SubtitleWorkspaceState())
    val subtitleState: StateFlow<SubtitleWorkspaceState> = _subtitleState.asStateFlow()

    private val _youtubeState = MutableStateFlow(YouTubeInputState())
    val youtubeState: StateFlow<YouTubeInputState> = _youtubeState.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private var lastAutoAdaptedDisplayId: Int? = null

    init {
        hardwareMonitor.start()
        viewModelScope.launch(Dispatchers.IO) {
            if (tvProfileDao.getProfileCount() == 0) {
                tvProfileDao.insertProfiles(TvProfilePresets.builtInProfiles)
            }
        }

        // Auto-adapt active profile when an HDMI / USB-C TV Display is plugged in
        viewModelScope.launch {
            combine(hardwareState, userSettings, tvProfiles) { hw, settings, profiles ->
                Triple(hw, settings, profiles)
            }.collect { (hw, settings, profiles) ->
                val primaryDisplay = hw.primaryDisplay
                if (settings.autoAdaptOnCableConnect && primaryDisplay != null &&
                    lastAutoAdaptedDisplayId != primaryDisplay.displayId
                ) {
                    lastAutoAdaptedDisplayId = primaryDisplay.displayId
                    adaptToDetectedDisplay(primaryDisplay.name, primaryDisplay.width, primaryDisplay.height, primaryDisplay.refreshRate.toInt(), profiles)
                } else if (primaryDisplay == null) {
                    lastAutoAdaptedDisplayId = null
                }
            }
        }

        // Re-scan folders whenever savedFolders or activeProfile changes
        viewModelScope.launch {
            combine(savedFolders, activeProfile) { folders, profile ->
                folders to profile
            }.collect { (folders, profile) ->
                rescanAllFolders(folders, profile)
            }
        }
    }

    private suspend fun adaptToDetectedDisplay(
        displayName: String,
        width: Int,
        height: Int,
        fps: Int,
        profiles: List<TvProfileEntity>
    ) {
        val safeWidth = if (width > 0) width else 1280
        val safeHeight = if (height > 0) height else 720
        val safeFps = if (fps > 0) fps else 30
        val brand = when {
            displayName.contains("LG", true) -> "LG"
            displayName.contains("Samsung", true) -> "Samsung"
            displayName.contains("Sony", true) -> "Sony"
            else -> "HDMI Auto"
        }
        val autoName = "تشخیص خودکار کابل: $displayName (${safeHeight}p)"
        val existing = profiles.firstOrNull { !it.isBuiltIn && it.name == autoName }
        val profileId = if (existing != null) {
            existing.id
        } else {
            tvProfileDao.insertProfile(
                TvProfileEntity(
                    name = autoName,
                    brand = brand,
                    modelYearHint = "شناسایی خودکار از کابل تصویر",
                    maxWidth = safeWidth,
                    maxHeight = safeHeight,
                    maxFps = safeFps,
                    preferredContainer = "MP4",
                    preferredVideoCodec = if (safeHeight <= 720) "H.264 (AVC)" else "H.264 / HEVC",
                    preferredAudioCodec = "AAC",
                    supportsSrt = true,
                    preferUtf8Bom = true,
                    isBuiltIn = false
                )
            )
        }
        prefsRepo.setSelectedProfileId(profileId)
        _toastMessage.value = "تلویزیون شناسایی شد و پروفایل روی ${safeWidth}×${safeHeight} تنظیم شد."
    }

    fun selectTvProfile(profileId: Long) {
        viewModelScope.launch {
            prefsRepo.setSelectedProfileId(profileId)
        }
    }

    fun createCustomTvProfile(
        name: String,
        brand: String,
        maxWidth: Int,
        maxHeight: Int,
        container: String
    ) {
        if (name.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val newId = tvProfileDao.insertProfile(
                TvProfileEntity(
                    name = name.trim(),
                    brand = brand.trim().ifBlank { "Custom" },
                    modelYearHint = "پروفایل سفارشی کاربر",
                    maxWidth = maxWidth,
                    maxHeight = maxHeight,
                    maxFps = 30,
                    preferredContainer = container,
                    preferredVideoCodec = "H.264 (AVC)",
                    preferredAudioCodec = "AAC",
                    supportsSrt = true,
                    preferUtf8Bom = true,
                    isBuiltIn = false
                )
            )
            prefsRepo.setSelectedProfileId(newId)
        }
    }

    fun deleteCustomTvProfile(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            tvProfileDao.deleteCustomProfile(id)
            if (userSettings.value.selectedProfileId == id) {
                prefsRepo.setSelectedProfileId(1L)
            }
        }
    }

    fun setAutoAdaptOnCable(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setAutoAdaptOnCableConnect(enabled) }
    }

    fun setAutoLaunchTvPresentation(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setAutoLaunchTvPresentation(enabled) }
    }

    fun refreshHardware() {
        hardwareMonitor.refreshAll()
    }

    fun addFolderFromSaf(treeUri: Uri, makeExportTarget: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                appContext.contentResolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }.onFailure {
                runCatching {
                    appContext.contentResolver.takePersistableUriPermission(
                        treeUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
            }

            val doc = DocumentFile.fromTreeUri(appContext, treeUri)
            val label = doc?.name?.takeIf { it.isNotBlank() }
                ?: DocumentsContract.getTreeDocumentId(treeUri).substringAfterLast(':')
                    .ifBlank { "پوشه انتخاب‌شده" }

            val currentFolders = savedFolders.value
            val shouldBeExport = makeExportTarget || currentFolders.none { it.isExportTarget }

            folderDao.insertFolder(
                SavedFolderEntity(
                    uriString = treeUri.toString(),
                    displayName = label,
                    isExportTarget = shouldBeExport
                )
            )
            if (shouldBeExport) {
                folderDao.setExportTarget(treeUri.toString())
            }
        }
    }

    fun setExportFolder(uriString: String) {
        viewModelScope.launch(Dispatchers.IO) {
            folderDao.setExportTarget(uriString)
            _toastMessage.value = "پوشه مقصد برای ذخیره فیلم‌های آماده تلویزیون تنظیم شد."
        }
    }

    fun removeFolder(uriString: String) {
        viewModelScope.launch(Dispatchers.IO) {
            folderDao.deleteFolder(uriString)
        }
    }

    fun refreshFoldersNow() {
        viewModelScope.launch {
            rescanAllFolders(savedFolders.value, activeProfile.value)
        }
    }

    private fun rescanAllFolders(folders: List<SavedFolderEntity>, profile: TvProfileEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            _isScanningFolders.value = true
            val allVideos = mutableListOf<ScannedVideoItem>()
            folders.forEach { folder ->
                val uri = Uri.parse(folder.uriString)
                val scanned = FolderScanner.scanFolder(appContext, uri, profile)
                folderDao.updateVideoCount(folder.uriString, scanned.size)
                allVideos.addAll(scanned)
            }
            _scannedVideos.value = allVideos
            _isScanningFolders.value = false
        }
    }

    fun startTranscodeForTv(video: ScannedVideoItem) {
        val exportFolder = savedFolders.value.firstOrNull { it.isExportTarget }?.uriString?.let(Uri::parse)
        val profile = activeProfile.value
        val offsetMs = userSettings.value.subtitleSyncOffsetMs
        transcoder.startAdaptation(
            sourceVideo = video,
            profile = profile,
            exportFolderUri = exportFolder,
            subtitleOffsetMs = offsetMs
        ) { jobState ->
            _transcodeJob.value = jobState
            if (!jobState.isRunning && jobState.completedOutputUri != null) {
                refreshFoldersNow()
            }
        }
    }

    fun cancelTranscode() {
        transcoder.cancel()
        _transcodeJob.value = TranscodeJobState()
    }

    fun clearTranscodeBanner() {
        _transcodeJob.value = TranscodeJobState()
    }

    fun selectVideoForSubtitleStudio(video: ScannedVideoItem) {
        _subtitleState.update { it.copy(selectedVideo = video, statusMessage = null) }
        val subUriStr = video.pairedSubtitleUriString
        if (subUriStr != null) {
            loadSubtitleFile(Uri.parse(subUriStr), video.pairedSubtitleName ?: "subtitle.srt")
        }
    }

    fun loadSubtitleFile(uri: Uri, displayName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _subtitleState.update { it.copy(isProcessing = true, statusMessage = null) }
            runCatching {
                SubtitleEngine.parseSubtitle(appContext, uri, displayName)
            }.onSuccess { parsed ->
                _subtitleState.update {
                    it.copy(
                        parsedSubtitle = parsed,
                        customSubtitleUri = uri.toString(),
                        isProcessing = false,
                        statusMessage = "زیرنویس با رمزگذاری «${parsed.detectedEncoding}» خوانده شد (${parsed.cues.size} خط)."
                    )
                }
            }.onFailure { err ->
                _subtitleState.update {
                    it.copy(
                        isProcessing = false,
                        statusMessage = "خطا در خواندن فایل زیرنویس: ${err.localizedMessage}"
                    )
                }
            }
        }
    }

    fun exportPairedSubtitleForTv() {
        val currentSub = _subtitleState.value.parsedSubtitle
        val selectedVideo = _subtitleState.value.selectedVideo
        if (currentSub == null || selectedVideo == null) {
            _subtitleState.update {
                it.copy(statusMessage = "ابتدا یک فیلم و یک فایل زیرنویس انتخاب کنید.")
            }
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _subtitleState.update { it.copy(isProcessing = true) }
            val targetFolderUri = savedFolders.value.firstOrNull { it.isExportTarget }?.uriString?.let(Uri::parse)
                ?: Uri.parse(selectedVideo.folderUriString)
            val shiftedSrt = SubtitleEngine.applyOffsetAndBuildSrt(
                cues = currentSub.cues,
                offsetMs = userSettings.value.subtitleSyncOffsetMs
            )
            val exportedUri = SubtitleEngine.exportSrtToFolder(
                context = appContext,
                targetTreeUri = targetFolderUri,
                movieBaseName = selectedVideo.baseName,
                srtContent = shiftedSrt,
                includeUtf8Bom = activeProfile.value.preferUtf8Bom
            )
            if (exportedUri != null) {
                _subtitleState.update {
                    it.copy(
                        isProcessing = false,
                        customSubtitleUri = exportedUri.toString(),
                        statusMessage = "زیرنویس فارسی با نام دقیق «${selectedVideo.baseName}.srt» و فرمت UTF-8 BOM ذخیره شد."
                    )
                }
                rescanAllFolders(savedFolders.value, activeProfile.value)
            } else {
                _subtitleState.update {
                    it.copy(
                        isProcessing = false,
                        statusMessage = "امکان نوشتن در این پوشه وجود ندارد. یک پوشه خروجی قابل نوشتن در بخش پوشه‌ها انتخاب کنید."
                    )
                }
            }
        }
    }

    fun setSubtitleFontSize(sizeSp: Float) {
        viewModelScope.launch { prefsRepo.setSubtitleFontSize(sizeSp) }
    }

    fun setSubtitleColor(ordinal: Int) {
        viewModelScope.launch { prefsRepo.setSubtitleColorOrdinal(ordinal) }
    }

    fun setSubtitleOffsetMs(offsetMs: Long) {
        viewModelScope.launch { prefsRepo.setSubtitleOffsetMs(offsetMs) }
    }

    fun setYoutubePrefer720p(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setYoutubePrefer720p(enabled) }
    }

    fun resolveAndBookmarkYouTube(rawInput: String, onResolved: (YouTubeBookmarkEntity) -> Unit) {
        viewModelScope.launch {
            _youtubeState.update { it.copy(isLoading = true, errorMessage = null) }
            val result = YouTubeMetadataClient.fetchMetadata(rawInput)
            result.onSuccess { resolved ->
                val entity = YouTubeBookmarkEntity(
                    videoId = resolved.videoId,
                    title = resolved.title,
                    authorName = resolved.authorName,
                    thumbnailUrl = resolved.thumbnailUrl,
                    url = resolved.watchUrl,
                    lastWatchedAt = System.currentTimeMillis()
                )
                youtubeDao.upsertBookmark(entity)
                _youtubeState.update { it.copy(isLoading = false, errorMessage = null) }
                onResolved(entity)
            }.onFailure { err ->
                _youtubeState.update {
                    it.copy(isLoading = false, errorMessage = err.localizedMessage ?: "لینک معتبر نیست")
                }
            }
        }
    }

    fun onBrowserUrlChanged(url: String) {
        val id = YouTubeMetadataClient.extractVideoId(url)
        _youtubeState.update { it.copy(activeBrowserVideoId = id) }
    }

    fun deleteYouTubeBookmark(videoId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            youtubeDao.deleteBookmark(videoId)
        }
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    override fun onCleared() {
        hardwareMonitor.stop()
        transcoder.cancel()
        super.onCleared()
    }
}
