package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MidnightBg = Color(0xFF0A0D14)
val SlateSurface = Color(0xFF131824)
val SlateSurfaceElevated = Color(0xFF1B2232)
val SlateSurfaceHigh = Color(0xFF232C40)

val CinemaGold = Color(0xFFFFB300)
val CinemaGoldLight = Color(0xFFFFD54F)
val CinemaGoldDark = Color(0xFFC68400)

val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanDim = Color(0xFF0097A7)

val EmeraldConnected = Color(0xFF00E676)
val AmberWarning = Color(0xFFFFAB40)
val CoralError = Color(0xFFFF5252)

val TextPrimary = Color(0xFFF3F6FC)
val TextSecondary = Color(0xFF9AA5BD)
val OutlineSubtle = Color(0xFF2C364D)
