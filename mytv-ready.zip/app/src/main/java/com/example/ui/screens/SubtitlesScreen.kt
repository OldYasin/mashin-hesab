package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.SubtitleColorOption
import com.example.data.local.UserSettings
import com.example.media.ScannedVideoItem
import com.example.media.SubtitleEngine
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldConnected
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.SlateSurfaceElevated
import com.example.ui.viewmodel.SubtitleWorkspaceState

@Composable
fun SubtitlesScreen(
    videos: List<ScannedVideoItem>,
    subtitleState: SubtitleWorkspaceState,
    userSettings: UserSettings,
    onSelectVideo: (ScannedVideoItem) -> Unit,
    onPickSubtitleFile: (Uri, String) -> Unit,
    onExportSubtitle: () -> Unit,
    onSetFontSize: (Float) -> Unit,
    onSetColorOrdinal: (Int) -> Unit,
    onSetOffsetMs: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val subPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            var fileName = "subtitle.srt"
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) {
                    fileName = cursor.getString(idx) ?: fileName
                }
            }
            onPickSubtitleFile(uri, fileName)
        }
    }

    val activeColor = SubtitleColorOption.entries.getOrElse(userSettings.subtitleColorOrdinal) {
        SubtitleColorOption.YELLOW
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Explanation Card
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Subtitles, contentDescription = null, tint = CinemaGold)
                            Text(
                                text = "استودیو زیرنویس فارسی تلویزیون",
                                style = MaterialTheme.typography.titleLarge
                            )
                        }
                        Text(
                            text = "تلویزیون‌های قدیمی (مثل ال‌جی ۲۰۱۴) برای خواندن زیرنویس فارسی، حتماً فایل .srt با رمزگذاری UTF-8 BOM و نام دقیقاً مشابه فایل فیلم نیاز دارند. اینجا خودکار اصلاح و ذخیره می‌شود.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Step 1: Select Video
            item {
                Text("۱. انتخاب فیلم هدف", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                if (videos.isEmpty()) {
                    Surface(
                        color = SlateSurfaceElevated,
                        shape = MaterialTheme.shapes.medium,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Text(
                            text = "ابتدا در تب «پوشه‌ها» یک پوشه فیلم اضافه کنید تا فیلم‌ها اینجا لیست شوند.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                } else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(videos, key = { it.uriString }) { video ->
                            val selected = subtitleState.selectedVideo?.uriString == video.uriString
                            Card(
                                modifier = Modifier
                                    .width(210.dp)
                                    .clickable { onSelectVideo(video) }
                                    .testTag("subtitle_target_video_${video.baseName}"),
                                shape = MaterialTheme.shapes.medium,
                                colors = CardDefaults.cardColors(
                                    containerColor = if (selected) SlateSurfaceElevated else MaterialTheme.colorScheme.surface
                                ),
                                border = BorderStroke(
                                    if (selected) 1.5.dp else 1.dp,
                                    if (selected) CinemaGold else MaterialTheme.colorScheme.outline
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Movie,
                                        contentDescription = null,
                                        tint = if (selected) CinemaGold else ElectricCyan
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = video.baseName,
                                            style = MaterialTheme.typography.titleSmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = video.pairedSubtitleName ?: "بدون زیرنویس",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    if (selected) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CinemaGold, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Step 2: Pick Subtitle File + Encoding Status
            item {
                Text("۲. انتخاب و رفع خرچنگ‌قورباغه زیرنویس", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { subPickerLauncher.launch(arrayOf("*/*")) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("pick_subtitle_file_button"),
                            border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.7f))
                        ) {
                            Icon(Icons.Default.AttachFile, contentDescription = null, tint = ElectricCyan)
                            Spacer(Modifier.width(6.dp))
                            Text("انتخاب فایل زیرنویس (.srt / .vtt / .ass)", color = ElectricCyan)
                        }

                        subtitleState.parsedSubtitle?.let { parsed ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                SpecBadge(parsed.fileName, CinemaGold)
                                SpecBadge(parsed.detectedEncoding, EmeraldConnected)
                            }
                        }

                        subtitleState.statusMessage?.let { msg ->
                            Text(
                                text = msg,
                                style = MaterialTheme.typography.bodyMedium,
                                color = EmeraldConnected
                            )
                        }

                        // Timing Offset Controls
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("تنظیم هماهنگی زمان:", style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "${userSettings.subtitleSyncOffsetMs / 1000.0} ثانیه",
                                style = MaterialTheme.typography.labelLarge,
                                color = CinemaGold
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(-2000L to "-2s", -500L to "-0.5s", 0L to "0", 500L to "+0.5s", 2000L to "+2s").forEach { (delta, label) ->
                                OutlinedButton(
                                    onClick = {
                                        val next = if (delta == 0L) 0L else userSettings.subtitleSyncOffsetMs + delta
                                        onSetOffsetMs(next)
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                                ) {
                                    Text(label, style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
            }

            // Step 3: Live Cinema Preview & Styling
            item {
                Text("۳. ظاهر زیرنویس هنگام پخش روی گوشی و HDMI", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MidnightBg),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        val previewLine = subtitleState.parsedSubtitle?.cues?.firstOrNull()?.text
                            ?: "نمونه پیش‌نمایش زیرنویس فارسی در سینمای مای تیوی"
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.Black)
                                .padding(vertical = 22.dp, horizontal = 14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = previewLine,
                                color = Color(activeColor.argbHex),
                                fontSize = userSettings.subtitleFontSizeSp.sp,
                                lineHeight = (userSettings.subtitleFontSizeSp + 8f).sp
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("اندازه فونت: ${userSettings.subtitleFontSizeSp.toInt()}pt", style = MaterialTheme.typography.bodyMedium)
                            Slider(
                                value = userSettings.subtitleFontSizeSp,
                                onValueChange = onSetFontSize,
                                valueRange = 14f..32f,
                                modifier = Modifier.width(190.dp),
                                colors = SliderDefaults.colors(thumbColor = CinemaGold, activeTrackColor = CinemaGold)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("رنگ:", style = MaterialTheme.typography.bodyMedium)
                            SubtitleColorOption.entries.forEachIndexed { idx, opt ->
                                val isSelected = idx == userSettings.subtitleColorOrdinal
                                Surface(
                                    modifier = Modifier
                                        .clickable { onSetColorOrdinal(idx) },
                                    color = if (isSelected) Color(opt.argbHex).copy(alpha = 0.2f) else SlateSurfaceElevated,
                                    shape = CircleShape,
                                    border = BorderStroke(1.dp, if (isSelected) Color(opt.argbHex) else MaterialTheme.colorScheme.outline)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(Color(opt.argbHex))
                                        )
                                        Text(opt.labelFa, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }

                        Button(
                            onClick = onExportSubtitle,
                            enabled = subtitleState.selectedVideo != null && subtitleState.parsedSubtitle != null && !subtitleState.isProcessing,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("export_subtitle_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("ذخیره زیرنویس هماهنگ برای تلویزیون (.srt)")
                        }
                    }
                }
            }

            // Preview First Cues
            val previewCues = subtitleState.parsedSubtitle?.cues?.take(6).orEmpty()
            if (previewCues.isNotEmpty()) {
                item {
                    Text("پیش‌نمایش خطوط زیرنویس", style = MaterialTheme.typography.titleMedium)
                }
                items(previewCues, key = { it.index }) { cue ->
                    val shiftedStart = SubtitleEngine.formatSrtTime((cue.startMs + userSettings.subtitleSyncOffsetMs).coerceAtLeast(0L))
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = MaterialTheme.shapes.small,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = shiftedStart,
                                style = MaterialTheme.typography.labelSmall,
                                color = ElectricCyan
                            )
                            Text(
                                text = cue.text,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}
