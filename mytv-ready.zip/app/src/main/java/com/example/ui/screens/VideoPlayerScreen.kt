package com.example.ui.screens

import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.util.TypedValue
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import com.example.R
import com.example.data.local.SubtitleColorOption
import com.example.data.local.UserSettings
import com.example.hardware.HardwareConnectionState
import com.example.hardware.TvCinemaPresentation
import com.example.hardware.TvHardwareMonitor
import com.example.media.SubtitleEngine
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldConnected
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.SlateSurfaceElevated
import kotlinx.coroutines.delay

@OptIn(UnstableApi::class)
@Composable
fun VideoPlayerScreen(
    videoUriString: String,
    subtitleUriString: String?,
    title: String,
    userSettings: UserSettings,
    hardwareState: HardwareConnectionState,
    hardwareMonitor: TvHardwareMonitor,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity

    val subColor = SubtitleColorOption.entries.getOrElse(userSettings.subtitleColorOrdinal) {
        SubtitleColorOption.YELLOW
    }

    val exoPlayer = remember(videoUriString, subtitleUriString) {
        ExoPlayer.Builder(context).build().apply {
            val builder = MediaItem.Builder().setUri(Uri.parse(videoUriString))
            if (!subtitleUriString.isNullOrBlank()) {
                val subConfig = MediaItem.SubtitleConfiguration.Builder(Uri.parse(subtitleUriString))
                    .setMimeType(MimeTypes.APPLICATION_SUBRIP)
                    .setLanguage("fa")
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build()
                builder.setSubtitleConfigurations(listOf(subConfig))
            }
            setMediaItem(builder.build())
            prepare()
            playWhenReady = true
        }
    }

    var isPlaying by remember { mutableStateOf(true) }
    var currentPosMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var subtitlesEnabled by remember { mutableStateOf(!subtitleUriString.isNullOrBlank()) }
    var projectToTv by remember(hardwareState.primaryDisplay) {
        mutableStateOf(hardwareState.primaryDisplay != null && userSettings.autoLaunchTvPresentation)
    }
    var isLandscape by remember { mutableStateOf(false) }

    // Manage external HDMI / USB-C Presentation
    DisposableEffect(projectToTv, hardwareState.primaryDisplay, subtitlesEnabled) {
        val display = if (projectToTv) hardwareMonitor.getPrimaryPresentationDisplay() else null
        var presentation: TvCinemaPresentation? = null
        if (display != null) {
            presentation = TvCinemaPresentation(
                outerContext = context,
                display = display,
                exoPlayer = exoPlayer,
                subtitleFontSizeSp = userSettings.subtitleFontSizeSp,
                subtitleTextColor = subColor.argbHex
            )
            runCatching { presentation.show() }
        }
        onDispose {
            runCatching { presentation?.dismiss() }
        }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    LaunchedEffect(exoPlayer) {
        while (true) {
            currentPosMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            durationMs = exoPlayer.duration.coerceAtLeast(0L)
            delay(500L)
        }
    }

    BackHandler {
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        onBack()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBg)
            .systemBarsPadding()
    ) {
        if (projectToTv && hardwareState.primaryDisplay != null) {
            // Dual-screen Remote Control UI on Phone while TV displays full-screen cinema
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("player_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.cd_back))
                    }
                    Surface(
                        color = EmeraldConnected.copy(alpha = 0.16f),
                        shape = CircleShape,
                        border = BorderStroke(1.dp, EmeraldConnected)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Tv, contentDescription = null, tint = EmeraldConnected, modifier = Modifier.size(16.dp))
                            Text(
                                text = "در حال پخش روی ${hardwareState.primaryDisplay?.name}",
                                style = MaterialTheme.typography.labelLarge,
                                color = EmeraldConnected
                            )
                        }
                    }
                }

                Card(
                    shape = MaterialTheme.shapes.extraLarge,
                    colors = CardDefaults.cardColors(containerColor = SlateSurfaceElevated),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleLarge,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "حالت ریموت کنترل تلویزیون فعال است",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ElectricCyan
                        )

                        if (durationMs > 0L) {
                            Slider(
                                value = currentPosMs.toFloat(),
                                onValueChange = { exoPlayer.seekTo(it.toLong()) },
                                valueRange = 0f..durationMs.toFloat(),
                                colors = SliderDefaults.colors(thumbColor = CinemaGold, activeTrackColor = CinemaGold)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(SubtitleEngine.formatSrtTime(currentPosMs).substringBefore(','), style = MaterialTheme.typography.labelSmall)
                                Text(SubtitleEngine.formatSrtTime(durationMs).substringBefore(','), style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(20.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { exoPlayer.seekTo((exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L)) },
                                modifier = Modifier.size(52.dp)
                            ) {
                                Icon(Icons.Default.Replay10, contentDescription = "۱۰ ثانیه عقب", modifier = Modifier.size(32.dp))
                            }

                            FilledIconButton(
                                onClick = { if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play() },
                                modifier = Modifier
                                    .size(68.dp)
                                    .testTag("remote_play_pause"),
                                colors = IconButtonDefaults.filledIconButtonColors(containerColor = CinemaGold)
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = stringResource(R.string.cd_play_pause),
                                    modifier = Modifier.size(36.dp)
                                )
                            }

                            IconButton(
                                onClick = { exoPlayer.seekTo(exoPlayer.currentPosition + 10_000L) },
                                modifier = Modifier.size(52.dp)
                            ) {
                                Icon(Icons.Default.Forward10, contentDescription = "۱۰ ثانیه جلو", modifier = Modifier.size(32.dp))
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Surface(
                        onClick = { projectToTv = false },
                        color = SlateSurfaceElevated,
                        shape = CircleShape,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Tv, contentDescription = null, tint = CinemaGold)
                            Text("نمایش روی گوشی")
                        }
                    }
                }
            }
        } else {
            // On-device Fullscreen PlayerView
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = true
                        setShowSubtitleButton(true)
                        subtitleView?.apply {
                            setApplyEmbeddedStyles(false)
                            setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, userSettings.subtitleFontSizeSp)
                            setStyle(
                                CaptionStyleCompat(
                                    subColor.argbHex,
                                    AndroidColor.argb(175, 0, 0, 0),
                                    AndroidColor.TRANSPARENT,
                                    CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                                    AndroidColor.BLACK,
                                    null
                                )
                            )
                        }
                        player = exoPlayer
                    }
                },
                modifier = Modifier.fillMaxSize()
            )

            // Top overlay toolbar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color.Black.copy(alpha = 0.45f))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("player_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.cd_back), tint = Color.White)
                    }
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (hardwareState.primaryDisplay != null) {
                        IconButton(onClick = { projectToTv = true }) {
                            Icon(Icons.Default.Tv, contentDescription = stringResource(R.string.cd_tv_display), tint = EmeraldConnected)
                        }
                    }
                    if (!subtitleUriString.isNullOrBlank()) {
                        IconButton(
                            onClick = {
                                subtitlesEnabled = !subtitlesEnabled
                                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                    .buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subtitlesEnabled)
                                    .build()
                            }
                        ) {
                            Icon(
                                Icons.Default.Subtitles,
                                contentDescription = "زیرنویس",
                                tint = if (subtitlesEnabled) CinemaGold else Color.Gray
                            )
                        }
                    }
                    IconButton(
                        onClick = {
                            isLandscape = !isLandscape
                            activity?.requestedOrientation = if (isLandscape) {
                                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            } else {
                                ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                            }
                        }
                    ) {
                        Icon(Icons.Default.ScreenRotation, contentDescription = "چرخش صفحه", tint = Color.White)
                    }
                }
            }
        }
    }
}
