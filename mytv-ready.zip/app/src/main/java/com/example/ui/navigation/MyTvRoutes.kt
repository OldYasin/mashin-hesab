package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
object ConnectRoute

@Serializable
object FoldersRoute

@Serializable
object SubtitlesRoute

@Serializable
object YouTubeRoute

@Serializable
data class VideoPlayerRoute(
    val videoUri: String,
    val subtitleUri: String? = null,
    val title: String
)

@Serializable
data class YouTubePlayerRoute(
    val videoId: String,
    val title: String
)
