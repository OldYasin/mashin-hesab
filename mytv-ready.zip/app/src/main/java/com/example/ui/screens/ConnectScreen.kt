package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Hd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SettingsInputHdmi
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.TvProfileEntity
import com.example.data.local.UserSettings
import com.example.hardware.CableConnectionType
import com.example.hardware.HardwareConnectionState
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldConnected
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.SlateSurfaceElevated

@Composable
fun ConnectScreen(
    hardwareState: HardwareConnectionState,
    profiles: List<TvProfileEntity>,
    activeProfile: TvProfileEntity,
    userSettings: UserSettings,
    onRefreshHardware: () -> Unit,
    onSelectProfile: (Long) -> Unit,
    onCreateCustomProfile: (name: String, brand: String, maxW: Int, maxH: Int, container: String) -> Unit,
    onDeleteCustomProfile: (Long) -> Unit,
    onToggleAutoAdapt: (Boolean) -> Unit,
    onToggleAutoPresentation: (Boolean) -> Unit,
    onGoToFolders: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showCreateDialog by remember { mutableStateOf(false) }

    val statusColor by animateColorAsState(
        targetValue = when (hardwareState.connectionType) {
            CableConnectionType.HDMI_DISPLAY -> EmeraldConnected
            CableConnectionType.USB_OTG_STORAGE -> ElectricCyan
            CableConnectionType.USB_CABLE_LINKED -> AmberWarning
            CableConnectionType.DISCONNECTED -> Color(0xFF6E7B94)
        },
        label = "statusColor"
    )

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Banner
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(176.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_tv_cinema_hero_1795268961447),
                            contentDescription = stringResource(R.string.cd_tv_hero),
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            MidnightBg.copy(alpha = 0.72f),
                                            MidnightBg.copy(alpha = 0.96f)
                                        )
                                    )
                                )
                        )
                        Row(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                color = MidnightBg.copy(alpha = 0.85f),
                                shape = CircleShape,
                                border = BorderStroke(1.dp, statusColor.copy(alpha = 0.7f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(statusColor)
                                    )
                                    Text(
                                        text = hardwareState.connectionType.labelFa,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = statusColor
                                    )
                                }
                            }
                        }
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "مای تیوی — مرکز اتصال هوشمند تلویزیون",
                                style = MaterialTheme.typography.headlineSmall,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "شناسایی خودکار کابل و تطبیق فیلم، زیرنویس و یوتیوب با هر تلویزیون",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Live Cable & Hardware Telemetry Card
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    border = BorderStroke(1.dp, statusColor.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    color = statusColor.copy(alpha = 0.16f),
                                    shape = CircleShape,
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = when (hardwareState.connectionType) {
                                                CableConnectionType.HDMI_DISPLAY -> Icons.Default.SettingsInputHdmi
                                                CableConnectionType.USB_OTG_STORAGE,
                                                CableConnectionType.USB_CABLE_LINKED -> Icons.Default.Usb
                                                CableConnectionType.DISCONNECTED -> Icons.Default.Cable
                                            },
                                            contentDescription = null,
                                            tint = statusColor
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = "وضعیت سخت‌افزاری کابل و نمایشگر",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = when {
                                            hardwareState.primaryDisplay != null -> {
                                                val d = hardwareState.primaryDisplay!!
                                                "${d.name} • ${d.width}×${d.height} @ ${d.refreshRate.toInt()}Hz"
                                            }
                                            hardwareState.usbDevices.isNotEmpty() -> {
                                                hardwareState.usbDevices.joinToString("، ") { it.displayTitle }
                                            }
                                            hardwareState.isUsbPowerConnected -> {
                                                "اتصال کابل USB برقرار است (برای انتقال مستقیم از حالت OTG یا HDMI استفاده کنید)"
                                            }
                                            else -> {
                                                "کابل HDMI/USB-C یا فلش OTG متصل کنید؛ یا پروفایل تی‌وی را دستی برگزینید"
                                            }
                                        },
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            IconButton(
                                onClick = onRefreshHardware,
                                modifier = Modifier.testTag("refresh_hardware_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "بروزرسانی وضعیت کابل",
                                    tint = CinemaGold
                                )
                            }
                        }

                        // Auto-Adapt Toggles
                        Surface(
                            color = SlateSurfaceElevated,
                            shape = MaterialTheme.shapes.medium
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "تطبیق خودکار هنگام اتصال کابل",
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        Text(
                                            text = "دریافت رزولوشن و مشخصات نمایشگر و تنظیم خودکار خروجی",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Switch(
                                        checked = userSettings.autoAdaptOnCableConnect,
                                        onCheckedChange = onToggleAutoAdapt,
                                        modifier = Modifier.testTag("switch_auto_adapt")
                                    )
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "ارسال تصویر اختصاصی به تی‌وی (HDMI)",
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        Text(
                                            text = "پخش تمام‌صفحه روی تلویزیون و تبدیل گوشی به ریموت کنترل",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Switch(
                                        checked = userSettings.autoLaunchTvPresentation,
                                        onCheckedChange = onToggleAutoPresentation,
                                        modifier = Modifier.testTag("switch_auto_presentation")
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Active TV Profile Card
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "پروفایل تلویزیون فعال",
                        style = MaterialTheme.typography.titleLarge
                    )
                    TextButton(
                        onClick = { showCreateDialog = true },
                        modifier = Modifier.testTag("add_custom_profile_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("پروفایل سفارشی")
                    }
                }
                Spacer(Modifier.height(8.dp))

                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f)),
                    border = BorderStroke(1.5.dp, CinemaGold.copy(alpha = 0.7f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.Tv, contentDescription = null, tint = CinemaGold)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = activeProfile.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CinemaGold
                                )
                                Text(
                                    text = "${activeProfile.brand} • ${activeProfile.modelYearHint}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            SpecBadge("${activeProfile.maxWidth}×${activeProfile.maxHeight}", ElectricCyan)
                            SpecBadge(activeProfile.preferredContainer, CinemaGold)
                            SpecBadge(activeProfile.preferredVideoCodec, EmeraldConnected)
                            SpecBadge(if (activeProfile.preferUtf8Bom) "SRT UTF-8" else "SRT", Color(0xFFB388FF))
                        }

                        Button(
                            onClick = onGoToFolders,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("go_to_folders_cta"),
                            colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)
                        ) {
                            Icon(Icons.Default.Hd, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("انتخاب پوشه فیلم و تطبیق برای این تلویزیون")
                        }
                    }
                }
            }

            // All TV Profiles Horizontal Selector
            item {
                Text(
                    text = "انتخاب سریع مدل تلویزیون (قدیمی تا 4K)",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(profiles, key = { it.id }) { profile ->
                        val isSelected = profile.id == activeProfile.id
                        Card(
                            modifier = Modifier
                                .width(230.dp)
                                .clickable { onSelectProfile(profile.id) }
                                .testTag("tv_profile_${profile.id}"),
                            shape = MaterialTheme.shapes.medium,
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) SlateSurfaceElevated else MaterialTheme.colorScheme.surface
                            ),
                            border = BorderStroke(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) CinemaGold else MaterialTheme.colorScheme.outline
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = profile.brand,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = ElectricCyan
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (!profile.isBuiltIn) {
                                            IconButton(
                                                onClick = { onDeleteCustomProfile(profile.id) },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.DeleteOutline,
                                                    contentDescription = "حذف پروفایل",
                                                    tint = MaterialTheme.colorScheme.error,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                        if (isSelected) {
                                            Icon(
                                                Icons.Default.CheckCircle,
                                                contentDescription = "فعال",
                                                tint = CinemaGold,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                                Text(
                                    text = profile.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 2
                                )
                                Text(
                                    text = "${profile.maxHeight}p • ${profile.preferredContainer} • ${profile.preferredVideoCodec}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // Practical LG 2014 / Cable Explanation Card
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Outlined.Info, contentDescription = null, tint = ElectricCyan)
                            Text(
                                text = "راهنمای اتصال به تلویزیون‌های قدیمی (مثل ال‌جی ۲۰۱۴)",
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        Text(
                            text = "۱. چرا با گوشی‌های جدید مثل اندروید ۴ مستقیم باز نمی‌شود؟ اندروید جدید حالت USB Mass Storage قدیمی را حذف کرده و فیلم‌های جدید ۱۰۸۰p/HEVC روی ال‌جی ۲۰۱۴ اجرا نمی‌شوند.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "۲. روش اول (فلش OTG یا کابل USB): در تب «پوشه‌ها» فیلم و زیرنویس را با یک لمس به 720p MP4 (H.264) و زیرنویس UTF-8 BOM هم‌نام تبدیل و داخل فلش یا پوشه خروجی ذخیره کنید.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "۳. روش دوم (کابل HDMI / USB-C): اگر تبدیل HDMI دارید، کافیست وصل کنید؛ مای تیوی مشخصات نمایشگر را خودکار می‌خواند و فیلم، زیرنویس و یوتیوب را مستقیم روی تلویزیون پخش می‌کند.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateTvProfileDialog(
            onDismiss = { showCreateDialog = false },
            onConfirm = { name, brand, w, h, container ->
                onCreateCustomProfile(name, brand, w, h, container)
                showCreateDialog = false
            }
        )
    }
}

@Composable
fun SpecBadge(text: String, accent: Color) {
    Surface(
        color = accent.copy(alpha = 0.14f),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.4f))
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = accent,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun CreateTvProfileDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, Int, Int, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("LG") }
    var selectedRes by remember { mutableStateOf(720) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("پروفایل تلویزیون جدید") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("نام پروفایل (مثلاً LG اتاق نشیمن)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = brand,
                    onValueChange = { brand = it },
                    label = { Text("برند تلویزیون") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("حداکثر رزولوشن قابل پخش:", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(480, 720, 1080).forEach { res ->
                        OutlinedButton(
                            onClick = { selectedRes = res },
                            border = BorderStroke(
                                1.5.dp,
                                if (selectedRes == res) CinemaGold else MaterialTheme.colorScheme.outline
                            )
                        ) {
                            Text("${res}p", color = if (selectedRes == res) CinemaGold else MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val w = when (selectedRes) {
                        480 -> 854
                        1080 -> 1920
                        else -> 1280
                    }
                    onConfirm(name.ifBlank { "$brand ${selectedRes}p" }, brand, w, selectedRes, "MP4")
                },
                colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)
            ) {
                Text("ذخیره پروفایل")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف")
            }
        }
    )
}
