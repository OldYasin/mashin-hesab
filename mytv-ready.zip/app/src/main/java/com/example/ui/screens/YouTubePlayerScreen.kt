package com.example.ui.screens

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Color as AndroidColor
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.example.data.local.UserSettings
import com.example.hardware.HardwareConnectionState
import com.example.hardware.TvCinemaPresentation
import com.example.hardware.TvHardwareMonitor
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.EmeraldConnected
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.SlateSurfaceElevated

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubePlayerScreen(
    videoId: String,
    title: String,
    userSettings: UserSettings,
    hardwareState: HardwareConnectionState,
    hardwareMonitor: TvHardwareMonitor,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity

    var isLandscape by remember { mutableStateOf(false) }
    var projectToTv by remember(hardwareState.primaryDisplay) {
        mutableStateOf(hardwareState.primaryDisplay != null && userSettings.autoLaunchTvPresentation)
    }

    DisposableEffect(projectToTv, hardwareState.primaryDisplay, videoId) {
        val display = if (projectToTv) hardwareMonitor.getPrimaryPresentationDisplay() else null
        var presentation: TvCinemaPresentation? = null
        if (display != null) {
            presentation = TvCinemaPresentation(
                outerContext = context,
                display = display,
                youtubeVideoId = videoId,
                prefer720p = userSettings.youtubePrefer720p
            )
            runCatching { presentation.show() }
        }
        onDispose {
            runCatching { presentation?.dismiss() }
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    BackHandler {
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        onBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBg)
            .systemBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.6f))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("yt_player_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.cd_back), tint = Color.White)
                }
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (hardwareState.primaryDisplay != null) {
                    IconButton(onClick = { projectToTv = !projectToTv }) {
                        Icon(
                            Icons.Default.Tv,
                            contentDescription = stringResource(R.string.cd_tv_display),
                            tint = if (projectToTv) EmeraldConnected else Color.White
                        )
                    }
                }
                IconButton(
                    onClick = {
                        isLandscape = !isLandscape
                        activity?.requestedOrientation = if (isLandscape) {
                            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        } else {
                            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                        }
                    }
                ) {
                    Icon(Icons.Default.ScreenRotation, contentDescription = "چرخش صفحه", tint = Color.White)
                }
            }
        }

        if (projectToTv && hardwareState.primaryDisplay != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = MaterialTheme.shapes.extraLarge,
                    colors = CardDefaults.cardColors(containerColor = SlateSurfaceElevated),
                    border = BorderStroke(1.dp, EmeraldConnected)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Surface(
                            color = EmeraldConnected.copy(alpha = 0.16f),
                            shape = CircleShape,
                            modifier = Modifier.size(64.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Tv, contentDescription = null, tint = EmeraldConnected, modifier = Modifier.size(34.dp))
                            }
                        }
                        Text(
                            text = "در حال پخش یوتیوب روی ${hardwareState.primaryDisplay?.name}",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = title,
                            style = MaterialTheme.typography.bodyMedium,
                            color = CinemaGold
                        )
                        Button(
                            onClick = { projectToTv = false },
                            colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)
                        ) {
                            Icon(Icons.Default.Tv, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("نمایش ویدیو روی گوشی")
                        }
                    }
                }
            }
        } else {
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        setBackgroundColor(AndroidColor.BLACK)
                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            mediaPlaybackRequiresUserGesture = false
                            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        }
                        webChromeClient = WebChromeClient()
                        webViewClient = WebViewClient()
                        val qualityParam = if (userSettings.youtubePrefer720p) "&vq=hd720" else ""
                        val html = """
                            <!DOCTYPE html>
                            <html>
                            <body style="margin:0;padding:0;background:#000;overflow:hidden;">
                              <iframe width="100%" height="100%"
                                style="position:fixed;top:0;left:0;width:100vw;height:100vh;border:0;"
                                src="https://www.youtube.com/embed/$videoId?autoplay=1&playsinline=1&rel=0$qualityParam"
                                allow="autoplay; encrypted-media; fullscreen" allowfullscreen>
                              </iframe>
                            </body>
                            </html>
                        """.trimIndent()
                        loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
