package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

private val MyTvDarkColorScheme = darkColorScheme(
    primary = CinemaGold,
    onPrimary = Color(0xFF1F1600),
    primaryContainer = Color(0xFF3E2D00),
    onPrimaryContainer = CinemaGoldLight,
    secondary = ElectricCyan,
    onSecondary = Color(0xFF002026),
    secondaryContainer = Color(0xFF003640),
    onSecondaryContainer = Color(0xFFB2F5FF),
    tertiary = EmeraldConnected,
    onTertiary = Color(0xFF00210E),
    tertiaryContainer = Color(0xFF00391B),
    onTertiaryContainer = Color(0xFF9DF8BA),
    background = MidnightBg,
    onBackground = TextPrimary,
    surface = SlateSurface,
    onSurface = TextPrimary,
    surfaceVariant = SlateSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLow = SlateSurface,
    surfaceContainer = SlateSurfaceElevated,
    surfaceContainerHigh = SlateSurfaceHigh,
    outline = OutlineSubtle,
    outlineVariant = Color(0xFF1F2739),
    error = CoralError,
    onError = Color(0xFF2E0003),
    errorContainer = Color(0xFF4D0A10),
    onErrorContainer = Color(0xFFFFB4B4)
)

private val MyTvShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MyTvTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = MyTvDarkColorScheme,
            typography = Typography,
            shapes = MyTvShapes,
            content = content
        )
    }
}
