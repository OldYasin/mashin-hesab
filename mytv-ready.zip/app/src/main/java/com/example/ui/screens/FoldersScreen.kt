package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.SavedFolderEntity
import com.example.data.local.TvProfileEntity
import com.example.media.ScannedVideoItem
import com.example.media.TranscodeJobState
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.CoralError
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldConnected
import com.example.ui.theme.SlateSurfaceElevated
import java.util.Locale

@Composable
fun FoldersScreen(
    activeProfile: TvProfileEntity,
    savedFolders: List<SavedFolderEntity>,
    scannedVideos: List<ScannedVideoItem>,
    isScanning: Boolean,
    transcodeJob: TranscodeJobState,
    onAddFolder: (Uri, Boolean) -> Unit,
    onSetExportFolder: (String) -> Unit,
    onRemoveFolder: (String) -> Unit,
    onRefreshFolders: () -> Unit,
    onPlayVideo: (ScannedVideoItem) -> Unit,
    onConvertVideoForTv: (ScannedVideoItem) -> Unit,
    onOpenSubtitlesForVideo: (ScannedVideoItem) -> Unit,
    onCancelTranscode: () -> Unit,
    onDismissTranscodeBanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            onAddFolder(uri, false)
        }
    }

    val exportFolderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            onAddFolder(uri, true)
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header + Action Buttons
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "پوشه‌های فیلم و فلش USB",
                                    style = MaterialTheme.typography.titleLarge
                                )
                                Text(
                                    text = "پروفایل بررسی: ${activeProfile.name} (${activeProfile.maxHeight}p ${activeProfile.preferredContainer})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CinemaGold
                                )
                            }
                            IconButton(
                                onClick = onRefreshFolders,
                                modifier = Modifier.testTag("refresh_folders_button")
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "اسکن مجدد پوشه‌ها", tint = ElectricCyan)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { folderPickerLauncher.launch(null) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("add_folder_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)
                            ) {
                                Icon(Icons.Default.CreateNewFolder, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("افزودن پوشه فیلم", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            OutlinedButton(
                                onClick = { exportFolderPickerLauncher.launch(null) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("choose_export_folder_button"),
                                border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.6f))
                            ) {
                                Icon(Icons.Default.FolderOpen, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("مقصد USB/خروجی", color = ElectricCyan, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }

            // Saved Folders Chips
            if (savedFolders.isNotEmpty()) {
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(savedFolders, key = { it.uriString }) { folder ->
                            Surface(
                                color = if (folder.isExportTarget) {
                                    ElectricCyan.copy(alpha = 0.14f)
                                } else {
                                    SlateSurfaceElevated
                                },
                                shape = MaterialTheme.shapes.medium,
                                border = BorderStroke(
                                    1.dp,
                                    if (folder.isExportTarget) ElectricCyan else MaterialTheme.colorScheme.outline
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    IconButton(
                                        onClick = { onSetExportFolder(folder.uriString) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (folder.isExportTarget) Icons.Default.Star else Icons.Outlined.StarOutline,
                                            contentDescription = "تنظیم به عنوان پوشه خروجی",
                                            tint = if (folder.isExportTarget) ElectricCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = folder.displayName,
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        Text(
                                            text = if (folder.isExportTarget) {
                                                "${folder.lastVideoCount} فیلم • مقصد خروجی"
                                            } else {
                                                "${folder.lastVideoCount} فیلم"
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(
                                        onClick = { onRemoveFolder(folder.uriString) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Close,
                                            contentDescription = "حذف پوشه",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Active Transcode Banner
            if (transcodeJob.isRunning || transcodeJob.completedOutputUri != null || transcodeJob.errorMessage != null) {
                item {
                    TranscodeStatusCard(
                        job = transcodeJob,
                        onCancel = onCancelTranscode,
                        onDismiss = onDismissTranscodeBanner
                    )
                }
            }

            // Loading Indicator
            if (isScanning) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = CinemaGold)
                        Spacer(Modifier.width(10.dp))
                        Text("در حال بررسی فرمت و رزولوشن ویدیوها...")
                    }
                }
            }

            // Empty State
            if (savedFolders.isEmpty()) {
                item {
                    Card(
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FolderOpen,
                                contentDescription = null,
                                tint = CinemaGold,
                                modifier = Modifier.size(56.dp)
                            )
                            Text(
                                text = "هنوز پوشه‌ای اضافه نکرده‌اید",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "هر پوشه‌ای روی گوشی یا فلش USB خود دارید انتخاب کنید تا فیلم‌ها، زیرنویس‌ها و سازگاری آن‌ها با تلویزیون (مثل ال‌جی ۲۰۱۴) بررسی شود.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Button(
                                onClick = { folderPickerLauncher.launch(null) },
                                colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)
                            ) {
                                Text("انتخاب اولین پوشه فیلم")
                            }
                        }
                    }
                }
            } else if (!isScanning && scannedVideos.isEmpty()) {
                item {
                    Card(
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(44.dp))
                            Text("در پوشه‌های انتخابی فایل ویدیویی پیدا نشد", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "پوشه‌ای را انتخاب کنید که فایل‌های MP4 / MKV / AVI در آن قرار دارند.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Scanned Video Items
            items(scannedVideos, key = { it.uriString }) { video ->
                VideoFileCompatibilityCard(
                    video = video,
                    profile = activeProfile,
                    isTranscodeBusy = transcodeJob.isRunning,
                    onPlay = { onPlayVideo(video) },
                    onConvert = { onConvertVideoForTv(video) },
                    onSubtitles = { onOpenSubtitlesForVideo(video) }
                )
            }
        }
    }
}

@Composable
private fun TranscodeStatusCard(
    job: TranscodeJobState,
    onCancel: () -> Unit,
    onDismiss: () -> Unit
) {
    val borderColor = when {
        job.errorMessage != null -> CoralError
        job.completedOutputUri != null -> EmeraldConnected
        else -> CinemaGold
    }
    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = SlateSurfaceElevated),
        border = BorderStroke(1.5.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = job.sourceFileName,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (job.isRunning) {
                    OutlinedButton(onClick = onCancel) {
                        Text("لغو")
                    }
                } else {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "بستن")
                    }
                }
            }
            Text(
                text = job.errorMessage ?: job.statusMessage,
                style = MaterialTheme.typography.bodyMedium,
                color = if (job.errorMessage != null) CoralError else MaterialTheme.colorScheme.onSurface
            )
            if (job.isRunning) {
                LinearProgressIndicator(
                    progress = { (job.progressPercent / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp),
                    color = CinemaGold
                )
            }
        }
    }
}

@Composable
private fun VideoFileCompatibilityCard(
    video: ScannedVideoItem,
    profile: TvProfileEntity,
    isTranscodeBusy: Boolean,
    onPlay: () -> Unit,
    onConvert: () -> Unit,
    onSubtitles: () -> Unit
) {
    val badgeColor = if (video.isCompatibleWithTv) EmeraldConnected else AmberWarning

    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = video.fileName,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SpecBadge(
                            text = if (video.width > 0) "${video.width}×${video.height}" else "HD",
                            accent = ElectricCyan
                        )
                        SpecBadge(
                            text = "${video.containerExt} • ${video.videoCodecLabel}",
                            accent = CinemaGold
                        )
                        SpecBadge(
                            text = formatSizeMb(video.sizeBytes),
                            accent = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Compatibility status row
            Surface(
                color = badgeColor.copy(alpha = 0.12f),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (video.isCompatibleWithTv) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = badgeColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (video.isCompatibleWithTv) {
                            "کاملاً سازگار با ${profile.brand} (${profile.maxHeight}p ${profile.preferredContainer})"
                        } else {
                            video.compatibilityNotes.joinToString(" • ")
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = badgeColor
                    )
                }
            }

            // Subtitle status
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    Icons.Default.Subtitles,
                    contentDescription = null,
                    tint = if (video.pairedSubtitleName != null) EmeraldConnected else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = if (video.pairedSubtitleName != null) {
                        "زیرنویس متصل: ${video.pairedSubtitleName}"
                    } else {
                        "بدون زیرنویس هم‌نام (از دکمه زیرنویس اضافه کنید)"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onPlay,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("play_video_${video.baseName}"),
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("پخش")
                }

                FilledTonalButton(
                    onClick = onConvert,
                    enabled = !isTranscodeBusy,
                    modifier = Modifier
                        .weight(1.25f)
                        .testTag("convert_video_${video.baseName}")
                ) {
                    Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = if (video.isCompatibleWithTv) "کپی به خروجی" else "تبدیل ${profile.maxHeight}p",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                OutlinedButton(
                    onClick = onSubtitles,
                    modifier = Modifier.testTag("subtitle_video_${video.baseName}")
                ) {
                    Icon(Icons.Default.Subtitles, contentDescription = "تنظیم زیرنویس", modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

private fun formatSizeMb(bytes: Long): String {
    if (bytes <= 0L) return "-- MB"
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1024.0) {
        String.format(Locale.US, "%.1f GB", mb / 1024.0)
    } else {
        String.format(Locale.US, "%.0f MB", mb)
    }
}
