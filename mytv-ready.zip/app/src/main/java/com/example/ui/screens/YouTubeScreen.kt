package com.example.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.data.local.UserSettings
import com.example.data.local.YouTubeBookmarkEntity
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.CoralError
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.SlateSurfaceElevated
import com.example.ui.viewmodel.YouTubeInputState

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeScreen(
    isOnline: Boolean,
    userSettings: UserSettings,
    youtubeState: YouTubeInputState,
    bookmarks: List<YouTubeBookmarkEntity>,
    onToggle720p: (Boolean) -> Unit,
    onResolveAndPlay: (String) -> Unit,
    onPlayBookmark: (YouTubeBookmarkEntity) -> Unit,
    onDeleteBookmark: (String) -> Unit,
    onBrowserUrlChanged: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var urlInput by rememberSaveable { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 720.dp)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (!isOnline) {
                Surface(
                    color = CoralError.copy(alpha = 0.16f),
                    shape = MaterialTheme.shapes.medium,
                    border = BorderStroke(1.dp, CoralError.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.WifiOff, contentDescription = null, tint = CoralError)
                        Text(
                            text = "اتصال اینترنت برقرار نیست. برای پخش ویدیوهای یوتیوب اینترنت را وصل کنید.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CoralError
                        )
                    }
                }
            }

            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                    icon = { Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(18.dp)) }
                ) {
                    Text("لینک و تاریخچه")
                }
                SegmentedButton(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                    icon = { Icon(Icons.Default.Explore, contentDescription = null, modifier = Modifier.size(18.dp)) }
                ) {
                    Text("مرورگر یوتیوب")
                }
            }
        }

        if (selectedTab == 0) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Card(
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "پخش مستقیم یوتیوب روی تلویزیون",
                                style = MaterialTheme.typography.titleMedium
                            )
                            OutlinedTextField(
                                value = urlInput,
                                onValueChange = { urlInput = it },
                                label = { Text("لینک ویدیو یا شناسه یوتیوب") },
                                placeholder = { Text("https://youtu.be/...") },
                                singleLine = true,
                                trailingIcon = {
                                    IconButton(
                                        onClick = {
                                            clipboard.getText()?.text?.let { urlInput = it }
                                        }
                                    ) {
                                        Icon(Icons.Default.ContentPaste, contentDescription = "چسباندن از کلیپ‌بورد", tint = ElectricCyan)
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("youtube_url_input")
                            )

                            youtubeState.errorMessage?.let { err ->
                                Text(err, style = MaterialTheme.typography.bodySmall, color = CoralError)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "پیشنهاد کیفیت 720p (مناسب تلویزیون قدیمی)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.weight(1f)
                                )
                                Switch(
                                    checked = userSettings.youtubePrefer720p,
                                    onCheckedChange = onToggle720p
                                )
                            }

                            Button(
                                onClick = { onResolveAndPlay(urlInput) },
                                enabled = urlInput.isNotBlank() && !youtubeState.isLoading,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("play_youtube_url_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)
                            ) {
                                if (youtubeState.isLoading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("دریافت و پخش در مای تیوی")
                                }
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "ویدیوهای ذخیره‌شده و اخیر",
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                if (bookmarks.isEmpty()) {
                    item {
                        Card(
                            shape = MaterialTheme.shapes.large,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.OndemandVideo, contentDescription = null, tint = CinemaGold, modifier = Modifier.size(44.dp))
                                Text("هنوز ویدیوی یوتیوبی باز نکرده‌اید", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "لینک یک ویدیو را اینجا بچسبانید یا از تب «مرورگر یوتیوب» ویدیوی دلخواهتان را انتخاب کنید.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(bookmarks, key = { it.videoId }) { item ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPlayBookmark(item) },
                            shape = MaterialTheme.shapes.medium,
                            colors = CardDefaults.cardColors(containerColor = SlateSurfaceElevated),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                AsyncImage(
                                    model = item.thumbnailUrl,
                                    contentDescription = item.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(width = 112.dp, height = 64.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = item.authorName,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = ElectricCyan,
                                        maxLines = 1
                                    )
                                }
                                IconButton(onClick = { onDeleteBookmark(item.videoId) }) {
                                    Icon(
                                        Icons.Default.DeleteOutline,
                                        contentDescription = "حذف",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Integrated YouTube Browser with automatic TV Cinema bridge bar
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 900.dp)
            ) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                mediaPlaybackRequiresUserGesture = false
                                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            }
                            webChromeClient = WebChromeClient()
                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                    super.onPageStarted(view, url, favicon)
                                    if (url != null) onBrowserUrlChanged(url)
                                }

                                override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                                    super.doUpdateVisitedHistory(view, url, isReload)
                                    if (url != null) onBrowserUrlChanged(url)
                                }

                                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                    val target = request?.url?.toString() ?: return false
                                    onBrowserUrlChanged(target)
                                    return false
                                }
                            }
                            loadUrl("https://m.youtube.com")
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )

                val detectedId = youtubeState.activeBrowserVideoId
                androidx.compose.animation.AnimatedVisibility(
                    visible = detectedId != null,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                ) {
                    Button(
                        onClick = { detectedId?.let { onResolveAndPlay(it) } },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("cast_browser_youtube_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)
                    ) {
                        Icon(Icons.Default.Cast, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("ارسال و پخش تمام‌صفحه در مای تیوی / تلویزیون")
                    }
                }
            }
        }
    }
}
