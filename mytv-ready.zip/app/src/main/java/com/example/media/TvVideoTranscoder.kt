package com.example.media

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.example.data.local.TvProfileEntity
import java.io.File
import java.io.FileInputStream
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

data class TranscodeJobState(
    val isRunning: Boolean = false,
    val sourceFileName: String = "",
    val targetProfileName: String = "",
    val progressPercent: Int = 0,
    val statusMessage: String = "",
    val completedOutputUri: String? = null,
    val errorMessage: String? = null
)

class TvVideoTranscoder(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private var activeTransformer: Transformer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isCancelled = false

    @OptIn(UnstableApi::class)
    fun startAdaptation(
        sourceVideo: ScannedVideoItem,
        profile: TvProfileEntity,
        exportFolderUri: Uri?,
        subtitleOffsetMs: Long,
        onStateUpdate: (TranscodeJobState) -> Unit
    ) {
        cancel()
        isCancelled = false

        val safeBaseName = "${sourceVideo.baseName}_${profile.maxHeight}p_TV"
        val cacheOutFile = File(context.cacheDir, "$safeBaseName.mp4")
        if (cacheOutFile.exists()) cacheOutFile.delete()

        val sourceUri = Uri.parse(sourceVideo.uriString)
        val inputMediaItem = MediaItem.fromUri(sourceUri)

        val videoEffects = if (sourceVideo.height == 0 || sourceVideo.height > profile.maxHeight) {
            listOf(Presentation.createForHeight(profile.maxHeight))
        } else {
            emptyList()
        }

        val editedMediaItem = EditedMediaItem.Builder(inputMediaItem)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()

        onStateUpdate(
            TranscodeJobState(
                isRunning = true,
                sourceFileName = sourceVideo.fileName,
                targetProfileName = profile.name,
                progressPercent = 0,
                statusMessage = "در حال تبدیل ویدیو به ${profile.maxHeight}p MP4 (H.264)..."
            )
        )

        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                if (isCancelled) return
                onStateUpdate(
                    TranscodeJobState(
                        isRunning = true,
                        sourceFileName = sourceVideo.fileName,
                        targetProfileName = profile.name,
                        progressPercent = 96,
                        statusMessage = "در حال ذخیره فیلم و زیرنویس هماهنگ در پوشه خروجی..."
                    )
                )
                scope.launch(Dispatchers.IO) {
                    val savedUri = writeOutputToDestination(
                        cacheFile = cacheOutFile,
                        outputBaseName = safeBaseName,
                        exportFolderUri = exportFolderUri,
                        pairedSubtitleUri = sourceVideo.pairedSubtitleUriString?.let(Uri::parse),
                        pairedSubtitleName = sourceVideo.pairedSubtitleName,
                        subtitleOffsetMs = subtitleOffsetMs
                    )
                    cacheOutFile.delete()
                    if (savedUri != null) {
                        onStateUpdate(
                            TranscodeJobState(
                                isRunning = false,
                                sourceFileName = sourceVideo.fileName,
                                targetProfileName = profile.name,
                                progressPercent = 100,
                                statusMessage = "آماده پخش روی تلویزیون شد! ($safeBaseName.mp4)",
                                completedOutputUri = savedUri.toString()
                            )
                        )
                    } else {
                        onStateUpdate(
                            TranscodeJobState(
                                isRunning = false,
                                sourceFileName = sourceVideo.fileName,
                                targetProfileName = profile.name,
                                errorMessage = "خطا در ذخیره فایل نهایی در پوشه خروجی."
                            )
                        )
                    }
                }
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                cacheOutFile.delete()
                if (isCancelled) return
                onStateUpdate(
                    TranscodeJobState(
                        isRunning = false,
                        sourceFileName = sourceVideo.fileName,
                        targetProfileName = profile.name,
                        errorMessage = "تبدیل ویدیو متوقف شد: ${exportException.localizedMessage ?: "کدک ورودی پشتیبانی نشد"}"
                    )
                )
            }
        }

        mainHandler.post {
            val transformer = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(listener)
                .build()
            activeTransformer = transformer
            transformer.start(editedMediaItem, cacheOutFile.absolutePath)

            val progressHolder = ProgressHolder()
            val progressRunnable = object : Runnable {
                override fun run() {
                    if (isCancelled || activeTransformer !== transformer) return
                    val state = transformer.getProgress(progressHolder)
                    if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                        onStateUpdate(
                            TranscodeJobState(
                                isRunning = true,
                                sourceFileName = sourceVideo.fileName,
                                targetProfileName = profile.name,
                                progressPercent = progressHolder.progress.coerceIn(1, 95),
                                statusMessage = "در حال کدگذاری برای تلویزیون (${progressHolder.progress}٪)..."
                            )
                        )
                    }
                    if (state != Transformer.PROGRESS_STATE_NOT_STARTED) {
                        mainHandler.postDelayed(this, 450L)
                    }
                }
            }
            mainHandler.postDelayed(progressRunnable, 450L)
        }
    }

    fun cancel() {
        isCancelled = true
        mainHandler.post {
            runCatching { activeTransformer?.cancel() }
            activeTransformer = null
        }
    }

    private fun writeOutputToDestination(
        cacheFile: File,
        outputBaseName: String,
        exportFolderUri: Uri?,
        pairedSubtitleUri: Uri?,
        pairedSubtitleName: String?,
        subtitleOffsetMs: Long
    ): Uri? {
        val outputVideoName = "$outputBaseName.mp4"

        if (exportFolderUri != null) {
            val tree = DocumentFile.fromTreeUri(context, exportFolderUri)
            if (tree != null && tree.canWrite()) {
                tree.findFile(outputVideoName)?.delete()
                val destDoc = tree.createFile("video/mp4", outputVideoName)
                if (destDoc != null) {
                    context.contentResolver.openOutputStream(destDoc.uri)?.use { out ->
                        FileInputStream(cacheFile).use { input -> input.copyTo(out) }
                    }
                    if (pairedSubtitleUri != null) {
                        val parsed = SubtitleEngine.parseSubtitle(
                            context,
                            pairedSubtitleUri,
                            pairedSubtitleName ?: "sub.srt"
                        )
                        val shifted = SubtitleEngine.applyOffsetAndBuildSrt(parsed.cues, subtitleOffsetMs)
                        SubtitleEngine.exportSrtToFolder(
                            context = context,
                            targetTreeUri = exportFolderUri,
                            movieBaseName = outputBaseName,
                            srtContent = shifted,
                            includeUtf8Bom = true
                        )
                    }
                    return destDoc.uri
                }
            }
        }

        // Fallback to MediaStore Movies/MyTV (zero-permission on Android 10+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, outputVideoName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/MyTV")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(cacheFile).use { input -> input.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri
        }
        return null
    }
}
