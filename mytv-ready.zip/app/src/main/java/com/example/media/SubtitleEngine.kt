package com.example.media

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.ByteArrayOutputStream
import java.nio.charset.Charset
import java.util.Locale

data class SubtitleCue(
    val index: Int,
    val startMs: Long,
    val endMs: Long,
    val text: String
) {
    val startFormatted: String get() = SubtitleEngine.formatSrtTime(startMs)
    val endFormatted: String get() = SubtitleEngine.formatSrtTime(endMs)
}

data class ParsedSubtitleResult(
    val fileName: String,
    val detectedEncoding: String,
    val cues: List<SubtitleCue>,
    val rawNormalizedSrt: String
)

object SubtitleEngine {

    private val windows1256: Charset = Charset.forName("windows-1256")

    fun parseSubtitle(context: Context, uri: Uri, displayName: String): ParsedSubtitleResult {
        val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArrayOutputStream()
            input.copyTo(buffer)
            buffer.toByteArray()
        } ?: ByteArray(0)

        val (encodingName, decodedText) = decodeSmart(bytes)
        val normalized = normalizeToSrt(decodedText, displayName)
        val cues = parseSrtCues(normalized)
        return ParsedSubtitleResult(
            fileName = displayName,
            detectedEncoding = encodingName,
            cues = cues,
            rawNormalizedSrt = normalized
        )
    }

    fun applyOffsetAndBuildSrt(cues: List<SubtitleCue>, offsetMs: Long): String {
        val sb = StringBuilder()
        cues.forEachIndexed { idx, cue ->
            val newStart = (cue.startMs + offsetMs).coerceAtLeast(0L)
            val newEnd = (cue.endMs + offsetMs).coerceAtLeast(newStart + 200L)
            sb.append(idx + 1).append('\n')
            sb.append(formatSrtTime(newStart)).append(" --> ").append(formatSrtTime(newEnd)).append('\n')
            sb.append(cue.text.trim()).append("\n\n")
        }
        return sb.toString()
    }

    fun exportSrtToFolder(
        context: Context,
        targetTreeUri: Uri,
        movieBaseName: String,
        srtContent: String,
        includeUtf8Bom: Boolean = true
    ): Uri? {
        val tree = DocumentFile.fromTreeUri(context, targetTreeUri) ?: return null
        val targetFileName = "$movieBaseName.srt"
        tree.findFile(targetFileName)?.delete()
        val created = tree.createFile("application/x-subrip", targetFileName) ?: return null
        context.contentResolver.openOutputStream(created.uri)?.use { out ->
            if (includeUtf8Bom) {
                out.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
            }
            out.write(srtContent.toByteArray(Charsets.UTF_8))
            out.flush()
        } ?: return null
        return created.uri
    }

    private fun decodeSmart(bytes: ByteArray): Pair<String, String> {
        if (bytes.size >= 3 &&
            bytes[0] == 0xEF.toByte() &&
            bytes[1] == 0xBB.toByte() &&
            bytes[2] == 0xBF.toByte()
        ) {
            return "UTF-8 (BOM)" to String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) {
            return "UTF-16LE" to String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) {
            return "UTF-16BE" to String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
        }

        if (isValidUtf8(bytes)) {
            val utf8Text = String(bytes, Charsets.UTF_8)
            // Check if non-ASCII exists; if valid UTF-8, return UTF-8
            return "UTF-8" to utf8Text
        }

        // Fallback to Windows-1256 (standard Persian/Arabic legacy ANSI SRT encoding)
        return "Windows-1256 (تبدیل خودکار فارسی)" to String(bytes, windows1256)
    }

    private fun isValidUtf8(bytes: ByteArray): Boolean {
        var i = 0
        while (i < bytes.size) {
            val b = bytes[i].toInt() and 0xFF
            val len = when {
                b <= 0x7F -> 1
                b in 0xC2..0xDF -> 2
                b in 0xE0..0xEF -> 3
                b in 0xF0..0xF4 -> 4
                else -> return false
            }
            if (i + len > bytes.size) return false
            for (j in 1 until len) {
                val c = bytes[i + j].toInt() and 0xFF
                if (c !in 0x80..0xBF) return false
            }
            i += len
        }
        return true
    }

    private fun normalizeToSrt(raw: String, fileName: String): String {
        val clean = raw.replace("\r\n", "\n").replace("\r", "\n").trim()
        val lower = fileName.lowercase(Locale.US)
        return when {
            lower.endsWith(".vtt") || clean.startsWith("WEBVTT") -> convertVttToSrt(clean)
            lower.endsWith(".ass") || lower.endsWith(".ssa") -> convertAssToSrt(clean)
            else -> clean
        }
    }

    private fun convertVttToSrt(vtt: String): String {
        val lines = vtt.lines().dropWhile { !it.contains("-->") }
        val sb = StringBuilder()
        var index = 1
        var i = 0
        while (i < lines.size) {
            val line = lines[i].trim()
            if (line.contains("-->")) {
                val timeParts = line.split("-->")
                val start = timeParts[0].trim().replace('.', ',')
                val end = timeParts.getOrNull(1)?.trim()?.split(" ")?.firstOrNull()?.replace('.', ',') ?: start
                val fixedStart = if (start.count { it == ':' } == 1) "00:$start" else start
                val fixedEnd = if (end.count { it == ':' } == 1) "00:$end" else end
                val textLines = mutableListOf<String>()
                i++
                while (i < lines.size && lines[i].isNotBlank()) {
                    textLines.add(lines[i].replace(Regex("<[^>]+>"), ""))
                    i++
                }
                if (textLines.isNotEmpty()) {
                    sb.append(index++).append('\n')
                    sb.append(fixedStart).append(" --> ").append(fixedEnd).append('\n')
                    sb.append(textLines.joinToString("\n")).append("\n\n")
                }
            }
            i++
        }
        return sb.toString()
    }

    private fun convertAssToSrt(ass: String): String {
        val sb = StringBuilder()
        var index = 1
        ass.lines().filter { it.startsWith("Dialogue:") }.forEach { line ->
            val parts = line.removePrefix("Dialogue:").split(",", limit = 10)
            if (parts.size >= 10) {
                val startMs = parseAssTimeMs(parts[1].trim())
                val endMs = parseAssTimeMs(parts[2].trim())
                val text = parts[9]
                    .replace("\\N", "\n")
                    .replace("\\n", "\n")
                    .replace(Regex("\\{[^}]*\\}"), "")
                    .trim()
                if (text.isNotEmpty()) {
                    sb.append(index++).append('\n')
                    sb.append(formatSrtTime(startMs)).append(" --> ").append(formatSrtTime(endMs)).append('\n')
                    sb.append(text).append("\n\n")
                }
            }
        }
        return sb.toString()
    }

    private fun parseSrtCues(srt: String): List<SubtitleCue> {
        val blocks = srt.split(Regex("\n\\s*\n"))
        val result = mutableListOf<SubtitleCue>()
        val timeRegex = Regex("""(\d{1,2}:\d{2}:\d{2}[,.]\d{3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[,.]\d{3})""")
        blocks.forEach { block ->
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            val timeLineIdx = lines.indexOfFirst { timeRegex.containsMatchIn(it) }
            if (timeLineIdx >= 0) {
                val match = timeRegex.find(lines[timeLineIdx]) ?: return@forEach
                val startMs = parseSrtTimeMs(match.groupValues[1])
                val endMs = parseSrtTimeMs(match.groupValues[2])
                val text = lines.drop(timeLineIdx + 1)
                    .joinToString("\n")
                    .replace(Regex("<[^>]+>"), "")
                if (text.isNotBlank()) {
                    result.add(
                        SubtitleCue(
                            index = result.size + 1,
                            startMs = startMs,
                            endMs = endMs,
                            text = text
                        )
                    )
                }
            }
        }
        return result
    }

    private fun parseSrtTimeMs(raw: String): Long {
        val parts = raw.replace(',', '.').split(":", ".")
        if (parts.size < 4) return 0L
        val h = parts[0].toLongOrNull() ?: 0L
        val m = parts[1].toLongOrNull() ?: 0L
        val s = parts[2].toLongOrNull() ?: 0L
        val ms = parts[3].padEnd(3, '0').take(3).toLongOrNull() ?: 0L
        return ((h * 3600) + (m * 60) + s) * 1000L + ms
    }

    private fun parseAssTimeMs(raw: String): Long {
        val parts = raw.split(":", ".")
        if (parts.size < 4) return 0L
        val h = parts[0].toLongOrNull() ?: 0L
        val m = parts[1].toLongOrNull() ?: 0L
        val s = parts[2].toLongOrNull() ?: 0L
        val cs = parts[3].toLongOrNull() ?: 0L
        return ((h * 3600) + (m * 60) + s) * 1000L + (cs * 10L)
    }

    fun formatSrtTime(ms: Long): String {
        val clamped = ms.coerceAtLeast(0L)
        val hours = clamped / 3_600_000L
        val minutes = (clamped % 3_600_000L) / 60_000L
        val seconds = (clamped % 60_000L) / 1_000L
        val millis = clamped % 1_000L
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
    }
}
