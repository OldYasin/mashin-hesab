package com.example.media

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

@Serializable
private data class YouTubeOEmbedDto(
    val title: String? = null,
    val author_name: String? = null,
    val thumbnail_url: String? = null
)

data class ResolvedYouTubeVideo(
    val videoId: String,
    val title: String,
    val authorName: String,
    val thumbnailUrl: String,
    val watchUrl: String
)

object YouTubeMetadataClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true }

    private val idPatterns = listOf(
        Regex("""(?:youtube\.com/watch\?.*?v=|youtu\.be/|youtube\.com/embed/|youtube\.com/shorts/|youtube\.com/live/)([A-Za-z0-9_-]{11})"""),
        Regex("""^([A-Za-z0-9_-]{11})$""")
    )

    fun extractVideoId(input: String): String? {
        val trimmed = input.trim()
        for (regex in idPatterns) {
            val match = regex.find(trimmed)
            if (match != null) return match.groupValues[1]
        }
        return null
    }

    suspend fun fetchMetadata(rawUrlOrId: String): Result<ResolvedYouTubeVideo> = withContext(Dispatchers.IO) {
        val videoId = extractVideoId(rawUrlOrId)
            ?: return@withContext Result.failure(IllegalArgumentException("لینک یا شناسه یوتیوب معتبر نیست"))

        val watchUrl = "https://www.youtube.com/watch?v=$videoId"
        val fallbackThumb = "https://img.youtube.com/vi/$videoId/hqdefault.jpg"

        return@withContext runCatching {
            val encodedUrl = URLEncoder.encode(watchUrl, "UTF-8")
            val request = Request.Builder()
                .url("https://www.youtube.com/oembed?url=$encodedUrl&format=json")
                .header("User-Agent", "MyTV-Android/1.0")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@runCatching ResolvedYouTubeVideo(
                        videoId = videoId,
                        title = "ویدیو یوتیوب ($videoId)",
                        authorName = "YouTube",
                        thumbnailUrl = fallbackThumb,
                        watchUrl = watchUrl
                    )
                }
                val body = response.body?.string().orEmpty()
                val dto = json.decodeFromString<YouTubeOEmbedDto>(body)
                ResolvedYouTubeVideo(
                    videoId = videoId,
                    title = dto.title?.takeIf { it.isNotBlank() } ?: "ویدیو یوتیوب ($videoId)",
                    authorName = dto.author_name?.takeIf { it.isNotBlank() } ?: "YouTube",
                    thumbnailUrl = dto.thumbnail_url?.takeIf { it.isNotBlank() } ?: fallbackThumb,
                    watchUrl = watchUrl
                )
            }
        }.recover {
            ResolvedYouTubeVideo(
                videoId = videoId,
                title = "ویدیو یوتیوب ($videoId)",
                authorName = "YouTube",
                thumbnailUrl = fallbackThumb,
                watchUrl = watchUrl
            )
        }
    }
}
