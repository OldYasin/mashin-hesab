package com.example.media

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.example.data.local.TvProfileEntity
import java.util.Locale

data class ScannedVideoItem(
    val uriString: String,
    val folderUriString: String,
    val fileName: String,
    val baseName: String,
    val containerExt: String,
    val width: Int,
    val height: Int,
    val durationMs: Long,
    val sizeBytes: Long,
    val videoCodecLabel: String,
    val pairedSubtitleUriString: String?,
    val pairedSubtitleName: String?,
    val isCompatibleWithTv: Boolean,
    val compatibilityNotes: List<String>
)

object FolderScanner {

    private val videoExtensions = setOf("mp4", "mkv", "avi", "mov", "webm", "m4v", "ts", "flv", "3gp")
    private val subtitleExtensions = setOf("srt", "vtt", "ass", "ssa")

    fun scanFolder(
        context: Context,
        folderUri: Uri,
        activeProfile: TvProfileEntity
    ): List<ScannedVideoItem> {
        val rootDoc = DocumentFile.fromTreeUri(context, folderUri) ?: return emptyList()
        if (!rootDoc.exists() || !rootDoc.isDirectory) return emptyList()

        val allFiles = rootDoc.listFiles().filter { it.isFile && !it.name.isNullOrBlank() }
        val subtitleDocs = allFiles.filter { doc ->
            val ext = doc.name.orEmpty().substringAfterLast('.', "").lowercase(Locale.US)
            ext in subtitleExtensions
        }
        val subtitleByBaseName = subtitleDocs.associateBy { doc ->
            doc.name.orEmpty().substringBeforeLast('.').lowercase(Locale.US)
        }

        val videoDocs = allFiles.filter { doc ->
            val name = doc.name.orEmpty()
            val ext = name.substringAfterLast('.', "").lowercase(Locale.US)
            ext in videoExtensions || (doc.type?.startsWith("video/") == true)
        }

        return videoDocs.map { doc ->
            inspectVideoFile(
                context = context,
                doc = doc,
                folderUriString = folderUri.toString(),
                subtitleByBaseName = subtitleByBaseName,
                profile = activeProfile
            )
        }.sortedBy { it.fileName.lowercase(Locale.US) }
    }

    fun evaluateCompatibility(
        containerExt: String,
        width: Int,
        height: Int,
        codecLabel: String,
        profile: TvProfileEntity
    ): Pair<Boolean, List<String>> {
        val notes = mutableListOf<String>()
        val extLower = containerExt.lowercase(Locale.US)

        if (profile.preferredContainer.equals("MP4", ignoreCase = true) && extLower != "mp4") {
            notes.add("فرمت $containerExt باید به MP4 تبدیل شود")
        }
        if (height > profile.maxHeight || width > profile.maxWidth) {
            notes.add("رزولوشن ${width}×${height} بالاتر از سقف ${profile.maxHeight}p تلویزیون است")
        }
        if (profile.preferredVideoCodec.contains("H.264") &&
            !profile.preferredVideoCodec.contains("HEVC") &&
            (codecLabel.contains("HEVC", true) || codecLabel.contains("H.265", true) || codecLabel.contains("VP9", true) || codecLabel.contains("AV1", true))
        ) {
            notes.add("کدک $codecLabel روی این تلویزیون پخش نمی‌شود (نیاز به H.264)")
        }

        return notes.isEmpty() to notes
    }

    private fun inspectVideoFile(
        context: Context,
        doc: DocumentFile,
        folderUriString: String,
        subtitleByBaseName: Map<String, DocumentFile>,
        profile: TvProfileEntity
    ): ScannedVideoItem {
        val fileName = doc.name ?: "video.mp4"
        val baseName = fileName.substringBeforeLast('.')
        val ext = fileName.substringAfterLast('.', "mp4").uppercase(Locale.US)

        var width = 0
        var height = 0
        var durationMs = 0L
        var codecLabel = "نامشخص"

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, doc.uri)
            width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
        } finally {
            runCatching { retriever.release() }
        }

        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, doc.uri, null)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/")) {
                    codecLabel = when {
                        mime.contains("avc", true) -> "H.264 (AVC)"
                        mime.contains("hevc", true) -> "HEVC (H.265)"
                        mime.contains("vp9", true) -> "VP9"
                        mime.contains("av01", true) -> "AV1"
                        mime.contains("mp4v", true) -> "MPEG-4"
                        else -> mime.removePrefix("video/").uppercase(Locale.US)
                    }
                    if (width == 0 && format.containsKey(MediaFormat.KEY_WIDTH)) {
                        width = format.getInteger(MediaFormat.KEY_WIDTH)
                    }
                    if (height == 0 && format.containsKey(MediaFormat.KEY_HEIGHT)) {
                        height = format.getInteger(MediaFormat.KEY_HEIGHT)
                    }
                    break
                }
            }
        } catch (_: Exception) {
        } finally {
            runCatching { extractor.release() }
        }

        val matchedSub = subtitleByBaseName[baseName.lowercase(Locale.US)]
        val (compatible, notes) = evaluateCompatibility(ext, width, height, codecLabel, profile)

        return ScannedVideoItem(
            uriString = doc.uri.toString(),
            folderUriString = folderUriString,
            fileName = fileName,
            baseName = baseName,
            containerExt = ext,
            width = width,
            height = height,
            durationMs = durationMs,
            sizeBytes = doc.length(),
            videoCodecLabel = codecLabel,
            pairedSubtitleUriString = matchedSub?.uri?.toString(),
            pairedSubtitleName = matchedSub?.name,
            isCompatibleWithTv = compatible,
            compatibilityNotes = notes
        )
    }
}
