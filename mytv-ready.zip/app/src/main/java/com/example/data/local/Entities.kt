package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tv_profiles")
data class TvProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val brand: String,
    val modelYearHint: String,
    val maxWidth: Int,
    val maxHeight: Int,
    val maxFps: Int = 30,
    val preferredContainer: String = "MP4",
    val preferredVideoCodec: String = "H.264 (AVC)",
    val preferredAudioCodec: String = "AAC",
    val supportsSrt: Boolean = true,
    val preferUtf8Bom: Boolean = true,
    val isBuiltIn: Boolean = false
)

@Entity(tableName = "saved_folders")
data class SavedFolderEntity(
    @PrimaryKey val uriString: String,
    val displayName: String,
    val isExportTarget: Boolean = false,
    val lastVideoCount: Int = 0,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "youtube_bookmarks")
data class YouTubeBookmarkEntity(
    @PrimaryKey val videoId: String,
    val title: String,
    val authorName: String,
    val thumbnailUrl: String,
    val url: String,
    val lastWatchedAt: Long = System.currentTimeMillis()
)
