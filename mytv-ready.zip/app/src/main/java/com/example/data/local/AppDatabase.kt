package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

object TvProfilePresets {
    val builtInProfiles = listOf(
        TvProfileEntity(
            id = 1L,
            name = "ال‌جی کلاسیک ۲۰۱۴ (NetCast / webOS 1.0)",
            brand = "LG",
            modelYearHint = "2012–2015 (مثل LG 2014)",
            maxWidth = 1280,
            maxHeight = 720,
            maxFps = 30,
            preferredContainer = "MP4",
            preferredVideoCodec = "H.264 (AVC)",
            preferredAudioCodec = "AAC",
            supportsSrt = true,
            preferUtf8Bom = true,
            isBuiltIn = true
        ),
        TvProfileEntity(
            id = 2L,
            name = "ال‌جی اسمارت (webOS 2.0 تا 2024)",
            brand = "LG",
            modelYearHint = "2016–2024",
            maxWidth = 1920,
            maxHeight = 1080,
            maxFps = 60,
            preferredContainer = "MP4",
            preferredVideoCodec = "H.264 / HEVC",
            preferredAudioCodec = "AAC / AC3",
            supportsSrt = true,
            preferUtf8Bom = true,
            isBuiltIn = true
        ),
        TvProfileEntity(
            id = 3L,
            name = "سامسونگ کلاسیک (سری D / F / H)",
            brand = "Samsung",
            modelYearHint = "2011–2015",
            maxWidth = 1920,
            maxHeight = 1080,
            maxFps = 30,
            preferredContainer = "MP4",
            preferredVideoCodec = "H.264 (AVC)",
            preferredAudioCodec = "AAC",
            supportsSrt = true,
            preferUtf8Bom = true,
            isBuiltIn = true
        ),
        TvProfileEntity(
            id = 4L,
            name = "سامسونگ تایزن 4K",
            brand = "Samsung",
            modelYearHint = "2016–2024",
            maxWidth = 3840,
            maxHeight = 2160,
            maxFps = 60,
            preferredContainer = "MP4",
            preferredVideoCodec = "H.264 / HEVC",
            preferredAudioCodec = "AAC",
            supportsSrt = true,
            preferUtf8Bom = true,
            isBuiltIn = true
        ),
        TvProfileEntity(
            id = 5L,
            name = "سونی براویا (قدیمی و جدید)",
            brand = "Sony",
            modelYearHint = "2013–2024",
            maxWidth = 1920,
            maxHeight = 1080,
            maxFps = 30,
            preferredContainer = "MP4",
            preferredVideoCodec = "H.264 (AVC)",
            preferredAudioCodec = "AAC",
            supportsSrt = true,
            preferUtf8Bom = true,
            isBuiltIn = true
        ),
        TvProfileEntity(
            id = 6L,
            name = "تی‌سی‌ال / هایسنس / اندروید تی‌وی",
            brand = "Android TV",
            modelYearHint = "همه‌کاره HD/FHD",
            maxWidth = 1920,
            maxHeight = 1080,
            maxFps = 60,
            preferredContainer = "MP4",
            preferredVideoCodec = "H.264 (AVC)",
            preferredAudioCodec = "AAC",
            supportsSrt = true,
            preferUtf8Bom = true,
            isBuiltIn = true
        ),
        TvProfileEntity(
            id = 7L,
            name = "تطبیق عمومی 480p (تلویزیون‌های خیلی قدیمی / گیرنده دیجیتال)",
            brand = "Universal Legacy",
            modelYearHint = "ست‌تاپ باکس و تی‌وی قدیمی",
            maxWidth = 854,
            maxHeight = 480,
            maxFps = 30,
            preferredContainer = "MP4",
            preferredVideoCodec = "H.264 (AVC)",
            preferredAudioCodec = "AAC",
            supportsSrt = true,
            preferUtf8Bom = true,
            isBuiltIn = true
        )
    )
}

@Database(
    entities = [
        TvProfileEntity::class,
        SavedFolderEntity::class,
        YouTubeBookmarkEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tvProfileDao(): TvProfileDao
    abstract fun savedFolderDao(): SavedFolderDao
    abstract fun youtubeBookmarkDao(): YouTubeBookmarkDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mytv_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
