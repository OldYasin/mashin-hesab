package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TvProfileDao {
    @Query("SELECT * FROM tv_profiles ORDER BY isBuiltIn DESC, id ASC")
    fun getAllProfiles(): Flow<List<TvProfileEntity>>

    @Query("SELECT * FROM tv_profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: Long): TvProfileEntity?

    @Query("SELECT COUNT(*) FROM tv_profiles")
    suspend fun getProfileCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: TvProfileEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfiles(profiles: List<TvProfileEntity>)

    @Query("DELETE FROM tv_profiles WHERE id = :id AND isBuiltIn = 0")
    suspend fun deleteCustomProfile(id: Long)
}

@Dao
interface SavedFolderDao {
    @Query("SELECT * FROM saved_folders ORDER BY isExportTarget DESC, addedAt DESC")
    fun getAllFolders(): Flow<List<SavedFolderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolder(folder: SavedFolderEntity)

    @Query("UPDATE saved_folders SET isExportTarget = (uriString = :uriString)")
    suspend fun setExportTarget(uriString: String)

    @Query("UPDATE saved_folders SET lastVideoCount = :count WHERE uriString = :uriString")
    suspend fun updateVideoCount(uriString: String, count: Int)

    @Query("DELETE FROM saved_folders WHERE uriString = :uriString")
    suspend fun deleteFolder(uriString: String)
}

@Dao
interface YouTubeBookmarkDao {
    @Query("SELECT * FROM youtube_bookmarks ORDER BY lastWatchedAt DESC")
    fun getAllBookmarks(): Flow<List<YouTubeBookmarkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBookmark(bookmark: YouTubeBookmarkEntity)

    @Query("DELETE FROM youtube_bookmarks WHERE videoId = :videoId")
    suspend fun deleteBookmark(videoId: String)
}
