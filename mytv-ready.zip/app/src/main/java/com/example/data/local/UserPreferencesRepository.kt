package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "mytv_prefs")

enum class SubtitleColorOption(val labelFa: String, val argbHex: Int) {
    YELLOW("زرد سینمایی", 0xFFFFD54F.toInt()),
    WHITE("سفید روشن", 0xFFFFFFFF.toInt()),
    CYAN("فیروزه‌ای", 0xFF00E5FF.toInt())
}

data class UserSettings(
    val selectedProfileId: Long = 1L,
    val autoAdaptOnCableConnect: Boolean = true,
    val autoLaunchTvPresentation: Boolean = true,
    val subtitleFontSizeSp: Float = 20f,
    val subtitleColorOrdinal: Int = 0,
    val subtitleSyncOffsetMs: Long = 0L,
    val youtubePrefer720p: Boolean = true
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val SELECTED_PROFILE_ID = longPreferencesKey("selected_profile_id")
        val AUTO_ADAPT_CABLE = booleanPreferencesKey("auto_adapt_cable")
        val AUTO_LAUNCH_PRESENTATION = booleanPreferencesKey("auto_launch_presentation")
        val SUBTITLE_FONT_SIZE = floatPreferencesKey("subtitle_font_size")
        val SUBTITLE_COLOR = intPreferencesKey("subtitle_color")
        val SUBTITLE_OFFSET_MS = longPreferencesKey("subtitle_offset_ms")
        val YOUTUBE_PREFER_720P = booleanPreferencesKey("youtube_prefer_720p")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        UserSettings(
            selectedProfileId = prefs[Keys.SELECTED_PROFILE_ID] ?: 1L,
            autoAdaptOnCableConnect = prefs[Keys.AUTO_ADAPT_CABLE] ?: true,
            autoLaunchTvPresentation = prefs[Keys.AUTO_LAUNCH_PRESENTATION] ?: true,
            subtitleFontSizeSp = prefs[Keys.SUBTITLE_FONT_SIZE] ?: 20f,
            subtitleColorOrdinal = prefs[Keys.SUBTITLE_COLOR] ?: 0,
            subtitleSyncOffsetMs = prefs[Keys.SUBTITLE_OFFSET_MS] ?: 0L,
            youtubePrefer720p = prefs[Keys.YOUTUBE_PREFER_720P] ?: true
        )
    }

    suspend fun setSelectedProfileId(id: Long) {
        context.dataStore.edit { it[Keys.SELECTED_PROFILE_ID] = id }
    }

    suspend fun setAutoAdaptOnCableConnect(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_ADAPT_CABLE] = enabled }
    }

    suspend fun setAutoLaunchTvPresentation(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_LAUNCH_PRESENTATION] = enabled }
    }

    suspend fun setSubtitleFontSize(sizeSp: Float) {
        context.dataStore.edit { it[Keys.SUBTITLE_FONT_SIZE] = sizeSp.coerceIn(14f, 34f) }
    }

    suspend fun setSubtitleColorOrdinal(ordinal: Int) {
        context.dataStore.edit { it[Keys.SUBTITLE_COLOR] = ordinal }
    }

    suspend fun setSubtitleOffsetMs(offsetMs: Long) {
        context.dataStore.edit { it[Keys.SUBTITLE_OFFSET_MS] = offsetMs }
    }

    suspend fun setYoutubePrefer720p(enabled: Boolean) {
        context.dataStore.edit { it[Keys.YOUTUBE_PREFER_720P] = enabled }
    }
}
