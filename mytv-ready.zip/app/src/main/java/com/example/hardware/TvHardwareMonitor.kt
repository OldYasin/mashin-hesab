package com.example.hardware

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.view.Display
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class CableConnectionType(val labelFa: String) {
    HDMI_DISPLAY("کابل HDMI / USB-C تصویر متصل است"),
    USB_OTG_STORAGE("حافظه USB / کابل OTG متصل است"),
    USB_CABLE_LINKED("کابل USB به دستگاه/تی‌وی متصل است"),
    DISCONNECTED("کابل تصویر یا USB متصل نیست")
}

data class ExternalDisplayInfo(
    val displayId: Int,
    val name: String,
    val width: Int,
    val height: Int,
    val refreshRate: Float,
    val isHdrSupported: Boolean
)

data class AttachedUsbDeviceInfo(
    val deviceName: String,
    val displayTitle: String,
    val manufacturer: String,
    val vendorId: Int,
    val productId: Int,
    val isMassStorage: Boolean
)

data class HardwareConnectionState(
    val connectionType: CableConnectionType = CableConnectionType.DISCONNECTED,
    val externalDisplays: List<ExternalDisplayInfo> = emptyList(),
    val usbDevices: List<AttachedUsbDeviceInfo> = emptyList(),
    val isUsbPowerConnected: Boolean = false,
    val isOnline: Boolean = false,
    val detectedBrandHint: String? = null
) {
    val primaryDisplay: ExternalDisplayInfo? get() = externalDisplays.firstOrNull()
}

class TvHardwareMonitor(private val context: Context) {

    private val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val _state = MutableStateFlow(HardwareConnectionState())
    val state: StateFlow<HardwareConnectionState> = _state.asStateFlow()

    private var isStarted = false

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = refreshAll()
        override fun onDisplayRemoved(displayId: Int) = refreshAll()
        override fun onDisplayChanged(displayId: Int) = refreshAll()
    }

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            refreshAll()
        }
    }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = refreshNetwork()
        override fun onLost(network: Network) = refreshNetwork()
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = refreshNetwork()
    }

    fun start() {
        if (isStarted) return
        isStarted = true
        displayManager.registerDisplayListener(displayListener, null)

        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction("android.hardware.usb.action.USB_STATE")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            context.registerReceiver(usbReceiver, filter)
        }

        runCatching {
            connectivityManager.registerDefaultNetworkCallback(networkCallback)
        }
        refreshAll()
    }

    fun stop() {
        if (!isStarted) return
        isStarted = false
        runCatching { displayManager.unregisterDisplayListener(displayListener) }
        runCatching { context.unregisterReceiver(usbReceiver) }
        runCatching { connectivityManager.unregisterNetworkCallback(networkCallback) }
    }

    fun getPrimaryPresentationDisplay(): Display? {
        return displayManager.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION).firstOrNull()
    }

    fun refreshAll() {
        val displays = readExternalDisplays()
        val usbList = readUsbDevices()
        val usbPower = isPluggedViaUsb()
        val online = checkIsOnline()

        val connType = when {
            displays.isNotEmpty() -> CableConnectionType.HDMI_DISPLAY
            usbList.any { it.isMassStorage } -> CableConnectionType.USB_OTG_STORAGE
            usbList.isNotEmpty() || usbPower -> CableConnectionType.USB_CABLE_LINKED
            else -> CableConnectionType.DISCONNECTED
        }

        val brandHint = detectBrandHint(displays, usbList)

        _state.update {
            it.copy(
                connectionType = connType,
                externalDisplays = displays,
                usbDevices = usbList,
                isUsbPowerConnected = usbPower,
                isOnline = online,
                detectedBrandHint = brandHint
            )
        }
    }

    private fun refreshNetwork() {
        val online = checkIsOnline()
        _state.update { it.copy(isOnline = online) }
    }

    private fun readExternalDisplays(): List<ExternalDisplayInfo> {
        val presentationDisplays =
            displayManager.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION)
        return presentationDisplays.map { display ->
            val mode = display.mode
            val hdrSupported = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                display.hdrCapabilities?.supportedHdrTypes?.isNotEmpty() == true
            } else {
                false
            }
            ExternalDisplayInfo(
                displayId = display.displayId,
                name = display.name ?: "تلویزیون / نمایشگر خارجی",
                width = mode.physicalWidth,
                height = mode.physicalHeight,
                refreshRate = mode.refreshRate,
                isHdrSupported = hdrSupported
            )
        }
    }

    private fun readUsbDevices(): List<AttachedUsbDeviceInfo> {
        return runCatching {
            usbManager.deviceList.values.map { device ->
                val isStorage = hasMassStorageInterface(device)
                val title = listOfNotNull(
                    device.manufacturerName?.takeIf { it.isNotBlank() },
                    device.productName?.takeIf { it.isNotBlank() }
                ).joinToString(" ").ifBlank {
                    if (isStorage) "فلش‌مموری USB OTG" else "دستگاه USB (${device.vendorId})"
                }
                AttachedUsbDeviceInfo(
                    deviceName = device.deviceName,
                    displayTitle = title,
                    manufacturer = device.manufacturerName ?: "نامشخص",
                    vendorId = device.vendorId,
                    productId = device.productId,
                    isMassStorage = isStorage
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun hasMassStorageInterface(device: UsbDevice): Boolean {
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            if (intf.interfaceClass == UsbConstants.USB_CLASS_MASS_STORAGE) return true
        }
        return device.deviceClass == UsbConstants.USB_CLASS_MASS_STORAGE
    }

    private fun isPluggedViaUsb(): Boolean {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
        return plugged == BatteryManager.BATTERY_PLUGGED_USB
    }

    private fun checkIsOnline(): Boolean {
        val network = connectivityManager.activeNetwork ?: return false
        val caps = connectivityManager.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun detectBrandHint(
        displays: List<ExternalDisplayInfo>,
        usbDevices: List<AttachedUsbDeviceInfo>
    ): String? {
        val combinedText = (displays.map { it.name } + usbDevices.map { "${it.manufacturer} ${it.displayTitle}" })
            .joinToString(" ")
            .lowercase()
        return when {
            "lg" in combinedText || "goldstar" in combinedText -> "LG"
            "samsung" in combinedText -> "Samsung"
            "sony" in combinedText || "bravia" in combinedText -> "Sony"
            "tcl" in combinedText -> "TCL"
            "hisense" in combinedText -> "Hisense"
            else -> null
        }
    }
}
