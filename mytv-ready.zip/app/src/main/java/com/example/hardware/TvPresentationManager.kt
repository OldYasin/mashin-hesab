package com.example.hardware

import android.annotation.SuppressLint
import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.util.TypedValue
import android.view.Display
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView

class TvCinemaPresentation(
    outerContext: Context,
    display: Display,
    private val exoPlayer: ExoPlayer? = null,
    private val youtubeVideoId: String? = null,
    private val prefer720p: Boolean = true,
    private val subtitleFontSizeSp: Float = 22f,
    private val subtitleTextColor: Int = Color.YELLOW
) : Presentation(outerContext, display) {

    private var webView: WebView? = null
    private var playerView: PlayerView? = null

    @SuppressLint("SetJavaScriptEnabled")
    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(context).apply {
            setBackgroundColor(Color.BLACK)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        if (exoPlayer != null) {
            val pv = PlayerView(context).apply {
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                setKeepContentOnPlayerReset(true)
                subtitleView?.apply {
                    setApplyEmbeddedStyles(false)
                    setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, subtitleFontSizeSp)
                    setStyle(
                        CaptionStyleCompat(
                            subtitleTextColor,
                            Color.argb(180, 0, 0, 0),
                            Color.TRANSPARENT,
                            CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                            Color.BLACK,
                            null
                        )
                    )
                }
                player = exoPlayer
            }
            playerView = pv
            root.addView(
                pv,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        } else if (!youtubeVideoId.isNullOrBlank()) {
            val wv = WebView(context).apply {
                setBackgroundColor(Color.BLACK)
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                }
                webChromeClient = WebChromeClient()
                webViewClient = WebViewClient()
                val qualityParam = if (prefer720p) "&vq=hd720" else ""
                val embedHtml = """
                    <!DOCTYPE html>
                    <html>
                    <body style="margin:0;padding:0;background:#000;overflow:hidden;">
                      <iframe width="100%" height="100%"
                        style="position:fixed;top:0;left:0;width:100vw;height:100vh;border:0;"
                        src="https://www.youtube.com/embed/$youtubeVideoId?autoplay=1&playsinline=1&rel=0$qualityParam"
                        allow="autoplay; encrypted-media; fullscreen" allowfullscreen>
                      </iframe>
                    </body>
                    </html>
                """.trimIndent()
                loadDataWithBaseURL("https://www.youtube.com", embedHtml, "text/html", "utf-8", null)
            }
            webView = wv
            root.addView(
                wv,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }

        setContentView(root)
    }

    override fun onStop() {
        playerView?.player = null
        webView?.destroy()
        webView = null
        super.onStop()
    }
}
