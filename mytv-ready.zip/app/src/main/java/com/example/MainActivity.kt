package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.outlined.Cable
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.OndemandVideo
import androidx.compose.material.icons.outlined.Subtitles
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.ui.navigation.ConnectRoute
import com.example.ui.navigation.FoldersRoute
import com.example.ui.navigation.SubtitlesRoute
import com.example.ui.navigation.VideoPlayerRoute
import com.example.ui.navigation.YouTubePlayerRoute
import com.example.ui.navigation.YouTubeRoute
import com.example.ui.screens.ConnectScreen
import com.example.ui.screens.FoldersScreen
import com.example.ui.screens.SubtitlesScreen
import com.example.ui.screens.VideoPlayerScreen
import com.example.ui.screens.YouTubePlayerScreen
import com.example.ui.screens.YouTubeScreen
import com.example.ui.theme.CinemaGold
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.MyTvTheme
import com.example.ui.theme.SlateSurface
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyTvTheme {
                MyTvAppShell()
            }
        }
    }
}

private data class TopNavItem<T : Any>(
    val route: T,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@Composable
private fun MyTvAppShell(viewModel: MainViewModel = viewModel()) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = backStackEntry?.destination

    val hardwareState by viewModel.hardwareState.collectAsStateWithLifecycle()
    val userSettings by viewModel.userSettings.collectAsStateWithLifecycle()
    val profiles by viewModel.tvProfiles.collectAsStateWithLifecycle()
    val activeProfile by viewModel.activeProfile.collectAsStateWithLifecycle()
    val savedFolders by viewModel.savedFolders.collectAsStateWithLifecycle()
    val scannedVideos by viewModel.scannedVideos.collectAsStateWithLifecycle()
    val isScanningFolders by viewModel.isScanningFolders.collectAsStateWithLifecycle()
    val transcodeJob by viewModel.transcodeJob.collectAsStateWithLifecycle()
    val subtitleState by viewModel.subtitleState.collectAsStateWithLifecycle()
    val youtubeState by viewModel.youtubeState.collectAsStateWithLifecycle()
    val youtubeBookmarks by viewModel.youtubeBookmarks.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(toastMessage) {
        val msg = toastMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    val isFullScreenPlayer = currentDest?.hasRoute<VideoPlayerRoute>() == true ||
        currentDest?.hasRoute<YouTubePlayerRoute>() == true

    val navItems = remember {
        listOf(
            TopNavItem(ConnectRoute, R.string.nav_connect, Icons.Filled.Cable, Icons.Outlined.Cable, "nav_connect"),
            TopNavItem(FoldersRoute, R.string.nav_folders, Icons.Filled.Folder, Icons.Outlined.Folder, "nav_folders"),
            TopNavItem(SubtitlesRoute, R.string.nav_subtitles, Icons.Filled.Subtitles, Icons.Outlined.Subtitles, "nav_subtitles"),
            TopNavItem(YouTubeRoute, R.string.nav_youtube, Icons.Filled.OndemandVideo, Icons.Outlined.OndemandVideo, "nav_youtube")
        )
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MidnightBg,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            contentWindowInsets = if (isFullScreenPlayer) WindowInsets(0, 0, 0, 0) else WindowInsets.navigationBars,
            bottomBar = {
                if (!isFullScreenPlayer && !useNavigationRail) {
                    NavigationBar(
                        containerColor = SlateSurface,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        navItems.forEach { item ->
                            val selected = currentDest?.hasRoute(item.route::class) == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(item.route) {
                                        popUpTo<ConnectRoute> { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(item.labelRes)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(item.labelRes),
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CinemaGold,
                                    selectedTextColor = CinemaGold,
                                    indicatorColor = CinemaGold.copy(alpha = 0.16f)
                                ),
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (!isFullScreenPlayer && useNavigationRail) {
                    NavigationRail(
                        containerColor = SlateSurface
                    ) {
                        navItems.forEach { item ->
                            val selected = currentDest?.hasRoute(item.route::class) == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(item.route) {
                                        popUpTo<ConnectRoute> { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(item.labelRes)
                                    )
                                },
                                label = { Text(stringResource(item.labelRes)) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = CinemaGold,
                                    selectedTextColor = CinemaGold,
                                    indicatorColor = CinemaGold.copy(alpha = 0.16f)
                                ),
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = ConnectRoute,
                    modifier = Modifier.weight(1f)
                ) {
                    composable<ConnectRoute> {
                        ConnectScreen(
                            hardwareState = hardwareState,
                            profiles = profiles,
                            activeProfile = activeProfile,
                            userSettings = userSettings,
                            onRefreshHardware = viewModel::refreshHardware,
                            onSelectProfile = viewModel::selectTvProfile,
                            onCreateCustomProfile = viewModel::createCustomTvProfile,
                            onDeleteCustomProfile = viewModel::deleteCustomTvProfile,
                            onToggleAutoAdapt = viewModel::setAutoAdaptOnCable,
                            onToggleAutoPresentation = viewModel::setAutoLaunchTvPresentation,
                            onGoToFolders = {
                                navController.navigate(FoldersRoute) {
                                    popUpTo<ConnectRoute> { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }

                    composable<FoldersRoute> {
                        FoldersScreen(
                            activeProfile = activeProfile,
                            savedFolders = savedFolders,
                            scannedVideos = scannedVideos,
                            isScanning = isScanningFolders,
                            transcodeJob = transcodeJob,
                            onAddFolder = viewModel::addFolderFromSaf,
                            onSetExportFolder = viewModel::setExportFolder,
                            onRemoveFolder = viewModel::removeFolder,
                            onRefreshFolders = viewModel::refreshFoldersNow,
                            onPlayVideo = { video ->
                                navController.navigate(
                                    VideoPlayerRoute(
                                        videoUri = video.uriString,
                                        subtitleUri = video.pairedSubtitleUriString,
                                        title = video.fileName
                                    )
                                )
                            },
                            onConvertVideoForTv = viewModel::startTranscodeForTv,
                            onOpenSubtitlesForVideo = { video ->
                                viewModel.selectVideoForSubtitleStudio(video)
                                navController.navigate(SubtitlesRoute) {
                                    popUpTo<ConnectRoute> { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            onCancelTranscode = viewModel::cancelTranscode,
                            onDismissTranscodeBanner = viewModel::clearTranscodeBanner
                        )
                    }

                    composable<SubtitlesRoute> {
                        SubtitlesScreen(
                            videos = scannedVideos,
                            subtitleState = subtitleState,
                            userSettings = userSettings,
                            onSelectVideo = viewModel::selectVideoForSubtitleStudio,
                            onPickSubtitleFile = viewModel::loadSubtitleFile,
                            onExportSubtitle = viewModel::exportPairedSubtitleForTv,
                            onSetFontSize = viewModel::setSubtitleFontSize,
                            onSetColorOrdinal = viewModel::setSubtitleColor,
                            onSetOffsetMs = viewModel::setSubtitleOffsetMs
                        )
                    }

                    composable<YouTubeRoute> {
                        YouTubeScreen(
                            isOnline = hardwareState.isOnline,
                            userSettings = userSettings,
                            youtubeState = youtubeState,
                            bookmarks = youtubeBookmarks,
                            onToggle720p = viewModel::setYoutubePrefer720p,
                            onResolveAndPlay = { raw ->
                                viewModel.resolveAndBookmarkYouTube(raw) { resolved ->
                                    navController.navigate(
                                        YouTubePlayerRoute(
                                            videoId = resolved.videoId,
                                            title = resolved.title
                                        )
                                    )
                                }
                            },
                            onPlayBookmark = { item ->
                                navController.navigate(
                                    YouTubePlayerRoute(
                                        videoId = item.videoId,
                                        title = item.title
                                    )
                                )
                            },
                            onDeleteBookmark = viewModel::deleteYouTubeBookmark,
                            onBrowserUrlChanged = viewModel::onBrowserUrlChanged
                        )
                    }

                    composable<VideoPlayerRoute> { entry ->
                        val args = entry.toRoute<VideoPlayerRoute>()
                        VideoPlayerScreen(
                            videoUriString = args.videoUri,
                            subtitleUriString = args.subtitleUri,
                            title = args.title,
                            userSettings = userSettings,
                            hardwareState = hardwareState,
                            hardwareMonitor = viewModel.hardwareMonitor,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable<YouTubePlayerRoute> { entry ->
                        val args = entry.toRoute<YouTubePlayerRoute>()
                        YouTubePlayerScreen(
                            videoId = args.videoId,
                            title = args.title,
                            userSettings = userSettings,
                            hardwareState = hardwareState,
                            hardwareMonitor = viewModel.hardwareMonitor,
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
