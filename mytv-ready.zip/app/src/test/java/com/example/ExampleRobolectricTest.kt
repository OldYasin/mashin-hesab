package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.TvProfilePresets
import com.example.media.FolderScanner
import com.example.media.SubtitleCue
import com.example.media.SubtitleEngine
import com.example.media.YouTubeMetadataClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches MyTV Persian branding`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("مای تیوی", appName)
    }

    @Test
    fun `LG 2014 profile flags 1080p MKV HEVC as incompatible and 720p MP4 H264 as compatible`() {
        val lg2014 = TvProfilePresets.builtInProfiles.first { it.id == 1L }

        val (ok720, notes720) = FolderScanner.evaluateCompatibility(
            containerExt = "MP4",
            width = 1280,
            height = 720,
            codecLabel = "H.264 (AVC)",
            profile = lg2014
        )
        assertTrue(ok720)
        assertTrue(notes720.isEmpty())

        val (ok1080, notes1080) = FolderScanner.evaluateCompatibility(
            containerExt = "MKV",
            width = 1920,
            height = 1080,
            codecLabel = "HEVC (H.265)",
            profile = lg2014
        )
        assertFalse(ok1080)
        assertEquals(3, notes1080.size)
    }

    @Test
    fun `youtube video id extraction supports standard shorts and share urls`() {
        assertEquals("dQw4w9WgXcQ", YouTubeMetadataClient.extractVideoId("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
        assertEquals("dQw4w9WgXcQ", YouTubeMetadataClient.extractVideoId("https://youtu.be/dQw4w9WgXcQ?si=abc"))
        assertEquals("dQw4w9WgXcQ", YouTubeMetadataClient.extractVideoId("https://youtube.com/shorts/dQw4w9WgXcQ"))
    }

    @Test
    fun `subtitle timing offset shifts cues accurately`() {
        val cues = listOf(SubtitleCue(1, 1_000L, 3_500L, "سلام دنیا"))
        val shifted = SubtitleEngine.applyOffsetAndBuildSrt(cues, 500L)
        assertTrue(shifted.contains("00:00:01,500 --> 00:00:04,000"))
        assertTrue(shifted.contains("سلام دنیا"))
    }
}
