package com.example.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import com.example.data.model.IpProvider
import com.example.data.model.NetworkSyncStatus
import com.example.data.preferences.SettingsRepository
import com.example.data.repository.TunnelRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class NetworkSyncManager(
    context: Context,
    private val repository: TunnelRepository,
    private val settingsRepository: SettingsRepository,
    private val engine: ParallelTunnelEngine
) {
    private val appContext = context.applicationContext
    private val connectivityManager =
        appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val syncMutex = Mutex()

    private val _syncStatus = MutableStateFlow(
        NetworkSyncStatus(isOnline = checkCurrentlyOnline())
    )
    val syncStatus: StateFlow<NetworkSyncStatus> = _syncStatus.asStateFlow()

    private var wasOffline = !_syncStatus.value.isOnline

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            handleConnectivityChange(isNowOnline = true)
        }

        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
            val hasInternet = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            handleConnectivityChange(isNowOnline = hasInternet)
        }

        override fun onLost(network: Network) {
            handleConnectivityChange(isNowOnline = checkCurrentlyOnline())
        }
    }

    fun startObserving() {
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        runCatching {
            connectivityManager.registerNetworkCallback(request, networkCallback)
        }
        scope.launch {
            repository.pendingSyncCountFlow.collect { count ->
                _syncStatus.update { it.copy(pendingTaskCount = count) }
            }
        }
        scope.launch {
            val last = settingsRepository.lastSyncTimeFlow.first()
            _syncStatus.update { it.copy(lastSyncTimeMs = last) }
        }
    }

    fun stopObserving() {
        runCatching { connectivityManager.unregisterNetworkCallback(networkCallback) }
    }

    private fun handleConnectivityChange(isNowOnline: Boolean) {
        _syncStatus.update { it.copy(isOnline = isNowOnline) }
        if (isNowOnline && wasOffline) {
            // Automatic synchronization upon network reconnection
            triggerSync(reason = "همگام‌سازی خودکار پس از اتصال مجدد")
        }
        wasOffline = !isNowOnline
    }

    fun triggerSync(reason: String = "همگام‌سازی دستی") {
        scope.launch {
            syncNow(reason)
        }
    }

    suspend fun syncNow(reason: String = "همگام‌سازی خودکار") {
        if (!checkCurrentlyOnline()) {
            _syncStatus.update {
                it.copy(
                    isOnline = false,
                    isSyncing = false,
                    lastSyncSummary = "آفلاین • تغییرات در دیتابیس محلی ذخیره شد"
                )
            }
            return
        }

        syncMutex.withLock {
            val tasks = repository.getPendingSyncTasksOnce()
            if (tasks.isEmpty()) {
                val now = System.currentTimeMillis()
                settingsRepository.updateLastSyncTime(now)
                _syncStatus.update {
                    it.copy(
                        isOnline = true,
                        isSyncing = false,
                        pendingTaskCount = 0,
                        lastSyncTimeMs = now,
                        lastSyncSummary = "همه داده‌ها به‌روز هستند"
                    )
                }
                return
            }

            _syncStatus.update {
                it.copy(isSyncing = true, lastSyncSummary = "$reason (${tasks.size} مورد)...")
            }

            val settings = settingsRepository.settingsFlow.first()
            val allServers = repository.getAllServersOnce().associateBy { it.id }
            var completedCount = 0

            for (task in tasks) {
                val success = when (task.taskType) {
                    "VERIFY_ENDPOINT" -> {
                        val endpointId = task.targetId.toLongOrNull()
                        val endpoint = endpointId?.let { allServers[it] }
                        if (endpoint == null) {
                            true
                        } else {
                            val ping = engine.pingEndpoint(endpoint, settings)
                            repository.updateServerHealth(endpoint.id, ping.latencyMs, ping.isHealthy)
                            true
                        }
                    }
                    "SYNC_REPORT" -> {
                        val reportId = task.targetId.toLongOrNull()
                        if (reportId != null) {
                            repository.markReportSynced(reportId)
                        }
                        true
                    }
                    "REPROBE_CLEAN_IP" -> {
                        val found = CleanIpScanner.scanCleanIps(IpProvider.GOOGLE, sampleCount = 12, expand = false) {}
                        if (found.isNotEmpty()) {
                            repository.saveCleanIps(IpProvider.GOOGLE, found)
                        }
                        true
                    }
                    else -> true
                }

                if (success) {
                    repository.completeSyncTask(task.id)
                    completedCount++
                } else {
                    repository.incrementSyncRetry(task)
                }
            }

            val now = System.currentTimeMillis()
            settingsRepository.updateLastSyncTime(now)
            val remaining = repository.getPendingSyncTasksOnce().size
            _syncStatus.update {
                it.copy(
                    isOnline = true,
                    isSyncing = false,
                    pendingTaskCount = remaining,
                    lastSyncTimeMs = now,
                    lastSyncSummary = "$completedCount مورد با موفقیت همگام‌سازی شد"
                )
            }
        }
    }

    private fun checkCurrentlyOnline(): Boolean {
        val active = connectivityManager.activeNetwork ?: return false
        val caps = connectivityManager.getNetworkCapabilities(active) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
