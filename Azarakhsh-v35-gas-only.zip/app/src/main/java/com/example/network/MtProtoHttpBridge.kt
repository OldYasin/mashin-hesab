package com.example.network

import com.example.core.logging.LogCategory
import com.example.core.logging.TunnelLogger
import com.example.core.logging.TunnelStats
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.CRC32
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Dual-method HTTP-to-MTProto bridge for relaying native Telegram SOCKS5 traffic
 * through Google Apps Script (UrlFetchApp) when no Cloudflare Worker WebSocket is active.
 *
 * Method 1 (Primary): MTProto-over-HTTPS via `https://<dc>.web.telegram.org/apiw1` (raw MTProto payload)
 * Method 2 (Fallback): MTProto-over-HTTP Full via `http://<dc_ip>/api` (length + seqno + payload + CRC32)
 */
object MtProtoHttpBridge {

    enum class TransportMode {
        ABRIDGED,       // 0xefefefef
        INTERMEDIATE,   // 0xeeeeeeee
        PADDED          // 0xdddddddd
    }

    enum class RelayMethod(val label: String) {
        APIW1_HTTPS("apiw1"),
        API_HTTP_FULL("api-http")
    }

    private data class DcEndpoint(
        val webHost: String,
        val ip: String,
        val mainHost: String? = null // fallback host when webHost is a media (-1) host
    )

    // Delayed hedging: if a relay hasn't answered after hedgeDelayMs() (adaptive), the same packet is sent once more via a
    // different GAS node. BOTH replies are forwarded to Telegram (the client drops duplicate msg_ids), so a reply
    // is never lost; the earliest one wins. Costs extra GAS quota only for requests slower than the delay.
    private const val HEDGE_ENABLED = true
    // Adaptive: ~1.3 x p90 of the measured relay RTT, clamped. A fixed 1.5s sat below the ~1.7s GAS floor, so almost
    // every small packet got a twin and burned double UrlFetch quota.
    private const val HEDGE_DELAY_MIN_MS = 2500L
    private const val HEDGE_DELAY_MAX_MS = 6000L
    private const val HEDGE_DELAY_DEFAULT_MS = 3000L
    private const val HEDGE_MIN_SAMPLES = 20
    @Volatile private var hedgeDelayCachedMs = HEDGE_DELAY_DEFAULT_MS
    @Volatile private var hedgeDelayCachedAt = 0L
    private const val HEDGE_MAX_PAYLOAD = 1400       // only small packets (messages, acks); big uploads are not duplicated
    private const val HEDGE_MAX_INFLIGHT = 8         // cap of simultaneous twins -> bounds extra GAS quota / slot usage
    private val hedgeInFlight = AtomicInteger(0)

    private val DC_MAP = mapOf(
        1 to DcEndpoint("pluto.web.telegram.org", "149.154.175.53"),
        2 to DcEndpoint("venus.web.telegram.org", "149.154.167.51"),
        3 to DcEndpoint("aurora.web.telegram.org", "149.154.175.100"),
        4 to DcEndpoint("vesta.web.telegram.org", "149.154.167.91"),
        5 to DcEndpoint("flora.web.telegram.org", "91.108.56.130")
    )

    // Remember which method works best per DC/host (main vs media) to avoid wasted fallback round-trips
    private val preferredMethodByHost = ConcurrentHashMap<String, RelayMethod>()
    // Cap total concurrent GAS relays (long-polls hold a GAS slot ~27s; Apps Script allows ~30 simultaneous executions
    // per account). The cap scales with the number of active GAS nodes instead of a fixed 24 for everything.
    private const val GLOBAL_SLOTS_PER_NODE = 24
    private const val GLOBAL_SLOTS_MAX = 168
    private val globalInFlight = AtomicInteger(0)
    @Volatile private var activeNodeCountCached = 1
    @Volatile private var activeNodeCountAt = 0L
    // consecutive transient failures in one session before the session is torn down
    private const val SESSION_MAX_TRANSIENT_FAILS = 3
    // Edge IPs that repeatedly return HTTP 404 on first packet (e.g. 149.154.165.136) -> fast-reject for 120s
    private val deadEdge404Count = ConcurrentHashMap<String, AtomicInteger>()
    private val deadEdgeCooldownUntil = ConcurrentHashMap<String, Long>()
    // DCs where http://<dc_ip>/api returned 404 -> skip redundant fallback for 5m to save GAS RTT & quota
    private val apiHttpCooldownUntil = ConcurrentHashMap<Int, Long>()

    /** Pure helper (unit-tested): hedge delay from the p90 relay RTT and the number of samples behind it. */
    internal fun computeHedgeDelayMs(p90Ms: Long, samples: Int): Long {
        if (samples < HEDGE_MIN_SAMPLES || p90Ms <= 0L) return HEDGE_DELAY_DEFAULT_MS
        return (p90Ms * 13L / 10L).coerceIn(HEDGE_DELAY_MIN_MS, HEDGE_DELAY_MAX_MS)
    }

    private fun hedgeDelayMs(): Long {
        val now = System.currentTimeMillis()
        if (now - hedgeDelayCachedAt > 5_000L) {
            hedgeDelayCachedMs = computeHedgeDelayMs(
                TunnelStats.percentile("t.tgRelay", 0.9),
                TunnelStats.sampleCount("t.tgRelay")
            )
            hedgeDelayCachedAt = now
        }
        return hedgeDelayCachedMs
    }

    private fun activeNodeCount(engine: ParallelTunnelEngine): Int {
        val now = System.currentTimeMillis()
        if (now - activeNodeCountAt > 2_000L) {
            activeNodeCountCached = engine.selectOrderedCandidates(com.example.data.model.EndpointType.GAS_SCRIPT).size.coerceAtLeast(1)
            activeNodeCountAt = now
        }
        return activeNodeCountCached
    }

    private suspend fun acquireGlobalSlot(engine: ParallelTunnelEngine) {
        while (true) {
            val limit = (GLOBAL_SLOTS_PER_NODE * activeNodeCount(engine)).coerceAtMost(GLOBAL_SLOTS_MAX)
            val cur = globalInFlight.get()
            if (cur < limit && globalInFlight.compareAndSet(cur, cur + 1)) return
            kotlinx.coroutines.delay(10L)
        }
    }

    private fun tryAcquireGlobalSlot(engine: ParallelTunnelEngine): Boolean {
        val limit = (GLOBAL_SLOTS_PER_NODE * activeNodeCount(engine)).coerceAtMost(GLOBAL_SLOTS_MAX)
        val cur = globalInFlight.get()
        return cur < limit && globalInFlight.compareAndSet(cur, cur + 1)
    }

    private fun releaseGlobalSlot() {
        globalInFlight.updateAndGet { if (it > 0) it - 1 else 0 }
    }

    fun isTelegramTarget(host: String, port: Int): Boolean {
        val h = host.trim().lowercase()
        if (h.endsWith(".telegram.org") || h == "telegram.org" || h.endsWith(".t.me")) return true
        // Common Telegram DC IPv4 prefixes: 149.154.160.0/20, 91.108.4.0/22..56.0/22, 95.161.64.0/20
        if (h.startsWith("149.154.") || h.startsWith("91.108.") || h.startsWith("95.161.")) return true
        // Telegram IPv6 DC prefixes
        if (h.startsWith("2001:b28:f23") || h.startsWith("2001:67c:4e8:")) return true
        // Common Telegram ports with binary traffic
        return port == 443 || port == 80 || port == 5222
    }

    fun inferDcFromHost(host: String): Int {
        val h = host.trim().lowercase()
        return when {
            h.startsWith("pluto") || h.startsWith("149.154.175.5") || h.contains("f001:") -> 1
            h.startsWith("venus") || h.startsWith("149.154.167.5") || h.startsWith("149.154.167.4") || h.contains("f002:") -> 2
            h.startsWith("aurora") || h.startsWith("149.154.175.10") || h.contains("f003:") -> 3
            h.startsWith("vesta") || h.startsWith("149.154.167.9") || h.startsWith("149.154.167.15") || h.contains("f004:") -> 4
            h.startsWith("flora") || h.startsWith("91.108.56.") || h.contains("f005:") -> 5
            else -> 2 // DC2 is the most common default
        }
    }

    /**
     * Handles an already-read 64-byte (or initial) Obfuscated2 stream from Telegram over SOCKS5.
     * Returns true if the stream was valid Obfuscated2 MTProto and handled, false if not Obfuscated2.
     */
    suspend fun bridgeObfuscatedStream(
        engine: ParallelTunnelEngine,
        targetHost: String,
        targetPort: Int,
        initialBytes: ByteArray,
        clientIn: InputStream,
        clientOut: OutputStream
    ): Boolean = withContext(Dispatchers.IO) {
        if (initialBytes.size < 64) {
            return@withContext false
        }

        val initPacket = initialBytes.copyOfRange(0, 64)
        val leftover = if (initialBytes.size > 64) {
            initialBytes.copyOfRange(64, initialBytes.size)
        } else {
            ByteArray(0)
        }

        // Client -> Server AES-256-CTR (key: init[8..39], iv: init[40..55])
        val rxKey = initPacket.copyOfRange(8, 40)
        val rxIv = initPacket.copyOfRange(40, 56)
        val rxCipher = Cipher.getInstance("AES/CTR/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, SecretKeySpec(rxKey, "AES"), IvParameterSpec(rxIv))
        }

        // Server -> Client AES-256-CTR (reversed bytes 8..55: key=rev[0..31], iv=rev[32..47])
        val rev = initPacket.copyOfRange(8, 56).reversedArray()
        val txKey = rev.copyOfRange(0, 32)
        val txIv = rev.copyOfRange(32, 48)
        val txCipher = Cipher.getInstance("AES/CTR/NoPadding").apply {
            init(Cipher.ENCRYPT_MODE, SecretKeySpec(txKey, "AES"), IvParameterSpec(txIv))
        }

        // Decrypt the 64-byte init header (advances rxCipher by 64 bytes)
        val decInit = rxCipher.update(initPacket) ?: return@withContext false
        if (decInit.size < 64) return@withContext false

        val mode = when {
            decInit[56] == 0xef.toByte() && decInit[57] == 0xef.toByte() &&
                decInit[58] == 0xef.toByte() && decInit[59] == 0xef.toByte() -> TransportMode.ABRIDGED
            decInit[56] == 0xee.toByte() && decInit[57] == 0xee.toByte() &&
                decInit[58] == 0xee.toByte() && decInit[59] == 0xee.toByte() -> TransportMode.INTERMEDIATE
            decInit[56] == 0xdd.toByte() && decInit[57] == 0xdd.toByte() &&
                decInit[58] == 0xdd.toByte() && decInit[59] == 0xdd.toByte() -> TransportMode.PADDED
            else -> return@withContext false
        }

        val rawDc = ByteBuffer.wrap(decInit, 60, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
        val absDc = kotlin.math.abs(rawDc).let { if (it > 10_000) it - 10_000 else it }
        val dcId = if (absDc in 1..5) absDc else inferDcFromHost(targetHost)
        // Negative dc in the obfuscated2 header = media/upload connection (IPs like ...::b, 167.92, 167.222).
        // Web endpoint for those is "<name>-1.web.telegram.org", the plain host returns nginx 404.
        val isMedia = rawDc < 0 || targetHost.endsWith("::b") || targetHost.contains("::b:")
        val baseEndpoint = DC_MAP[dcId] ?: DC_MAP.getValue(2)
        val dcEndpoint = if (isMedia) baseEndpoint.copy(
            webHost = baseEndpoint.webHost.replaceFirst(".web.", "-1.web."),
            mainHost = baseEndpoint.webHost
        ) else baseEndpoint

        val nowMs = System.currentTimeMillis()
        if ((deadEdgeCooldownUntil[targetHost] ?: 0L) > nowMs) {
            TunnelStats.inc("tg.bridge.404.skip")
            return@withContext false
        }
        TunnelStats.inc("tg.bridge.sessions")
        TunnelLogger.i(
            LogCategory.GAS,
            "TG-BRIDGE",
            "شروع پل MTProto-HTTP برای DC$dcId (${mode.name})",
            "$targetHost:$targetPort -> ${dcEndpoint.webHost}"
        )

        val stream = BufferedDecryptedStream(clientIn, rxCipher, leftover)
        val seqNoCounter = AtomicInteger(0)
        val writeLock = Any()
        val concurrencyLimit = Semaphore(permits = 8)
        val failed = AtomicBoolean(false)
        val sessionTransientFails = AtomicInteger(0)

        try {
            coroutineScope {
                while (!failed.get()) {
                    val rawPayload = readPacket(stream, mode) ?: break
                    if (rawPayload.isEmpty()) continue

                    val payload = if (mode == TransportMode.PADDED) {
                        stripPaddedIntermediatePadding(rawPayload)
                    } else {
                        rawPayload
                    }
                    if (payload.isEmpty()) continue

                    engine.recordTraffic(upBytes = payload.size.toLong(), downBytes = 0L)
                    TunnelStats.inc("tg.bridge.tx")

                    val packetSeqNo = seqNoCounter.getAndIncrement()
                    val tWait0 = System.nanoTime()
                    concurrencyLimit.acquire()
                    acquireGlobalSlot(engine)
                    val waitMs = ((System.nanoTime() - tWait0) / 1_000_000L).coerceAtLeast(0L)
                    TunnelStats.sample("t.tgQueueWait", waitMs)
                    launch {
                        val tRelay0 = System.nanoTime()
                        val hedgeStarted = AtomicBoolean(false)
                        val hedgeDelivered = AtomicBoolean(false)
                        fun deliver(replies: List<ByteArray>) {
                            for (reply in replies) {
                                if (reply.isEmpty()) continue
                                val framed = framePacket(reply, mode)
                                synchronized(writeLock) {
                                    val encrypted = txCipher.update(framed) ?: return@synchronized
                                    clientOut.write(encrypted)
                                    clientOut.flush()
                                }
                                engine.recordTraffic(upBytes = 0L, downBytes = reply.size.toLong())
                                TunnelStats.inc("tg.bridge.rx")
                            }
                        }
                        val hedgeJob = if (HEDGE_ENABLED && payload.size <= HEDGE_MAX_PAYLOAD &&
                            activeNodeCount(engine) >= 2
                        ) {
                            launch {
                                kotlinx.coroutines.delay(hedgeDelayMs())
                                if (hedgeInFlight.incrementAndGet() > HEDGE_MAX_INFLIGHT) {
                                    hedgeInFlight.decrementAndGet()
                                    TunnelStats.inc("tg.bridge.hedgeSkip")
                                    return@launch
                                }
                                // a twin occupies a real GAS slot too: respect the global cap instead of bypassing it
                                if (!tryAcquireGlobalSlot(engine)) {
                                    hedgeInFlight.decrementAndGet()
                                    TunnelStats.inc("tg.bridge.hedgeSkip")
                                    return@launch
                                }
                                hedgeStarted.set(true)
                                TunnelStats.inc("tg.bridge.hedge")
                                try {
                                    val r = runCatching {
                                        relayPacketDualMethod(
                                            engine = engine, dcId = dcId, dcEndpoint = dcEndpoint,
                                            fallbackIp = targetHost, payload = payload, seqNo = packetSeqNo,
                                            hedge = true
                                        )
                                    }.getOrNull()
                                    if (r != null && !failed.get()) {
                                        runCatching { deliver(r) }
                                        hedgeDelivered.set(true)
                                        TunnelStats.inc("tg.bridge.hedgeRx")
                                    }
                                } finally {
                                    releaseGlobalSlot()
                                    hedgeInFlight.decrementAndGet()
                                }
                            }
                        } else null
                        try {
                            val was404 = AtomicBoolean(false)
                            var replyPayloads = relayPacketDualMethod(
                                engine = engine,
                                dcId = dcId,
                                dcEndpoint = dcEndpoint,
                                fallbackIp = targetHost,
                                payload = payload,
                                seqNo = packetSeqNo,
                                was404 = was404
                            )
                            // transient failure (502 / timeout / bad node): retry once on a different node
                            // instead of tearing down the whole Telegram session
                            if (replyPayloads == null && !was404.get() && !hedgeStarted.get()) {
                                TunnelStats.inc("tg.bridge.retry")
                                replyPayloads = relayPacketDualMethod(
                                    engine = engine,
                                    dcId = dcId,
                                    dcEndpoint = dcEndpoint,
                                    fallbackIp = targetHost,
                                    payload = payload,
                                    seqNo = packetSeqNo,
                                    hedge = true,
                                    was404 = was404
                                )
                            }
                            // primary answered before the hedge fired -> drop the pending hedge; if the hedge
                            // is already in flight let it finish so its reply (possibly the only copy) is delivered
                            if (hedgeJob != null && !hedgeStarted.get()) hedgeJob.cancel()

                            // primary failed but its twin is already in flight: let the twin finish first
                            if (replyPayloads == null && hedgeStarted.get() && hedgeJob != null) {
                                hedgeJob.join()
                                if (hedgeDelivered.get()) return@launch
                            }
                            if (replyPayloads == null) {
                                TunnelStats.inc("tg.bridge.fail")
                                if (was404.get()) {
                                    // real 404 from Telegram's edge: this host does not speak HTTP -> fast-reject it for a while
                                    val hits = deadEdge404Count.getOrPut(targetHost) { AtomicInteger(0) }.incrementAndGet()
                                    if (packetSeqNo == 0 || hits >= 2) {
                                        deadEdgeCooldownUntil[targetHost] = System.currentTimeMillis() + 120_000L
                                        deadEdge404Count.remove(targetHost)
                                    }
                                    failed.set(true)
                                    runCatching { clientIn.close() }
                                } else if (sessionTransientFails.incrementAndGet() >= SESSION_MAX_TRANSIENT_FAILS) {
                                    // timeout / quota / 502 several times in a row: give up this session (no DC cooldown)
                                    failed.set(true)
                                    runCatching { clientIn.close() }
                                } else {
                                    // transient failure: drop only this packet, MTProto resends it on its own
                                    TunnelStats.inc("tg.bridge.dropTransient")
                                }
                                return@launch
                            }
                            sessionTransientFails.set(0)
                            if (packetSeqNo == 0) deadEdge404Count.remove(targetHost)

                            deliver(replyPayloads)
                            val relayMs = ((System.nanoTime() - tRelay0) / 1_000_000L).coerceAtLeast(1L)
                            if (relayMs <= 8_000L) {
                                TunnelStats.sample("t.tgRelay", relayMs)
                            } else {
                                TunnelStats.inc("tg.bridge.longPoll")
                            }
                        } finally {
                            releaseGlobalSlot()
                            concurrencyLimit.release()
                        }
                    }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: EOFException) {
            // Normal client disconnect
        } catch (e: Exception) {
            TunnelLogger.d(
                LogCategory.GAS,
                "TG-BRIDGE-END",
                "پایان نشست پل تلگرام DC$dcId",
                e.localizedMessage
            )
        }
        return@withContext true
    }

    private suspend fun relayPacketDualMethod(
        engine: ParallelTunnelEngine,
        dcId: Int,
        dcEndpoint: DcEndpoint,
        fallbackIp: String,
        payload: ByteArray,
        seqNo: Int,
        hedge: Boolean = false,
        was404: AtomicBoolean? = null
    ): List<ByteArray>? {
        val methodKey = dcEndpoint.webHost
        val preferred = preferredMethodByHost[methodKey] ?: RelayMethod.APIW1_HTTPS
        val order = if (preferred == RelayMethod.APIW1_HTTPS) {
            listOf(RelayMethod.APIW1_HTTPS, RelayMethod.API_HTTP_FULL)
        } else {
            listOf(RelayMethod.API_HTTP_FULL, RelayMethod.APIW1_HTTPS)
        }

        for (method in order) {
            val attempt = when (method) {
                RelayMethod.APIW1_HTTPS -> {
                    var a = tryApiw1Https(engine, dcEndpoint.webHost, payload, hedge)
                    if (a.payloads == null && a.terminal404 && dcEndpoint.mainHost != null) {
                        a = tryApiw1Https(engine, dcEndpoint.mainHost, payload, hedge)
                    }
                    a
                }
                RelayMethod.API_HTTP_FULL -> {
                    if ((apiHttpCooldownUntil[dcId] ?: 0L) > System.currentTimeMillis()) {
                        MethodAttempt(null, terminal404 = true)
                    } else {
                        val a = tryApiHttpFull(engine, dcEndpoint.ip, payload, seqNo, hedge)
                        if (a.terminal404) {
                            apiHttpCooldownUntil[dcId] = System.currentTimeMillis() + 300_000L
                        }
                        a
                    }
                }
            }
            if (attempt.payloads != null) {
                preferredMethodByHost[methodKey] = method
                return attempt.payloads
            }
            // Only treat 404 as terminal if the fallback method itself fails; apiw1 404 should fall back to API_HTTP_FULL
            if (attempt.terminal404 && method == RelayMethod.API_HTTP_FULL) {
                was404?.set(true)
                return null
            }
        }
        return null
    }

    private data class MethodAttempt(val payloads: List<ByteArray>?, val terminal404: Boolean = false)

    private suspend fun tryApiw1Https(
        engine: ParallelTunnelEngine,
        webHost: String,
        payload: ByteArray,
        hedge: Boolean = false
    ): MethodAttempt {
        val url = "https://$webHost/apiw1"
        val headers = mapOf(
            "Content-Type" to "application/octet-stream",
            "Accept" to "*/*"
        )
        val res = engine.relayHttpViaGasPool(
            targetUrl = url,
            method = "POST",
            headers = headers,
            bodyBytes = payload,
            followRedirects = false,
            nodeOffset = if (hedge) 1 else 0
        )
        if (!res.ok || res.statusCode !in 200..299) {
            TunnelLogger.d(
                LogCategory.GAS,
                "TG-APIW1-ERR",
                "خطای متود apiw1 روی $webHost: HTTP ${res.statusCode}",
                res.error
            )
            val is404 = res.ok && res.statusCode == 404
            if (is404) TunnelStats.inc("tg.bridge.404")
            return MethodAttempt(null, terminal404 = is404)
        }
        // Empty 200 OK is valid for fire-and-forget packets such as msgs_ack
        if (res.bodyBytes.isEmpty()) return MethodAttempt(emptyList())
        return MethodAttempt(listOf(res.bodyBytes))
    }

    private suspend fun tryApiHttpFull(
        engine: ParallelTunnelEngine,
        dcIp: String,
        payload: ByteArray,
        seqNo: Int,
        hedge: Boolean = false
    ): MethodAttempt {
        val fullBody = encodeFullPacket(payload, seqNo)
        val url = "http://$dcIp/api"
        val headers = mapOf(
            "Content-Type" to "application/octet-stream",
            "Accept" to "*/*"
        )
        val res = engine.relayHttpViaGasPool(
            targetUrl = url,
            method = "POST",
            headers = headers,
            bodyBytes = fullBody,
            followRedirects = false,
            nodeOffset = if (hedge) 1 else 0
        )
        if (!res.ok || res.statusCode !in 200..299) {
            TunnelLogger.d(
                LogCategory.GAS,
                "TG-API-ERR",
                "خطای متود api-http روی $dcIp: HTTP ${res.statusCode}",
                res.error
            )
            val is404 = res.ok && res.statusCode == 404
            if (is404) TunnelStats.inc("tg.bridge.404")
            return MethodAttempt(null, terminal404 = is404)
        }
        if (res.bodyBytes.isEmpty()) return MethodAttempt(emptyList())
        return MethodAttempt(decodeFullPackets(res.bodyBytes))
    }

    internal fun encodeFullPacket(payload: ByteArray, seqNo: Int): ByteArray {
        val totalLen = payload.size + 12
        val buf = ByteBuffer.allocate(totalLen).order(ByteOrder.LITTLE_ENDIAN)
        buf.putInt(totalLen)
        buf.putInt(seqNo)
        buf.put(payload)
        val crc = CRC32().apply { update(buf.array(), 0, totalLen - 4) }.value.toInt()
        buf.putInt(crc)
        return buf.array()
    }

    internal fun decodeFullPackets(data: ByteArray): List<ByteArray>? {
        if (data.size == 4) {
            // 4-byte MTProto transport error code (e.g. -404, -429)
            return null
        }
        val out = ArrayList<ByteArray>()
        var offset = 0
        while (offset + 12 <= data.size) {
            val len = ByteBuffer.wrap(data, offset, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (len < 12 || offset + len > data.size) {
                // Fallback: if response isn't Full-framed, don't corrupt the stream
                return if (out.isEmpty()) null else out
            }
            val expectedCrc = ByteBuffer.wrap(data, offset + len - 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
            val actualCrc = CRC32().apply { update(data, offset, len - 4) }.value.toInt()
            if (expectedCrc != actualCrc) {
                return if (out.isEmpty()) null else out
            }
            out.add(data.copyOfRange(offset + 8, offset + len - 4))
            offset += len
        }
        return out
    }

    internal fun stripPaddedIntermediatePadding(raw: ByteArray): ByteArray {
        if (raw.size < 20) return raw
        val authKeyId = ByteBuffer.wrap(raw, 0, 8).order(ByteOrder.LITTLE_ENDIAN).long
        if (authKeyId == 0L) {
            // Unencrypted MTProto: auth_key_id(8) + msg_id(8) + msg_data_len(4) + msg_data
            val msgLen = ByteBuffer.wrap(raw, 16, 4).order(ByteOrder.LITTLE_ENDIAN).int
            val exact = 20 + msgLen
            return if (msgLen >= 0 && exact <= raw.size) raw.copyOfRange(0, exact) else raw
        }
        // Encrypted MTProto: auth_key_id(8) + msg_key(16) + N*16 bytes + 0..15 random padding
        if (raw.size < 24) return raw
        val encLen = ((raw.size - 24) / 16) * 16
        return raw.copyOfRange(0, 24 + encLen)
    }

    internal fun decodeAbridgedLengthBytes(first: Int, readThreeBytes: () -> ByteArray?): Int? {
        // Bit 7 (0x80) is the MTProto quick-ack flag; strip it before checking 0x7f
        val cleanFirst = first and 0x7F
        val lenWords = if (cleanFirst == 0x7f) {
            val b = readThreeBytes() ?: return null
            (b[0].toInt() and 0xFF) or
                ((b[1].toInt() and 0xFF) shl 8) or
                ((b[2].toInt() and 0xFF) shl 16)
        } else {
            cleanFirst
        }
        val byteLen = lenWords * 4
        return if (byteLen <= 0 || byteLen > 16 * 1024 * 1024) null else byteLen
    }

    private fun readPacket(stream: BufferedDecryptedStream, mode: TransportMode): ByteArray? {
        return when (mode) {
            TransportMode.ABRIDGED -> {
                val first = stream.readByteOrNull() ?: return null
                val byteLen = decodeAbridgedLengthBytes(first) { stream.readExact(3) } ?: return null
                stream.readExact(byteLen)
            }
            TransportMode.INTERMEDIATE, TransportMode.PADDED -> {
                val lenBytes = stream.readExact(4) ?: return null
                val rawLen = ByteBuffer.wrap(lenBytes).order(ByteOrder.LITTLE_ENDIAN).int
                val byteLen = rawLen and 0x7FFFFFFF
                if (byteLen <= 0 || byteLen > 16 * 1024 * 1024) return null
                stream.readExact(byteLen)
            }
        }
    }

    internal fun framePacket(payload: ByteArray, mode: TransportMode): ByteArray {
        val out = ByteArrayOutputStream(payload.size + 8)
        when (mode) {
            TransportMode.ABRIDGED -> {
                val words = payload.size / 4
                if (words < 127) {
                    out.write(words)
                } else {
                    out.write(0x7f)
                    out.write(words and 0xFF)
                    out.write((words shr 8) and 0xFF)
                    out.write((words shr 16) and 0xFF)
                }
                out.write(payload)
            }
            TransportMode.INTERMEDIATE, TransportMode.PADDED -> {
                val lenBytes = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(payload.size).array()
                out.write(lenBytes)
                out.write(payload)
            }
        }
        return out.toByteArray()
    }

    private class BufferedDecryptedStream(
        private val input: InputStream,
        private val cipher: Cipher,
        initialLeftover: ByteArray
    ) {
        private var buf = if (initialLeftover.isNotEmpty()) {
            cipher.update(initialLeftover) ?: ByteArray(0)
        } else {
            ByteArray(0)
        }
        private var pos = 0

        fun readByteOrNull(): Int? {
            if (!ensureAvailable(1)) return null
            return buf[pos++].toInt() and 0xFF
        }

        fun readExact(count: Int): ByteArray? {
            val out = ByteArray(count)
            var filled = 0
            while (filled < count) {
                if (!ensureAvailable(1)) return null
                val take = minOf(count - filled, buf.size - pos)
                System.arraycopy(buf, pos, out, filled, take)
                pos += take
                filled += take
            }
            return out
        }

        private fun ensureAvailable(needed: Int): Boolean {
            if (buf.size - pos >= needed) return true
            val tmp = ByteArray(16_384)
            val n = input.read(tmp)
            if (n <= 0) return false
            val dec = cipher.update(tmp, 0, n) ?: return false
            val rem = buf.size - pos
            val next = ByteArray(rem + dec.size)
            if (rem > 0) System.arraycopy(buf, pos, next, 0, rem)
            System.arraycopy(dec, 0, next, rem, dec.size)
            buf = next
            pos = 0
            return buf.isNotEmpty()
        }
    }
}
