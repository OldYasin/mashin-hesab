package com.example.network

import com.example.core.logging.LogCategory
import com.example.core.logging.TunnelLogger
import com.example.data.local.CleanIpEntity
import com.example.data.model.IpProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLParameters
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.math.abs
import kotlin.random.Random

data class ScanProgress(
    val isScanning: Boolean = false,
    val scannedCount: Int = 0,
    val totalCount: Int = 0,
    val foundCount: Int = 0,
    val provider: IpProvider = IpProvider.GOOGLE
)

object CleanIpScanner {

    // Official Google IPv4 CIDR ranges (Google Frontend / Apps Script / Search)
    private val googleCidrs = listOf(
        "142.250.0.0/15",
        "172.217.0.0/16",
        "216.58.192.0/19",
        "172.253.0.0/16",
        "74.125.0.0/16",
        "108.177.0.0/17",
        "209.85.128.0/17",
        "64.233.160.0/19"
    )

    // Official Cloudflare IPv4 CIDR ranges
    private val cloudflareCidrs = listOf(
        "104.16.0.0/13",
        "104.24.0.0/14",
        "172.64.0.0/13",
        "162.158.0.0/15",
        "188.114.96.0/20",
        "198.41.128.0/17",
        "141.101.64.0/18",
        "108.162.192.0/18",
        "103.21.244.0/22",
        "103.22.200.0/22",
        "103.31.4.0/22",
        "190.93.240.0/20",
        "197.234.240.0/22"
    )

    data class DnsResolverStatus(
        val name: String,
        val endpoint: String,
        val isDoh: Boolean,
        val ok: Boolean,
        val latencyMs: Int,
        val poisoned: Boolean = false
    )

    private val topCleanIps = ConcurrentHashMap<IpProvider, List<String>>()
    private val rotateIndex = ConcurrentHashMap<IpProvider, Int>()

    fun seedTopIps(provider: IpProvider, ips: List<String>) {
        if (ips.isNotEmpty()) {
            topCleanIps[provider] = ips.distinct().take(8)
        }
    }

    fun rotateNextCleanIp(provider: IpProvider, failedIp: String): String? {
        val list = topCleanIps[provider].orEmpty().filter { it != failedIp && it !in badAutoIps }
        if (list.isEmpty()) return null
        val idx = (rotateIndex[provider] ?: 0) % list.size
        rotateIndex[provider] = idx + 1
        return list[idx]
    }

    suspend fun testDnsResolvers(): List<DnsResolverStatus> = withContext(Dispatchers.IO) {
        // Minimal DNS A-record query for example.com (ID=0x1234)
        val dnsQuery = byteArrayOf(
            0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x07, 'e'.code.toByte(), 'x'.code.toByte(), 'a'.code.toByte(), 'm'.code.toByte(),
            'p'.code.toByte(), 'l'.code.toByte(), 'e'.code.toByte(),
            0x03, 'c'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte(), 0x00,
            0x00, 0x01, 0x00, 0x01
        )
        val targets = listOf(
            Triple("Google DoH", "https://dns.google/dns-query", true),
            Triple("Cloudflare DoH", "https://cloudflare-dns.com/dns-query", true),
            Triple("Quad9 DoH", "https://dns.quad9.net/dns-query", true),
            Triple("OpenDNS DoH", "https://doh.opendns.com/dns-query", true),
            Triple("AdGuard DoH", "https://dns.adguard-dns.com/dns-query", true),
            Triple("Google UDP", "8.8.8.8", false),
            Triple("Cloudflare UDP", "1.1.1.1", false),
            Triple("Quad9 UDP", "9.9.9.9", false)
        )
        coroutineScope {
            targets.map { (name, endpoint, isDoh) ->
                async {
                    val t0 = System.nanoTime()
                    if (isDoh) {
                        runCatching {
                            val url = java.net.URL(endpoint)
                            val conn = url.openConnection() as HttpsURLConnection
                            conn.connectTimeout = 2500
                            conn.readTimeout = 2500
                            conn.requestMethod = "POST"
                            conn.doOutput = true
                            conn.setRequestProperty("Content-Type", "application/dns-message")
                            conn.setRequestProperty("Accept", "application/dns-message")
                            conn.outputStream.use { it.write(dnsQuery) }
                            val code = conn.responseCode
                            val body = if (code in 200..299) conn.inputStream.use { it.readBytes() } else ByteArray(0)
                            val rtt = ((System.nanoTime() - t0) / 1_000_000L).toInt().coerceAtLeast(1)
                            val poisoned = hasPoisonedIp(body)
                            DnsResolverStatus(name, endpoint, true, code in 200..299 && body.size >= 12 && !poisoned, rtt, poisoned)
                        }.getOrElse {
                            DnsResolverStatus(name, endpoint, true, false, -1, false)
                        }
                    } else {
                        runCatching {
                            java.net.DatagramSocket().use { ds ->
                                BypassOkHttpFactory.datagramProtector?.invoke(ds)
                                ds.soTimeout = 2000
                                val addr = java.net.InetAddress.getByName(endpoint)
                                ds.send(java.net.DatagramPacket(dnsQuery, dnsQuery.size, addr, 53))
                                val buf = ByteArray(512)
                                val resp = java.net.DatagramPacket(buf, buf.size)
                                ds.receive(resp)
                                val rtt = ((System.nanoTime() - t0) / 1_000_000L).toInt().coerceAtLeast(1)
                                val data = buf.copyOf(resp.length)
                                val poisoned = hasPoisonedIp(data)
                                DnsResolverStatus(name, endpoint, false, data.size >= 12 && !poisoned, rtt, poisoned)
                            }
                        }.getOrElse {
                            DnsResolverStatus(name, endpoint, false, false, -1, false)
                        }
                    }
                }
            }.awaitAll()
        }
    }

    private fun hasPoisonedIp(dnsWire: ByteArray): Boolean {
        for (i in 12 until dnsWire.size - 3) {
            if (dnsWire[i] == 10.toByte() && dnsWire[i + 1] == 10.toByte() && dnsWire[i + 2] == 34.toByte()) return true
        }
        return false
    }

    fun defaultRangesFor(provider: IpProvider): List<String> = when (provider) {
        IpProvider.GOOGLE -> googleCidrs
        IpProvider.CLOUDFLARE -> cloudflareCidrs
    }

    private val autoScanLock = Any()
    @Volatile
    private var cachedAutoGoogleIp: String? = null
    @Volatile
    private var cachedAutoGoogleIpAtMs: Long = 0L
    private const val AUTO_IP_TTL_MS = 15 * 60_000L
    private val badAutoIps = ConcurrentHashMap.newKeySet<String>()

    fun invalidateAutoGoogleIp(ip: String) {
        val trimmed = ip.trim()
        if (trimmed.isNotBlank()) badAutoIps.add(trimmed)
        if (cachedAutoGoogleIp == trimmed) {
            cachedAutoGoogleIp = null
            cachedAutoGoogleIpAtMs = 0L
        }
    }

    /**
     * Used when system DNS (and 8.8.8.8) fails during total internet blackouts:
     * runs a fast, single-flight parallel TLS+HTTP scan across Google CIDRs to find a live IP.
     */
    fun quickDiscoverGoogleIpBlocking(): String? {
        val now = System.currentTimeMillis()
        val existing = cachedAutoGoogleIp
        if (existing != null && existing !in badAutoIps && now - cachedAutoGoogleIpAtMs < AUTO_IP_TTL_MS) {
            return existing
        }
        synchronized(autoScanLock) {
            val recheck = cachedAutoGoogleIp
            val now2 = System.currentTimeMillis()
            if (recheck != null && recheck !in badAutoIps && now2 - cachedAutoGoogleIpAtMs < AUTO_IP_TTL_MS) {
                return recheck
            }
            val found = runBlocking(Dispatchers.IO) {
                scanCleanIps(
                    provider = IpProvider.GOOGLE,
                    customPrefix = "",
                    sampleCount = 28,
                    deep = false,
                    onProgress = {}
                ).firstOrNull { it.ip !in badAutoIps }
            }
            if (found != null) {
                cachedAutoGoogleIp = found.ip
                cachedAutoGoogleIpAtMs = System.currentTimeMillis()
                TunnelLogger.i(
                    LogCategory.TLS_IP,
                    "AUTO-SCAN",
                    "آی‌پی سالم گوگل با اسکن خودکار پیدا شد: ${found.ip} (${found.latencyMs}ms)"
                )
                return found.ip
            }
            return null
        }
    }

    fun generateCandidates(
        provider: IpProvider,
        customPrefix: String = "",
        sampleCount: Int = 60
    ): List<String> {
        val ranges = if (customPrefix.isNotBlank()) {
            customPrefix.split(',', ';', '\n')
                .map { it.trim() }
                .filter { it.isNotBlank() }
        } else {
            when (provider) {
                IpProvider.GOOGLE -> googleCidrs
                IpProvider.CLOUDFLARE -> cloudflareCidrs
            }
        }
        if (ranges.isEmpty()) return emptyList()

        val candidates = LinkedHashSet<String>()
        var attempts = 0
        val maxAttempts = sampleCount * 6
        while (candidates.size < sampleCount && attempts < maxAttempts) {
            val range = ranges[attempts % ranges.size]
            attempts++
            val ip = sampleIpFromRange(range)
            if (ip != null) candidates.add(ip)
        }
        return candidates.toList()
    }

    private fun sampleIpFromRange(raw: String): String? {
        val trimmed = raw.trim().trimEnd('.')
        if (trimmed.contains('/')) {
            val parts = trimmed.split('/', limit = 2)
            val baseInt = ipv4ToInt(parts[0].trim()) ?: return null
            val prefixLen = parts[1].trim().toIntOrNull()?.coerceIn(8, 32) ?: return null
            if (prefixLen == 32) return intToIpv4(baseInt)
            val hostBits = 32 - prefixLen
            val mask = (-1L shl hostBits).toInt()
            val network = baseInt and mask
            val span = 1 shl hostBits
            val offset = if (span <= 2) Random.nextInt(0, span) else Random.nextInt(1, span - 1)
            val candidateInt = network or offset
            val lastOctet = candidateInt and 0xFF
            if (lastOctet == 0 || lastOctet == 255) return null
            return intToIpv4(candidateInt)
        }
        val parts = trimmed.split('.')
        return when (parts.size) {
            4 -> trimmed
            3 -> "$trimmed.${Random.nextInt(1, 254)}"
            2 -> "$trimmed.${Random.nextInt(1, 254)}.${Random.nextInt(1, 254)}"
            1 -> "${parts[0]}.${Random.nextInt(1, 254)}.${Random.nextInt(1, 254)}.${Random.nextInt(1, 254)}"
            else -> null
        }
    }

    private fun ipv4ToInt(ip: String): Int? {
        val parts = ip.split('.')
        if (parts.size != 4) return null
        var acc = 0
        for (p in parts) {
            val oct = p.toIntOrNull() ?: return null
            if (oct < 0 || oct > 255) return null
            acc = (acc shl 8) or oct
        }
        return acc
    }

    private fun intToIpv4(value: Int): String {
        return "${(value ushr 24) and 0xFF}.${(value ushr 16) and 0xFF}.${(value ushr 8) and 0xFF}.${value and 0xFF}"
    }

    // ---------------------------------------------------------------------------------------------
    // Scanner v2
    //  * The old probe timed TCP + TLS + one HTTP request together (~3 round trips), so every IP of the same
    //    edge landed at ~3 x RTT (~600 ms). Now connect cost (tcp, tls) and the latency of requests on an
    //    ALREADY OPEN connection (what the relay really sees: the HTTP/2 connection is reused) are measured apart.
    //  * Stage 1 is broad and cheap, then the neighbourhood (/24) of the best hits is explored, then the
    //    finalists are measured on 3 fresh connections x 4 warm requests with a lower parallelism so the phone
    //    does not congest its own link and flatten the differences.
    // ---------------------------------------------------------------------------------------------

    private class ProbeResult(
        val ip: String,
        val tcpMs: Int,
        val tlsMs: Int,
        val warmRtts: List<Int>
    ) {
        val connectMs: Int get() = tcpMs + tlsMs
        /** broad stage ranking: connect cost + first request, i.e. the old "total" number */
        val stage1Score: Int get() = connectMs + (warmRtts.firstOrNull() ?: 0)
    }

    private class DeepResult(val entity: CleanIpEntity, val score: Int, val connectMs: Int)

    private class OpenConn(
        val sock: Socket,
        val ssl: SSLSocket,
        val reader: BufferedReader,
        val tcpMs: Int,
        val tlsMs: Int
    ) {
        fun close() {
            runCatching { ssl.close() }
            runCatching { sock.close() }
        }
    }

    private class HttpReply(val ms: Int, val reusable: Boolean)

    private fun nsToMs(ns: Long): Int = (ns / 1_000_000L).toInt().coerceAtLeast(1)

    internal fun medianOf(values: List<Int>): Int {
        if (values.isEmpty()) return 0
        val s = values.sorted()
        return if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2
    }

    /** spread of warm samples: p90 - min (robust against one outlier, unlike max - min) */
    internal fun spreadOf(values: List<Int>): Int {
        if (values.size < 2) return 0
        val s = values.sorted()
        return s[((s.size - 1) * 0.9).toInt()] - s.first()
    }

    /** final ranking: request latency on a warm connection + half the jitter + an eighth of the connect cost */
    internal fun rankScore(warmMedianMs: Int, jitterMs: Int, connectMs: Int): Int =
        warmMedianMs + jitterMs / 2 + connectMs / 8

    internal fun isPublicIpv4(ip: String): Boolean {
        val p = ip.split('.')
        if (p.size != 4) return false
        val o = p.map { it.toIntOrNull() ?: return false }
        if (o.any { it !in 0..255 }) return false
        return when {
            o[0] == 0 || o[0] == 10 || o[0] == 127 || o[0] >= 224 -> false
            o[0] == 169 && o[1] == 254 -> false
            o[0] == 172 && o[1] in 16..31 -> false
            o[0] == 192 && o[1] == 168 -> false
            o[0] == 100 && o[1] in 64..127 -> false
            else -> true
        }
    }

    /** random unused addresses from the same /24 as [ip] (a live edge IP usually has live neighbours) */
    internal fun neighborIps(ip: String, tried: Set<String>, count: Int): List<String> {
        val p = ip.split('.')
        if (p.size != 4) return emptyList()
        val prefix = "${p[0]}.${p[1]}.${p[2]}"
        val out = LinkedHashSet<String>()
        var guard = 0
        while (out.size < count && guard++ < count * 6) {
            val c = "$prefix.${Random.nextInt(1, 255)}"
            if (c != ip && c !in tried) out.add(c)
        }
        return out.toList()
    }

    /** IPs that the system resolver returns for the provider's own hostnames (poisoned/private answers dropped) */
    private suspend fun resolveSeedIps(provider: IpProvider): List<String> {
        val hosts = when (provider) {
            IpProvider.GOOGLE -> listOf("script.google.com", "script.googleusercontent.com", "www.google.com", "docs.google.com")
            IpProvider.CLOUDFLARE -> listOf("cloudflare.com", "www.cloudflare.com")
        }
        val found = java.util.concurrent.ConcurrentLinkedQueue<String>()
        val scope = kotlinx.coroutines.CoroutineScope(Dispatchers.IO + kotlinx.coroutines.SupervisorJob())
        val jobs = hosts.map { h ->
            scope.launch {
                runCatching {
                    java.net.InetAddress.getAllByName(h)
                        .filterIsInstance<java.net.Inet4Address>()
                        .forEach { a -> a.hostAddress?.let { found.add(it) } }
                }
            }
        }
        // getAllByName cannot be cancelled: do not join the blocking calls beyond the timeout, use what arrived
        kotlinx.coroutines.withTimeoutOrNull(1800L) { jobs.forEach { it.join() } }
        scope.cancel()
        return found.filter { isPublicIpv4(it) }.distinct()
    }

    private fun openTlsConnection(
        ip: String,
        sniHost: String,
        connectTimeoutMs: Int = 1500,
        readTimeoutMs: Int = 1800
    ): OpenConn? {
        val sock = Socket()
        var ssl: SSLSocket? = null
        return try {
            BypassOkHttpFactory.socketProtector?.invoke(sock)
            val t0 = System.nanoTime()
            sock.connect(InetSocketAddress(ip, 443), connectTimeoutMs)
            val t1 = System.nanoTime()
            sock.tcpNoDelay = true
            val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
            val s = factory.createSocket(sock, sniHost, 443, true) as SSLSocket
            ssl = s
            s.soTimeout = readTimeoutMs
            val params: SSLParameters = s.sslParameters
            params.serverNames = listOf(SNIHostName(sniHost))
            params.endpointIdentificationAlgorithm = "HTTPS"
            s.sslParameters = params
            s.startHandshake()
            val t2 = System.nanoTime()
            if (!HttpsURLConnection.getDefaultHostnameVerifier().verify(sniHost, s.session)) {
                runCatching { s.close() }
                runCatching { sock.close() }
                return null
            }
            OpenConn(
                sock = sock,
                ssl = s,
                reader = BufferedReader(InputStreamReader(s.inputStream, Charsets.ISO_8859_1)),
                tcpMs = nsToMs(t1 - t0),
                tlsMs = nsToMs(t2 - t1)
            )
        } catch (_: Exception) {
            runCatching { ssl?.close() }
            runCatching { sock.close() }
            null
        }
    }

    /**
     * One request/response on an open connection. The measured time is request -> status line (a pure round trip
     * plus server think time). Returns null when the answer is not a sane HTTP response for this provider.
     */
    private fun httpRoundTrip(conn: OpenConn, sniHost: String, provider: IpProvider, keepAlive: Boolean): HttpReply? {
        val isCf = provider == IpProvider.CLOUDFLARE
        val method = if (isCf) "GET" else "HEAD"
        val path = if (isCf) "/cdn-cgi/trace" else "/"
        val req = (
            "$method $path HTTP/1.1\r\n" +
                "Host: $sniHost\r\n" +
                "User-Agent: Mozilla/5.0\r\n" +
                "Accept: */*\r\n" +
                "Connection: ${if (keepAlive) "keep-alive" else "close"}\r\n\r\n"
            ).toByteArray(Charsets.US_ASCII)
        return try {
            val t0 = System.nanoTime()
            conn.ssl.outputStream.write(req)
            conn.ssl.outputStream.flush()
            val status = conn.reader.readLine() ?: return null
            val ms = nsToMs(System.nanoTime() - t0)
            if (!status.startsWith("HTTP/1.")) return null
            val code = status.split(' ').getOrNull(1)?.toIntOrNull() ?: return null
            if (code !in 200..499) return null
            if (isCf && code != 200) return null

            var contentLength = -1
            var connClose = false
            var lines = 0
            while (true) {
                val line = conn.reader.readLine() ?: return null
                if (line.isEmpty()) break
                if (++lines > 64) return null
                val lower = line.lowercase()
                if (lower.startsWith("content-length:")) contentLength = lower.substringAfter(':').trim().toIntOrNull() ?: -1
                if (lower.startsWith("connection:") && lower.contains("close")) connClose = true
            }
            var reusable = keepAlive && !connClose
            if (method != "HEAD") {
                if (contentLength in 0..65_536) {
                    var left = contentLength
                    val buf = CharArray(1024)
                    while (left > 0) {
                        val n = conn.reader.read(buf, 0, minOf(left, buf.size))
                        if (n < 0) { reusable = false; break }
                        left -= n
                    }
                } else {
                    reusable = false // chunked / until-close body: do not reuse this connection
                }
            }
            HttpReply(ms, reusable)
        } catch (_: Exception) {
            null
        }
    }

    /** TCP + TLS (certificate checked for [sniHost]) + [warmSamples] requests on that same connection. */
    private fun probeConnection(ip: String, sniHost: String, provider: IpProvider, warmSamples: Int): ProbeResult? {
        val conn = openTlsConnection(ip, sniHost) ?: return null
        try {
            val rtts = ArrayList<Int>(warmSamples)
            for (i in 0 until warmSamples) {
                val reply = httpRoundTrip(conn, sniHost, provider, keepAlive = i < warmSamples - 1)
                if (reply == null) {
                    if (i == 0) return null
                    break
                }
                rtts.add(reply.ms)
                if (!reply.reusable) break
            }
            if (rtts.isEmpty()) return null
            return ProbeResult(ip, conn.tcpMs, conn.tlsMs, rtts)
        } finally {
            conn.close()
        }
    }

    suspend fun scanCleanIps(
        provider: IpProvider,
        customPrefix: String = "",
        sampleCount: Int = 60,
        deep: Boolean = true,
        expand: Boolean = true,
        seedIps: List<String> = emptyList(),
        onProgress: (ScanProgress) -> Unit
    ): List<CleanIpEntity> = withContext(Dispatchers.IO) {
        val useOfficial = customPrefix.isBlank()
        val sniHost = when (provider) {
            IpProvider.GOOGLE -> "script.google.com"
            IpProvider.CLOUDFLARE -> "cloudflare.com"
        }

        // candidates: previously good IPs first, then DNS answers, then random samples of the ranges
        val candidates = LinkedHashSet<String>()
        if (useOfficial) {
            seedIps.filter { isPublicIpv4(it) }.forEach { candidates.add(it) }
            topCleanIps[provider].orEmpty().forEach { candidates.add(it) }
            if (deep) resolveSeedIps(provider).forEach { candidates.add(it) }
        }
        candidates.addAll(generateCandidates(provider, customPrefix, sampleCount))

        val tried = HashSet<String>(candidates)
        var total = candidates.size
        var scanned = 0
        val stage1 = ArrayList<ProbeResult>()
        val semaphore = Semaphore(24)

        TunnelLogger.i(
            LogCategory.TLS_IP,
            "SCAN-START",
            "شروع اسکن ${provider.titleFa} ($total کاندید)",
            "SNI=$sniHost, ranges=${customPrefix.ifBlank { "official-cidrs" }}, deep=$deep, expand=$expand, seeds=${candidates.size - sampleCount.coerceAtMost(candidates.size)}"
        )
        onProgress(ScanProgress(isScanning = true, scannedCount = 0, totalCount = total, foundCount = 0, provider = provider))

        suspend fun probeBatch(ips: List<String>) {
            coroutineScope {
                ips.map { ip ->
                    async {
                        semaphore.withPermit {
                            val r = probeConnection(ip, sniHost, provider, warmSamples = 1)
                            synchronized(stage1) {
                                scanned++
                                if (r != null) stage1.add(r)
                                onProgress(
                                    ScanProgress(
                                        isScanning = true,
                                        scannedCount = scanned,
                                        totalCount = total,
                                        foundCount = stage1.size,
                                        provider = provider
                                    )
                                )
                            }
                        }
                    }
                }.awaitAll()
            }
        }

        // Stage 1: broad TCP + TLS(SNI + certificate) + one HTTP answer
        probeBatch(candidates.toList())

        // Stage 1b: explore the /24 neighbourhood of the best hits
        if (deep && expand && useOfficial && stage1.isNotEmpty()) {
            val best = synchronized(stage1) { stage1.sortedBy { it.stage1Score }.take(12) }
            val extra = LinkedHashSet<String>()
            for (b in best) extra.addAll(neighborIps(b.ip, tried, 8))
            if (extra.isNotEmpty()) {
                tried.addAll(extra)
                total += extra.size
                probeBatch(extra.toList())
            }
        }

        val ranked = synchronized(stage1) { stage1.sortedBy { it.stage1Score } }

        val sorted: List<CleanIpEntity>
        if (!deep) {
            // fast mode (blackout auto-discovery): verify the secondary SNI only for the few best hits
            val top = ranked.take(8)
            val ok = coroutineScope {
                top.map { r ->
                    async {
                        if (provider != IpProvider.GOOGLE || verifyAdditionalSni(r.ip, "script.googleusercontent.com")) r else null
                    }
                }.awaitAll().filterNotNull()
            }
            sorted = ok.map {
                CleanIpEntity(
                    ip = it.ip, provider = provider.name, latencyMs = it.stage1Score, jitterMs = 0,
                    tlsVerified = true, isSelected = false, lastTestedMs = System.currentTimeMillis()
                )
            }
        } else {
            // Stage 2: 3 fresh connections x 4 warm requests per finalist, low parallelism
            val finalists = ranked.take(24)
            val deepSem = Semaphore(6)
            val results = ArrayList<DeepResult>()
            if (finalists.isNotEmpty()) {
                coroutineScope {
                    finalists.map { cand ->
                        async {
                            deepSem.withPermit {
                                val d = probeIpDeep(cand.ip, sniHost, provider)
                                if (d != null) synchronized(results) { results.add(d) }
                            }
                        }
                    }.awaitAll()
                }
            }
            val byScore = results.sortedBy { it.score }
            sorted = byScore.map { it.entity }
            if (byScore.isNotEmpty()) {
                TunnelLogger.i(
                    LogCategory.TLS_IP,
                    "SCAN-TOP",
                    "نتیجه‌ی اسکن دقیق ${provider.titleFa}",
                    byScore.take(5).joinToString("\n") {
                        "${it.entity.ip} -> req ${it.entity.latencyMs}ms (jitter ${it.entity.jitterMs}ms) • connect ${it.connectMs}ms • score ${it.score}"
                    }
                )
            }
        }

        if (sorted.isNotEmpty()) seedTopIps(provider, sorted.map { it.ip })
        if (sorted.isNotEmpty()) {
            val top = sorted.first()
            TunnelLogger.i(
                LogCategory.TLS_IP,
                "SCAN-DONE",
                "اسکن ${provider.titleFa} پایان یافت: ${sorted.size} آی‌پی معتبر از ${stage1.size} پاسخ‌دهنده (بهترین: ${top.ip} با ${top.latencyMs}ms)",
                "probed=$total, stage1-ok=${stage1.size}"
            )
        } else {
            TunnelLogger.w(
                LogCategory.TLS_IP,
                "SCAN-EMPTY",
                "هیچ آی‌پی تمیز معتبری برای ${provider.titleFa} در این رنج یافت نشد",
                "Total probed: $total, SNI=$sniHost"
            )
        }

        onProgress(
            ScanProgress(
                isScanning = false,
                scannedCount = total,
                totalCount = total,
                foundCount = sorted.size,
                provider = provider
            )
        )
        sorted
    }

    /**
     * Deep check of one finalist: 3 fresh connections, each with 4 requests on the open connection.
     * latencyMs = median warm request latency (first request of each connection dropped: it pays cold-start cost),
     * jitterMs = p90 - min of the warm samples, connect cost only enters the ranking score.
     */
    private fun probeIpDeep(ip: String, sniHost: String, provider: IpProvider): DeepResult? {
        val tcps = ArrayList<Int>()
        val tlss = ArrayList<Int>()
        val warm = ArrayList<Int>()
        var fails = 0
        for (round in 0 until 3) {
            val r = probeConnection(ip, sniHost, provider, warmSamples = 4)
            if (r == null) {
                fails++
                if (fails > 1) return null // flaky: needs >= 2 of 3 good connections
                continue
            }
            tcps.add(r.tcpMs)
            tlss.add(r.tlsMs)
            warm.addAll(if (r.warmRtts.size >= 3) r.warmRtts.drop(1) else r.warmRtts)
        }
        if (tcps.size < 2 || warm.size < 4) return null
        if (provider == IpProvider.GOOGLE && !verifyAdditionalSni(ip, "script.googleusercontent.com")) return null
        if (provider == IpProvider.CLOUDFLARE && !verifyWebSocketUpgradeProbe(ip, sniHost)) return null

        val warmMed = medianOf(warm)
        val jitter = spreadOf(warm)
        val connect = medianOf(tcps) + medianOf(tlss)
        val entity = CleanIpEntity(
            ip = ip,
            provider = provider.name,
            latencyMs = warmMed,
            jitterMs = jitter,
            tlsVerified = true,
            isSelected = false,
            lastTestedMs = System.currentTimeMillis()
        )
        return DeepResult(entity, rankScore(warmMed, jitter, connect), connect)
    }

    private fun verifyWebSocketUpgradeProbe(ip: String, sniHost: String): Boolean {
        val sock = Socket()
        var ssl: SSLSocket? = null
        return try {
            BypassOkHttpFactory.socketProtector?.invoke(sock)
            sock.connect(InetSocketAddress(ip, 443), 1500)
            val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
            ssl = sslFactory.createSocket(sock, sniHost, 443, true) as SSLSocket
            ssl.soTimeout = 1800
            val params = ssl.sslParameters
            params.serverNames = listOf(SNIHostName(sniHost))
            params.endpointIdentificationAlgorithm = "HTTPS"
            ssl.sslParameters = params
            ssl.startHandshake()
            val req = (
                "GET / HTTP/1.1\r\n" +
                    "Host: $sniHost\r\n" +
                    "Upgrade: websocket\r\n" +
                    "Connection: Upgrade\r\n" +
                    "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n" +
                    "Sec-WebSocket-Version: 13\r\n\r\n"
                ).toByteArray(Charsets.US_ASCII)
            ssl.outputStream.write(req)
            ssl.outputStream.flush()
            val statusLine = BufferedReader(InputStreamReader(ssl.inputStream, Charsets.US_ASCII)).readLine()
            statusLine != null && statusLine.startsWith("HTTP/1.")
        } catch (_: Exception) {
            false
        } finally {
            runCatching { ssl?.close() }
            runCatching { sock.close() }
        }
    }

    private fun verifyAdditionalSni(ip: String, host: String): Boolean {
        val sock = Socket()
        var ssl: SSLSocket? = null
        return try {
            BypassOkHttpFactory.socketProtector?.invoke(sock)
            sock.connect(InetSocketAddress(ip, 443), 1400)
            val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
            ssl = sslFactory.createSocket(sock, host, 443, true) as SSLSocket
            ssl.soTimeout = 1600
            val params: SSLParameters = ssl.sslParameters
            params.serverNames = listOf(SNIHostName(host))
            params.endpointIdentificationAlgorithm = "HTTPS"
            ssl.sslParameters = params
            ssl.startHandshake()
            HttpsURLConnection.getDefaultHostnameVerifier().verify(host, ssl.session)
        } catch (_: Exception) {
            false
        } finally {
            runCatching { ssl?.close() }
            runCatching { sock.close() }
        }
    }
}
