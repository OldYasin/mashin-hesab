package com.example

import com.example.network.CleanIpScanner
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CleanIpScannerTest {

    @Test
    fun medianHandlesOddEvenAndEmpty() {
        assertEquals(0, CleanIpScanner.medianOf(emptyList()))
        assertEquals(5, CleanIpScanner.medianOf(listOf(9, 1, 5)))
        assertEquals(6, CleanIpScanner.medianOf(listOf(4, 8, 5, 7)))
    }

    @Test
    fun spreadIgnoresSingleOutlier() {
        // p90 - min: one slow sample out of ten must not dominate like max - min would
        val samples = listOf(200, 205, 198, 210, 202, 199, 204, 201, 207, 900)
        assertTrue(CleanIpScanner.spreadOf(samples) < 20)
        assertEquals(0, CleanIpScanner.spreadOf(listOf(150)))
    }

    @Test
    fun rankScorePrefersLowWarmLatencyOverConnectCost() {
        val steady = CleanIpScanner.rankScore(warmMedianMs = 180, jitterMs = 10, connectMs = 400)
        val spiky = CleanIpScanner.rankScore(warmMedianMs = 180, jitterMs = 120, connectMs = 300)
        val slow = CleanIpScanner.rankScore(warmMedianMs = 260, jitterMs = 10, connectMs = 300)
        assertTrue(steady < spiky)
        assertTrue(steady < slow)
    }

    @Test
    fun publicIpv4RejectsPoisonedAndPrivateAnswers() {
        assertFalse(CleanIpScanner.isPublicIpv4("10.10.34.34"))
        assertFalse(CleanIpScanner.isPublicIpv4("192.168.1.1"))
        assertFalse(CleanIpScanner.isPublicIpv4("172.20.0.1"))
        assertFalse(CleanIpScanner.isPublicIpv4("127.0.0.1"))
        assertFalse(CleanIpScanner.isPublicIpv4("not-an-ip"))
        assertTrue(CleanIpScanner.isPublicIpv4("142.250.185.46"))
        assertTrue(CleanIpScanner.isPublicIpv4("172.217.16.14"))
    }

    @Test
    fun neighborsStayInSameSlash24AndSkipTried() {
        val tried = setOf("142.250.185.46", "142.250.185.47")
        val n = CleanIpScanner.neighborIps("142.250.185.46", tried, 8)
        assertEquals(8, n.size)
        assertEquals(8, n.toSet().size)
        n.forEach {
            assertTrue(it.startsWith("142.250.185."))
            assertFalse(it in tried)
        }
    }
}
