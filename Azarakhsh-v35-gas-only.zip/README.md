<div dir="rtl" align="right">

# آذرخش (Azarakhsh)

**اپ اندروید برای روزهای قطعی کامل اینترنت در ایران.**

آذرخش برای زمانی ساخته شده که دسترسی به اینترنت بین‌الملل در ایران قطع شده است، یعنی وقتی که VPN و پروکسی‌های معمول دیگر کار نمی‌کنند ولی هنوز می‌شود به سرویس‌های گوگل رسید. این نسخه (`gas-only`) فقط از **Google Apps Script (GAS)** به‌عنوان رله استفاده می‌کند. نه VPS لازم است، نه Cloudflare Worker و نه سرور خارج از کشور؛ فقط چند اکانت گوگل.

## چطور کار می‌کند

```
اپ‌های گوشی ─► VPN محلی ─► آذرخش ─► IP تمیز گوگل ─► Apps Script (شما) ─► اینترنت آزاد
تلگرام ───────► SOCKS5 محلی ─► پل MTProto-HTTP ───► Apps Script (شما) ─► سرورهای تلگرام
```

- هر اکانت گوگل یک اسکریپت (Web App) می‌گیرد؛ اپ کد اسکریپت را با کلید اختصاصی خودتان می‌سازد و درخواست‌ها را بین چند اسکریپت موازی پخش می‌کند.
- ارتباط با گوگل از طریق **IP تمیز** انجام می‌شود که اسکنر داخل اپ پیدا می‌کند.
- ترافیک HTTP/HTTPS از رله‌ی GAS عبور می‌کند (با گواهی MITM محلی، برای HTTPS).
- سایت‌های ایرانی مستقیم و بدون تونل باز می‌شوند.
- DNS از طریق DoH گوگل رد می‌شود.

## قابلیت‌ها

- رله‌ی چندنودی با Google Apps Script، با پخش بار، cooldown خودکار روی نودهای پر شده (quota) و cache برای محتوای ایستا
- **اسکنر IP تمیز گوگل** با سنجش جداگانه‌ی connect و تأخیر درخواست روی کانکشن باز، گشتن همسایه‌ها و تست دوباره‌ی IPهای خوب قبلی
- **پل MTProto به HTTP برای تلگرام** (مسیر `/apiw1` و `/api`) روی SOCKS5 محلی، همراه با hedging تطبیقی و retry روی نود دیگر
- کنترل دمای گوشی (Thermal Guard)
- گزارش‌ها، لاگ تشخیصی و Export برای عیب‌یابی

## راه‌اندازی

1. **ساخت اسکریپت** (برای هر اکانت گوگل یک بار): داخل اپ به بخش راهنمای اسکریپت بروید، کد تولیدشده را در یک پروژه‌ی جدید Apps Script بچسبانید و `Deploy > New deployment > Web app` را بزنید (`Execute as: Me`، `Who has access: Anyone`). لینک `/exec` را کپی کنید.
2. **افزودن نودها:** لینک هر اسکریپت را در بخش سرورها اضافه کنید. برای هر اکانت **یک** نود کافی است؛ حدود و سهمیه‌ی Apps Script روی خود اکانت است، پس چند نود روی یک اکانت ظرفیت اضافه نمی‌دهد.
3. **اسکن IP تمیز:** در بخش اسکنر، اسکن گوگل را بزنید و بهترین IP را اعمال کنید.
4. **اتصال:** VPN را روشن کنید و گواهی CA را (برای HTTPS) نصب کنید.
5. **تلگرام:** در تنظیمات اپ گزینه‌ی «پل HTTP به MTProto تلگرام (GAS)» را روشن کنید (به‌صورت پیش‌فرض خاموش است)، و اگر لازم بود پروکسی SOCKS5 تلگرام را روی `127.0.0.1:10808` بگذارید.

## محدودیت‌ها (بخوانید)

- هر درخواست یک اجرای کامل Apps Script است، پس تأخیر هر پیام تلگرام معمولاً بین حدود ۱.۸ تا ۵ ثانیه است. این سقف خود GAS است و از کد اپ پایین نمی‌آید.
- ترافیک UDP (مثل تماس صوتی و تصویری) و TCP خام پشتیبانی نمی‌شود. WebSocket و gRPC هم روی GAS ممکن نیست.
- هر اکانت گوگل سهمیه‌ی روزانه‌ی `UrlFetch` و سقف اجرای همزمان دارد. برای ظرفیت بیشتر باید اکانت بیشتری اضافه کنید.
- این اپ برای شرایط اضطراری است، نه جایگزین یک VPN سریع در روزهای عادی.

## ساخت از سورس

- Android Studio، `minSdk 24`، `targetSdk 36`، شناسه‌ی برنامه `com.azarakhsh.vpn`
- پروژه را با **Open** در Android Studio باز کنید و Sync کنید، بعد روی گوشی یا شبیه‌ساز اجرا کنید.
- نیازی به `GEMINI_API_KEY` نیست؛ فایل `.env.example` فقط یادگار قالب اولیه است.
- فایل `.github/workflows/build.yml` برای ساخت روی GitHub Actions آماده است.
- تاریخچه‌ی تغییرات: [CHANGELOG.md](CHANGELOG.md)

</div>

---

## English summary

**Azarakhsh** is an Android app built for **total Internet shutdowns in Iran**, i.e. when access to the international Internet is cut but Google services are still reachable. This `gas-only` build relays traffic exclusively through **Google Apps Script** (one deployment per Google account): no VPS, no Cloudflare Worker, no foreign server. It includes a local VPN, a clean-IP scanner for Google, and an HTTP-to-MTProto bridge so Telegram can work over a local SOCKS5 proxy (`127.0.0.1:10808`).

Known limits: each request is a full Apps Script execution (~1.8-5 s per Telegram message), no UDP / raw TCP / WebSocket / gRPC, and per-account Apps Script quotas apply. See [CHANGELOG.md](CHANGELOG.md) for details.
