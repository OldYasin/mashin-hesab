# v5 — less heat, same speed
- Warm WebSocket pool: single refill loop (was one loop per connection -> 368 sockets for 34 connections), target 4, stops topping up when idle, ping 30s.
- Iranian sites (.ir, digikala, aparat, divar, bale, eitaa...) go direct, not through the tunnel (fixes the 4s stalls + 7-byte TLS alert of api.abangateway.ir).
- DoH to 8.8.4.4 (no reply via Cloudflare) is remapped to 8.8.8.8 (same dns.google cert).
- Notification updated every 5s instead of every 1s.
- Noisy Xiaomi system apps excluded from the VPN (list: NOISY_SYSTEM_PACKAGES in ScriptVpnService.kt).

# v6 — better diagnostics
- PULSE line every 15s: connections/min, ws-opened vs discarded, warm/cold, domestic-direct, streams, speed, battery temp. WARN + flag (HOT, POOL-CHURN, NO-REPLY, WS-FAIL, FALLBACK) when something is off.
- Export header: device, Android version, protocol/settings, server list (no secrets).
- DIAGNOSIS: battery temp start/now/max, efficiency (ws-opened per connection), slow-connection list, new verdict hints (heat, pool churn, background app spam, slow sites).
- Per-connection lines: healthy = DEBUG, slow/proxy = INFO, no-reply / TLS-alert-only / odd end = WARN with a <<< marker.
- Log UI no longer re-copies 4000 rows on every line (max ~2.5 updates/s) -> less CPU. Export always uses a fresh snapshot.
- "Session stopped" is logged/saved once (was twice).

# v7 — logs inside Reports, cleaner app
- "لاگ‌ها" tab removed; Reports tab ("گزارش‌ها و لاگ") now has sections: جلسه‌ها | مشکل‌ها (WARN+ERR, with count) | اتصال‌ها (WS + PULSE) | DNS و VPN | سرور و IP | سیستم | تشخیص (DIAGNOSIS + verdict in-app, copy full report) | همه لاگ‌ها.
- Every log section: level filter, search, top-tag chips (tap to filter), copy/share/pause/clear.
- Removed: top-bar sync pill (had an always-running spin animation = constant redraws), offline-sync card, per-session "synced" label.
- Removed: compression chips, encryption+padding toggle (no effect on the WebSocket path), compression KPI/badges (always 0% on WebSocket).
