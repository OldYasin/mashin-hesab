package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.logging.LogCategory
import com.example.core.logging.LogLevel
import com.example.core.logging.TunnelLogEntry
import com.example.core.logging.TunnelLogger
import com.example.ui.components.AppIcons
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.RoseError
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LogsPanel(
    logs: List<TunnelLogEntry>,
    isPaused: Boolean,
    onTogglePause: () -> Unit,
    onClearLogs: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var showFilters by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedLevel by remember { mutableStateOf<LogLevel?>(null) }
    var selectedCategory by remember { mutableStateOf<LogCategory?>(null) }
    var expandedLogIds by remember { mutableStateOf<Set<Long>>(emptySet()) }

    val errorCount = remember(logs) { logs.count { it.level == LogLevel.ERROR } }
    val warnCount = remember(logs) { logs.count { it.level == LogLevel.WARN } }

    val filteredLogs = remember(logs, selectedLevel, selectedCategory, searchQuery) {
        val q = searchQuery.trim()
        logs.filter { entry ->
            (selectedLevel == null || entry.level == selectedLevel) &&
                (selectedCategory == null || entry.category == selectedCategory) &&
                (q.isEmpty() ||
                    entry.message.contains(q, ignoreCase = true) ||
                    entry.tag.contains(q, ignoreCase = true) ||
                    (entry.details?.contains(q, ignoreCase = true) == true))
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Compact 1-row toolbar
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp),
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LogStatBadge("${filteredLogs.size}/${logs.size}", CyanSecondary)
                        if (errorCount > 0) LogStatBadge("$errorCount خطا", RoseError)
                        if (warnCount > 0) LogStatBadge("$warnCount هشدار", AmberWarning)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { showFilters = !showFilters },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                AppIcons.Search,
                                contentDescription = "جستجو و فیلتر",
                                tint = if (showFilters || searchQuery.isNotEmpty() || selectedLevel != null || selectedCategory != null) {
                                    CyanSecondary
                                } else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = {
                                val exported = TunnelLogger.exportAsText(filteredLogs)
                                clipboard.setText(AnnotatedString(exported))
                                onShowMessage("${filteredLogs.size} خط لاگ کپی شد")
                            },
                            enabled = filteredLogs.isNotEmpty(),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(AppIcons.ContentCopy, contentDescription = "کپی لاگ", modifier = Modifier.size(17.dp))
                        }
                        IconButton(
                            onClick = {
                                val exported = TunnelLogger.exportAsText(filteredLogs)
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, "ScriptTunnel Logs")
                                    putExtra(Intent.EXTRA_TEXT, exported)
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "ارسال لاگ‌ها"))
                            },
                            enabled = filteredLogs.isNotEmpty(),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(AppIcons.Share, contentDescription = "اشتراک‌گذاری لاگ", modifier = Modifier.size(17.dp))
                        }
                        TextButton(
                            onClick = onTogglePause,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (isPaused) "ادامه" else "توقف",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                        IconButton(
                            onClick = onClearLogs,
                            enabled = logs.isNotEmpty(),
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("clear_logs_button")
                        ) {
                            Icon(AppIcons.Delete, contentDescription = "پاک کردن لاگ‌ها", tint = RoseError, modifier = Modifier.size(17.dp))
                        }
                    }
                }

                AnimatedVisibility(visible = showFilters) {
                    Column(
                        modifier = Modifier.padding(top = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("جستجو در پیام، تگ یا IP...", style = MaterialTheme.typography.bodySmall) },
                            leadingIcon = { Icon(AppIcons.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(AppIcons.Close, contentDescription = "پاک کردن جستجو", modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("logs_search_field")
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = selectedLevel == null && selectedCategory == null,
                                onClick = {
                                    selectedLevel = null
                                    selectedCategory = null
                                },
                                label = { Text("همه", style = MaterialTheme.typography.labelSmall) }
                            )
                            LogLevel.entries.forEach { lvl ->
                                FilterChip(
                                    selected = selectedLevel == lvl,
                                    onClick = { selectedLevel = if (selectedLevel == lvl) null else lvl },
                                    label = { Text(lvl.titleFa, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                            LogCategory.entries.forEach { cat ->
                                FilterChip(
                                    selected = selectedCategory == cat,
                                    onClick = { selectedCategory = if (selectedCategory == cat) null else cat },
                                    label = { Text(cat.badge, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (filteredLogs.isEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(AppIcons.Terminal, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(28.dp))
                    Text(
                        text = if (logs.isEmpty()) "هنوز لاگی ثبت نشده است" else "لاگی با این فیلتر پیدا نشد",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        text = "با تست سرور، اسکن آی‌پی یا اتصال تونل، لاگ‌ها این‌جا نمایش داده می‌شوند.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(filteredLogs, key = { it.id }) { entry ->
                    val isExpanded = entry.id in expandedLogIds
                    LogEntryCard(
                        entry = entry,
                        isExpanded = isExpanded,
                        onToggleExpand = {
                            expandedLogIds = if (isExpanded) expandedLogIds - entry.id else expandedLogIds + entry.id
                        },
                        onCopySingle = {
                            val text = TunnelLogger.exportAsText(listOf(entry))
                            clipboard.setText(AnnotatedString(text))
                            onShowMessage("لاگ کپی شد")
                        }
                    )
                }
            }
        }
    }
}

@Composable
internal fun LogStatBadge(text: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = color.copy(alpha = 0.15f)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
internal fun LogEntryCard(
    entry: TunnelLogEntry,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onCopySingle: () -> Unit
) {
    val levelColor = when (entry.level) {
        LogLevel.ERROR -> RoseError
        LogLevel.WARN -> AmberWarning
        LogLevel.INFO -> EmeraldPrimary
        LogLevel.DEBUG -> CyanSecondary
    }
    val hasDetails = !entry.details.isNullOrBlank()

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (hasDetails) Modifier.clickable { onToggleExpand() } else Modifier),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = 1.dp,
            color = if (entry.level == LogLevel.ERROR) RoseError.copy(alpha = 0.45f) else MaterialTheme.colorScheme.outline
        )
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = levelColor.copy(alpha = 0.16f)
                    ) {
                        Text(
                            text = entry.level.shortLabel,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold
                            ),
                            color = levelColor,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(
                                text = "${entry.category.badge}/${entry.tag}",
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.width(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text(
                            text = formatLogTime(entry.timestampMs),
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (hasDetails) {
                        Icon(
                            imageVector = if (isExpanded) AppIcons.ExpandLess else AppIcons.ExpandMore,
                            contentDescription = null,
                            tint = CyanSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Text(
                text = entry.message,
                style = MaterialTheme.typography.bodySmall,
                maxLines = if (isExpanded) Int.MAX_VALUE else 2,
                overflow = TextOverflow.Ellipsis
            )

            if (hasDetails) {
                AnimatedVisibility(visible = isExpanded) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                IconButton(
                                    onClick = onCopySingle,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        AppIcons.ContentCopy,
                                        contentDescription = "کپی جزئیات",
                                        modifier = Modifier.size(14.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                Text(
                                    text = entry.details.orEmpty(),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = JetBrainsMonoFontFamily,
                                        lineHeight = 15.sp
                                    ),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatLogTime(ms: Long): String {
    return SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(ms))
}
