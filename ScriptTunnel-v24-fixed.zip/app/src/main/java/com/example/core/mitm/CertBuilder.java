package com.example.core.mitm;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/**
 * Minimal X.509 v3 certificate writer (DER) using only the JDK, so the app needs no BouncyCastle.
 * Signs with SHA256withRSA. Used by {@link MitmCa} to create the local root CA and per-host leaf certs.
 */
public final class CertBuilder {
    private CertBuilder() {}

    private static final String OID_SHA256_RSA = "1.2.840.113549.1.1.11";
    private static final String OID_CN = "2.5.4.3";
    private static final String OID_SKI = "2.5.29.14";
    private static final String OID_KEY_USAGE = "2.5.29.15";
    private static final String OID_SAN = "2.5.29.17";
    private static final String OID_BASIC = "2.5.29.19";
    private static final String OID_AKI = "2.5.29.35";
    private static final String OID_EKU = "2.5.29.37";
    private static final String OID_SERVER_AUTH = "1.3.6.1.5.5.7.3.1";

    /**
     * @param subjectKey  public key of the certificate being issued
     * @param signerKey   private key of the issuer (the CA key; for a self-signed root = subject's own key)
     * @param issuerKey   public key of the issuer (used for the Authority Key Identifier)
     * @param sans        DNS names / IP literals for leaf certs (ignored for CA)
     */
    public static byte[] build(PublicKey subjectKey, String subjectCn, PrivateKey signerKey,
                               PublicKey issuerKey, String issuerCn, BigInteger serial,
                               Date notBefore, Date notAfter, boolean ca, List<String> sans)
            throws GeneralSecurityException {
        byte[] sigAlg = seq(oid(OID_SHA256_RSA), new byte[]{0x05, 0x00});

        ByteArrayOutputStream exts = new ByteArrayOutputStream();
        if (ca) {
            writeExt(exts, OID_BASIC, true, seq(new byte[]{0x01, 0x01, (byte) 0xFF}));
            writeExt(exts, OID_KEY_USAGE, true, bitString(new byte[]{0x06}, 1)); // keyCertSign | cRLSign
        } else {
            writeExt(exts, OID_BASIC, true, seq());
            writeExt(exts, OID_KEY_USAGE, true, bitString(new byte[]{(byte) 0xA0}, 5)); // digitalSignature | keyEncipherment
            writeExt(exts, OID_EKU, false, seq(oid(OID_SERVER_AUTH)));
            if (sans != null && !sans.isEmpty()) {
                ByteArrayOutputStream names = new ByteArrayOutputStream();
                for (String s : sans) {
                    byte[] ip = ipLiteral(s);
                    if (ip != null) writeBytes(names, tlv(0x87, ip));
                    else writeBytes(names, tlv(0x82, s.getBytes(StandardCharsets.US_ASCII)));
                }
                writeExt(exts, OID_SAN, false, tlv(0x30, names.toByteArray()));
            }
        }
        byte[] subjectKeyId = keyId(subjectKey);
        writeExt(exts, OID_SKI, false, tlv(0x04, subjectKeyId));
        if (!ca) {
            writeExt(exts, OID_AKI, false, seq(tlv(0x80, keyId(issuerKey))));
        }

        byte[] tbs = seq(
                tlv(0xA0, tlv(0x02, new byte[]{0x02})),                 // version v3
                tlv(0x02, serial.toByteArray()),
                sigAlg,
                name(issuerCn),
                seq(time(notBefore), time(notAfter)),
                name(subjectCn),
                subjectKey.getEncoded(),                                  // SubjectPublicKeyInfo
                tlv(0xA3, tlv(0x30, exts.toByteArray()))
        );

        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initSign(signerKey);
        sig.update(tbs);
        byte[] signature = sig.sign();

        byte[] sigBits = new byte[signature.length + 1];
        System.arraycopy(signature, 0, sigBits, 1, signature.length);
        return seq(tbs, sigAlg, tlv(0x03, sigBits));
    }

    // ---- DER helpers -------------------------------------------------------------------------

    private static byte[] keyId(PublicKey k) throws GeneralSecurityException {
        return MessageDigest.getInstance("SHA-1").digest(k.getEncoded());
    }

    private static byte[] tlv(int tag, byte[] content) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(tag);
        int n = content.length;
        if (n < 0x80) {
            o.write(n);
        } else if (n < 0x100) {
            o.write(0x81); o.write(n);
        } else if (n < 0x10000) {
            o.write(0x82); o.write(n >> 8); o.write(n);
        } else {
            o.write(0x83); o.write(n >> 16); o.write(n >> 8); o.write(n);
        }
        o.write(content, 0, content.length);
        return o.toByteArray();
    }

    private static byte[] seq(byte[]... parts) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (byte[] p : parts) o.write(p, 0, p.length);
        return tlv(0x30, o.toByteArray());
    }

    private static byte[] bitString(byte[] bits, int unused) {
        byte[] c = new byte[bits.length + 1];
        c[0] = (byte) unused;
        System.arraycopy(bits, 0, c, 1, bits.length);
        return tlv(0x03, c);
    }

    private static byte[] name(String cn) {
        byte[] atv = seq(oid(OID_CN), tlv(0x0C, cn.getBytes(StandardCharsets.UTF_8)));
        return seq(tlv(0x31, atv));
    }

    private static byte[] time(Date d) {
        SimpleDateFormat f = new SimpleDateFormat("yyMMddHHmmss'Z'");
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return tlv(0x17, f.format(d).getBytes(StandardCharsets.US_ASCII)); // UTCTime (valid through 2049)
    }

    private static byte[] oid(String dotted) {
        String[] p = dotted.split("\\.");
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(Integer.parseInt(p[0]) * 40 + Integer.parseInt(p[1]));
        for (int i = 2; i < p.length; i++) {
            long v = Long.parseLong(p[i]);
            int shift = 0;
            while ((v >> (shift + 7)) > 0) shift += 7;
            for (; shift > 0; shift -= 7) o.write((int) (((v >> shift) & 0x7F) | 0x80));
            o.write((int) (v & 0x7F));
        }
        return tlv(0x06, o.toByteArray());
    }

    private static void writeExt(ByteArrayOutputStream o, String oid, boolean critical, byte[] value) {
        byte[] e = critical
                ? seq(oid(oid), new byte[]{0x01, 0x01, (byte) 0xFF}, tlv(0x04, value))
                : seq(oid(oid), tlv(0x04, value));
        writeBytes(o, e);
    }

    private static void writeBytes(ByteArrayOutputStream o, byte[] b) {
        o.write(b, 0, b.length);
    }

    /** Returns the raw address bytes if s is an IPv4/IPv6 literal, else null (never does DNS). */
    private static byte[] ipLiteral(String s) {
        if (s.matches("\\d{1,3}(\\.\\d{1,3}){3}")) {
            String[] p = s.split("\\.");
            byte[] b = new byte[4];
            for (int i = 0; i < 4; i++) {
                int v = Integer.parseInt(p[i]);
                if (v > 255) return null;
                b[i] = (byte) v;
            }
            return b;
        }
        if (s.indexOf(':') >= 0) {
            try {
                return java.net.InetAddress.getByName(s).getAddress();
            } catch (Exception e) {
                return null;
            }
        }
        return null;
    }
}
