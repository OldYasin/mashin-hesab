package com.example.core.logging

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Lightweight aggregator so the exported log starts with a readable DIAGNOSIS block
 * (timings, failure counters, per-ProxyIP health, automatic verdict) instead of
 * thousands of noisy lines.
 */
object TunnelStats {

    @Volatile private var startMs = System.currentTimeMillis()
    private val counters = ConcurrentHashMap<String, AtomicInteger>()
    private val samples = ConcurrentHashMap<String, MutableList<Long>>()
    private const val MAX_SAMPLES = 3000
    private val gaugeFirst = ConcurrentHashMap<String, Double>()
    private val gaugeLast = ConcurrentHashMap<String, Double>()
    private val gaugeMax = ConcurrentHashMap<String, Double>()

    /** Records a measured value over time (battery temperature, ...): first / last / max are reported. */
    fun gauge(name: String, v: Double) {
        gaugeFirst.putIfAbsent(name, v)
        gaugeLast[name] = v
        gaugeMax.merge(name, v) { a, b -> maxOf(a, b) }
    }

    fun reset() {
        startMs = System.currentTimeMillis()
        counters.clear()
        samples.clear()
        gaugeFirst.clear(); gaugeLast.clear(); gaugeMax.clear()
    }

    fun inc(key: String): Int = counters.getOrPut(key) { AtomicInteger(0) }.incrementAndGet()

    fun add(key: String, n: Int) { if (n > 0) counters.getOrPut(key) { AtomicInteger(0) }.addAndGet(n) }

    fun get(key: String): Int = counters[key]?.get() ?: 0

    fun sample(name: String, ms: Long) {
        if (ms < 0) return
        val list = samples.getOrPut(name) { java.util.Collections.synchronizedList(ArrayList()) }
        synchronized(list) {
            if (list.size >= MAX_SAMPLES) list.removeAt(0)
            list.add(ms)
        }
    }

    private fun pct(sorted: List<Long>, p: Double): Long =
        if (sorted.isEmpty()) 0L else sorted[((sorted.size - 1) * p).toInt()]

    private fun timing(name: String, label: String): String {
        val list = samples[name] ?: return "$label: n=0"
        val s = synchronized(list) { list.sorted() }
        if (s.isEmpty()) return "$label: n=0"
        return "$label: n=${s.size} p50=${pct(s, 0.5)}ms p90=${pct(s, 0.9)}ms max=${s.last()}ms"
    }

    private fun top(prefix: String, limit: Int = 6): List<Pair<String, Int>> =
        counters.entries.filter { it.key.startsWith(prefix) }
            .map { it.key.removePrefix(prefix) to it.value.get() }
            .sortedByDescending { it.second }
            .take(limit)

    private fun med(name: String): Long {
        val list = samples[name] ?: return 0L
        val s = synchronized(list) { list.sorted() }
        return pct(s, 0.5)
    }

    fun report(): String {
        val sb = StringBuilder()
        val secs = (System.currentTimeMillis() - startMs) / 1000
        val total = get("conn.total")
        val ok = get("conn.ok")
        val fallback = get("conn.fallback")
        val zero = get("conn.zeroRx")
        val warm = get("pool.warm")
        val cold = get("pool.cold")
        val viaProxy = get("route.proxy")
        val direct = get("route.direct")

        sb.appendLine("##### DIAGNOSIS (since session start, ${secs}s) #####")
        sb.appendLine("Connections: total=$total ok=$ok fallback-to-direct=$fallback zero-reply=$zero ws-failures=${get("ws.fail")}")
        sb.appendLine("Requests: GAS(invocations=${get("gas.invocations")} urlFetch=${get("gas.urlFetches")} saved=${get("gas.saved")} failed=${get("gas.failed")}) | CF(ws=${get("cf.requests")} warm=$warm fail=${get("ws.fail")})")
        sb.appendLine("Pool: warm-hit=$warm cold=$cold discarded=${get("pool.discard")} ws-opened=${get("ws.opened")}")
        sb.appendLine("Route (worker->dest): direct=$direct via-ProxyIP=$viaProxy")
        val opened = get("ws.opened")
        val ratio = if (total > 0) opened.toFloat() / total else 0f
        sb.appendLine("Upload: peak-backlog=${(gaugeMax["up.backlogKB"] ?: 0.0).toInt()}KB | peak-ws-queue=${(gaugeMax["up.wsQueueKB"] ?: 0.0).toInt()}KB | window-drops=${get("up.windowDrop")}")
        sb.appendLine("Network/User: underlying-network-changes=${get("net.change")} | user-marks=${get("user.mark")}")
        sb.appendLine("Efficiency: ws-opened per connection = ${"%.1f".format(ratio)} (healthy <= 1.5) | domestic direct-bypass = ${get("bypass.direct")} | slow(>2s) = ${top("slow:", 99).sumOf { it.second }}")
        sb.appendLine(timing("t.open", "WS open (cold only)  "))
        sb.appendLine(timing("t.connect", "Worker->dest connect "))
        sb.appendLine(timing("t.ttfb", "First reply after send"))
        sb.appendLine(timing("t.total", "Connection lifetime   "))
        sb.appendLine("UDP/QUIC answered with ICMP-unreachable: ${get("udp.icmp")} | filtered-DNS drops: ${get("drop.filtered")} | DoH answers: ${get("dns.ok")} (poisoned blocked: ${get("dns.poison")})")

        val tFirst = gaugeFirst["bat.temp"]
        if (tFirst != null) {
            sb.appendLine("Device: battery temp start=${"%.1f".format(tFirst)}C now=${"%.1f".format(gaugeLast["bat.temp"] ?: tFirst)}C max=${"%.1f".format(gaugeMax["bat.temp"] ?: tFirst)}C | level now=${(gaugeLast["bat.level"] ?: 0.0).toInt()}% | peak-streams=${(gaugeMax["streams"] ?: 0.0).toInt()} | peak-conn/min=${(gaugeMax["conn.perMin"] ?: 0.0).toInt()}")
        }
        val slowSites = top("slow:", 6)
        if (slowSites.isNotEmpty()) {
            sb.appendLine("Slow connections (connect or first reply > 2s):")
            slowSites.forEach { sb.appendLine("  x${it.second}  ${it.first}") }
        }

        val proxies = top("proxy.ok:", 8)
        val deadProxies = top("proxy.dead:", 8)
        if (proxies.isNotEmpty() || deadProxies.isNotEmpty()) {
            sb.appendLine("ProxyIP health:")
            proxies.forEach { sb.appendLine("  OK   x${it.second}  ${it.first}") }
            deadProxies.forEach { sb.appendLine("  DEAD x${it.second}  ${it.first}  (connected but no reply)") }
        }
        val directFails = top("direct.fail:", 5)
        if (directFails.isNotEmpty()) {
            sb.appendLine("Direct connect failures (worker could not reach dest, ProxyIP used):")
            directFails.forEach { sb.appendLine("  x${it.second}  ${it.first}") }
        }
        val wsErrs = top("ws.err:", 5)
        if (wsErrs.isNotEmpty()) {
            sb.appendLine("WebSocket errors:")
            wsErrs.forEach { sb.appendLine("  x${it.second}  ${it.first}") }
        }
        val wErrs = top("worker.err:", 5)
        if (wErrs.isNotEmpty()) {
            sb.appendLine("Worker errors:")
            wErrs.forEach { sb.appendLine("  x${it.second}  ${it.first}") }
        }
        val zeroDst = top("zero.", 6)
        if (zeroDst.isNotEmpty()) {
            sb.appendLine("Destinations that sent NO reply (TX>0, RX=0):")
            zeroDst.forEach { sb.appendLine("  x${it.second}  ${it.first}") }
        }
        val sites = top("site:", 10)
        if (sites.isNotEmpty()) {
            sb.appendLine("Top sites (SNI): ok=got reply, noreply=sent but nothing came back")
            sites.forEach { sb.appendLine("  x${it.second}  ${it.first}  ok=${get("siteRx:" + it.first)} noreply=${get("siteNoRx:" + it.first)}") }
        }
        val apps = top("app:", 8)
        if (apps.isNotEmpty()) {
            sb.appendLine("Top apps (WS connections | RX | TX | noreply | ws-fail):")
            apps.forEach {
                sb.appendLine("  x${it.second}  ${it.first}  rx=${get("appRxKB:" + it.first)}KB tx=${get("appTxKB:" + it.first)}KB noreply=${get("appZero:" + it.first)} fail=${get("appFail:" + it.first)}")
            }
        }
        val stalls = top("stall:", 6)
        if (stalls.isNotEmpty() || get("stall.abort") > 0) {
            sb.appendLine("Stalls (sent data, no reply for >=6s): total=${get("stall.total")} aborted-while-waiting=${get("stall.abort")} | ${timing("t.stall", "recovered after")}")
            stalls.forEach { sb.appendLine("  x${it.second}  ${it.first}") }
        }
        sb.appendLine("Geo-forced (Google/Gemini/AI via foreign ProxyIP): ${get("geo.forced")}")
        val alerts = top("tls.alert:", 6)
        if (alerts.isNotEmpty()) {
            sb.appendLine("Dest answered with only a TLS alert (RX<=12B) = wrong/blocked path:")
            alerts.forEach { sb.appendLine("  x${it.second}  ${it.first}") }
        }
        val ends = top("end.", 6)
        if (ends.isNotEmpty()) {
            sb.appendLine("Connection end reasons: " + ends.joinToString(", ") { "${it.first}=${it.second}" })
        }

        sb.appendLine("--- VERDICT ---")
        val hints = mutableListOf<String>()
        if (total == 0) hints += "هنوز اتصالی ثبت نشده؛ بعد از چند دقیقه استفاده، لاگ رو دوباره Export کن."
        if (total >= 10 && ratio > 2.5f) hints += "گرمای گوشی/باتری: به ازای هر اتصال ${"%.1f".format(ratio)} وب‌سوکت باز شده (سالم ≤ 1.5)؛ استخر آماده بیش از حد پر و دور ریخته می‌شه."
        val tMax = gaugeMax["bat.temp"]
        if (tMax != null && tMax >= 42.0) {
            val startTemp = gaugeFirst["bat.temp"] ?: tMax
            val hotBusy = get("pulse.hotBusy")
            val hotIdle = get("pulse.hotIdle")
            hints += when {
                hotBusy > 0 -> "دمای باتری به ${"%.1f".format(tMax)}°C رسید و ${hotBusy} بار همزمان بار تونل بالا بود؛ خطوط PULSE با HOT رو ببین تا بفهمی کی اتصال‌ها زیاد شده."
                startTemp >= 42.0 -> "دمای گوشی از قبل از شروع تونل ${"%.1f".format(startTemp)}°C بوده و بار تونل کم بوده (${hotIdle} پالس)؛ گرما احتمالاً از چیز دیگه‌ست (صفحه روشن، شارژ، برنامه‌های دیگه)، نه تونل."
                else -> "دمای باتری به ${"%.1f".format(tMax)}°C رسید ولی بار تونل کم بوده؛ گرما احتمالاً از تونل نیست."
            }
        }
        if (tMax != null && tFirst != null && tMax - tFirst >= 4.0) hints += "دمای باتری توی همین جلسه ${"%.1f".format(tMax - tFirst)} درجه بالا رفته؛ اگه در حال شارژ بودی اون هم اثر داره."
        if ((gaugeMax["conn.perMin"] ?: 0.0) > 150.0) hints += "اتصال در دقیقه خیلی زیاده (${(gaugeMax["conn.perMin"] ?: 0.0).toInt()}): یه اپ پس‌زمینه (آنالیتیکس/تبلیغ) مدام اتصال می‌سازه؛ SNIهای پرتکرار بخش Top sites رو ببین."
        if (slowSites.isNotEmpty()) hints += "اتصال‌های کند (>۲ثانیه) ثبت شد (${slowSites.sumOf { it.second }}): بخش Slow connections رو ببین؛ اگه سایت ایرانیه باید bypass بشه."
        if (total > 0 && fallback * 100 / total >= 5) hints += "فال‌بک مستقیم زیاده (${fallback}/$total): ورکر یا WebSocket وصل نمی‌شه؛ IP واقعی لو می‌ره. ورژن ورکر و کلین‌آی‌پی رو چک کن."
        if (get("ws.fail") > 0) hints += "WebSocket خطا داره (${get("ws.fail")}): کلین‌آی‌پی کلودفلر یا اینترنت ناپایداره؛ یه کلین‌آی‌پی دیگه امتحان کن."
        if (cold > 0 && med("t.open") > 700) hints += "باز شدن WebSocket کنده (p50=${med("t.open")}ms): کلین‌آی‌پی کلودفلر ضعیفه، اسکن مجدد بزن."
        if (warm + cold > 5 && warm * 100 / (warm + cold) < 50) hints += "استخر WebSocket آماده کم می‌آره (warm=${warm}/${warm + cold}): تعداد اتصال‌ها بیشتر از سرعت پر شدن استخره."
        if (med("t.connect") > 800) hints += "ورکر دیر به مقصد وصل می‌شه (p50=${med("t.connect")}ms): معمولاً ProxyIP کنده؛ کشور دیگه یا ProxyIP دلخواه بذار."
        if (med("t.ttfb") > 1500) hints += "اولین جواب مقصد دیر میاد (p50=${med("t.ttfb")}ms): مسیر ورکر←مقصد کنده."
        if (total > 10 && zero * 100 / total >= 12) hints += "اتصال بی‌جواب زیاده (${zero}/$total): ProxyIP مرده یا مقصد از ورکر بلاکه؛ بخش ProxyIP health رو ببین."
        if (deadProxies.isNotEmpty()) hints += "ProxyIPهای مرده: " + deadProxies.joinToString { it.first } + " — اینا رو توی فیلد دلخواه ننویس."
        if (viaProxy + direct > 0 && viaProxy * 100 / (viaProxy + direct) > 40) hints += "بیشتر ترافیک از ProxyIP رد می‌شه (${viaProxy}/${viaProxy + direct}): طبیعیه اگه سایت‌ها پشت کلودفلرن، ولی ProxyIP سریع‌تر تأثیر مستقیم داره."
        if (alerts.isNotEmpty()) hints += "جواب فقط ۷ بایت (TLS alert) یعنی اون مسیر اصلاً به مقصد نمی‌رسه (ProxyIP فقط به سایت‌های پشت کلودفلر وصل میشه، نه گوگل)."
        if (false && get("geo.forced") == 0 && total > 0) hints += "هیچ اتصال گوگل/جمنای شناسایی نشد (SNI دیده نشد). اگه جمنای رو باز کردی و اینجا خالیه، مرورگر از DoH/QUIC/ECH استفاده می‌کنه؛ QUIC و Secure-DNS مرورگر رو خاموش کن."
        if (false && get("geo.forced") > 0) hints += "ترافیک گوگل/AI از ProxyIP خارجی رفت (${get("geo.forced")} اتصال)؛ اگه هنوز جمنای بلاکه ProxyIP کشور دیگه‌ای (مثلاً DE/NL) توی تنظیمات انتخاب کن."
        if (get("stall.abort") > 0) hints += "${get("stall.abort")} اتصال وسط انتظار جواب بسته شد (STALL-ABORT)؛ خطوط STALL-ABORT و NET دور همون ساعت رو ببین (قطع شبکه یا مسیر ورکر←مقصد)."
        else if (get("stall.total") > 5) hints += "${get("stall.total")} بار اتصال بیشتر از ۶ ثانیه منتظر جواب موند ولی جواب رسید؛ مسیر کنده/ناپایداره (خطوط STALL / STALL-END)."
        if (get("net.change") > 3) hints += "شبکه زیرین ${get("net.change")} بار تغییر کرد (وای‌فای/دیتا/افت اعتبار)؛ قطعی‌ها احتمالاً با خطوط NET هم‌زمانن."
        if (hints.isEmpty() && total > 0) hints += "مشکل واضحی دیده نشد؛ اگه هنوز کنده، زمان‌ها رو با p50/p90 بالا مقایسه کن."
        hints.forEach { sb.appendLine("* $it") }
        sb.appendLine("#####################################################")
        return sb.toString()
    }
}
