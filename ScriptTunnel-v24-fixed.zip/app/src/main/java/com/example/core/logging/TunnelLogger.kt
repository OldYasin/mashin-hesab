package com.example.core.logging

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

enum class LogLevel(val shortLabel: String, val titleFa: String) {
    DEBUG("DBG", "دیباگ"),
    INFO("INF", "اطلاعات"),
    WARN("WRN", "هشدار"),
    ERROR("ERR", "خطا")
}

enum class LogCategory(val badge: String, val titleFa: String) {
    GAS("GAS", "گوگل اسکریپت"),
    TLS_IP("TLS", "اسکن و SSL"),
    CF_WS("WS", "کلودفلر"),
    DNS_DOH("DOH", "دی‌ان‌اس"),
    VPN("VPN", "سرویس VPN"),
    SYNC("SYNC", "همگام‌سازی"),
    SYSTEM("SYS", "سیستم")
}

data class TunnelLogEntry(
    val id: Long,
    val timestampMs: Long,
    val level: LogLevel,
    val category: LogCategory,
    val tag: String,
    val message: String,
    val details: String? = null
)

object TunnelLogger {

    private const val MAX_ENTRIES = 4000
    private const val DEDUP_WINDOW_MS = 5_000L
    @Volatile var dedupEnabled: Boolean = false
    private val idGen = AtomicLong(1L)
    private val lock = Any()
    private val buffer = ArrayDeque<TunnelLogEntry>(MAX_ENTRIES)
    private val recentDedup = HashMap<String, Pair<Long, Int>>()

    // Publishing a full copy of the buffer (up to 4000 rows) to the UI on EVERY line burned CPU
    // (a busy tunnel logs dozens of lines per second). Now at most ~2.5 publishes per second.
    private const val PUBLISH_INTERVAL_MS = 400L
    @Volatile private var lastPublishMs = 0L
    @Volatile private var publishScheduled = false
    private val flusher = java.util.concurrent.Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "log-flush").apply { isDaemon = true }
    }

    /** Device/app/settings header printed at the top of every export (set when a session starts). */
    @Volatile var sessionContext: String = ""

    private val _logs = MutableStateFlow<List<TunnelLogEntry>>(emptyList())
    val logs: StateFlow<List<TunnelLogEntry>> = _logs.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    fun togglePause() {
        val next = !_isPaused.value
        _isPaused.value = next
        if (!next) {
            synchronized(lock) {
                _logs.value = buffer.reversed()
            }
        }
    }

    fun log(
        level: LogLevel,
        category: LogCategory,
        tag: String,
        message: String,
        details: String? = null
    ) {
        val now = System.currentTimeMillis()
        val dedupKey = "${level.name}|${category.name}|$tag|$message"
        synchronized(lock) {
            val prev = if (dedupEnabled) recentDedup[dedupKey] else null
            if (dedupEnabled && prev != null && now - prev.first < DEDUP_WINDOW_MS) {
                recentDedup[dedupKey] = prev.first to (prev.second + 1)
                return
            }
            val suppressedCount = prev?.second ?: 0
            if (dedupEnabled) recentDedup[dedupKey] = now to 0
            if (recentDedup.size > 512) {
                val cutoff = now - DEDUP_WINDOW_MS * 2
                recentDedup.entries.removeAll { it.value.first < cutoff }
            }
            val finalDetails = buildString {
                if (!details.isNullOrBlank()) append(details)
                if (suppressedCount > 0) {
                    if (isNotEmpty()) append(" | ")
                    append("×$suppressedCount تکرار قبلی خلاصه شد")
                }
            }.ifBlank { null }
            val entry = TunnelLogEntry(
                id = idGen.getAndIncrement(),
                timestampMs = now,
                level = level,
                category = category,
                tag = tag,
                message = message,
                details = finalDetails
            )
            if (buffer.size >= MAX_ENTRIES) {
                buffer.removeFirst()
            }
            buffer.addLast(entry)
            publishLocked()
        }
    }

    private fun publishLocked() {
        if (_isPaused.value) return
        val now = System.currentTimeMillis()
        if (now - lastPublishMs >= PUBLISH_INTERVAL_MS) {
            lastPublishMs = now
            _logs.value = buffer.reversed()
        } else if (!publishScheduled) {
            publishScheduled = true
            flusher.schedule({
                synchronized(lock) {
                    publishScheduled = false
                    lastPublishMs = System.currentTimeMillis()
                    if (!_isPaused.value) _logs.value = buffer.reversed()
                }
            }, PUBLISH_INTERVAL_MS, java.util.concurrent.TimeUnit.MILLISECONDS)
        }
    }

    /** Always-fresh copy (newest first) for export, independent of the throttled UI flow. */
    fun snapshot(): List<TunnelLogEntry> = synchronized(lock) { buffer.reversed() }

    fun d(category: LogCategory, tag: String, message: String, details: String? = null) =
        log(LogLevel.DEBUG, category, tag, message, details)

    fun i(category: LogCategory, tag: String, message: String, details: String? = null) =
        log(LogLevel.INFO, category, tag, message, details)

    fun w(category: LogCategory, tag: String, message: String, details: String? = null) =
        log(LogLevel.WARN, category, tag, message, details)

    fun e(category: LogCategory, tag: String, message: String, details: String? = null) =
        log(LogLevel.ERROR, category, tag, message, details)

    fun clear() {
        synchronized(lock) {
            buffer.clear()
            _logs.value = emptyList()
        }
    }

    fun exportAsText(entries: List<TunnelLogEntry> = snapshot()): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
        val errCount = entries.count { it.level == LogLevel.ERROR }
        val warnCount = entries.count { it.level == LogLevel.WARN }
        val infoCount = entries.count { it.level == LogLevel.INFO }
        val dbgCount = entries.count { it.level == LogLevel.DEBUG }

        val sb = StringBuilder()
        sb.appendLine("=== ScriptTunnel Diagnostic Logs ===")
        sb.appendLine("Exported: ${fmt.format(Date())}")
        sb.appendLine("Summary : Total=${entries.size} | ERR=$errCount | WRN=$warnCount | INF=$infoCount | DBG=$dbgCount")
        sb.appendLine("====================================")
        if (sessionContext.isNotBlank()) {
            sb.appendLine(sessionContext)
            sb.appendLine("====================================")
        }
        sb.append(TunnelStats.report())
        sb.appendLine()
        entries.reversed().forEach { entry ->
            sb.append("[${fmt.format(Date(entry.timestampMs))}] ")
            sb.append("[${entry.level.shortLabel}] ")
            sb.append("[${entry.category.badge}/${entry.tag}] ")
            sb.appendLine(entry.message)
            if (!entry.details.isNullOrBlank()) {
                entry.details.lines().forEach { line ->
                    sb.appendLine("    | $line")
                }
            }
        }
        return sb.toString()
    }
}
