package com.example.core

import android.content.Context
import com.example.core.mitm.MitmCa
import com.example.data.local.AppDatabase
import com.example.data.preferences.SettingsRepository
import com.example.data.repository.TunnelRepository
import com.example.network.NetworkSyncManager
import com.example.network.ParallelTunnelEngine

class AppContainer private constructor(context: Context) {
    private val appContext = context.applicationContext

    val database: AppDatabase = AppDatabase.getInstance(appContext)
    val tunnelRepository: TunnelRepository = TunnelRepository(database)
    val settingsRepository: SettingsRepository = SettingsRepository(appContext)
    val mitmCa: MitmCa by lazy { MitmCa(appContext) }
    val tunnelEngine: ParallelTunnelEngine = ParallelTunnelEngine()
    val networkSyncManager: NetworkSyncManager = NetworkSyncManager(
        context = appContext,
        repository = tunnelRepository,
        settingsRepository = settingsRepository,
        engine = tunnelEngine
    ).apply {
        startObserving()
    }

    companion object {
        @Volatile
        private var instance: AppContainer? = null

        fun get(context: Context): AppContainer {
            return instance ?: synchronized(this) {
                instance ?: AppContainer(context).also { instance = it }
            }
        }
    }
}
