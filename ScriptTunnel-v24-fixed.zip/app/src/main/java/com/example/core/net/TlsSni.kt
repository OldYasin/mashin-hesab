package com.example.core.net

/** Reads the server name (SNI) out of a TLS ClientHello without touching the payload. */
object TlsSni {
    fun parse(d: ByteArray): String? = runCatching {
        if (d.size < 48 || d[0].toInt() != 0x16 || d[5].toInt() != 0x01) return null
        var p = 5 + 4 + 2 + 32                       // record hdr + handshake hdr + version + random
        p += 1 + (d[p].toInt() and 0xFF)             // session id
        p += 2 + (u16(d, p))                         // cipher suites
        p += 1 + (d[p].toInt() and 0xFF)             // compression
        val extEnd = p + 2 + u16(d, p); p += 2
        while (p + 4 <= extEnd && p + 4 <= d.size) {
            val type = u16(d, p); val len = u16(d, p + 2); p += 4
            if (type == 0) {                         // server_name
                var q = p + 2
                if (q + 3 > d.size) return null
                val nameLen = u16(d, q + 1); q += 3
                if (q + nameLen > d.size) return null
                return String(d, q, nameLen, Charsets.US_ASCII).lowercase()
            }
            p += len
        }
        null
    }.getOrNull()

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
}

/**
 * Sites that refuse Cloudflare-edge egress IPs near Iran ("not supported in your country").
 * These are sent through a ProxyIP (real foreign exit) instead of the worker's own IP.
 */
object GeoRoute {
    private val suffixes = listOf(
        "gemini.google.com", "bard.google.com", "aistudio.google.com", "makersuite.google.com",
        "generativelanguage.googleapis.com", "clients6.google.com", "accounts.google.com",
        "google.com", "googleapis.com", "gstatic.com", "googleusercontent.com", "ggpht.com",
        "notebooklm.google", "labs.google", "deepmind.google", "openai.com", "chatgpt.com", "oaistatic.com"
    )
    /** OFF: ProxyIP hosts are Cloudflare machines, they cannot relay to Google (TLS alert, RX=7B). */
    const val ENABLED = false
    fun needsForeignExit(host: String?): Boolean {
        if (!ENABLED || host.isNullOrEmpty()) return false
        return suffixes.any { host == it || host.endsWith(".$it") }
    }
}

/**
 * Domestic (Iranian) sites: they are reachable straight from the phone and often REJECT foreign
 * egress IPs (e.g. api.abangateway.ir waited 4s then returned a 7-byte TLS alert via the worker).
 * They skip the tunnel completely: faster, and no WebSocket/CPU spent on them.
 */
object DirectRoute {
    private val suffixes = listOf(
        ".ir", "digikala.com", "aparat.com", "divar.io", "bale.ai", "eitaa.com",
        "shatel.com", "torob.com", "filimo.com", "blubank.com", "rubika.ir",
        "snapp.ir", "shaparak.ir", "tapsi.ir", "irancell.ir", "mci.ir"
    )

    // Major Iranian ISP, datacenter (Arvan/AbrArvan, Afranet, ParsOnline, Shatel, Asiatech, MCI/Irancell) & banking CIDR ranges
    private val iranCidrs: List<Pair<Int, Int>> = listOf(
        "5.22.0.0/16", "5.160.0.0/16", "31.24.0.0/16", "31.56.0.0/14",
        "37.156.0.0/16", "37.255.0.0/16", "46.209.0.0/16", "46.224.0.0/15",
        "78.38.0.0/15", "79.127.0.0/16", "85.15.0.0/16", "89.165.0.0/16",
        "91.98.0.0/15", "94.182.0.0/15", "185.105.0.0/16", "185.143.232.0/22",
        "188.158.0.0/15", "194.225.0.0/16", "217.218.0.0/15"
    ).mapNotNull { parseCidr(it) }

    private fun parseCidr(cidr: String): Pair<Int, Int>? {
        val parts = cidr.split('/')
        if (parts.size != 2) return null
        val ip = ipv4ToInt(parts[0]) ?: return null
        val prefix = parts[1].toIntOrNull()?.coerceIn(0, 32) ?: return null
        val mask = if (prefix == 0) 0 else (-1 shl (32 - prefix))
        return (ip and mask) to mask
    }

    private fun ipv4ToInt(ip: String): Int? {
        val p = ip.split('.')
        if (p.size != 4) return null
        var acc = 0
        for (s in p) {
            val v = s.toIntOrNull() ?: return null
            if (v !in 0..255) return null
            acc = (acc shl 8) or v
        }
        return acc
    }

    fun isIranianIp(ip: String?): Boolean {
        if (ip.isNullOrBlank()) return false
        val ipInt = ipv4ToInt(ip.trim()) ?: return false
        return iranCidrs.any { (net, mask) -> (ipInt and mask) == net }
    }

    fun shouldGoDirect(host: String?, dstIp: String? = null): Boolean {
        if (!host.isNullOrEmpty()) {
            val h = host.lowercase()
            if (suffixes.any { sfx ->
                    if (sfx.startsWith(".")) h.endsWith(sfx) else (h == sfx || h.endsWith(".$sfx"))
                }
            ) return true
        }
        return isIranianIp(dstIp)
    }
}
