package com.example.core.mitm

import java.io.ByteArrayOutputStream

/**
 * Minimal RFC 7541 HPACK decoder (with full Huffman + dynamic table) and encoder.
 */
class HpackCodec(private var maxDynamicBytes: Int = 4096) {

    private val dynamicTable = ArrayDeque<Pair<String, String>>()
    private var dynamicBytes = 0

    fun decode(block: ByteArray): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        var pos = 0
        while (pos < block.size) {
            val b = block[pos].toInt() and 0xFF
            when {
                (b and 0x80) != 0 -> {
                    val (idx, nextPos) = readInt(block, pos, 7)
                    pos = nextPos
                    if (idx > 0) out.add(getEntry(idx))
                }
                (b and 0xC0) == 0x40 -> {
                    val (idx, p1) = readInt(block, pos, 6)
                    val (name, p2) = if (idx > 0) getEntry(idx).first to p1 else readString(block, p1)
                    val (value, p3) = readString(block, p2)
                    pos = p3
                    val entry = name to value
                    out.add(entry)
                    addDynamic(entry)
                }
                (b and 0xE0) == 0x20 -> {
                    val (newMax, nextPos) = readInt(block, pos, 5)
                    pos = nextPos
                    maxDynamicBytes = minOf(newMax, 4096)
                    evictToFit()
                }
                else -> {
                    val (idx, p1) = readInt(block, pos, 4)
                    val (name, p2) = if (idx > 0) getEntry(idx).first to p1 else readString(block, p1)
                    val (value, p3) = readString(block, p2)
                    pos = p3
                    out.add(name to value)
                }
            }
        }
        return out
    }

    private fun getEntry(index: Int): Pair<String, String> {
        if (index <= STATIC_TABLE.size) return STATIC_TABLE[index - 1]
        val dynIdx = index - STATIC_TABLE.size - 1
        return if (dynIdx in dynamicTable.indices) dynamicTable[dynIdx] else ("" to "")
    }

    private fun addDynamic(entry: Pair<String, String>) {
        val size = entry.first.length + entry.second.length + 32
        if (size > maxDynamicBytes) {
            dynamicTable.clear()
            dynamicBytes = 0
            return
        }
        dynamicTable.addFirst(entry)
        dynamicBytes += size
        evictToFit()
    }

    private fun evictToFit() {
        while (dynamicBytes > maxDynamicBytes && dynamicTable.isNotEmpty()) {
            val removed = dynamicTable.removeLast()
            dynamicBytes -= (removed.first.length + removed.second.length + 32)
        }
    }

    private fun readInt(buf: ByteArray, start: Int, prefixBits: Int): Pair<Int, Int> {
        val mask = (1 shl prefixBits) - 1
        var value = buf[start].toInt() and mask
        var pos = start + 1
        if (value < mask) return value to pos
        var m = 0
        while (pos < buf.size) {
            val b = buf[pos++].toInt() and 0xFF
            value += (b and 0x7F) shl m
            if ((b and 0x80) == 0) break
            m += 7
        }
        return value to pos
    }

    private fun readString(buf: ByteArray, start: Int): Pair<String, Int> {
        val huffman = (buf[start].toInt() and 0x80) != 0
        val (len, dataStart) = readInt(buf, start, 7)
        val end = minOf(dataStart + len, buf.size)
        val raw = buf.copyOfRange(dataStart, end)
        val str = if (huffman) decodeHuffman(raw) else String(raw, Charsets.ISO_8859_1)
        return str to end
    }

    companion object {
        private class TrieNode {
            var left: TrieNode? = null
            var right: TrieNode? = null
            var symbol: Int = -1
        }

        private val STATIC_TABLE = arrayOf(
            ":authority" to "", ":method" to "GET", ":method" to "POST", ":path" to "/",
            ":path" to "/index.html", ":scheme" to "http", ":scheme" to "https", ":status" to "200",
            ":status" to "204", ":status" to "206", ":status" to "304", ":status" to "400",
            ":status" to "404", ":status" to "500", "accept-charset" to "", "accept-encoding" to "gzip, deflate",
            "accept-language" to "", "accept-ranges" to "", "accept" to "", "access-control-allow-origin" to "",
            "age" to "", "allow" to "", "authorization" to "", "cache-control" to "",
            "content-disposition" to "", "content-encoding" to "", "content-language" to "", "content-length" to "",
            "content-location" to "", "content-range" to "", "content-type" to "", "cookie" to "",
            "date" to "", "etag" to "", "expect" to "", "expires" to "",
            "from" to "", "host" to "", "if-match" to "", "if-modified-since" to "",
            "if-none-match" to "", "if-range" to "", "if-unmodified-since" to "", "last-modified" to "",
            "link" to "", "location" to "", "max-forwards" to "", "proxy-authenticate" to "",
            "proxy-authorization" to "", "range" to "", "referer" to "", "refresh" to "",
            "retry-after" to "", "server" to "", "set-cookie" to "", "strict-transport-security" to "",
            "transfer-encoding" to "", "user-agent" to "", "vary" to "", "via" to "",
            "www-authenticate" to ""
        )

        private val HUFFMAN_CODES = arrayOf(
            8184 to 13, 8388568 to 23, 268435426 to 28, 268435427 to 28, 268435428 to 28, 268435429 to 28, 268435430 to 28, 268435431 to 28,
            268435432 to 28, 16777194 to 24, 1073741820 to 30, 268435433 to 28, 268435434 to 28, 1073741821 to 30, 268435435 to 28, 268435436 to 28,
            268435437 to 28, 268435438 to 28, 268435439 to 28, 268435440 to 28, 268435441 to 28, 268435442 to 28, 1073741822 to 30, 268435443 to 28,
            268435444 to 28, 268435445 to 28, 268435446 to 28, 268435447 to 28, 268435448 to 28, 268435449 to 28, 268435450 to 28, 268435451 to 28,
            20 to 6, 1016 to 10, 1017 to 10, 4090 to 12, 8185 to 13, 21 to 6, 248 to 8, 2042 to 11,
            1018 to 10, 1019 to 10, 249 to 8, 2043 to 11, 250 to 8, 22 to 6, 23 to 6, 24 to 6,
            0 to 5, 1 to 5, 2 to 5, 25 to 6, 26 to 6, 27 to 6, 28 to 6, 29 to 6,
            30 to 6, 31 to 6, 92 to 7, 251 to 8, 32764 to 15, 32 to 6, 4091 to 12, 1020 to 10,
            8186 to 13, 33 to 6, 93 to 7, 94 to 7, 95 to 7, 96 to 7, 97 to 7, 98 to 7,
            99 to 7, 100 to 7, 101 to 7, 102 to 7, 103 to 7, 104 to 7, 105 to 7, 106 to 7,
            107 to 7, 108 to 7, 109 to 7, 110 to 7, 111 to 7, 112 to 7, 113 to 7, 114 to 7,
            252 to 8, 115 to 7, 253 to 8, 8187 to 13, 524272 to 19, 8188 to 13, 16380 to 14, 34 to 6,
            32765 to 15, 3 to 5, 35 to 6, 4 to 5, 36 to 6, 5 to 5, 37 to 6, 38 to 6,
            39 to 6, 6 to 5, 116 to 7, 117 to 7, 40 to 6, 41 to 6, 42 to 6, 7 to 5,
            43 to 6, 118 to 7, 44 to 6, 8 to 5, 9 to 5, 45 to 6, 119 to 7, 120 to 7,
            121 to 7, 122 to 7, 123 to 7, 32766 to 15, 2044 to 11, 16381 to 14, 8189 to 13, 268435452 to 28,
            1048550 to 20, 4194258 to 22, 1048551 to 20, 1048552 to 20, 4194259 to 22, 4194260 to 22, 4194261 to 22, 8388569 to 23,
            4194262 to 22, 8388570 to 23, 8388571 to 23, 8388572 to 23, 8388573 to 23, 8388574 to 23, 16777195 to 24, 8388575 to 23,
            16777196 to 24, 16777197 to 24, 4194263 to 22, 8388576 to 23, 16777198 to 24, 8388577 to 23, 8388578 to 23, 8388579 to 23,
            8388580 to 23, 2097116 to 21, 4194264 to 22, 8388581 to 23, 4194265 to 22, 8388582 to 23, 8388583 to 23, 16777199 to 24,
            4194266 to 22, 2097117 to 21, 1048553 to 20, 4194267 to 22, 4194268 to 22, 8388584 to 23, 8388585 to 23, 2097118 to 21,
            8388586 to 23, 4194269 to 22, 4194270 to 22, 16777200 to 24, 2097119 to 21, 4194271 to 22, 8388587 to 23, 8388588 to 23,
            2097120 to 21, 2097121 to 21, 4194272 to 22, 2097122 to 21, 8388589 to 23, 4194273 to 22, 8388590 to 23, 8388591 to 23,
            1048554 to 20, 4194274 to 22, 4194275 to 22, 4194276 to 22, 8388592 to 23, 4194277 to 22, 4194278 to 22, 8388593 to 23,
            67108832 to 26, 67108833 to 26, 1048555 to 20, 524273 to 19, 4194279 to 22, 8388594 to 23, 4194280 to 22, 33554412 to 25,
            67108834 to 26, 67108835 to 26, 67108836 to 26, 134217694 to 27, 134217695 to 27, 67108837 to 26, 16777201 to 24, 33554413 to 25,
            524274 to 19, 2097123 to 21, 67108838 to 26, 134217696 to 27, 134217697 to 27, 67108839 to 26, 134217698 to 27, 16777202 to 24,
            2097124 to 21, 2097125 to 21, 67108840 to 26, 67108841 to 26, 268435453 to 28, 134217699 to 27, 134217700 to 27, 134217701 to 27,
            1048556 to 20, 16777203 to 24, 1048557 to 20, 2097126 to 21, 4194281 to 22, 2097127 to 21, 2097128 to 21, 8388595 to 23,
            4194282 to 22, 4194283 to 22, 33554414 to 25, 33554415 to 25, 16777204 to 24, 16777205 to 24, 67108842 to 26, 8388596 to 23,
            67108843 to 26, 134217702 to 27, 67108844 to 26, 67108845 to 26, 134217703 to 27, 134217704 to 27, 134217705 to 27, 134217706 to 27,
            134217707 to 27, 268435454 to 28, 134217708 to 27, 134217709 to 27, 134217710 to 27, 134217711 to 27, 134217712 to 27, 67108846 to 26,
            1073741823 to 30
        )

        private val ROOT: TrieNode = TrieNode().apply {
            for (sym in HUFFMAN_CODES.indices) {
                val (code, len) = HUFFMAN_CODES[sym]
                var node = this
                for (bit in len - 1 downTo 0) {
                    val b = (code ushr bit) and 1
                    node = if (b == 0) {
                        node.left ?: TrieNode().also { node.left = it }
                    } else {
                        node.right ?: TrieNode().also { node.right = it }
                    }
                }
                node.symbol = sym
            }
        }

        fun decodeHuffman(data: ByteArray): String {
            val out = ByteArrayOutputStream()
            var node = ROOT
            for (byte in data) {
                val v = byte.toInt() and 0xFF
                for (bit in 7 downTo 0) {
                    val b = (v ushr bit) and 1
                    node = (if (b == 0) node.left else node.right) ?: return out.toString("ISO-8859-1")
                    if (node.symbol >= 0) {
                        if (node.symbol == 256) return out.toString("ISO-8859-1")
                        out.write(node.symbol)
                        node = ROOT
                    }
                }
            }
            return out.toString("ISO-8859-1")
        }

        fun encodeResponse(statusCode: Int, headers: List<Pair<String, String>>): ByteArray {
            val out = ByteArrayOutputStream()
            val staticStatusIdx = when (statusCode) {
                200 -> 8
                204 -> 9
                206 -> 10
                304 -> 11
                400 -> 12
                404 -> 13
                500 -> 14
                else -> 0
            }
            if (staticStatusIdx > 0) {
                out.write(0x80 or staticStatusIdx)
            } else {
                out.write(0x08)
                writeRawString(out, statusCode.toString())
            }
            for ((k, v) in headers) {
                out.write(0x00)
                writeRawString(out, k.lowercase())
                writeRawString(out, v)
            }
            return out.toByteArray()
        }

        private fun writeRawString(out: ByteArrayOutputStream, s: String) {
            val bytes = s.toByteArray(Charsets.ISO_8859_1)
            writeInt(out, bytes.size, 7, 0x00)
            out.write(bytes)
        }

        private fun writeInt(out: ByteArrayOutputStream, value: Int, prefixBits: Int, prefixMask: Int) {
            val maxPrefix = (1 shl prefixBits) - 1
            if (value < maxPrefix) {
                out.write(prefixMask or value)
                return
            }
            out.write(prefixMask or maxPrefix)
            var rem = value - maxPrefix
            while (rem >= 128) {
                out.write((rem and 0x7F) or 0x80)
                rem = rem ushr 7
            }
            out.write(rem)
        }
    }
}
