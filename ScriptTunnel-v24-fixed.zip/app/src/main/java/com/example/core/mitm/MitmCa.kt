package com.example.core.mitm

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.security.KeyChain
import java.io.ByteArrayInputStream
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.Date
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

/**
 * Manages the local MITM Root CA (persisted in app files) and issues per-host leaf certificates
 * via [CertBuilder] for TLS termination when relaying HTTPS through Google Apps Script.
 */
class MitmCa(context: Context) {

    private val appContext = context.applicationContext

    private val caDir = File(context.applicationContext.filesDir, "mitm_ca")
    private val certFile = File(caDir, "ca_cert.der")
    private val privFile = File(caDir, "ca_priv.pk8")
    private val pubFile = File(caDir, "ca_pub.x509")

    private val random = SecureRandom()
    private val hostContexts = ConcurrentHashMap<String, SSLContext>()

    private val caCert: X509Certificate
    private val caPrivateKey: PrivateKey
    private val caPublicKey: PublicKey

    private val leafKeyPair: KeyPair by lazy {
        KeyPairGenerator.getInstance("RSA").apply {
            initialize(2048, random)
        }.generateKeyPair()
    }

    init {
        val loaded = loadCa()
        if (loaded != null) {
            caCert = loaded.first
            caPrivateKey = loaded.second
            caPublicKey = loaded.third
        } else {
            val created = createAndSaveCa()
            caCert = created.first
            caPrivateKey = created.second
            caPublicKey = created.third
        }
    }

    fun sslContextForHost(host: String): SSLContext {
        val clean = host.trim().lowercase().ifBlank { "localhost" }
        return hostContexts.getOrPut(clean) { buildLeafContext(clean) }
    }

    fun caCertificateDer(): ByteArray = caCert.encoded

    fun isCaInstalled(): Boolean {
        val targetDer = caCert.encoded
        val inAndroidStore = runCatching {
            val ks = KeyStore.getInstance("AndroidCAStore")
            ks.load(null)
            val aliases = ks.aliases()
            while (aliases.hasMoreElements()) {
                val alias = aliases.nextElement()
                val cert = ks.getCertificate(alias) ?: continue
                if (cert.encoded.contentEquals(targetDer)) return@runCatching true
            }
            false
        }.getOrDefault(false)
        if (inAndroidStore) return true

        return runCatching {
            val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
            tmf.init(null as KeyStore?)
            val x509 = tmf.trustManagers.filterIsInstance<X509TrustManager>().firstOrNull()
            x509?.acceptedIssuers?.any { it.encoded.contentEquals(targetDer) } == true
        }.getOrDefault(false)
    }

    @Suppress("DEPRECATION")
    fun createInstallIntent(): Intent {
        return KeyChain.createInstallIntent().apply {
            putExtra(KeyChain.EXTRA_CERTIFICATE, caCert.encoded)
            putExtra(KeyChain.EXTRA_NAME, CA_COMMON_NAME)
        }
    }

    /**
     * Android 11+ no longer installs CA certificates from KeyChain.createInstallIntent().
     * Saves the CA as Downloads/ScriptTunnel-CA.crt so the user can install it from
     * Settings > Security > Encryption & credentials > Install a certificate > CA certificate.
     */
    fun exportCaToDownloads(): Boolean = runCatching {
        val name = "ScriptTunnel-CA.crt"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = appContext.contentResolver
            runCatching {
                resolver.delete(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    "${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                    arrayOf(name)
                )
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/x-x509-ca-cert")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return@runCatching false
            resolver.openOutputStream(uri)?.use { it.write(caCert.encoded) } ?: return@runCatching false
            true
        } else {
            false
        }
    }.getOrDefault(false)

    private fun buildLeafContext(host: String): SSLContext {
        val now = System.currentTimeMillis()
        val notBefore = Date(now - 86_400_000L)
        val notAfter = Date(now + 365L * 86_400_000L)
        val serial = BigInteger(63, random).add(BigInteger.ONE)

        val leafDer = CertBuilder.build(
            leafKeyPair.public,
            host,
            caPrivateKey,
            caPublicKey,
            CA_COMMON_NAME,
            serial,
            notBefore,
            notAfter,
            false,
            listOf(host)
        )
        val cf = CertificateFactory.getInstance("X.509")
        val leafCert = cf.generateCertificate(ByteArrayInputStream(leafDer)) as X509Certificate

        val ks = KeyStore.getInstance(KeyStore.getDefaultType()).apply {
            load(null, null)
            setKeyEntry("leaf", leafKeyPair.private, charArrayOf(), arrayOf(leafCert, caCert))
        }
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()).apply {
            init(ks, charArrayOf())
        }
        return SSLContext.getInstance("TLS").apply {
            init(kmf.keyManagers, null, random)
        }
    }

    private fun loadCa(): Triple<X509Certificate, PrivateKey, PublicKey>? {
        if (!certFile.exists() || !privFile.exists() || !pubFile.exists()) return null
        return runCatching {
            val cf = CertificateFactory.getInstance("X.509")
            val cert = cf.generateCertificate(ByteArrayInputStream(certFile.readBytes())) as X509Certificate
            val kf = KeyFactory.getInstance("RSA")
            val priv = kf.generatePrivate(PKCS8EncodedKeySpec(privFile.readBytes()))
            val pub = kf.generatePublic(X509EncodedKeySpec(pubFile.readBytes()))
            Triple(cert, priv, pub)
        }.getOrNull()
    }

    private fun createAndSaveCa(): Triple<X509Certificate, PrivateKey, PublicKey> {
        caDir.mkdirs()
        val kp = KeyPairGenerator.getInstance("RSA").apply {
            initialize(2048, random)
        }.generateKeyPair()

        val now = System.currentTimeMillis()
        val notBefore = Date(now - 86_400_000L)
        val notAfter = Date(now + 10L * 365L * 86_400_000L)
        val serial = BigInteger(63, random).add(BigInteger.ONE)

        val der = CertBuilder.build(
            kp.public,
            CA_COMMON_NAME,
            kp.private,
            kp.public,
            CA_COMMON_NAME,
            serial,
            notBefore,
            notAfter,
            true,
            null
        )

        certFile.writeBytes(der)
        privFile.writeBytes(kp.private.encoded)
        pubFile.writeBytes(kp.public.encoded)

        val cf = CertificateFactory.getInstance("X.509")
        val cert = cf.generateCertificate(ByteArrayInputStream(der)) as X509Certificate
        return Triple(cert, kp.private, kp.public)
    }

    companion object {
        const val CA_COMMON_NAME = "ScriptTunnel Local CA"
    }
}
