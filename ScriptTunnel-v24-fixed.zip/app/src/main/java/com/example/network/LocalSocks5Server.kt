package com.example.network

import com.example.data.model.BypassSettings
import com.example.data.model.EndpointType
import com.example.data.model.TunnelProtocol
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer

class LocalSocks5Server(
    private val engine: ParallelTunnelEngine
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var serverSocket: ServerSocket? = null
    private var acceptJob: Job? = null

    @Volatile
    private var currentSettings: BypassSettings = BypassSettings()

    @Volatile
    var isRunning: Boolean = false
        private set

    fun start(settings: BypassSettings) {
        currentSettings = settings
        if (isRunning && serverSocket?.localPort == settings.localSocksPort) return
        stop()

        acceptJob = scope.launch {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), settings.localSocksPort))
                serverSocket = ss
                isRunning = true

                while (isActive && !ss.isClosed) {
                    val client = ss.accept()
                    launch { handleSocksClient(client) }
                }
            } catch (_: Exception) {
                // Stopped or port closed
            } finally {
                isRunning = false
            }
        }
    }

    fun updateSettings(settings: BypassSettings) {
        currentSettings = settings
    }

    fun stop() {
        isRunning = false
        acceptJob?.cancel()
        acceptJob = null
        runCatching { serverSocket?.close() }
        serverSocket = null
    }

    private suspend fun handleSocksClient(client: Socket) {
        engine.incrementStreams()
        try {
            client.soTimeout = 30_000
            client.tcpNoDelay = true
            val input = BufferedInputStream(client.getInputStream())
            val output = client.getOutputStream()

            // 1. SOCKS5 Greeting (RFC 1928)
            val ver = input.read()
            if (ver != 0x05) {
                client.close()
                return
            }
            val nMethods = input.read()
            if (nMethods <= 0) {
                client.close()
                return
            }
            val methods = ByteArray(nMethods)
            readFully(input, methods)
            // Reply: SOCKS5, NO AUTH (0x00)
            output.write(byteArrayOf(0x05, 0x00))
            output.flush()

            // 2. SOCKS5 Request
            val reqHeader = ByteArray(4)
            readFully(input, reqHeader)
            val cmd = reqHeader[1].toInt() and 0xFF
            val atyp = reqHeader[3].toInt() and 0xFF

            if (cmd != 0x01) { // Only CONNECT supported
                sendSocksReply(output, 0x07)
                client.close()
                return
            }

            val targetHost = when (atyp) {
                0x01 -> { // IPv4
                    val addr = ByteArray(4)
                    readFully(input, addr)
                    InetAddress.getByAddress(addr).hostAddress ?: "0.0.0.0"
                }
                0x03 -> { // Domain
                    val len = input.read()
                    if (len <= 0) {
                        sendSocksReply(output, 0x01)
                        client.close()
                        return
                    }
                    val domainBytes = ByteArray(len)
                    readFully(input, domainBytes)
                    String(domainBytes, Charsets.UTF_8)
                }
                0x04 -> { // IPv6
                    val addr = ByteArray(16)
                    readFully(input, addr)
                    InetAddress.getByAddress(addr).hostAddress ?: "::1"
                }
                else -> {
                    sendSocksReply(output, 0x08)
                    client.close()
                    return
                }
            }

            val portBytes = ByteArray(2)
            readFully(input, portBytes)
            val targetPort = ByteBuffer.wrap(portBytes).short.toInt() and 0xFFFF

            val settings = currentSettings
            val wsNodes = engine.selectOrderedCandidates(EndpointType.CF_WORKER_WS)
                .filter { it.endpointType == EndpointType.CF_WORKER_WS }

            val useWebSocket = wsNodes.isNotEmpty() &&
                (settings.protocol == TunnelProtocol.CF_WEBSOCKET ||
                    settings.protocol == TunnelProtocol.HYBRID_SMART ||
                    settings.protocol == TunnelProtocol.SOCKS5_LOCAL)

            com.example.core.logging.TunnelLogger.d(
                com.example.core.logging.LogCategory.VPN, "SOCKS5",
                "درخواست $targetHost:$targetPort",
                if (useWebSocket) "مسیر: CF-WS" else "مسیر: GAS (HTTP + پل MTProto)"
            )
            if (useWebSocket) {
                relayViaWorkerWebSocket(wsNodes.first(), targetHost, targetPort, input, output, client)
            } else {
                // GAS-only HTTP relay mode (handles plain HTTP requests over SOCKS5)
                sendSocksReply(output, 0x00)
                relayHttpOnlyViaGas(targetHost, targetPort, input, output, client)
            }
        } catch (_: Exception) {
            // Stream ended
        } finally {
            runCatching { client.close() }
            engine.decrementStreams()
        }
    }

    private suspend fun relayViaWorkerWebSocket(
        workerNode: com.example.data.local.ServerEndpointEntity,
        targetHost: String,
        targetPort: Int,
        clientIn: InputStream,
        clientOut: OutputStream,
        clientSocket: Socket
    ) {
        val connectedSignal = CompletableDeferred<Boolean>()
        val incomingFromWs = Channel<ByteArray>(capacity = 64)

        val ws = engine.openWorkerWebSocket(workerNode, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val ctrl = JSONObject().apply {
                    put("type", "CONNECT")
                    put("host", targetHost)
                    put("port", targetPort)
                }.toString()
                webSocket.send(ctrl)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val obj = runCatching { JSONObject(text) }.getOrNull() ?: return
                when (obj.optString("type")) {
                    "CONNECTED" -> connectedSignal.complete(true)
                    "ERROR" -> connectedSignal.complete(false)
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val arr = bytes.toByteArray()
                engine.recordTraffic(upBytes = 0L, downBytes = arr.size.toLong())
                if (incomingFromWs.trySend(arr).isFailure) {
                    runCatching { kotlinx.coroutines.runBlocking { incomingFromWs.send(arr) } }
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                incomingFromWs.close()
                connectedSignal.complete(false)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                incomingFromWs.close()
                connectedSignal.complete(false)
            }
        })

        val ready = withTimeoutOrNull(8_000L) { connectedSignal.await() } ?: false
        if (!ready) {
            sendSocksReply(clientOut, 0x05)
            ws.cancel()
            return
        }

        sendSocksReply(clientOut, 0x00)
        clientSocket.soTimeout = 0

        val writerJob = scope.launch {
            try {
                for (chunk in incomingFromWs) {
                    clientOut.write(chunk)
                    clientOut.flush()
                }
            } catch (_: Exception) {
                // client closed
            } finally {
                runCatching { clientSocket.close() }
            }
        }

        try {
            val buf = ByteArray(16_384)
            while (true) {
                val read = clientIn.read(buf)
                if (read <= 0) break
                val slice = buf.copyOf(read)
                engine.recordTraffic(upBytes = read.toLong(), downBytes = 0L)
                if (!ws.send(slice.toByteString(0, read))) break
            }
        } catch (_: Exception) {
            // EOF or error
        } finally {
            writerJob.cancel()
            ws.close(1000, "EOF")
        }
    }

    private suspend fun relayHttpOnlyViaGas(
        targetHost: String,
        targetPort: Int,
        clientIn: InputStream,
        clientOut: OutputStream,
        clientSocket: Socket
    ) {
        val buf = ByteArray(16_384)
        val n = clientIn.read(buf)
        if (n <= 0) return
        val firstChunk = String(buf, 0, n, Charsets.ISO_8859_1)

        // Check if plain HTTP request
        val lines = firstChunk.split("\r\n")
        val requestLine = lines.firstOrNull().orEmpty().split(" ")
        if (requestLine.size >= 2 && requestLine[0] in listOf("GET", "POST", "PUT", "DELETE", "HEAD")) {
            val method = requestLine[0]
            val path = requestLine[1]
            val scheme = if (targetPort == 443) "https" else "http"
            val fullUrl = if (path.startsWith("http")) path else "$scheme://$targetHost:$targetPort$path"
            val headers = mutableMapOf<String, String>()
            for (line in lines.drop(1)) {
                if (line.isBlank()) break
                val idx = line.indexOf(':')
                if (idx > 0) {
                    val k = line.substring(0, idx).trim()
                    val v = line.substring(idx + 1).trim()
                    if (!k.equals("Host", ignoreCase = true) && !k.equals("Connection", ignoreCase = true)) {
                        headers[k] = v
                    }
                }
            }
            val res = engine.relayHttpViaGasPool(fullUrl, method, headers, null)
            val statusLine = "HTTP/1.1 ${res.statusCode} OK\r\nContent-Length: ${res.bodyBytes.size}\r\nConnection: close\r\n\r\n"
            clientOut.write(statusLine.toByteArray(Charsets.ISO_8859_1))
            clientOut.write(res.bodyBytes)
            clientOut.flush()
        } else {
            // Ensure at least 64 bytes are buffered if this is an MTProto Obfuscated2 handshake
            var initial = buf.copyOf(n)
            if (initial.size < 64) {
                val acc = ByteArray(64)
                System.arraycopy(initial, 0, acc, 0, initial.size)
                var total = initial.size
                while (total < 64) {
                    val more = runCatching { clientIn.read(acc, total, 64 - total) }.getOrDefault(-1)
                    if (more <= 0) break
                    total += more
                }
                initial = acc.copyOf(total)
            }

            val handledByBridge = if (currentSettings.mtProtoHttpBridgeEnabled && initial.size >= 64) {
                clientSocket.soTimeout = 0
                MtProtoHttpBridge.bridgeObfuscatedStream(
                    engine = engine,
                    targetHost = targetHost,
                    targetPort = targetPort,
                    initialBytes = initial,
                    clientIn = clientIn,
                    clientOut = clientOut
                )
            } else {
                false
            }

            if (!handledByBridge) {
                com.example.core.logging.TunnelLogger.d(
                    com.example.core.logging.LogCategory.VPN, "SOCKS5",
                    "ترافیک غیر HTTP پشتیبانی‌نشده در حالت GAS رد شد",
                    "$targetHost:$targetPort"
                )
                val msg = "HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\nRaw TCP requires a Cloudflare Worker WebSocket endpoint."
                runCatching {
                    clientOut.write(msg.toByteArray(Charsets.ISO_8859_1))
                    clientOut.flush()
                }
            }
        }
    }

    private fun sendSocksReply(out: OutputStream, rep: Int) {
        // VER=5, REP=rep, RSV=0, ATYP=1(IPv4), BND.ADDR=0.0.0.0, BND.PORT=0
        out.write(byteArrayOf(0x05, rep.toByte(), 0x00, 0x01, 0, 0, 0, 0, 0, 0))
        out.flush()
    }

    private fun readFully(input: InputStream, dst: ByteArray) {
        var offset = 0
        while (offset < dst.size) {
            val n = input.read(dst, offset, dst.size - offset)
            if (n < 0) throw IOException("Unexpected EOF")
            offset += n
        }
    }
}
