package com.example.network

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.example.core.logging.LogCategory
import com.example.core.logging.TunnelLogger
import com.example.data.local.ServerEndpointEntity
import com.example.data.model.EndpointType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Universal parser for DNSTT configs from ScriptTunnel and other Android/desktop DNSTT apps:
 *  - dnstt://base64_json  or  dnstt://ns.domain.com?pubkey=...&doh=...&name=...
 *  - dns://base64_json    or  dns://ns.domain.com?pubkey=...&udp=...
 *  - Raw JSON: {"domain":"...","pubkey":"...","doh":"...","dot":"...","udp":"...","name":"..."}
 *  - CLI / key-value text: "-doh https://dns.google/dns-query -pubkey <hex> ns.example.com"
 */
object DnsttConfigParser {

    fun looksLikeDnstt(raw: String): Boolean {
        val t = raw.trim()
        val lower = t.lowercase()
        return lower.startsWith("dnstt://") ||
            lower.startsWith("dns://") ||
            (t.startsWith("{") && (lower.contains("pubkey") || lower.contains("publickey") || lower.contains("public_key"))) ||
            (lower.contains("-pubkey") || (lower.contains("pubkey") && (lower.contains("doh") || lower.contains("dot") || lower.contains("udp") || lower.contains("domain") || lower.contains("ns"))))
    }

    fun parse(raw: String): ServerEndpointEntity? {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return null

        // 1. URI forms: dnstt://... or dns://...
        if (trimmed.startsWith("dnstt://", ignoreCase = true) || trimmed.startsWith("dns://", ignoreCase = true)) {
            val payload = trimmed.substringAfter("://")
            // 1a. Try Base64 JSON first (e.g. dnstt://eyJkb21haW4iOi... )
            if (!payload.contains("?") && !payload.contains(".")) {
                val decoded = runCatching {
                    String(Base64.decode(payload, Base64.URL_SAFE or Base64.DEFAULT), Charsets.UTF_8)
                }.getOrNull()
                if (decoded != null && decoded.trimStart().startsWith("{")) {
                    parseJson(decoded)?.let { return it }
                }
            }
            // 1b. Query URI: dnstt://ns.domain.com?pubkey=...&doh=...&name=...
            val uri = runCatching { Uri.parse(trimmed) }.getOrNull()
            if (uri != null) {
                val host = uri.host.orEmpty().trim()
                val pubkey = firstNonBlank(
                    uri.getQueryParameter("pubkey"),
                    uri.getQueryParameter("publicKey"),
                    uri.getQueryParameter("public_key"),
                    uri.getQueryParameter("key")
                )
                val transport = firstNonBlank(
                    uri.getQueryParameter("doh")?.let { ensureScheme(it, "https://") },
                    uri.getQueryParameter("dot")?.let { ensureDot(it) },
                    uri.getQueryParameter("udp")?.let { ensureUdp(it) },
                    uri.getQueryParameter("resolver"),
                    uri.getQueryParameter("addr")
                ).ifBlank { "https://dns.google/dns-query" }
                val name = firstNonBlank(uri.getQueryParameter("name"), uri.fragment, host)
                if (host.isNotBlank() && pubkey.isNotBlank()) {
                    return ServerEndpointEntity(
                        name = name.ifBlank { "DNSTT $host" },
                        url = host,
                        secretKey = pubkey,
                        type = EndpointType.DNSTT.name,
                        customSniHost = transport,
                        weight = 1,
                        isParallelActive = true
                    )
                }
            }
        }

        // 2. JSON object
        if (trimmed.startsWith("{")) {
            parseJson(trimmed)?.let { return it }
        }

        // 3. CLI flags or multiline key=value / key:value
        return parseCliOrKeyValue(trimmed)
    }

    private fun parseJson(jsonText: String): ServerEndpointEntity? = runCatching {
        val obj = JSONObject(jsonText)
        val domain = firstNonBlank(
            obj.optString("domain"),
            obj.optString("ns"),
            obj.optString("nameserver"),
            obj.optString("url"),
            obj.optString("host")
        )
        val pubkey = firstNonBlank(
            obj.optString("pubkey"),
            obj.optString("publicKey"),
            obj.optString("public_key"),
            obj.optString("key")
        )
        val transport = firstNonBlank(
            obj.optString("doh").takeIf { it.isNotBlank() }?.let { ensureScheme(it, "https://") },
            obj.optString("dot").takeIf { it.isNotBlank() }?.let { ensureDot(it) },
            obj.optString("udp").takeIf { it.isNotBlank() }?.let { ensureUdp(it) },
            obj.optString("resolver"),
            obj.optString("transport"),
            obj.optString("sni")
        ).ifBlank { "https://dns.google/dns-query" }
        val name = firstNonBlank(obj.optString("name"), obj.optString("remarks"), domain)
        if (domain.isBlank() || pubkey.isBlank()) return@runCatching null
        ServerEndpointEntity(
            name = name.ifBlank { "DNSTT $domain" },
            url = domain,
            secretKey = pubkey,
            type = EndpointType.DNSTT.name,
            customSniHost = transport,
            weight = 1,
            isParallelActive = true
        )
    }.getOrNull()

    private fun parseCliOrKeyValue(text: String): ServerEndpointEntity? {
        var domain = ""
        var pubkey = ""
        var transport = ""
        var name = ""

        val tokens = text.split(Regex("\\s+")).filter { it.isNotBlank() }
        var i = 0
        while (i < tokens.size) {
            val tok = tokens[i]
            when {
                tok == "-doh" && i + 1 < tokens.size -> { transport = ensureScheme(tokens[++i], "https://") }
                tok == "-dot" && i + 1 < tokens.size -> { transport = ensureDot(tokens[++i]) }
                tok == "-udp" && i + 1 < tokens.size -> { transport = ensureUdp(tokens[++i]) }
                (tok == "-pubkey" || tok == "--pubkey") && i + 1 < tokens.size -> { pubkey = tokens[++i] }
                tok.contains("=") || tok.contains(":") && !tok.startsWith("http") -> {
                    val sep = if (tok.contains("=")) '=' else ':'
                    val k = tok.substringBefore(sep).trim().lowercase()
                    val v = tok.substringAfter(sep).trim()
                    when (k) {
                        "domain", "ns", "nameserver" -> domain = v
                        "pubkey", "publickey", "public_key", "key" -> pubkey = v
                        "doh" -> transport = ensureScheme(v, "https://")
                        "dot" -> transport = ensureDot(v)
                        "udp" -> transport = ensureUdp(v)
                        "resolver", "transport" -> transport = v
                        "name", "remarks" -> name = v
                    }
                }
                !tok.startsWith("-") && tok.contains(".") && !tok.contains("://") && domain.isBlank() -> {
                    if (!tok.matches(Regex("^\\d+\\.\\d+\\.\\d+\\.\\d+(:\\d+)?$"))) {
                        domain = tok
                    }
                }
            }
            i++
        }
        if (domain.isBlank() || pubkey.isBlank()) return null
        return ServerEndpointEntity(
            name = name.ifBlank { "DNSTT $domain" },
            url = domain,
            secretKey = pubkey,
            type = EndpointType.DNSTT.name,
            customSniHost = transport.ifBlank { "https://dns.google/dns-query" },
            weight = 1,
            isParallelActive = true
        )
    }

    private fun firstNonBlank(vararg values: String?): String =
        values.firstOrNull { !it.isNullOrBlank() }?.trim().orEmpty()

    private fun ensureScheme(v: String, scheme: String): String {
        val t = v.trim()
        return if (t.startsWith("http://") || t.startsWith("https://")) t else "$scheme$t"
    }

    private fun ensureDot(v: String): String {
        val t = v.trim()
        return if (t.startsWith("dot://")) t else "dot://$t"
    }

    private fun ensureUdp(v: String): String {
        val t = v.trim()
        return if (t.startsWith("udp://")) t else "udp://$t"
    }
}

/**
 * Manages the native dnstt-client binary (libdnstt.so in jniLibs or filesDir/dnstt-client)
 * listening on 127.0.0.1:10809 when DNSTT_TUNNEL is active.
 */
object DnsttProcessManager {
    const val SOCKS_PORT = 10809

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var process: Process? = null
    private var logJob: Job? = null
    private val running = AtomicBoolean(false)

    fun isRunning(): Boolean = running.get() && process?.isAlive == true

    fun findBinary(context: Context): File? {
        val nativeBin = File(context.applicationInfo.nativeLibraryDir, "libdnstt.so")
        if (nativeBin.exists() && nativeBin.canExecute()) return nativeBin
        val localBin = File(context.filesDir, "dnstt-client")
        if (localBin.exists()) {
            runCatching { localBin.setExecutable(true) }
            if (localBin.canExecute()) return localBin
        }
        return null
    }

    fun start(context: Context, endpoint: ServerEndpointEntity): Boolean {
        stop()
        val bin = findBinary(context)
        if (bin == null) {
            TunnelLogger.w(
                LogCategory.VPN,
                "DNSTT-NO-BIN",
                "باینری libdnstt.so در اپ پیدا نشد",
                "برای فعال‌شدن موتور DNSTT، فایل کامپایل‌شده libdnstt.so را در مسیر app/src/main/jniLibs/arm64-v8a/ قرار دهید."
            )
            return false
        }

        val transport = endpoint.customSniHost.trim().ifBlank { "https://dns.google/dns-query" }
        val args = mutableListOf(bin.absolutePath)
        when {
            transport.startsWith("dot://") -> {
                args.add("-dot")
                args.add(transport.removePrefix("dot://"))
            }
            transport.startsWith("udp://") -> {
                args.add("-udp")
                args.add(transport.removePrefix("udp://"))
            }
            else -> {
                args.add("-doh")
                args.add(if (transport.startsWith("http")) transport else "https://$transport")
            }
        }
        args.add("-pubkey")
        args.add(endpoint.secretKey.trim())
        args.add(endpoint.url.trim())
        args.add("127.0.0.1:$SOCKS_PORT")

        return runCatching {
            val pb = ProcessBuilder(args).redirectErrorStream(true)
            val proc = pb.start()
            process = proc
            running.set(true)
            TunnelLogger.i(
                LogCategory.VPN,
                "DNSTT-START",
                "موتور DNSTT روی 127.0.0.1:$SOCKS_PORT راه‌اندازی شد (${endpoint.url})",
                "Transport=$transport"
            )
            logJob = scope.launch {
                runCatching {
                    BufferedReader(InputStreamReader(proc.inputStream)).use { br ->
                        var line: String?
                        while (br.readLine().also { line = it } != null && running.get()) {
                            TunnelLogger.d(LogCategory.VPN, "DNSTT", line.orEmpty())
                        }
                    }
                }
                running.set(false)
            }
            true
        }.onFailure { err ->
            TunnelLogger.e(LogCategory.VPN, "DNSTT-ERR", "خطا در اجرای DNSTT", err.localizedMessage)
            running.set(false)
        }.getOrDefault(false)
    }

    fun stop() {
        running.set(false)
        logJob?.cancel()
        logJob = null
        runCatching { process?.destroy() }
        process = null
    }
}
