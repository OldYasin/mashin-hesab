## v36 - TGX hybrid Telegram path (GAS -> Cloudflare Worker -> Telegram TCP) - NOT built/tested on a device
- New worker (tgx/worker.js, also in the scripts guide as "ورکر TGX"): one real TCP socket per session via cloudflare:sockets; optional Durable Object (binding TGX, class TgxSession), otherwise memory mode (best effort, NOSESS -> client reconnects).
- New client TgxBridge.kt: pipes the raw SOCKS5 stream (no MTProto parsing) through GAS with offsets/acks, so retries on any GAS node are safe.
- New settings + dashboard toggle "تلگرام هیبریدی" with worker URL and secret fields. Off by default; the old MtProtoHttpBridge is untouched and used as fallback when a TGX session cannot be opened.
- SOCKS5 hook: Telegram hosts go to TGX first when enabled; CF-WS is skipped for them. Engine: "/__tgx/" URLs use the fast MAC path, skip the relay cap and do not cool nodes down on long-poll timeouts.
- TGX full tunnel: new setting "تونل کامل TCP (همهٔ اپ‌ها)" (tgHybridAllTraffic, off by default, shown under the TGX toggle). When on, every TCP stream (TLS, HTTP, anything; not port 25) goes through TGX as raw bytes, before the old HTTP/MITM special case; if a session cannot be opened it falls back to the old path. Non-Telegram sessions are capped at 60 and may use only 2/3 of the GAS slots so Telegram is never starved. The TGX worker from the guide now allows any destination (ALLOW_ANY_HOST=true, SMTP blocked): keep the secret private.
- ONE Cloudflare worker: the old CF-WS worker and the TGX worker are merged (tgx/worker-unified.js). The scripts guide has two tabs again (Code.gs, Cloudflare worker). Routing: /__tgx/* -> TGX, everything else (WebSocket upgrade, /egress) -> old WS tunnel, /ping -> merged info. Re-deploy the new code on your worker.
- VPN mode fix: TUN traffic goes through TunTcpProxy, not the SOCKS5 server, so TunTcpProxy now routes Telegram (or all TCP with "full tunnel", Iranian IPs excluded) to the local SOCKS5 server where the TGX hook lives (no read timeout on that hop). While "تلگرام هیبریدی" is on and configured, the old CF-WS path is OFF in both TunTcpProxy and LocalSocks5Server.
- Main-page "ورکر کلودفلر" card (shown when a CF worker server exists): smart WebSocket (cfWsSmartEnabled, default on, keeps old behaviour) XOR TGX (turning one on turns the other off) XOR neither = Google relay only. CF-WS is used only in smart mode. TGX worker URL/secret fields are optional: empty = taken from the selected CF worker server (TgxBridge.resolveWorker). The old TGX rows were moved out of the bypass section into this card.
- Unit tests: TgxBridgeTest. Worker test: tgx/test.mjs (needs a generated tgx_test_worker.mjs with a fake socket).
- The old 300 KB test mismatch was the test echo server prefixing each TCP chunk with "R:"; with a pass-through echo the byte count matches.

## v35 - stronger clean-IP scanner
- Why every IP showed ~600 ms: the old probe timed TCP + TLS + the first HTTP answer together (about 3 round trips), so all IPs of the same edge came out at ~3 x RTT. The scanner now measures connect cost (tcp, tls) and the latency of requests on an already open connection separately. The number shown in the list is the warm request latency, i.e. what the relay sees when it reuses the connection.
- Stage 1 (broad, 24 parallel) -> stage 1b (the /24 neighbours of the 12 best hits, 8 each) -> stage 2 (24 finalists, 3 fresh connections x 4 warm requests, 6 parallel; flaky IPs need >= 2 of 3 good connections). Ranking = warm median + jitter/2 + connect/8; jitter is p90 - min, so one outlier no longer dominates.
- New candidate sources: IPs saved from the previous scan (re-tested first, also after an app restart), IPs the resolver returns for script.google.com & co (private/poisoned answers dropped), then random samples of the ranges. Custom ranges are scanned as typed (no neighbour exploration).
- Blackout auto-discovery (quickDiscoverGoogleIpBlocking) uses the fast mode: stage 1 only + secondary-SNI check on the 8 best. Background REPROBE_CLEAN_IP skips the neighbour exploration.
- Unit tests: CleanIpScannerTest.

## v34 - GAS-only Telegram bridge fixes
- Hedge delay is now adaptive: 1.3 x p90 of t.tgRelay, clamped to 2.5-6 s (3 s until 20 samples exist). The old fixed 1.5 s was below the ~1.7 s GAS floor, so nearly every small packet was duplicated and UrlFetch quota was spent twice.
- DC "dead edge" cooldown (120 s) is now only triggered by a real HTTP 404. Timeouts, quota errors and 502 used to mark the whole DC dead and every new Telegram connection then got "502 Raw TCP requires...".
- A transient failure now drops only that packet (MTProto resends it); the session is closed only after 3 failures in a row (tg.bridge.dropTransient counter).
- Global relay cap is 24 per active GAS node (max 168 = 7 nodes) instead of a fixed 24; node count is cached for 2 s, so the per-packet candidate lookup no longer advances the round-robin index.
- Hedge twins now also count against the global cap (they used to bypass it).
- New TunnelStats.percentile / sampleCount; unit tests for the hedge delay.

## v32
- Servers screen: action buttons re-laid out (no squeezed add button), colored switches, ping chip, shorter ProxyIP field label
- Telegram bridge: GAS caps 24 global / 8 per session; hedge now at 1.5s for small packets only (max 8 twins in flight); transient failure retries once on another node instead of closing the session (tg.bridge.retry / hedgeSkip counters)

## v31
- Telegram bridge: delayed hedging. A packet with no reply after 2.2s (HEDGE_DELAY_MS in MtProtoHttpBridge) is re-sent once through a different GAS node; both replies are forwarded to Telegram (duplicate msg_ids are ignored by the client) so nothing is lost. Counters: tg.bridge.hedge / tg.bridge.hedgeRx. Needs >= 2 active GAS nodes.
- GAS relay: new "mac" envelope for Telegram (HMAC-only, no xor keystream) -> ~30 fewer Utilities.computeDigest calls per request in Apps Script; response gzip attempt skipped (nogz). Re-deploy the script on every node to benefit; old deployments are auto-detected and use the full encrypted envelope.

## v30
- MtProtoHttpBridge – media DC connections (negative dc id in obfuscated2 header) now use <dc>-1.web.telegram.org with fallback to main host (fixes apiw1 404 on DC2/DC4 media).

## v19.1
- Thermal guard also follows Android PowerManager thermal status (API 29+), combined with battery temperature (the higher level wins)
- Thermal guard: FAST_DEFLATE now emits real gzip (it was sent as raw zlib labelled "none", so every relay failed above 42C); hysteresis + charging headroom on throttle levels, gentler concurrency limits
- Fix build: missing HorizontalDivider import and server delete confirmation dialog (ServersScreen)
- Fix Google Search opening in desktop layout: relay now sends Title-Case header names (HTTP/2 lowercase user-agent was ignored by UrlFetchApp)
- Script: Content-Type for POST bodies is passed via UrlFetchApp contentType (re-deploy script to get this part)
- Telegram Web: Vary-retry keeps the mapped host; long-poll read timeouts no longer cool down a script

# v5 — less heat, same speed
- Warm WebSocket pool: single refill loop (was one loop per connection -> 368 sockets for 34 connections), target 4, stops topping up when idle, ping 30s.
- Iranian sites (.ir, digikala, aparat, divar, bale, eitaa...) go direct, not through the tunnel (fixes the 4s stalls + 7-byte TLS alert of api.abangateway.ir).
- DoH to 8.8.4.4 (no reply via Cloudflare) is remapped to 8.8.8.8 (same dns.google cert).
- Notification updated every 5s instead of every 1s.
- Noisy Xiaomi system apps excluded from the VPN (list: NOISY_SYSTEM_PACKAGES in ScriptVpnService.kt).

# v6 — better diagnostics
- PULSE line every 15s: connections/min, ws-opened vs discarded, warm/cold, domestic-direct, streams, speed, battery temp. WARN + flag (HOT, POOL-CHURN, NO-REPLY, WS-FAIL, FALLBACK) when something is off.
- Export header: device, Android version, protocol/settings, server list (no secrets).
- DIAGNOSIS: battery temp start/now/max, efficiency (ws-opened per connection), slow-connection list, new verdict hints (heat, pool churn, background app spam, slow sites).
- Per-connection lines: healthy = DEBUG, slow/proxy = INFO, no-reply / TLS-alert-only / odd end = WARN with a <<< marker.
- Log UI no longer re-copies 4000 rows on every line (max ~2.5 updates/s) -> less CPU. Export always uses a fresh snapshot.
- "Session stopped" is logged/saved once (was twice).

# v7 — logs inside Reports, cleaner app
- "لاگ‌ها" tab removed; Reports tab ("گزارش‌ها و لاگ") now has sections: جلسه‌ها | مشکل‌ها (WARN+ERR, with count) | اتصال‌ها (WS + PULSE) | DNS و VPN | سرور و IP | سیستم | تشخیص (DIAGNOSIS + verdict in-app, copy full report) | همه لاگ‌ها.
- Every log section: level filter, search, top-tag chips (tap to filter), copy/share/pause/clear.
- Removed: top-bar sync pill (had an always-running spin animation = constant redraws), offline-sync card, per-session "synced" label.
- Removed: compression chips, encryption+padding toggle (no effect on the WebSocket path), compression KPI/badges (always 0% on WebSocket).

## v11 - stall detection, network monitor, user mark
- STALL / STALL-END / STALL-ABORT log lines: connection sent data but got no reply for >=6s (and what happened next). DIAGNOSIS has a "Stalls" block.
- NET log lines: underlying network lost/available, wifi<->cellular switch, validated flag, signal bucket.
- Notification button "ثبت قطعی" writes a USER-MARK line (streams, stalls, net state, battery) at the exact moment of a glitch.

## v10 - fix upload+download drops, TCP flow control, pool fix, per-app logging
- TunTcpProxy: segments were ACKed before being queued; when the 64-slot queue overflowed they were silently dropped -> corrupt TLS stream -> upload failed. Now ACK only after a successful enqueue (else dup-ACK so the phone retransmits), queue capacity 1024.
- Coalesce small TUN segments into <=48KB WebSocket frames (far fewer Worker message events).
- Backpressure on OkHttp WebSocket send queue (queueSize).
- Real TCP flow control: advertised window now shrinks with upload backlog + window-update ACK when drained.
- Removed forced 30s WebSocket ping (false "no pong" kills under upload load).
- Diagnostics: "Upload: peak-backlog / peak-ws-queue / window-drops" line.
- Warm pool: warmingCount was decremented twice when an idle ready socket died -> counter went negative -> pool over-filled (ws-opened ~4 per connection, heat). Fixed with per-socket flag.
- Download path: incoming.trySend() could silently drop worker->phone chunks (same bug class as upload). Now blocks the reader thread for backpressure (TUN + SOCKS5).
- Build label v8-diag.
- Logging: every connection line now has app=<package> (via getConnectionOwnerUid); new "Top apps" block in DIAGNOSIS (conns/RX/TX/noreply/ws-fail).
- HOT flag only when the tunnel carried real load; idle tunnel + warm phone shows PHONE-WARM(idle-tunnel); VERDICT explains the difference.
- Manifest: QUERY_ALL_PACKAGES so app names resolve on Android 11+.

## v13 - MITM fixes
- CA install: Android 11+ refuses KeyChain installs, so the button now saves ScriptTunnel-CA.crt to Downloads and opens Security settings (manual install: Install a certificate > CA certificate). Android 10 and older keep the in-app intent.
- TunTcpProxy: CA-installed check is re-tried every 5s until true (was cached forever per VPN session, so installing the CA while connected had no effect until restart).
- MitmCa is created lazily off the main thread (RSA-2048 keygen no longer blocks the first launch).
- MITM / plain-HTTP keep-alive connections time out after 120s idle (no more stuck IO threads).
- Google script must be re-deployed (light response mode from v12).

## v14 - faster, cheaper Google relay
- Relay HTTP client is now reused (HTTP/2 connection to script.google.com stays open). Before, every relayed request opened a new TCP+TLS connection through the clean IP.
- New GasRelayCache: static GET responses (images, css, js, fonts, or explicit Cache-Control max-age; never private/no-store/Set-Cookie) are cached in memory (32 MB LRU, 4 MB per item, max 1 h). Identical GETs in flight at the same time share one relay call.
- Quota handling: when a script reports a quota/"too many times" error it is skipped for 30 min (60 s for the short-time limit, 5 min for HTTP 429, 10 s after a transport error) and the other deployments are used. If all are cooling down, all are tried.
- Text responses (html/css/js/json/xml/svg) are gzipped inside the script before base64 (new request flag gzBody; old scripts still work, they just do not compress). **Re-deploy the Google script.**
- Cancelled relay calls are no longer logged as relay errors.
- Pulse stats: relay.cacheHit, relay.coalesced.

