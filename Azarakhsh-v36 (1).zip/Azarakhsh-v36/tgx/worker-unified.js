/**
 * ScriptTunnel unified Cloudflare Worker (ONE worker for everything)
 *  - WebSocket TCP tunnel (direct connect + ProxyIP fallback)        : used when Cloudflare is reachable
 *  - TGX raw-TCP session API  /__tgx/o | /__tgx/x | /__tgx/c         : used through Google Apps Script (full blackout)
 * Optional Durable Object: binding name TGX, class TgxSession (TGX works without it in best-effort memory mode).
 */
import { connect } from 'cloudflare:sockets';

const TUNNEL_SECRET = "__SECRET__";
const ALLOW_ANY_HOST = false;       // true = allow any host:port (not only Telegram)
const IDLE_MS = 90000;
const DN_CAP = 4 * 1024 * 1024;     // max un-acked downstream bytes buffered before the socket is paused
const HDR = 17;                     // flags(1) + upAck(8) + dnStart(8)
const F_EOF = 1, F_ERR = 2, F_NOSESS = 4, F_GAP = 8;

function put64(b, o, n) {
  const hi = Math.floor(n / 4294967296);
  const lo = n - hi * 4294967296;
  b[o] = (hi >>> 24) & 255; b[o + 1] = (hi >>> 16) & 255; b[o + 2] = (hi >>> 8) & 255; b[o + 3] = hi & 255;
  b[o + 4] = (lo >>> 24) & 255; b[o + 5] = (lo >>> 16) & 255; b[o + 6] = (lo >>> 8) & 255; b[o + 7] = lo & 255;
}

function frame(flags, upAck, dnStart, data) {
  const d = data || new Uint8Array(0);
  const out = new Uint8Array(HDR + d.length);
  out[0] = flags;
  put64(out, 1, upAck);
  put64(out, 9, dnStart);
  out.set(d, HDR);
  return new Response(out, { status: 200, headers: { "content-type": "application/octet-stream", "cache-control": "no-store" } });
}

function hostAllowed(h, p) {
  h = String(h || "").toLowerCase();
  if (!(p > 0 && p < 65536)) return false;
  if (ALLOW_ANY_HOST) return p !== 25;
  if (h.endsWith(".telegram.org") || h === "telegram.org" || h.endsWith(".t.me")) return true;
  if (h.startsWith("149.154.") || h.startsWith("91.108.") || h.startsWith("95.161.") || h.startsWith("185.76.151.")) return true;
  if (h.startsWith("2001:b28:f23") || h.startsWith("2001:67c:4e8")) return true;
  return false;
}

async function toBytes(req) {
  const ab = await req.arrayBuffer();
  return new Uint8Array(ab);
}

function withTimeout(promise, ms, msg) {
  let t;
  const to = new Promise((_, rej) => { t = setTimeout(() => rej(new Error(msg || "timeout")), ms); });
  return Promise.race([promise, to]).finally(() => clearTimeout(t));
}

class Session {
  constructor() {
    this.sock = null;
    this.writer = null;
    this.upNext = 0;
    this.writeChain = Promise.resolve();
    this.chunks = [];        // { start, data }
    this.dnBase = 0;         // offset of first buffered byte
    this.dnEnd = 0;          // offset after last buffered byte
    this.eof = false;
    this.err = "";
    this.waiters = [];
    this.drain = null;
    this.closed = false;
    this.lastUse = Date.now();
  }

  async open(host, port) {
    this.sock = connect({ hostname: host, port: port });
    await withTimeout(this.sock.opened, 6000, "connect timeout");
    this.writer = this.sock.writable.getWriter();
    this.pump();
  }

  wake() {
    const w = this.waiters;
    this.waiters = [];
    for (const f of w) { try { f(); } catch (e) {} }
  }

  async pump() {
    const reader = this.sock.readable.getReader();
    try {
      while (!this.closed) {
        const { value, done } = await reader.read();
        if (done) break;
        if (value && value.length) {
          this.chunks.push({ start: this.dnEnd, data: value });
          this.dnEnd += value.length;
          this.wake();
          while (!this.closed && (this.dnEnd - this.dnBase) > DN_CAP) {
            await new Promise((r) => { this.drain = r; });
          }
        }
      }
    } catch (e) {
      this.err = String(e && e.message ? e.message : e);
    }
    this.eof = true;
    this.wake();
  }

  trim(ack) {
    if (ack <= this.dnBase) return;
    if (ack > this.dnEnd) ack = this.dnEnd;
    while (this.chunks.length) {
      const c = this.chunks[0];
      const end = c.start + c.data.length;
      if (end <= ack) { this.chunks.shift(); continue; }
      if (c.start < ack) {
        const cut = ack - c.start;
        this.chunks[0] = { start: ack, data: c.data.subarray(cut) };
      }
      break;
    }
    this.dnBase = ack;
    if (this.drain && (this.dnEnd - this.dnBase) <= DN_CAP) {
      const d = this.drain;
      this.drain = null;
      d();
    }
  }

  collect(from, max) {
    const parts = [];
    let got = 0;
    for (const c of this.chunks) {
      const end = c.start + c.data.length;
      if (end <= from) continue;
      let part = c.data;
      let s = c.start;
      if (s < from) { part = part.subarray(from - s); s = from; }
      if (got + part.length > max) part = part.subarray(0, max - got);
      parts.push(part);
      got += part.length;
      if (got >= max) break;
    }
    const out = new Uint8Array(got);
    let o = 0;
    for (const p of parts) { out.set(p, o); o += p.length; }
    return out;
  }

  // ordered, de-duplicated upstream write. returns false on gap
  async write(uo, bytes) {
    if (uo > this.upNext) return false;
    const skip = this.upNext - uo;
    if (skip >= bytes.length) return true;
    const data = skip > 0 ? bytes.subarray(skip) : bytes;
    this.upNext += data.length;
    const w = this.writer;
    this.writeChain = this.writeChain.then(() => w.write(data)).catch((e) => {
      this.err = String(e && e.message ? e.message : e);
      this.eof = true;
      this.wake();
    });
    await this.writeChain;
    return true;
  }

  async read(dnAck, waitMs, max) {
    this.trim(dnAck);
    if (this.dnEnd <= dnAck && !this.eof && waitMs > 0) {
      await new Promise((resolve) => {
        let done = false;
        const fin = () => { if (!done) { done = true; resolve(); } };
        this.waiters.push(fin);
        setTimeout(fin, waitMs);
      });
    }
    const data = this.collect(dnAck, max);
    const atEnd = (dnAck + data.length) >= this.dnEnd;
    return { data: data, eof: this.eof && atEnd, start: dnAck };
  }

  close() {
    if (this.closed) return;
    this.closed = true;
    this.eof = true;
    try { if (this.writer) this.writer.releaseLock(); } catch (e) {}
    try { if (this.sock) this.sock.close(); } catch (e) {}
    if (this.drain) { const d = this.drain; this.drain = null; d(); }
    this.wake();
  }
}

function num(v, d) {
  if (v === null || v === undefined || v === "") return d;
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? n : d;
}

// shared request logic. `holder` = { sess: Session|null }, `onNew`/`onClose` hooks.
async function serve(request, url, holder, hooks) {
  const op = url.pathname.slice("/__tgx/".length);
  const q = url.searchParams;

  if (op === "o") {
    const host = q.get("h") || "";
    const port = num(q.get("p"), 0);
    if (!hostAllowed(host, port)) return frame(F_ERR, 0, 0, new TextEncoder().encode("host_not_allowed"));
    if (holder.sess) { try { holder.sess.close(); } catch (e) {} holder.sess = null; }
    const s = new Session();
    try {
      await s.open(host, port);
    } catch (e) {
      s.close();
      return frame(F_ERR, 0, 0, new TextEncoder().encode("connect_failed: " + String(e && e.message ? e.message : e)));
    }
    holder.sess = s;
    if (hooks && hooks.onNew) hooks.onNew(s);
    const body = await toBytes(request);
    if (body.length) { await s.write(0, body); }
    return frame(0, s.upNext, 0, null);
  }

  const s = holder.sess;
  if (!s || s.closed) return frame(F_NOSESS | F_EOF, 0, 0, null);
  s.lastUse = Date.now();

  if (op === "c") {
    s.close();
    holder.sess = null;
    if (hooks && hooks.onClose) hooks.onClose();
    return frame(F_EOF, s.upNext, s.dnEnd, null);
  }

  if (op === "x") {
    const uo = num(q.get("uo"), 0);
    const dn = num(q.get("dn"), 0);
    const w = Math.min(num(q.get("w"), 0), 25000);
    const m = Math.min(num(q.get("m"), 262144), 524288);
    let flags = 0;
    const body = await toBytes(request);
    if (body.length) {
      const ok = await s.write(uo, body);
      if (!ok) flags |= F_GAP;
    }
    if (flags & F_GAP) return frame(flags, s.upNext, dn, null);
    const r = await s.read(dn, w, m);
    if (r.eof) flags |= F_EOF;
    if (r.eof && s.err) flags |= F_ERR;
    return frame(flags, s.upNext, r.start, r.data);
  }

  return new Response("bad op", { status: 400 });
}

// ---- Durable Object (reliable mode) ----
export class TgxSession {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    this.holder = { sess: null };
    this.idle = null;
  }
  touch() {
    if (this.idle) clearTimeout(this.idle);
    this.idle = setTimeout(() => {
      if (this.holder.sess) { this.holder.sess.close(); this.holder.sess = null; }
    }, IDLE_MS);
  }
  async fetch(request) {
    const url = new URL(request.url);
    this.touch();
    const res = await serve(request, url, this.holder, {
      onClose: () => { if (this.idle) { clearTimeout(this.idle); this.idle = null; } }
    });
    return res;
  }
}

// ---- Memory fallback ----
const MEM = new Map();
function sweep() {
  const now = Date.now();
  for (const [k, h] of MEM) {
    if (!h.sess || h.sess.closed || now - h.sess.lastUse > IDLE_MS) {
      try { if (h.sess) h.sess.close(); } catch (e) {}
      MEM.delete(k);
    }
  }
}

const tgxHandler = {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/ping" || url.searchParams.get("ping") === "1") {
      return new Response(JSON.stringify({
        ok: true, edge: "cf-worker-tgx", ver: "tgx-1",
        mode: (env && env.TGX) ? "durable-object" : "memory",
        colo: (request.cf && request.cf.colo) || "", ts: Date.now()
      }), { headers: { "content-type": "application/json" } });
    }

    if (!url.pathname.startsWith("/__tgx/")) {
      return new Response("ScriptTunnel TGX Active", { status: 200 });
    }

    const auth = request.headers.get("X-Tunnel-Auth") || url.searchParams.get("t");
    if (auth !== TUNNEL_SECRET) return new Response("Unauthorized", { status: 403 });

    const sid = url.searchParams.get("sid") || "";
    if (!/^[A-Za-z0-9_-]{8,64}$/.test(sid)) return new Response("bad sid", { status: 400 });

    try {
      if (env && env.TGX) {
        const id = env.TGX.idFromName(sid);
        return await env.TGX.get(id).fetch(request);
      }
      if (MEM.size > 64) sweep();
      let h = MEM.get(sid);
      if (!h) { h = { sess: null }; MEM.set(sid, h); }
      const res = await serve(request, url, h, { onClose: () => MEM.delete(sid) });
      return res;
    } catch (e) {
      return frame(F_ERR | F_EOF, 0, 0, new TextEncoder().encode(String(e && e.message ? e.message : e)));
    }
  }
};

// ---- WebSocket tunnel ----
const DEFAULT_PROXY_IPS = [
  "ProxyIP.DE.CMLiussss.net",
  "ProxyIP.NL.CMLiussss.net",
  "ProxyIP.SG.CMLiussss.net",
  "ProxyIP.US.CMLiussss.net",
  "ProxyIP.JP.CMLiussss.net",
  "proxyip.fxxk.dedyn.io",
  "cdn-all.xn--b6gac.eu.org",
  "cdn.xn--b6gac.eu.org"
];

// shared by all requests handled in the same isolate
let goodProxy = "";
const badProxy = new Map();

function markBad(p) {
  if (!p) return;
  badProxy.set(p, Date.now() + 120000);
  if (p === goodProxy) goodProxy = "";
}

function getProxyList(env, fromApp) {
  const split = (v) => v ? String(v).split(",").map(s => s.trim()).filter(Boolean) : [];
  const pinned = split(fromApp).concat(split(env && env.PROXYIP));
  const now = Date.now();
  if (goodProxy && (badProxy.get(goodProxy) || 0) > now) goodProxy = "";
  const rest = (goodProxy ? [goodProxy] : []).concat(DEFAULT_PROXY_IPS);
  const all = pinned.concat(rest.filter(x => !pinned.includes(x)));
  const alive = all.filter(x => !((badProxy.get(x) || 0) > now));
  return alive.length ? alive : DEFAULT_PROXY_IPS.slice();
}

function parseHostPort(entry, defPort) {
  let h = entry, p = defPort;
  const m = entry.match(/^(.+):(\d+)$/);
  if (m && !entry.includes("]")) { h = m[1]; p = Number(m[2]); }
  return { hostname: h, port: p, key: entry };
}

async function openWithTimeout(sock, ms) {
  let t;
  const timeout = new Promise((_, rej) => { t = setTimeout(() => rej(new Error("connect timeout")), ms); });
  try { await Promise.race([sock.opened, timeout]); } finally { clearTimeout(t); }
}

const wsHandler = {
  async fetch(request, env) {
    const url = new URL(request.url);
    const upgradeHeader = request.headers.get("Upgrade");

    if (url.pathname === "/ping") {
      return new Response(JSON.stringify({ ok: true, edge: "cf-worker-ws", ver: "v8-stable", colo: (request.cf && request.cf.colo) || "", country: (request.cf && request.cf.country) || "", ts: Date.now() }), {
        headers: { "content-type": "application/json" }
      });
    }

    if (url.pathname === "/egress") {
      const hdr = { "content-type": "application/json" };
      const colo = (request.cf && request.cf.colo) || "";
      try {
        const s = connect({ hostname: "ip-api.com", port: 80 });
        await openWithTimeout(s, 3000);
        const w = s.writable.getWriter();
        await w.write(new TextEncoder().encode("GET /json?fields=status,country,countryCode,query,isp,hosting HTTP/1.1\r\nHost: ip-api.com\r\nConnection: close\r\n\r\n"));
        const r = s.readable.getReader();
        const dec = new TextDecoder();
        let out = "";
        const t0 = Date.now();
        while (Date.now() - t0 < 3000) {
          const { value, done } = await r.read();
          if (done) break;
          out += dec.decode(value, { stream: true });
        }
        try { s.close(); } catch (e) {}
        const body = out.split("\r\n\r\n").slice(1).join("").trim();
        return new Response(JSON.stringify({ colo: colo, egress: body }), { headers: hdr });
      } catch (e) {
        return new Response(JSON.stringify({ colo: colo, error: String(e) }), { headers: hdr });
      }
    }

    if (!upgradeHeader || upgradeHeader.toLowerCase() !== "websocket") {
      return new Response("ScriptTunnel CF-Worker Active (v8-stable)", { status: 200 });
    }

    const authToken = request.headers.get("X-Tunnel-Auth") || url.searchParams.get("token");
    if (authToken !== TUNNEL_SECRET) {
      return new Response("Unauthorized", { status: 403 });
    }

    const webSocketPair = new WebSocketPair();
    const [client, server] = Object.values(webSocketPair);
    server.accept();

    let remoteSocket = null;
    let remoteWriter = null;
    let closed = false;
    let connecting = false;
    let gotData = false;
    let viaProxy = false;
    let currentProxy = "";
    let retries = 0;
    let target = null;
    let replayable = true;
    let rxTotal = 0;
    let directFail = "";
    let sniName = "";
    let sentSize = 0;
    const sentChunks = [];
    const pending = [];
    let writeChain = Promise.resolve();

    const releaseWriter = () => {
      const w = remoteWriter;
      remoteWriter = null;
      if (w) { try { w.releaseLock(); } catch {} }
    };

    const cleanup = () => {
      if (closed) return;
      closed = true;
      releaseWriter();
      try { remoteSocket?.close(); } catch {}
      remoteSocket = null;
      try { server.close(); } catch {}
    };

    const toBytes = async (data) => {
      return data instanceof ArrayBuffer
        ? new Uint8Array(data)
        : ArrayBuffer.isView(data)
          ? new Uint8Array(data.buffer, data.byteOffset, data.byteLength)
          : new Uint8Array(await data.arrayBuffer());
    };

    const writeToCurrent = async (bytes) => {
      if (closed) return;
      if (!remoteWriter || connecting) {
        if (pending.length < 256) pending.push(bytes);
        return;
      }
      if (!gotData) {
        if (sentSize + bytes.byteLength <= 65536) { sentChunks.push(bytes); sentSize += bytes.byteLength; }
        else replayable = false;
      }
      const w = remoteWriter;
      try {
        await w.write(bytes);
      } catch (e) {
        // Stream closed while waiting on ProxyIP or during failover: buffer if replayable instead of crashing WS
        if (!closed && (connecting || (!gotData && viaProxy && replayable && retries < 3))) {
          if (pending.length < 256) pending.push(bytes);
          return;
        }
        throw e;
      }
    };

    const sendRemote = (bytes) => {
      writeChain = writeChain.then(() => writeToCurrent(bytes));
      return writeChain;
    };

    const flushPending = async () => {
      while (pending.length && !closed && remoteWriter && !connecting) {
        const chunk = pending.shift();
        await writeToCurrent(chunk);
      }
    };

    const pipeRemote = (sock) => {
      (async () => {
        const reader = sock.readable.getReader();
        try {
          while (true) {
            const { value, done } = await reader.read();
            if (done) break;
            if (value && value.byteLength > 0) {
              if (!gotData) { gotData = true; if (viaProxy && currentProxy) goodProxy = currentProxy; }
              rxTotal += value.byteLength;
              server.send(value);
            }
          }
        } catch (e) {}
        // ProxyIP accepted the connection but never answered -> mark it bad and try the next one
        if (!gotData && viaProxy && sock === remoteSocket && !closed && replayable && retries < 3) {
          retries++;
          try { server.send(JSON.stringify({ type: "INFO", event: "proxy-dead", proxy: currentProxy })); } catch {}
          markBad(currentProxy);
          connecting = true;
          releaseWriter();
          try {
            await attach(true);
            for (const c of sentChunks) {
              if (closed || !remoteWriter) break;
              await remoteWriter.write(c);
            }
            connecting = false;
            await flushPending();
            return;
          } catch (e) {
            connecting = false;
          }
        }
        if (sock === remoteSocket) {
          try { server.send(JSON.stringify({ type: "INFO", event: "remote-end", rx: rxTotal, route: viaProxy ? "proxy" : "direct" })); } catch {}
          cleanup();
        }
      })();
    };

    const attach = async (useProxy) => {
      const candidates = useProxy
        ? getProxyList(env, target.proxyip).slice(0, 3).map(e => parseHostPort(e, target.port))
        : [{ hostname: target.host, port: target.port, key: "" }];
      let lastErr = null;
      const tried = [];
      for (const c of candidates) {
        if (closed) throw new Error("ws closed");
        try {
          const s = connect({ hostname: c.hostname, port: c.port });
          await openWithTimeout(s, 2500);
          releaseWriter();
          try { remoteSocket?.close(); } catch {}
          remoteSocket = s;
          remoteWriter = s.writable.getWriter();
          viaProxy = useProxy;
          currentProxy = c.key;
          pipeRemote(s);
          return;
        } catch (e) { lastErr = e; tried.push(c.hostname + ":" + c.port); markBad(c.key); }
      }
      throw new Error((useProxy ? "ProxyIP failed [" : "direct failed [") + tried.join(", ") + "] " + (lastErr ? lastErr.message : ""));
    };

    const doConnect = async (host, port, proxyip, force, sni) => {
      target = { host, port: Number(port), proxyip: proxyip || "" };
      sniName = sni || "";
      connecting = true;
      const t0 = Date.now();
      try {
        if (force) {
          try {
            await attach(true);
          } catch (e) {
            directFail = "force-proxy failed, using direct: " + String(e && e.message ? e.message : e).slice(0, 100);
            await attach(false);
          }
        } else {
          try {
            await attach(false);
          } catch (e) {
            directFail = String(e && e.message ? e.message : e).slice(0, 140);
            await attach(true);
          }
        }
        server.send(JSON.stringify({
          type: "CONNECTED",
          route: viaProxy ? "proxy" : "direct",
          via: viaProxy ? currentProxy : "",
          ms: Date.now() - t0,
          directFail: directFail
        }));
      } finally {
        connecting = false;
      }
      await flushPending();
    };

    server.addEventListener("message", async (event) => {
      try {
        if (typeof event.data === "string") {
          const ctrl = JSON.parse(event.data);
          if (ctrl.type === "PING") {
            server.send(JSON.stringify({ type: "PONG", ts: Date.now() }));
            return;
          }
          if (ctrl.type === "CONNECT" && ctrl.host && ctrl.port && !remoteSocket && !connecting) {
            await doConnect(ctrl.host, ctrl.port, ctrl.proxyip, ctrl.forceProxy === true, ctrl.sni);
          }
        } else {
          const bytes = await toBytes(event.data);
          if (!remoteWriter || connecting) {
            if (pending.length < 256) pending.push(bytes);
            return;
          }
          await sendRemote(bytes);
        }
      } catch (err) {
        try { server.send(JSON.stringify({ type: "ERROR", message: String(err) })); } catch {}
        cleanup();
      }
    });

    server.addEventListener("close", cleanup);
    server.addEventListener("error", cleanup);

    return new Response(null, { status: 101, webSocket: client });
  }
};

// ---- single entry point ----
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/ping" || url.searchParams.get("ping") === "1") {
      return new Response(JSON.stringify({
        ok: true, edge: "cf-worker-ws", ver: "v8-stable", tgx: "tgx-1",
        tgxMode: (env && env.TGX) ? "durable-object" : "memory",
        colo: (request.cf && request.cf.colo) || "", country: (request.cf && request.cf.country) || "", ts: Date.now()
      }), { headers: { "content-type": "application/json" } });
    }
    if (url.pathname.startsWith("/__tgx/")) return tgxHandler.fetch(request, env);
    return wsHandler.fetch(request, env);
  }
};
