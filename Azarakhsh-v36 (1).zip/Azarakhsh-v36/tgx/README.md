# Unified Cloudflare Worker (WebSocket tunnel + TGX)

tgx/worker-unified.js is the ONE worker the app generates (Scripts guide -> "ورکر کلودفلر (WS + TGX)").
- WebSocket TCP tunnel (old CF-WS path) and /__tgx/o|x|c session API (GAS -> Worker -> raw TCP) in the same file.
- /ping reports edge "cf-worker-ws" plus tgx / tgxMode.
- Optional Durable Object: binding TGX, class TgxSession.
- tgx/test.mjs: logic test with a fake socket. Generate tgx_test_worker.mjs from worker-unified.js (swap the cloudflare:sockets import for a node:net based connect, secret "sek", ALLOW_ANY_HOST=true).
Kotlin was never compiled and nothing was run against a real Worker/GAS. See CHANGELOG v36.
