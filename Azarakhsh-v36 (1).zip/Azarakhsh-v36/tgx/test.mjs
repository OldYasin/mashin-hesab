import net from 'node:net';
import worker, { TgxSession } from './tgx_test_worker.mjs';

// echo-ish server: replies "R:"+data, and after receiving "BYE" closes
const srv = net.createServer((c) => {
  c.on('data', (d) => { if (d.toString().includes('BYE')) { c.end(Buffer.from('R:BYE')); return; } c.write(Buffer.concat([Buffer.from('R:'), d])); });
});
await new Promise(r => srv.listen(0, '127.0.0.1', r));
globalThis.__ECHO_PORT = srv.address().port;

const BASE = 'https://w.example/__tgx/';
const H = { 'X-Tunnel-Auth': 'sek' };
function parse(buf) {
  const b = new Uint8Array(buf);
  const rd = (o) => { let v = 0; for (let i = 0; i < 8; i++) v = v * 256 + b[o + i]; return v; };
  return { flags: b[0], upAck: rd(1), dnStart: rd(9), data: Buffer.from(b.subarray(17)).toString() };
}
async function call(path, body, env) {
  const r = await worker.fetch(new Request(BASE + path, { method: 'POST', headers: H, body }), env);
  if (r.status !== 200) return { status: r.status };
  return parse(await r.arrayBuffer());
}
function assert(c, m) { if (!c) { console.log('FAIL:', m); process.exitCode = 1; } else console.log('ok:', m); }

// auth
let r = await worker.fetch(new Request(BASE + 'x?sid=abcdefgh', { method: 'POST' }), {});
assert(r.status === 403, 'unauthorized rejected');

// host not allowed
let o = await call('o?sid=sess0001&h=1.1.1.1&p=443&uo=0', new Uint8Array(0), {});
assert(o.flags & 2, 'non-telegram host rejected');

for (const mode of ['memory', 'do']) {
  let env = {};
  if (mode === 'do') {
    const objs = new Map();
    env = { TGX: { idFromName: (n) => n, get: (id) => { if (!objs.has(id)) objs.set(id, new TgxSession({}, {})); return { fetch: (req) => objs.get(id).fetch(req) }; } } };
  }
  const sid = 'sid' + mode + '12345';
  console.log('--- mode', mode);
  o = await call(`o?sid=${sid}&h=149.154.167.51&p=443`, Buffer.from('HELLO'), env);
  assert(o.flags === 0 && o.upAck === 5, 'open ok, initial bytes written upAck=5');

  let x = await call(`x?sid=${sid}&uo=5&dn=0&w=2000&m=1000`, Buffer.from(''), env);
  assert(x.data === 'R:HELLO' && x.dnStart === 0, 'poll got R:HELLO');

  // out-of-order: send uo=20 (gap) first
  x = await call(`x?sid=${sid}&uo=20&dn=7&w=0`, Buffer.from('zzz'), env);
  assert(x.flags & 8 && x.upAck === 5, 'gap detected, upAck stays 5');

  x = await call(`x?sid=${sid}&uo=5&dn=7&w=1500`, Buffer.from('AB'), env);
  console.log(JSON.stringify(x)); assert(x.upAck === 7 && x.data === 'R:AB' && x.dnStart === 7, 'send AB, got R:AB piggybacked/waited');

  // duplicate/overlap resend (retry from another node): uo=5 resend "ABCD" -> only "CD" new
  x = await call(`x?sid=${sid}&uo=5&dn=11&w=1500`, Buffer.from('ABCD'), env);
  console.log(JSON.stringify(x)); assert(x.upAck === 9 && x.data === 'R:CD', 'overlap deduped, only CD forwarded');

  // re-ack old dn (retry of lost response): ask again from dn=7 -> should re-deliver buffered? (already trimmed up to 11 -> start 11)
  x = await call(`x?sid=${sid}&uo=9&dn=0&w=0`, Buffer.from(''), env);
  assert(x.dnStart === 11 || x.data.length >= 0, 'stale ack handled without crash');

  // big payload
  const big = Buffer.alloc(300000, 65);
  x = await call(`x?sid=${sid}&uo=9&dn=11&w=2000&m=524288`, big, env);
  let got = x.data.length; let dn = x.dnStart + x.data.length;
  for (let i = 0; i < 20 && got < 300002; i++) { const y = await call(`x?sid=${sid}&uo=${9 + 300000}&dn=${dn}&w=500&m=524288`, Buffer.from(''), env); got += y.data.length; dn = y.dnStart + y.data.length; }
  assert(x.upAck === 300009 && got === 300002, 'big upstream 300KB echoed back fully (' + got + ')');

  // EOF
  x = await call(`x?sid=${sid}&uo=300009&dn=${dn}&w=1500`, Buffer.from('BYE'), env);
  let eof = x.flags & 1; let d2 = x.data;
  if (!eof) { const y = await call(`x?sid=${sid}&uo=300012&dn=${x.dnStart + x.data.length}&w=1500`, Buffer.from(''), env); eof = y.flags & 1; d2 += y.data; }
  assert(eof && d2.includes('R:BYE'), 'remote close -> EOF flag after delivering data');

  const c = await call(`c?sid=${sid}`, Buffer.from(''), env);
  assert(c.flags & 1, 'close ok');
  const n = await call(`x?sid=${sid}&uo=0&dn=0&w=0`, Buffer.from(''), env);
  assert(n.flags & 4, 'NOSESSION after close');
}
srv.close();
setTimeout(() => process.exit(process.exitCode || 0), 100);
