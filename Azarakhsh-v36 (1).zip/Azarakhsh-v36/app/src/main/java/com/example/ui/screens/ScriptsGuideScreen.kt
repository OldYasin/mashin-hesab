package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.scripts.ScriptTemplates
import com.example.ui.components.AppIcons
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily

@Composable
fun ScriptsGuideScreen(
    secretKey: String,
    onRegenerateSecret: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboard = LocalClipboardManager.current
    var selectedScriptType by remember { mutableIntStateOf(0) } // 0 = GAS, 1 = unified CF Worker (WS + TGX)
    var enableEncryption by remember { mutableStateOf(true) }
    var enableGzip by remember { mutableStateOf(true) }

    val codeText = remember(selectedScriptType, secretKey, enableEncryption, enableGzip) {
        if (selectedScriptType == 0) {
            ScriptTemplates.generateGoogleAppsScript(secretKey, enableEncryption, enableGzip)
        } else {
            ScriptTemplates.generateCloudflareWorkerScript(secretKey)
        }
    }

    val guideSteps = remember {
        listOf(
            "گام ۱: ساخت پروژه جدید در Google Apps Script" to
                "به نشانی script.google.com بروید و New Project را بزنید. هیچ نیازی به خرید سرور مجازی (VPS) نیست و کل اجرا روی زیرساخت گوگل انجام می‌شود.",
            "گام ۲: کپی کد تولیدشده با کلید اختصاصی" to
                "کد «اسکریپت گوگل (Code.gs)» را از همین صفحه با کلید امنیتی یکتای خود کپی کرده و جایگزین محتوای پیش‌فرض Code.gs کنید.",
            "گام ۳: انتشار (Deploy) به صورت Web App" to
                "از منوی بالا Deploy > New deployment > Web app را انتخاب کنید. گزینه Execute as را روی Me و Who has access را روی Anyone بگذارید و لینک خروجی (/exec) را کپی کنید.",
            "گام ۴: مصرف موازی چند اسکریپت" to
                "می‌توانید با چند اکانت یا چند پروژه مختلف، ۳ تا ۵ اسکریپت گوگل بسازید و همه را در بخش «سرورهای موازی» اضافه کنید تا سرعت و پایداری چندبرابر شود.",
            "گام ۵ (پیشرفته): وب‌سوکت کلودفلر برای تمام پروتکل‌ها" to
                "برای ترافیک غیر وب (تلگرام، SSH، SOCKS5 کامل) کد «ورکر کلودفلر (worker.js)» را در پنل رایگان Cloudflare Workers قرار دهید تا استریم دوطرفه TCP-over-WebSocket فعال شود.",
            "گام ۶ (قطعی کامل): تونل TGX روی همان ورکر" to
                "ورکر کلودفلر بالا هر دو کار را انجام می‌دهد (وب‌سوکت و TGX)؛ فقط یک ورکر بسازید. این نسخه هر مقصدی را برای TGX مجاز می‌کند تا «تونل کامل TCP» کار کند، پس کلید را محرمانه نگه دارید. برای پایداری بیشتر می‌توانید Durable Object با نام binding برابر TGX و کلاس TgxSession اضافه کنید (اختیاری). سپس در داشبورد «تلگرام هیبریدی» را روشن و آدرس ورکر و همان کلید را وارد کنید.",
            "گام ۷: استخراج آی‌پی تمیز گوگل و اتصال" to
                "در تب سرورها روی «اسکنر آی‌پی گوگل» بزنید تا آی‌پی‌های بدون فیلتر خودکار پیدا شوند؛ سپس به صفحه اصلی برگردید و با یک دکمه متصل شوید."
        )
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Secret Key & Generator Options Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(AppIcons.Code, contentDescription = null, tint = EmeraldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تولیدکننده کد اختصاصی بدون نیاز به VPS", style = MaterialTheme.typography.titleMedium)
                    }

                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("کلید رمزنگاری یکتا (TUNNEL_SECRET)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                    Text(
                                        text = secretKey,
                                        style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                        color = CyanSecondary
                                    )
                                }
                            }
                            OutlinedButton(onClick = onRegenerateSecret) {
                                Icon(AppIcons.AutoFix, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("جدید")
                            }
                        }
                    }

                    if (selectedScriptType == 0) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("رمزنگاری HMAC-SHA256 CTR در اسکریپت", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = enableEncryption, onCheckedChange = { enableEncryption = it })
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("فشرده‌سازی پاسخ GZIP برای شبکه ضعیف", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = enableGzip, onCheckedChange = { enableGzip = it })
                        }
                    }
                }
            }
        }

        // Script Type Switcher + Code Viewer
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = selectedScriptType == 0,
                        onClick = { selectedScriptType = 0 },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                    ) {
                        Text("اسکریپت گوگل (Code.gs)")
                    }
                    SegmentedButton(
                        selected = selectedScriptType == 1,
                        onClick = { selectedScriptType = 1 },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                    ) {
                        Text("ورکر کلودفلر (WS + TGX)")
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (selectedScriptType == 0) "Code.gs • آماده اجرا در گوگل" else "worker.js • یک ورکر برای وب‌سوکت و TGX (قطعی کامل)",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Button(
                                onClick = {
                                    clipboard.setText(AnnotatedString(codeText))
                                    onShowMessage("کد کامل با کلید اختصاصی کپی شد")
                                },
                                modifier = Modifier.testTag("copy_script_button")
                            ) {
                                Icon(AppIcons.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("کپی کد")
                            }
                        }

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = MaterialTheme.shapes.small,
                            color = MaterialTheme.colorScheme.background
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 112.dp)
                                    .clipToBounds()
                            ) {
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                    Text(
                                        text = codeText,
                                        maxLines = 6,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = JetBrainsMonoFontFamily,
                                            fontSize = 11.sp,
                                            lineHeight = 16.sp
                                        ),
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier
                                            .horizontalScroll(rememberScrollState())
                                            .padding(12.dp)
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(52.dp)
                                        .align(Alignment.BottomCenter)
                                        .background(
                                            Brush.verticalGradient(
                                                colors = listOf(
                                                    Color.Transparent,
                                                    MaterialTheme.colorScheme.background.copy(alpha = 0.85f),
                                                    MaterialTheme.colorScheme.background
                                                )
                                            )
                                        )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Step-by-Step Guide Header
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(AppIcons.MenuBook, contentDescription = null, tint = CyanSecondary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("راهنمای کامل راه‌اندازی (قدم به قدم)", style = MaterialTheme.typography.titleMedium)
            }
        }

        itemsIndexed(guideSteps) { index, (title, body) ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Surface(
                        modifier = Modifier.size(28.dp),
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "${index + 1}",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(text = title, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = body,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
