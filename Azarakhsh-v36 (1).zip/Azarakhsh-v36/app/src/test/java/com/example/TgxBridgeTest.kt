package com.example

import com.example.network.TgxBridge
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TgxBridgeTest {

    private fun reply(flags: Int, upAck: Long, dnStart: Long, data: ByteArray): ByteArray {
        val out = ByteArray(17 + data.size)
        out[0] = flags.toByte()
        for (i in 0 until 8) out[1 + i] = (upAck shr (56 - 8 * i)).toByte()
        for (i in 0 until 8) out[9 + i] = (dnStart shr (56 - 8 * i)).toByte()
        System.arraycopy(data, 0, out, 17, data.size)
        return out
    }

    @Test
    fun parseReplyReadsHeaderAndData() {
        val body = reply(TgxBridge.FLAG_EOF or TgxBridge.FLAG_GAP, 0x0102030405L, 0x1122334455L, byteArrayOf(9, 8, 7))
        val r = TgxBridge.parseReply(body)
        assertNotNull(r)
        assertEquals(TgxBridge.FLAG_EOF or TgxBridge.FLAG_GAP, r!!.flags)
        assertEquals(0x0102030405L, r.upAck)
        assertEquals(0x1122334455L, r.dnStart)
        assertArrayEquals(byteArrayOf(9, 8, 7), r.data)
    }

    @Test
    fun parseReplyRejectsShortBodyAndAllowsEmptyData() {
        assertNull(TgxBridge.parseReply(ByteArray(16)))
        val r = TgxBridge.parseReply(reply(0, 5, 6, ByteArray(0)))
        assertNotNull(r)
        assertEquals(0, r!!.data.size)
    }

    @Test
    fun newDownstreamSkipsAlreadyReceivedBytes() {
        val data = byteArrayOf(1, 2, 3, 4, 5)
        assertArrayEquals(data, TgxBridge.newDownstream(10, 10, data))
        assertArrayEquals(byteArrayOf(3, 4, 5), TgxBridge.newDownstream(12, 10, data))
        assertEquals(0, TgxBridge.newDownstream(15, 10, data).size)   // fully duplicate
        assertEquals(0, TgxBridge.newDownstream(9, 10, data).size)    // gap: start is beyond what we have
        assertEquals(0, TgxBridge.newDownstream(0, 0, ByteArray(0)).size)
    }

    @Test
    fun upBufferSnapshotAckAndCompaction() {
        val b = TgxBridge.UpBuffer()
        assertFalse(b.hasPending())
        b.append(byteArrayOf(1, 2, 3, 4))
        b.append(byteArrayOf(5, 6))
        assertTrue(b.hasPending())
        val (off0, bytes0) = b.snapshot(4)
        assertEquals(0L, off0)
        assertArrayEquals(byteArrayOf(1, 2, 3, 4), bytes0)

        b.ackTo(3)
        assertEquals(3L, b.ackedOffset())
        val (off1, bytes1) = b.snapshot(100)
        assertEquals(3L, off1)
        assertArrayEquals(byteArrayOf(4, 5, 6), bytes1)

        b.ackTo(1)                    // never goes backwards
        assertEquals(3L, b.ackedOffset())
        b.ackTo(1000)                 // never past what was appended
        assertEquals(6L, b.ackedOffset())
        assertFalse(b.hasPending())

        repeat(50) { b.append(ByteArray(1000) { i -> i.toByte() }) }
        val (off2, bytes2) = b.snapshot(1_000_000)
        assertEquals(6L, off2)
        assertEquals(50_000, bytes2.size)
    }

    @Test
    fun isTelegramHostMatchesOnlyTelegram() {
        assertTrue(TgxBridge.isTelegramHost("149.154.167.51"))
        assertTrue(TgxBridge.isTelegramHost("91.108.56.100"))
        assertTrue(TgxBridge.isTelegramHost("pluto.web.telegram.org"))
        assertTrue(TgxBridge.isTelegramHost("2001:b28:f23d::a"))
        assertFalse(TgxBridge.isTelegramHost("example.com"))
        assertFalse(TgxBridge.isTelegramHost("8.8.8.8"))
        assertFalse(TgxBridge.isTelegramHost("evil-telegram.org.example.com"))
    }

    @Test
    fun normalizeBaseHandlesSchemesAndSlashes() {
        assertEquals("https://a.workers.dev", TgxBridge.normalizeBase(" https://a.workers.dev/ "))
        assertEquals("https://a.workers.dev", TgxBridge.normalizeBase("wss://a.workers.dev"))
        assertEquals("http://a.dev", TgxBridge.normalizeBase("ws://a.dev"))
        assertEquals("https://a.workers.dev", TgxBridge.normalizeBase("a.workers.dev"))
        assertEquals("", TgxBridge.normalizeBase("  "))
    }
}
