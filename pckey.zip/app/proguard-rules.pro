-keep class com.example.MainActivity { *; }
-keep class com.example.ime.PCKeyInputMethodService { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-dontwarn org.bouncycastle.**
-dontwarn org.conscrypt.**
-dontwarn org.openjsse.**
