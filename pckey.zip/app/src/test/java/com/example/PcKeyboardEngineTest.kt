package com.example

import android.content.Context
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.test.core.app.ApplicationProvider
import com.example.data.KeyboardLanguage
import com.example.data.KeyboardSettings
import com.example.data.SettingsRepository
import com.example.data.TabBehavior
import com.example.ime.engine.PcInputController
import com.example.ime.engine.SandboxEditorTarget
import com.example.ime.model.KeyAction
import com.example.ime.model.ModifierState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PcKeyboardEngineTest {

    private lateinit var context: Context
    private lateinit var repo: SettingsRepository
    private lateinit var target: SandboxEditorTarget
    private lateinit var controller: PcInputController
    private val defaultSettings = KeyboardSettings(autoCapitalize = false)

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        repo = SettingsRepository.getInstance(context)
        target = SandboxEditorTarget(context, repo)
        target.updateFromField(TextFieldValue("", TextRange(0)))
        controller = PcInputController(targetProvider = { target })
        controller.setInitialLanguage(KeyboardLanguage.ENGLISH, defaultSettings)
    }

    @Test
    fun `ctrl copy paste cut select all undo redo work cleanly`() {
        "hello world".forEach { ch ->
            controller.onKeyAction(KeyAction.Text(ch.toString()), defaultSettings)
        }
        assertEquals("hello world", target.value.value.text)

        // Ctrl + A
        controller.onKeyAction(KeyAction.CtrlToggle, defaultSettings)
        controller.onKeyAction(KeyAction.Text("a"), defaultSettings)
        assertEquals(TextRange(0, 11), target.value.value.selection)

        // Ctrl + C
        controller.onKeyAction(KeyAction.CtrlToggle, defaultSettings)
        controller.onKeyAction(KeyAction.Text("c"), defaultSettings)

        // Move to end and space then Ctrl + V
        controller.onKeyAction(KeyAction.End, defaultSettings)
        controller.onKeyAction(KeyAction.Text(" "), defaultSettings)
        controller.onKeyAction(KeyAction.CtrlToggle, defaultSettings)
        controller.onKeyAction(KeyAction.Text("v"), defaultSettings)
        assertEquals("hello world hello world", target.value.value.text)

        // Ctrl + Z (Undo paste)
        controller.onKeyAction(KeyAction.CtrlToggle, defaultSettings)
        controller.onKeyAction(KeyAction.Text("z"), defaultSettings)
        assertEquals("hello world ", target.value.value.text)

        // Ctrl + Y (Redo paste)
        controller.onKeyAction(KeyAction.CtrlToggle, defaultSettings)
        controller.onKeyAction(KeyAction.Text("y"), defaultSettings)
        assertEquals("hello world hello world", target.value.value.text)
    }

    @Test
    fun `ctrl backspace and home end shift selection behave like pc`() {
        target.updateFromField(TextFieldValue("first line\nsecond word here", TextRange(27)))

        // Ctrl + Backspace deletes "here"
        controller.onKeyAction(KeyAction.CtrlToggle, defaultSettings)
        controller.onKeyAction(KeyAction.Backspace, defaultSettings)
        assertEquals("first line\nsecond word ", target.value.value.text)

        // Home moves to start of second line (index 11)
        controller.onKeyAction(KeyAction.Home, defaultSettings)
        assertEquals(TextRange(11), target.value.value.selection)

        // Shift + Ctrl + ArrowRight selects "second"
        controller.onKeyAction(KeyAction.ShiftToggle, defaultSettings)
        controller.onKeyAction(KeyAction.CtrlToggle, defaultSettings)
        controller.onKeyAction(KeyAction.ArrowRight, defaultSettings)
        assertEquals(TextRange(11, 17), target.value.value.selection)
    }

    @Test
    fun `tab behavior and zwnj and ctrl space language switch work`() {
        val spacesSettings = defaultSettings.copy(tabBehavior = TabBehavior.SPACES_4)
        controller.onKeyAction(KeyAction.Tab, spacesSettings)
        assertEquals("    ", target.value.value.text)

        // Ctrl + Space switches to Persian
        controller.onKeyAction(KeyAction.CtrlToggle, spacesSettings)
        controller.onKeyAction(KeyAction.Space, spacesSettings)
        assertEquals(KeyboardLanguage.PERSIAN, controller.uiState.value.language)
        assertEquals(ModifierState.OFF, controller.uiState.value.ctrlState)

        // ZWNJ inserts \u200C
        controller.onKeyAction(KeyAction.Text("می"), spacesSettings)
        controller.onKeyAction(KeyAction.Zwnj, spacesSettings)
        controller.onKeyAction(KeyAction.Text("خواهم"), spacesSettings)
        assertTrue(target.value.value.text.endsWith("می\u200Cخواهم"))
    }

    @Test
    fun `ten thousand lines select all copy clear and paste works cleanly`() {
        target.insertTenThousandLinesSample()
        val originalLen = target.value.value.text.length
        assertTrue(originalLen > 200_000)

        controller.onKeyAction(KeyAction.SelectAllShortcut, defaultSettings)
        assertEquals(TextRange(0, originalLen), target.value.value.selection)

        controller.onKeyAction(KeyAction.CopyShortcut, defaultSettings)
        target.clearText()
        assertEquals("", target.value.value.text)

        controller.onKeyAction(KeyAction.PasteShortcut, defaultSettings)
        assertEquals(originalLen, target.value.value.text.length)
    }

    @Test
    fun `wide persian layout matches screenshot rows and pc panel and hide callbacks work`() {
        val wideSettings = defaultSettings.copy(widePersianKeys = true)
        val rows = com.example.ime.model.KeyboardLayouts.buildRows(
            mode = com.example.ime.model.KeyboardMode.LETTERS,
            language = KeyboardLanguage.PERSIAN,
            shiftState = ModifierState.OFF,
            settings = wideSettings,
        )
        assertEquals(4, rows.size)
        assertEquals(11, rows[0].size) // ض..چ
        assertEquals(11, rows[1].size) // ش..گ
        assertEquals(11, rows[2].size) // ظ..ث + Backspace
        assertEquals(7, rows[3].size)  // #+=, 123, ،, Space, ., يـ, Enter

        var hiddenCalled = false
        val panelController = PcInputController(
            targetProvider = { target },
            onHideKeyboard = { hiddenCalled = true },
        )
        assertEquals(false, panelController.uiState.value.pcPanelOpen)
        panelController.togglePcPanel()
        assertEquals(true, panelController.uiState.value.pcPanelOpen)
        panelController.togglePcPanel()
        assertEquals(false, panelController.uiState.value.pcPanelOpen)

        panelController.hideKeyboard()
        assertTrue(hiddenCalled)
    }
}
