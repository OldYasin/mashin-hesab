package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.KeyboardSettings
import com.example.ui.components.PCKeyIcons
import com.example.ui.components.SettingSwitchRow
import com.example.ui.components.SettingsSectionHeader

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FeaturesScreen(
    settings: KeyboardSettings,
    onUpdateSettings: ((KeyboardSettings) -> KeyboardSettings) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 640.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            text = "پروفیل‌های آماده",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = "با یک لمس همه قابلیت‌ها را متناسب با نیاز خود تنظیم کنید یا تک‌تک ماژول‌ها را از پایین فعال و غیرفعال نمایید.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            FilledTonalButton(
                                onClick = {
                                    onUpdateSettings {
                                        it.copy(
                                            enableTopUtilityBar = true,
                                            showPcToolbar = true,
                                            enableFnToggle = true,
                                            enableNumpadMode = true,
                                            enableQuickCopyPasteButtons = true,
                                            enableUndoRedoButtons = true,
                                            clipboardHistoryEnabled = true,
                                            enableEmojiPanel = true,
                                            showNumberRow = true,
                                            showZwnjKey = true,
                                            widePersianKeys = true,
                                            enableSpaceSwipe = true,
                                            backspaceWordSwipeEnabled = true,
                                        )
                                    }
                                },
                                modifier = Modifier.testTag("preset_full_pc"),
                            ) {
                                Text("همه قابلیت‌ها (کامل)")
                            }
                            FilledTonalButton(
                                onClick = {
                                    onUpdateSettings {
                                        it.copy(
                                            enableTopUtilityBar = true,
                                            showPcToolbar = false,
                                            enableFnToggle = false,
                                            showFunctionRow = false,
                                            enableNumpadMode = false,
                                            enableQuickCopyPasteButtons = true,
                                            enableUndoRedoButtons = false,
                                            clipboardHistoryEnabled = true,
                                            enableEmojiPanel = true,
                                            showNumberRow = false,
                                            showZwnjKey = true,
                                            widePersianKeys = true,
                                        )
                                    }
                                },
                                modifier = Modifier.testTag("preset_minimal"),
                            ) {
                                Text("سبک و خلوت")
                            }
                            FilledTonalButton(
                                onClick = {
                                    onUpdateSettings {
                                        it.copy(
                                            enableTopUtilityBar = true,
                                            showPcToolbar = true,
                                            enableFnToggle = true,
                                            showFunctionRow = true,
                                            enableNumpadMode = true,
                                            enableQuickCopyPasteButtons = true,
                                            enableUndoRedoButtons = true,
                                            clipboardHistoryEnabled = true,
                                            showNumberRow = true,
                                            enableSpaceSwipe = true,
                                            backspaceWordSwipeEnabled = true,
                                        )
                                    }
                                },
                                modifier = Modifier.testTag("preset_coding"),
                            ) {
                                Text("برنامه‌نویسی / ترمینال")
                            }
                        }
                    }
                }

                SettingsSectionHeader(
                    title = "نوارها و ماژول‌های پیسی",
                    icon = PCKeyIcons.Tune,
                )

                SettingSwitchRow(
                    title = "نوار ابزار بالایی (Utility Bar)",
                    subtitle = "نمایش نوار دسترسی سریع در بالاترین بخش کیبورد",
                    checked = settings.enableTopUtilityBar,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(enableTopUtilityBar = v) } },
                    testTag = "feat_top_bar",
                )

                SettingSwitchRow(
                    title = "نوار کلیدهای پیسی (Ctrl, Alt, Esc, Tab, Arrows)",
                    subtitle = "دسترسی مستقیم به کلیدهای کنترلی، فلش‌ها، Home، End، PgUp/PgDn و Del",
                    checked = settings.showPcToolbar,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(showPcToolbar = v) } },
                    testTag = "feat_pc_bar",
                )

                SettingSwitchRow(
                    title = "کلیدهای تابعی (F1 تا F12)",
                    subtitle = "فعال بودن دکمه Fn و ردیف کامل کلیدهای F1–F12",
                    checked = settings.enableFnToggle,
                    onCheckedChange = { v ->
                        onUpdateSettings {
                            it.copy(enableFnToggle = v, showFunctionRow = if (!v) false else it.showFunctionRow)
                        }
                    },
                    testTag = "feat_fn",
                )

                SettingSwitchRow(
                    title = "صفحه ماشین‌حساب (Numpad)",
                    subtitle = "دسترسی به حالت Numpad پیسی همراه با عملگرهای ریاضی و Tab",
                    checked = settings.enableNumpadMode,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(enableNumpadMode = v) } },
                    testTag = "feat_numpad",
                )

                SettingSwitchRow(
                    title = "ردیف اعداد همیشگی (۱ تا ۰)",
                    subtitle = "نمایش ردیف مجزای اعداد در بالای حروف",
                    checked = settings.showNumberRow,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(showNumberRow = v) } },
                    testTag = "feat_number_row",
                )

                SettingsSectionHeader(
                    title = "ابزارهای سریع کپی، پیست و پنل‌ها",
                    icon = PCKeyIcons.Bolt,
                )

                SettingSwitchRow(
                    title = "دکمه‌های تک‌لمسی All / Copy / Paste",
                    subtitle = "دکمه‌های سریع برای انتخاب، کپی و پیست فوری حتی تا ۱۰ هزار خط",
                    checked = settings.enableQuickCopyPasteButtons,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(enableQuickCopyPasteButtons = v) } },
                    testTag = "feat_quick_cp",
                )

                SettingSwitchRow(
                    title = "دکمه‌های سریع Undo / Redo",
                    subtitle = "برگشت به عقب و تکرار حرکت روی نوار ابزار",
                    checked = settings.enableUndoRedoButtons,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(enableUndoRedoButtons = v) } },
                    testTag = "feat_undo_redo",
                )

                SettingSwitchRow(
                    title = "تاریخچه کلیپ‌بورد هوشمند",
                    subtitle = "ذخیره خودکار متن‌های کپی‌شده و امکان سنجاق کردن در پنل کلیپ‌بورد",
                    checked = settings.clipboardHistoryEnabled,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(clipboardHistoryEnabled = v) } },
                    testTag = "feat_clipboard",
                )

                SettingSwitchRow(
                    title = "ذخیرهٔ پسورد و کپی‌های حساس",
                    subtitle = "متن‌هایی که برنامه‌ها «حساس» علامت می‌زنند یا از فیلد پسورد کپی می‌شوند هم در تاریخچه ذخیره شوند",
                    checked = settings.saveSensitiveClips,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(saveSensitiveClips = v) } },
                    testTag = "feat_save_sensitive",
                )

                SettingSwitchRow(
                    title = "پنل ایموجی و کایموجی",
                    subtitle = "نمایش آیکون و پنل دسته‌بندی ایموجی‌ها",
                    checked = settings.enableEmojiPanel,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(enableEmojiPanel = v) } },
                    testTag = "feat_emoji",
                )

                SettingsSectionHeader(
                    title = "راحتی تایپ فارسی و ژست‌ها",
                    icon = PCKeyIcons.Keyboard,
                )

                SettingSwitchRow(
                    title = "دکمه‌های پهن و راحت فارسی",
                    subtitle = "پهن‌تر شدن کلیدهای فارسی (حداکثر ۱۱ کلید در ردیف) برای تایپ سریع‌تر و بدون خطا",
                    checked = settings.widePersianKeys,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(widePersianKeys = v) } },
                    testTag = "feat_wide_persian",
                )

                SettingSwitchRow(
                    title = "کلید اختصاصی نیم‌فاصله (ZWNJ)",
                    subtitle = "نمایش کلید نیم‌فاصله کنار Space در حالت فارسی",
                    checked = settings.showZwnjKey,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(showZwnjKey = v) } },
                    testTag = "feat_zwnj",
                )

                SettingSwitchRow(
                    title = "ژست کشیدن انگشت روی Space",
                    subtitle = "جابجایی روان مکان‌نما (Trackpad) یا تغییر زبان با کشیدن روی Space",
                    checked = settings.enableSpaceSwipe,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(enableSpaceSwipe = v) } },
                    testTag = "feat_space_swipe",
                )

                SettingSwitchRow(
                    title = "حذف سریع کلمه با کشیدن Backspace",
                    subtitle = "با کشیدن انگشت از دکمه پاک‌کن به چپ، یک کلمه کامل پاک می‌شود",
                    checked = settings.backspaceWordSwipeEnabled,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(backspaceWordSwipeEnabled = v) } },
                    testTag = "feat_bsp_swipe",
                )

                SettingSwitchRow(
                    title = "پیش‌نمایش حبابی حروف (Popup)",
                    subtitle = "نمایش بزرگ‌تر حرف بالای انگشت هنگام لمس کلید",
                    checked = settings.keyPopupEnabled,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(keyPopupEnabled = v) } },
                    testTag = "feat_popup",
                )

                SettingSwitchRow(
                    title = "لرزش کلیدها (Haptic Feedback)",
                    subtitle = "بازخورد لرزشی دقیق هنگام تایپ",
                    checked = settings.hapticEnabled,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(hapticEnabled = v) } },
                    testTag = "feat_haptic",
                )

                SettingSwitchRow(
                    title = "صدای کلیک کلیدها",
                    subtitle = "افکت صوتی سبک هنگام فشردن کلیدها",
                    checked = settings.soundEnabled,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(soundEnabled = v) } },
                    testTag = "feat_sound",
                )
            }
        }
    }
}
