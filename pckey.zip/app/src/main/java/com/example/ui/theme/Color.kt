package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF0B1016)
val ObsidianSurface = Color(0xFF111822)
val ObsidianSurfaceHigh = Color(0xFF1A2433)
val ObsidianSurfaceHighest = Color(0xFF233044)
val ObsidianOutline = Color(0xFF2E3D52)

val CyanPrimary = Color(0xFF38BDF8)
val CyanOnPrimary = Color(0xFF041C2B)
val CyanContainer = Color(0xFF0C364F)
val CyanOnContainer = Color(0xFFBFE9FF)

val AmberSecondary = Color(0xFFF59E0B)
val AmberOnSecondary = Color(0xFF261600)
val AmberContainer = Color(0xFF4B3000)
val AmberOnContainer = Color(0xFFFFDDA6)

val EmeraldTertiary = Color(0xFF34D399)
val EmeraldOnTertiary = Color(0xFF022619)

val LightBg = Color(0xFFF4F6FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceHigh = Color(0xFFE9EEF5)
val LightOutline = Color(0xFFCBD5E1)
val LightPrimary = Color(0xFF0284C7)
val LightSecondary = Color(0xFFD97706)
