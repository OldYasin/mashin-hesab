package com.example.ui

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.text.Editable
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import com.example.data.ClipboardEntry
import com.example.data.KeyboardSettings
import com.example.data.SettingsRepository
import com.example.ime.PCKeyInputMethodService
import com.example.ime.engine.KeyboardUiState
import com.example.ime.engine.PcInputController
import com.example.ime.engine.SandboxEditorTarget
import com.example.ime.engine.SandboxStats
import com.example.ime.ui.KeyboardFeedback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

@Immutable
data class ImeStatus(
    val isEnabled: Boolean = false,
    val isSelected: Boolean = false,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository = SettingsRepository.getInstance(application)
    val settings: StateFlow<KeyboardSettings> = repository.settings
    val clipboardEntries: StateFlow<List<ClipboardEntry>> = repository.clipboardEntries

    val feedback = KeyboardFeedback(application)
    private val sandboxTarget = SandboxEditorTarget(application, repository)
    val sandboxStats: StateFlow<SandboxStats> = sandboxTarget.stats
    val sandboxLastEvent: StateFlow<String?> = sandboxTarget.lastEvent

    val sandboxController = PcInputController(
        targetProvider = { sandboxTarget },
        onClipboardPasteText = { text -> sandboxTarget.pasteDirectOptimized(text) },
    ).apply {
        setInitialLanguage(settings.value.defaultLanguage, settings.value)
    }
    val sandboxKeyboardState: StateFlow<KeyboardUiState> = sandboxController.uiState

    private val _imeStatus = MutableStateFlow(ImeStatus())
    val imeStatus: StateFlow<ImeStatus> = _imeStatus.asStateFlow()

    init {
        refreshImeStatus()
    }

    fun refreshImeStatus() {
        val context = getApplication<Application>()
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        val expectedComponent = ComponentName(context, PCKeyInputMethodService::class.java)
        val enabledList = imm?.enabledInputMethodList.orEmpty()
        val isEnabled = enabledList.any {
            it.packageName == context.packageName || it.component == expectedComponent
        }
        val currentDefault = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.DEFAULT_INPUT_METHOD,
        )
        val isSelected = currentDefault == expectedComponent.flattenToShortString() ||
            currentDefault == expectedComponent.flattenToString()
        _imeStatus.value = ImeStatus(isEnabled = isEnabled, isSelected = isSelected)
    }

    fun attachSandboxEditText(editText: EditText) {
        sandboxTarget.attachEditText(editText)
    }

    fun detachSandboxEditText(editText: EditText) {
        sandboxTarget.detachEditText(editText)
    }

    fun onSandboxEditTextChanged(editable: Editable, selStart: Int, selEnd: Int) {
        sandboxTarget.onEditTextChanged(editable, selStart, selEnd)
    }

    fun onSandboxSelectionChanged(editText: EditText) {
        sandboxTarget.refreshStatsFromEditText(editText)
    }

    fun insertTenThousandLinesSample() {
        sandboxTarget.insertTenThousandLinesSample()
    }

    fun clearSandboxText() {
        sandboxTarget.clearText()
    }

    fun updateSettings(transform: (KeyboardSettings) -> KeyboardSettings) {
        repository.updateSettings(transform)
        sandboxController.syncLanguageWithSettings(repository.settings.value)
    }
}
