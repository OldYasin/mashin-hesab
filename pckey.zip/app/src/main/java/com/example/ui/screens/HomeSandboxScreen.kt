package com.example.ui.screens

import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.widget.EditText
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.data.ClipboardEntry
import com.example.data.KeyboardSettings
import com.example.ime.engine.KeyboardUiState
import com.example.ime.engine.PcInputController
import com.example.ime.engine.SandboxStats
import com.example.ime.ui.KeyboardFeedback
import com.example.ime.ui.KeyboardView
import com.example.ui.ImeStatus
import com.example.ui.components.PCKeyIcons
import com.example.ui.components.SettingsSectionHeader
import com.example.ui.theme.JetBrainsMonoFontFamily

private data class ShortcutDoc(
    val combo: String,
    val desc: String,
)

private val pcShortcuts = listOf(
    ShortcutDoc("All / Copy / Paste", "انتخاب، کپی و پیست تک‌لمسی حتی تا ۱۰ هزار خط بدون لگ"),
    ShortcutDoc("Ctrl + C / X / V", "کپی، برش و جای‌گذاری مستقیم + ذخیره در کلیپ‌بورد"),
    ShortcutDoc("Ctrl + Z / Y", "برگشت به عقب (Undo) و انجام مجدد (Redo)"),
    ShortcutDoc("Ctrl + Backspace", "حذف سریع یک کلمه کامل به عقب (یا کشیدن به چپ روی پاک‌کن)"),
    ShortcutDoc("Ctrl + ← / →", "پرش مکان‌نما کلمه به کلمه"),
    ShortcutDoc("Shift + ← ↑ ↓ →", "انتخاب دقیق متن با کلیدهای جهت"),
    ShortcutDoc("Home / End / Del", "ابتدا و انتهای خط + حذف کاراکتر جلویی"),
    ShortcutDoc("Fn / F1–F12 / Esc / Tab", "ردیف کامل کلیدهای تابعی و کنترلی پیسی"),
    ShortcutDoc("Space Trackpad", "کشیدن انگشت روی Space برای حرکت نرم مکان‌نما"),
    ShortcutDoc("نیم‌فاصله (ZWNJ)", "درج مستقیم نیم‌فاصله استاندارد فارسی"),
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeSandboxScreen(
    imeStatus: ImeStatus,
    settings: KeyboardSettings,
    clipboardEntries: List<ClipboardEntry>,
    sandboxStats: SandboxStats,
    lastEvent: String?,
    sandboxUiState: KeyboardUiState,
    sandboxController: PcInputController,
    feedback: KeyboardFeedback,
    onAttachEditText: (EditText) -> Unit,
    onDetachEditText: (EditText) -> Unit,
    onEditTextChanged: (Editable, Int, Int) -> Unit,
    onSelectionChanged: (EditText) -> Unit,
    onInsert10kSample: () -> Unit,
    onClearSandbox: () -> Unit,
    onOpenImeSettings: () -> Unit,
    onPickIme: () -> Unit,
    onResolveClipText: (ClipboardEntry) -> String,
    onTogglePinClip: (String) -> Unit,
    onDeleteClip: (String) -> Unit,
    onClearUnpinnedClips: () -> Unit,
    onOpenAppearanceTab: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var showEmbeddedKeyboard by rememberSaveable { mutableStateOf(false) }

    val textColorArgb = MaterialTheme.colorScheme.onSurface.toArgb()
    val hintColorArgb = MaterialTheme.colorScheme.onSurfaceVariant.toArgb()
    val fieldBgColor = MaterialTheme.colorScheme.surface
    val borderColor = MaterialTheme.colorScheme.outline

    Column(
        modifier = modifier.fillMaxSize(),
    ) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item {
                Column(
                    modifier = Modifier.widthIn(max = 640.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    HeroStatusCard(
                        imeStatus = imeStatus,
                        onOpenImeSettings = onOpenImeSettings,
                        onPickIme = onPickIme,
                    )

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainer,
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = PCKeyIcons.Terminal,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp),
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "میز تست زنده و تست ۱۰ هزار خط",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = onClearSandbox,
                                        modifier = Modifier.testTag("clear_sandbox_button"),
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "پاک کردن متن تست",
                                        )
                                    }
                                }
                            }

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                FilledTonalButton(
                                    onClick = { showEmbeddedKeyboard = !showEmbeddedKeyboard },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("toggle_sandbox_keyboard_button"),
                                ) {
                                    Icon(
                                        imageVector = PCKeyIcons.Keyboard,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (showEmbeddedKeyboard) "بستن کیبورد داخلی" else "باز کردن کیبورد داخلی",
                                        style = MaterialTheme.typography.labelLarge,
                                    )
                                }
                                FilledTonalButton(
                                    onClick = onInsert10kSample,
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                                    ),
                                    modifier = Modifier.testTag("insert_10k_lines_button"),
                                ) {
                                    Icon(
                                        imageVector = PCKeyIcons.Bolt,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = "تولید ۱۰٬۰۰۰ خط",
                                        style = MaterialTheme.typography.labelLarge,
                                    )
                                }
                            }

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                TelemetryChip("Lines: ${sandboxStats.lineCount}")
                                TelemetryChip("Chars: ${sandboxStats.charCount}")
                                TelemetryChip("Cursor: ${sandboxStats.cursorPos}")
                                if (sandboxStats.selectionLength > 0) {
                                    TelemetryChip("Selected: ${sandboxStats.selectionLength}", highlight = true)
                                }
                                if (lastEvent != null) {
                                    TelemetryChip(lastEvent, highlight = true)
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(144.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(fieldBgColor)
                                    .border(1.dp, borderColor, RoundedCornerShape(12.dp))
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                            ) {
                                AndroidView(
                                    factory = { ctx ->
                                        object : EditText(ctx) {
                                            override fun onSelectionChanged(selStart: Int, selEnd: Int) {
                                                super.onSelectionChanged(selStart, selEnd)
                                                onSelectionChanged(this)
                                            }
                                        }.apply {
                                            background = null
                                            gravity = Gravity.TOP or Gravity.START
                                            setTextColor(textColorArgb)
                                            setHintTextColor(hintColorArgb)
                                            hint = "اینجا تایپ کنید یا روی دکمه «تولید ۱۰٬۰۰۰ خط» بزنید و با All / Copy / Paste سرعت را تست کنید..."
                                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                                            typeface = ctx.resources.getIdentifier("shabnam", "font", ctx.packageName)
                                                .takeIf { it != 0 }
                                                ?.let { ResourcesCompat.getFont(ctx, it) }
                                                ?: ResourcesCompat.getFont(ctx, R.font.vazirmatn)
                                            inputType = InputType.TYPE_CLASS_TEXT or
                                                InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                                                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                                            isVerticalScrollBarEnabled = true
                                            setPadding(0, 0, 0, 0)
                                            // Built-in keyboard only appears when the field is touched/focused.
                                            showSoftInputOnFocus = false
                                            setOnTouchListener { v, event ->
                                                if (event.action == android.view.MotionEvent.ACTION_UP) {
                                                    showEmbeddedKeyboard = true
                                                    v.performClick()
                                                }
                                                false
                                            }
                                            setOnFocusChangeListener { _, hasFocus ->
                                                if (hasFocus) showEmbeddedKeyboard = true
                                            }
                                            addTextChangedListener(object : TextWatcher {
                                                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                                                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                                                override fun afterTextChanged(s: Editable?) {
                                                    if (s != null) {
                                                        onEditTextChanged(s, selectionStart, selectionEnd)
                                                    }
                                                }
                                            })
                                            onAttachEditText(this)
                                        }
                                    },
                                    update = { et ->
                                        et.setTextColor(textColorArgb)
                                        et.setHintTextColor(hintColorArgb)
                                    },
                                    onRelease = { et ->
                                        onDetachEditText(et)
                                    },
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag("sandbox_text_field"),
                                )
                            }
                        }
                    }

                    SettingsSectionHeader(
                        title = "قابلیت‌های کیبورد پیسی در PCKey",
                        icon = PCKeyIcons.Keyboard,
                    )

                    pcShortcuts.forEach { doc ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainer,
                            ),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(
                                    text = doc.desc,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(end = 10.dp),
                                )
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                    Surface(
                                        shape = RoundedCornerShape(7.dp),
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                    ) {
                                        Text(
                                            text = doc.combo,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontFamily = JetBrainsMonoFontFamily,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "ساخته‌شده توسط vicious cycle",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                Text(
                                    text = "@WhrAmIGoing",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                    }
                }
            }
        }

        AnimatedVisibility(visible = showEmbeddedKeyboard, enter = expandVertically(), exit = shrinkVertically()) {
            KeyboardView(
                uiState = sandboxUiState,
                settings = settings,
                clipboardEntries = clipboardEntries,
                controller = sandboxController,
                feedback = feedback,
                onResolveClipText = onResolveClipText,
                onTogglePinClip = onTogglePinClip,
                onDeleteClip = onDeleteClip,
                onClearUnpinnedClips = onClearUnpinnedClips,
                onOpenSettings = onOpenAppearanceTab,
                onHideKeyboard = { showEmbeddedKeyboard = false },
            )
        }
    }
}

@Composable
private fun HeroStatusCard(
    imeStatus: ImeStatus,
    onOpenImeSettings: () -> Unit,
    onPickIme: () -> Unit,
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_keyboard_hero),
                    contentDescription = stringResource(id = R.string.hero_banner_desc),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.82f),
                                    MaterialTheme.colorScheme.surfaceContainer,
                                )
                            )
                        ),
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                ) {
                    Text(
                        text = "PCKey — کیبورد استاندارد پیسی",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = "تایپ روان فارسی با دکمه‌های پهن و کلیدهای Ctrl، Alt، Tab، Esc، F1–F12 و Numpad",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                val statusOk = imeStatus.isEnabled && imeStatus.isSelected
                val statusText = when {
                    statusOk -> "وضعیت: فعال و انتخاب‌شده به عنوان کیبورد پیش‌فرض"
                    imeStatus.isEnabled -> "وضعیت: فعال شده — مرحله بعد: انتخاب به عنوان کیبورد فعلی"
                    else -> "وضعیت: هنوز در تنظیمات اندروید فعال نشده است"
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (statusOk) {
                        MaterialTheme.colorScheme.tertiary.copy(alpha = 0.16f)
                    } else {
                        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f)
                    },
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = if (statusOk) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (statusOk) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Medium,
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Button(
                        onClick = onOpenImeSettings,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("enable_ime_button"),
                        shape = RoundedCornerShape(12.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            modifier = Modifier.size(17.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "۱. فعال‌سازی", style = MaterialTheme.typography.labelLarge)
                    }
                    FilledTonalButton(
                        onClick = onPickIme,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("select_ime_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        ),
                    ) {
                        Icon(
                            imageVector = PCKeyIcons.SwapHoriz,
                            contentDescription = null,
                            modifier = Modifier.size(17.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "۲. انتخاب کیبورد", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryChip(
    label: String,
    highlight: Boolean = false,
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (highlight) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceContainerHigh
            },
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontFamily = JetBrainsMonoFontFamily,
                color = if (highlight) {
                    MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
    }
}
