package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.KeyboardLanguage
import com.example.data.KeyboardSettings
import com.example.data.SpaceSwipeMode
import com.example.data.TabBehavior
import com.example.ui.components.PCKeyIcons
import com.example.ui.components.SettingOptionsCard
import com.example.ui.components.SettingSwitchRow
import com.example.ui.components.SettingsSectionHeader

@Composable
fun PcSettingsScreen(
    settings: KeyboardSettings,
    clipboardCount: Int,
    onUpdateSettings: ((KeyboardSettings) -> KeyboardSettings) -> Unit,
    onClearUnpinnedClips: () -> Unit,
    onClearAllClips: () -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 640.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                SettingsSectionHeader(
                    title = "رفتار کلیدهای پیسی (PC Controls)",
                    icon = PCKeyIcons.Terminal,
                )

                SettingSwitchRow(
                    title = "باز بودن پیش‌فرض ردیف F1 تا F12",
                    subtitle = "نمایش ردیف کلیدهای تابعی به صورت دائم هنگام باز شدن کیبورد",
                    checked = settings.showFunctionRow,
                    enabled = settings.enableFnToggle,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(showFunctionRow = v) } },
                    testTag = "switch_fn_row",
                )

                SettingOptionsCard(
                    title = "رفتار کلید Tab",
                    subtitle = settings.tabBehavior.descriptionFa,
                    options = TabBehavior.entries,
                    selected = settings.tabBehavior,
                    labelProvider = { it.titleFa },
                    onSelect = { chosen -> onUpdateSettings { it.copy(tabBehavior = chosen) } },
                    testTagPrefix = "tab_behavior",
                )

                SettingsSectionHeader(
                    title = "رفتار کلید فاصله و میانبرها",
                    icon = PCKeyIcons.Bolt,
                )

                SettingOptionsCard(
                    title = "عملکرد کشیدن انگشت روی Space",
                    subtitle = settings.spaceSwipeMode.descriptionFa,
                    options = SpaceSwipeMode.entries,
                    selected = settings.spaceSwipeMode,
                    labelProvider = { it.titleFa },
                    onSelect = { chosen -> onUpdateSettings { it.copy(spaceSwipeMode = chosen) } },
                    testTagPrefix = "space_swipe",
                )

                SettingSwitchRow(
                    title = "تغییر زبان با Ctrl + Space",
                    subtitle = "سوئیچ سریع بین فارسی و انگلیسی مشابه ویندوز",
                    checked = settings.ctrlSpaceSwitchesLanguage,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(ctrlSpaceSwitchesLanguage = v) } },
                    testTag = "switch_ctrl_space",
                )

                SettingSwitchRow(
                    title = "حروف بزرگ خودکار در اول جمله (English)",
                    subtitle = "فعال‌سازی خودکار Shift در شروع خط یا بعد از نقطه",
                    checked = settings.autoCapitalize,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(autoCapitalize = v) } },
                    testTag = "switch_auto_cap",
                )

                SettingSwitchRow(
                    title = "درج نقطه با دو بار زدن Space",
                    subtitle = "تبدیل دوبار فاصله سریع به نقطه و فاصله در تایپ انگلیسی",
                    checked = settings.doubleSpacePeriod,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(doubleSpacePeriod = v) } },
                    testTag = "switch_double_space",
                )

                SettingsSectionHeader(
                    title = "زبان‌ها و تایپ فارسی",
                    icon = PCKeyIcons.Language,
                )

                SettingSwitchRow(
                    title = "چیدمان پهن و راحت دکمه‌های فارسی",
                    subtitle = "حداکثر ۱۱ کلید در هر ردیف با فاصله تماس صفر برای تایپ فوق‌العاده راحت",
                    checked = settings.widePersianKeys,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(widePersianKeys = v) } },
                    testTag = "switch_wide_persian",
                )

                SettingSwitchRow(
                    title = "فعال بودن کیبورد فارسی",
                    subtitle = "چیدمان استاندارد فارسی همراه با کلیدهای گ، چ، پ، ژ و اعراب با نگه داشتن",
                    checked = settings.enablePersian,
                    enabled = settings.enableEnglish || !settings.enablePersian,
                    onCheckedChange = { v ->
                        if (v || settings.enableEnglish) {
                            onUpdateSettings {
                                val nextDefault = if (!v && it.defaultLanguage == KeyboardLanguage.PERSIAN) {
                                    KeyboardLanguage.ENGLISH
                                } else {
                                    it.defaultLanguage
                                }
                                it.copy(enablePersian = v, defaultLanguage = nextDefault)
                            }
                        }
                    },
                    testTag = "switch_enable_persian",
                )

                SettingSwitchRow(
                    title = "فعال بودن کیبورد انگلیسی (QWERTY)",
                    subtitle = "چیدمان کامل انگلیسی مناسب کدنویسی و متن‌های لاتین",
                    checked = settings.enableEnglish,
                    enabled = settings.enablePersian || !settings.enableEnglish,
                    onCheckedChange = { v ->
                        if (v || settings.enablePersian) {
                            onUpdateSettings {
                                val nextDefault = if (!v && it.defaultLanguage == KeyboardLanguage.ENGLISH) {
                                    KeyboardLanguage.PERSIAN
                                } else {
                                    it.defaultLanguage
                                }
                                it.copy(enableEnglish = v, defaultLanguage = nextDefault)
                            }
                        }
                    },
                    testTag = "switch_enable_english",
                )

                SettingOptionsCard(
                    title = "زبان پیش‌فرض هنگام باز شدن کیبورد",
                    options = buildList {
                        if (settings.enablePersian) add(KeyboardLanguage.PERSIAN)
                        if (settings.enableEnglish) add(KeyboardLanguage.ENGLISH)
                    },
                    selected = settings.defaultLanguage,
                    labelProvider = { it.labelFa },
                    onSelect = { lang -> onUpdateSettings { it.copy(defaultLanguage = lang) } },
                    testTagPrefix = "default_lang",
                )

                SettingSwitchRow(
                    title = "اعداد فارسی در کیبورد فارسی (۱۲۳)",
                    subtitle = "در صورت غیرفعال بودن، در حالت فارسی نیز اعداد انگلیسی (123) تایپ می‌شوند",
                    checked = settings.persianDigitsInPersianMode,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(persianDigitsInPersianMode = v) } },
                    testTag = "switch_persian_digits",
                )

                SettingsSectionHeader(
                    title = "مدیریت کلیپ‌بورد",
                    icon = PCKeyIcons.ContentPaste,
                )

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "آیتم‌های ذخیره‌شده: $clipboardCount",
                                style = MaterialTheme.typography.titleSmall,
                            )
                            Text(
                                text = "پاکسازی کلیپ‌های قدیمی یا کل تاریخچه",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Row {
                            OutlinedButton(
                                onClick = onClearUnpinnedClips,
                                enabled = clipboardCount > 0,
                                modifier = Modifier.testTag("clear_unpinned_clips_button"),
                            ) {
                                Text("حذف غیرسنجاق‌ها")
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            OutlinedButton(
                                onClick = onClearAllClips,
                                enabled = clipboardCount > 0,
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error,
                                ),
                                modifier = Modifier.testTag("clear_all_clips_button"),
                            ) {
                                Text("حذف همه")
                            }
                        }
                    }
                }
            }
        }
    }
}
