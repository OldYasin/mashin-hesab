package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.KeyboardSettings
import com.example.data.KeyboardThemePreset
import com.example.ime.ui.resolveKeyboardPalette
import com.example.ui.components.PCKeyIcons
import com.example.ui.components.SettingSliderCard
import com.example.ui.components.SettingSwitchRow
import com.example.ui.components.SettingsSectionHeader
import com.example.ui.theme.JetBrainsMonoFontFamily

@Composable
fun AppearanceSettingsScreen(
    settings: KeyboardSettings,
    onUpdateSettings: ((KeyboardSettings) -> KeyboardSettings) -> Unit,
    onResetDefaults: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        item {
            Column(
                modifier = Modifier.widthIn(max = 640.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                LiveThemePreviewCard(settings = settings)

                SettingsSectionHeader(
                    title = "انتخاب تم و رنگ‌بندی",
                    icon = PCKeyIcons.Palette,
                )

                KeyboardThemePreset.entries.forEach { preset ->
                    ThemePresetRow(
                        preset = preset,
                        selected = settings.theme == preset,
                        onSelect = { onUpdateSettings { it.copy(theme = preset) } },
                    )
                }

                SettingsSectionHeader(
                    title = "ابعاد و ظاهر کلیدها",
                    icon = PCKeyIcons.Keyboard,
                )

                SettingSliderCard(
                    title = "ارتفاع کیبورد",
                    valueText = "${settings.keyboardHeightDp} dp",
                    value = settings.keyboardHeightDp.toFloat(),
                    valueRange = 210f..360f,
                    onValueChange = { v -> onUpdateSettings { it.copy(keyboardHeightDp = v) } },
                    testTag = "slider_height",
                )

                SettingSliderCard(
                    title = "اندازه فونت حروف",
                    valueText = "${settings.keyFontSizeSp} sp",
                    value = settings.keyFontSizeSp.toFloat(),
                    valueRange = 14f..26f,
                    onValueChange = { v -> onUpdateSettings { it.copy(keyFontSizeSp = v) } },
                    testTag = "slider_font_size",
                )

                SettingSliderCard(
                    title = "انحنای گوشه کلیدها",
                    valueText = "${settings.keyCornerRadiusDp} dp",
                    value = settings.keyCornerRadiusDp.toFloat(),
                    valueRange = 2f..16f,
                    onValueChange = { v -> onUpdateSettings { it.copy(keyCornerRadiusDp = v) } },
                    testTag = "slider_corner_radius",
                )

                SettingSwitchRow(
                    title = "حاشیه و کادر دور کلیدها",
                    subtitle = "نمایش خط ظریف دور کلیدها برای تفکیک بهتر شبیه کیبورد مکانیکی",
                    checked = settings.showKeyBorders,
                    onCheckedChange = { v -> onUpdateSettings { it.copy(showKeyBorders = v) } },
                    testTag = "switch_key_borders",
                )

                SettingsSectionHeader(
                    title = "لرزش، صدا و سرعت واکنش",
                    icon = PCKeyIcons.Bolt,
                )

                SettingSliderCard(
                    title = "شدت لرزش کلیدها",
                    valueText = "${settings.hapticStrength}%",
                    value = settings.hapticStrength.toFloat(),
                    valueRange = 10f..100f,
                    enabled = settings.hapticEnabled,
                    onValueChange = { v -> onUpdateSettings { it.copy(hapticStrength = v) } },
                    testTag = "slider_haptic_strength",
                )

                SettingSliderCard(
                    title = "مکث نگه داشتن کلید (Long-Press)",
                    valueText = "${settings.longPressDelayMs} ms",
                    value = settings.longPressDelayMs.toFloat(),
                    valueRange = 180f..600f,
                    onValueChange = { v -> onUpdateSettings { it.copy(longPressDelayMs = v) } },
                    testTag = "slider_long_press",
                )

                SettingSliderCard(
                    title = "سرعت تکرار پاک‌کن و کلیدهای جهت",
                    valueText = "${settings.keyRepeatSpeedMs} ms",
                    value = settings.keyRepeatSpeedMs.toFloat(),
                    valueRange = 25f..110f,
                    onValueChange = { v -> onUpdateSettings { it.copy(keyRepeatSpeedMs = v) } },
                    testTag = "slider_repeat_speed",
                )

                SettingsSectionHeader(
                    title = "درباره سازنده",
                    icon = Icons.Default.Info,
                )

                DeveloperCreditCard(
                    onCopyTelegram = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        cm?.setPrimaryClip(ClipData.newPlainText("Telegram", "@WhrAmIGoing"))
                        Toast.makeText(context, "آیدی @WhrAmIGoing کپی شد", Toast.LENGTH_SHORT).show()
                    },
                    onOpenTelegram = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/WhrAmIGoing"))
                        runCatching { context.startActivity(intent) }.onFailure {
                            Toast.makeText(context, "آیدی تلگرام: @WhrAmIGoing", Toast.LENGTH_SHORT).show()
                        }
                    },
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedButton(
                    onClick = onResetDefaults,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reset_defaults_button"),
                    shape = RoundedCornerShape(12.dp),
                ) {
                    Icon(
                        imageVector = PCKeyIcons.RestartAlt,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "بازگردانی همه تنظیمات به حالت پیش‌فرض",
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
            }
        }
    }
}

@Composable
private fun DeveloperCreditCard(
    onCopyTelegram: () -> Unit,
    onOpenTelegram: () -> Unit,
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column {
                    Text(
                        text = "سازنده: vicious cycle",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "ارتباط و پشتیبانی در تلگرام",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Surface(
                        shape = RoundedCornerShape(9.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                    ) {
                        Text(
                            text = "@WhrAmIGoing",
                            style = MaterialTheme.typography.labelLarge,
                            fontFamily = JetBrainsMonoFontFamily,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                FilledTonalButton(
                    onClick = onCopyTelegram,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("copy_telegram_id_button"),
                    shape = RoundedCornerShape(11.dp),
                ) {
                    Icon(
                        imageVector = PCKeyIcons.ContentCopy,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("کپی آیدی")
                }
                Button(
                    onClick = onOpenTelegram,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("open_telegram_button"),
                    shape = RoundedCornerShape(11.dp),
                ) {
                    Text("باز کردن تلگرام")
                }
            }
        }
    }
}

@Composable
private fun LiveThemePreviewCard(settings: KeyboardSettings) {
    val palette = resolveKeyboardPalette(settings.theme)
    val radius = settings.keyCornerRadiusDp.dp
    val sampleKeys = listOf("Ctrl", "ض", "ص", "Q", "W", "Space", "Enter")

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = palette.background),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = "پیش‌نمایش زنده: ${settings.theme.titleFa}",
                color = palette.keyHintText,
                style = MaterialTheme.typography.labelLarge,
            )
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                    sampleKeys.forEachIndexed { idx, label ->
                        val isCtrl = idx == 0
                        val isEnter = idx == sampleKeys.lastIndex
                        val isSpace = idx == 5
                        val bg = when {
                            isCtrl -> palette.activeModifierBg
                            isEnter -> palette.accentKeyBg
                            else -> palette.keyBg
                        }
                        val fg = when {
                            isCtrl -> palette.activeModifierContent
                            isEnter -> palette.accentKeyContent
                            else -> palette.keyText
                        }
                        Box(
                            modifier = Modifier
                                .weight(if (isSpace) 2.2f else 1f)
                                .height(42.dp)
                                .clip(RoundedCornerShape(radius))
                                .background(bg)
                                .then(
                                    if (settings.showKeyBorders) {
                                        Modifier.border(1.dp, palette.border, RoundedCornerShape(radius))
                                    } else {
                                        Modifier
                                    }
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = label,
                                color = fg,
                                fontSize = if (isCtrl || isEnter || isSpace) 11.sp else settings.keyFontSizeSp.sp,
                                fontFamily = if (isCtrl || isEnter) JetBrainsMonoFontFamily else MaterialTheme.typography.bodyLarge.fontFamily,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemePresetRow(
    preset: KeyboardThemePreset,
    selected: Boolean,
    onSelect: () -> Unit,
) {
    val previewPalette = resolveKeyboardPalette(preset)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onSelect() }
            .testTag("theme_preset_${preset.name}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
            else MaterialTheme.colorScheme.surfaceContainer,
        ),
        border = BorderStroke(
            width = if (selected) 1.5.dp else 1.dp,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(horizontalArrangement = Arrangement.spacedBy((-6).dp)) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(previewPalette.background)
                            .border(1.dp, previewPalette.border, CircleShape),
                    )
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(previewPalette.keyBg)
                            .border(1.dp, previewPalette.border, CircleShape),
                    )
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(previewPalette.accentKeyBg)
                            .border(1.dp, previewPalette.border, CircleShape),
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = preset.titleFa,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = preset.subtitleEn,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (selected) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "انتخاب‌شده",
                    tint = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}
