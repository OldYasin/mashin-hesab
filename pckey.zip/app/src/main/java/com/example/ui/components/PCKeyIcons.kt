package com.example.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

object PCKeyIcons {

    val Backspace: ImageVector by lazy {
        vec("Backspace", autoMirror = true) {
            path(fill = SolidColor(Color.Black)) {
                moveTo(22f, 3f)
                horizontalLineTo(7f)
                curveTo(6.31f, 3f, 5.77f, 3.35f, 5.41f, 3.88f)
                lineTo(0f, 12f)
                lineTo(5.41f, 20.11f)
                curveTo(5.77f, 20.64f, 6.31f, 21f, 7f, 21f)
                horizontalLineTo(22f)
                curveTo(23.1f, 21f, 24f, 20.1f, 24f, 19f)
                verticalLineTo(5f)
                curveTo(24f, 3.9f, 23.1f, 3f, 22f, 3f)
                close()
                moveTo(19f, 15.59f)
                lineTo(17.59f, 17f)
                lineTo(14f, 13.41f)
                lineTo(10.41f, 17f)
                lineTo(9f, 15.59f)
                lineTo(12.59f, 12f)
                lineTo(9f, 8.41f)
                lineTo(10.41f, 7f)
                lineTo(14f, 10.59f)
                lineTo(17.59f, 7f)
                lineTo(19f, 8.41f)
                lineTo(15.41f, 12f)
                lineTo(19f, 15.59f)
                close()
            }
        }
    }

    val KeyboardReturn: ImageVector by lazy {
        vec("KeyboardReturn", autoMirror = true) {
            path(fill = SolidColor(Color.Black)) {
                moveTo(19f, 7f)
                verticalLineTo(11f)
                horizontalLineTo(5.83f)
                lineTo(9.41f, 7.41f)
                lineTo(8f, 6f)
                lineTo(2f, 12f)
                lineTo(8f, 18f)
                lineTo(9.41f, 16.59f)
                lineTo(5.83f, 13f)
                horizontalLineTo(21f)
                verticalLineTo(7f)
                horizontalLineTo(19f)
                close()
            }
        }
    }

    val Capslock: ImageVector by lazy {
        vec("Capslock") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 8.41f)
                lineTo(16.59f, 13f)
                lineTo(18f, 11.59f)
                lineTo(12f, 5.59f)
                lineTo(6f, 11.59f)
                lineTo(7.41f, 13f)
                lineTo(12f, 8.41f)
                close()
                moveTo(6f, 18f)
                horizontalLineTo(18f)
                verticalLineTo(16f)
                horizontalLineTo(6f)
                verticalLineTo(18f)
                close()
            }
        }
    }

    val ShiftArrow: ImageVector by lazy {
        vec("ShiftArrow") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(4f, 12f)
                lineTo(5.41f, 13.41f)
                lineTo(11f, 7.83f)
                verticalLineTo(20f)
                horizontalLineTo(13f)
                verticalLineTo(7.83f)
                lineTo(18.58f, 13.42f)
                lineTo(20f, 12f)
                lineTo(12f, 4f)
                lineTo(4f, 12f)
                close()
            }
        }
    }

    val Language: ImageVector by lazy {
        vec("Language") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(11.99f, 2f)
                curveTo(6.47f, 2f, 2f, 6.48f, 2f, 12f)
                reflectiveCurveTo(6.47f, 22f, 11.99f, 22f)
                curveTo(17.52f, 22f, 22f, 17.52f, 22f, 12f)
                reflectiveCurveTo(17.52f, 2f, 11.99f, 2f)
                close()
                moveTo(18.92f, 8f)
                horizontalLineTo(15.97f)
                curveTo(15.65f, 6.75f, 15.19f, 5.55f, 14.59f, 4.44f)
                curveTo(16.43f, 5.07f, 17.96f, 6.35f, 18.92f, 8f)
                close()
                moveTo(12f, 4.04f)
                curveTo(12.83f, 5.24f, 13.48f, 6.57f, 13.91f, 8f)
                horizontalLineTo(10.09f)
                curveTo(10.52f, 6.57f, 11.17f, 5.24f, 12f, 4.04f)
                close()
                moveTo(4.26f, 14f)
                curveTo(4.1f, 13.36f, 4f, 12.69f, 4f, 12f)
                reflectiveCurveTo(4.1f, 10.64f, 4.26f, 10f)
                horizontalLineTo(7.64f)
                curveTo(7.56f, 10.66f, 7.52f, 11.32f, 7.52f, 12f)
                reflectiveCurveTo(7.56f, 13.34f, 7.64f, 14f)
                horizontalLineTo(4.26f)
                close()
                moveTo(5.08f, 16f)
                horizontalLineTo(8.03f)
                curveTo(8.35f, 17.25f, 8.81f, 18.45f, 9.41f, 19.56f)
                curveTo(7.57f, 18.93f, 6.04f, 17.66f, 5.08f, 16f)
                close()
                moveTo(8.03f, 8f)
                horizontalLineTo(5.08f)
                curveTo(6.04f, 6.34f, 7.57f, 5.07f, 9.41f, 4.44f)
                curveTo(8.81f, 5.55f, 8.35f, 6.75f, 8.03f, 8f)
                close()
                moveTo(12f, 19.96f)
                curveTo(11.17f, 18.76f, 10.52f, 17.43f, 10.09f, 16f)
                horizontalLineTo(13.91f)
                curveTo(13.48f, 17.43f, 12.83f, 18.76f, 12f, 19.96f)
                close()
                moveTo(14.34f, 14f)
                horizontalLineTo(9.66f)
                curveTo(9.57f, 13.34f, 9.52f, 12.68f, 9.52f, 12f)
                reflectiveCurveTo(9.57f, 10.65f, 9.66f, 10f)
                horizontalLineTo(14.34f)
                curveTo(14.43f, 10.65f, 14.48f, 11.32f, 14.48f, 12f)
                reflectiveCurveTo(14.43f, 13.34f, 14.34f, 14f)
                close()
                moveTo(14.59f, 19.56f)
                curveTo(15.19f, 18.45f, 15.65f, 17.25f, 15.97f, 16f)
                horizontalLineTo(18.92f)
                curveTo(17.96f, 17.65f, 16.43f, 18.93f, 14.59f, 19.56f)
                close()
                moveTo(16.36f, 14f)
                curveTo(16.44f, 13.34f, 16.48f, 12.68f, 16.48f, 12f)
                reflectiveCurveTo(16.44f, 10.66f, 16.36f, 10f)
                horizontalLineTo(19.74f)
                curveTo(19.9f, 10.64f, 20f, 11.31f, 20f, 12f)
                reflectiveCurveTo(19.9f, 13.36f, 19.74f, 14f)
                horizontalLineTo(16.36f)
                close()
            }
        }
    }

    val Undo: ImageVector by lazy {
        vec("Undo", autoMirror = true) {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12.5f, 8f)
                curveTo(9.85f, 8f, 7.45f, 9f, 5.6f, 10.6f)
                lineTo(2f, 7f)
                verticalLineTo(16f)
                horizontalLineTo(11f)
                lineTo(7.38f, 12.38f)
                curveTo(8.77f, 11.22f, 10.54f, 10.5f, 12.5f, 10.5f)
                curveTo(16.04f, 10.5f, 19.05f, 12.81f, 20.1f, 16f)
                lineTo(22.47f, 15.22f)
                curveTo(21.08f, 11.03f, 17.15f, 8f, 12.5f, 8f)
                close()
            }
        }
    }

    val Redo: ImageVector by lazy {
        vec("Redo", autoMirror = true) {
            path(fill = SolidColor(Color.Black)) {
                moveTo(18.4f, 10.6f)
                curveTo(16.55f, 9f, 14.15f, 8f, 11.5f, 8f)
                curveTo(6.85f, 8f, 2.92f, 11.03f, 1.54f, 15.22f)
                lineTo(3.9f, 16f)
                curveTo(4.95f, 12.81f, 7.95f, 10.5f, 11.5f, 10.5f)
                curveTo(13.45f, 10.5f, 15.23f, 11.22f, 16.62f, 12.38f)
                lineTo(13f, 16f)
                horizontalLineTo(22f)
                verticalLineTo(7f)
                lineTo(18.4f, 10.6f)
                close()
            }
        }
    }

    val ContentCopy: ImageVector by lazy {
        vec("ContentCopy") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(16f, 1f)
                horizontalLineTo(4f)
                curveTo(2.9f, 1f, 2f, 1.9f, 2f, 3f)
                verticalLineTo(17f)
                horizontalLineTo(4f)
                verticalLineTo(3f)
                horizontalLineTo(16f)
                verticalLineTo(1f)
                close()
                moveTo(19f, 5f)
                horizontalLineTo(8f)
                curveTo(6.9f, 5f, 6f, 5.9f, 6f, 7f)
                verticalLineTo(21f)
                curveTo(6f, 22.1f, 6.9f, 23f, 8f, 23f)
                horizontalLineTo(19f)
                curveTo(20.1f, 23f, 21f, 22.1f, 21f, 21f)
                verticalLineTo(7f)
                curveTo(21f, 5.9f, 20.1f, 5f, 19f, 5f)
                close()
                moveTo(19f, 21f)
                horizontalLineTo(8f)
                verticalLineTo(7f)
                horizontalLineTo(19f)
                verticalLineTo(21f)
                close()
            }
        }
    }

    val ContentPaste: ImageVector by lazy {
        vec("ContentPaste") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(19f, 2f)
                horizontalLineTo(14.82f)
                curveTo(14.4f, 0.84f, 13.3f, 0f, 12f, 0f)
                curveTo(10.7f, 0f, 9.6f, 0.84f, 9.18f, 2f)
                horizontalLineTo(5f)
                curveTo(3.9f, 2f, 3f, 2.9f, 3f, 4f)
                verticalLineTo(20f)
                curveTo(3f, 21.1f, 3.9f, 22f, 5f, 22f)
                horizontalLineTo(19f)
                curveTo(20.1f, 22f, 21f, 21.1f, 21f, 20f)
                verticalLineTo(4f)
                curveTo(21f, 2.9f, 20.1f, 2f, 19f, 2f)
                close()
                moveTo(12f, 2f)
                curveTo(12.55f, 2f, 13f, 2.45f, 13f, 3f)
                reflectiveCurveTo(12.55f, 4f, 12f, 4f)
                reflectiveCurveTo(11f, 3.55f, 11f, 3f)
                reflectiveCurveTo(11.45f, 2f, 12f, 2f)
                close()
                moveTo(19f, 20f)
                horizontalLineTo(5f)
                verticalLineTo(4f)
                horizontalLineTo(7f)
                verticalLineTo(7f)
                horizontalLineTo(17f)
                verticalLineTo(4f)
                horizontalLineTo(19f)
                verticalLineTo(20f)
                close()
            }
        }
    }

    val SelectAll: ImageVector by lazy {
        vec("SelectAll") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(3f, 5f)
                horizontalLineTo(5f)
                verticalLineTo(3f)
                curveTo(3.9f, 3f, 3f, 3.9f, 3f, 5f)
                close()
                moveTo(3f, 13f)
                horizontalLineTo(5f)
                verticalLineTo(11f)
                horizontalLineTo(3f)
                verticalLineTo(13f)
                close()
                moveTo(7f, 21f)
                horizontalLineTo(9f)
                verticalLineTo(19f)
                horizontalLineTo(7f)
                verticalLineTo(21f)
                close()
                moveTo(3f, 9f)
                horizontalLineTo(5f)
                verticalLineTo(7f)
                horizontalLineTo(3f)
                verticalLineTo(9f)
                close()
                moveTo(13f, 3f)
                horizontalLineTo(11f)
                verticalLineTo(5f)
                horizontalLineTo(13f)
                verticalLineTo(3f)
                close()
                moveTo(19f, 3f)
                verticalLineTo(5f)
                horizontalLineTo(21f)
                curveTo(21f, 3.9f, 20.1f, 3f, 19f, 3f)
                close()
                moveTo(5f, 21f)
                verticalLineTo(19f)
                horizontalLineTo(3f)
                curveTo(3f, 20.1f, 3.9f, 21f, 5f, 21f)
                close()
                moveTo(3f, 17f)
                horizontalLineTo(5f)
                verticalLineTo(15f)
                horizontalLineTo(3f)
                verticalLineTo(17f)
                close()
                moveTo(9f, 3f)
                horizontalLineTo(7f)
                verticalLineTo(5f)
                horizontalLineTo(9f)
                verticalLineTo(3f)
                close()
                moveTo(11f, 21f)
                horizontalLineTo(13f)
                verticalLineTo(19f)
                horizontalLineTo(11f)
                verticalLineTo(21f)
                close()
                moveTo(19f, 13f)
                horizontalLineTo(21f)
                verticalLineTo(11f)
                horizontalLineTo(19f)
                verticalLineTo(13f)
                close()
                moveTo(19f, 21f)
                curveTo(20.1f, 21f, 21f, 20.1f, 21f, 19f)
                horizontalLineTo(19f)
                verticalLineTo(21f)
                close()
                moveTo(19f, 9f)
                horizontalLineTo(21f)
                verticalLineTo(7f)
                horizontalLineTo(19f)
                verticalLineTo(9f)
                close()
                moveTo(19f, 17f)
                horizontalLineTo(21f)
                verticalLineTo(15f)
                horizontalLineTo(19f)
                verticalLineTo(17f)
                close()
                moveTo(15f, 21f)
                horizontalLineTo(17f)
                verticalLineTo(19f)
                horizontalLineTo(15f)
                verticalLineTo(21f)
                close()
                moveTo(15f, 5f)
                horizontalLineTo(17f)
                verticalLineTo(3f)
                horizontalLineTo(15f)
                verticalLineTo(5f)
                close()
                moveTo(7f, 17f)
                horizontalLineTo(17f)
                verticalLineTo(7f)
                horizontalLineTo(7f)
                verticalLineTo(17f)
                close()
                moveTo(9f, 9f)
                horizontalLineTo(15f)
                verticalLineTo(15f)
                horizontalLineTo(9f)
                verticalLineTo(9f)
                close()
            }
        }
    }

    val Emoji: ImageVector by lazy {
        vec("Emoji") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(11.99f, 2f)
                curveTo(6.47f, 2f, 2f, 6.48f, 2f, 12f)
                reflectiveCurveTo(6.47f, 22f, 11.99f, 22f)
                curveTo(17.52f, 22f, 22f, 17.52f, 22f, 12f)
                reflectiveCurveTo(17.52f, 2f, 11.99f, 2f)
                close()
                moveTo(12f, 20f)
                curveTo(7.58f, 20f, 4f, 16.42f, 4f, 12f)
                reflectiveCurveTo(7.58f, 4f, 12f, 4f)
                reflectiveCurveTo(20f, 7.58f, 20f, 12f)
                reflectiveCurveTo(16.42f, 20f, 12f, 20f)
                close()
                moveTo(15.5f, 11f)
                curveTo(16.33f, 11f, 17f, 10.33f, 17f, 9.5f)
                reflectiveCurveTo(16.33f, 8f, 15.5f, 8f)
                reflectiveCurveTo(14f, 8.67f, 14f, 9.5f)
                reflectiveCurveTo(14.67f, 11f, 15.5f, 11f)
                close()
                moveTo(8.5f, 11f)
                curveTo(9.33f, 11f, 10f, 10.33f, 10f, 9.5f)
                reflectiveCurveTo(9.33f, 8f, 8.5f, 8f)
                reflectiveCurveTo(7f, 8.67f, 7f, 9.5f)
                reflectiveCurveTo(7.67f, 11f, 8.5f, 11f)
                close()
                moveTo(12f, 17.5f)
                curveTo(14.33f, 17.5f, 16.31f, 16.04f, 17.11f, 14f)
                horizontalLineTo(6.89f)
                curveTo(7.69f, 16.04f, 9.67f, 17.5f, 12f, 17.5f)
                close()
            }
        }
    }

    val Pin: ImageVector by lazy {
        vec("Pin") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(16f, 12f)
                verticalLineTo(4f)
                horizontalLineTo(17f)
                verticalLineTo(2f)
                horizontalLineTo(7f)
                verticalLineTo(4f)
                horizontalLineTo(8f)
                verticalLineTo(12f)
                lineTo(6f, 14f)
                verticalLineTo(16f)
                horizontalLineTo(11.2f)
                verticalLineTo(22f)
                horizontalLineTo(12.8f)
                verticalLineTo(16f)
                horizontalLineTo(18f)
                verticalLineTo(14f)
                lineTo(16f, 12f)
                close()
            }
        }
    }

    val PinOutline: ImageVector by lazy {
        vec("PinOutline") {
            path(
                fill = null,
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(15f, 4f)
                verticalLineTo(11.5f)
                lineTo(17f, 14f)
                horizontalLineTo(7f)
                lineTo(9f, 11.5f)
                verticalLineTo(4f)
                moveTo(8f, 4f)
                horizontalLineTo(16f)
                moveTo(12f, 14f)
                verticalLineTo(21f)
            }
        }
    }

    val Keyboard: ImageVector by lazy {
        vec("Keyboard") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(20f, 5f)
                horizontalLineTo(4f)
                curveTo(2.9f, 5f, 2.01f, 5.9f, 2.01f, 7f)
                lineTo(2f, 17f)
                curveTo(2f, 18.1f, 2.9f, 19f, 4f, 19f)
                horizontalLineTo(20f)
                curveTo(21.1f, 19f, 22f, 18.1f, 22f, 17f)
                verticalLineTo(7f)
                curveTo(22f, 5.9f, 21.1f, 5f, 20f, 5f)
                close()
                moveTo(11f, 8f)
                horizontalLineTo(13f)
                verticalLineTo(10f)
                horizontalLineTo(11f)
                verticalLineTo(8f)
                close()
                moveTo(11f, 11f)
                horizontalLineTo(13f)
                verticalLineTo(13f)
                horizontalLineTo(11f)
                verticalLineTo(11f)
                close()
                moveTo(8f, 8f)
                horizontalLineTo(10f)
                verticalLineTo(10f)
                horizontalLineTo(8f)
                verticalLineTo(8f)
                close()
                moveTo(8f, 11f)
                horizontalLineTo(10f)
                verticalLineTo(13f)
                horizontalLineTo(8f)
                verticalLineTo(11f)
                close()
                moveTo(7f, 13f)
                horizontalLineTo(5f)
                verticalLineTo(11f)
                horizontalLineTo(7f)
                verticalLineTo(13f)
                close()
                moveTo(7f, 10f)
                horizontalLineTo(5f)
                verticalLineTo(8f)
                horizontalLineTo(7f)
                verticalLineTo(10f)
                close()
                moveTo(16f, 17f)
                horizontalLineTo(8f)
                verticalLineTo(15f)
                horizontalLineTo(16f)
                verticalLineTo(17f)
                close()
                moveTo(16f, 13f)
                horizontalLineTo(14f)
                verticalLineTo(11f)
                horizontalLineTo(16f)
                verticalLineTo(13f)
                close()
                moveTo(16f, 10f)
                horizontalLineTo(14f)
                verticalLineTo(8f)
                horizontalLineTo(16f)
                verticalLineTo(10f)
                close()
                moveTo(19f, 13f)
                horizontalLineTo(17f)
                verticalLineTo(11f)
                horizontalLineTo(19f)
                verticalLineTo(13f)
                close()
                moveTo(19f, 10f)
                horizontalLineTo(17f)
                verticalLineTo(8f)
                horizontalLineTo(19f)
                verticalLineTo(10f)
                close()
            }
        }
    }

    val Tune: ImageVector by lazy {
        vec("Tune") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(3f, 17f)
                verticalLineTo(19f)
                horizontalLineTo(9f)
                verticalLineTo(17f)
                horizontalLineTo(3f)
                close()
                moveTo(3f, 5f)
                verticalLineTo(7f)
                horizontalLineTo(13f)
                verticalLineTo(5f)
                horizontalLineTo(3f)
                close()
                moveTo(13f, 21f)
                verticalLineTo(19f)
                horizontalLineTo(21f)
                verticalLineTo(17f)
                horizontalLineTo(13f)
                verticalLineTo(15f)
                horizontalLineTo(11f)
                verticalLineTo(21f)
                horizontalLineTo(13f)
                close()
                moveTo(7f, 9f)
                verticalLineTo(11f)
                horizontalLineTo(3f)
                verticalLineTo(13f)
                horizontalLineTo(7f)
                verticalLineTo(15f)
                horizontalLineTo(9f)
                verticalLineTo(9f)
                horizontalLineTo(7f)
                close()
                moveTo(21f, 13f)
                verticalLineTo(11f)
                horizontalLineTo(11f)
                verticalLineTo(13f)
                horizontalLineTo(21f)
                close()
                moveTo(15f, 9f)
                horizontalLineTo(17f)
                verticalLineTo(7f)
                horizontalLineTo(21f)
                verticalLineTo(5f)
                horizontalLineTo(17f)
                verticalLineTo(3f)
                horizontalLineTo(15f)
                verticalLineTo(9f)
                close()
            }
        }
    }

    val Palette: ImageVector by lazy {
        vec("Palette") {
            path(fill = SolidColor(Color.Black), pathFillType = PathFillType.EvenOdd) {
                moveTo(12f, 3f)
                curveTo(7.03f, 3f, 3f, 7.03f, 3f, 12f)
                curveTo(3f, 16.97f, 7.03f, 21f, 12f, 21f)
                curveTo(12.83f, 21f, 13.5f, 20.33f, 13.5f, 19.5f)
                curveTo(13.5f, 19.11f, 13.35f, 18.76f, 13.11f, 18.49f)
                curveTo(12.88f, 18.23f, 12.73f, 17.88f, 12.73f, 17.5f)
                curveTo(12.73f, 16.67f, 13.4f, 16f, 14.23f, 16f)
                horizontalLineTo(16f)
                curveTo(18.76f, 16f, 21f, 13.76f, 21f, 11f)
                curveTo(21f, 6.58f, 16.97f, 3f, 12f, 3f)
                close()
                moveTo(6.5f, 12f)
                curveTo(5.67f, 12f, 5f, 11.33f, 5f, 10.5f)
                reflectiveCurveTo(5.67f, 9f, 6.5f, 9f)
                reflectiveCurveTo(8f, 9.67f, 8f, 10.5f)
                reflectiveCurveTo(7.33f, 12f, 6.5f, 12f)
                close()
                moveTo(9.5f, 8f)
                curveTo(8.67f, 8f, 8f, 7.33f, 8f, 6.5f)
                reflectiveCurveTo(8.67f, 5f, 9.5f, 5f)
                reflectiveCurveTo(11f, 5.67f, 11f, 6.5f)
                reflectiveCurveTo(10.33f, 8f, 9.5f, 8f)
                close()
                moveTo(14.5f, 8f)
                curveTo(13.67f, 8f, 13f, 7.33f, 13f, 6.5f)
                reflectiveCurveTo(13.67f, 5f, 14.5f, 5f)
                reflectiveCurveTo(16f, 5.67f, 16f, 6.5f)
                reflectiveCurveTo(15.33f, 8f, 14.5f, 8f)
                close()
                moveTo(17.5f, 12f)
                curveTo(16.67f, 12f, 16f, 11.33f, 16f, 10.5f)
                reflectiveCurveTo(16.67f, 9f, 17.5f, 9f)
                reflectiveCurveTo(19f, 9.67f, 19f, 10.5f)
                reflectiveCurveTo(18.33f, 12f, 17.5f, 12f)
                close()
            }
        }
    }

    val Terminal: ImageVector by lazy {
        vec("Terminal") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(20f, 4f)
                horizontalLineTo(4f)
                curveTo(2.89f, 4f, 2f, 4.9f, 2f, 6f)
                verticalLineTo(18f)
                curveTo(2f, 19.1f, 2.89f, 20f, 4f, 20f)
                horizontalLineTo(20f)
                curveTo(21.1f, 20f, 22f, 19.1f, 22f, 18f)
                verticalLineTo(6f)
                curveTo(22f, 4.9f, 21.1f, 4f, 20f, 4f)
                close()
                moveTo(20f, 18f)
                horizontalLineTo(4f)
                verticalLineTo(8f)
                horizontalLineTo(20f)
                verticalLineTo(18f)
                close()
                moveTo(18f, 17f)
                horizontalLineTo(12f)
                verticalLineTo(15f)
                horizontalLineTo(18f)
                verticalLineTo(17f)
                close()
                moveTo(7.5f, 17f)
                lineTo(6.09f, 15.59f)
                lineTo(8.67f, 13f)
                lineTo(6.08f, 10.41f)
                lineTo(7.5f, 9f)
                lineTo(11.5f, 13f)
                lineTo(7.5f, 17f)
                close()
            }
        }
    }

    val SwapHoriz: ImageVector by lazy {
        vec("SwapHoriz") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(6.99f, 11f)
                lineTo(3f, 15f)
                lineTo(6.99f, 19f)
                verticalLineTo(16f)
                horizontalLineTo(14f)
                verticalLineTo(14f)
                horizontalLineTo(6.99f)
                verticalLineTo(11f)
                close()
                moveTo(21f, 9f)
                lineTo(17.01f, 5f)
                verticalLineTo(8f)
                horizontalLineTo(10f)
                verticalLineTo(10f)
                horizontalLineTo(17.01f)
                verticalLineTo(13f)
                lineTo(21f, 9f)
                close()
            }
        }
    }

    val DeleteSweep: ImageVector by lazy {
        vec("DeleteSweep") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(15f, 16f)
                horizontalLineTo(19f)
                verticalLineTo(18f)
                horizontalLineTo(15f)
                close()
                moveTo(15f, 8f)
                horizontalLineTo(22f)
                verticalLineTo(10f)
                horizontalLineTo(15f)
                close()
                moveTo(15f, 12f)
                horizontalLineTo(21f)
                verticalLineTo(14f)
                horizontalLineTo(15f)
                close()
                moveTo(3f, 18f)
                curveTo(3f, 19.1f, 3.9f, 20f, 5f, 20f)
                horizontalLineTo(11f)
                curveTo(12.1f, 20f, 13f, 19.1f, 13f, 18f)
                verticalLineTo(8f)
                horizontalLineTo(3f)
                verticalLineTo(18f)
                close()
                moveTo(14f, 5f)
                horizontalLineTo(11f)
                lineTo(10f, 4f)
                horizontalLineTo(6f)
                lineTo(5f, 5f)
                horizontalLineTo(2f)
                verticalLineTo(7f)
                horizontalLineTo(14f)
                close()
            }
        }
    }

    val Bolt: ImageVector by lazy {
        vec("Bolt") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(11f, 21f)
                horizontalLineTo(10f)
                lineTo(11f, 14f)
                horizontalLineTo(7.5f)
                curveTo(6.62f, 14f, 6.17f, 12.93f, 6.79f, 12.3f)
                lineTo(13.5f, 3f)
                horizontalLineTo(14.5f)
                lineTo(13.5f, 10f)
                horizontalLineTo(17f)
                curveTo(17.89f, 10f, 18.33f, 11.08f, 17.7f, 11.71f)
                lineTo(11f, 21f)
                close()
            }
        }
    }

    val RestartAlt: ImageVector by lazy {
        vec("RestartAlt") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 5f)
                verticalLineTo(1f)
                lineTo(7f, 6f)
                lineTo(12f, 11f)
                verticalLineTo(7f)
                curveTo(15.31f, 7f, 18f, 9.69f, 18f, 13f)
                reflectiveCurveTo(15.31f, 19f, 12f, 19f)
                reflectiveCurveTo(6f, 16.31f, 6f, 13f)
                horizontalLineTo(4f)
                curveTo(4f, 17.42f, 7.58f, 21f, 12f, 21f)
                reflectiveCurveTo(20f, 17.42f, 20f, 13f)
                reflectiveCurveTo(16.42f, 5f, 12f, 5f)
                close()
            }
        }
    }

    private fun vec(
        name: String,
        autoMirror: Boolean = false,
        block: ImageVector.Builder.() -> Unit,
    ): ImageVector = ImageVector.Builder(
        name = name,
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f,
        autoMirror = autoMirror,
    ).apply(block).build()
}
