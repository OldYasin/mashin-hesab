package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.PCKeyIcons
import com.example.ui.screens.AppearanceSettingsScreen
import com.example.ui.screens.FeaturesScreen
import com.example.ui.screens.HomeSandboxScreen
import com.example.ui.screens.PcSettingsScreen
import com.example.ui.theme.PCKeyTheme

private enum class AppTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
) {
    HOME("تست زنده", Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
    FEATURES("قابلیت‌ها", PCKeyIcons.Tune, PCKeyIcons.Tune, "nav_features"),
    PC_LAYOUT("پیسی و زبان", PCKeyIcons.Keyboard, PCKeyIcons.Keyboard, "nav_pc_layout"),
    APPEARANCE("ظاهر و درباره", PCKeyIcons.Palette, PCKeyIcons.Palette, "nav_appearance"),
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PCKeyTheme(darkTheme = true) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    PCKeySettingsRoot(
                        viewModel = viewModel,
                        onOpenImeSettings = {
                            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
                        },
                        onPickIme = {
                            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                            imm?.showInputMethodPicker()
                        },
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshImeStatus()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PCKeySettingsRoot(
    viewModel: MainViewModel,
    onOpenImeSettings: () -> Unit,
    onPickIme: () -> Unit,
) {
    var currentTab by rememberSaveable { mutableStateOf(AppTab.HOME) }

    BackHandler(enabled = currentTab != AppTab.HOME) {
        currentTab = AppTab.HOME
    }

    val imeStatus by viewModel.imeStatus.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val clips by viewModel.clipboardEntries.collectAsStateWithLifecycle()
    val sandboxStats by viewModel.sandboxStats.collectAsStateWithLifecycle()
    val sandboxLastEvent by viewModel.sandboxLastEvent.collectAsStateWithLifecycle()
    val sandboxKeyboardState by viewModel.sandboxKeyboardState.collectAsStateWithLifecycle()

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = when (currentTab) {
                                AppTab.HOME -> "PCKey • کیبورد پیسی"
                                AppTab.FEATURES -> "مدیریت قابلیت‌های کیبورد"
                                AppTab.PC_LAYOUT -> "تنظیمات پیسی و زبان"
                                AppTab.APPEARANCE -> "ظاهر، تم و سازنده"
                            },
                            fontWeight = FontWeight.Bold,
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface,
                    ),
                )
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                    ) {
                        AppTab.entries.forEach { tab ->
                            val selected = currentTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { currentTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.title,
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.title,
                                        style = MaterialTheme.typography.labelLarge,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                modifier = Modifier.testTag(tab.testTag),
                            )
                        }
                    }
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (useRail) {
                    NavigationRail(
                        modifier = Modifier.fillMaxHeight(),
                        containerColor = MaterialTheme.colorScheme.surface,
                    ) {
                        AppTab.entries.forEach { tab ->
                            val selected = currentTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { currentTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.title,
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.title,
                                        style = MaterialTheme.typography.labelLarge,
                                    )
                                },
                                modifier = Modifier.testTag(tab.testTag),
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    when (currentTab) {
                        AppTab.HOME -> HomeSandboxScreen(
                            imeStatus = imeStatus,
                            settings = settings,
                            clipboardEntries = clips,
                            sandboxStats = sandboxStats,
                            lastEvent = sandboxLastEvent,
                            sandboxUiState = sandboxKeyboardState,
                            sandboxController = viewModel.sandboxController,
                            feedback = viewModel.feedback,
                            onAttachEditText = viewModel::attachSandboxEditText,
                            onDetachEditText = viewModel::detachSandboxEditText,
                            onEditTextChanged = viewModel::onSandboxEditTextChanged,
                            onSelectionChanged = viewModel::onSandboxSelectionChanged,
                            onInsert10kSample = viewModel::insertTenThousandLinesSample,
                            onClearSandbox = viewModel::clearSandboxText,
                            onOpenImeSettings = onOpenImeSettings,
                            onPickIme = onPickIme,
                            onResolveClipText = { viewModel.repository.resolveClipText(it) },
                            onTogglePinClip = { viewModel.repository.togglePinClip(it) },
                            onDeleteClip = { viewModel.repository.deleteClip(it) },
                            onClearUnpinnedClips = { viewModel.repository.clearUnpinnedClips() },
                            onOpenAppearanceTab = { currentTab = AppTab.APPEARANCE },
                        )

                        AppTab.FEATURES -> FeaturesScreen(
                            settings = settings,
                            onUpdateSettings = viewModel::updateSettings,
                        )

                        AppTab.PC_LAYOUT -> PcSettingsScreen(
                            settings = settings,
                            clipboardCount = clips.size,
                            onUpdateSettings = viewModel::updateSettings,
                            onClearUnpinnedClips = { viewModel.repository.clearUnpinnedClips() },
                            onClearAllClips = { viewModel.repository.clearAllClips() },
                        )

                        AppTab.APPEARANCE -> AppearanceSettingsScreen(
                            settings = settings,
                            onUpdateSettings = viewModel::updateSettings,
                            onResetDefaults = { viewModel.repository.resetToDefaults() },
                        )
                    }
                }
            }
        }
    }
}
