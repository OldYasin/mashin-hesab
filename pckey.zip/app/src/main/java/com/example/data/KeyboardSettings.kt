package com.example.data

import androidx.compose.runtime.Immutable

enum class KeyboardThemePreset(val titleFa: String, val subtitleEn: String) {
    OBSIDIAN("گرافیت", "Graphite"),
    AMOLED("مشکی خالص", "AMOLED"),
    MIDNIGHT_BLUE("آبی نیمه‌شب", "Midnight"),
    FOREST_TERMINAL("سبز ترمینال", "Terminal"),
    NORD("یخی نورد", "Nord"),
    DRACULA("دراکولا", "Dracula"),
    MOCHA("موکا", "Mocha"),
    TOKYO_NIGHT("شب توکیو", "Tokyo Night"),
    CLEAN_LIGHT("روشن مینیمال", "Clean Light"),
    LATTE("لاته", "Latte"),
    SAKURA("شکوفه", "Sakura"),
    DYNAMIC("هماهنگ با سیستم", "Material You"),
}

enum class KeyboardLanguage(val code: String, val labelFa: String, val shortLabel: String) {
    PERSIAN("fa", "فارسی", "فا"),
    ENGLISH("en", "English", "EN"),
}

enum class TabBehavior(val titleFa: String, val descriptionFa: String) {
    INSERT_TAB_CHAR("کاراکتر Tab (\\t)", "درج کاراکتر تب واقعی مناسب کدنویسی و ویرایشگرها"),
    SPACES_4("۴ فاصله (4 Spaces)", "درج ۴ کاراکتر فاصله به جای تب"),
    SPACES_2("۲ فاصله (2 Spaces)", "درج ۲ کاراکتر فاصله به جای تب"),
    NAVIGATE_NEXT_FIELD("انتقال به فیلد بعدی", "رفتن به کادر ورودی بعدی در فرم‌ها"),
}

enum class SpaceSwipeMode(val titleFa: String, val descriptionFa: String) {
    CURSOR_TRACKPAD("جابجایی مکان‌نما (Trackpad)", "کشیدن انگشت روی Space مکان‌نما را دقیق جابجا می‌کند"),
    SWITCH_LANGUAGE("تغییر زبان (فارسی / EN)", "کشیدن انگشت روی Space زبان را تغییر می‌دهد"),
}

@Immutable
data class KeyboardSettings(
    val theme: KeyboardThemePreset = KeyboardThemePreset.OBSIDIAN,
    val keyboardHeightDp: Int = 248,
    val keyCornerRadiusDp: Int = 6,
    val keyFontSizeSp: Int = 21,
    val showKeyBorders: Boolean = true,
    val widePersianKeys: Boolean = true,
    val enableTopUtilityBar: Boolean = true,
    val enableFnToggle: Boolean = true,
    val enableNumpadMode: Boolean = true,
    val enableQuickCopyPasteButtons: Boolean = true,
    val enableUndoRedoButtons: Boolean = true,
    val enableEmojiPanel: Boolean = true,
    val showNumberRow: Boolean = false,
    val showPcToolbar: Boolean = false,
    val showFunctionRow: Boolean = false,
    val showZwnjKey: Boolean = true,
    val persianDigitsInPersianMode: Boolean = false,
    val defaultLanguage: KeyboardLanguage = KeyboardLanguage.PERSIAN,
    val enablePersian: Boolean = true,
    val enableEnglish: Boolean = true,
    val tabBehavior: TabBehavior = TabBehavior.INSERT_TAB_CHAR,
    val enableSpaceSwipe: Boolean = true,
    val spaceSwipeMode: SpaceSwipeMode = SpaceSwipeMode.SWITCH_LANGUAGE,
    val backspaceWordSwipeEnabled: Boolean = true,
    val ctrlSpaceSwitchesLanguage: Boolean = true,
    val autoCapitalize: Boolean = true,
    val doubleSpacePeriod: Boolean = true,
    val hapticEnabled: Boolean = true,
    val hapticStrength: Int = 50,
    val soundEnabled: Boolean = false,
    val keyPopupEnabled: Boolean = true,
    val longPressDelayMs: Int = 340,
    val keyRepeatSpeedMs: Int = 45,
    val clipboardHistoryEnabled: Boolean = true,
    val saveSensitiveClips: Boolean = true,
)
