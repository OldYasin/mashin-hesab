package com.example.data

import androidx.compose.runtime.Immutable

@Immutable
data class ClipboardEntry(
    val id: String,
    val text: String,
    val preview: String = text.take(140),
    val lineCount: Int = 1,
    val charCount: Int = text.length,
    val timestamp: Long,
    val pinned: Boolean = false,
    val isLargeCached: Boolean = false,
)
