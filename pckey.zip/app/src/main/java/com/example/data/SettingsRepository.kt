package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

private val Context.pckeyDataStore: DataStore<Preferences> by preferencesDataStore(name = "pckey_prefs")

class SettingsRepository private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val largeClipDir = File(appContext.filesDir, "pckey_clips").apply { mkdirs() }
    private val largeClipCache = ConcurrentHashMap<String, String>()

    private val _settings = MutableStateFlow(KeyboardSettings())
    val settings: StateFlow<KeyboardSettings> = _settings.asStateFlow()

    private val _clipboardEntries = MutableStateFlow<List<ClipboardEntry>>(emptyList())
    val clipboardEntries: StateFlow<List<ClipboardEntry>> = _clipboardEntries.asStateFlow()

    init {
        scope.launch {
            appContext.pckeyDataStore.data
                .map { prefs -> prefs.toKeyboardSettings() }
                .collect { loaded ->
                    _settings.value = loaded
                }
        }
        scope.launch {
            appContext.pckeyDataStore.data
                .map { prefs -> parseClipboardJson(prefs[KEY_CLIPBOARD_JSON] ?: "[]") }
                .collect { clips ->
                    _clipboardEntries.value = clips
                }
        }
    }

    fun updateSettings(transform: (KeyboardSettings) -> KeyboardSettings) {
        val next = transform(_settings.value)
        _settings.value = next
        scope.launch {
            appContext.pckeyDataStore.edit { prefs ->
                prefs[KEY_THEME] = next.theme.name
                prefs[KEY_HEIGHT] = next.keyboardHeightDp
                prefs[KEY_RADIUS] = next.keyCornerRadiusDp
                prefs[KEY_FONT_SIZE] = next.keyFontSizeSp
                prefs[KEY_BORDERS] = next.showKeyBorders
                prefs[KEY_WIDE_PERSIAN] = next.widePersianKeys
                prefs[KEY_ENABLE_TOP_BAR] = next.enableTopUtilityBar
                prefs[KEY_ENABLE_FN] = next.enableFnToggle
                prefs[KEY_ENABLE_NUMPAD] = next.enableNumpadMode
                prefs[KEY_ENABLE_QUICK_CP] = next.enableQuickCopyPasteButtons
                prefs[KEY_ENABLE_UNDO_REDO] = next.enableUndoRedoButtons
                prefs[KEY_ENABLE_EMOJI] = next.enableEmojiPanel
                prefs[KEY_NUMBER_ROW] = next.showNumberRow
                prefs[KEY_PC_TOOLBAR] = next.showPcToolbar
                prefs[KEY_FUNCTION_ROW] = next.showFunctionRow
                prefs[KEY_ZWNJ] = next.showZwnjKey
                prefs[KEY_PERSIAN_DIGITS] = next.persianDigitsInPersianMode
                prefs[KEY_DEFAULT_LANG] = next.defaultLanguage.name
                prefs[KEY_ENABLE_PERSIAN] = next.enablePersian
                prefs[KEY_ENABLE_ENGLISH] = next.enableEnglish
                prefs[KEY_TAB_BEHAVIOR] = next.tabBehavior.name
                prefs[KEY_ENABLE_SPACE_SWIPE] = next.enableSpaceSwipe
                prefs[KEY_SPACE_SWIPE] = next.spaceSwipeMode.name
                prefs[KEY_BSP_WORD_SWIPE] = next.backspaceWordSwipeEnabled
                prefs[KEY_CTRL_SPACE] = next.ctrlSpaceSwitchesLanguage
                prefs[KEY_AUTO_CAP] = next.autoCapitalize
                prefs[KEY_DOUBLE_SPACE] = next.doubleSpacePeriod
                prefs[KEY_HAPTIC] = next.hapticEnabled
                prefs[KEY_HAPTIC_STRENGTH] = next.hapticStrength
                prefs[KEY_SOUND] = next.soundEnabled
                prefs[KEY_POPUP] = next.keyPopupEnabled
                prefs[KEY_LONG_PRESS] = next.longPressDelayMs
                prefs[KEY_REPEAT_SPEED] = next.keyRepeatSpeedMs
                prefs[KEY_CLIPBOARD_ENABLED] = next.clipboardHistoryEnabled
            }
        }
    }

    fun resetToDefaults() {
        updateSettings { KeyboardSettings() }
    }

    fun resolveClipText(entry: ClipboardEntry): String {
        if (!entry.isLargeCached && entry.text.isNotEmpty()) return entry.text
        largeClipCache[entry.id]?.let { return it }
        val file = File(largeClipDir, "${entry.id}.txt")
        if (file.exists()) {
            val loaded = runCatching { file.readText() }.getOrDefault(entry.text)
            largeClipCache[entry.id] = loaded
            return loaded
        }
        return entry.text
    }

    fun addClipboardText(rawText: String) {
        if (!_settings.value.clipboardHistoryEnabled) return
        if (rawText.isBlank()) return

        scope.launch(Dispatchers.Default) {
            val text = rawText.trim('\u0000')
            if (text.isBlank()) return@launch

            val lineCount = countLinesFast(text)
            val preview = buildPreview(text)
            val isLarge = text.length > INLINE_CLIP_THRESHOLD
            val current = _clipboardEntries.value

            val existingSame = current.firstOrNull {
                it.charCount == text.length && it.preview == preview && resolveClipText(it) == text
            }
            val existingPinned = existingSame?.pinned ?: false
            val newId = existingSame?.id ?: UUID.randomUUID().toString()

            if (isLarge) {
                largeClipCache[newId] = text
                runCatching { File(largeClipDir, "$newId.txt").writeText(text) }
            }

            val filtered = current.filterNot { it.id == newId }
            val newEntry = ClipboardEntry(
                id = newId,
                text = if (isLarge) "" else text,
                preview = preview,
                lineCount = lineCount,
                charCount = text.length,
                timestamp = System.currentTimeMillis(),
                pinned = existingPinned,
                isLargeCached = isLarge,
            )
            val combined = sortAndTrimClips(listOf(newEntry) + filtered)
            cleanupOrphanClipFiles(combined)
            saveClipboardEntries(combined)
        }
    }

    fun togglePinClip(id: String) {
        val updated = _clipboardEntries.value.map { entry ->
            if (entry.id == id) entry.copy(pinned = !entry.pinned) else entry
        }
        saveClipboardEntries(sortAndTrimClips(updated))
    }

    fun deleteClip(id: String) {
        largeClipCache.remove(id)
        scope.launch { runCatching { File(largeClipDir, "$id.txt").delete() } }
        val updated = _clipboardEntries.value.filterNot { it.id == id }
        saveClipboardEntries(updated)
    }

    fun clearUnpinnedClips() {
        val updated = _clipboardEntries.value.filter { it.pinned }
        cleanupOrphanClipFiles(updated)
        saveClipboardEntries(updated)
    }

    fun clearAllClips() {
        largeClipCache.clear()
        scope.launch {
            runCatching { largeClipDir.listFiles()?.forEach { it.delete() } }
        }
        saveClipboardEntries(emptyList())
    }

    private fun cleanupOrphanClipFiles(kept: List<ClipboardEntry>) {
        val keptIds = kept.mapTo(HashSet()) { it.id }
        largeClipCache.keys.removeAll { it !in keptIds }
        runCatching {
            largeClipDir.listFiles()?.forEach { file ->
                val id = file.nameWithoutExtension
                if (id !in keptIds) file.delete()
            }
        }
    }

    private fun sortAndTrimClips(list: List<ClipboardEntry>): List<ClipboardEntry> {
        val pinned = list.filter { it.pinned }.sortedByDescending { it.timestamp }
        val unpinned = list.filterNot { it.pinned }.sortedByDescending { it.timestamp }.take(25)
        return pinned + unpinned
    }

    private fun saveClipboardEntries(entries: List<ClipboardEntry>) {
        _clipboardEntries.value = entries
        val jsonArray = JSONArray()
        entries.forEach { entry ->
            jsonArray.put(
                JSONObject().apply {
                    put("id", entry.id)
                    put("text", if (entry.isLargeCached) "" else entry.text)
                    put("preview", entry.preview)
                    put("lines", entry.lineCount)
                    put("chars", entry.charCount)
                    put("ts", entry.timestamp)
                    put("pinned", entry.pinned)
                    put("large", entry.isLargeCached)
                }
            )
        }
        val serialized = jsonArray.toString()
        scope.launch {
            appContext.pckeyDataStore.edit { prefs ->
                prefs[KEY_CLIPBOARD_JSON] = serialized
            }
        }
    }

    private fun parseClipboardJson(raw: String): List<ClipboardEntry> {
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val text = obj.optString("text", "")
                    val preview = obj.optString("preview", text.take(140))
                    val chars = obj.optInt("chars", text.length)
                    val lines = obj.optInt("lines", 1)
                    add(
                        ClipboardEntry(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            text = text,
                            preview = preview,
                            lineCount = lines,
                            charCount = chars,
                            timestamp = obj.optLong("ts", 0L),
                            pinned = obj.optBoolean("pinned", false),
                            isLargeCached = obj.optBoolean("large", false),
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun Preferences.toKeyboardSettings(): KeyboardSettings {
        return KeyboardSettings(
            theme = runCatching { KeyboardThemePreset.valueOf(this[KEY_THEME] ?: "") }
                .getOrDefault(KeyboardThemePreset.OBSIDIAN),
            keyboardHeightDp = (this[KEY_HEIGHT] ?: 248).coerceIn(210, 360),
            keyCornerRadiusDp = (this[KEY_RADIUS] ?: 6).coerceIn(2, 16),
            keyFontSizeSp = (this[KEY_FONT_SIZE] ?: 21).coerceIn(14, 26),
            showKeyBorders = this[KEY_BORDERS] ?: true,
            widePersianKeys = this[KEY_WIDE_PERSIAN] ?: true,
            enableTopUtilityBar = this[KEY_ENABLE_TOP_BAR] ?: true,
            enableFnToggle = this[KEY_ENABLE_FN] ?: true,
            enableNumpadMode = this[KEY_ENABLE_NUMPAD] ?: true,
            enableQuickCopyPasteButtons = this[KEY_ENABLE_QUICK_CP] ?: true,
            enableUndoRedoButtons = this[KEY_ENABLE_UNDO_REDO] ?: true,
            enableEmojiPanel = this[KEY_ENABLE_EMOJI] ?: true,
            showNumberRow = this[KEY_NUMBER_ROW] ?: false,
            showPcToolbar = this[KEY_PC_TOOLBAR] ?: false,
            showFunctionRow = this[KEY_FUNCTION_ROW] ?: false,
            showZwnjKey = this[KEY_ZWNJ] ?: true,
            persianDigitsInPersianMode = this[KEY_PERSIAN_DIGITS] ?: true,
            defaultLanguage = runCatching { KeyboardLanguage.valueOf(this[KEY_DEFAULT_LANG] ?: "") }
                .getOrDefault(KeyboardLanguage.PERSIAN),
            enablePersian = this[KEY_ENABLE_PERSIAN] ?: true,
            enableEnglish = this[KEY_ENABLE_ENGLISH] ?: true,
            tabBehavior = runCatching { TabBehavior.valueOf(this[KEY_TAB_BEHAVIOR] ?: "") }
                .getOrDefault(TabBehavior.INSERT_TAB_CHAR),
            enableSpaceSwipe = this[KEY_ENABLE_SPACE_SWIPE] ?: true,
            spaceSwipeMode = runCatching { SpaceSwipeMode.valueOf(this[KEY_SPACE_SWIPE] ?: "") }
                .getOrDefault(SpaceSwipeMode.CURSOR_TRACKPAD),
            backspaceWordSwipeEnabled = this[KEY_BSP_WORD_SWIPE] ?: true,
            ctrlSpaceSwitchesLanguage = this[KEY_CTRL_SPACE] ?: true,
            autoCapitalize = this[KEY_AUTO_CAP] ?: true,
            doubleSpacePeriod = this[KEY_DOUBLE_SPACE] ?: true,
            hapticEnabled = this[KEY_HAPTIC] ?: true,
            hapticStrength = (this[KEY_HAPTIC_STRENGTH] ?: 50).coerceIn(10, 100),
            soundEnabled = this[KEY_SOUND] ?: false,
            keyPopupEnabled = this[KEY_POPUP] ?: true,
            longPressDelayMs = (this[KEY_LONG_PRESS] ?: 340).coerceIn(180, 600),
            keyRepeatSpeedMs = (this[KEY_REPEAT_SPEED] ?: 45).coerceIn(25, 110),
            clipboardHistoryEnabled = this[KEY_CLIPBOARD_ENABLED] ?: true,
        )
    }

    companion object {
        private const val INLINE_CLIP_THRESHOLD = 8_192

        private val KEY_THEME = stringPreferencesKey("theme")
        private val KEY_HEIGHT = intPreferencesKey("height_dp")
        private val KEY_RADIUS = intPreferencesKey("corner_radius_dp")
        private val KEY_FONT_SIZE = intPreferencesKey("font_size_sp")
        private val KEY_BORDERS = booleanPreferencesKey("show_borders")
        private val KEY_WIDE_PERSIAN = booleanPreferencesKey("wide_persian_keys")
        private val KEY_ENABLE_TOP_BAR = booleanPreferencesKey("enable_top_utility_bar")
        private val KEY_ENABLE_FN = booleanPreferencesKey("enable_fn_toggle")
        private val KEY_ENABLE_NUMPAD = booleanPreferencesKey("enable_numpad_mode")
        private val KEY_ENABLE_QUICK_CP = booleanPreferencesKey("enable_quick_cp")
        private val KEY_ENABLE_UNDO_REDO = booleanPreferencesKey("enable_undo_redo")
        private val KEY_ENABLE_EMOJI = booleanPreferencesKey("enable_emoji_panel")
        private val KEY_NUMBER_ROW = booleanPreferencesKey("show_number_row")
        private val KEY_PC_TOOLBAR = booleanPreferencesKey("show_pc_toolbar")
        private val KEY_FUNCTION_ROW = booleanPreferencesKey("show_function_row")
        private val KEY_ZWNJ = booleanPreferencesKey("show_zwnj")
        private val KEY_PERSIAN_DIGITS = booleanPreferencesKey("persian_digits")
        private val KEY_DEFAULT_LANG = stringPreferencesKey("default_language")
        private val KEY_ENABLE_PERSIAN = booleanPreferencesKey("enable_persian")
        private val KEY_ENABLE_ENGLISH = booleanPreferencesKey("enable_english")
        private val KEY_TAB_BEHAVIOR = stringPreferencesKey("tab_behavior")
        private val KEY_ENABLE_SPACE_SWIPE = booleanPreferencesKey("enable_space_swipe")
        private val KEY_SPACE_SWIPE = stringPreferencesKey("space_swipe")
        private val KEY_BSP_WORD_SWIPE = booleanPreferencesKey("backspace_word_swipe")
        private val KEY_CTRL_SPACE = booleanPreferencesKey("ctrl_space_lang")
        private val KEY_AUTO_CAP = booleanPreferencesKey("auto_cap")
        private val KEY_DOUBLE_SPACE = booleanPreferencesKey("double_space_period")
        private val KEY_HAPTIC = booleanPreferencesKey("haptic_enabled")
        private val KEY_HAPTIC_STRENGTH = intPreferencesKey("haptic_strength")
        private val KEY_SOUND = booleanPreferencesKey("sound_enabled")
        private val KEY_POPUP = booleanPreferencesKey("key_popup")
        private val KEY_LONG_PRESS = intPreferencesKey("long_press_ms")
        private val KEY_REPEAT_SPEED = intPreferencesKey("repeat_speed_ms")
        private val KEY_CLIPBOARD_ENABLED = booleanPreferencesKey("clipboard_enabled")
        private val KEY_CLIPBOARD_JSON = stringPreferencesKey("clipboard_json")

        @Volatile
        private var instance: SettingsRepository? = null

        fun getInstance(context: Context): SettingsRepository {
            return instance ?: synchronized(this) {
                instance ?: SettingsRepository(context).also { instance = it }
            }
        }

        private fun countLinesFast(text: String): Int {
            var count = 1
            for (i in 0 until text.length) {
                if (text[i] == '\n') count++
            }
            return count
        }

        private fun buildPreview(text: String): String {
            val sb = StringBuilder(144)
            val limit = minOf(text.length, 140)
            for (i in 0 until limit) {
                val c = text[i]
                sb.append(if (c == '\n' || c == '\r' || c == '\t') ' ' else c)
            }
            if (text.length > 140) sb.append("…")
            return sb.toString()
        }
    }
}
