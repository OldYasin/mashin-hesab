package com.example.ime.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.data.ClipboardEntry
import com.example.data.KeyboardLanguage
import com.example.data.KeyboardSettings
import com.example.ime.engine.KeyboardUiState
import com.example.ime.engine.PcInputController
import com.example.ime.model.KeyAction
import com.example.ime.model.KeyItem
import com.example.ime.model.KeyboardLayouts
import com.example.ime.model.KeyboardMode
import com.example.ime.model.ModifierState
import com.example.ui.components.PCKeyIcons
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.VazirmatnFontFamily
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

private class LayoutBoundsHolder(
    var pos: Offset = Offset.Zero,
    var size: Size = Size.Zero,
)

private data class ActiveKeyOverlay(
    val key: KeyItem,
    val centerX: Float,
    val topY: Float,
    val widthPx: Float,
    val showAlternates: Boolean,
    val selectedAlternateIndex: Int,
)

@Composable
fun KeyboardView(
    uiState: KeyboardUiState,
    settings: KeyboardSettings,
    clipboardEntries: List<ClipboardEntry>,
    controller: PcInputController,
    feedback: KeyboardFeedback,
    onResolveClipText: (ClipboardEntry) -> String,
    onTogglePinClip: (String) -> Unit,
    onDeleteClip: (String) -> Unit,
    onClearUnpinnedClips: () -> Unit,
    onOpenSettings: (() -> Unit)? = null,
    onHideKeyboard: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val palette = resolveKeyboardPalette(settings.theme)
    val latestSettings by rememberUpdatedState(settings)

    val rootBounds = remember { LayoutBoundsHolder() }
    val overlayState = remember { mutableStateOf<ActiveKeyOverlay?>(null) }
    val setOverlay: (ActiveKeyOverlay?) -> Unit = remember { { o -> overlayState.value = o } }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .background(palette.background)
                .onGloballyPositioned { coords ->
                    rootBounds.pos = coords.positionInRoot()
                    rootBounds.size = Size(coords.size.width.toFloat(), coords.size.height.toFloat())
                },
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp),
            ) {
                if (settings.enableTopUtilityBar) {
                    PcUtilityHeaderBar(
                        uiState = uiState,
                        settings = settings,
                        palette = palette,
                        onHideKeyboard = {
                            feedback.performTick(settings)
                            onHideKeyboard?.invoke() ?: controller.hideKeyboard()
                        },
                        onTogglePcPanel = {
                            feedback.performTick(settings)
                            controller.togglePcPanel()
                        },
                        onAction = { action ->
                            feedback.performFeedback(action, settings)
                            controller.onKeyAction(action, settings)
                        },
                        onOpenSettings = {
                            feedback.performTick(settings)
                            onOpenSettings?.invoke() ?: controller.openSettings()
                        },
                    )
                }

                val showPcPanel = uiState.pcPanelOpen &&
                    uiState.mode != KeyboardMode.CLIPBOARD &&
                    uiState.mode != KeyboardMode.EMOJI

                AnimatedVisibility(
                    visible = showPcPanel,
                    enter = slideInVertically(tween(230, easing = FastOutSlowInEasing)) { it / 2 } + fadeIn(tween(200)),
                    exit = slideOutVertically(tween(180, easing = FastOutSlowInEasing)) { it / 2 } + fadeOut(tween(140)),
                ) {
                    PcControlStrip(
                        uiState = uiState,
                        palette = palette,
                        settings = settings,
                        feedback = feedback,
                        onToggleFn = {
                            feedback.performTick(settings)
                            controller.toggleFnRow()
                        },
                        onAction = { action -> controller.onKeyAction(action, settings) },
                    )
                }

                val showFn = settings.enableFnToggle &&
                    ((showPcPanel && uiState.fnRowExpanded) || settings.showFunctionRow) &&
                    uiState.mode != KeyboardMode.CLIPBOARD &&
                    uiState.mode != KeyboardMode.EMOJI

                AnimatedVisibility(
                    visible = showFn,
                    enter = slideInVertically(tween(230, easing = FastOutSlowInEasing)) { it / 2 } + fadeIn(tween(200)),
                    exit = slideOutVertically(tween(180, easing = FastOutSlowInEasing)) { it / 2 } + fadeOut(tween(140)),
                ) {
                    FunctionKeysStrip(
                        palette = palette,
                        settings = settings,
                        feedback = feedback,
                        onAction = { action -> controller.onKeyAction(action, settings) },
                    )
                }

                val bodyHeight = settings.keyboardHeightDp.dp

                when (uiState.mode) {
                    KeyboardMode.CLIPBOARD -> {
                        ClipboardPanel(
                            entries = clipboardEntries,
                            palette = palette,
                            height = bodyHeight,
                            onPasteEntry = { entry ->
                                feedback.performTick(settings)
                                controller.pasteClip(onResolveClipText(entry))
                            },
                            onTogglePin = onTogglePinClip,
                            onDelete = onDeleteClip,
                            onClearUnpinned = onClearUnpinnedClips,
                            onPasteSystemClipboard = {
                                feedback.performTick(settings)
                                controller.onKeyAction(KeyAction.PasteShortcut, settings)
                            },
                            onBack = {
                                feedback.performTick(settings)
                                controller.switchMode(KeyboardMode.LETTERS)
                            },
                        )
                    }

                    KeyboardMode.EMOJI -> {
                        EmojiPanel(
                            palette = palette,
                            height = bodyHeight,
                            onPickEmoji = { emoji ->
                                feedback.performTick(settings)
                                controller.onKeyAction(KeyAction.Text(emoji), settings)
                            },
                            onBackspace = {
                                feedback.performFeedback(KeyAction.Backspace, settings)
                                controller.onKeyAction(KeyAction.Backspace, settings)
                            },
                            onBack = {
                                feedback.performTick(settings)
                                controller.switchMode(KeyboardMode.LETTERS)
                            },
                        )
                    }

                    else -> {
                        val numberRow = remember(uiState.language, uiState.shiftState, settings) {
                            if (settings.showNumberRow && uiState.mode == KeyboardMode.LETTERS) {
                                KeyboardLayouts.buildNumberRow(
                                    language = uiState.language,
                                    shifted = uiState.shiftState != ModifierState.OFF,
                                    settings = settings,
                                )
                            } else {
                                emptyList()
                            }
                        }
                        val rows = remember(uiState.mode, uiState.language, uiState.shiftState, settings, uiState.numpadPersianDigits) {
                            KeyboardLayouts.buildRows(
                                mode = uiState.mode,
                                language = uiState.language,
                                shiftState = uiState.shiftState,
                                settings = settings,
                                numpadPersianDigits = uiState.numpadPersianDigits,
                            )
                        }
                        val allRows = remember(numberRow, rows) {
                            if (numberRow.isNotEmpty()) listOf(numberRow) + rows else rows
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(bodyHeight)
                                .padding(horizontal = 2.dp, vertical = 2.dp),
                        ) {
                            allRows.forEachIndexed { rowIndex, rowKeys ->
                                val isMiddleEnglishRow = uiState.mode == KeyboardMode.LETTERS &&
                                    uiState.language == KeyboardLanguage.ENGLISH &&
                                    ((numberRow.isNotEmpty() && rowIndex == 2) || (numberRow.isEmpty() && rowIndex == 1))

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    if (isMiddleEnglishRow) {
                                        Spacer(modifier = Modifier.weight(0.45f))
                                    }
                                    rowKeys.forEach { keyItem ->
                                        key(keyItem.id) {
                                            KeyboardKeyButton(
                                                key = keyItem,
                                                shiftState = if (keyItem.action == KeyAction.ShiftToggle) uiState.shiftState else ModifierState.OFF,
                                                settings = latestSettings,
                                                palette = palette,
                                                feedback = feedback,
                                                controller = controller,
                                                rootBounds = rootBounds,
                                                onOverlayChange = setOverlay,
                                                modifier = Modifier
                                                    .weight(keyItem.weight)
                                                    .fillMaxHeight(),
                                            )
                                        }
                                    }
                                    if (isMiddleEnglishRow) {
                                        Spacer(modifier = Modifier.weight(0.45f))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            OverlayHost(
                overlayState = overlayState,
                rootBounds = rootBounds,
                palette = palette,
            )
        }
    }
}

@Composable
private fun PcUtilityHeaderBar(
    uiState: KeyboardUiState,
    settings: KeyboardSettings,
    palette: KeyboardPalette,
    onHideKeyboard: () -> Unit,
    onTogglePcPanel: () -> Unit,
    onAction: (KeyAction) -> Unit,
    onOpenSettings: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(palette.toolbarBackground)
            .padding(horizontal = 6.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        // Left fixed cluster: Hide Keyboard button + PC Panel toggle right next to it
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(palette.specialKeyBg.copy(alpha = 0.7f))
                .clickable { onHideKeyboard() }
                .testTag("ime_hide_keyboard_button"),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = PCKeyIcons.HideKeyboard,
                contentDescription = "بستن کیبورد",
                tint = palette.keyText,
                modifier = Modifier.size(24.dp),
            )
        }

        Row(
            modifier = Modifier
                .height(38.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(if (uiState.pcPanelOpen) palette.activeModifierBg else palette.specialKeyBg)
                .border(
                    width = 1.dp,
                    color = if (uiState.pcPanelOpen) palette.activeModifierBg else palette.border,
                    shape = RoundedCornerShape(8.dp),
                )
                .clickable { onTogglePcPanel() }
                .padding(horizontal = 9.dp)
                .testTag("ime_pc_panel_toggle"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Icon(
                imageVector = PCKeyIcons.Terminal,
                contentDescription = "پنل پیسی",
                tint = if (uiState.pcPanelOpen) palette.activeModifierContent else palette.keyText,
                modifier = Modifier.size(20.dp),
            )
            Text(
                text = "PC",
                color = if (uiState.pcPanelOpen) palette.activeModifierContent else palette.keyText,
                fontSize = 14.sp,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
            )
        }

        // Scrollable middle utility icons & quick actions
        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            if (settings.enableEmojiPanel) {
                ToolbarIconButton(
                    icon = PCKeyIcons.Emoji,
                    desc = "ایموجی",
                    active = uiState.mode == KeyboardMode.EMOJI,
                    palette = palette,
                    onClick = { onAction(KeyAction.SwitchMode(KeyboardMode.EMOJI)) },
                )
            }
            if (settings.clipboardHistoryEnabled) {
                ToolbarIconButton(
                    icon = PCKeyIcons.ContentPaste,
                    desc = "کلیپ‌بورد",
                    active = uiState.mode == KeyboardMode.CLIPBOARD,
                    palette = palette,
                    onClick = { onAction(KeyAction.SwitchMode(KeyboardMode.CLIPBOARD)) },
                )
            }
            if (settings.enableQuickCopyPasteButtons) {
                ToolbarActionChip(
                    icon = PCKeyIcons.SelectAll,
                    label = "All",
                    palette = palette,
                    onClick = { onAction(KeyAction.SelectAllShortcut) },
                )
                ToolbarActionChip(
                    icon = PCKeyIcons.ContentCopy,
                    label = "Copy",
                    palette = palette,
                    onClick = { onAction(KeyAction.CopyShortcut) },
                )
                ToolbarActionChip(
                    icon = PCKeyIcons.ContentPaste,
                    label = "Paste",
                    palette = palette,
                    accent = true,
                    onClick = { onAction(KeyAction.PasteShortcut) },
                )
            }
            if (settings.enableUndoRedoButtons) {
                ToolbarIconButton(
                    icon = PCKeyIcons.Undo,
                    desc = "Undo",
                    active = false,
                    palette = palette,
                    onClick = { onAction(KeyAction.UndoShortcut) },
                )
                ToolbarIconButton(
                    icon = PCKeyIcons.Redo,
                    desc = "Redo",
                    active = false,
                    palette = palette,
                    onClick = { onAction(KeyAction.RedoShortcut) },
                )
            }
            ToolbarIconButton(
                icon = Icons.Default.Settings,
                desc = "تنظیمات کیبورد",
                active = false,
                palette = palette,
                onClick = onOpenSettings,
            )
        }

        // Right fixed cluster: Globe + En/Fa language pill (zero popup notifications)
        if (settings.enablePersian && settings.enableEnglish) {
            Row(
                modifier = Modifier
                    .height(38.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .clickable { onAction(KeyAction.SwitchLanguage) }
                    .padding(horizontal = 2.dp)
                    .testTag("ime_lang_toggle"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
            ) {
                Icon(
                    imageVector = PCKeyIcons.Language,
                    contentDescription = "تغییر زبان",
                    tint = palette.keyHintText,
                    modifier = Modifier.size(23.dp),
                )
                Text(
                    text = "En",
                    color = if (uiState.language == KeyboardLanguage.ENGLISH) palette.activeModifierBg else palette.keyHintText,
                    fontSize = 16.sp,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = if (uiState.language == KeyboardLanguage.ENGLISH) FontWeight.Bold else FontWeight.Medium,
                )
                Text(
                    text = "فا",
                    color = if (uiState.language == KeyboardLanguage.PERSIAN) palette.activeModifierBg else palette.keyHintText,
                    fontSize = 17.sp,
                    fontFamily = VazirmatnFontFamily,
                    fontWeight = if (uiState.language == KeyboardLanguage.PERSIAN) FontWeight.Bold else FontWeight.Medium,
                )
            }
        }
    }
}

@Composable
private fun ToolbarActionChip(
    icon: ImageVector,
    label: String,
    palette: KeyboardPalette,
    accent: Boolean = false,
    onClick: () -> Unit,
) {
    val bg = if (accent) palette.accentKeyBg.copy(alpha = 0.22f) else palette.specialKeyBg
    val border = if (accent) palette.accentKeyBg.copy(alpha = 0.65f) else palette.border
    val tint = if (accent) palette.accentKeyBg else palette.keyText
    Row(
        modifier = Modifier
            .height(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(18.dp),
        )
        Text(
            text = label,
            color = palette.keyText,
            fontSize = 13.sp,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
    }
}

@Composable
private fun PcControlStrip(
    uiState: KeyboardUiState,
    palette: KeyboardPalette,
    settings: KeyboardSettings,
    feedback: KeyboardFeedback,
    onToggleFn: () -> Unit,
    onAction: (KeyAction) -> Unit,
) {
    val pcKeys = remember {
        listOf(
            KeyItem("pc_esc", "Esc", action = KeyAction.Escape, isSpecial = true),
            KeyItem("pc_tab", "Tab", action = KeyAction.Tab, isSpecial = true),
            KeyItem("pc_ctrl", "Ctrl", action = KeyAction.CtrlToggle, isSpecial = true),
            KeyItem("pc_alt", "Alt", action = KeyAction.AltToggle, isSpecial = true),
            KeyItem("pc_left", "←", action = KeyAction.ArrowLeft, isSpecial = true, isRepeatable = true),
            KeyItem("pc_down", "↓", action = KeyAction.ArrowDown, isSpecial = true, isRepeatable = true),
            KeyItem("pc_up", "↑", action = KeyAction.ArrowUp, isSpecial = true, isRepeatable = true),
            KeyItem("pc_right", "→", action = KeyAction.ArrowRight, isSpecial = true, isRepeatable = true),
            KeyItem("pc_del", "Del", action = KeyAction.ForwardDelete, isSpecial = true, isRepeatable = true),
            KeyItem("pc_home", "Home", action = KeyAction.Home, isSpecial = true),
            KeyItem("pc_end", "End", action = KeyAction.End, isSpecial = true),
            KeyItem("pc_pgup", "PgUp", action = KeyAction.PageUp, isSpecial = true),
            KeyItem("pc_pgdn", "PgDn", action = KeyAction.PageDown, isSpecial = true),
        )
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(palette.toolbarBackground.copy(alpha = 0.85f))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (settings.enableFnToggle) {
            ToolbarPillButton(
                label = "Fn",
                active = uiState.fnRowExpanded || settings.showFunctionRow,
                palette = palette,
                onClick = onToggleFn,
            )
        }
        pcKeys.forEach { key ->
            val modState = when (key.action) {
                KeyAction.CtrlToggle -> uiState.ctrlState
                KeyAction.AltToggle -> uiState.altState
                else -> ModifierState.OFF
            }
            val bg = when {
                key.action == KeyAction.CtrlToggle && modState != ModifierState.OFF -> palette.activeModifierBg
                key.action == KeyAction.AltToggle && modState != ModifierState.OFF -> palette.altModifierBg
                else -> palette.keyBg
            }
            val fg = when {
                modState != ModifierState.OFF -> palette.activeModifierContent
                else -> palette.keyText
            }
            PcMiniStripKey(
                key = key,
                bg = bg,
                fg = fg,
                border = palette.border,
                isLocked = modState == ModifierState.LOCKED,
                settings = settings,
                feedback = feedback,
                onAction = onAction,
            )
        }
    }
}

@Composable
private fun PcMiniStripKey(
    key: KeyItem,
    bg: Color,
    fg: Color,
    border: Color,
    isLocked: Boolean,
    settings: KeyboardSettings,
    feedback: KeyboardFeedback,
    onAction: (KeyAction) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val latestSettings by rememberUpdatedState(settings)
    val latestOnAction by rememberUpdatedState(onAction)
    var isPressed by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .height(30.dp)
            .widthIn(min = 34.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (isPressed) bg.copy(alpha = 0.72f) else bg)
            .border(1.dp, border.copy(alpha = 0.75f), RoundedCornerShape(6.dp))
            .pointerInput(key.id) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    isPressed = true
                    feedback.performFeedback(key.action, latestSettings)
                    latestOnAction(key.action)

                    var repeatJob: kotlinx.coroutines.Job? = null
                    if (key.isRepeatable) {
                        repeatJob = scope.launch {
                            delay(latestSettings.longPressDelayMs.toLong())
                            while (true) {
                                feedback.performTick(latestSettings)
                                latestOnAction(key.action)
                                delay(latestSettings.keyRepeatSpeedMs.toLong())
                            }
                        }
                    }

                    do {
                        val event = awaitPointerEvent(PointerEventPass.Main)
                    } while (event.changes.any { it.pressed })

                    repeatJob?.cancel()
                    isPressed = false
                }
            }
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        when (key.action) {
            KeyAction.ArrowLeft -> Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "چپ", tint = fg, modifier = Modifier.size(16.dp))
            KeyAction.ArrowRight -> Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "راست", tint = fg, modifier = Modifier.size(16.dp))
            KeyAction.ArrowUp -> Icon(Icons.Default.KeyboardArrowUp, "بالا", tint = fg, modifier = Modifier.size(16.dp))
            KeyAction.ArrowDown -> Icon(Icons.Default.KeyboardArrowDown, "پایین", tint = fg, modifier = Modifier.size(16.dp))
            else -> Text(
                text = if (isLocked) "${key.label}•" else key.label,
                color = fg,
                fontSize = 11.sp,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun FunctionKeysStrip(
    palette: KeyboardPalette,
    settings: KeyboardSettings,
    feedback: KeyboardFeedback,
    onAction: (KeyAction) -> Unit,
) {
    val fnKeys = remember { KeyboardLayouts.buildFunctionRow() }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(palette.toolbarBackground)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 6.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        fnKeys.forEach { key ->
            Box(
                modifier = Modifier
                    .height(28.dp)
                    .widthIn(min = 38.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(palette.specialKeyBg)
                    .border(1.dp, palette.border, RoundedCornerShape(6.dp))
                    .clickable {
                        feedback.performFeedback(key.action, settings)
                        onAction(key.action)
                    }
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = key.label,
                    color = palette.keyText,
                    fontSize = 11.sp,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}

@Composable
private fun ToolbarPillButton(
    label: String,
    active: Boolean,
    palette: KeyboardPalette,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .height(30.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(if (active) palette.activeModifierBg else palette.specialKeyBg)
            .border(1.dp, if (active) palette.activeModifierBg else palette.border, RoundedCornerShape(7.dp))
            .clickable { onClick() }
            .padding(horizontal = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (active) palette.activeModifierContent else palette.keyText,
            fontSize = 11.sp,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun ToolbarIconButton(
    icon: ImageVector,
    desc: String,
    active: Boolean,
    palette: KeyboardPalette,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (active) palette.activeModifierBg else palette.specialKeyBg)
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = desc,
            tint = if (active) palette.activeModifierContent else palette.keyText,
            modifier = Modifier.size(23.dp),
        )
    }
}

@Composable
private fun KeyboardKeyButton(
    key: KeyItem,
    shiftState: ModifierState,
    settings: KeyboardSettings,
    palette: KeyboardPalette,
    feedback: KeyboardFeedback,
    controller: PcInputController,
    rootBounds: LayoutBoundsHolder,
    onOverlayChange: (ActiveKeyOverlay?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scope = rememberCoroutineScope()
    val latestSettings by rememberUpdatedState(settings)
    val latestKey by rememberUpdatedState(key)

    var isPressed by remember { mutableStateOf(false) }
    val keyBounds = remember { LayoutBoundsHolder() }

    val shiftActive = key.action == KeyAction.ShiftToggle && shiftState != ModifierState.OFF
    val cornerRadius = settings.keyCornerRadiusDp.dp

    val bgColor = when {
        shiftActive -> palette.activeModifierBg
        key.isAccent -> if (isPressed) palette.accentKeyBg.copy(alpha = 0.8f) else palette.accentKeyBg
        key.isSpecial -> if (isPressed) palette.specialKeyPressedBg else palette.specialKeyBg
        else -> if (isPressed) palette.keyPressedBg else palette.keyBg
    }

    val textColor = when {
        shiftActive -> palette.activeModifierContent
        key.isAccent -> palette.accentKeyContent
        else -> palette.keyText
    }

    // Outer Box captures touch edge-to-edge (zero dead gaps between keys!), inner Box renders keycap visual
    Box(
        modifier = modifier
            .onGloballyPositioned { coords ->
                keyBounds.pos = coords.positionInRoot()
                keyBounds.size = Size(coords.size.width.toFloat(), coords.size.height.toFloat())
            }
            .pointerInput(key.id) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    isPressed = true

                    val currentKey = latestKey
                    val currentSettings = latestSettings
                    val rootPos = rootBounds.pos
                    val relCenterX = keyBounds.pos.x - rootPos.x + keyBounds.size.width / 2f
                    val relTopY = keyBounds.pos.y - rootPos.y

                    val immediateOnDown = currentKey.action is KeyAction.ShiftToggle ||
                        currentKey.action is KeyAction.CtrlToggle ||
                        currentKey.action is KeyAction.AltToggle ||
                        currentKey.isRepeatable

                    var longPressJob: kotlinx.coroutines.Job? = null
                    var alternatesActive = false
                    var selectedAltIdx = 0
                    var spaceDragged = false
                    var backspaceWordSwiped = false

                    try {
                        if (immediateOnDown) {
                            feedback.performFeedback(currentKey.action, currentSettings)
                            controller.onKeyAction(currentKey.action, currentSettings)
                        } else {
                            feedback.performFeedback(currentKey.action, currentSettings)
                            if (currentSettings.keyPopupEnabled && currentKey.action !is KeyAction.Space && !currentKey.isSpecial) {
                                onOverlayChange(
                                    ActiveKeyOverlay(
                                        key = currentKey,
                                        centerX = relCenterX,
                                        topY = relTopY,
                                        widthPx = keyBounds.size.width,
                                        showAlternates = false,
                                        selectedAlternateIndex = 0,
                                    )
                                )
                            }
                        }

                        var lastX = down.position.x
                        var totalDx = 0f

                        if (currentKey.isRepeatable) {
                            longPressJob = scope.launch {
                                delay(currentSettings.longPressDelayMs.toLong())
                                while (true) {
                                    if (!backspaceWordSwiped) {
                                        feedback.performTick(currentSettings)
                                        controller.onKeyAction(currentKey.action, currentSettings)
                                    }
                                    delay(currentSettings.keyRepeatSpeedMs.toLong())
                                }
                            }
                        } else if (currentKey.alternates.isNotEmpty()) {
                            longPressJob = scope.launch {
                                delay(currentSettings.longPressDelayMs.toLong())
                                alternatesActive = true
                                feedback.performTick(currentSettings)
                                onOverlayChange(
                                    ActiveKeyOverlay(
                                        key = currentKey,
                                        centerX = relCenterX,
                                        topY = relTopY,
                                        widthPx = keyBounds.size.width,
                                        showAlternates = true,
                                        selectedAlternateIndex = 0,
                                    )
                                )
                            }
                        }

                        while (true) {
                            val event = awaitPointerEvent(PointerEventPass.Main)
                            val change = event.changes.firstOrNull { it.id == down.id } ?: event.changes.firstOrNull()
                            if (change == null || !change.pressed) {
                                break
                            }

                            val dx = change.position.x - lastX
                            lastX = change.position.x
                            totalDx += dx

                            if (currentKey.action is KeyAction.Space && currentSettings.enableSpaceSwipe && abs(totalDx) > 20f) {
                                spaceDragged = true
                                controller.onSpaceHorizontalDrag(dx, currentSettings) {
                                    feedback.performTick(currentSettings)
                                }
                                change.consume()
                            } else if (currentKey.action is KeyAction.Backspace && currentSettings.backspaceWordSwipeEnabled && !backspaceWordSwiped && totalDx < -42f) {
                                backspaceWordSwiped = true
                                longPressJob?.cancel()
                                controller.deleteWordBackwardSwipe(currentSettings)
                                feedback.performTick(currentSettings)
                                change.consume()
                            } else if (alternatesActive && currentKey.alternates.isNotEmpty()) {
                                val stepWidth = 44f
                                val idx = ((totalDx / stepWidth).roundToInt()).coerceIn(0, currentKey.alternates.lastIndex)
                                if (idx != selectedAltIdx) {
                                    selectedAltIdx = idx
                                    feedback.performTick(currentSettings)
                                    onOverlayChange(
                                        ActiveKeyOverlay(
                                            key = currentKey,
                                            centerX = relCenterX,
                                            topY = relTopY,
                                            widthPx = keyBounds.size.width,
                                            showAlternates = true,
                                            selectedAlternateIndex = idx,
                                        )
                                    )
                                }
                            }
                        }

                        if (currentKey.action is KeyAction.Space) {
                            if (!spaceDragged) {
                                controller.onKeyAction(KeyAction.Space, currentSettings)
                            }
                        } else if (!immediateOnDown) {
                            if (alternatesActive && currentKey.alternates.isNotEmpty()) {
                                val chosen = currentKey.alternates[selectedAltIdx.coerceIn(0, currentKey.alternates.lastIndex)]
                                controller.onKeyAction(KeyAction.Text(chosen), currentSettings)
                            } else {
                                controller.onKeyAction(currentKey.action, currentSettings)
                            }
                        }
                    } finally {
                        longPressJob?.cancel()
                        isPressed = false
                        onOverlayChange(null)
                        if (currentKey.action is KeyAction.Space) {
                            controller.resetSpaceDrag()
                        }
                    }
                }
            }
            .padding(horizontal = 1.8.dp, vertical = 2.5.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(cornerRadius))
                .background(if (isPressed) Color.Transparent else palette.keyShadow)
                .padding(bottom = if (isPressed) 0.dp else 1.5.dp)
                .clip(RoundedCornerShape(cornerRadius))
                .background(bgColor)
                .then(
                    if (settings.showKeyBorders) {
                        Modifier.border(0.6.dp, palette.border.copy(alpha = 0.65f), RoundedCornerShape(cornerRadius))
                    } else {
                        Modifier
                    }
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (!key.hint.isNullOrEmpty() && !key.isSpecial) {
                Text(
                    text = key.hint,
                    color = palette.keyHintText,
                    fontSize = 9.5.sp,
                    fontFamily = VazirmatnFontFamily,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 2.dp, end = 3.5.dp),
                    maxLines = 1,
                )
            }

            when (key.action) {
                KeyAction.ShiftToggle -> {
                    Icon(
                        imageVector = if (shiftState == ModifierState.LOCKED) {
                            PCKeyIcons.Capslock
                        } else {
                            PCKeyIcons.ShiftArrow
                        },
                        contentDescription = "Shift",
                        tint = textColor,
                        modifier = Modifier.size(20.dp),
                    )
                }

                KeyAction.Backspace -> {
                    Icon(
                        imageVector = PCKeyIcons.Backspace,
                        contentDescription = "پاک کردن",
                        tint = textColor,
                        modifier = Modifier.size(20.dp),
                    )
                }

                KeyAction.Enter -> {
                    Icon(
                        imageVector = PCKeyIcons.KeyboardReturn,
                        contentDescription = "Enter",
                        tint = textColor,
                        modifier = Modifier.size(21.dp),
                    )
                }

                KeyAction.SwitchLanguage -> {
                    Icon(
                        imageVector = PCKeyIcons.Language,
                        contentDescription = "تغییر زبان",
                        tint = textColor,
                        modifier = Modifier.size(19.dp),
                    )
                }

                KeyAction.Space -> {
                    Text(
                        text = key.label,
                        color = palette.keyHintText,
                        fontSize = 11.5.sp,
                        fontFamily = VazirmatnFontFamily,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }

                KeyAction.Zwnj -> {
                    Text(
                        text = key.label,
                        color = textColor,
                        fontSize = settings.keyFontSizeSp.sp,
                        fontFamily = VazirmatnFontFamily,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                    )
                }

                else -> if (key.id == KeyboardLayouts.NUMPAD_KEY_ID) {
                    Icon(
                        imageVector = PCKeyIcons.NumpadGrid,
                        contentDescription = "صفحه اعداد",
                        tint = textColor,
                        modifier = Modifier.size(20.dp),
                    )
                } else {
                    Text(
                        text = key.label,
                        color = textColor,
                        fontSize = if (key.isSpecial) 13.sp else settings.keyFontSizeSp.sp,
                        fontFamily = if (key.isSpecial) JetBrainsMonoFontFamily else VazirmatnFontFamily,
                        fontWeight = if (key.isSpecial) FontWeight.SemiBold else FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                    )
                }
            }
        }
    }
}

@Composable
private fun OverlayHost(
    overlayState: State<ActiveKeyOverlay?>,
    rootBounds: LayoutBoundsHolder,
    palette: KeyboardPalette,
) {
    val active = overlayState.value ?: return
    KeyOverlayPopup(
        overlay = active,
        rootSize = rootBounds.size,
        palette = palette,
    )
}

@Composable
private fun KeyOverlayPopup(
    overlay: ActiveKeyOverlay,
    rootSize: Size,
    palette: KeyboardPalette,
) {
    val density = LocalDensity.current
    val itemCount = if (overlay.showAlternates) overlay.key.alternates.size else 1
    val itemWidthPx = with(density) { 40.dp.toPx() }
    val popupWidthPx = (itemCount * itemWidthPx).coerceAtLeast(overlay.widthPx.coerceAtLeast(with(density) { 46.dp.toPx() }))
    val popupHeightPx = with(density) { 48.dp.toPx() }
    val verticalGapPx = with(density) { 6.dp.toPx() }

    val x = (overlay.centerX - popupWidthPx / 2f).coerceIn(4f, (rootSize.width - popupWidthPx - 4f).coerceAtLeast(4f))
    val y = (overlay.topY - popupHeightPx - verticalGapPx).coerceAtLeast(2f)

    Box(
        modifier = Modifier
            .zIndex(10f)
            .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
            .width(with(density) { popupWidthPx.toDp() })
            .height(with(density) { popupHeightPx.toDp() })
            .shadow(8.dp, RoundedCornerShape(10.dp))
            .clip(RoundedCornerShape(10.dp))
            .background(palette.popupBg)
            .border(1.dp, palette.border, RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center,
    ) {
        if (overlay.showAlternates && overlay.key.alternates.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 3.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                overlay.key.alternates.forEachIndexed { idx, alt ->
                    val selected = idx == overlay.selectedAlternateIndex
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(vertical = 4.dp, horizontal = 2.dp)
                            .clip(RoundedCornerShape(7.dp))
                            .background(if (selected) palette.popupHighlightBg else Color.Transparent),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = alt,
                            color = if (selected) palette.activeModifierContent else palette.keyText,
                            fontSize = 18.sp,
                            fontFamily = VazirmatnFontFamily,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
            }
        } else {
            Text(
                text = overlay.key.label,
                color = palette.keyText,
                fontSize = 24.sp,
                fontFamily = VazirmatnFontFamily,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}
