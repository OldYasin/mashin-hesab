package com.example.ime.engine

import android.view.KeyEvent
import androidx.compose.runtime.Immutable
import com.example.data.KeyboardLanguage
import com.example.data.KeyboardSettings
import com.example.data.SpaceSwipeMode
import com.example.ime.model.KeyAction
import com.example.ime.model.KeyboardMode
import com.example.ime.model.ModifierState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

@Immutable
data class KeyboardUiState(
    val language: KeyboardLanguage = KeyboardLanguage.PERSIAN,
    val mode: KeyboardMode = KeyboardMode.LETTERS,
    val shiftState: ModifierState = ModifierState.OFF,
    val ctrlState: ModifierState = ModifierState.OFF,
    val altState: ModifierState = ModifierState.OFF,
    val fnRowExpanded: Boolean = false,
    val statusToast: String? = null,
)

class PcInputController(
    private val targetProvider: () -> EditorTarget,
    private val onClipboardPasteText: ((String) -> Unit)? = null,
    private val onOpenSettings: (() -> Unit)? = null,
) {
    private val _uiState = MutableStateFlow(KeyboardUiState())
    val uiState: StateFlow<KeyboardUiState> = _uiState.asStateFlow()

    private var lastShiftTapTime = 0L
    private var lastCtrlTapTime = 0L
    private var lastAltTapTime = 0L
    private var lastSpaceTapTime = 0L
    private var trackpadAccumulatedPx = 0f

    fun syncLanguageWithSettings(settings: KeyboardSettings) {
        _uiState.update { current ->
            val validLang = when {
                !settings.enablePersian && settings.enableEnglish -> KeyboardLanguage.ENGLISH
                settings.enablePersian && !settings.enableEnglish -> KeyboardLanguage.PERSIAN
                else -> current.language
            }
            current.copy(
                language = validLang,
                fnRowExpanded = current.fnRowExpanded || settings.showFunctionRow,
            )
        }
    }

    fun setInitialLanguage(language: KeyboardLanguage, settings: KeyboardSettings) {
        val targetLang = when {
            language == KeyboardLanguage.PERSIAN && !settings.enablePersian -> KeyboardLanguage.ENGLISH
            language == KeyboardLanguage.ENGLISH && !settings.enableEnglish -> KeyboardLanguage.PERSIAN
            else -> language
        }
        _uiState.update {
            it.copy(
                language = targetLang,
                fnRowExpanded = settings.showFunctionRow,
            )
        }
    }

    fun toggleFnRow() {
        _uiState.update { it.copy(fnRowExpanded = !it.fnRowExpanded, statusToast = null) }
    }

    fun switchMode(mode: KeyboardMode) {
        _uiState.update { current ->
            val nextMode = if (current.mode == mode && mode != KeyboardMode.LETTERS) {
                KeyboardMode.LETTERS
            } else {
                mode
            }
            current.copy(mode = nextMode, statusToast = null)
        }
    }

    fun switchLanguage(settings: KeyboardSettings) {
        if (!settings.enablePersian || !settings.enableEnglish) return
        _uiState.update { current ->
            val next = if (current.language == KeyboardLanguage.PERSIAN) {
                KeyboardLanguage.ENGLISH
            } else {
                KeyboardLanguage.PERSIAN
            }
            current.copy(
                language = next,
                mode = if (current.mode == KeyboardMode.LETTERS) KeyboardMode.LETTERS else current.mode,
                shiftState = ModifierState.OFF,
                statusToast = if (next == KeyboardLanguage.PERSIAN) "فارسی" else "English",
            )
        }
    }

    fun clearStatusToast() {
        _uiState.update { it.copy(statusToast = null) }
    }

    fun onKeyAction(action: KeyAction, settings: KeyboardSettings) {
        val state = _uiState.value
        val target = targetProvider()

        when (action) {
            KeyAction.ShiftToggle -> {
                val now = System.currentTimeMillis()
                val nextShift = when (state.shiftState) {
                    ModifierState.OFF -> ModifierState.ARMED
                    ModifierState.ARMED -> if (now - lastShiftTapTime < 380L) ModifierState.LOCKED else ModifierState.OFF
                    ModifierState.LOCKED -> ModifierState.OFF
                }
                lastShiftTapTime = now
                _uiState.update { it.copy(shiftState = nextShift, statusToast = if (nextShift == ModifierState.LOCKED) "Caps Lock" else null) }
                return
            }

            KeyAction.CtrlToggle -> {
                val now = System.currentTimeMillis()
                val nextCtrl = when (state.ctrlState) {
                    ModifierState.OFF -> ModifierState.ARMED
                    ModifierState.ARMED -> if (now - lastCtrlTapTime < 380L) ModifierState.LOCKED else ModifierState.OFF
                    ModifierState.LOCKED -> ModifierState.OFF
                }
                lastCtrlTapTime = now
                _uiState.update { it.copy(ctrlState = nextCtrl, statusToast = if (nextCtrl != ModifierState.OFF) "Ctrl" else null) }
                return
            }

            KeyAction.AltToggle -> {
                val now = System.currentTimeMillis()
                val nextAlt = when (state.altState) {
                    ModifierState.OFF -> ModifierState.ARMED
                    ModifierState.ARMED -> if (now - lastAltTapTime < 380L) ModifierState.LOCKED else ModifierState.OFF
                    ModifierState.LOCKED -> ModifierState.OFF
                }
                lastAltTapTime = now
                _uiState.update { it.copy(altState = nextAlt, statusToast = if (nextAlt != ModifierState.OFF) "Alt" else null) }
                return
            }

            KeyAction.SwitchLanguage -> {
                switchLanguage(settings)
                return
            }

            is KeyAction.SwitchMode -> {
                switchMode(action.mode)
                return
            }

            else -> Unit
        }

        val ctrlActive = state.ctrlState != ModifierState.OFF
        val altActive = state.altState != ModifierState.OFF
        val shiftActive = state.shiftState != ModifierState.OFF

        var statusMessage: String? = null

        when (action) {
            is KeyAction.Text -> {
                if (ctrlActive || altActive) {
                    statusMessage = handleModifiedTextKey(
                        text = action.value,
                        keyCode = action.keyCode,
                        ctrl = ctrlActive,
                        alt = altActive,
                        shift = shiftActive,
                        target = target,
                    )
                } else {
                    target.commitText(action.value)
                    maybeApplyAutoCapitalize(settings, target, action.value)
                }
            }

            KeyAction.Backspace -> {
                if (ctrlActive) {
                    target.deleteWordBackward()
                    statusMessage = "Ctrl+Bksp"
                } else {
                    target.deleteBackward(1)
                }
            }

            KeyAction.ForwardDelete -> {
                if (ctrlActive) {
                    target.deleteWordForward()
                    statusMessage = "Ctrl+Del"
                } else {
                    target.deleteForward(1)
                }
            }

            KeyAction.Space -> {
                if (ctrlActive && settings.ctrlSpaceSwitchesLanguage) {
                    switchLanguage(settings)
                    consumeOneShotModifiers()
                    return
                }
                val now = System.currentTimeMillis()
                if (settings.doubleSpacePeriod &&
                    now - lastSpaceTapTime < 320L &&
                    state.language == KeyboardLanguage.ENGLISH
                ) {
                    val before = target.getTextBeforeCursor(2)
                    if (before.endsWith(" ") && before.length >= 2 && !before[before.length - 2].isWhitespace()) {
                        target.deleteBackward(1)
                        target.commitText(". ")
                        lastSpaceTapTime = 0L
                        maybeApplyAutoCapitalize(settings, target, ".")
                        consumeOneShotModifiers()
                        return
                    }
                }
                lastSpaceTapTime = now
                target.commitText(" ")
                maybeApplyAutoCapitalize(settings, target, " ")
            }

            KeyAction.Enter -> {
                if (ctrlActive) {
                    target.sendKeyEvent(KeyEvent.KEYCODE_ENTER, KeyEvent.META_CTRL_ON)
                    statusMessage = "Ctrl+Enter"
                } else {
                    target.performEnter()
                    maybeApplyAutoCapitalize(settings, target, "\n")
                    consumeOneShotModifiers(skipAutoCap = true)
                    return
                }
            }

            KeyAction.Tab -> {
                if (shiftActive) {
                    target.sendKeyEvent(KeyEvent.KEYCODE_TAB, KeyEvent.META_SHIFT_ON)
                    statusMessage = "Shift+Tab"
                } else {
                    target.performTab(settings.tabBehavior)
                }
            }

            KeyAction.Escape -> {
                target.sendKeyEvent(KeyEvent.KEYCODE_ESCAPE, buildMetaState(ctrlActive, altActive, shiftActive))
                statusMessage = "Esc"
            }

            KeyAction.Zwnj -> {
                target.commitText("\u200C")
            }

            KeyAction.ArrowLeft -> target.moveCursorLeft(select = shiftActive, byWord = ctrlActive)
            KeyAction.ArrowRight -> target.moveCursorRight(select = shiftActive, byWord = ctrlActive)
            KeyAction.ArrowUp -> target.moveCursorUp(select = shiftActive)
            KeyAction.ArrowDown -> target.moveCursorDown(select = shiftActive)
            KeyAction.Home -> target.moveHome(select = shiftActive, document = ctrlActive)
            KeyAction.End -> target.moveEnd(select = shiftActive, document = ctrlActive)
            KeyAction.PageUp -> target.movePageUp(select = shiftActive)
            KeyAction.PageDown -> target.movePageDown(select = shiftActive)

            is KeyAction.FunctionKey -> {
                val code = KeyEvent.KEYCODE_F1 + (action.number - 1).coerceIn(0, 11)
                target.sendKeyEvent(code, buildMetaState(ctrlActive, altActive, shiftActive))
                statusMessage = "F${action.number}"
            }

            KeyAction.CopyShortcut -> {
                target.performCopy()
                statusMessage = "کپی شد (Ctrl+C)"
            }
            KeyAction.CutShortcut -> {
                target.performCut()
                statusMessage = "بریده شد (Ctrl+X)"
            }
            KeyAction.PasteShortcut -> {
                target.performPaste()
                statusMessage = "جای‌گذاری (Ctrl+V)"
            }
            KeyAction.SelectAllShortcut -> {
                target.performSelectAll()
                statusMessage = "انتخاب همه (Ctrl+A)"
            }
            KeyAction.UndoShortcut -> {
                target.performUndo()
                statusMessage = "برگشت (Ctrl+Z)"
            }
            KeyAction.RedoShortcut -> {
                target.performRedo()
                statusMessage = "تکرار (Ctrl+Y)"
            }

            KeyAction.ShiftToggle,
            KeyAction.CtrlToggle,
            KeyAction.AltToggle,
            KeyAction.SwitchLanguage,
            is KeyAction.SwitchMode -> Unit
        }

        consumeOneShotModifiers(skipAutoCap = action is KeyAction.Text && !ctrlActive && !altActive)
        if (statusMessage != null) {
            _uiState.update { it.copy(statusToast = statusMessage) }
        }
    }

    fun pasteClip(text: String) {
        onClipboardPasteText?.invoke(text) ?: targetProvider().commitText(text)
    }

    fun deleteWordBackwardSwipe(settings: KeyboardSettings) {
        if (!settings.backspaceWordSwipeEnabled) return
        targetProvider().deleteWordBackward()
    }

    fun onSpaceHorizontalDrag(deltaPx: Float, settings: KeyboardSettings, onTriggerTick: () -> Unit) {
        if (!settings.enableSpaceSwipe) return
        when (settings.spaceSwipeMode) {
            SpaceSwipeMode.CURSOR_TRACKPAD -> {
                trackpadAccumulatedPx += deltaPx
                val stepPx = 18f
                while (trackpadAccumulatedPx >= stepPx) {
                    targetProvider().moveCursorRight(
                        select = _uiState.value.shiftState != ModifierState.OFF,
                        byWord = _uiState.value.ctrlState != ModifierState.OFF,
                    )
                    trackpadAccumulatedPx -= stepPx
                    onTriggerTick()
                }
                while (trackpadAccumulatedPx <= -stepPx) {
                    targetProvider().moveCursorLeft(
                        select = _uiState.value.shiftState != ModifierState.OFF,
                        byWord = _uiState.value.ctrlState != ModifierState.OFF,
                    )
                    trackpadAccumulatedPx += stepPx
                    onTriggerTick()
                }
            }
            SpaceSwipeMode.SWITCH_LANGUAGE -> {
                trackpadAccumulatedPx += deltaPx
                if (kotlin.math.abs(trackpadAccumulatedPx) > 72f) {
                    trackpadAccumulatedPx = 0f
                    switchLanguage(settings)
                    onTriggerTick()
                }
            }
        }
    }

    fun resetSpaceDrag() {
        trackpadAccumulatedPx = 0f
    }

    fun openSettings() {
        onOpenSettings?.invoke()
    }

    fun updateAutoCapitalizeOnCursorStart(settings: KeyboardSettings) {
        if (!settings.autoCapitalize) return
        val state = _uiState.value
        if (state.language != KeyboardLanguage.ENGLISH || state.mode != KeyboardMode.LETTERS) return
        if (state.shiftState == ModifierState.LOCKED) return
        val before = targetProvider().getTextBeforeCursor(16)
        val shouldCap = before.isEmpty() ||
            before.endsWith("\n") ||
            before.trimEnd().let { trimmed ->
                trimmed.endsWith(".") || trimmed.endsWith("!") || trimmed.endsWith("?")
            } && before.lastOrNull()?.isWhitespace() == true
        _uiState.update {
            it.copy(shiftState = if (shouldCap) ModifierState.ARMED else ModifierState.OFF)
        }
    }

    private fun handleModifiedTextKey(
        text: String,
        keyCode: Int?,
        ctrl: Boolean,
        alt: Boolean,
        shift: Boolean,
        target: EditorTarget,
    ): String {
        val lower = text.lowercase()
        if (ctrl && !alt) {
            when (lower) {
                "c", "ز" -> {
                    target.performCopy()
                    return "Ctrl+C (کپی)"
                }
                "x", "ط" -> {
                    target.performCut()
                    return "Ctrl+X (برش)"
                }
                "v", "ر" -> {
                    target.performPaste()
                    return "Ctrl+V (جای‌گذاری)"
                }
                "a", "ش" -> {
                    target.performSelectAll()
                    return "Ctrl+A (انتخاب همه)"
                }
                "z", "ظ" -> {
                    if (shift) {
                        target.performRedo()
                        return "Ctrl+Shift+Z (تکرار)"
                    }
                    target.performUndo()
                    return "Ctrl+Z (برگشت)"
                }
                "y", "غ" -> {
                    target.performRedo()
                    return "Ctrl+Y (تکرار)"
                }
            }
        }

        val resolvedCode = keyCode ?: mapCharToKeyCode(lower)
        if (resolvedCode != null) {
            target.sendKeyEvent(resolvedCode, buildMetaState(ctrl, alt, shift))
        }
        val prefix = buildString {
            if (ctrl) append("Ctrl+")
            if (alt) append("Alt+")
            if (shift) append("Shift+")
            append(text.uppercase())
        }
        return prefix
    }

    private fun maybeApplyAutoCapitalize(
        settings: KeyboardSettings,
        target: EditorTarget,
        committed: String,
    ) {
        if (!settings.autoCapitalize) return
        val state = _uiState.value
        if (state.language != KeyboardLanguage.ENGLISH) return
        if (state.shiftState == ModifierState.LOCKED) return
        if (committed == "\n") {
            _uiState.update { it.copy(shiftState = ModifierState.ARMED) }
            return
        }
        if (committed == " ") {
            val before = target.getTextBeforeCursor(4)
            if (before.endsWith(". ") || before.endsWith("! ") || before.endsWith("? ")) {
                _uiState.update { it.copy(shiftState = ModifierState.ARMED) }
                return
            }
        }
        if (state.shiftState == ModifierState.ARMED) {
            _uiState.update { it.copy(shiftState = ModifierState.OFF) }
        }
    }

    private fun consumeOneShotModifiers(skipAutoCap: Boolean = false) {
        _uiState.update { current ->
            current.copy(
                shiftState = if (!skipAutoCap && current.shiftState == ModifierState.ARMED) ModifierState.OFF else current.shiftState,
                ctrlState = if (current.ctrlState == ModifierState.ARMED) ModifierState.OFF else current.ctrlState,
                altState = if (current.altState == ModifierState.ARMED) ModifierState.OFF else current.altState,
            )
        }
    }

    private fun buildMetaState(ctrl: Boolean, alt: Boolean, shift: Boolean): Int {
        var meta = 0
        if (ctrl) meta = meta or KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        if (alt) meta = meta or KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        if (shift) meta = meta or KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON
        return meta
    }

    private fun mapCharToKeyCode(ch: String): Int? {
        return when (ch) {
            "a" -> KeyEvent.KEYCODE_A
            "b" -> KeyEvent.KEYCODE_B
            "c" -> KeyEvent.KEYCODE_C
            "d" -> KeyEvent.KEYCODE_D
            "e" -> KeyEvent.KEYCODE_E
            "f" -> KeyEvent.KEYCODE_F
            "g" -> KeyEvent.KEYCODE_G
            "h" -> KeyEvent.KEYCODE_H
            "i" -> KeyEvent.KEYCODE_I
            "j" -> KeyEvent.KEYCODE_J
            "k" -> KeyEvent.KEYCODE_K
            "l" -> KeyEvent.KEYCODE_L
            "m" -> KeyEvent.KEYCODE_M
            "n" -> KeyEvent.KEYCODE_N
            "o" -> KeyEvent.KEYCODE_O
            "p" -> KeyEvent.KEYCODE_P
            "q" -> KeyEvent.KEYCODE_Q
            "r" -> KeyEvent.KEYCODE_R
            "s" -> KeyEvent.KEYCODE_S
            "t" -> KeyEvent.KEYCODE_T
            "u" -> KeyEvent.KEYCODE_U
            "v" -> KeyEvent.KEYCODE_V
            "w" -> KeyEvent.KEYCODE_W
            "x" -> KeyEvent.KEYCODE_X
            "y" -> KeyEvent.KEYCODE_Y
            "z" -> KeyEvent.KEYCODE_Z
            else -> null
        }
    }
}
