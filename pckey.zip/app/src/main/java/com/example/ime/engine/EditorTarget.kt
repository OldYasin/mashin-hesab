package com.example.ime.engine

import com.example.data.TabBehavior

interface EditorTarget {
    fun commitText(text: String)
    fun deleteBackward(count: Int = 1)
    fun deleteForward(count: Int = 1)
    fun deleteWordBackward()
    fun deleteWordForward()
    fun getTextBeforeCursor(maxChars: Int): String
    fun getTextAfterCursor(maxChars: Int): String
    fun moveCursorLeft(select: Boolean, byWord: Boolean)
    fun moveCursorRight(select: Boolean, byWord: Boolean)
    fun moveCursorUp(select: Boolean)
    fun moveCursorDown(select: Boolean)
    fun moveHome(select: Boolean, document: Boolean)
    fun moveEnd(select: Boolean, document: Boolean)
    fun movePageUp(select: Boolean)
    fun movePageDown(select: Boolean)
    fun performCopy(): Boolean
    fun performCut(): Boolean
    fun performPaste(): Boolean
    fun performSelectAll(): Boolean
    fun performUndo(): Boolean
    fun performRedo(): Boolean
    fun sendKeyEvent(keyCode: Int, metaState: Int = 0)
    fun performEnter()
    fun performTab(behavior: TabBehavior)
}
