package com.example.ime.model

import androidx.compose.runtime.Immutable

enum class ModifierState {
    OFF,
    ARMED,
    LOCKED,
}

enum class KeyboardMode {
    LETTERS,
    SYMBOLS_1,
    SYMBOLS_2,
    NUMPAD,
    CLIPBOARD,
    EMOJI,
}

sealed interface KeyAction {
    data class Text(val value: String, val keyCode: Int? = null) : KeyAction
    data object Backspace : KeyAction
    data object ForwardDelete : KeyAction
    data object Enter : KeyAction
    data object Space : KeyAction
    data object Tab : KeyAction
    data object Escape : KeyAction
    data object ShiftToggle : KeyAction
    data object CtrlToggle : KeyAction
    data object AltToggle : KeyAction
    data object SwitchLanguage : KeyAction
    data class SwitchMode(val mode: KeyboardMode) : KeyAction
    data object Zwnj : KeyAction
    data object ArrowLeft : KeyAction
    data object ArrowRight : KeyAction
    data object ArrowUp : KeyAction
    data object ArrowDown : KeyAction
    data object Home : KeyAction
    data object End : KeyAction
    data object PageUp : KeyAction
    data object PageDown : KeyAction
    data class FunctionKey(val number: Int) : KeyAction
    data object CopyShortcut : KeyAction
    data object CutShortcut : KeyAction
    data object PasteShortcut : KeyAction
    data object SelectAllShortcut : KeyAction
    data object UndoShortcut : KeyAction
    data object RedoShortcut : KeyAction
}

@Immutable
data class KeyItem(
    val id: String,
    val label: String,
    val hint: String? = null,
    val action: KeyAction,
    val alternates: List<String> = emptyList(),
    val weight: Float = 1f,
    val isSpecial: Boolean = false,
    val isAccent: Boolean = false,
    val isRepeatable: Boolean = false,
)
