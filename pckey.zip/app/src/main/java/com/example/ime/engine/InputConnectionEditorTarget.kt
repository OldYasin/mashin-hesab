package com.example.ime.engine

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import com.example.data.SettingsRepository
import com.example.data.TabBehavior
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.yield

class InputConnectionEditorTarget(
    private val service: InputMethodService,
    private val settingsRepository: SettingsRepository,
) : EditorTarget {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var pasteJob: Job? = null

    private val ic: InputConnection?
        get() = service.currentInputConnection

    private val clipboardManager: ClipboardManager?
        get() = service.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager

    override fun commitText(text: String) {
        if (text.length <= CHUNK_THRESHOLD) {
            ic?.commitText(text, 1)
        } else {
            commitLargeTextChunked(text)
        }
    }

    override fun deleteBackward(count: Int) {
        val conn = ic ?: return
        val selected = conn.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            conn.commitText("", 1)
        } else {
            conn.deleteSurroundingText(count, 0)
        }
    }

    override fun deleteForward(count: Int) {
        val conn = ic ?: return
        val selected = conn.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            conn.commitText("", 1)
        } else {
            val after = conn.getTextAfterCursor(count, 0)
            if (!after.isNullOrEmpty()) {
                conn.deleteSurroundingText(0, minOf(count, after.length))
            } else {
                sendKeyEvent(KeyEvent.KEYCODE_FORWARD_DEL, 0)
            }
        }
    }

    override fun deleteWordBackward() {
        val conn = ic ?: return
        val selected = conn.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            conn.commitText("", 1)
            return
        }
        val before = conn.getTextBeforeCursor(64, 0)?.toString() ?: ""
        if (before.isEmpty()) {
            sendKeyEvent(KeyEvent.KEYCODE_DEL, KeyEvent.META_CTRL_ON)
            return
        }
        val count = computeWordBackwardCount(before)
        if (count > 0) {
            conn.deleteSurroundingText(count, 0)
        }
    }

    override fun deleteWordForward() {
        val conn = ic ?: return
        val selected = conn.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            conn.commitText("", 1)
            return
        }
        val after = conn.getTextAfterCursor(64, 0)?.toString() ?: ""
        if (after.isEmpty()) {
            sendKeyEvent(KeyEvent.KEYCODE_FORWARD_DEL, KeyEvent.META_CTRL_ON)
            return
        }
        val count = computeWordForwardCount(after)
        if (count > 0) {
            conn.deleteSurroundingText(0, count)
        }
    }

    override fun getTextBeforeCursor(maxChars: Int): String {
        return ic?.getTextBeforeCursor(maxChars, 0)?.toString().orEmpty()
    }

    override fun getTextAfterCursor(maxChars: Int): String {
        return ic?.getTextAfterCursor(maxChars, 0)?.toString().orEmpty()
    }

    override fun moveCursorLeft(select: Boolean, byWord: Boolean) {
        sendKeyEvent(KeyEvent.KEYCODE_DPAD_LEFT, buildMeta(select, byWord))
    }

    override fun moveCursorRight(select: Boolean, byWord: Boolean) {
        sendKeyEvent(KeyEvent.KEYCODE_DPAD_RIGHT, buildMeta(select, byWord))
    }

    override fun moveCursorUp(select: Boolean) {
        sendKeyEvent(KeyEvent.KEYCODE_DPAD_UP, buildMeta(select, false))
    }

    override fun moveCursorDown(select: Boolean) {
        sendKeyEvent(KeyEvent.KEYCODE_DPAD_DOWN, buildMeta(select, false))
    }

    override fun moveHome(select: Boolean, document: Boolean) {
        sendKeyEvent(KeyEvent.KEYCODE_MOVE_HOME, buildMeta(select, document))
    }

    override fun moveEnd(select: Boolean, document: Boolean) {
        sendKeyEvent(KeyEvent.KEYCODE_MOVE_END, buildMeta(select, document))
    }

    override fun movePageUp(select: Boolean) {
        sendKeyEvent(KeyEvent.KEYCODE_PAGE_UP, buildMeta(select, false))
    }

    override fun movePageDown(select: Boolean) {
        sendKeyEvent(KeyEvent.KEYCODE_PAGE_DOWN, buildMeta(select, false))
    }

    override fun performCopy(): Boolean {
        val conn = ic ?: return false
        // Executed natively inside the host app's process -> handles 10,000+ lines with zero Binder truncation
        val ok = conn.performContextMenuAction(android.R.id.copy)
        captureClipboardAsync()
        return ok
    }

    override fun performCut(): Boolean {
        val conn = ic ?: return false
        val ok = conn.performContextMenuAction(android.R.id.cut)
        captureClipboardAsync()
        return ok
    }

    override fun performPaste(): Boolean {
        val conn = ic ?: return false
        // Native in-process paste handles massive 10,000+ line clips instantaneously
        if (conn.performContextMenuAction(android.R.id.paste)) {
            return true
        }
        val clipText = clipboardManager?.primaryClip?.getItemAt(0)?.coerceToText(service)?.toString()
            ?: return false
        if (clipText.isEmpty()) return false
        commitText(clipText)
        return true
    }

    fun pasteClipOptimized(text: String) {
        if (text.isEmpty()) return
        val conn = ic ?: return
        runCatching {
            clipboardManager?.setPrimaryClip(ClipData.newPlainText("PCKey", text))
        }
        // Prefer host app's native paste first when clip is huge (bypasses Binder IPC limits)
        if (text.length > CHUNK_THRESHOLD && conn.performContextMenuAction(android.R.id.paste)) {
            return
        }
        commitText(text)
    }

    private fun captureClipboardAsync() {
        scope.launch {
            delay(24L)
            if (com.example.data.isSensitiveClip(clipboardManager)) return@launch
            val text = runCatching {
                clipboardManager?.primaryClip?.getItemAt(0)?.coerceToText(service)?.toString()
            }.getOrNull()
            if (!text.isNullOrBlank()) {
                settingsRepository.addClipboardText(text)
            }
        }
    }

    private fun commitLargeTextChunked(text: String) {
        pasteJob?.cancel()
        pasteJob = scope.launch {
            val len = text.length
            var offset = 0
            while (offset < len) {
                val conn = ic ?: break
                conn.beginBatchEdit()
                var batches = 0
                while (offset < len && batches < 4) {
                    var end = (offset + CHUNK_SIZE).coerceAtMost(len)
                    if (end < len) {
                        val newlineIdx = text.lastIndexOf('\n', end - 1)
                        if (newlineIdx > offset + CHUNK_SIZE / 2) {
                            end = newlineIdx + 1
                        }
                    }
                    conn.commitText(text.substring(offset, end), 1)
                    offset = end
                    batches++
                }
                conn.endBatchEdit()
                if (offset < len) {
                    yield()
                }
            }
        }
    }

    override fun performSelectAll(): Boolean {
        return ic?.performContextMenuAction(android.R.id.selectAll) ?: false
    }

    override fun performUndo(): Boolean {
        val conn = ic ?: return false
        val handled = conn.performContextMenuAction(android.R.id.undo)
        if (!handled) {
            sendKeyEvent(KeyEvent.KEYCODE_Z, KeyEvent.META_CTRL_ON)
        }
        return true
    }

    override fun performRedo(): Boolean {
        val conn = ic ?: return false
        val handled = conn.performContextMenuAction(android.R.id.redo)
        if (!handled) {
            sendKeyEvent(KeyEvent.KEYCODE_Y, KeyEvent.META_CTRL_ON)
        }
        return true
    }

    override fun sendKeyEvent(keyCode: Int, metaState: Int) {
        val conn = ic ?: return
        val now = SystemClock.uptimeMillis()
        conn.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0, metaState))
        conn.sendKeyEvent(KeyEvent(now, now + 8, KeyEvent.ACTION_UP, keyCode, 0, metaState))
    }

    override fun performEnter() {
        val conn = ic ?: return
        val info = service.currentInputEditorInfo
        val imeAction = info?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        val isMultiLine = (info?.inputType ?: 0) and EditorInfo.TYPE_TEXT_FLAG_MULTI_LINE != 0
        if (!isMultiLine && imeAction != EditorInfo.IME_ACTION_NONE && imeAction != EditorInfo.IME_ACTION_UNSPECIFIED) {
            conn.performEditorAction(imeAction)
        } else {
            sendKeyEvent(KeyEvent.KEYCODE_ENTER, 0)
        }
    }

    override fun performTab(behavior: TabBehavior) {
        when (behavior) {
            TabBehavior.INSERT_TAB_CHAR -> commitText("\t")
            TabBehavior.SPACES_4 -> commitText("    ")
            TabBehavior.SPACES_2 -> commitText("  ")
            TabBehavior.NAVIGATE_NEXT_FIELD -> {
                val conn = ic ?: return
                if (!conn.performEditorAction(EditorInfo.IME_ACTION_NEXT)) {
                    sendKeyEvent(KeyEvent.KEYCODE_TAB, 0)
                }
            }
        }
    }

    private fun buildMeta(select: Boolean, byWord: Boolean): Int {
        var meta = 0
        if (select) meta = meta or KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON
        if (byWord) meta = meta or KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        return meta
    }

    companion object {
        private const val CHUNK_THRESHOLD = 8_192
        private const val CHUNK_SIZE = 16_384

        fun computeWordBackwardCount(before: String): Int {
            var i = before.length
            if (i == 0) return 0
            while (i > 0 && before[i - 1].isWhitespace()) {
                i--
            }
            if (i == before.length && i > 0 && !isWordChar(before[i - 1])) {
                return 1
            }
            while (i > 0 && isWordChar(before[i - 1])) {
                i--
            }
            return (before.length - i).coerceAtLeast(1)
        }

        fun computeWordForwardCount(after: String): Int {
            var i = 0
            val len = after.length
            if (len == 0) return 0
            while (i < len && after[i].isWhitespace()) {
                i++
            }
            if (i == 0 && !isWordChar(after[0])) {
                return 1
            }
            while (i < len && isWordChar(after[i])) {
                i++
            }
            return i.coerceAtLeast(1)
        }

        private fun isWordChar(c: Char): Boolean {
            return c.isLetterOrDigit() || c == '_' || c == '\u200C'
        }
    }
}
