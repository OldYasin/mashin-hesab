package com.example.ime

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.data.SettingsRepository
import com.example.ime.engine.InputConnectionEditorTarget
import com.example.ime.engine.PcInputController
import com.example.ime.ui.KeyboardFeedback
import com.example.ime.ui.KeyboardView
import com.example.ime.ui.resolveKeyboardPalette

class PCKeyInputMethodService :
    InputMethodService(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    override val viewModelStore: ViewModelStore = ViewModelStore()

    override val lifecycle: Lifecycle
        get() = lifecycleRegistry

    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    private lateinit var settingsRepository: SettingsRepository
    private lateinit var editorTarget: InputConnectionEditorTarget
    private lateinit var controller: PcInputController
    private lateinit var feedback: KeyboardFeedback
    private var clipboardManager: ClipboardManager? = null

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val text = clipboardManager?.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (!text.isNullOrBlank()) {
            settingsRepository.addClipboardText(text)
        }
    }

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performAttach()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)

        settingsRepository = SettingsRepository.getInstance(this)
        feedback = KeyboardFeedback(this)
        editorTarget = InputConnectionEditorTarget(this, settingsRepository)
        controller = PcInputController(
            targetProvider = { editorTarget },
            onClipboardPasteText = { text ->
                editorTarget.pasteClipOptimized(text)
            },
            onOpenSettings = {
                val intent = Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
            },
        )
        controller.setInitialLanguage(
            language = settingsRepository.settings.value.defaultLanguage,
            settings = settingsRepository.settings.value,
        )

        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboardManager?.addPrimaryClipChangedListener(clipListener)
    }

    override fun onCreateInputView(): View {
        val decorView = window?.window?.decorView
        decorView?.setViewTreeLifecycleOwner(this)
        decorView?.setViewTreeViewModelStoreOwner(this)
        decorView?.setViewTreeSavedStateRegistryOwner(this)

        return ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@PCKeyInputMethodService)
            setViewTreeViewModelStoreOwner(this@PCKeyInputMethodService)
            setViewTreeSavedStateRegistryOwner(this@PCKeyInputMethodService)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                val settings by settingsRepository.settings.collectAsState()
                val uiState by controller.uiState.collectAsState()
                val clips by settingsRepository.clipboardEntries.collectAsState()
                val palette = resolveKeyboardPalette(settings.theme)

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(palette.background)
                        .navigationBarsPadding(),
                ) {
                    KeyboardView(
                        uiState = uiState,
                        settings = settings,
                        clipboardEntries = clips,
                        controller = controller,
                        feedback = feedback,
                        onResolveClipText = { settingsRepository.resolveClipText(it) },
                        onTogglePinClip = { settingsRepository.togglePinClip(it) },
                        onDeleteClip = { settingsRepository.deleteClip(it) },
                        onClearUnpinnedClips = { settingsRepository.clearUnpinnedClips() },
                    )
                }
            }
        }
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val settings = settingsRepository.settings.value
        controller.syncLanguageWithSettings(settings)
        controller.updateAutoCapitalizeOnCursorStart(settings)
    }

    override fun onWindowShown() {
        super.onWindowShown()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }

    override fun onWindowHidden() {
        super.onWindowHidden()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
    }

    override fun onDestroy() {
        clipboardManager?.removePrimaryClipChangedListener(clipListener)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        viewModelStore.clear()
        super.onDestroy()
    }
}
