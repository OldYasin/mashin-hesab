package com.example.ime.model

import android.view.KeyEvent
import com.example.data.KeyboardLanguage
import com.example.data.KeyboardSettings

object KeyboardLayouts {

    const val NUMPAD_KEY_LABEL = "NUMPAD"
    const val NUMPAD_KEY_ID = "bot_numpad"

    private val persianDigits = listOf("۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹", "۰")
    private val latinDigits = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
    private val digitSymbols = listOf("!", "@", "#", "$", "%", "^", "&", "*", "(", ")")
    private val digitKeyCodes = listOf(
        KeyEvent.KEYCODE_1, KeyEvent.KEYCODE_2, KeyEvent.KEYCODE_3, KeyEvent.KEYCODE_4, KeyEvent.KEYCODE_5,
        KeyEvent.KEYCODE_6, KeyEvent.KEYCODE_7, KeyEvent.KEYCODE_8, KeyEvent.KEYCODE_9, KeyEvent.KEYCODE_0,
    )

    fun buildNumberRow(
        language: KeyboardLanguage,
        shifted: Boolean,
        settings: KeyboardSettings,
    ): List<KeyItem> {
        val usePersian = language == KeyboardLanguage.PERSIAN && settings.persianDigitsInPersianMode
        return List(10) { idx ->
            val primary = when {
                shifted -> digitSymbols[idx]
                usePersian -> persianDigits[idx]
                else -> latinDigits[idx]
            }
            val hint = if (shifted) latinDigits[idx] else digitSymbols[idx]
            val alts = buildList {
                if (usePersian) add(latinDigits[idx]) else add(persianDigits[idx])
                add(digitSymbols[idx])
            }
            KeyItem(
                id = "num_$idx",
                label = primary,
                hint = hint,
                action = KeyAction.Text(primary, digitKeyCodes[idx]),
                alternates = alts,
                weight = 1f,
            )
        }
    }

    fun buildFunctionRow(): List<KeyItem> {
        return (1..12).map { num ->
            KeyItem(
                id = "fn_$num",
                label = "F$num",
                action = KeyAction.FunctionKey(num),
                weight = 1f,
                isSpecial = true,
            )
        }
    }

    fun buildRows(
        mode: KeyboardMode,
        language: KeyboardLanguage,
        shiftState: ModifierState,
        settings: KeyboardSettings,
        numpadPersianDigits: Boolean? = null,
    ): List<List<KeyItem>> {
        val shifted = shiftState != ModifierState.OFF
        return when (mode) {
            KeyboardMode.LETTERS -> when (language) {
                KeyboardLanguage.PERSIAN -> buildPersianRows(shifted, settings)
                KeyboardLanguage.ENGLISH -> buildEnglishRows(shifted, settings)
            }
            KeyboardMode.SYMBOLS_1 -> buildSymbols1Rows(language, settings)
            KeyboardMode.SYMBOLS_2 -> buildSymbols2Rows(language, settings)
            KeyboardMode.NUMPAD -> buildNumpadRows(language, settings, numpadPersianDigits)
            KeyboardMode.CLIPBOARD, KeyboardMode.EMOJI -> emptyList()
        }
    }

    private fun buildEnglishRows(
        shifted: Boolean,
        settings: KeyboardSettings,
    ): List<List<KeyItem>> {
        val row1Chars = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
        val row1Alts = listOf(
            listOf("1", "~"), listOf("2", "@"), listOf("3", "é", "è", "ê", "ë"),
            listOf("4", "®"), listOf("5", "™"), listOf("6"),
            listOf("7", "ú", "ü", "û", "ù"), listOf("8", "í", "î", "ï"),
            listOf("9", "ó", "ö", "ô", "ò"), listOf("0", "π"),
        )
        val row1Codes = listOf(
            KeyEvent.KEYCODE_Q, KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_E, KeyEvent.KEYCODE_R, KeyEvent.KEYCODE_T,
            KeyEvent.KEYCODE_Y, KeyEvent.KEYCODE_U, KeyEvent.KEYCODE_I, KeyEvent.KEYCODE_O, KeyEvent.KEYCODE_P,
        )

        val row2Chars = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
        val row2Alts = listOf(
            listOf("á", "à", "â", "ä", "æ", "@"), listOf("ß", "§", "$"), listOf("°"),
            listOf("#"), listOf("&"), listOf("-"), listOf("+"), listOf("("), listOf(")"),
        )
        val row2Codes = listOf(
            KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_G,
            KeyEvent.KEYCODE_H, KeyEvent.KEYCODE_J, KeyEvent.KEYCODE_K, KeyEvent.KEYCODE_L,
        )

        val row3Chars = listOf("z", "x", "c", "v", "b", "n", "m")
        val row3Alts = listOf(
            listOf("*"), listOf("\""), listOf("ç", "ć", "©"), listOf("'"),
            listOf(":"), listOf("ñ", ";"), listOf("?", "/"),
        )
        val row3Codes = listOf(
            KeyEvent.KEYCODE_Z, KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_C, KeyEvent.KEYCODE_V,
            KeyEvent.KEYCODE_B, KeyEvent.KEYCODE_N, KeyEvent.KEYCODE_M,
        )

        val r1 = row1Chars.mapIndexed { i, ch ->
            val label = if (shifted) ch.uppercase() else ch
            KeyItem(
                id = "en_r1_$i",
                label = label,
                hint = if (!settings.showNumberRow) latinDigits[i] else null,
                action = KeyAction.Text(label, row1Codes[i]),
                alternates = row1Alts[i],
                weight = 1f,
            )
        }
        val r2 = row2Chars.mapIndexed { i, ch ->
            val label = if (shifted) ch.uppercase() else ch
            KeyItem(
                id = "en_r2_$i",
                label = label,
                action = KeyAction.Text(label, row2Codes[i]),
                alternates = row2Alts[i],
                weight = 1f,
            )
        }
        val r3 = buildList {
            add(
                KeyItem(
                    id = "en_shift",
                    label = "SHIFT",
                    action = KeyAction.ShiftToggle,
                    weight = 1.45f,
                    isSpecial = true,
                )
            )
            row3Chars.forEachIndexed { i, ch ->
                val label = if (shifted) ch.uppercase() else ch
                add(
                    KeyItem(
                        id = "en_r3_$i",
                        label = label,
                        action = KeyAction.Text(label, row3Codes[i]),
                        alternates = row3Alts[i],
                        weight = 1f,
                    )
                )
            }
            add(
                KeyItem(
                    id = "en_bsp",
                    label = "DEL",
                    action = KeyAction.Backspace,
                    weight = 1.45f,
                    isSpecial = true,
                    isRepeatable = true,
                )
            )
        }

        val r4 = buildBottomRow(
            leftModeLabel = null,
            leftTargetMode = KeyboardMode.LETTERS,
            secondaryModeLabel = null,
            secondaryTargetMode = KeyboardMode.SYMBOLS_1,
            language = KeyboardLanguage.ENGLISH,
            settings = settings,
        )

        return listOf(r1, r2, r3, r4)
    }

    /**
     * Exact ergonomic 4-row Persian layout matching the screenshot:
     * Row 1 (11 keys): ض ص ق ف غ ع ه خ ح ج چ (with top-right digit hints ۱..۰ and @)
     * Row 2 (11 keys): ش س ی ب ل ا ت ن م ک گ (with hints ئ, آ, ك)
     * Row 3 (10 letters + wide Backspace): ظ ط ژ ز ر ذ د پ و ث [Backspace]
     * Row 4: #+=  123  ،  [Space]  .  نیم‌ف  [Enter]
     */
    private fun buildPersianRows(
        shifted: Boolean,
        settings: KeyboardSettings,
    ): List<List<KeyItem>> {
        val useFaDigits = settings.persianDigitsInPersianMode
        val digits = if (useFaDigits) persianDigits else latinDigits

        val r1Normal = listOf("ض", "ص", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "چ")
        val r1Hints = listOf(
            digits[0], digits[1], digits[2], digits[3], digits[4],
            digits[5], digits[6], digits[7], digits[8], digits[9], "@",
        )
        val r1Alts = listOf(
            listOf(digits[0], "1", "َ"),
            listOf(digits[1], "2", "ُ"),
            listOf(digits[2], "3", "ِ"),
            listOf(digits[3], "4", "ّ"),
            listOf(digits[4], "5", "ً"),
            listOf(digits[5], "6", "ٌ"),
            listOf(digits[6], "7", "ة", "ۀ", "ه‍"),
            listOf(digits[7], "8", "×"),
            listOf(digits[8], "9", "«"),
            listOf(digits[9], "0", "»"),
            listOf("@", "#", "«", "»"),
        )

        val r2Normal = listOf("ش", "س", "ی", "ب", "ل", "ا", "ت", "ن", "م", "ک", "گ")
        val r2Hints = listOf(null, null, "ئ", null, null, "آ", null, null, null, "ك", null)
        val r2Alts = listOf(
            listOf("ٍ"), listOf("ٌ"), listOf("ئ", "ي", "ى"), listOf("ً"),
            listOf("لآ"), listOf("آ", "أ", "إ", "ء"), listOf("ـ", "ّ"),
            listOf("،"), listOf("؛"), listOf("ك"), listOf("«", "»"),
        )

        val r3Normal = listOf("ظ", "ط", "ژ", "ز", "ر", "ذ", "د", "پ", "و", "ث")
        val r3Hints = listOf(null, null, null, null, null, null, null, null, "ؤ", null)
        val r3Alts = listOf(
            emptyList(), listOf("ْ"), emptyList(), emptyList(), listOf("﷼"),
            emptyList(), listOf("ـ"), emptyList(), listOf("ؤ"), listOf("ً", "ٌ", "ٍ"),
        )

        val r1 = List(r1Normal.size) { i ->
            val ch = if (shifted) r1Alts[i].firstOrNull() ?: r1Normal[i] else r1Normal[i]
            KeyItem(
                id = "fa_r1_$i",
                label = ch,
                hint = if (!settings.showNumberRow) r1Hints[i] else null,
                action = KeyAction.Text(ch),
                alternates = r1Alts[i],
                weight = 1f,
            )
        }

        val r2 = List(r2Normal.size) { i ->
            val ch = r2Normal[i]
            KeyItem(
                id = "fa_r2_$i",
                label = ch,
                hint = r2Hints[i],
                action = KeyAction.Text(ch),
                alternates = r2Alts[i],
                weight = 1f,
            )
        }

        val r3 = buildList {
            for (i in r3Normal.indices) {
                val ch = r3Normal[i]
                add(
                    KeyItem(
                        id = "fa_r3_$i",
                        label = ch,
                        hint = r3Hints[i],
                        action = KeyAction.Text(ch),
                        alternates = r3Alts[i],
                        weight = 1f,
                    )
                )
            }
            add(
                KeyItem(
                    id = "fa_bsp",
                    label = "DEL",
                    action = KeyAction.Backspace,
                    weight = 1.45f,
                    isSpecial = true,
                    isRepeatable = true,
                )
            )
        }

        val r4 = buildBottomRow(
            leftModeLabel = null,
            leftTargetMode = KeyboardMode.LETTERS,
            secondaryModeLabel = "123",
            secondaryTargetMode = KeyboardMode.SYMBOLS_1,
            language = KeyboardLanguage.PERSIAN,
            settings = settings,
        )

        return listOf(r1, r2, r3, r4)
    }

    private fun buildSymbols1Rows(
        language: KeyboardLanguage,
        settings: KeyboardSettings,
    ): List<List<KeyItem>> {
        val usePersianDigits = language == KeyboardLanguage.PERSIAN && settings.persianDigitsInPersianMode
        val nums = if (usePersianDigits) persianDigits else latinDigits

        val r1 = nums.mapIndexed { i, s ->
            KeyItem(
                id = "sym1_r1_$i",
                label = s,
                hint = if (usePersianDigits) latinDigits[i] else persianDigits[i],
                action = KeyAction.Text(s, digitKeyCodes[i]),
                alternates = listOf(if (usePersianDigits) latinDigits[i] else persianDigits[i]),
                weight = 1f,
            )
        }
        val r2 = listOf("@", "#", "$", "_", "&", "-", "+", "(", ")", "/").mapIndexed { i, s ->
            KeyItem(id = "sym1_r2_$i", label = s, action = KeyAction.Text(s), weight = 1f)
        }
        val r3 = buildList {
            add(
                KeyItem(
                    id = "sym1_more",
                    label = "#+=",
                    action = KeyAction.SwitchMode(KeyboardMode.SYMBOLS_2),
                    weight = 1.45f,
                    isSpecial = true,
                )
            )
            val mid = if (language == KeyboardLanguage.PERSIAN) {
                listOf("*", "\"", "'", ":", "؛", "!", "؟")
            } else {
                listOf("*", "\"", "'", ":", ";", "!", "?")
            }
            mid.forEachIndexed { i, s ->
                add(KeyItem(id = "sym1_r3_$i", label = s, action = KeyAction.Text(s), weight = 1f))
            }
            add(
                KeyItem(
                    id = "sym1_bsp",
                    label = "DEL",
                    action = KeyAction.Backspace,
                    weight = 1.45f,
                    isSpecial = true,
                    isRepeatable = true,
                )
            )
        }
        val r4 = buildBottomRow(
            leftModeLabel = if (settings.enableNumpadMode) NUMPAD_KEY_LABEL else null,
            leftTargetMode = KeyboardMode.NUMPAD,
            secondaryModeLabel = if (language == KeyboardLanguage.PERSIAN) "اب‌پ" else "ABC",
            secondaryTargetMode = KeyboardMode.LETTERS,
            language = language,
            settings = settings,
        )
        return listOf(r1, r2, r3, r4)
    }

    private fun buildSymbols2Rows(
        language: KeyboardLanguage,
        settings: KeyboardSettings,
    ): List<List<KeyItem>> {
        val r1 = listOf("~", "`", "|", "•", "√", "π", "÷", "×", "¶", "Δ").mapIndexed { i, s ->
            KeyItem(id = "sym2_r1_$i", label = s, action = KeyAction.Text(s), weight = 1f)
        }
        val r2 = listOf("£", "€", "$", "﷼", "^", "°", "=", "{", "}", "\\").mapIndexed { i, s ->
            KeyItem(id = "sym2_r2_$i", label = s, action = KeyAction.Text(s), weight = 1f)
        }
        val r3 = buildList {
            add(
                KeyItem(
                    id = "sym2_back",
                    label = "123",
                    action = KeyAction.SwitchMode(KeyboardMode.SYMBOLS_1),
                    weight = 1.45f,
                    isSpecial = true,
                )
            )
            listOf("%", "©", "®", "™", "[", "]", "<", ">").forEachIndexed { i, s ->
                add(KeyItem(id = "sym2_r3_$i", label = s, action = KeyAction.Text(s), weight = 1f))
            }
            add(
                KeyItem(
                    id = "sym2_bsp",
                    label = "DEL",
                    action = KeyAction.Backspace,
                    weight = 1.45f,
                    isSpecial = true,
                    isRepeatable = true,
                )
            )
        }
        val r4 = buildBottomRow(
            leftModeLabel = null,
            leftTargetMode = KeyboardMode.LETTERS,
            secondaryModeLabel = if (language == KeyboardLanguage.PERSIAN) "اب‌پ" else "ABC",
            secondaryTargetMode = KeyboardMode.LETTERS,
            language = language,
            settings = settings,
        )
        return listOf(r1, r2, r3, r4)
    }

    private fun buildNumpadRows(
        language: KeyboardLanguage,
        settings: KeyboardSettings,
        persianOverride: Boolean?,
    ): List<List<KeyItem>> {
        val usePersian = persianOverride
            ?: (language == KeyboardLanguage.PERSIAN && settings.persianDigitsInPersianMode)
        fun d(n: Int): String = if (usePersian) persianDigits[(n + 9) % 10] else n.toString()

        val r1 = listOf(
            KeyItem("np_7", d(7), action = KeyAction.Text(d(7), KeyEvent.KEYCODE_7), weight = 1.15f),
            KeyItem("np_8", d(8), action = KeyAction.Text(d(8), KeyEvent.KEYCODE_8), weight = 1.15f),
            KeyItem("np_9", d(9), action = KeyAction.Text(d(9), KeyEvent.KEYCODE_9), weight = 1.15f),
            KeyItem("np_div", "/", action = KeyAction.Text("/"), weight = 0.9f, isSpecial = true),
            KeyItem("np_bsp", "DEL", action = KeyAction.Backspace, weight = 1.1f, isSpecial = true, isRepeatable = true),
        )
        val r2 = listOf(
            KeyItem("np_4", d(4), action = KeyAction.Text(d(4), KeyEvent.KEYCODE_4), weight = 1.15f),
            KeyItem("np_5", d(5), action = KeyAction.Text(d(5), KeyEvent.KEYCODE_5), weight = 1.15f),
            KeyItem("np_6", d(6), action = KeyAction.Text(d(6), KeyEvent.KEYCODE_6), weight = 1.15f),
            KeyItem("np_mul", "*", action = KeyAction.Text("*"), weight = 0.9f, isSpecial = true),
            KeyItem("np_fdel", "Del", action = KeyAction.ForwardDelete, weight = 1.1f, isSpecial = true, isRepeatable = true),
        )
        val r3 = listOf(
            KeyItem("np_1", d(1), action = KeyAction.Text(d(1), KeyEvent.KEYCODE_1), weight = 1.15f),
            KeyItem("np_2", d(2), action = KeyAction.Text(d(2), KeyEvent.KEYCODE_2), weight = 1.15f),
            KeyItem("np_3", d(3), action = KeyAction.Text(d(3), KeyEvent.KEYCODE_3), weight = 1.15f),
            KeyItem("np_sub", "-", action = KeyAction.Text("-"), weight = 0.9f, isSpecial = true),
            KeyItem("np_tab", "Tab", action = KeyAction.Tab, weight = 1.1f, isSpecial = true),
        )
        val r4 = listOf(
            KeyItem(
                id = "np_abc",
                label = if (language == KeyboardLanguage.PERSIAN) "اب‌پ" else "ABC",
                action = KeyAction.SwitchMode(KeyboardMode.LETTERS),
                weight = 1.05f,
                isSpecial = true,
            ),
            KeyItem(
                id = "np_fa_toggle",
                label = if (usePersian) "123" else "۱۲۳",
                action = KeyAction.ToggleNumpadDigits,
                weight = 0.95f,
                isSpecial = true,
            ),
            KeyItem("np_0", d(0), action = KeyAction.Text(d(0), KeyEvent.KEYCODE_0), weight = 1.05f),
            KeyItem("np_dot", ".", alternates = listOf(",", "٫", "٬"), action = KeyAction.Text("."), weight = 0.85f),
            KeyItem("np_plus", "+", action = KeyAction.Text("+"), weight = 0.8f, isSpecial = true),
            KeyItem("np_eq", "=", action = KeyAction.Text("="), weight = 0.8f, isSpecial = true),
            KeyItem("np_enter", "ENTER", action = KeyAction.Enter, weight = 1.1f, isAccent = true),
        )
        return listOf(r1, r2, r3, r4)
    }

    private fun buildBottomRow(
        leftModeLabel: String?,
        leftTargetMode: KeyboardMode,
        secondaryModeLabel: String?,
        secondaryTargetMode: KeyboardMode,
        language: KeyboardLanguage,
        settings: KeyboardSettings,
    ): List<KeyItem> {
        val showZwnj = language == KeyboardLanguage.PERSIAN && settings.showZwnjKey
        val commaLabel = if (language == KeyboardLanguage.PERSIAN) "،" else ","
        val dotAlternates = if (language == KeyboardLanguage.PERSIAN) {
            listOf(".", "؟", "!", "؛", ":", "…", "/")
        } else {
            listOf(".", ",", "?", "!", ":", ";", "-", "'", "\"", "/")
        }

        // Keep the space bar centered: left mode keys + comma must weigh the same as dot + zwnj + enter.
        val rightWeight = 0.85f + (if (showZwnj) 0.9f else 0f) + 1.45f
        val commaWeight = 0.85f
        val modeKeys = listOfNotNull(leftModeLabel, secondaryModeLabel).size.coerceAtLeast(1)
        val modeWeight = (rightWeight - commaWeight) / modeKeys

        return buildList {
            if (leftModeLabel != null) {
                add(
                    KeyItem(
                        id = if (leftTargetMode == KeyboardMode.NUMPAD) NUMPAD_KEY_ID else "bot_sym2",
                        label = leftModeLabel,
                        action = KeyAction.SwitchMode(leftTargetMode),
                        weight = modeWeight,
                        isSpecial = true,
                    )
                )
            }
            if (secondaryModeLabel != null) {
                add(
                    KeyItem(
                        id = "bot_sym1",
                        label = secondaryModeLabel,
                        action = KeyAction.SwitchMode(secondaryTargetMode),
                        weight = modeWeight,
                        isSpecial = true,
                    )
                )
            }
            add(
                KeyItem(
                    id = "bot_comma",
                    label = commaLabel,
                    action = KeyAction.Text(commaLabel),
                    alternates = if (language == KeyboardLanguage.PERSIAN) listOf("،", ",", "؛") else listOf(",", ";", ":"),
                    weight = commaWeight,
                )
            )
            add(
                KeyItem(
                    id = "bot_space",
                    label = if (language == KeyboardLanguage.PERSIAN) "◄  فا  ►" else "◄  EN  ►",
                    action = KeyAction.Space,
                    weight = if (showZwnj) 3.35f else 4.15f,
                )
            )
            add(
                KeyItem(
                    id = "bot_dot",
                    label = ".",
                    hint = if (language == KeyboardLanguage.PERSIAN) "؟!" else "?!",
                    action = KeyAction.Text("."),
                    alternates = dotAlternates,
                    weight = 0.85f,
                )
            )
            if (showZwnj) {
                add(
                    KeyItem(
                        id = "bot_zwnj",
                        label = "يـ",
                        hint = "نیم‌ف",
                        action = KeyAction.Zwnj,
                        alternates = listOf("\u200C", "ـ"),
                        weight = 0.9f,
                    )
                )
            }
            add(
                KeyItem(
                    id = "bot_enter",
                    label = "ENTER",
                    action = KeyAction.Enter,
                    weight = 1.45f,
                    isAccent = true,
                )
            )
        }
    }
}
