package com.example.ime.model

import android.view.KeyEvent
import com.example.data.KeyboardLanguage
import com.example.data.KeyboardSettings

object KeyboardLayouts {

    private val persianDigits = listOf("۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹", "۰")
    private val latinDigits = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
    private val digitSymbols = listOf("!", "@", "#", "$", "%", "^", "&", "*", "(", ")")
    private val digitKeyCodes = listOf(
        KeyEvent.KEYCODE_1, KeyEvent.KEYCODE_2, KeyEvent.KEYCODE_3, KeyEvent.KEYCODE_4, KeyEvent.KEYCODE_5,
        KeyEvent.KEYCODE_6, KeyEvent.KEYCODE_7, KeyEvent.KEYCODE_8, KeyEvent.KEYCODE_9, KeyEvent.KEYCODE_0,
    )

    fun buildNumberRow(
        language: KeyboardLanguage,
        shifted: Boolean,
        settings: KeyboardSettings,
    ): List<KeyItem> {
        val usePersian = language == KeyboardLanguage.PERSIAN && settings.persianDigitsInPersianMode
        return List(10) { idx ->
            val primary = when {
                shifted -> digitSymbols[idx]
                usePersian -> persianDigits[idx]
                else -> latinDigits[idx]
            }
            val hint = if (shifted) latinDigits[idx] else digitSymbols[idx]
            val alts = buildList {
                if (usePersian) add(latinDigits[idx]) else add(persianDigits[idx])
                add(digitSymbols[idx])
            }
            KeyItem(
                id = "num_$idx",
                label = primary,
                hint = hint,
                action = KeyAction.Text(primary, digitKeyCodes[idx]),
                alternates = alts,
                weight = 1f,
            )
        }
    }

    fun buildFunctionRow(): List<KeyItem> {
        return (1..12).map { num ->
            KeyItem(
                id = "fn_$num",
                label = "F$num",
                action = KeyAction.FunctionKey(num),
                weight = 1f,
                isSpecial = true,
            )
        }
    }

    fun buildRows(
        mode: KeyboardMode,
        language: KeyboardLanguage,
        shiftState: ModifierState,
        settings: KeyboardSettings,
    ): List<List<KeyItem>> {
        val shifted = shiftState != ModifierState.OFF
        return when (mode) {
            KeyboardMode.LETTERS -> when (language) {
                KeyboardLanguage.PERSIAN -> buildPersianRows(shifted, settings)
                KeyboardLanguage.ENGLISH -> buildEnglishRows(shifted, settings)
            }
            KeyboardMode.SYMBOLS_1 -> buildSymbols1Rows(language, settings)
            KeyboardMode.SYMBOLS_2 -> buildSymbols2Rows(language, settings)
            KeyboardMode.NUMPAD -> buildNumpadRows(language, settings)
            KeyboardMode.CLIPBOARD, KeyboardMode.EMOJI -> emptyList()
        }
    }

    private fun buildEnglishRows(
        shifted: Boolean,
        settings: KeyboardSettings,
    ): List<List<KeyItem>> {
        val row1Chars = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
        val row1Alts = listOf(
            listOf("1", "~"), listOf("2", "@"), listOf("3", "é", "è", "ê", "ë"),
            listOf("4", "®"), listOf("5", "™"), listOf("6"),
            listOf("7", "ú", "ü", "û", "ù"), listOf("8", "í", "î", "ï"),
            listOf("9", "ó", "ö", "ô", "ò"), listOf("0", "π"),
        )
        val row1Codes = listOf(
            KeyEvent.KEYCODE_Q, KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_E, KeyEvent.KEYCODE_R, KeyEvent.KEYCODE_T,
            KeyEvent.KEYCODE_Y, KeyEvent.KEYCODE_U, KeyEvent.KEYCODE_I, KeyEvent.KEYCODE_O, KeyEvent.KEYCODE_P,
        )

        val row2Chars = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
        val row2Alts = listOf(
            listOf("á", "à", "â", "ä", "æ", "@"), listOf("ß", "§", "$"), listOf("°"),
            listOf("#"), listOf("&"), listOf("-"), listOf("+"), listOf("("), listOf(")"),
        )
        val row2Codes = listOf(
            KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_G,
            KeyEvent.KEYCODE_H, KeyEvent.KEYCODE_J, KeyEvent.KEYCODE_K, KeyEvent.KEYCODE_L,
        )

        val row3Chars = listOf("z", "x", "c", "v", "b", "n", "m")
        val row3Alts = listOf(
            listOf("*"), listOf("\""), listOf("ç", "ć", "©"), listOf("'"),
            listOf(":"), listOf("ñ", ";"), listOf("?", "/"),
        )
        val row3Codes = listOf(
            KeyEvent.KEYCODE_Z, KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_C, KeyEvent.KEYCODE_V,
            KeyEvent.KEYCODE_B, KeyEvent.KEYCODE_N, KeyEvent.KEYCODE_M,
        )

        val r1 = row1Chars.mapIndexed { i, ch ->
            val label = if (shifted) ch.uppercase() else ch
            KeyItem(
                id = "en_r1_$i",
                label = label,
                hint = if (!settings.showNumberRow) latinDigits[i] else null,
                action = KeyAction.Text(label, row1Codes[i]),
                alternates = row1Alts[i],
                weight = 1f,
            )
        }
        val r2 = row2Chars.mapIndexed { i, ch ->
            val label = if (shifted) ch.uppercase() else ch
            KeyItem(
                id = "en_r2_$i",
                label = label,
                action = KeyAction.Text(label, row2Codes[i]),
                alternates = row2Alts[i],
                weight = 1f,
            )
        }
        val r3 = buildList {
            add(
                KeyItem(
                    id = "en_shift",
                    label = "SHIFT",
                    action = KeyAction.ShiftToggle,
                    weight = 1.45f,
                    isSpecial = true,
                )
            )
            row3Chars.forEachIndexed { i, ch ->
                val label = if (shifted) ch.uppercase() else ch
                add(
                    KeyItem(
                        id = "en_r3_$i",
                        label = label,
                        action = KeyAction.Text(label, row3Codes[i]),
                        alternates = row3Alts[i],
                        weight = 1f,
                    )
                )
            }
            add(
                KeyItem(
                    id = "en_bsp",
                    label = "DEL",
                    action = KeyAction.Backspace,
                    weight = 1.45f,
                    isSpecial = true,
                    isRepeatable = true,
                )
            )
        }

        val r4 = buildBottomRow(
            modeKeyLabel = "?123",
            targetMode = KeyboardMode.SYMBOLS_1,
            language = KeyboardLanguage.ENGLISH,
            settings = settings,
        )

        return listOf(r1, r2, r3, r4)
    }

    private fun buildPersianRows(
        shifted: Boolean,
        settings: KeyboardSettings,
    ): List<List<KeyItem>> {
        val wide = settings.widePersianKeys

        val r1Normal = if (wide) {
            listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج")
        } else {
            listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "چ")
        }
        val r1Shift = if (wide) {
            listOf("ض", "ص", "ث", "ٌ", "ُ", "ِ", "ّ", "ة", "×", "آ", "چ")
        } else {
            listOf("ض", "ص", "ث", "ٌ", "ُ", "ِ", "ّ", "ة", "×", "آ", "«", "»")
        }
        val r1Hints = if (wide) {
            listOf(null, null, null, null, "ُ", "ِ", "ّ", "ة", null, "آ", "چ")
        } else {
            listOf(null, null, null, null, "ُ", "ِ", "ّ", "ة", null, "آ", "«", "»")
        }
        val r1Alts = if (wide) {
            listOf(
                emptyList(), emptyList(), emptyList(), listOf("ٌ"), listOf("ُ"),
                listOf("ِ"), listOf("ّ"), listOf("ة", "ۀ", "ه‍"), listOf("×"),
                listOf("آ", "أ", "إ"), listOf("چ", "«", "»"),
            )
        } else {
            listOf(
                emptyList(), emptyList(), emptyList(), listOf("ٌ"), listOf("ُ"),
                listOf("ِ"), listOf("ّ"), listOf("ة", "ۀ", "ه‍"), listOf("×"),
                listOf("آ", "أ", "إ"), listOf("«"), listOf("»"),
            )
        }

        val r2Normal = listOf("ش", "س", "ی", "ب", "ل", "ا", "ت", "ن", "م", "ک", "گ")
        val r2Shift = listOf("ٍ", "ٌ", "ئ", "ً", "لآ", "آ", "ـ", "،", "؛", "ك", "«")
        val r2Hints = listOf(null, null, "ئ", null, null, "آ", "ـ", null, null, "ك", null)
        val r2Alts = listOf(
            listOf("ٍ"), listOf("ٌ"), listOf("ئ", "ي", "ى"), listOf("ً"),
            listOf("لآ"), listOf("آ", "أ", "إ", "ء"), listOf("ـ", "ط"),
            listOf("،"), listOf("؛"), listOf("ك"), listOf("»"),
        )

        val r3Normal = if (wide) {
            listOf("ظ", "ط", "ز", "ر", "ذ", "د", "پ", "و", "چ")
        } else {
            listOf("ظ", "ط", "ز", "ر", "ذ", "د", "پ", "و")
        }
        val r3Shift = if (wide) {
            listOf("ك", "ْ", "ژ", "﷼", "؟", "ـ", "ء", "ؤ", "»")
        } else {
            listOf("ك", "ْ", "ژ", "﷼", "؟", "ـ", "ء", "ؤ")
        }
        val r3Hints = if (wide) {
            listOf(null, "ْ", "ژ", null, "؟", null, "ء", "ؤ", "»")
        } else {
            listOf(null, "ْ", "ژ", null, "؟", null, "ء", "ؤ")
        }
        val r3Alts = if (wide) {
            listOf(
                emptyList(), listOf("ْ"), listOf("ژ"), listOf("﷼"),
                listOf("؟"), listOf("ـ"), listOf("ء"), listOf("ؤ"), listOf("«", "»"),
            )
        } else {
            listOf(
                emptyList(), listOf("ْ"), listOf("ژ"), listOf("﷼"),
                listOf("؟"), listOf("ـ"), listOf("ء"), listOf("ؤ"),
            )
        }

        val r1 = List(r1Normal.size) { i ->
            val ch = if (shifted) r1Shift[i] else r1Normal[i]
            KeyItem(
                id = "fa_r1_$i",
                label = ch,
                hint = if (!shifted) r1Hints[i] else null,
                action = KeyAction.Text(ch),
                alternates = r1Alts[i],
                weight = 1f,
            )
        }

        val r2 = List(r2Normal.size) { i ->
            val ch = if (shifted) r2Shift[i] else r2Normal[i]
            KeyItem(
                id = "fa_r2_$i",
                label = ch,
                hint = if (!shifted) r2Hints[i] else null,
                action = KeyAction.Text(ch),
                alternates = r2Alts[i],
                weight = 1f,
            )
        }

        val r3 = buildList {
            add(
                KeyItem(
                    id = "fa_shift",
                    label = "SHIFT",
                    action = KeyAction.ShiftToggle,
                    weight = if (wide) 1.15f else 1.35f,
                    isSpecial = true,
                )
            )
            for (i in r3Normal.indices) {
                val ch = if (shifted) r3Shift[i] else r3Normal[i]
                add(
                    KeyItem(
                        id = "fa_r3_$i",
                        label = ch,
                        hint = if (!shifted) r3Hints[i] else null,
                        action = KeyAction.Text(ch),
                        alternates = r3Alts[i],
                        weight = 1f,
                    )
                )
            }
            add(
                KeyItem(
                    id = "fa_bsp",
                    label = "DEL",
                    action = KeyAction.Backspace,
                    weight = if (wide) 1.25f else 1.35f,
                    isSpecial = true,
                    isRepeatable = true,
                )
            )
        }

        val r4 = buildBottomRow(
            modeKeyLabel = "?۱۲۳",
            targetMode = KeyboardMode.SYMBOLS_1,
            language = KeyboardLanguage.PERSIAN,
            settings = settings,
        )

        return listOf(r1, r2, r3, r4)
    }

    private fun buildSymbols1Rows(
        language: KeyboardLanguage,
        settings: KeyboardSettings,
    ): List<List<KeyItem>> {
        val r1 = listOf("!", "@", "#", "$", "%", "^", "&", "*", "(", ")").mapIndexed { i, s ->
            KeyItem(id = "sym1_r1_$i", label = s, action = KeyAction.Text(s), weight = 1f)
        }
        val r2 = listOf("-", "_", "=", "+", "[", "]", "{", "}", "\\", "|").mapIndexed { i, s ->
            KeyItem(id = "sym1_r2_$i", label = s, action = KeyAction.Text(s), weight = 1f)
        }
        val r3 = buildList {
            add(
                KeyItem(
                    id = "sym1_more",
                    label = "=\\<",
                    action = KeyAction.SwitchMode(KeyboardMode.SYMBOLS_2),
                    weight = 1.45f,
                    isSpecial = true,
                )
            )
            val mid = if (language == KeyboardLanguage.PERSIAN) {
                listOf("؛", ":", "'", "\"", "«", "»", "؟")
            } else {
                listOf(";", ":", "'", "\"", "<", ">", "/")
            }
            mid.forEachIndexed { i, s ->
                KeyItem(
                    id = "sym1_r3_$i",
                    label = s,
                    action = KeyAction.Text(s),
                    weight = 1f,
                ).also { add(it) }
            }
            add(
                KeyItem(
                    id = "sym1_bsp",
                    label = "DEL",
                    action = KeyAction.Backspace,
                    weight = 1.45f,
                    isSpecial = true,
                    isRepeatable = true,
                )
            )
        }
        val r4 = buildBottomRow(
            modeKeyLabel = if (language == KeyboardLanguage.PERSIAN) "اب‌پ" else "ABC",
            targetMode = KeyboardMode.LETTERS,
            language = language,
            settings = settings,
        )
        return listOf(r1, r2, r3, r4)
    }

    private fun buildSymbols2Rows(
        language: KeyboardLanguage,
        settings: KeyboardSettings,
    ): List<List<KeyItem>> {
        val r1 = listOf("~", "`", "°", "•", "·", "×", "÷", "√", "π", "≠").mapIndexed { i, s ->
            KeyItem(id = "sym2_r1_$i", label = s, action = KeyAction.Text(s), weight = 1f)
        }
        val r2 = listOf("€", "£", "¥", "₹", "﷼", "©", "®", "™", "§", "¶").mapIndexed { i, s ->
            KeyItem(id = "sym2_r2_$i", label = s, action = KeyAction.Text(s), weight = 1f)
        }
        val r3 = buildList {
            add(
                KeyItem(
                    id = "sym2_back",
                    label = "?123",
                    action = KeyAction.SwitchMode(KeyboardMode.SYMBOLS_1),
                    weight = 1.45f,
                    isSpecial = true,
                )
            )
            listOf("«", "»", "‹", "›", "—", "–", "…").forEachIndexed { i, s ->
                add(KeyItem(id = "sym2_r3_$i", label = s, action = KeyAction.Text(s), weight = 1f))
            }
            add(
                KeyItem(
                    id = "sym2_bsp",
                    label = "DEL",
                    action = KeyAction.Backspace,
                    weight = 1.45f,
                    isSpecial = true,
                    isRepeatable = true,
                )
            )
        }
        val r4 = buildBottomRow(
            modeKeyLabel = if (language == KeyboardLanguage.PERSIAN) "اب‌پ" else "ABC",
            targetMode = KeyboardMode.LETTERS,
            language = language,
            settings = settings,
        )
        return listOf(r1, r2, r3, r4)
    }

    private fun buildNumpadRows(
        language: KeyboardLanguage,
        settings: KeyboardSettings,
    ): List<List<KeyItem>> {
        val usePersian = language == KeyboardLanguage.PERSIAN && settings.persianDigitsInPersianMode
        fun d(n: Int): String = if (usePersian) persianDigits[(n + 9) % 10] else n.toString()

        val r1 = listOf(
            KeyItem("np_7", d(7), action = KeyAction.Text(d(7), KeyEvent.KEYCODE_7), weight = 1.15f),
            KeyItem("np_8", d(8), action = KeyAction.Text(d(8), KeyEvent.KEYCODE_8), weight = 1.15f),
            KeyItem("np_9", d(9), action = KeyAction.Text(d(9), KeyEvent.KEYCODE_9), weight = 1.15f),
            KeyItem("np_div", "/", action = KeyAction.Text("/"), weight = 0.9f, isSpecial = true),
            KeyItem("np_bsp", "DEL", action = KeyAction.Backspace, weight = 1.1f, isSpecial = true, isRepeatable = true),
        )
        val r2 = listOf(
            KeyItem("np_4", d(4), action = KeyAction.Text(d(4), KeyEvent.KEYCODE_4), weight = 1.15f),
            KeyItem("np_5", d(5), action = KeyAction.Text(d(5), KeyEvent.KEYCODE_5), weight = 1.15f),
            KeyItem("np_6", d(6), action = KeyAction.Text(d(6), KeyEvent.KEYCODE_6), weight = 1.15f),
            KeyItem("np_mul", "*", action = KeyAction.Text("*"), weight = 0.9f, isSpecial = true),
            KeyItem("np_fdel", "Del", action = KeyAction.ForwardDelete, weight = 1.1f, isSpecial = true, isRepeatable = true),
        )
        val r3 = listOf(
            KeyItem("np_1", d(1), action = KeyAction.Text(d(1), KeyEvent.KEYCODE_1), weight = 1.15f),
            KeyItem("np_2", d(2), action = KeyAction.Text(d(2), KeyEvent.KEYCODE_2), weight = 1.15f),
            KeyItem("np_3", d(3), action = KeyAction.Text(d(3), KeyEvent.KEYCODE_3), weight = 1.15f),
            KeyItem("np_sub", "-", action = KeyAction.Text("-"), weight = 0.9f, isSpecial = true),
            KeyItem("np_tab", "Tab", action = KeyAction.Tab, weight = 1.1f, isSpecial = true),
        )
        val r4 = listOf(
            KeyItem(
                id = "np_abc",
                label = if (language == KeyboardLanguage.PERSIAN) "اب‌پ" else "ABC",
                action = KeyAction.SwitchMode(KeyboardMode.LETTERS),
                weight = 1.15f,
                isSpecial = true,
            ),
            KeyItem("np_0", d(0), action = KeyAction.Text(d(0), KeyEvent.KEYCODE_0), weight = 1.15f),
            KeyItem("np_dot", ".", alternates = listOf(",", "٫", "٬"), action = KeyAction.Text("."), weight = 0.95f),
            KeyItem("np_plus", "+", action = KeyAction.Text("+"), weight = 0.9f, isSpecial = true),
            KeyItem("np_eq", "=", action = KeyAction.Text("="), weight = 0.85f, isSpecial = true),
            KeyItem("np_enter", "ENTER", action = KeyAction.Enter, weight = 1.15f, isAccent = true),
        )
        return listOf(r1, r2, r3, r4)
    }

    private fun buildBottomRow(
        modeKeyLabel: String,
        targetMode: KeyboardMode,
        language: KeyboardLanguage,
        settings: KeyboardSettings,
    ): List<KeyItem> {
        val showGlobe = settings.enablePersian && settings.enableEnglish
        val showZwnj = language == KeyboardLanguage.PERSIAN && settings.showZwnjKey
        val dotLabel = if (language == KeyboardLanguage.PERSIAN) "." else "."
        val dotAlternates = if (language == KeyboardLanguage.PERSIAN) {
            listOf("،", "؛", "؟", "!", ":", "…", "/")
        } else {
            listOf(",", "?", "!", ":", ";", "-", "'", "\"", "/")
        }
        val commaLabel = if (language == KeyboardLanguage.PERSIAN) "،" else ","

        return buildList {
            add(
                KeyItem(
                    id = "bot_mode",
                    label = modeKeyLabel,
                    action = KeyAction.SwitchMode(targetMode),
                    weight = 1.4f,
                    isSpecial = true,
                )
            )
            if (showGlobe) {
                add(
                    KeyItem(
                        id = "bot_lang",
                        label = "GLOBE",
                        action = KeyAction.SwitchLanguage,
                        weight = 1.05f,
                        isSpecial = true,
                    )
                )
            }
            if (showZwnj) {
                add(
                    KeyItem(
                        id = "bot_zwnj",
                        label = "نیم‌ف",
                        hint = "ZWNJ",
                        action = KeyAction.Zwnj,
                        weight = 1.05f,
                        isSpecial = true,
                    )
                )
            } else {
                add(
                    KeyItem(
                        id = "bot_comma",
                        label = commaLabel,
                        action = KeyAction.Text(commaLabel),
                        alternates = if (language == KeyboardLanguage.PERSIAN) listOf(",", "؛") else listOf(";", ":"),
                        weight = 0.95f,
                    )
                )
            }
            add(
                KeyItem(
                    id = "bot_space",
                    label = if (language == KeyboardLanguage.PERSIAN) "فاصله • فارسی" else "Space • EN",
                    action = KeyAction.Space,
                    weight = if (showGlobe && showZwnj) 3.7f else 4.2f,
                )
            )
            add(
                KeyItem(
                    id = "bot_dot",
                    label = dotLabel,
                    hint = if (language == KeyboardLanguage.PERSIAN) "،" else ",",
                    action = KeyAction.Text(dotLabel),
                    alternates = dotAlternates,
                    weight = 1.0f,
                )
            )
            add(
                KeyItem(
                    id = "bot_enter",
                    label = "ENTER",
                    action = KeyAction.Enter,
                    weight = 1.55f,
                    isAccent = true,
                )
            )
        }
    }
}
