package com.example.ime.engine

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.SystemClock
import android.text.Editable
import android.text.Selection
import android.view.KeyEvent
import android.widget.EditText
import androidx.compose.runtime.Immutable
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import com.example.data.SettingsRepository
import com.example.data.TabBehavior
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference

@Immutable
data class SandboxStats(
    val cursorPos: Int = 0,
    val selectionLength: Int = 0,
    val lineCount: Int = 1,
    val charCount: Int = 0,
)

class SandboxEditorTarget(
    private val context: Context,
    private val settingsRepository: SettingsRepository,
) : EditorTarget {

    private val _value = MutableStateFlow(
        TextFieldValue(
            text = "سلام! اینجا می‌تونی کیبورد PCKey رو تست کنی.\nTry Ctrl+A, Ctrl+C, Ctrl+V, Ctrl+Z, Ctrl+Backspace, Home/End & Arrows!",
            selection = TextRange(0),
        )
    )
    val value: StateFlow<TextFieldValue> = _value.asStateFlow()

    private val _stats = MutableStateFlow(computeStats(_value.value.text, 0, 0))
    val stats: StateFlow<SandboxStats> = _stats.asStateFlow()

    private val _lastEvent = MutableStateFlow<String?>(null)
    val lastEvent: StateFlow<String?> = _lastEvent.asStateFlow()

    private var attachedEditText: WeakReference<EditText>? = null
    private var inMemoryClipboard: String? = null

    private val undoStack = ArrayDeque<TextFieldValue>()
    private val redoStack = ArrayDeque<TextFieldValue>()

    private val clipboardManager: ClipboardManager?
        get() = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager

    fun attachEditText(editText: EditText) {
        if (attachedEditText?.get() === editText) return
        attachedEditText = WeakReference(editText)
        editText.setText(_value.value.text)
        val selEnd = _value.value.selection.end.coerceIn(0, editText.text.length)
        editText.setSelection(selEnd)
        refreshStatsFromEditText(editText)
    }

    fun detachEditText(editText: EditText) {
        if (attachedEditText?.get() === editText) {
            val currentText = editText.text?.toString().orEmpty()
            val start = editText.selectionStart.coerceIn(0, currentText.length)
            val end = editText.selectionEnd.coerceIn(0, currentText.length)
            _value.value = TextFieldValue(currentText, TextRange(start, end))
            attachedEditText = null
        }
    }

    fun onEditTextChanged(editable: Editable, selStart: Int, selEnd: Int) {
        refreshStats(editable, selStart, selEnd)
    }

    fun refreshStatsFromEditText(editText: EditText) {
        val editable = editText.text ?: return
        refreshStats(editable, editText.selectionStart.coerceAtLeast(0), editText.selectionEnd.coerceAtLeast(0))
    }

    private fun refreshStats(text: CharSequence, selStart: Int, selEnd: Int) {
        val min = minOf(selStart, selEnd).coerceAtLeast(0)
        val max = maxOf(selStart, selEnd).coerceAtLeast(min)
        val lines = attachedEditText?.get()?.lineCount ?: countLines(text)
        _stats.value = SandboxStats(
            cursorPos = selEnd.coerceAtLeast(0),
            selectionLength = max - min,
            lineCount = lines,
            charCount = text.length,
        )
    }

    fun updateFromField(newValue: TextFieldValue) {
        if (newValue.text.length != _value.value.text.length ||
            (newValue.text.length < 10_000 && newValue.text != _value.value.text)
        ) {
            pushUndo(_value.value)
        }
        _value.value = newValue
        _stats.value = computeStats(
            newValue.text,
            newValue.selection.end,
            newValue.selection.length,
        )
    }

    fun clearText() {
        val et = attachedEditText?.get()
        if (et != null) {
            pushUndoSnapshot(et.text.toString(), et.selectionStart, et.selectionEnd)
            et.text?.clear()
            refreshStatsFromEditText(et)
            _lastEvent.value = "Cleared"
            return
        }
        pushUndo(_value.value)
        updateFromField(TextFieldValue("", TextRange(0)))
    }

    fun insertTenThousandLinesSample() {
        val startMs = SystemClock.elapsedRealtime()
        val sb = StringBuilder(260_000)
        for (i in 1..10_000) {
            sb.append("Line ").append(i).append(" — PCKey 10K fast copy & paste stress test\n")
        }
        val sample = sb.toString()
        val et = attachedEditText?.get()
        if (et != null) {
            et.setText(sample)
            et.setSelection(0)
            refreshStatsFromEditText(et)
        } else {
            updateFromField(TextFieldValue(sample, TextRange(0)))
        }
        val elapsed = (SystemClock.elapsedRealtime() - startMs).coerceAtLeast(1)
        _lastEvent.value = "10,000 خط آماده شد (${elapsed}ms)"
    }

    private fun pushUndoSnapshot(text: String, start: Int, end: Int) {
        if (text.length > 50_000) {
            if (undoStack.size >= 4) undoStack.removeFirst()
        } else if (undoStack.size >= 40) {
            undoStack.removeFirst()
        }
        undoStack.addLast(TextFieldValue(text, TextRange(start.coerceAtLeast(0), end.coerceAtLeast(0))))
        redoStack.clear()
    }

    private fun pushUndo(snapshot: TextFieldValue) {
        if (snapshot.text.length < 10_000 && undoStack.lastOrNull()?.text == snapshot.text) return
        val maxUndo = if (snapshot.text.length > 50_000) 4 else 40
        while (undoStack.size >= maxUndo) undoStack.removeFirst()
        undoStack.addLast(snapshot)
        redoStack.clear()
    }

    private fun applyEdit(newValue: TextFieldValue, recordUndo: Boolean = true) {
        if (recordUndo) {
            pushUndo(_value.value)
        }
        _value.value = newValue
        _stats.value = computeStats(newValue.text, newValue.selection.end, newValue.selection.length)
    }

    override fun commitText(text: String) {
        val et = attachedEditText?.get()
        if (et != null) {
            val editable = et.text ?: return
            val min = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
            val max = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(min)
            if (text.length < 8_000 && editable.length < 20_000) {
                pushUndoSnapshot(editable.toString(), min, max)
            }
            editable.replace(min, max, text)
            val cursor = (min + text.length).coerceAtMost(editable.length)
            Selection.setSelection(editable, cursor)
            refreshStatsFromEditText(et)
            return
        }

        val current = _value.value
        val min = current.selection.min
        val max = current.selection.max
        val nextText = current.text.replaceRange(min, max, text)
        val cursor = min + text.length
        applyEdit(TextFieldValue(nextText, TextRange(cursor)))
    }

    override fun deleteBackward(count: Int) {
        val et = attachedEditText?.get()
        if (et != null) {
            val editable = et.text ?: return
            val min = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
            val max = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(min)
            if (min != max) {
                editable.delete(min, max)
                Selection.setSelection(editable, min)
            } else if (min > 0) {
                val start = (min - count).coerceAtLeast(0)
                editable.delete(start, min)
                Selection.setSelection(editable, start)
            }
            refreshStatsFromEditText(et)
            return
        }

        val current = _value.value
        val min = current.selection.min
        val max = current.selection.max
        if (min != max) {
            applyEdit(TextFieldValue(current.text.removeRange(min, max), TextRange(min)))
        } else if (min > 0) {
            val start = (min - count).coerceAtLeast(0)
            applyEdit(TextFieldValue(current.text.removeRange(start, min), TextRange(start)))
        }
    }

    override fun deleteForward(count: Int) {
        val et = attachedEditText?.get()
        if (et != null) {
            val editable = et.text ?: return
            val min = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
            val max = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(min)
            if (min != max) {
                editable.delete(min, max)
                Selection.setSelection(editable, min)
            } else if (max < editable.length) {
                val end = (max + count).coerceAtMost(editable.length)
                editable.delete(max, end)
                Selection.setSelection(editable, max)
            }
            refreshStatsFromEditText(et)
            return
        }

        val current = _value.value
        val min = current.selection.min
        val max = current.selection.max
        if (min != max) {
            applyEdit(TextFieldValue(current.text.removeRange(min, max), TextRange(min)))
        } else if (max < current.text.length) {
            val end = (max + count).coerceAtMost(current.text.length)
            applyEdit(TextFieldValue(current.text.removeRange(max, end), TextRange(max)))
        }
    }

    override fun deleteWordBackward() {
        val et = attachedEditText?.get()
        if (et != null) {
            val editable = et.text ?: return
            val min = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
            val max = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(min)
            if (min != max) {
                editable.delete(min, max)
                Selection.setSelection(editable, min)
            } else if (min > 0) {
                val lookbackStart = (min - 64).coerceAtLeast(0)
                val before = editable.subSequence(lookbackStart, min).toString()
                val count = InputConnectionEditorTarget.computeWordBackwardCount(before)
                val start = (min - count).coerceAtLeast(0)
                editable.delete(start, min)
                Selection.setSelection(editable, start)
            }
            refreshStatsFromEditText(et)
            return
        }

        val current = _value.value
        val min = current.selection.min
        val max = current.selection.max
        if (min != max) {
            applyEdit(TextFieldValue(current.text.removeRange(min, max), TextRange(min)))
            return
        }
        if (min <= 0) return
        val before = current.text.substring((min - 64).coerceAtLeast(0), min)
        val count = InputConnectionEditorTarget.computeWordBackwardCount(before)
        val start = (min - count).coerceAtLeast(0)
        applyEdit(TextFieldValue(current.text.removeRange(start, min), TextRange(start)))
    }

    override fun deleteWordForward() {
        val et = attachedEditText?.get()
        if (et != null) {
            val editable = et.text ?: return
            val min = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
            val max = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(min)
            if (min != max) {
                editable.delete(min, max)
                Selection.setSelection(editable, min)
            } else if (max < editable.length) {
                val lookaheadEnd = (max + 64).coerceAtMost(editable.length)
                val after = editable.subSequence(max, lookaheadEnd).toString()
                val count = InputConnectionEditorTarget.computeWordForwardCount(after)
                val end = (max + count).coerceAtMost(editable.length)
                editable.delete(max, end)
                Selection.setSelection(editable, max)
            }
            refreshStatsFromEditText(et)
            return
        }

        val current = _value.value
        val min = current.selection.min
        val max = current.selection.max
        if (min != max) {
            applyEdit(TextFieldValue(current.text.removeRange(min, max), TextRange(min)))
            return
        }
        if (max >= current.text.length) return
        val after = current.text.substring(max, (max + 64).coerceAtMost(current.text.length))
        val count = InputConnectionEditorTarget.computeWordForwardCount(after)
        val end = (max + count).coerceAtMost(current.text.length)
        applyEdit(TextFieldValue(current.text.removeRange(max, end), TextRange(max)))
    }

    override fun getTextBeforeCursor(maxChars: Int): String {
        val et = attachedEditText?.get()
        if (et != null) {
            val editable = et.text ?: return ""
            val end = minOf(et.selectionStart, et.selectionEnd).coerceIn(0, editable.length)
            val start = (end - maxChars).coerceAtLeast(0)
            return editable.subSequence(start, end).toString()
        }
        val current = _value.value
        val end = current.selection.min.coerceIn(0, current.text.length)
        val start = (end - maxChars).coerceAtLeast(0)
        return current.text.substring(start, end)
    }

    override fun getTextAfterCursor(maxChars: Int): String {
        val et = attachedEditText?.get()
        if (et != null) {
            val editable = et.text ?: return ""
            val start = maxOf(et.selectionStart, et.selectionEnd).coerceIn(0, editable.length)
            val end = (start + maxChars).coerceAtMost(editable.length)
            return editable.subSequence(start, end).toString()
        }
        val current = _value.value
        val start = current.selection.max.coerceIn(0, current.text.length)
        val end = (start + maxChars).coerceAtMost(current.text.length)
        return current.text.substring(start, end)
    }

    override fun moveCursorLeft(select: Boolean, byWord: Boolean) {
        val et = attachedEditText?.get()
        if (et != null) {
            val editable = et.text ?: return
            val active = et.selectionEnd.coerceIn(0, editable.length)
            val next = if (byWord) {
                val start = (active - 64).coerceAtLeast(0)
                val before = editable.subSequence(start, active).toString()
                (active - InputConnectionEditorTarget.computeWordBackwardCount(before)).coerceAtLeast(0)
            } else {
                (active - 1).coerceAtLeast(0)
            }
            setEditTextCursor(et, next, select)
            return
        }
        val current = _value.value
        val active = current.selection.end
        val next = if (byWord) {
            val before = current.text.substring((active - 64).coerceAtLeast(0), active)
            (active - InputConnectionEditorTarget.computeWordBackwardCount(before)).coerceAtLeast(0)
        } else {
            (active - 1).coerceAtLeast(0)
        }
        updateCursor(next, select)
    }

    override fun moveCursorRight(select: Boolean, byWord: Boolean) {
        val et = attachedEditText?.get()
        if (et != null) {
            val editable = et.text ?: return
            val active = et.selectionEnd.coerceIn(0, editable.length)
            val next = if (byWord) {
                val end = (active + 64).coerceAtMost(editable.length)
                val after = editable.subSequence(active, end).toString()
                (active + InputConnectionEditorTarget.computeWordForwardCount(after)).coerceAtMost(editable.length)
            } else {
                (active + 1).coerceAtMost(editable.length)
            }
            setEditTextCursor(et, next, select)
            return
        }
        val current = _value.value
        val active = current.selection.end
        val next = if (byWord) {
            val after = current.text.substring(active, (active + 64).coerceAtMost(current.text.length))
            (active + InputConnectionEditorTarget.computeWordForwardCount(after)).coerceAtMost(current.text.length)
        } else {
            (active + 1).coerceAtMost(current.text.length)
        }
        updateCursor(next, select)
    }

    override fun moveCursorUp(select: Boolean) {
        val et = attachedEditText?.get()
        if (et != null) {
            val keyCode = KeyEvent.KEYCODE_DPAD_UP
            val meta = if (select) KeyEvent.META_SHIFT_ON else 0
            val now = SystemClock.uptimeMillis()
            et.dispatchKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0, meta))
            et.dispatchKeyEvent(KeyEvent(now, now + 5, KeyEvent.ACTION_UP, keyCode, 0, meta))
            refreshStatsFromEditText(et)
            return
        }
        val current = _value.value
        val pos = current.selection.end
        val text = current.text
        val lineStart = text.lastIndexOf('\n', (pos - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 }
        if (lineStart == 0) {
            updateCursor(0, select)
            return
        }
        val col = pos - lineStart
        val prevLineEnd = lineStart - 1
        val prevLineStart = text.lastIndexOf('\n', (prevLineEnd - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 }
        val prevLineLen = prevLineEnd - prevLineStart
        updateCursor(prevLineStart + col.coerceAtMost(prevLineLen), select)
    }

    override fun moveCursorDown(select: Boolean) {
        val et = attachedEditText?.get()
        if (et != null) {
            val keyCode = KeyEvent.KEYCODE_DPAD_DOWN
            val meta = if (select) KeyEvent.META_SHIFT_ON else 0
            val now = SystemClock.uptimeMillis()
            et.dispatchKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0, meta))
            et.dispatchKeyEvent(KeyEvent(now, now + 5, KeyEvent.ACTION_UP, keyCode, 0, meta))
            refreshStatsFromEditText(et)
            return
        }
        val current = _value.value
        val pos = current.selection.end
        val text = current.text
        val lineStart = text.lastIndexOf('\n', (pos - 1).coerceAtLeast(0)).let { if (it < 0 || pos == 0) 0 else it + 1 }
        val col = pos - lineStart
        val nextNewline = text.indexOf('\n', pos)
        if (nextNewline < 0) {
            updateCursor(text.length, select)
            return
        }
        val nextLineStart = nextNewline + 1
        val nextLineEnd = text.indexOf('\n', nextLineStart).let { if (it < 0) text.length else it }
        val nextLineLen = nextLineEnd - nextLineStart
        updateCursor(nextLineStart + col.coerceAtMost(nextLineLen), select)
    }

    override fun moveHome(select: Boolean, document: Boolean) {
        val et = attachedEditText?.get()
        if (et != null) {
            val editable = et.text ?: return
            val targetPos = if (document) {
                0
            } else {
                val pos = et.selectionEnd.coerceIn(0, editable.length)
                if (pos == 0) 0 else lastIndexOfNewline(editable, pos - 1) + 1
            }
            setEditTextCursor(et, targetPos, select)
            return
        }
        val current = _value.value
        if (document) {
            updateCursor(0, select)
            return
        }
        val pos = current.selection.end
        val lineStart = if (pos == 0) 0 else {
            current.text.lastIndexOf('\n', pos - 1).let { if (it < 0) 0 else it + 1 }
        }
        updateCursor(lineStart, select)
    }

    override fun moveEnd(select: Boolean, document: Boolean) {
        val et = attachedEditText?.get()
        if (et != null) {
            val editable = et.text ?: return
            val targetPos = if (document) {
                editable.length
            } else {
                val pos = et.selectionEnd.coerceIn(0, editable.length)
                indexOfNewlineOrEnd(editable, pos)
            }
            setEditTextCursor(et, targetPos, select)
            return
        }
        val current = _value.value
        if (document) {
            updateCursor(current.text.length, select)
            return
        }
        val pos = current.selection.end
        val lineEnd = current.text.indexOf('\n', pos).let { if (it < 0) current.text.length else it }
        updateCursor(lineEnd, select)
    }

    override fun movePageUp(select: Boolean) = moveHome(select, document = true)

    override fun movePageDown(select: Boolean) = moveEnd(select, document = true)

    override fun performCopy(): Boolean {
        val startMs = SystemClock.elapsedRealtime()
        val et = attachedEditText?.get()
        val selected: String = if (et != null) {
            val min = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
            val max = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(min)
            if (min == max) return false
            et.text?.subSequence(min, max)?.toString().orEmpty()
        } else {
            val current = _value.value
            if (current.selection.collapsed) return false
            current.text.substring(current.selection.min, current.selection.max)
        }
        if (selected.isEmpty()) return false

        inMemoryClipboard = selected
        runCatching {
            clipboardManager?.setPrimaryClip(ClipData.newPlainText("PCKey", selected))
        }
        settingsRepository.addClipboardText(selected)
        val elapsed = (SystemClock.elapsedRealtime() - startMs).coerceAtLeast(1)
        _lastEvent.value = "کپی شد (${selected.length} کاراکتر • ${elapsed}ms)"
        return true
    }

    override fun performCut(): Boolean {
        val startMs = SystemClock.elapsedRealtime()
        val et = attachedEditText?.get()
        if (et != null) {
            val editable = et.text ?: return false
            val min = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
            val max = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(min)
            if (min == max) return false
            val selected = editable.subSequence(min, max).toString()
            inMemoryClipboard = selected
            runCatching {
                clipboardManager?.setPrimaryClip(ClipData.newPlainText("PCKey", selected))
            }
            settingsRepository.addClipboardText(selected)
            editable.delete(min, max)
            Selection.setSelection(editable, min)
            refreshStatsFromEditText(et)
            val elapsed = (SystemClock.elapsedRealtime() - startMs).coerceAtLeast(1)
            _lastEvent.value = "بریده شد (${selected.length} • ${elapsed}ms)"
            return true
        }

        val current = _value.value
        if (current.selection.collapsed) return false
        val min = current.selection.min
        val max = current.selection.max
        val selected = current.text.substring(min, max)
        inMemoryClipboard = selected
        runCatching {
            clipboardManager?.setPrimaryClip(ClipData.newPlainText("PCKey", selected))
        }
        settingsRepository.addClipboardText(selected)
        applyEdit(TextFieldValue(current.text.removeRange(min, max), TextRange(min)))
        val elapsed = (SystemClock.elapsedRealtime() - startMs).coerceAtLeast(1)
        _lastEvent.value = "بریده شد (${selected.length} • ${elapsed}ms)"
        return true
    }

    override fun performPaste(): Boolean {
        val startMs = SystemClock.elapsedRealtime()
        val clip = inMemoryClipboard
            ?: runCatching { clipboardManager?.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString() }.getOrNull()
            ?: settingsRepository.clipboardEntries.value.firstOrNull()?.let { settingsRepository.resolveClipText(it) }
            ?: return false
        if (clip.isEmpty()) return false

        val et = attachedEditText?.get()
        if (et != null) {
            val editable = et.text ?: return false
            val min = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
            val max = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(min)
            editable.replace(min, max, clip)
            val cursor = (min + clip.length).coerceAtMost(editable.length)
            Selection.setSelection(editable, cursor)
            refreshStatsFromEditText(et)
        } else {
            commitText(clip)
        }
        val elapsed = (SystemClock.elapsedRealtime() - startMs).coerceAtLeast(1)
        _lastEvent.value = "پیست شد (${clip.length} کاراکتر • ${elapsed}ms)"
        return true
    }

    fun pasteDirectOptimized(text: String) {
        if (text.isEmpty()) return
        inMemoryClipboard = text
        val startMs = SystemClock.elapsedRealtime()
        val et = attachedEditText?.get()
        if (et != null) {
            val editable = et.text ?: return
            val min = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
            val max = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(min)
            editable.replace(min, max, text)
            val cursor = (min + text.length).coerceAtMost(editable.length)
            Selection.setSelection(editable, cursor)
            refreshStatsFromEditText(et)
        } else {
            commitText(text)
        }
        val elapsed = (SystemClock.elapsedRealtime() - startMs).coerceAtLeast(1)
        _lastEvent.value = "پیست شد (${text.length} • ${elapsed}ms)"
    }

    override fun performSelectAll(): Boolean {
        val et = attachedEditText?.get()
        if (et != null) {
            val len = et.text?.length ?: 0
            et.selectAll()
            refreshStatsFromEditText(et)
            _lastEvent.value = "انتخاب همه ($len کاراکتر)"
            return true
        }
        val len = _value.value.text.length
        val next = _value.value.copy(selection = TextRange(0, len))
        _value.value = next
        _stats.value = computeStats(next.text, next.selection.end, next.selection.length)
        _lastEvent.value = "انتخاب همه ($len)"
        return true
    }

    override fun performUndo(): Boolean {
        val prev = undoStack.removeLastOrNull() ?: return false
        val et = attachedEditText?.get()
        if (et != null) {
            redoStack.addLast(
                TextFieldValue(
                    et.text.toString(),
                    TextRange(et.selectionStart.coerceAtLeast(0), et.selectionEnd.coerceAtLeast(0)),
                )
            )
            et.setText(prev.text)
            et.setSelection(
                prev.selection.start.coerceIn(0, prev.text.length),
                prev.selection.end.coerceIn(0, prev.text.length),
            )
            refreshStatsFromEditText(et)
        } else {
            redoStack.addLast(_value.value)
            _value.value = prev
            _stats.value = computeStats(prev.text, prev.selection.end, prev.selection.length)
        }
        _lastEvent.value = "Undo"
        return true
    }

    override fun performRedo(): Boolean {
        val next = redoStack.removeLastOrNull() ?: return false
        val et = attachedEditText?.get()
        if (et != null) {
            undoStack.addLast(
                TextFieldValue(
                    et.text.toString(),
                    TextRange(et.selectionStart.coerceAtLeast(0), et.selectionEnd.coerceAtLeast(0)),
                )
            )
            et.setText(next.text)
            et.setSelection(
                next.selection.start.coerceIn(0, next.text.length),
                next.selection.end.coerceIn(0, next.text.length),
            )
            refreshStatsFromEditText(et)
        } else {
            undoStack.addLast(_value.value)
            _value.value = next
            _stats.value = computeStats(next.text, next.selection.end, next.selection.length)
        }
        _lastEvent.value = "Redo"
        return true
    }

    override fun sendKeyEvent(keyCode: Int, metaState: Int) {
        val name = KeyEvent.keyCodeToString(keyCode).removePrefix("KEYCODE_")
        val mods = buildString {
            if ((metaState and KeyEvent.META_CTRL_ON) != 0) append("Ctrl+")
            if ((metaState and KeyEvent.META_ALT_ON) != 0) append("Alt+")
            if ((metaState and KeyEvent.META_SHIFT_ON) != 0) append("Shift+")
        }
        _lastEvent.value = "KeyEvent: $mods$name"
        if (keyCode == KeyEvent.KEYCODE_ENTER) {
            commitText("\n")
        }
    }

    override fun performEnter() {
        commitText("\n")
    }

    override fun performTab(behavior: TabBehavior) {
        when (behavior) {
            TabBehavior.INSERT_TAB_CHAR -> commitText("\t")
            TabBehavior.SPACES_4 -> commitText("    ")
            TabBehavior.SPACES_2 -> commitText("  ")
            TabBehavior.NAVIGATE_NEXT_FIELD -> {
                _lastEvent.value = "Tab -> Next Field"
                commitText("\t")
            }
        }
    }

    private fun setEditTextCursor(et: EditText, newEnd: Int, select: Boolean) {
        val len = et.text?.length ?: 0
        val clampedEnd = newEnd.coerceIn(0, len)
        if (select) {
            val anchor = et.selectionStart.coerceIn(0, len)
            et.setSelection(anchor, clampedEnd)
        } else {
            et.setSelection(clampedEnd)
        }
        refreshStatsFromEditText(et)
    }

    private fun updateCursor(newEnd: Int, select: Boolean) {
        val current = _value.value
        val nextRange = if (select) {
            TextRange(current.selection.start, newEnd)
        } else {
            TextRange(newEnd)
        }
        val next = current.copy(selection = nextRange)
        _value.value = next
        _stats.value = computeStats(next.text, next.selection.end, next.selection.length)
    }

    companion object {
        private fun countLines(cs: CharSequence): Int {
            var count = 1
            for (i in 0 until cs.length) {
                if (cs[i] == '\n') count++
            }
            return count
        }

        private fun lastIndexOfNewline(cs: CharSequence, fromIndex: Int): Int {
            for (i in fromIndex downTo 0) {
                if (cs[i] == '\n') return i
            }
            return -1
        }

        private fun indexOfNewlineOrEnd(cs: CharSequence, fromIndex: Int): Int {
            for (i in fromIndex until cs.length) {
                if (cs[i] == '\n') return i
            }
            return cs.length
        }

        private fun computeStats(text: String, cursor: Int, selLen: Int): SandboxStats {
            return SandboxStats(
                cursorPos = cursor,
                selectionLength = selLen,
                lineCount = countLines(text),
                charCount = text.length,
            )
        }
    }
}
