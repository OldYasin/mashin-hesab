package com.example.ime.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import com.example.data.KeyboardThemePreset

@Immutable
data class KeyboardPalette(
    val background: Color,
    val toolbarBackground: Color,
    val keyBg: Color,
    val keyPressedBg: Color,
    val keyShadow: Color,
    val specialKeyBg: Color,
    val specialKeyPressedBg: Color,
    val accentKeyBg: Color,
    val accentKeyContent: Color,
    val activeModifierBg: Color,
    val activeModifierContent: Color,
    val altModifierBg: Color,
    val keyText: Color,
    val keyHintText: Color,
    val border: Color,
    val popupBg: Color,
    val popupHighlightBg: Color,
    val isDark: Boolean,
)

@Composable
fun resolveKeyboardPalette(preset: KeyboardThemePreset): KeyboardPalette {
    val systemDark = isSystemInDarkTheme()
    val context = LocalContext.current

    return when (preset) {
        KeyboardThemePreset.OBSIDIAN -> buildPalette(
            dark = true, bg = 0xFF0B0D12, toolbar = 0xFF12151C, key = 0xFF222733, special = 0xFF171B24,
            accent = 0xFF8AB4FF, onAccent = 0xFF0A1330, text = 0xFFEDEFF5, hint = 0xFF8089A0, alt = 0xFFFFB454,
        )
        KeyboardThemePreset.AMOLED -> buildPalette(
            dark = true, bg = 0xFF000000, toolbar = 0xFF0A0A0A, key = 0xFF1A1A1C, special = 0xFF0F0F11,
            accent = 0xFF30D5C8, onAccent = 0xFF00201D, text = 0xFFF5F5F5, hint = 0xFF7A7A80, alt = 0xFFFF9F43,
        )
        KeyboardThemePreset.MIDNIGHT_BLUE -> buildPalette(
            dark = true, bg = 0xFF0A1022, toolbar = 0xFF101A33, key = 0xFF1C2B52, special = 0xFF131F3D,
            accent = 0xFF6EA8FF, onAccent = 0xFF04142E, text = 0xFFEAF1FF, hint = 0xFF8497C4, alt = 0xFFC4A1FF,
        )
        KeyboardThemePreset.FOREST_TERMINAL -> buildPalette(
            dark = true, bg = 0xFF0A130F, toolbar = 0xFF101C16, key = 0xFF1B3027, special = 0xFF12221B,
            accent = 0xFF4ADE80, onAccent = 0xFF04210F, text = 0xFFDCFCE7, hint = 0xFF7FB89A, alt = 0xFFFACC15,
        )
        KeyboardThemePreset.NORD -> buildPalette(
            dark = true, bg = 0xFF2E3440, toolbar = 0xFF343B49, key = 0xFF434C5E, special = 0xFF3B4252,
            accent = 0xFF88C0D0, onAccent = 0xFF1F2933, text = 0xFFECEFF4, hint = 0xFF9AA5B8, alt = 0xFFEBCB8B,
        )
        KeyboardThemePreset.DRACULA -> buildPalette(
            dark = true, bg = 0xFF1E1F29, toolbar = 0xFF252734, key = 0xFF343746, special = 0xFF282A36,
            accent = 0xFFBD93F9, onAccent = 0xFF1A1230, text = 0xFFF8F8F2, hint = 0xFF8D93B8, alt = 0xFFFFB86C,
        )
        KeyboardThemePreset.MOCHA -> buildPalette(
            dark = true, bg = 0xFF181825, toolbar = 0xFF1E1E2E, key = 0xFF313244, special = 0xFF262637,
            accent = 0xFFF5C2E7, onAccent = 0xFF2A1022, text = 0xFFCDD6F4, hint = 0xFF8C91B0, alt = 0xFFFAB387,
        )
        KeyboardThemePreset.TOKYO_NIGHT -> buildPalette(
            dark = true, bg = 0xFF16161E, toolbar = 0xFF1A1B26, key = 0xFF2A2E42, special = 0xFF1F2335,
            accent = 0xFF7AA2F7, onAccent = 0xFF0F1530, text = 0xFFC0CAF5, hint = 0xFF7C86B0, alt = 0xFFFF9E64,
        )
        KeyboardThemePreset.CLEAN_LIGHT -> buildPalette(
            dark = false, bg = 0xFFD9DEE7, toolbar = 0xFFE8ECF3, key = 0xFFFFFFFF, special = 0xFFC5CCD9,
            accent = 0xFF2563EB, onAccent = 0xFFFFFFFF, text = 0xFF111827, hint = 0xFF6B7280, alt = 0xFFD97706,
        )
        KeyboardThemePreset.LATTE -> buildPalette(
            dark = false, bg = 0xFFE6DFD2, toolbar = 0xFFEFE9DD, key = 0xFFFFFCF5, special = 0xFFCFC6B4,
            accent = 0xFFB45309, onAccent = 0xFFFFFFFF, text = 0xFF2B2118, hint = 0xFF857868, alt = 0xFF0F766E,
        )
        KeyboardThemePreset.SAKURA -> buildPalette(
            dark = false, bg = 0xFFF3DDE4, toolbar = 0xFFF9E9EE, key = 0xFFFFFFFF, special = 0xFFE6C3CF,
            accent = 0xFFDB2777, onAccent = 0xFFFFFFFF, text = 0xFF3B0F24, hint = 0xFF94677B, alt = 0xFF7C3AED,
        )

        KeyboardThemePreset.DYNAMIC -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val scheme = if (systemDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
                KeyboardPalette(
                    background = scheme.surfaceContainerLowest,
                    toolbarBackground = scheme.surfaceContainerLow,
                    keyBg = scheme.surfaceContainerHigh,
                    keyPressedBg = scheme.primaryContainer,
                    keyShadow = scheme.outlineVariant,
                    specialKeyBg = scheme.surfaceContainer,
                    specialKeyPressedBg = scheme.secondaryContainer,
                    accentKeyBg = scheme.primary,
                    accentKeyContent = scheme.onPrimary,
                    activeModifierBg = scheme.primary,
                    activeModifierContent = scheme.onPrimary,
                    altModifierBg = scheme.tertiary,
                    keyText = scheme.onSurface,
                    keyHintText = scheme.onSurfaceVariant,
                    border = scheme.outlineVariant,
                    popupBg = scheme.surfaceContainerHighest,
                    popupHighlightBg = scheme.primary,
                    isDark = systemDark,
                )
            } else {
                if (systemDark) resolveKeyboardPalette(KeyboardThemePreset.OBSIDIAN)
                else resolveKeyboardPalette(KeyboardThemePreset.CLEAN_LIGHT)
            }
        }
    }
}

private fun buildPalette(
    dark: Boolean,
    bg: Long,
    toolbar: Long,
    key: Long,
    special: Long,
    accent: Long,
    onAccent: Long,
    text: Long,
    hint: Long,
    alt: Long,
): KeyboardPalette {
    val cBg = Color(bg)
    val cKey = Color(key)
    val cSpecial = Color(special)
    val cAccent = Color(accent)
    val cText = Color(text)
    return KeyboardPalette(
        background = cBg,
        toolbarBackground = Color(toolbar),
        keyBg = cKey,
        keyPressedBg = lerp(cKey, cAccent, 0.30f),
        keyShadow = if (dark) lerp(cBg, Color.Black, 0.55f) else lerp(cBg, Color.Black, 0.20f),
        specialKeyBg = cSpecial,
        specialKeyPressedBg = lerp(cSpecial, cAccent, 0.30f),
        accentKeyBg = cAccent,
        accentKeyContent = Color(onAccent),
        activeModifierBg = cAccent,
        activeModifierContent = Color(onAccent),
        altModifierBg = Color(alt),
        keyText = cText,
        keyHintText = Color(hint),
        border = lerp(cKey, cText, 0.14f),
        popupBg = if (dark) lerp(cKey, cText, 0.10f) else Color.White,
        popupHighlightBg = cAccent,
        isDark = dark,
    )
}
