package com.example.ime.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.example.data.KeyboardThemePreset

@Immutable
data class KeyboardPalette(
    val background: Color,
    val toolbarBackground: Color,
    val keyBg: Color,
    val keyPressedBg: Color,
    val keyShadow: Color,
    val specialKeyBg: Color,
    val specialKeyPressedBg: Color,
    val accentKeyBg: Color,
    val accentKeyContent: Color,
    val activeModifierBg: Color,
    val activeModifierContent: Color,
    val altModifierBg: Color,
    val keyText: Color,
    val keyHintText: Color,
    val border: Color,
    val popupBg: Color,
    val popupHighlightBg: Color,
    val isDark: Boolean,
)

@Composable
fun resolveKeyboardPalette(preset: KeyboardThemePreset): KeyboardPalette {
    val systemDark = isSystemInDarkTheme()
    val context = LocalContext.current

    return when (preset) {
        KeyboardThemePreset.OBSIDIAN -> KeyboardPalette(
            background = Color(0xFF0C1118),
            toolbarBackground = Color(0xFF131B26),
            keyBg = Color(0xFF1E2937),
            keyPressedBg = Color(0xFF2D3E52),
            keyShadow = Color(0xFF06090D),
            specialKeyBg = Color(0xFF16202C),
            specialKeyPressedBg = Color(0xFF263547),
            accentKeyBg = Color(0xFF0EA5E9),
            accentKeyContent = Color(0xFF031521),
            activeModifierBg = Color(0xFF38BDF8),
            activeModifierContent = Color(0xFF041A26),
            altModifierBg = Color(0xFFF59E0B),
            keyText = Color(0xFFF1F5F9),
            keyHintText = Color(0xFF7D91AA),
            border = Color(0xFF2B3A4D),
            popupBg = Color(0xFF283648),
            popupHighlightBg = Color(0xFF38BDF8),
            isDark = true,
        )

        KeyboardThemePreset.CLEAN_LIGHT -> KeyboardPalette(
            background = Color(0xFFE7ECF3),
            toolbarBackground = Color(0xFFF1F5F9),
            keyBg = Color(0xFFFFFFFF),
            keyPressedBg = Color(0xFFDCE6F2),
            keyShadow = Color(0xFFB5C2D1),
            specialKeyBg = Color(0xFFD2DCE8),
            specialKeyPressedBg = Color(0xFFBDCBDA),
            accentKeyBg = Color(0xFF0284C7),
            accentKeyContent = Color.White,
            activeModifierBg = Color(0xFF0284C7),
            activeModifierContent = Color.White,
            altModifierBg = Color(0xFFD97706),
            keyText = Color(0xFF0F172A),
            keyHintText = Color(0xFF64748B),
            border = Color(0xFFCBD5E1),
            popupBg = Color(0xFFFFFFFF),
            popupHighlightBg = Color(0xFF0284C7),
            isDark = false,
        )

        KeyboardThemePreset.MIDNIGHT_BLUE -> KeyboardPalette(
            background = Color(0xFF091224),
            toolbarBackground = Color(0xFF0F1C36),
            keyBg = Color(0xFF182A4D),
            keyPressedBg = Color(0xFF264070),
            keyShadow = Color(0xFF040914),
            specialKeyBg = Color(0xFF12203B),
            specialKeyPressedBg = Color(0xFF1F345E),
            accentKeyBg = Color(0xFF60A5FA),
            accentKeyContent = Color(0xFF06152B),
            activeModifierBg = Color(0xFF60A5FA),
            activeModifierContent = Color(0xFF06152B),
            altModifierBg = Color(0xFFA78BFA),
            keyText = Color(0xFFEFF6FF),
            keyHintText = Color(0xFF8AA4CC),
            border = Color(0xFF273F6E),
            popupBg = Color(0xFF213660),
            popupHighlightBg = Color(0xFF60A5FA),
            isDark = true,
        )

        KeyboardThemePreset.FOREST_TERMINAL -> KeyboardPalette(
            background = Color(0xFF08120E),
            toolbarBackground = Color(0xFF0E1D17),
            keyBg = Color(0xFF142820),
            keyPressedBg = Color(0xFF1E3D31),
            keyShadow = Color(0xFF030806),
            specialKeyBg = Color(0xFF0F2019),
            specialKeyPressedBg = Color(0xFF1A352A),
            accentKeyBg = Color(0xFF10B981),
            accentKeyContent = Color(0xFF021A11),
            activeModifierBg = Color(0xFF34D399),
            activeModifierContent = Color(0xFF021A11),
            altModifierBg = Color(0xFFFBBF24),
            keyText = Color(0xFFD1FAE5),
            keyHintText = Color(0xFF6EE7B7).copy(alpha = 0.65f),
            border = Color(0xFF1E3D31),
            popupBg = Color(0xFF1A352A),
            popupHighlightBg = Color(0xFF10B981),
            isDark = true,
        )

        KeyboardThemePreset.DYNAMIC -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val scheme = if (systemDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
                KeyboardPalette(
                    background = scheme.surfaceContainerLowest,
                    toolbarBackground = scheme.surfaceContainerLow,
                    keyBg = scheme.surfaceContainerHigh,
                    keyPressedBg = scheme.primaryContainer,
                    keyShadow = scheme.outlineVariant,
                    specialKeyBg = scheme.surfaceContainer,
                    specialKeyPressedBg = scheme.secondaryContainer,
                    accentKeyBg = scheme.primary,
                    accentKeyContent = scheme.onPrimary,
                    activeModifierBg = scheme.primary,
                    activeModifierContent = scheme.onPrimary,
                    altModifierBg = scheme.tertiary,
                    keyText = scheme.onSurface,
                    keyHintText = scheme.onSurfaceVariant,
                    border = scheme.outlineVariant,
                    popupBg = scheme.surfaceContainerHighest,
                    popupHighlightBg = scheme.primary,
                    isDark = systemDark,
                )
            } else {
                if (systemDark) resolveKeyboardPalette(KeyboardThemePreset.OBSIDIAN)
                else resolveKeyboardPalette(KeyboardThemePreset.CLEAN_LIGHT)
            }
        }
    }
}
