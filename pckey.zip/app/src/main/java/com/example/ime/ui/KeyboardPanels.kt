package com.example.ime.ui

import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ClipboardEntry
import com.example.ui.components.PCKeyIcons
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.VazirmatnFontFamily

private data class EmojiCategory(
    val title: String,
    val icon: String,
    val emojis: List<String>,
)

private val emojiCategories = listOf(
    EmojiCategory(
        title = "لبخند",
        icon = "😀",
        emojis = listOf(
            "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣",
            "😊", "😇", "🙂", "😉", "😍", "🥰", "😘", "😋",
            "😎", "🤩", "🥳", "🤔", "🤨", "😐", "😑", "😶",
            "🙄", "😏", "😌", "😔", "😴", "🤯", "😱", "😭",
            "😡", "🤬", "🥺", "🥹", "🤗", "🤭", "🤫", "🫠",
        ),
    ),
    EmojiCategory(
        title = "اشاره",
        icon = "👍",
        emojis = listOf(
            "👍", "👎", "👏", "🙌", "🤝", "🙏", "✌️", "🤞",
            "👌", "🤌", "🤏", "👈", "👉", "👆", "👇", "☝️",
            "✋", "🤚", "🖐️", "💪", "🦾", "🫶", "🫡", "✍️",
        ),
    ),
    EmojiCategory(
        title = "قلب",
        icon = "❤️",
        emojis = listOf(
            "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍",
            "💔", "❤️‍🔥", "💕", "💖", "💗", "✨", "⭐", "🌟",
            "🔥", "💥", "💫", "🎉", "🎊", "🏆", "🥇", "💎",
        ),
    ),
    EmojiCategory(
        title = "تکنولوژی",
        icon = "⌨️",
        emojis = listOf(
            "⌨️", "💻", "🖥️", "🖱️", "📱", "⚡", "🔋", "🔌",
            "🛠️", "⚙️", "🔧", "🔒", "🔑", "📌", "📎", "📁",
            "📄", "📝", "🔍", "📊", "🚀", "🛸", "🤖", "🧠",
        ),
    ),
    EmojiCategory(
        title = "کایموجی",
        icon = "ツ",
        emojis = listOf(
            "¯\\_(ツ)_/¯", "(╯°□°)╯︵ ┻━┻", "┬─┬ノ( º _ ºノ)", "(⌐■_■)",
            "(｡◕‿◕｡)", "(づ｡◕‿‿◕｡)づ", "(☞ﾟヮﾟ)☞", "ʕ•ᴥ•ʔ",
            "♥‿♥", "(¬‿¬)", "(T_T)", "(ง'̀-'́)ง",
        ),
    ),
)

@Composable
fun ClipboardPanel(
    entries: List<ClipboardEntry>,
    palette: KeyboardPalette,
    height: Dp,
    onPasteEntry: (ClipboardEntry) -> Unit,
    onTogglePin: (String) -> Unit,
    onDelete: (String) -> Unit,
    onClearUnpinned: () -> Unit,
    onPasteSystemClipboard: () -> Unit,
    onBack: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(height)
            .background(palette.background)
            .padding(horizontal = 8.dp, vertical = 6.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.specialKeyBg)
                        .clickable { onBack() }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                ) {
                    Text(
                        text = "بازگشت",
                        color = palette.keyText,
                        fontSize = 12.sp,
                        fontFamily = VazirmatnFontFamily,
                        fontWeight = FontWeight.Medium,
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "کلیپ‌بورد (${entries.size}) · ← حذف  → سنجاق",
                    color = palette.keyText,
                    fontSize = 13.sp,
                    fontFamily = VazirmatnFontFamily,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.accentKeyBg.copy(alpha = 0.2f))
                        .border(1.dp, palette.accentKeyBg.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .clickable { onPasteSystemClipboard() }
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = PCKeyIcons.ContentPaste,
                            contentDescription = "جای‌گذاری کلیپ‌بورد سیستم",
                            tint = palette.accentKeyBg,
                            modifier = Modifier.size(14.dp),
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Paste",
                            color = palette.keyText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
                if (entries.any { !it.pinned }) {
                    IconButton(
                        onClick = onClearUnpinned,
                        modifier = Modifier.size(32.dp),
                    ) {
                        Icon(
                            imageVector = PCKeyIcons.DeleteSweep,
                            contentDescription = "پاک کردن غیرسنجاق‌شده‌ها",
                            tint = palette.keyHintText,
                            modifier = Modifier.size(18.dp),
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (entries.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = "متنی در کلیپ‌بورد ذخیره نشده است. با دکمه Copy یا Ctrl+C حتی ۱۰ هزار خط بدون لگ ذخیره می‌شود.",
                    color = palette.keyHintText,
                    fontSize = 12.sp,
                    fontFamily = VazirmatnFontFamily,
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(bottom = 4.dp),
            ) {
                items(entries, key = { it.id }) { entry ->
                    SwipeableClipRow(
                        entry = entry,
                        palette = palette,
                        onPaste = { onPasteEntry(entry) },
                        onPin = { onTogglePin(entry.id) },
                        onDelete = { onDelete(entry.id) },
                    )
                }
            }
        }
    }
}

@Composable
private fun SwipeableClipRow(
    entry: ClipboardEntry,
    palette: KeyboardPalette,
    onPaste: () -> Unit,
    onPin: () -> Unit,
    onDelete: () -> Unit,
) {
    var rawOffset by remember(entry.id) { mutableFloatStateOf(0f) }
    var dragging by remember(entry.id) { mutableStateOf(false) }
    val animated by animateFloatAsState(
        targetValue = rawOffset,
        animationSpec = if (dragging) snap() else tween(160),
        label = "clipSwipe",
    )
    val density = LocalDensity.current
    val triggerPx = with(density) { 72.dp.toPx() }
    val maxPx = with(density) { 120.dp.toPx() }
    val shape = RoundedCornerShape(10.dp)
    val pinning = animated > 0f

    Box(modifier = Modifier.fillMaxWidth().clip(shape)) {
        // Action layer revealed behind the row: swipe right = pin, swipe left = delete
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(if (pinning) palette.activeModifierBg else Color(0xFFDC2626))
                .padding(horizontal = 16.dp),
            contentAlignment = if (pinning) Alignment.CenterStart else Alignment.CenterEnd,
        ) {
            if (animated != 0f) {
                Icon(
                    imageVector = if (pinning) PCKeyIcons.Pin else Icons.Default.Close,
                    contentDescription = if (pinning) "سنجاق" else "حذف",
                    tint = if (pinning) palette.activeModifierContent else Color.White,
                    modifier = Modifier.size(20.dp),
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .offset { IntOffset(animated.roundToInt(), 0) }
                .clip(shape)
                .background(palette.keyBg)
                .border(
                    width = 1.dp,
                    color = if (entry.pinned) palette.activeModifierBg.copy(alpha = 0.6f) else palette.border,
                    shape = shape,
                )
                .pointerInput(entry.id) {
                    detectHorizontalDragGestures(
                        onDragStart = { dragging = true },
                        onDragEnd = {
                            dragging = false
                            val o = rawOffset
                            rawOffset = 0f
                            if (o >= triggerPx) onPin() else if (o <= -triggerPx) onDelete()
                        },
                        onDragCancel = {
                            dragging = false
                            rawOffset = 0f
                        },
                        onHorizontalDrag = { change, dx ->
                            change.consume()
                            rawOffset = (rawOffset + dx).coerceIn(-maxPx, maxPx)
                        },
                    )
                }
                .clickable { onPaste() }
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = entry.preview,
                    color = palette.keyText,
                    fontSize = 13.sp,
                    fontFamily = VazirmatnFontFamily,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                if (entry.lineCount > 1 || entry.charCount > 140) {
                    Text(
                        text = "${entry.lineCount} خط • ${formatCharSize(entry.charCount)}",
                        color = palette.activeModifierBg,
                        fontSize = 10.sp,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
            if (entry.pinned) {
                Icon(
                    imageVector = PCKeyIcons.Pin,
                    contentDescription = "سنجاق‌شده",
                    tint = palette.activeModifierBg,
                    modifier = Modifier.size(14.dp),
                )
            }
        }
    }
}

private fun formatCharSize(chars: Int): String {
    return if (chars >= 1024) {
        "${chars / 1024} KB"
    } else {
        "$chars chars"
    }
}

@Composable
fun EmojiPanel(
    palette: KeyboardPalette,
    height: Dp,
    onPickEmoji: (String) -> Unit,
    onBackspace: () -> Unit,
    onBack: () -> Unit,
) {
    var selectedCategory by remember { mutableIntStateOf(0) }
    val currentCategory = emojiCategories[selectedCategory]

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(height)
            .background(palette.background)
            .padding(horizontal = 8.dp, vertical = 6.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(palette.specialKeyBg)
                    .clickable { onBack() }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
            ) {
                Text(
                    text = "ABC",
                    color = palette.keyText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            emojiCategories.forEachIndexed { idx, cat ->
                val isSelected = idx == selectedCategory
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) palette.activeModifierBg else palette.specialKeyBg)
                        .clickable { selectedCategory = idx }
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                ) {
                    Text(
                        text = "${cat.icon} ${cat.title}",
                        color = if (isSelected) palette.activeModifierContent else palette.keyText,
                        fontSize = 12.sp,
                        fontFamily = VazirmatnFontFamily,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    )
                }
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(palette.specialKeyBg)
                    .clickable { onBackspace() }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
            ) {
                Icon(
                    imageVector = PCKeyIcons.Backspace,
                    contentDescription = "پاک کردن",
                    tint = palette.keyText,
                    modifier = Modifier.size(16.dp),
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        val columns = if (selectedCategory == emojiCategories.lastIndex) 2 else 8
        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(currentCategory.emojis) { item ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.keyBg.copy(alpha = 0.45f))
                        .clickable { onPickEmoji(item) }
                        .padding(vertical = 7.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = item,
                        fontSize = if (columns == 2) 14.sp else 22.sp,
                        color = palette.keyText,
                    )
                }
            }
        }
    }
}
