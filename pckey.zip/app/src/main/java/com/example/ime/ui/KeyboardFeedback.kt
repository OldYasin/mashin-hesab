package com.example.ime.ui

import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.data.KeyboardSettings
import com.example.ime.model.KeyAction

class KeyboardFeedback(context: Context) {

    private val appContext = context.applicationContext
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    @Suppress("DEPRECATION")
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        manager?.defaultVibrator
    } else {
        appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    fun performFeedback(action: KeyAction?, settings: KeyboardSettings) {
        if (settings.hapticEnabled) {
            vibrateKey(settings.hapticStrength)
        }
        if (settings.soundEnabled) {
            playSound(action)
        }
    }

    fun performTick(settings: KeyboardSettings) {
        if (settings.hapticEnabled) {
            vibrateKey((settings.hapticStrength * 0.6f).toInt().coerceAtLeast(15))
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrateKey(strength: Int) {
        val vib = vibrator ?: return
        if (!vib.hasVibrator()) return
        val durationMs = (8L + (strength * 0.22f).toLong()).coerceIn(6L, 32L)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val amplitude = ((strength / 100f) * 220f).toInt().coerceIn(25, 255)
            vib.vibrate(VibrationEffect.createOneShot(durationMs, amplitude))
        } else {
            vib.vibrate(durationMs)
        }
    }

    private fun playSound(action: KeyAction?) {
        val am = audioManager ?: return
        val effect = when (action) {
            KeyAction.Backspace, KeyAction.ForwardDelete -> AudioManager.FX_KEYPRESS_DELETE
            KeyAction.Space -> AudioManager.FX_KEYPRESS_SPACEBAR
            KeyAction.Enter -> AudioManager.FX_KEYPRESS_RETURN
            else -> AudioManager.FX_KEYPRESS_STANDARD
        }
        am.playSoundEffect(effect, -1f)
    }
}
