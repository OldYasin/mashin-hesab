package com.example.core.scripts

import android.util.Base64
import com.example.data.local.ServerEndpointEntity
import com.example.data.model.EndpointType
import org.json.JSONObject

object ScriptTemplates {

    fun generateGoogleAppsScript(
        secretKey: String,
        enableEncryption: Boolean = true,
        enableGzip: Boolean = true
    ): String = """
/**
 * ScriptTunnel v2 - Google Apps Script Encrypted & Compressed Relay
 * Deploy as: Web App -> Execute as: Me -> Who has access: Anyone
 * No VPS Required | Parallel Multi-Script Ready | DoH + HTTP/HTTPS Relay
 */
const TUNNEL_SECRET = "$secretKey";
const ENFORCE_ENCRYPTION = $enableEncryption;
const ENABLE_GZIP_RESPONSE = $enableGzip;

function doGet(e) {
  const params = (e && e.parameter) ? e.parameter : {};
  if (params.ping === "1") {
    if (params.token && params.token !== TUNNEL_SECRET) {
      return jsonOut({ ok: false, error: "unauthorized" });
    }
    return jsonOut({
      ok: true,
      edge: "google-apps-script",
      ts: Date.now(),
      enc: ENFORCE_ENCRYPTION,
      gzip: ENABLE_GZIP_RESPONSE
    });
  }
  return jsonOut({ ok: true, service: "ScriptTunnel Relay Active" });
}

function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) {
      return jsonOut({ ok: false, error: "empty_body" });
    }
    const envelope = JSON.parse(e.postData.contents);
    let payloadBytes;

    if (envelope.enc === true && envelope.data) {
      const rawPacket = Utilities.base64Decode(envelope.data);
      const decrypted = decryptStreamHmac(rawPacket, TUNNEL_SECRET);
      if (!decrypted) {
        return jsonOut({ ok: false, error: "hmac_auth_failed" });
      }
      payloadBytes = decrypted;
    } else if (!ENFORCE_ENCRYPTION && envelope.token === TUNNEL_SECRET && envelope.data) {
      payloadBytes = Utilities.base64Decode(envelope.data);
    } else {
      return jsonOut({ ok: false, error: "invalid_auth_or_encryption" });
    }

    if (envelope.comp === "gzip") {
      payloadBytes = Utilities.ungzip(Utilities.newBlob(payloadBytes, "application/x-gzip")).getBytes();
    }

    const req = JSON.parse(Utilities.newBlob(payloadBytes).getDataAsString("UTF-8"));

    // Action 1: DNS-over-HTTPS Query
    if (req.action === "doh" && req.dnsB64) {
      const dnsWire = Utilities.base64Decode(req.dnsB64);
      const dohRes = UrlFetchApp.fetch("https://dns.google/dns-query", {
        method: "post",
        contentType: "application/dns-message",
        headers: { "Accept": "application/dns-message" },
        payload: dnsWire,
        muteHttpExceptions: true
      });
      return respondEncrypted({
        ok: true,
        status: dohRes.getResponseCode(),
        dnsB64: Utilities.base64Encode(dohRes.getContent())
      });
    }

    // Action 2: Telemetry Sync Echo (Offline Queue Sync)
    if (req.action === "sync_ack") {
      return respondEncrypted({ ok: true, syncedAt: Date.now(), count: req.count || 0 });
    }

    // Action 2.5: Batch HTTP/HTTPS Relay via UrlFetchApp.fetchAll
    if (req.action === "batch" && Array.isArray(req.items)) {
      const fetchReqs = [];
      const itemMeta = [];
      for (let i = 0; i < req.items.length; i++) {
        const item = req.items[i];
        const ch = {};
        if (item.headers) {
          for (const k in item.headers) {
            const lk = k.toLowerCase();
            if (lk === "host" || lk === "content-length" || lk === "connection" || lk === "accept-encoding" || lk === "transfer-encoding") {
              continue;
            }
            ch[k] = item.headers[k];
          }
        }
        const opts = {
          url: item.url,
          method: (item.method || "get").toLowerCase(),
          headers: ch,
          muteHttpExceptions: true,
          followRedirects: item.followRedirects !== false
        };
        if (item.bodyB64 && opts.method !== "get" && opts.method !== "head") {
          opts.payload = Utilities.base64Decode(item.bodyB64);
        }
        fetchReqs.push(opts);
        itemMeta.push(item);
      }
      let results = null;
      try {
        results = UrlFetchApp.fetchAll(fetchReqs);
      } catch (batchErr) {
        results = null;
      }
      const outItems = [];
      for (let i = 0; i < fetchReqs.length; i++) {
        try {
          const r = results ? results[i] : UrlFetchApp.fetch(fetchReqs[i].url, fetchReqs[i]);
          const rh = r.getAllHeaders();
          let bb = r.getContent();
          let be = "none";
          if (itemMeta[i].gzBody === true && bb.length > 200 && isCompressibleType(rh)) {
            const gz = Utilities.gzip(Utilities.newBlob(bb, "application/octet-stream")).getBytes();
            if (gz.length < bb.length) {
              bb = gz;
              be = "gzip";
            }
          }
          outItems.push({
            ok: true,
            status: r.getResponseCode(),
            headers: rh,
            bodyEnc: be,
            bodyB64: Utilities.base64Encode(bb)
          });
        } catch (itemErr) {
          outItems.push({ ok: false, error: String(itemErr) });
        }
      }
      return respondFast({ ok: true, items: outItems }, req.light === true);
    }

    // Action 3: HTTP/HTTPS Relay
    if (!req.url) {
      return jsonOut({ ok: false, error: "missing_url" });
    }

    const cleanHeaders = {};
    if (req.headers) {
      for (const k in req.headers) {
        const lk = k.toLowerCase();
        if (lk === "host" || lk === "content-length" || lk === "connection" || lk === "accept-encoding" || lk === "transfer-encoding") {
          continue;
        }
        cleanHeaders[k] = req.headers[k];
      }
    }

    const fetchOpts = {
      method: (req.method || "get").toLowerCase(),
      headers: cleanHeaders,
      muteHttpExceptions: true,
      followRedirects: req.followRedirects !== false
    };
    if (req.bodyB64 && fetchOpts.method !== "get" && fetchOpts.method !== "head") {
      fetchOpts.payload = Utilities.base64Decode(req.bodyB64);
      for (const hk in cleanHeaders) {
        if (hk.toLowerCase() === "content-type") { fetchOpts.contentType = cleanHeaders[hk]; delete cleanHeaders[hk]; break; }
      }
    }

    const res = UrlFetchApp.fetch(req.url, fetchOpts);
    const respHeaders = res.getAllHeaders();
    let bodyBytes = res.getContent();
    let bodyEnc = "none";
    // text bodies are gzipped before base64 (base64 of plain text barely compresses afterwards)
    if (req.gzBody === true && bodyBytes.length > 200 && isCompressibleType(respHeaders)) {
      const gz = Utilities.gzip(Utilities.newBlob(bodyBytes, "application/octet-stream")).getBytes();
      if (gz.length < bodyBytes.length) {
        bodyBytes = gz;
        bodyEnc = "gzip";
      }
    }
    return respondFast({
      ok: true,
      status: res.getResponseCode(),
      headers: respHeaders,
      bodyEnc: bodyEnc,
      bodyB64: Utilities.base64Encode(bodyBytes)
    }, req.light === true);
  } catch (err) {
    return jsonOut({ ok: false, error: String(err) });
  }
}

function respondFast(obj, isLight) {
  let rawBytes = Utilities.newBlob(JSON.stringify(obj)).getBytes();
  let compMode = "none";
  if (ENABLE_GZIP_RESPONSE && rawBytes.length > 64) {
    const gz = Utilities.gzip(Utilities.newBlob(rawBytes)).getBytes();
    if (gz.length < rawBytes.length) {
      rawBytes = gz;
      compMode = "gzip";
    }
  }
  if (isLight) {
    return jsonOut({
      ok: true,
      enc: false,
      comp: compMode,
      data: Utilities.base64Encode(rawBytes)
    });
  }
  const encrypted = encryptStreamHmac(rawBytes, TUNNEL_SECRET);
  return jsonOut({
    ok: true,
    enc: true,
    comp: compMode,
    data: Utilities.base64Encode(encrypted)
  });
}

function respondEncrypted(obj) {
  return respondFast(obj, false);
}

function isCompressibleType(headers) {
  let ct = "";
  for (const k in headers) {
    if (k.toLowerCase() === "content-type") { ct = String(headers[k]).toLowerCase(); break; }
  }
  if (!ct) return false;
  return ct.indexOf("text/") === 0 || ct.indexOf("json") >= 0 || ct.indexOf("javascript") >= 0 ||
    ct.indexOf("xml") >= 0 || ct.indexOf("svg") >= 0;
}

function jsonOut(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function sha256Bytes(bytes) {
  return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, bytes);
}

function encryptStreamHmac(plain, secret) {
  const key = sha256Bytes(Utilities.newBlob(secret).getBytes());
  const nonce = [];
  for (let i = 0; i < 16; i++) nonce.push(Math.floor(Math.random() * 256) - 128);
  const cipher = xorKeyStream(plain, key, nonce);
  const macInput = nonce.concat(cipher);
  const tag = Utilities.computeHmacSha256Signature(macInput, key);
  return nonce.concat(tag).concat(cipher);
}

function decryptStreamHmac(packet, secret) {
  if (!packet || packet.length < 48) return null;
  const key = sha256Bytes(Utilities.newBlob(secret).getBytes());
  const nonce = packet.slice(0, 16);
  const tag = packet.slice(16, 48);
  const cipher = packet.slice(48);
  const expected = Utilities.computeHmacSha256Signature(nonce.concat(cipher), key);
  for (let i = 0; i < 32; i++) {
    if ((tag[i] & 0xff) !== (expected[i] & 0xff)) return null;
  }
  return xorKeyStream(cipher, key, nonce);
}

function xorKeyStream(input, key, nonce) {
  const out = new Array(input.length);
  let counter = 0;
  let offset = 0;
  while (offset < input.length) {
    const cBytes = [
      (counter >>> 24) & 0xff,
      (counter >>> 16) & 0xff,
      (counter >>> 8) & 0xff,
      counter & 0xff
    ].map(b => b > 127 ? b - 256 : b);
    const block = sha256Bytes(key.concat(nonce).concat(cBytes));
    const n = Math.min(block.length, input.length - offset);
    for (let i = 0; i < n; i++) {
      out[offset + i] = ((input[offset + i] & 0xff) ^ (block[i] & 0xff));
      if (out[offset + i] > 127) out[offset + i] -= 256;
    }
    offset += n;
    counter++;
  }
  return out;
}
""".trimIndent()

    fun generateCloudflareWorkerScript(secretKey: String): String = """
/**
 * ScriptTunnel v5 (v8-stable) - Cloudflare Worker Full-Duplex TCP over WebSocket
 * Direct connect() first; on connect failure (destination on Cloudflare / blocked) -> ProxyIP fallback.
 * Fixes:
 *  - Serialized writeChain + safe connecting guard prevents "TypeError: This WritableStream has been closed."
 *    during ProxyIP failover / socket swap.
 *  - Faster 2500ms connect timeouts (max 3 ProxyIPs) so total setup stays well below client timeout.
 *  - Dead ProxyIPs are cached for 120s and never re-selected via goodProxy; fallback list includes
 *    multiple independent ProxyIP pools.
 */
import { connect } from 'cloudflare:sockets';

const TUNNEL_SECRET = "$secretKey";

const DEFAULT_PROXY_IPS = [
  "ProxyIP.DE.CMLiussss.net",
  "ProxyIP.NL.CMLiussss.net",
  "ProxyIP.SG.CMLiussss.net",
  "ProxyIP.US.CMLiussss.net",
  "ProxyIP.JP.CMLiussss.net",
  "proxyip.fxxk.dedyn.io",
  "cdn-all.xn--b6gac.eu.org",
  "cdn.xn--b6gac.eu.org"
];

// shared by all requests handled in the same isolate
let goodProxy = "";
const badProxy = new Map();

function markBad(p) {
  if (!p) return;
  badProxy.set(p, Date.now() + 120000);
  if (p === goodProxy) goodProxy = "";
}

function getProxyList(env, fromApp) {
  const split = (v) => v ? String(v).split(",").map(s => s.trim()).filter(Boolean) : [];
  const pinned = split(fromApp).concat(split(env && env.PROXYIP));
  const now = Date.now();
  if (goodProxy && (badProxy.get(goodProxy) || 0) > now) goodProxy = "";
  const rest = (goodProxy ? [goodProxy] : []).concat(DEFAULT_PROXY_IPS);
  const all = pinned.concat(rest.filter(x => !pinned.includes(x)));
  const alive = all.filter(x => !((badProxy.get(x) || 0) > now));
  return alive.length ? alive : DEFAULT_PROXY_IPS.slice();
}

function parseHostPort(entry, defPort) {
  let h = entry, p = defPort;
  const m = entry.match(/^(.+):(\d+)${'$'}/);
  if (m && !entry.includes("]")) { h = m[1]; p = Number(m[2]); }
  return { hostname: h, port: p, key: entry };
}

async function openWithTimeout(sock, ms) {
  let t;
  const timeout = new Promise((_, rej) => { t = setTimeout(() => rej(new Error("connect timeout")), ms); });
  try { await Promise.race([sock.opened, timeout]); } finally { clearTimeout(t); }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const upgradeHeader = request.headers.get("Upgrade");

    if (url.pathname === "/ping") {
      return new Response(JSON.stringify({ ok: true, edge: "cf-worker-ws", ver: "v8-stable", colo: (request.cf && request.cf.colo) || "", country: (request.cf && request.cf.country) || "", ts: Date.now() }), {
        headers: { "content-type": "application/json" }
      });
    }

    if (url.pathname === "/egress") {
      const hdr = { "content-type": "application/json" };
      const colo = (request.cf && request.cf.colo) || "";
      try {
        const s = connect({ hostname: "ip-api.com", port: 80 });
        await openWithTimeout(s, 3000);
        const w = s.writable.getWriter();
        await w.write(new TextEncoder().encode("GET /json?fields=status,country,countryCode,query,isp,hosting HTTP/1.1\r\nHost: ip-api.com\r\nConnection: close\r\n\r\n"));
        const r = s.readable.getReader();
        const dec = new TextDecoder();
        let out = "";
        const t0 = Date.now();
        while (Date.now() - t0 < 3000) {
          const { value, done } = await r.read();
          if (done) break;
          out += dec.decode(value, { stream: true });
        }
        try { s.close(); } catch (e) {}
        const body = out.split("\r\n\r\n").slice(1).join("").trim();
        return new Response(JSON.stringify({ colo: colo, egress: body }), { headers: hdr });
      } catch (e) {
        return new Response(JSON.stringify({ colo: colo, error: String(e) }), { headers: hdr });
      }
    }

    if (!upgradeHeader || upgradeHeader.toLowerCase() !== "websocket") {
      return new Response("ScriptTunnel CF-Worker Active (v8-stable)", { status: 200 });
    }

    const authToken = request.headers.get("X-Tunnel-Auth") || url.searchParams.get("token");
    if (authToken !== TUNNEL_SECRET) {
      return new Response("Unauthorized", { status: 403 });
    }

    const webSocketPair = new WebSocketPair();
    const [client, server] = Object.values(webSocketPair);
    server.accept();

    let remoteSocket = null;
    let remoteWriter = null;
    let closed = false;
    let connecting = false;
    let gotData = false;
    let viaProxy = false;
    let currentProxy = "";
    let retries = 0;
    let target = null;
    let replayable = true;
    let rxTotal = 0;
    let directFail = "";
    let sniName = "";
    let sentSize = 0;
    const sentChunks = [];
    const pending = [];
    let writeChain = Promise.resolve();

    const releaseWriter = () => {
      const w = remoteWriter;
      remoteWriter = null;
      if (w) { try { w.releaseLock(); } catch {} }
    };

    const cleanup = () => {
      if (closed) return;
      closed = true;
      releaseWriter();
      try { remoteSocket?.close(); } catch {}
      remoteSocket = null;
      try { server.close(); } catch {}
    };

    const toBytes = async (data) => {
      return data instanceof ArrayBuffer
        ? new Uint8Array(data)
        : ArrayBuffer.isView(data)
          ? new Uint8Array(data.buffer, data.byteOffset, data.byteLength)
          : new Uint8Array(await data.arrayBuffer());
    };

    const writeToCurrent = async (bytes) => {
      if (closed) return;
      if (!remoteWriter || connecting) {
        if (pending.length < 256) pending.push(bytes);
        return;
      }
      if (!gotData) {
        if (sentSize + bytes.byteLength <= 65536) { sentChunks.push(bytes); sentSize += bytes.byteLength; }
        else replayable = false;
      }
      const w = remoteWriter;
      try {
        await w.write(bytes);
      } catch (e) {
        // Stream closed while waiting on ProxyIP or during failover: buffer if replayable instead of crashing WS
        if (!closed && (connecting || (!gotData && viaProxy && replayable && retries < 3))) {
          if (pending.length < 256) pending.push(bytes);
          return;
        }
        throw e;
      }
    };

    const sendRemote = (bytes) => {
      writeChain = writeChain.then(() => writeToCurrent(bytes));
      return writeChain;
    };

    const flushPending = async () => {
      while (pending.length && !closed && remoteWriter && !connecting) {
        const chunk = pending.shift();
        await writeToCurrent(chunk);
      }
    };

    const pipeRemote = (sock) => {
      (async () => {
        const reader = sock.readable.getReader();
        try {
          while (true) {
            const { value, done } = await reader.read();
            if (done) break;
            if (value && value.byteLength > 0) {
              if (!gotData) { gotData = true; if (viaProxy && currentProxy) goodProxy = currentProxy; }
              rxTotal += value.byteLength;
              server.send(value);
            }
          }
        } catch (e) {}
        // ProxyIP accepted the connection but never answered -> mark it bad and try the next one
        if (!gotData && viaProxy && sock === remoteSocket && !closed && replayable && retries < 3) {
          retries++;
          try { server.send(JSON.stringify({ type: "INFO", event: "proxy-dead", proxy: currentProxy })); } catch {}
          markBad(currentProxy);
          connecting = true;
          releaseWriter();
          try {
            await attach(true);
            for (const c of sentChunks) {
              if (closed || !remoteWriter) break;
              await remoteWriter.write(c);
            }
            connecting = false;
            await flushPending();
            return;
          } catch (e) {
            connecting = false;
          }
        }
        if (sock === remoteSocket) {
          try { server.send(JSON.stringify({ type: "INFO", event: "remote-end", rx: rxTotal, route: viaProxy ? "proxy" : "direct" })); } catch {}
          cleanup();
        }
      })();
    };

    const attach = async (useProxy) => {
      const candidates = useProxy
        ? getProxyList(env, target.proxyip).slice(0, 3).map(e => parseHostPort(e, target.port))
        : [{ hostname: target.host, port: target.port, key: "" }];
      let lastErr = null;
      const tried = [];
      for (const c of candidates) {
        if (closed) throw new Error("ws closed");
        try {
          const s = connect({ hostname: c.hostname, port: c.port });
          await openWithTimeout(s, 2500);
          releaseWriter();
          try { remoteSocket?.close(); } catch {}
          remoteSocket = s;
          remoteWriter = s.writable.getWriter();
          viaProxy = useProxy;
          currentProxy = c.key;
          pipeRemote(s);
          return;
        } catch (e) { lastErr = e; tried.push(c.hostname + ":" + c.port); markBad(c.key); }
      }
      throw new Error((useProxy ? "ProxyIP failed [" : "direct failed [") + tried.join(", ") + "] " + (lastErr ? lastErr.message : ""));
    };

    const doConnect = async (host, port, proxyip, force, sni) => {
      target = { host, port: Number(port), proxyip: proxyip || "" };
      sniName = sni || "";
      connecting = true;
      const t0 = Date.now();
      try {
        if (force) {
          try {
            await attach(true);
          } catch (e) {
            directFail = "force-proxy failed, using direct: " + String(e && e.message ? e.message : e).slice(0, 100);
            await attach(false);
          }
        } else {
          try {
            await attach(false);
          } catch (e) {
            directFail = String(e && e.message ? e.message : e).slice(0, 140);
            await attach(true);
          }
        }
        server.send(JSON.stringify({
          type: "CONNECTED",
          route: viaProxy ? "proxy" : "direct",
          via: viaProxy ? currentProxy : "",
          ms: Date.now() - t0,
          directFail: directFail
        }));
      } finally {
        connecting = false;
      }
      await flushPending();
    };

    server.addEventListener("message", async (event) => {
      try {
        if (typeof event.data === "string") {
          const ctrl = JSON.parse(event.data);
          if (ctrl.type === "PING") {
            server.send(JSON.stringify({ type: "PONG", ts: Date.now() }));
            return;
          }
          if (ctrl.type === "CONNECT" && ctrl.host && ctrl.port && !remoteSocket && !connecting) {
            await doConnect(ctrl.host, ctrl.port, ctrl.proxyip, ctrl.forceProxy === true, ctrl.sni);
          }
        } else {
          const bytes = await toBytes(event.data);
          if (!remoteWriter || connecting) {
            if (pending.length < 256) pending.push(bytes);
            return;
          }
          await sendRemote(bytes);
        }
      } catch (err) {
        try { server.send(JSON.stringify({ type: "ERROR", message: String(err) })); } catch {}
        cleanup();
      }
    });

    server.addEventListener("close", cleanup);
    server.addEventListener("error", cleanup);

    return new Response(null, { status: 101, webSocket: client });
  }
};
""".trimIndent()

    data class BundleImportResult(
        val servers: List<ServerEndpointEntity>,
        val cleanGoogleIp: String,
        val cleanCfIp: String
    )

    fun encodeBundleUri(
        servers: List<ServerEndpointEntity>,
        cleanGoogleIp: String,
        cleanCfIp: String
    ): String {
        val arr = org.json.JSONArray()
        servers.forEach { ep ->
            arr.put(JSONObject().apply {
                put("name", ep.name)
                put("url", ep.url)
                put("key", ep.secretKey)
                put("type", ep.type)
                put("sni", ep.customSniHost)
                put("ip", ep.customCleanIp)
                put("w", ep.weight)
            })
        }
        val rootObj = JSONObject().apply {
            put("bundle", true)
            put("v", 1)
            put("googleIp", cleanGoogleIp)
            put("cfIp", cleanCfIp)
            put("servers", arr)
        }.toString()
        val b64 = Base64.encodeToString(rootObj.toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.URL_SAFE)
        return "scriptvpnbundle://$b64"
    }

    fun decodeBundleUri(raw: String): BundleImportResult? {
        val trimmed = raw.trim()
        val jsonStr = when {
            trimmed.startsWith("scriptvpnbundle://") -> {
                val b64 = trimmed.removePrefix("scriptvpnbundle://")
                runCatching { String(Base64.decode(b64, Base64.URL_SAFE or Base64.DEFAULT), Charsets.UTF_8) }.getOrNull()
                    ?: return null
            }
            trimmed.startsWith("{") && trimmed.contains(""bundle"") -> trimmed
            else -> return null
        }
        return runCatching {
            val obj = JSONObject(jsonStr)
            val arr = obj.optJSONArray("servers") ?: return@runCatching null
            val list = mutableListOf<ServerEndpointEntity>()
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                list.add(
                    ServerEndpointEntity(
                        name = item.optString("name", "سرور ایمپورت‌شده"),
                        url = item.optString("url").trim(),
                        secretKey = item.optString("key", ""),
                        type = item.optString("type", EndpointType.GAS_SCRIPT.name),
                        customSniHost = item.optString("sni", ""),
                        customCleanIp = item.optString("ip", ""),
                        weight = item.optInt("w", 1),
                        isParallelActive = true
                    )
                )
            }
            BundleImportResult(
                servers = list.filter { it.url.isNotBlank() },
                cleanGoogleIp = obj.optString("googleIp", ""),
                cleanCfIp = obj.optString("cfIp", "")
            )
        }.getOrNull()
    }

    fun encodeShareUri(endpoint: ServerEndpointEntity): String {
        val json = JSONObject().apply {
            put("v", 2)
            put("name", endpoint.name)
            put("url", endpoint.url)
            put("key", endpoint.secretKey)
            put("type", endpoint.type)
            put("sni", endpoint.customSniHost)
            put("ip", endpoint.customCleanIp)
            put("w", endpoint.weight)
        }.toString()
        val b64 = Base64.encodeToString(json.toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.URL_SAFE)
        return "scriptvpn://$b64"
    }

    fun decodeShareUri(raw: String): ServerEndpointEntity? {
        val trimmed = raw.trim()
        if (com.example.network.DnsttConfigParser.looksLikeDnstt(trimmed)) {
            com.example.network.DnsttConfigParser.parse(trimmed)?.let { return it }
        }
        val jsonStr = when {
            trimmed.startsWith("scriptvpn://") -> {
                val b64 = trimmed.removePrefix("scriptvpn://")
                runCatching {
                    String(Base64.decode(b64, Base64.URL_SAFE or Base64.DEFAULT), Charsets.UTF_8)
                }.getOrNull() ?: return null
            }
            trimmed.startsWith("{") -> trimmed
            else -> return null
        }
        return runCatching {
            val obj = JSONObject(jsonStr)
            val url = obj.getString("url").trim()
            val typeStr = obj.optString("type", EndpointType.GAS_SCRIPT.name)
            ServerEndpointEntity(
                name = obj.optString("name", "سرور واردشده"),
                url = url,
                secretKey = obj.optString("key", ""),
                type = typeStr,
                customSniHost = obj.optString("sni", ""),
                customCleanIp = obj.optString("ip", ""),
                weight = obj.optInt("w", 1),
                isParallelActive = true
            )
        }.getOrNull()
    }
}
