package com.example.network

import java.util.Locale

/**
 * Small in-memory LRU for static GET responses relayed through Apps Script.
 * Every relay costs ~1s of latency plus Apps Script quota, so repeated images/scripts/styles
 * (and identical requests made at the same moment) should not go through it twice.
 */
class GasRelayCache(private val maxBytes: Long = 32L * 1024 * 1024) {

    private class Entry(val response: GasRelayResponse, val expiresAt: Long, val size: Int)

    private val map = LinkedHashMap<String, Entry>(64, 0.75f, true)
    private var totalBytes = 0L

    @Synchronized
    fun get(key: String): GasRelayResponse? {
        val entry = map[key] ?: return null
        if (System.currentTimeMillis() >= entry.expiresAt) {
            map.remove(key)
            totalBytes -= entry.size
            return null
        }
        return entry.response
    }

    @Synchronized
    fun put(key: String, response: GasRelayResponse, ttlMs: Long) {
        if (ttlMs <= 0L) return
        val size = response.bodyBytes.size + 512
        if (size > MAX_ENTRY_BYTES + 512) return
        map.remove(key)?.let { totalBytes -= it.size }
        map[key] = Entry(response, System.currentTimeMillis() + ttlMs, size)
        totalBytes += size
        val iter = map.entries.iterator()
        while (totalBytes > maxBytes && iter.hasNext()) {
            val oldest = iter.next()
            totalBytes -= oldest.value.size
            iter.remove()
        }
    }

    @Synchronized
    fun clear() {
        map.clear()
        totalBytes = 0L
    }

    companion object {
        const val MAX_ENTRY_BYTES = 4 * 1024 * 1024
        private const val MAX_TTL_MS = 3_600_000L
        private const val DEFAULT_STATIC_TTL_MS = 300_000L

        private const val HASHED_ASSET_TTL_MS = 6 * 3_600_000L
        // Vite/webpack style content-hashed names (name-AbCd1234.js): the name changes when the content does
        private val HASHED_ASSET = Regex("-[A-Za-z0-9_-]{8}\\.(?:m?js|css|woff2?|png|jpe?g|webp|svg|gif|wasm)$")

        fun isHashedAsset(url: String): Boolean {
            val path = url.substringBefore('?').substringBefore('#')
            return HASHED_ASSET.containsMatchIn(path)
        }

        private val S_MAXAGE = Regex("s-maxage\\s*=\\s*(\\d+)")
        private val MAXAGE = Regex("max-age\\s*=\\s*(\\d+)")

        fun keyFor(url: String, headers: Map<String, String>): String {
            val accept = headers.entries.firstOrNull { it.key.equals("accept", ignoreCase = true) }?.value.orEmpty()
            return "$url|$accept"
        }

        fun isCacheableRequest(method: String, headers: Map<String, String>, body: ByteArray?): Boolean {
            if (!method.equals("GET", ignoreCase = true)) return false
            if (body != null && body.isNotEmpty()) return false
            return headers.keys.none { it.equals("range", ignoreCase = true) || it.equals("authorization", ignoreCase = true) }
        }

        private fun isStaticType(contentType: String): Boolean =
            contentType.startsWith("image/") ||
                contentType.startsWith("font/") ||
                contentType.startsWith("text/css") ||
                contentType.contains("javascript") ||
                contentType.contains("application/font") ||
                contentType.contains("application/x-font") ||
                contentType.contains("application/wasm")

        /** How long a response may be reused, in ms; 0 = do not cache. */
        fun ttlMsFor(res: GasRelayResponse, reqHeaders: Map<String, String>, url: String? = null): Long {
            val hashed = url != null && isHashedAsset(url)
            if (!res.ok || res.statusCode != 200) return 0L
            if (res.bodyBytes.isEmpty() || res.bodyBytes.size > MAX_ENTRY_BYTES) return 0L

            var cacheControl = ""
            var contentType = ""
            var vary = ""
            var hasSetCookie = false
            for ((k, v) in res.headers) {
                when (k.lowercase(Locale.ROOT)) {
                    "cache-control" -> cacheControl = v.lowercase(Locale.ROOT)
                    "content-type" -> contentType = v.lowercase(Locale.ROOT)
                    "vary" -> vary = v.lowercase(Locale.ROOT)
                    "set-cookie" -> hasSetCookie = true
                }
            }
            if (hasSetCookie) return 0L
            if (cacheControl.contains("no-store") || cacheControl.contains("private")) return 0L
            if (!hashed && cacheControl.contains("no-cache")) return 0L
            if (vary.contains("*") || vary.contains("cookie")) return 0L

            val isStatic = isStaticType(contentType)
            val hasCookie = reqHeaders.keys.any { it.equals("cookie", ignoreCase = true) }
            if (hasCookie && !isStatic && !cacheControl.contains("public")) return 0L

            if (hashed) return HASHED_ASSET_TTL_MS

            val maxAge = S_MAXAGE.find(cacheControl)?.groupValues?.get(1)?.toLongOrNull()
                ?: MAXAGE.find(cacheControl)?.groupValues?.get(1)?.toLongOrNull()
            return when {
                maxAge != null -> if (maxAge <= 0L) 0L else minOf(maxAge * 1000L, MAX_TTL_MS)
                isStatic -> DEFAULT_STATIC_TTL_MS
                else -> 0L
            }
        }
    }
}
