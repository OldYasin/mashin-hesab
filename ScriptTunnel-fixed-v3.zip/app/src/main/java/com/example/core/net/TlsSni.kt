package com.example.core.net

/** Reads the server name (SNI) out of a TLS ClientHello without touching the payload. */
object TlsSni {
    fun parse(d: ByteArray): String? = runCatching {
        if (d.size < 48 || d[0].toInt() != 0x16 || d[5].toInt() != 0x01) return null
        var p = 5 + 4 + 2 + 32                       // record hdr + handshake hdr + version + random
        p += 1 + (d[p].toInt() and 0xFF)             // session id
        p += 2 + (u16(d, p))                         // cipher suites
        p += 1 + (d[p].toInt() and 0xFF)             // compression
        val extEnd = p + 2 + u16(d, p); p += 2
        while (p + 4 <= extEnd && p + 4 <= d.size) {
            val type = u16(d, p); val len = u16(d, p + 2); p += 4
            if (type == 0) {                         // server_name
                var q = p + 2
                if (q + 3 > d.size) return null
                val nameLen = u16(d, q + 1); q += 3
                if (q + nameLen > d.size) return null
                return String(d, q, nameLen, Charsets.US_ASCII).lowercase()
            }
            p += len
        }
        null
    }.getOrNull()

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
}

/**
 * Sites that refuse Cloudflare-edge egress IPs near Iran ("not supported in your country").
 * These are sent through a ProxyIP (real foreign exit) instead of the worker's own IP.
 */
object GeoRoute {
    private val suffixes = listOf(
        "gemini.google.com", "bard.google.com", "aistudio.google.com", "makersuite.google.com",
        "generativelanguage.googleapis.com", "clients6.google.com", "accounts.google.com",
        "google.com", "googleapis.com", "gstatic.com", "googleusercontent.com", "ggpht.com",
        "notebooklm.google", "labs.google", "deepmind.google", "openai.com", "chatgpt.com", "oaistatic.com"
    )
    fun needsForeignExit(host: String?): Boolean {
        if (host.isNullOrEmpty()) return false
        return suffixes.any { host == it || host.endsWith(".$it") }
    }
}
