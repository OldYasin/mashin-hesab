# Keep Room database, entities, and DAOs
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @androidx.room.Entity class * { *; }
-dontwarn androidx.room.**

# Keep Service and Application classes referenced in AndroidManifest
-keep public class com.example.service.ScriptVpnService { *; }
-keep public class com.example.MainActivity { *; }

# Keep OkHttp / Okio
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
