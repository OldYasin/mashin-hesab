package com.example.network

import com.example.core.logging.LogCategory
import com.example.core.logging.TunnelLogger
import com.example.data.model.BypassSettings
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.Dns
import okhttp3.HttpUrl
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import java.io.FilterOutputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.DatagramSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import javax.net.SocketFactory
import kotlin.random.Random

object BypassOkHttpFactory {

    private const val BROWSER_USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    @Volatile
    var socketProtector: ((Socket) -> Boolean)? = null

    @Volatile
    var datagramProtector: ((DatagramSocket) -> Boolean)? = null

    private val sharedCookieJar = InMemoryCookieJar()
    private val loggedDnsBindings = ConcurrentHashMap.newKeySet<String>()
    private val badCleanIps = ConcurrentHashMap.newKeySet<String>().apply {
        addAll(listOf("8.8.8.8", "8.8.4.4", "1.1.1.1", "1.0.0.1"))
    }

    fun markBadCleanIp(ip: String) {
        val trimmed = ip.trim()
        if (trimmed.isNotBlank()) badCleanIps.add(trimmed)
    }

    fun createClient(
        settings: BypassSettings,
        overrideCleanIp: String = "",
        connectTimeoutMs: Long = 8_000L,
        readTimeoutMs: Long = 20_000L,
        disableCleanIp: Boolean = false
    ): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(connectTimeoutMs, TimeUnit.MILLISECONDS)
            .readTimeout(readTimeoutMs, TimeUnit.MILLISECONDS)
            .writeTimeout(15_000L, TimeUnit.MILLISECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .cookieJar(sharedCookieJar)
            .addInterceptor(browserHeaderInterceptor())

        if (settings.adaptiveKeepAlive) {
            builder.pingInterval(20, TimeUnit.SECONDS)
        }

        val customDns = createBypassDns(settings, if (disableCleanIp) "" else overrideCleanIp, disableCleanIp)
        builder.dns(customDns)

        val fragmentEnabled = settings.tlsFragmentation
        builder.socketFactory(BypassSocketFactory(fragmentEnabled))

        return builder.build()
    }

    private fun browserHeaderInterceptor(): Interceptor = Interceptor { chain ->
        val original = chain.request()
        val reqBuilder = original.newBuilder()
        if (original.header("User-Agent") == null) {
            reqBuilder.header("User-Agent", BROWSER_USER_AGENT)
        }
        if (original.header("Accept") == null) {
            reqBuilder.header("Accept", "application/json, text/plain, */*")
        }
        chain.proceed(reqBuilder.build())
    }

    private fun createBypassDns(
        settings: BypassSettings,
        overrideCleanIp: String,
        disableCleanIp: Boolean
    ): Dns {
        return object : Dns {
            override fun lookup(hostname: String): List<InetAddress> {
                if (disableCleanIp) {
                    return Dns.SYSTEM.lookup(hostname)
                }

                val cleanIp = when {
                    overrideCleanIp.isNotBlank() -> overrideCleanIp.trim()
                    !settings.cleanIpBinding -> ""
                    hostname.contains("google", ignoreCase = true) ||
                        hostname.contains("gstatic", ignoreCase = true) -> settings.activeCleanGoogleIp.trim()
                    else -> settings.activeCleanCfIp.trim()
                }

                if (cleanIp.isNotBlank() && cleanIp !in badCleanIps) {
                    val parsed = runCatching { InetAddress.getByName(cleanIp) }.getOrNull()
                    if (parsed != null) {
                        if (loggedDnsBindings.add("$hostname->$cleanIp")) {
                            TunnelLogger.i(
                                LogCategory.TLS_IP,
                                "DNS-BIND",
                                "نگاشت $hostname -> $cleanIp",
                                "CleanIP=$cleanIp, host=$hostname"
                            )
                        }
                        return listOf(parsed)
                    }
                }
                return Dns.SYSTEM.lookup(hostname)
            }
        }
    }

    private class InMemoryCookieJar : CookieJar {
        private val store = ConcurrentHashMap<String, List<Cookie>>()

        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            if (cookies.isEmpty()) return
            val existing = store[url.host].orEmpty().toMutableList()
            cookies.forEach { incoming ->
                existing.removeAll { it.name == incoming.name }
                existing.add(incoming)
            }
            store[url.host] = existing
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            val now = System.currentTimeMillis()
            return store[url.host].orEmpty().filter { it.expiresAt > now }
        }
    }

    private class BypassSocketFactory(
        private val fragmentFirstWrite: Boolean
    ) : SocketFactory() {

        override fun createSocket(): Socket {
            return ProtectedFragmentSocket(fragmentFirstWrite)
        }

        override fun createSocket(host: String?, port: Int): Socket {
            return ProtectedFragmentSocket(fragmentFirstWrite).apply {
                connect(InetSocketAddress(host, port))
            }
        }

        override fun createSocket(host: String?, port: Int, localHost: InetAddress?, localPort: Int): Socket {
            return ProtectedFragmentSocket(fragmentFirstWrite).apply {
                bind(InetSocketAddress(localHost, localPort))
                connect(InetSocketAddress(host, port))
            }
        }

        override fun createSocket(host: InetAddress?, port: Int): Socket {
            return ProtectedFragmentSocket(fragmentFirstWrite).apply {
                connect(InetSocketAddress(host, port))
            }
        }

        override fun createSocket(address: InetAddress?, port: Int, localAddress: InetAddress?, localPort: Int): Socket {
            return ProtectedFragmentSocket(fragmentFirstWrite).apply {
                bind(InetSocketAddress(localAddress, localPort))
                connect(InetSocketAddress(address, port))
            }
        }
    }

    private class ProtectedFragmentSocket(
        private val fragmentFirstWrite: Boolean
    ) : Socket() {

        @Volatile
        private var firstWriteDone = false

        override fun connect(endpoint: java.net.SocketAddress?, timeout: Int) {
            socketProtector?.invoke(this)
            super.connect(endpoint, timeout)
            runCatching { tcpNoDelay = true }
        }

        override fun getOutputStream(): OutputStream {
            val raw = super.getOutputStream()
            if (!fragmentFirstWrite) return raw
            return object : FilterOutputStream(raw) {
                override fun write(b: ByteArray, off: Int, len: Int) {
                    if (!firstWriteDone && len > 32) {
                        firstWriteDone = true
                        var cursor = off
                        val end = off + len
                        while (cursor < end) {
                            val chunk = Random.nextInt(14, 34).coerceAtMost(end - cursor)
                            out.write(b, cursor, chunk)
                            out.flush()
                            cursor += chunk
                            if (cursor < end) {
                                runCatching { Thread.sleep(2L) }
                            }
                        }
                    } else {
                        out.write(b, off, len)
                    }
                }
            }
        }
    }
}
