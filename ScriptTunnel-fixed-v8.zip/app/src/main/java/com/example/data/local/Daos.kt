package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ServerEndpointDao {
    @Query("SELECT * FROM server_endpoints ORDER BY isParallelActive DESC, lastLatencyMs ASC, createdAtMs DESC")
    fun observeAll(): Flow<List<ServerEndpointEntity>>

    @Query("SELECT * FROM server_endpoints WHERE isParallelActive = 1 ORDER BY lastLatencyMs ASC")
    suspend fun getParallelActiveList(): List<ServerEndpointEntity>

    @Query("SELECT * FROM server_endpoints")
    suspend fun getAllOnce(): List<ServerEndpointEntity>

    @Query("SELECT * FROM server_endpoints WHERE id = :id")
    suspend fun getById(id: Long): ServerEndpointEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(endpoint: ServerEndpointEntity): Long

    @Update
    suspend fun update(endpoint: ServerEndpointEntity)

    @Query("DELETE FROM server_endpoints WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE server_endpoints SET syncStatus = :status WHERE id = :id")
    suspend fun updateSyncStatus(id: Long, status: String)
}

@Dao
interface CleanIpDao {
    @Query("SELECT * FROM clean_ips ORDER BY provider ASC, latencyMs ASC")
    fun observeAll(): Flow<List<CleanIpEntity>>

    @Query("SELECT * FROM clean_ips WHERE provider = :provider ORDER BY latencyMs ASC")
    suspend fun getByProviderOnce(provider: String): List<CleanIpEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(ips: List<CleanIpEntity>)

    @Query("UPDATE clean_ips SET isSelected = (ip = :ip) WHERE provider = :provider")
    suspend fun selectIpForProvider(ip: String, provider: String)

    @Query("DELETE FROM clean_ips WHERE provider = :provider")
    suspend fun clearByProvider(provider: String)
}

@Dao
interface ConnectionReportDao {
    @Query("SELECT * FROM connection_reports ORDER BY startedAtMs DESC LIMIT 100")
    fun observeRecent(): Flow<List<ConnectionReportEntity>>

    @Query("SELECT * FROM connection_reports WHERE syncStatus != 'SYNCED'")
    suspend fun getUnsyncedOnce(): List<ConnectionReportEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(report: ConnectionReportEntity): Long

    @Query("UPDATE connection_reports SET syncStatus = :status WHERE id = :id")
    suspend fun updateSyncStatus(id: Long, status: String)

    @Query("DELETE FROM connection_reports")
    suspend fun clearAll()
}

@Dao
interface PendingSyncTaskDao {
    @Query("SELECT * FROM pending_sync_tasks ORDER BY createdAtMs ASC")
    fun observeAll(): Flow<List<PendingSyncTaskEntity>>

    @Query("SELECT COUNT(*) FROM pending_sync_tasks")
    fun observeCount(): Flow<Int>

    @Query("SELECT * FROM pending_sync_tasks ORDER BY createdAtMs ASC")
    suspend fun getAllOnce(): List<PendingSyncTaskEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(task: PendingSyncTaskEntity): Long

    @Update
    suspend fun update(task: PendingSyncTaskEntity)

    @Query("DELETE FROM pending_sync_tasks WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM pending_sync_tasks")
    suspend fun clearAll()
}
