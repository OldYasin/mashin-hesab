package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.EndpointType
import com.example.data.model.IpProvider
import com.example.data.model.SyncStatus

@Entity(tableName = "server_endpoints")
data class ServerEndpointEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val url: String,
    val secretKey: String,
    val type: String = EndpointType.GAS_SCRIPT.name,
    val customSniHost: String = "",
    val customCleanIp: String = "",
    val isParallelActive: Boolean = true,
    val weight: Int = 1,
    val lastLatencyMs: Int = -1,
    val successCount: Int = 0,
    val failureCount: Int = 0,
    val isHealthy: Boolean = false,
    val syncStatus: String = SyncStatus.PENDING_SYNC.name,
    val lastCheckedMs: Long = 0L,
    val createdAtMs: Long = System.currentTimeMillis()
) {
    val endpointType: EndpointType
        get() = runCatching { EndpointType.valueOf(type) }.getOrDefault(EndpointType.GAS_SCRIPT)

    val syncStatusEnum: SyncStatus
        get() = runCatching { SyncStatus.valueOf(syncStatus) }.getOrDefault(SyncStatus.PENDING_SYNC)

    val uptimePercent: Int
        get() {
            val total = successCount + failureCount
            return if (total == 0) 100 else ((successCount * 100f) / total).toInt().coerceIn(0, 100)
        }
}

@Entity(tableName = "clean_ips")
data class CleanIpEntity(
    @PrimaryKey val ip: String,
    val provider: String = IpProvider.GOOGLE.name,
    val latencyMs: Int,
    val jitterMs: Int = 0,
    val tlsVerified: Boolean = true,
    val isSelected: Boolean = false,
    val lastTestedMs: Long = System.currentTimeMillis()
) {
    val providerEnum: IpProvider
        get() = runCatching { IpProvider.valueOf(provider) }.getOrDefault(IpProvider.GOOGLE)
}

@Entity(tableName = "connection_reports")
data class ConnectionReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val startedAtMs: Long,
    val endedAtMs: Long,
    val protocolName: String,
    val endpointSummary: String,
    val avgLatencyMs: Int,
    val jitterMs: Int,
    val stabilityScore: Float,
    val packetLossPercent: Float,
    val downloadBytes: Long,
    val uploadBytes: Long,
    val compressionSavedBytes: Long,
    val syncStatus: String = SyncStatus.PENDING_SYNC.name,
    val notes: String = ""
) {
    val syncStatusEnum: SyncStatus
        get() = runCatching { SyncStatus.valueOf(syncStatus) }.getOrDefault(SyncStatus.PENDING_SYNC)
}

@Entity(tableName = "pending_sync_tasks")
data class PendingSyncTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val taskType: String, // "VERIFY_ENDPOINT", "SYNC_REPORT", "REPROBE_CLEAN_IP"
    val targetId: String,
    val payloadJson: String,
    val retryCount: Int = 0,
    val createdAtMs: Long = System.currentTimeMillis()
)
