package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.CleanIpEntity
import com.example.data.local.ConnectionReportEntity
import com.example.data.local.PendingSyncTaskEntity
import com.example.data.local.ServerEndpointEntity
import com.example.data.model.IpProvider
import com.example.data.model.SyncStatus
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject

class TunnelRepository(private val db: AppDatabase) {

    private val serverDao = db.serverEndpointDao()
    private val cleanIpDao = db.cleanIpDao()
    private val reportDao = db.connectionReportDao()
    private val syncTaskDao = db.pendingSyncTaskDao()

    val serversFlow: Flow<List<ServerEndpointEntity>> = serverDao.observeAll()
    val cleanIpsFlow: Flow<List<CleanIpEntity>> = cleanIpDao.observeAll()
    val reportsFlow: Flow<List<ConnectionReportEntity>> = reportDao.observeRecent()
    val pendingSyncTasksFlow: Flow<List<PendingSyncTaskEntity>> = syncTaskDao.observeAll()
    val pendingSyncCountFlow: Flow<Int> = syncTaskDao.observeCount()

    suspend fun getParallelActiveServers(): List<ServerEndpointEntity> = serverDao.getParallelActiveList()

    suspend fun getAllServersOnce(): List<ServerEndpointEntity> = serverDao.getAllOnce()

    suspend fun addOrUpdateServer(endpoint: ServerEndpointEntity, isOnline: Boolean): Long {
        val status = if (isOnline) SyncStatus.PENDING_SYNC else SyncStatus.OFFLINE_DRAFT
        val toSave = endpoint.copy(syncStatus = status.name)
        val id = serverDao.insert(toSave)
        val actualId = if (endpoint.id > 0L) endpoint.id else id
        enqueueSyncTask(
            taskType = "VERIFY_ENDPOINT",
            targetId = actualId.toString(),
            payload = JSONObject().apply {
                put("url", toSave.url)
                put("type", toSave.type)
            }.toString()
        )
        return actualId
    }

    suspend fun updateServerHealth(
        id: Long,
        latencyMs: Int,
        isHealthy: Boolean,
        syncStatus: SyncStatus = SyncStatus.SYNCED
    ) {
        val existing = serverDao.getById(id) ?: return
        val updated = existing.copy(
            lastLatencyMs = latencyMs,
            isHealthy = isHealthy,
            successCount = if (isHealthy) existing.successCount + 1 else existing.successCount,
            failureCount = if (!isHealthy) existing.failureCount + 1 else existing.failureCount,
            lastCheckedMs = System.currentTimeMillis(),
            syncStatus = syncStatus.name
        )
        serverDao.update(updated)
    }

    suspend fun toggleServerParallelActive(endpoint: ServerEndpointEntity) {
        serverDao.update(endpoint.copy(isParallelActive = !endpoint.isParallelActive))
    }

    suspend fun deleteServer(id: Long) {
        serverDao.deleteById(id)
    }

    suspend fun saveCleanIps(provider: IpProvider, ips: List<CleanIpEntity>) {
        cleanIpDao.clearByProvider(provider.name)
        cleanIpDao.upsertAll(ips)
    }

    suspend fun selectCleanIp(ip: String, provider: IpProvider) {
        cleanIpDao.selectIpForProvider(ip, provider.name)
    }

    suspend fun recordConnectionReport(report: ConnectionReportEntity, isOnline: Boolean): Long {
        val status = if (isOnline) SyncStatus.PENDING_SYNC else SyncStatus.OFFLINE_DRAFT
        val savedId = reportDao.insert(report.copy(syncStatus = status.name))
        enqueueSyncTask(
            taskType = "SYNC_REPORT",
            targetId = savedId.toString(),
            payload = JSONObject().apply {
                put("stability", report.stabilityScore)
                put("avgLatency", report.avgLatencyMs)
                put("downloadBytes", report.downloadBytes)
                put("uploadBytes", report.uploadBytes)
            }.toString()
        )
        return savedId
    }

    suspend fun markReportSynced(id: Long) {
        reportDao.updateSyncStatus(id, SyncStatus.SYNCED.name)
    }

    suspend fun markServerSynced(id: Long) {
        serverDao.updateSyncStatus(id, SyncStatus.SYNCED.name)
    }

    suspend fun clearReports() {
        reportDao.clearAll()
    }

    suspend fun enqueueSyncTask(taskType: String, targetId: String, payload: String) {
        syncTaskDao.insert(
            PendingSyncTaskEntity(
                taskType = taskType,
                targetId = targetId,
                payloadJson = payload
            )
        )
    }

    suspend fun getPendingSyncTasksOnce(): List<PendingSyncTaskEntity> = syncTaskDao.getAllOnce()

    suspend fun incrementSyncRetry(task: PendingSyncTaskEntity) {
        syncTaskDao.update(task.copy(retryCount = task.retryCount + 1))
    }

    suspend fun completeSyncTask(taskId: Long) {
        syncTaskDao.deleteById(taskId)
    }
}
