package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.logging.LogCategory
import com.example.core.logging.LogLevel
import com.example.core.logging.TunnelLogEntry
import com.example.core.logging.TunnelLogger
import com.example.ui.components.AppIcons
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.RoseError
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LogsPanel(
    logs: List<TunnelLogEntry>,
    isPaused: Boolean,
    onTogglePause: () -> Unit,
    onClearLogs: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var searchQuery by remember { mutableStateOf("") }
    var selectedLevel by remember { mutableStateOf<LogLevel?>(null) }
    var expandedLogIds by remember { mutableStateOf<Set<Long>>(emptySet()) }

    val errorCount = remember(logs) { logs.count { it.level == LogLevel.ERROR } }
    val warnCount = remember(logs) { logs.count { it.level == LogLevel.WARN } }

    val levelLogs = remember(logs, selectedLevel) {
        if (selectedLevel == null) logs else logs.filter { it.level == selectedLevel }
    }
    // Most frequent tags of this section: tap one to filter by it (quick grouping).
    val tagCounts = remember(levelLogs) {
        levelLogs.groupingBy { it.tag }.eachCount().entries.sortedByDescending { it.value }.take(8)
    }
    val filteredLogs = remember(levelLogs, searchQuery) {
        val q = searchQuery.trim()
        if (q.isEmpty()) levelLogs else levelLogs.filter { entry ->
            entry.message.contains(q, ignoreCase = true) ||
                entry.tag.contains(q, ignoreCase = true) ||
                (entry.details?.contains(q, ignoreCase = true) == true)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Header Summary & Actions
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    LogStatBadge("نمایش: ${filteredLogs.size} از ${logs.size}", CyanSecondary)
                    if (errorCount > 0) LogStatBadge("خطا: $errorCount", RoseError)
                    if (warnCount > 0) LogStatBadge("هشدار: $warnCount", AmberWarning)
                }

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("جستجو در پیام، کد خطا (403)، IP یا URL...") },
                    leadingIcon = { Icon(AppIcons.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(AppIcons.Close, contentDescription = "پاک کردن جستجو", modifier = Modifier.size(18.dp))
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("logs_search_field")
                )

                // Level Filter Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedLevel == null,
                        onClick = { selectedLevel = null },
                        label = { Text("همه سطوح") }
                    )
                    LogLevel.entries.forEach { lvl ->
                        FilterChip(
                            selected = selectedLevel == lvl,
                            onClick = { selectedLevel = if (selectedLevel == lvl) null else lvl },
                            label = { Text(lvl.titleFa) }
                        )
                    }
                }

                if (tagCounts.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        tagCounts.forEach { (tag, n) ->
                            FilterChip(
                                selected = searchQuery == tag,
                                onClick = { searchQuery = if (searchQuery == tag) "" else tag },
                                label = { Text("$tag ×$n", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }

                // Action Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val exported = TunnelLogger.exportAsText(filteredLogs)
                            clipboard.setText(AnnotatedString(exported))
                            onShowMessage("${filteredLogs.size} خط لاگ در کلیپ‌بورد کپی شد")
                        },
                        enabled = filteredLogs.isNotEmpty(),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(AppIcons.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("کپی لاگ")
                    }
                    OutlinedButton(
                        onClick = {
                            val exported = TunnelLogger.exportAsText(filteredLogs)
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "ScriptTunnel Logs")
                                putExtra(Intent.EXTRA_TEXT, exported)
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "ارسال یا ذخیره لاگ‌ها"))
                        },
                        enabled = filteredLogs.isNotEmpty(),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(AppIcons.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("خروجی")
                    }
                    OutlinedButton(
                        onClick = onTogglePause
                    ) {
                        Text(if (isPaused) "ادامه" else "توقف")
                    }
                    OutlinedButton(
                        onClick = onClearLogs,
                        enabled = logs.isNotEmpty(),
                        modifier = Modifier.testTag("clear_logs_button")
                    ) {
                        Icon(AppIcons.Delete, contentDescription = "پاک کردن لاگ‌ها", tint = RoseError, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        if (filteredLogs.isEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(AppIcons.Terminal, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(32.dp))
                    Text(
                        text = if (logs.isEmpty()) "هنوز لاگی ثبت نشده است" else "هیچ لاگی با فیلتر فعلی مطابقت ندارد",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        text = "با ذخیره یا تست سرور، اسکن آی‌پی یا برقراری اتصال، تمام جزئیات شبکه و خطاها (مانند 403 و SSL) این‌جا نمایش داده می‌شود.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredLogs, key = { it.id }) { entry ->
                    val isExpanded = entry.id in expandedLogIds
                    LogEntryCard(
                        entry = entry,
                        isExpanded = isExpanded,
                        onToggleExpand = {
                            expandedLogIds = if (isExpanded) expandedLogIds - entry.id else expandedLogIds + entry.id
                        },
                        onCopySingle = {
                            val text = TunnelLogger.exportAsText(listOf(entry))
                            clipboard.setText(AnnotatedString(text))
                            onShowMessage("لاگ کپی شد")
                        }
                    )
                }
            }
        }
    }
}

@Composable
internal fun LogStatBadge(text: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = color.copy(alpha = 0.15f)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
        )
    }
}

@Composable
internal fun LogEntryCard(
    entry: TunnelLogEntry,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onCopySingle: () -> Unit
) {
    val levelColor = when (entry.level) {
        LogLevel.ERROR -> RoseError
        LogLevel.WARN -> AmberWarning
        LogLevel.INFO -> EmeraldPrimary
        LogLevel.DEBUG -> CyanSecondary
    }
    val hasDetails = !entry.details.isNullOrBlank()

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (hasDetails) Modifier.clickable { onToggleExpand() } else Modifier),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = 1.dp,
            color = if (entry.level == LogLevel.ERROR) RoseError.copy(alpha = 0.45f) else MaterialTheme.colorScheme.outline
        )
    ) {
        Column(modifier = Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = levelColor.copy(alpha = 0.16f)
                    ) {
                        Text(
                            text = entry.level.shortLabel,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold
                            ),
                            color = levelColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(
                                text = "${entry.category.badge}/${entry.tag}",
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Text(
                        text = formatLogTime(entry.timestampMs),
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text(
                text = entry.message,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = if (isExpanded) Int.MAX_VALUE else 3,
                overflow = TextOverflow.Ellipsis
            )

            if (hasDetails) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isExpanded) "بستن جزئیات فنی" else "مشاهده جزئیات فنی",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyanSecondary
                    )
                    Icon(
                        imageVector = if (isExpanded) AppIcons.ExpandLess else AppIcons.ExpandMore,
                        contentDescription = null,
                        tint = CyanSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                AnimatedVisibility(visible = isExpanded) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                IconButton(
                                    onClick = onCopySingle,
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        AppIcons.ContentCopy,
                                        contentDescription = "کپی جزئیات",
                                        modifier = Modifier.size(14.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                Text(
                                    text = entry.details.orEmpty(),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = JetBrainsMonoFontFamily,
                                        lineHeight = 16.sp
                                    ),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatLogTime(ms: Long): String {
    return SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(ms))
}
