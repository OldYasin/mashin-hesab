package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.sp
import com.example.core.logging.LogCategory
import com.example.core.logging.LogLevel
import com.example.core.logging.TunnelLogEntry
import com.example.core.logging.TunnelLogger
import com.example.core.logging.TunnelStats
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.ConnectionReportEntity
import com.example.ui.components.AppIcons
import com.example.ui.components.formatBytesHuman
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.RoseError
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class ReportSection(val label: String) {
    SESSIONS("جلسه‌ها"),
    PROBLEMS("مشکل‌ها"),
    CONNECTIONS("اتصال‌ها"),
    NETWORK("DNS و VPN"),
    SERVERS("سرور و IP"),
    SYSTEM("سیستم"),
    DIAGNOSIS("تشخیص"),
    ALL("همه لاگ‌ها");

    fun matches(e: TunnelLogEntry): Boolean = when (this) {
        PROBLEMS -> e.level == LogLevel.WARN || e.level == LogLevel.ERROR
        CONNECTIONS -> e.category == LogCategory.CF_WS || e.tag == "PULSE"
        NETWORK -> e.category == LogCategory.DNS_DOH || e.category == LogCategory.VPN
        SERVERS -> e.category == LogCategory.GAS || e.category == LogCategory.TLS_IP
        SYSTEM -> (e.category == LogCategory.SYSTEM && e.tag != "PULSE") || e.category == LogCategory.SYNC
        ALL -> true
        else -> false
    }
}

@Composable
fun ReportsScreen(
    reports: List<ConnectionReportEntity>,
    logs: List<TunnelLogEntry>,
    isLogsPaused: Boolean,
    onTogglePause: () -> Unit,
    onClearLogs: () -> Unit,
    onClearReports: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var section by rememberSaveable { mutableStateOf(ReportSection.SESSIONS) }
    val problemCount = remember(logs) { logs.count { it.level == LogLevel.WARN || it.level == LogLevel.ERROR } }
    val hasErrors = remember(logs) { logs.any { it.level == LogLevel.ERROR } }

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ReportSection.entries.forEach { sec ->
                val label = if (sec == ReportSection.PROBLEMS && problemCount > 0) "${sec.label} ($problemCount)" else sec.label
                FilterChip(
                    selected = section == sec,
                    onClick = { section = sec },
                    label = { Text(label) },
                    modifier = Modifier.testTag("report_section_${sec.name.lowercase()}"),
                    colors = if (sec == ReportSection.PROBLEMS && problemCount > 0) {
                        androidx.compose.material3.FilterChipDefaults.filterChipColors(
                            labelColor = if (hasErrors) RoseError else AmberWarning
                        )
                    } else androidx.compose.material3.FilterChipDefaults.filterChipColors()
                )
            }
        }

        when (section) {
            ReportSection.SESSIONS -> SessionsPanel(reports, onClearReports, Modifier.weight(1f))
            ReportSection.DIAGNOSIS -> DiagnosisPanel(logs.size, onShowMessage, Modifier.weight(1f))
            else -> {
                val sectionLogs = remember(logs, section) { logs.filter { section.matches(it) } }
                LogsPanel(
                    logs = sectionLogs,
                    isPaused = isLogsPaused,
                    onTogglePause = onTogglePause,
                    onClearLogs = onClearLogs,
                    onShowMessage = onShowMessage,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun DiagnosisPanel(logCount: Int, onShowMessage: (String) -> Unit, modifier: Modifier = Modifier) {
    val clipboard = LocalClipboardManager.current
    var refreshKey by remember { mutableStateOf(0) }
    val report = remember(logCount, refreshKey) { TunnelStats.report() }
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { refreshKey++ }) { Text("بروزرسانی") }
            OutlinedButton(onClick = {
                clipboard.setText(AnnotatedString(TunnelLogger.exportAsText()))
                onShowMessage("گزارش کامل + لاگ‌ها کپی شد")
            }) {
                Icon(AppIcons.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("کپی گزارش کامل")
            }
        }
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            androidx.compose.runtime.CompositionLocalProvider(
                androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Ltr
            ) {
                androidx.compose.foundation.text.selection.SelectionContainer {
                    Text(
                        text = report,
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily, lineHeight = 16.sp),
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SessionsPanel(
    reports: List<ConnectionReportEntity>,
    onClearReports: () -> Unit,
    modifier: Modifier = Modifier
) {
    val avgStability = if (reports.isEmpty()) 100f else reports.map { it.stabilityScore }.average().toFloat()
    val totalTraffic = reports.sumOf { it.downloadBytes + it.uploadBytes }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Summary KPI Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ReportKpiCard(
                    title = "میانگین پایداری",
                    value = "${avgStability.toInt()}%",
                    accent = EmeraldPrimary,
                    modifier = Modifier.weight(1f)
                )
                ReportKpiCard(
                    title = "تعداد جلسه",
                    value = "${reports.size}",
                    accent = CyanSecondary,
                    modifier = Modifier.weight(1f)
                )
                ReportKpiCard(
                    title = "کل ترافیک",
                    value = formatBytesHuman(totalTraffic),
                    accent = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Graphical Session Stability History
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "نمودار پایداری جلسات اخیر",
                        style = MaterialTheme.typography.titleMedium
                    )
                    if (reports.isEmpty()) {
                        Text(
                            text = "هنوز گزارشی ثبت نشده است؛ پس از قطع هر اتصال، گزارش دقیق پایداری در دیتابیس محلی ذخیره می‌شود.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        val recent = reports.take(12).reversed()
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(110.dp)
                        ) {
                            val barCount = recent.size.coerceAtLeast(1)
                            val gap = 8.dp.toPx()
                            val barWidth = ((size.width - gap * (barCount - 1)) / barCount).coerceAtLeast(6f)
                            recent.forEachIndexed { idx, rep ->
                                val frac = (rep.stabilityScore / 100f).coerceIn(0.08f, 1f)
                                val barH = size.height * frac
                                val x = idx * (barWidth + gap)
                                val color = when {
                                    rep.stabilityScore >= 80f -> EmeraldPrimary
                                    rep.stabilityScore >= 55f -> AmberWarning
                                    else -> RoseError
                                }
                                drawRoundRect(
                                    color = color,
                                    topLeft = Offset(x, size.height - barH),
                                    size = Size(barWidth, barH),
                                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                                )
                            }
                        }
                    }
                }
            }
        }

        // Session Logs Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(AppIcons.Assessment, contentDescription = null, tint = CyanSecondary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "گزارش دقیق جلسات (${reports.size})",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
                if (reports.isNotEmpty()) {
                    IconButton(onClick = onClearReports) {
                        Icon(AppIcons.Delete, contentDescription = "پاک کردن تاریخچه گزارش‌ها", tint = RoseError)
                    }
                }
            }
        }

        items(reports, key = { it.id }) { report ->
            val scoreColor = when {
                report.stabilityScore >= 80f -> EmeraldPrimary
                report.stabilityScore >= 55f -> AmberWarning
                else -> RoseError
            }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${report.protocolName} • ${report.endpointSummary}",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f)
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = scoreColor.copy(alpha = 0.16f)
                        ) {
                            Text(
                                text = "پایداری ${report.stabilityScore.toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                color = scoreColor,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Text(
                        text = "${formatTimestamp(report.startedAtMs)} • ${report.notes}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "پینگ: ${report.avgLatencyMs}ms • نوسان: ${report.jitterMs}ms",
                            style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "↓ ${formatBytesHuman(report.downloadBytes)}  ↑ ${formatBytesHuman(report.uploadBytes)}",
                            style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = CyanSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportKpiCard(
    title: String,
    value: String,
    accent: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }
    }
}

private fun formatTimestamp(ms: Long): String {
    return SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(ms))
}
