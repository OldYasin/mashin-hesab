package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.data.model.BypassSettings
import com.example.data.model.CompressionLevel
import com.example.data.model.TunnelConnectionState
import com.example.data.model.TunnelProtocol
import com.example.data.model.TunnelTelemetry
import com.example.ui.components.AppIcons
import com.example.ui.components.PowerConnectOrb
import com.example.ui.components.RealTimeSpeedChart
import com.example.ui.components.StabilityArcGauge
import com.example.ui.components.formatBytesHuman
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import kotlinx.coroutines.delay

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    telemetry: TunnelTelemetry,
    settings: BypassSettings,
    onPowerClick: () -> Unit,
    onProtocolSelected: (TunnelProtocol) -> Unit,
    onToggleTlsFrag: (Boolean) -> Unit,
    onToggleCleanIp: (Boolean) -> Unit,
    onToggleKeepAlive: (Boolean) -> Unit,
    onToggleDoh: (Boolean) -> Unit,
    onToggleVpnMode: (Boolean) -> Unit,
    onProbeTunnel: () -> Unit,
    onNavigateToServers: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboard = LocalClipboardManager.current
    var showAdvancedBypass by remember { mutableStateOf(false) }

    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(telemetry.connectionState, telemetry.connectedSinceMs) {
        if (telemetry.connectionState == TunnelConnectionState.CONNECTED && telemetry.connectedSinceMs > 0L) {
            while (true) {
                nowMs = System.currentTimeMillis()
                delay(1000L)
            }
        }
    }

    val elapsedSec = if (telemetry.connectionState == TunnelConnectionState.CONNECTED && telemetry.connectedSinceMs > 0L) {
        ((nowMs - telemetry.connectedSinceMs) / 1000L).coerceAtLeast(0L)
    } else 0L

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Connection Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.extraLarge,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp, horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    PowerConnectOrb(
                        state = telemetry.connectionState,
                        onClick = onPowerClick
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = telemetry.connectionState.titleFa,
                        style = MaterialTheme.typography.titleMedium,
                        color = if (telemetry.connectionState == TunnelConnectionState.CONNECTED) EmeraldPrimary
                        else MaterialTheme.colorScheme.onSurface
                    )

                    if (elapsedSec > 0L) {
                        Spacer(modifier = Modifier.height(4.dp))
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(
                                text = formatTimer(elapsedSec),
                                style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Active Pool + SOCKS5 Local Pill Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable(onClick = onNavigateToServers),
                            shape = MaterialTheme.shapes.medium,
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = AppIcons.Hub,
                                    contentDescription = null,
                                    tint = EmeraldPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "استخر موازی (${telemetry.activeEndpointCount})",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = telemetry.activeEndpointLabel,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1
                                    )
                                }
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = MaterialTheme.shapes.medium,
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Row(
                                modifier = Modifier.padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "پروکسی SOCKS5",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        Text(
                                            text = telemetry.activeSocksAddress,
                                            style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                            color = CyanSecondary
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = {
                                        clipboard.setText(AnnotatedString(telemetry.activeSocksAddress))
                                        onShowMessage("آدرس SOCKS5 کپی شد")
                                    }
                                ) {
                                    Icon(
                                        imageVector = AppIcons.ContentCopy,
                                        contentDescription = "کپی آدرس ساکس۵",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Protocol Selector
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "پروتکل ارتباطی و مسیر انتقال",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TunnelProtocol.entries.forEach { proto ->
                        val selected = settings.protocol == proto
                        FilterChip(
                            selected = selected,
                            onClick = { onProtocolSelected(proto) },
                            label = {
                                Text(
                                    text = proto.titleFa,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.testTag("protocol_chip_${proto.name.lowercase()}")
                        )
                    }
                }
                Text(
                    text = settings.protocol.subtitleFa,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Real-Time Graphical Speed Chart
        item {
            RealTimeSpeedChart(
                samples = telemetry.speedHistory,
                currentDownKbps = telemetry.downloadKbps,
                currentUpKbps = telemetry.uploadKbps
            )
        }

        // Stability Gauge + Compression Stats Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "وضعیت پایداری",
                        style = MaterialTheme.typography.titleMedium
                    )

                    StabilityArcGauge(
                        score = telemetry.stabilityScore,
                        latencyMs = telemetry.currentLatencyMs,
                        jitterMs = telemetry.jitterMs,
                        lossPercent = telemetry.packetLossPercent
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TrafficStatMini("دریافت کل", formatBytesHuman(telemetry.totalDownloadBytes))
                        TrafficStatMini("ارسال کل", formatBytesHuman(telemetry.totalUploadBytes))
                        TrafficStatMini(
                            "آی‌پی تمیز گوگل",
                            settings.activeCleanGoogleIp.ifBlank { "خودکار" }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onProbeTunnel,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("live_probe_button")
                        ) {
                            Icon(AppIcons.Speed, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تست زنده تونل و DoH")
                        }
                        if (telemetry.connectionState == TunnelConnectionState.CONNECTED) {
                            Button(
                                onClick = onPowerClick,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                modifier = Modifier.weight(0.7f)
                            ) {
                                Text("قطع")
                            }
                        }
                    }
                }
            }
        }

        // Smart Censorship Bypass & Compression Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showAdvancedBypass = !showAdvancedBypass },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = AppIcons.ShieldFilled,
                                contentDescription = null,
                                tint = CyanSecondary
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "تنظیمات دور زدن فیلترینگ",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = "TLS Fragment • آی‌پی تمیز • Keep-Alive • DoH",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Icon(
                            imageVector = if (showAdvancedBypass) AppIcons.ExpandLess else AppIcons.ExpandMore,
                            contentDescription = "باز و بسته کردن تنظیمات دور زدن فیلترینگ"
                        )
                    }

                    AnimatedVisibility(visible = showAdvancedBypass) {
                        Column(
                            modifier = Modifier.padding(top = 14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))

                            BypassToggleRow(
                                icon = AppIcons.VpnKey,
                                title = "حالت VPN سراسری دستگاه",
                                subtitle = "در صورت خاموش بودن، فقط سرور محلی SOCKS5 اجرا می‌شود",
                                checked = settings.vpnModeEnabled,
                                onCheckedChange = onToggleVpnMode
                            )
                            BypassToggleRow(
                                icon = AppIcons.Tune,
                                title = "تکه‌تکه‌سازی بسته‌های TLS (Fragment)",
                                subtitle = "عبور از فیلترینگ SNI با ارسال خردشده بسته‌های اولیه",
                                checked = settings.tlsFragmentation,
                                onCheckedChange = onToggleTlsFrag
                            )
                            BypassToggleRow(
                                icon = AppIcons.Dns,
                                title = "اتصال مستقیم به آی‌پی تمیز",
                                subtitle = "جایگزینی خودکار DNS فیلترشده با سریع‌ترین آی‌پی گوگل/کلودفلر",
                                checked = settings.cleanIpBinding,
                                onCheckedChange = onToggleCleanIp
                            )
                            BypassToggleRow(
                                icon = AppIcons.Bolt,
                                title = "نگهدارنده پایدار اتصال (Keep-Alive)",
                                subtitle = "پایش دوره‌ای و سوئیچ خودکار به اسکریپت موازی سالم",
                                checked = settings.adaptiveKeepAlive,
                                onCheckedChange = onToggleKeepAlive
                            )
                            BypassToggleRow(
                                icon = AppIcons.Dns,
                                title = "DNS رمزنگاری‌شده (DoH)",
                                subtitle = "جلوگیری از مسمومیت DNS در تونل",
                                checked = settings.dohEnabled,
                                onCheckedChange = onToggleDoh
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TrafficStatMini(label: String, value: String) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(2.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(
                text = value,
                style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun BypassToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.bodyLarge)
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

private fun formatTimer(totalSeconds: Long): String {
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return String.format("%02d:%02d:%02d", h, m, s)
}
