package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Obsidian Cyber-Minimalist Palette
val ObsidianBg = Color(0xFF090D16)
val ObsidianSurface = Color(0xFF111827)
val ObsidianSurfaceVariant = Color(0xFF1A2334)
val ObsidianBorder = Color(0xFF24324B)

val EmeraldPrimary = Color(0xFF00E5A3)
val EmeraldOnPrimary = Color(0xFF00291C)
val EmeraldContainer = Color(0xFF073B2E)

val CyanSecondary = Color(0xFF38BDF8)
val CyanOnSecondary = Color(0xFF002436)
val CyanContainer = Color(0xFF0C354D)

val VioletTertiary = Color(0xFFA78BFA)
val AmberWarning = Color(0xFFFBBF24)
val RoseError = Color(0xFFFB7185)

val DarkTextPrimary = Color(0xFFF1F5F9)
val DarkTextSecondary = Color(0xFF94A3B8)

// Clean Light Palette
val LightBg = Color(0xFFF4F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE9EFF8)
val LightBorder = Color(0xFFD2DCEB)

val LightEmeraldPrimary = Color(0xFF00875A)
val LightEmeraldContainer = Color(0xFFD2F7E8)
val LightCyanSecondary = Color(0xFF0284C7)
val LightCyanContainer = Color(0xFFD9F0FC)

val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
