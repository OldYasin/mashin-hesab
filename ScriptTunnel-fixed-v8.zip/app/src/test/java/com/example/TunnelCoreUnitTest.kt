package com.example

import com.example.core.crypto.TunnelCrypto
import com.example.core.scripts.ScriptTemplates
import com.example.data.local.ServerEndpointEntity
import com.example.data.model.CompressionLevel
import com.example.data.model.EndpointType
import com.example.data.model.IpProvider
import com.example.network.CleanIpScanner
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class TunnelCoreUnitTest {

    @Test
    fun gzipCompressionAndDecompressionRoundtrip() {
        val sample = ("ScriptTunnel compressed payload for weak networks! ".repeat(20)).toByteArray()
        val compressed = TunnelCrypto.compress(sample, CompressionLevel.ULTRA_GZIP)
        assertTrue(compressed.compressedSize < compressed.rawSize)
        val restored = TunnelCrypto.decompressGzip(compressed.bytes)
        assertArrayEquals(sample, restored)
    }

    @Test
    fun streamHmacEncryptDecryptAndTamperDetection() {
        val secret = TunnelCrypto.generateStrongSecret()
        val plain = "{\"url\":\"https://example.com\",\"method\":\"GET\"}".toByteArray()
        val cipher = TunnelCrypto.encryptStreamHmac(plain, secret)
        val decrypted = TunnelCrypto.decryptStreamHmac(cipher, secret)
        assertArrayEquals(plain, decrypted)

        // Tamper one byte -> HMAC must reject
        val tampered = cipher.copyOf()
        tampered[tampered.size - 1] = (tampered.last().toInt() xor 0xFF).toByte()
        assertNull(TunnelCrypto.decryptStreamHmac(tampered, secret))
    }

    @Test
    fun aesGcmEncryptDecryptRoundtrip() {
        val secret = "test_secret_256_bit"
        val plain = "Cloudflare Worker WebSocket Payload".toByteArray()
        val encrypted = TunnelCrypto.encryptAesGcm(plain, secret)
        val decrypted = TunnelCrypto.decryptAesGcm(encrypted, secret)
        assertArrayEquals(plain, decrypted)
    }

    @Test
    fun scriptTemplatesIncludeSecretAndShareUriRoundtrips() {
        val secret = "st_custom_token_12345"
        val gas = ScriptTemplates.generateGoogleAppsScript(secret)
        val cf = ScriptTemplates.generateCloudflareWorkerScript(secret)
        assertTrue(gas.contains(secret))
        assertTrue(cf.contains(secret))

        val entity = ServerEndpointEntity(
            name = "اسکریپت ۱",
            url = "https://script.google.com/macros/s/abc/exec",
            secretKey = secret,
            type = EndpointType.GAS_SCRIPT.name,
            weight = 3
        )
        val uri = ScriptTemplates.encodeShareUri(entity)
        assertTrue(uri.startsWith("scriptvpn://"))
        val decoded = ScriptTemplates.decodeShareUri(uri)
        assertNotNull(decoded)
        assertEquals(entity.name, decoded?.name)
        assertEquals(entity.url, decoded?.url)
        assertEquals(entity.secretKey, decoded?.secretKey)
        assertEquals(3, decoded?.weight)
    }

    @Test
    fun cleanIpCandidatesGeneratedForGoogleAndCloudflare() {
        val googleIps = CleanIpScanner.generateCandidates(IpProvider.GOOGLE, sampleCount = 15)
        val cfIps = CleanIpScanner.generateCandidates(IpProvider.CLOUDFLARE, sampleCount = 15)
        assertEquals(15, googleIps.size)
        assertEquals(15, cfIps.size)
        assertTrue(googleIps.all { it.count { c -> c == '.' } == 3 })
        assertTrue(cfIps.all { it.count { c -> c == '.' } == 3 })
    }
}
