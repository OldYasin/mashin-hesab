package com.example.core.crypto

import android.util.Base64
import com.example.data.model.CompressionLevel
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.zip.Deflater
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import java.util.zip.Inflater
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

data class CompressedPayload(
    val bytes: ByteArray,
    val rawSize: Int,
    val compressedSize: Int
)

object TunnelCrypto {

    private val secureRandom = SecureRandom()

    fun generateStrongSecret(lengthChars: Int = 32): String {
        val alphabet = "abcdefghjkmnpqrstuvwxyz23456789ABCDEFGHJKLMNPQRSTUVWXYZ"
        return buildString(lengthChars) {
            append("st_")
            repeat(lengthChars - 3) {
                append(alphabet[secureRandom.nextInt(alphabet.length)])
            }
        }
    }

    fun randomPaddingString(minLen: Int = 8, maxLen: Int = 40): String {
        val len = minLen + secureRandom.nextInt((maxLen - minLen).coerceAtLeast(1))
        val bytes = ByteArray(len)
        secureRandom.nextBytes(bytes)
        return Base64.encodeToString(bytes, Base64.NO_WRAP or Base64.URL_SAFE)
    }

    fun compress(data: ByteArray, level: CompressionLevel): CompressedPayload {
        if (level == CompressionLevel.OFF || data.size < 32) {
            return CompressedPayload(data, data.size, data.size)
        }
        return when (level) {
            CompressionLevel.ULTRA_GZIP -> {
                val bos = ByteArrayOutputStream()
                GZIPOutputStream(bos).use { it.write(data) }
                val out = bos.toByteArray()
                if (out.size < data.size) CompressedPayload(out, data.size, out.size)
                else CompressedPayload(data, data.size, data.size)
            }
            CompressionLevel.FAST_DEFLATE -> {
                // same gzip container as ULTRA_GZIP (the Apps Script side only unwraps gzip), just the cheapest deflate level
                val bos = ByteArrayOutputStream()
                object : GZIPOutputStream(bos) {
                    init { def.setLevel(Deflater.BEST_SPEED) }
                }.use { it.write(data) }
                val out = bos.toByteArray()
                if (out.size < data.size) CompressedPayload(out, data.size, out.size)
                else CompressedPayload(data, data.size, data.size)
            }
            CompressionLevel.OFF -> CompressedPayload(data, data.size, data.size)
        }
    }

    fun decompressGzip(data: ByteArray): ByteArray {
        return GZIPInputStream(ByteArrayInputStream(data)).use { it.readBytes() }
    }

    fun decompressDeflate(data: ByteArray): ByteArray {
        val inflater = Inflater()
        inflater.setInput(data)
        val bos = ByteArrayOutputStream()
        val buf = ByteArray(1024)
        while (!inflater.finished()) {
            val count = inflater.inflate(buf)
            if (count == 0 && inflater.needsInput()) break
            bos.write(buf, 0, count)
        }
        inflater.end()
        return bos.toByteArray()
    }

    fun sha256(bytes: ByteArray): ByteArray {
        return MessageDigest.getInstance("SHA-256").digest(bytes)
    }

    fun hmacSha256(data: ByteArray, key: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return mac.doFinal(data)
    }

    /**
     * Cross-compatible stream encryption (SHA-256 CTR + HMAC-SHA256) matching Google Apps Script Utilities API.
     */
    fun encryptStreamHmac(plain: ByteArray, secret: String): ByteArray {
        val key = sha256(secret.toByteArray(Charsets.UTF_8))
        val nonce = ByteArray(16).also { secureRandom.nextBytes(it) }
        val cipher = xorKeyStream(plain, key, nonce)
        val macInput = ByteArray(nonce.size + cipher.size)
        System.arraycopy(nonce, 0, macInput, 0, nonce.size)
        System.arraycopy(cipher, 0, macInput, nonce.size, cipher.size)
        val tag = hmacSha256(macInput, key)
        // Layout: [16-byte nonce][32-byte hmac][ciphertext]
        return ByteArray(16 + 32 + cipher.size).apply {
            System.arraycopy(nonce, 0, this, 0, 16)
            System.arraycopy(tag, 0, this, 16, 32)
            System.arraycopy(cipher, 0, this, 48, cipher.size)
        }
    }

    /**
     * MAC-only envelope ("mac" mode): same layout as encryptStreamHmac ([16 nonce][32 hmac][payload]) but the
     * payload is NOT xor-encrypted. Used for Telegram MTProto traffic, which is already end-to-end encrypted and
     * travels over HTTPS to Google; this removes ~30 Utilities.computeDigest calls per request in Apps Script
     * while keeping HMAC authentication (the relay is not an open proxy).
     */
    fun macOnly(plain: ByteArray, secret: String): ByteArray {
        val key = sha256(secret.toByteArray(Charsets.UTF_8))
        val nonce = ByteArray(16).also { secureRandom.nextBytes(it) }
        val macInput = ByteArray(nonce.size + plain.size)
        System.arraycopy(nonce, 0, macInput, 0, nonce.size)
        System.arraycopy(plain, 0, macInput, nonce.size, plain.size)
        val tag = hmacSha256(macInput, key)
        return ByteArray(16 + 32 + plain.size).apply {
            System.arraycopy(nonce, 0, this, 0, 16)
            System.arraycopy(tag, 0, this, 16, 32)
            System.arraycopy(plain, 0, this, 48, plain.size)
        }
    }

    fun decryptStreamHmac(packet: ByteArray, secret: String): ByteArray? {
        if (packet.size < 48) return null
        val key = sha256(secret.toByteArray(Charsets.UTF_8))
        val nonce = packet.copyOfRange(0, 16)
        val tag = packet.copyOfRange(16, 48)
        val cipher = packet.copyOfRange(48, packet.size)
        val macInput = ByteArray(nonce.size + cipher.size)
        System.arraycopy(nonce, 0, macInput, 0, nonce.size)
        System.arraycopy(cipher, 0, macInput, nonce.size, cipher.size)
        val expectedTag = hmacSha256(macInput, key)
        if (!MessageDigest.isEqual(tag, expectedTag)) return null
        return xorKeyStream(cipher, key, nonce)
    }

    /**
     * Hardware-accelerated AES-256-GCM for Cloudflare Worker / local secure envelopes.
     */
    fun encryptAesGcm(plain: ByteArray, secret: String): ByteArray {
        val keyBytes = sha256(secret.toByteArray(Charsets.UTF_8))
        val iv = ByteArray(12).also { secureRandom.nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(keyBytes, "AES"), GCMParameterSpec(128, iv))
        val encrypted = cipher.doFinal(plain)
        return ByteArray(iv.size + encrypted.size).apply {
            System.arraycopy(iv, 0, this, 0, iv.size)
            System.arraycopy(encrypted, 0, this, iv.size, encrypted.size)
        }
    }

    fun decryptAesGcm(packet: ByteArray, secret: String): ByteArray? {
        if (packet.size < 13) return null
        val keyBytes = sha256(secret.toByteArray(Charsets.UTF_8))
        val iv = packet.copyOfRange(0, 12)
        val encrypted = packet.copyOfRange(12, packet.size)
        return runCatching {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"), GCMParameterSpec(128, iv))
            cipher.doFinal(encrypted)
        }.getOrNull()
    }

    fun xorMask(data: ByteArray, secret: String, nonce: ByteArray): ByteArray {
        val key = sha256(secret.toByteArray(Charsets.UTF_8))
        return xorKeyStream(data, key, nonce)
    }

    private fun xorKeyStream(input: ByteArray, key: ByteArray, nonce: ByteArray): ByteArray {
        val out = ByteArray(input.size)
        var counter = 0
        var offset = 0
        val digest = MessageDigest.getInstance("SHA-256")
        while (offset < input.size) {
            digest.reset()
            digest.update(key)
            digest.update(nonce)
            digest.update(byteArrayOf(
                ((counter ushr 24) and 0xFF).toByte(),
                ((counter ushr 16) and 0xFF).toByte(),
                ((counter ushr 8) and 0xFF).toByte(),
                (counter and 0xFF).toByte()
            ))
            val block = digest.digest()
            val toProcess = minOf(block.size, input.size - offset)
            for (i in 0 until toProcess) {
                out[offset + i] = (input[offset + i].toInt() xor block[i].toInt()).toByte()
            }
            offset += toProcess
            counter++
        }
        return out
    }
}
