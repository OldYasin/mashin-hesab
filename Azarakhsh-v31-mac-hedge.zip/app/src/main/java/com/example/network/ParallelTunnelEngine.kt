package com.example.network

import android.util.Base64
import com.example.core.crypto.TunnelCrypto
import com.example.core.logging.LogCategory
import com.example.core.logging.TunnelLogger
import com.example.core.logging.TunnelStats
import com.example.data.local.ServerEndpointEntity
import com.example.data.model.BypassSettings
import com.example.data.model.CompressionLevel
import com.example.data.model.EndpointType
import com.example.data.model.LoadBalanceMode
import com.example.data.model.SpeedSample
import com.example.data.model.TunnelConnectionState
import com.example.data.model.TunnelProtocol
import com.example.data.model.TunnelTelemetry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.net.ssl.SSLException
import javax.net.ssl.SSLPeerUnverifiedException
import kotlin.math.abs

data class PingResult(
    val endpointId: Long,
    val isHealthy: Boolean,
    val latencyMs: Int,
    val message: String
)

data class GasRelayResponse(
    val ok: Boolean,
    val statusCode: Int,
    val bodyBytes: ByteArray,
    val headers: List<Pair<String, String>> = emptyList(),
    val error: String? = null
)

class ParallelTunnelEngine {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val roundRobinIndex = AtomicInteger(0)
    private val dnsCache = ConcurrentHashMap<String, Pair<Long, ByteArray>>()

    private val intervalDownBytes = AtomicLong(0L)
    private val intervalUpBytes = AtomicLong(0L)
    private val totalDownBytes = AtomicLong(0L)
    private val totalUpBytes = AtomicLong(0L)
    private val rawBytes = AtomicLong(0L)
    private val compressedBytes = AtomicLong(0L)
    private val totalRequests = AtomicInteger(0)
    private val failedRequests = AtomicInteger(0)
    private val activeStreams = AtomicInteger(0)

    @Volatile
    private var lastLatencyMs = 0

    @Volatile
    private var lastJitterMs = 0

    @Volatile
    private var activePool: List<ServerEndpointEntity> = emptyList()

    @Volatile
    private var currentSettings: BypassSettings = BypassSettings()

    private var telemetryJob: Job? = null

    private val _telemetry = MutableStateFlow(TunnelTelemetry())
    val telemetry: StateFlow<TunnelTelemetry> = _telemetry.asStateFlow()

    fun updatePoolAndSettings(endpoints: List<ServerEndpointEntity>, settings: BypassSettings) {
        activePool = endpoints.filter { it.isParallelActive }
        currentSettings = settings
        _telemetry.update {
            it.copy(
                activeEndpointCount = activePool.size,
                activeSocksAddress = "127.0.0.1:${settings.localSocksPort}",
                activeEndpointLabel = buildPoolLabel(activePool)
            )
        }
    }

    fun startTelemetrySession(state: TunnelConnectionState = TunnelConnectionState.CONNECTED) {
        com.example.core.logging.TunnelStats.reset()
        totalDownBytes.set(0L)
        totalUpBytes.set(0L)
        rawBytes.set(0L)
        compressedBytes.set(0L)
        totalRequests.set(0)
        failedRequests.set(0)
        val startedAt = System.currentTimeMillis()
        _telemetry.update {
            it.copy(
                connectionState = state,
                connectedSinceMs = startedAt,
                lastErrorMessage = null,
                speedHistory = emptyList()
            )
        }
        TunnelLogger.i(
            LogCategory.SYSTEM,
            "SESSION",
            "جلسه تله‌متری تونل آغاز شد (${activePool.size} سرور فعال)",
            "Pool=${buildPoolLabel(activePool)}, Protocol=${currentSettings.protocol.name}"
        )
        telemetryJob?.cancel()
        telemetryJob = scope.launch {
            while (isActive) {
                delay(1000L)
                val downDelta = intervalDownBytes.getAndSet(0L)
                val upDelta = intervalUpBytes.getAndSet(0L)
                val downKbps = (downDelta / 1024f)
                val upKbps = (upDelta / 1024f)

                val reqCount = totalRequests.get()
                val failCount = failedRequests.get()
                val lossPct = if (reqCount == 0) 0f else (failCount * 100f) / reqCount
                val stability = computeStabilityScore(lastLatencyMs, lastJitterMs, lossPct, activePool.size)

                val sample = SpeedSample(
                    timestampMs = System.currentTimeMillis(),
                    downloadKbps = downKbps,
                    uploadKbps = upKbps,
                    stabilityPercent = stability
                )
                _telemetry.update { prev ->
                    val history = (prev.speedHistory + sample).takeLast(60)
                    prev.copy(
                        downloadKbps = downKbps,
                        uploadKbps = upKbps,
                        totalDownloadBytes = totalDownBytes.get(),
                        totalUploadBytes = totalUpBytes.get(),
                        rawBytesProcessed = rawBytes.get(),
                        compressedBytesSent = compressedBytes.get(),
                        stabilityScore = stability,
                        currentLatencyMs = lastLatencyMs,
                        jitterMs = lastJitterMs,
                        packetLossPercent = lossPct,
                        activeTcpStreams = activeStreams.get(),
                        activeEndpointCount = activePool.size,
                        activeEndpointLabel = buildPoolLabel(activePool),
                        gasRequests = TunnelStats.get("gas.invocations"),
                        gasUrlFetches = TunnelStats.get("gas.urlFetches"),
                        gasSavedRequests = TunnelStats.get("gas.saved"),
                        cfRequests = TunnelStats.get("cf.requests"),
                        cfWarmReuses = TunnelStats.get("pool.warm"),
                        batteryTempC = currentBatteryTempC,
                        batteryCharging = currentBatteryCharging,
                        thermalThrottled = isThermalThrottled(),
                        speedHistory = history
                    )
                }
            }
        }
    }

    fun setConnectionState(state: TunnelConnectionState, errorMessage: String? = null) {
        _telemetry.update {
            it.copy(
                connectionState = state,
                lastErrorMessage = errorMessage
            )
        }
        if (errorMessage != null) {
            TunnelLogger.e(LogCategory.SYSTEM, "STATE", "وضعیت اتصال: ${state.titleFa}", errorMessage)
        } else {
            TunnelLogger.i(LogCategory.SYSTEM, "STATE", "وضعیت اتصال: ${state.titleFa}")
        }
    }

    fun stopTelemetrySession() {
        clearWarmPool()
        telemetryJob?.cancel()
        telemetryJob = null
        TunnelLogger.i(
            LogCategory.SYSTEM,
            "SESSION",
            "جلسه تونل متوقف شد",
            "Down=${totalDownBytes.get()}B, Up=${totalUpBytes.get()}B"
        )
        _telemetry.update {
            it.copy(
                connectionState = TunnelConnectionState.DISCONNECTED,
                downloadKbps = 0f,
                uploadKbps = 0f,
                activeTcpStreams = 0,
                connectedSinceMs = 0L
            )
        }
    }

    fun recordTraffic(upBytes: Long, downBytes: Long, rawPayload: Long = 0L, compressedPayload: Long = 0L) {
        if (upBytes > 0) {
            intervalUpBytes.addAndGet(upBytes)
            totalUpBytes.addAndGet(upBytes)
        }
        if (downBytes > 0) {
            intervalDownBytes.addAndGet(downBytes)
            totalDownBytes.addAndGet(downBytes)
        }
        if (rawPayload > 0) {
            rawBytes.addAndGet(rawPayload)
            compressedBytes.addAndGet(if (compressedPayload > 0) compressedPayload else rawPayload)
        }
    }

    fun incrementStreams() = activeStreams.incrementAndGet()
    fun decrementStreams() = activeStreams.updateAndGet { (it - 1).coerceAtLeast(0) }

    suspend fun pingEndpoint(
        endpoint: ServerEndpointEntity,
        settings: BypassSettings
    ): PingResult = withContext(Dispatchers.IO) {
        val cleanIp = if (!settings.cleanIpBinding) {
            ""
        } else {
            endpoint.customCleanIp.ifBlank {
                if (endpoint.endpointType == EndpointType.CF_WORKER_WS) settings.activeCleanCfIp
                else settings.activeCleanGoogleIp
            }.trim()
        }

        val normalizedUrl = normalizeHttpUrl(endpoint.url)
        val pingUrl = when (endpoint.endpointType) {
            EndpointType.CF_WORKER_WS -> {
                val base = normalizedUrl.trimEnd('/')
                "$base/ping"
            }
            else -> {
                val sep = if (normalizedUrl.contains("?")) "&" else "?"
                "${normalizedUrl}${sep}ping=1&token=${endpoint.secretKey}"
            }
        }

        if (endpoint.endpointType == EndpointType.GAS_SCRIPT && normalizedUrl.contains("/dev")) {
            TunnelLogger.w(
                LogCategory.GAS,
                "GAS-URL",
                "لینک «${endpoint.name}» به /dev ختم شده است؛ برای اجرا باید لینک /exec باشد",
                "URL=$normalizedUrl"
            )
        }

        val firstAttempt = executePingAttempt(
            endpoint = endpoint,
            settings = settings,
            pingUrl = pingUrl,
            cleanIp = cleanIp,
            disableCleanIp = false
        )

        // Automatic fallback to System DNS if Clean IP failed due to SSL Hostname / network error
        if (!firstAttempt.result.isHealthy && firstAttempt.shouldRetryDirect && cleanIp.isNotBlank()) {
            TunnelLogger.w(
                LogCategory.GAS,
                "PING-FALLBACK",
                "تلاش مجدد پینگ «${endpoint.name}» بدون آی‌پی تمیز ($cleanIp) با DNS مستقیم",
                "Reason=${firstAttempt.result.message}"
            )
            val fallback = executePingAttempt(
                endpoint = endpoint,
                settings = settings,
                pingUrl = pingUrl,
                cleanIp = "",
                disableCleanIp = true
            )
            return@withContext fallback.result
        }

        return@withContext firstAttempt.result
    }

    private data class PingAttemptOutcome(
        val result: PingResult,
        val shouldRetryDirect: Boolean = false
    )

    private fun executePingAttempt(
        endpoint: ServerEndpointEntity,
        settings: BypassSettings,
        pingUrl: String,
        cleanIp: String,
        disableCleanIp: Boolean
    ): PingAttemptOutcome {
        val logCat = if (endpoint.endpointType == EndpointType.CF_WORKER_WS) LogCategory.CF_WS else LogCategory.GAS
        val client = BypassOkHttpFactory.createClient(
            settings = settings,
            overrideCleanIp = cleanIp,
            connectTimeoutMs = 7_000L,
            readTimeoutMs = 10_000L,
            disableCleanIp = disableCleanIp
        )

        val (effectivePingUrl, realHostHeader) = if (endpoint.endpointType == EndpointType.CF_WORKER_WS && endpoint.customSniHost.isNotBlank()) {
            applySniSpoofUrl(pingUrl, endpoint.customSniHost)
        } else {
            pingUrl to null
        }

        val req = Request.Builder()
            .url(effectivePingUrl)
            .get()
            .apply {
                // Real SNI Spoofing: TLS SNI uses customSniHost (effectivePingUrl), HTTP Host carries the real Worker host
                if (realHostHeader != null) {
                    header("Host", realHostHeader)
                }
            }
            .build()

        val t0 = System.nanoTime()
        return try {
            client.newCall(req).execute().use { res ->
                val rtt = ((System.nanoTime() - t0) / 1_000_000L).toInt().coerceAtLeast(1)
                val body = res.body?.string().orEmpty()
                val finalUrl = res.request.url.toString()

                if (res.code == 403 || res.code == 401) {
                    val diag = build403Diagnostic(finalUrl, body)
                    TunnelLogger.e(
                        logCat,
                        "PING-${res.code}",
                        "خطای ${res.code} برای «${endpoint.name}»: $diag",
                        "URL=$pingUrl\nFinalURL=$finalUrl\nCleanIP=${cleanIp.ifBlank { "system-dns" }}\nResponse=${body.take(300)}"
                    )
                    return PingAttemptOutcome(PingResult(endpoint.id, false, -1, diag), shouldRetryDirect = false)
                }

                if (finalUrl.contains("accounts.google.com", ignoreCase = true) ||
                    (body.trimStart().startsWith("<") && !body.contains("\"ok\":true"))
                ) {
                    val msg = "صفحه ورود گوگل برگشت داده شد؛ در Deploy گزینه Who has access را روی Anyone بگذارید"
                    TunnelLogger.e(
                        logCat,
                        "PING-AUTH",
                        "خطای دسترسی برای «${endpoint.name}»: $msg",
                        "HTTP=${res.code}, FinalURL=$finalUrl\nSnippet=${body.take(240)}"
                    )
                    return PingAttemptOutcome(PingResult(endpoint.id, false, -1, msg), shouldRetryDirect = false)
                }

                if (body.contains("\"error\":\"unauthorized\"")) {
                    val msg = "کلید امنیتی (TUNNEL_SECRET) با اسکریپت گوگل مطابقت ندارد"
                    TunnelLogger.e(
                        logCat,
                        "PING-SECRET",
                        "عدم تطابق کلید امنیتی در «${endpoint.name}»",
                        "HTTP=${res.code}, Body=$body"
                    )
                    return PingAttemptOutcome(PingResult(endpoint.id, false, -1, msg), shouldRetryDirect = false)
                }

                val ok = res.isSuccessful && (body.contains("\"ok\":true") || body.contains("ScriptTunnel") || res.code in 200..299)
                if (ok) {
                    updateLatencyStats(rtt)
                    TunnelLogger.i(
                        logCat,
                        "PING-OK",
                        "پینگ موفق «${endpoint.name}» (${rtt}ms • HTTP ${res.code})",
                        "FinalURL=$finalUrl, CleanIP=${cleanIp.ifBlank { "system-dns" }}"
                    )
                    PingAttemptOutcome(PingResult(endpoint.id, true, rtt, "پینگ موفق (${rtt}ms)"))
                } else {
                    TunnelLogger.e(
                        logCat,
                        "PING-FAIL",
                        "پینگ ناموفق «${endpoint.name}» (HTTP ${res.code})",
                        "FinalURL=$finalUrl\nCleanIP=${cleanIp.ifBlank { "system-dns" }}\nBody=${body.take(240)}"
                    )
                    PingAttemptOutcome(PingResult(endpoint.id, false, -1, "کد خطا: ${res.code}"))
                }
            }
        } catch (e: SSLPeerUnverifiedException) {
            if (cleanIp.isNotBlank()) BypassOkHttpFactory.markBadCleanIp(cleanIp)
            val msg = "خطای گواهی SSL روی آی‌پی ${cleanIp.ifBlank { "پیش‌فرض" }} (عدم تطابق دامنه)"
            TunnelLogger.e(
                logCat,
                "PING-SSL",
                "خطای تایید دامنه SSL برای «${endpoint.name}»",
                "CleanIP=$cleanIp\nError=${e.localizedMessage}"
            )
            PingAttemptOutcome(PingResult(endpoint.id, false, -1, msg), shouldRetryDirect = true)
        } catch (e: SSLException) {
            val msg = "خطای TLS/SSL: ${e.localizedMessage ?: "Handshake failed"}"
            TunnelLogger.e(
                logCat,
                "PING-TLS",
                "خطای هندشیک TLS برای «${endpoint.name}»",
                "CleanIP=$cleanIp\nError=${e.javaClass.simpleName}: ${e.localizedMessage}"
            )
            PingAttemptOutcome(PingResult(endpoint.id, false, -1, msg), shouldRetryDirect = true)
        } catch (e: Exception) {
            val msg = e.localizedMessage ?: "خطای شبکه"
            TunnelLogger.e(
                logCat,
                "PING-ERR",
                "خطای اتصال به «${endpoint.name}»: $msg",
                "CleanIP=${cleanIp.ifBlank { "system-dns" }}\nException=${e.javaClass.simpleName}: ${e.message}"
            )
            PingAttemptOutcome(PingResult(endpoint.id, false, -1, msg), shouldRetryDirect = cleanIp.isNotBlank())
        }
    }

    private fun build403Diagnostic(finalUrl: String, body: String): String {
        return when {
            finalUrl.contains("/dev") -> "لینک /dev مجاز نیست؛ از لینک Deploy شده (/exec) استفاده کنید"
            body.contains("Access denied", ignoreCase = true) || body.contains("Permission", ignoreCase = true) ->
                "خطای 403 گوگل: در Deploy گزینه Who has access را روی Anyone بگذارید"
            else -> "خطای 403 گوگل: دسترسی Web App را روی Anyone قرار دهید و لینک /exec را بررسی کنید"
        }
    }

    fun selectOrderedCandidates(preferredType: EndpointType? = null): List<ServerEndpointEntity> {
        val pool = if (preferredType != null) {
            val matching = activePool.filter { it.endpointType == preferredType }
            matching.ifEmpty { activePool }
        } else {
            activePool
        }
        if (pool.isEmpty()) return emptyList()

        return when (currentSettings.loadBalanceMode) {
            LoadBalanceMode.PARALLEL_ROUND_ROBIN -> {
                val start = abs(roundRobinIndex.getAndIncrement()) % pool.size
                (0 until pool.size).map { i -> pool[(start + i) % pool.size] }
            }
            LoadBalanceMode.ADAPTIVE_LATENCY -> {
                val now = System.currentTimeMillis()
                pool.sortedWith(
                    compareBy<ServerEndpointEntity> { (nodeCooldownUntil[it.url] ?: 0L) > now }
                        .thenBy { !it.isHealthy }
                        .thenBy { nodeInFlight[it.url]?.get() ?: 0 }
                        .thenBy { nodeEwmaMs[it.url] ?: if (it.lastLatencyMs > 0) it.lastLatencyMs else 9999 }
                        .thenByDescending { it.weight }
                )
            }
            LoadBalanceMode.FAILOVER -> {
                pool.sortedWith(compareByDescending<ServerEndpointEntity> { it.isHealthy }
                    .thenByDescending { it.weight }
                    .thenBy { if (it.lastLatencyMs > 0) it.lastLatencyMs else 9999 })
            }
        }
    }

    private val relayCache = GasRelayCache()
    private val inflightRelays = ConcurrentHashMap<String, kotlinx.coroutines.CompletableDeferred<GasRelayResponse>>()
    private val nodeCooldownUntil = ConcurrentHashMap<String, Long>()
    private val nodeInFlight = ConcurrentHashMap<String, AtomicInteger>()
    private val nodeEwmaMs = ConcurrentHashMap<String, Int>()

    private fun recordNodeLatency(url: String, rttMs: Int) {
        val prev = nodeEwmaMs[url] ?: 0
        nodeEwmaMs[url] = if (prev <= 0) rttMs else ((prev * 7 + rttMs * 3) / 10).coerceAtLeast(1)
    }

    private fun coolDownNode(url: String, name: String, ms: Long, why: String) {
        nodeCooldownUntil[url] = System.currentTimeMillis() + ms
        TunnelLogger.w(
            LogCategory.GAS,
            "RELAY-COOLDOWN",
            "اسکریپت «$name» برای ${ms / 1000} ثانیه کنار گذاشته شد",
            why.take(200)
        )
    }

    /** Apps Script quota errors: skip that deployment for a while and use the others. */
    private fun coolDownIfQuota(url: String, name: String, err: String) {
        val e = err.lowercase()
        when {
            "short time" in e -> coolDownNode(url, name, 60_000L, err)
            "too many times" in e || "quota" in e || "bandwidth" in e -> coolDownNode(url, name, 1_800_000L, err)
        }
    }

    /**
     * Relay through the Google script pool. Static GETs are served from a small cache, and identical
     * GETs that are in flight at the same moment share one relay call.
     */
    private val prefetchSeen: MutableSet<String> = java.util.Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())
    private val prefetchGate = Semaphore(12)
    private val staticImportRegex = Regex("""(?:from|import)\s*["'](\.{1,2}/[^"'\s?#]+\.m?js)["']""")

    /**
     * A page built from ~200 ES modules costs ~1.7s per file when the browser asks one by one (6 connections,
     * no HTTP/2 here). Scan a delivered module for its static relative imports and relay them now, in parallel,
     * so the browser's own requests hit the cache or join the in-flight relay.
     */
    fun prefetchModuleDeps(baseUrl: String, reqHeaders: Map<String, String>, res: GasRelayResponse) {
        if (isThermalThrottled()) return
        if (!res.ok || res.statusCode != 200 || res.bodyBytes.isEmpty() || res.bodyBytes.size > 2_500_000) return
        val ct = res.headers.firstOrNull { it.first.equals("content-type", true) }?.second.orEmpty().lowercase()
        if (!ct.contains("javascript")) return
        if (!baseUrl.startsWith("https://")) return
        if (prefetchSeen.size > 4000) prefetchSeen.clear()
        val base = try { java.net.URI(baseUrl) } catch (e: Exception) { return }
        val hdrs = LinkedHashMap<String, String>()
        for ((k, v) in reqHeaders) {
            when (k.lowercase()) {
                "accept", "range", "authorization", "if-none-match", "if-modified-since", "if-range", "cookie" -> {}
                else -> hdrs[k] = v
            }
        }
        hdrs["Accept"] = "*/*"
        val text = String(res.bodyBytes, Charsets.UTF_8)
        var launched = 0
        for (m in staticImportRegex.findAll(text)) {
            if (launched >= 80) break
            val abs = try { base.resolve(m.groupValues[1]).toString() } catch (e: Exception) { continue }
            if (!abs.startsWith("https://")) continue
            if (!prefetchSeen.add(abs)) continue
            launched++
            scope.launch {
                prefetchGate.withPermit {
                    val r = try { relayHttpViaGasPool(abs, "GET", hdrs, null, false) } catch (e: Exception) { null }
                    if (r != null && r.ok && r.statusCode == 200) prefetchModuleDeps(abs, hdrs, r)
                }
            }
        }
        if (launched > 0) TunnelStats.inc("relay.prefetch")
    }

    suspend fun relayHttpViaGasPool(
        targetUrl: String,
        method: String = "GET",
        headers: Map<String, String> = emptyMap(),
        bodyBytes: ByteArray? = null,
        followRedirects: Boolean = true,
        nodeOffset: Int = 0
    ): GasRelayResponse {
        if (!GasRelayCache.isCacheableRequest(method, headers, bodyBytes)) {
            return relayUncached(targetUrl, method, headers, bodyBytes, followRedirects, nodeOffset)
        }
        val key = GasRelayCache.keyFor(targetUrl, headers) + "|" + followRedirects
        relayCache.get(key)?.let {
            TunnelStats.inc("relay.cacheHit")
            TunnelStats.inc("gas.saved")
            return it
        }
        val mine = kotlinx.coroutines.CompletableDeferred<GasRelayResponse>()
        val leader = inflightRelays.putIfAbsent(key, mine)
        if (leader != null) {
            val shared = runCatching { leader.await() }.getOrNull()
            if (shared != null && shared.ok) {
                TunnelStats.inc("relay.coalesced")
                TunnelStats.inc("gas.saved")
                return shared
            }
            return relayUncached(targetUrl, method, headers, bodyBytes, followRedirects)
        }
        try {
            val res = relayUncached(targetUrl, method, headers, bodyBytes, followRedirects)
            if (res.ok) relayCache.put(key, res, GasRelayCache.ttlMsFor(res, headers, targetUrl))
            mine.complete(res)
            return res
        } finally {
            if (!mine.isCompleted) {
                mine.complete(GasRelayResponse(false, 502, ByteArray(0), error = "relay cancelled"))
            }
            inflightRelays.remove(key, mine)
        }
    }

    private data class GasBatchItem(
        val targetUrl: String,
        val method: String,
        val headers: Map<String, String>,
        val bodyBytes: ByteArray?,
        val followRedirects: Boolean,
        val isTelegramRpc: Boolean,
        val deferred: kotlinx.coroutines.CompletableDeferred<GasRelayResponse>
    )

    private val gasBatchQueue = java.util.concurrent.ConcurrentLinkedQueue<GasBatchItem>()
    private val gasBatchRunning = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var currentBatteryTempC: Float = 0f
    @Volatile private var currentBatteryCharging: Boolean = false
    private val gasRelayInFlight = AtomicInteger(0)
    private val gasSlotSignal = kotlinx.coroutines.channels.Channel<Unit>(kotlinx.coroutines.channels.Channel.CONFLATED)

    /** 0 = normal, 1 = warm, 2 = hot. Hysteresis stops the level flapping when the temperature hovers at a threshold. */
    @Volatile private var thermalLevel: Int = 0
    @Volatile private var batteryThermalLevel: Int = 0
    @Volatile private var systemThermalLevel: Int = 0

    fun updateThermalReading(tempC: Float, charging: Boolean) {
        currentBatteryTempC = tempC
        currentBatteryCharging = charging
        // a charging phone sits a few degrees warmer on its own, so give it 1°C more headroom
        val bias = if (charging) 1.0f else 0f
        val warmOn = 42.0f + bias; val warmOff = 40.5f + bias
        val hotOn = 45.0f + bias; val hotOff = 43.5f + bias
        batteryThermalLevel = when (batteryThermalLevel) {
            2 -> if (tempC < hotOff) (if (tempC < warmOff) 0 else 1) else 2
            1 -> if (tempC >= hotOn) 2 else if (tempC < warmOff) 0 else 1
            else -> if (tempC >= hotOn) 2 else if (tempC >= warmOn) 1 else 0
        }
        thermalLevel = maxOf(batteryThermalLevel, systemThermalLevel)
    }

    /**
     * Android's own thermal status (PowerManager, API 29+): 0 NONE, 1 LIGHT, 2 MODERATE, 3 SEVERE, 4+ CRITICAL..SHUTDOWN.
     * It reflects the SoC/skin sensors, which the battery temperature alone can miss. The system already adds its own hysteresis.
     */
    fun updateSystemThermalStatus(status: Int) {
        systemThermalLevel = when {
            status >= 3 -> 2
            status == 2 -> 1
            else -> 0
        }
        thermalLevel = maxOf(batteryThermalLevel, systemThermalLevel)
    }

    private fun thermalActive(): Boolean = currentSettings.thermalGuardEnabled
    private fun isThermalThrottled(): Boolean = thermalActive() && thermalLevel >= 1

    private fun maxConcurrentGasRelays(): Int {
        if (!thermalActive()) return 8
        return when (thermalLevel) {
            2 -> 3
            1 -> 5
            else -> 8
        }
    }
    private val batchUnsupportedNodes = ConcurrentHashMap.newKeySet<String>()
    // Nodes whose deployed script predates the "mac" envelope -> use the full encrypted envelope instead
    private val macUnsupportedNodes = ConcurrentHashMap.newKeySet<String>()

    /**
     * HTTP/2 clients send lowercase header names (user-agent, content-type). Apps Script's UrlFetchApp treats
     * header names case-sensitively and only replaces its own default "User-Agent" when the exact key matches,
     * so a lowercase one is lost and Google serves the desktop layout. Re-case to Title-Case before relaying.
     */
    private fun canonicalHeaders(src: Map<String, String>): Map<String, String> {
        val out = LinkedHashMap<String, String>(src.size)
        for ((k, v) in src) {
            if (k.isEmpty() || k.startsWith(":")) continue
            val name = k.split('-').joinToString("-") { part ->
                if (part.isEmpty()) part else part[0].uppercaseChar() + part.substring(1).lowercase()
            }
            out[name] = v
        }
        return out
    }

    private suspend fun relayUncached(
        targetUrl: String,
        method: String,
        headers: Map<String, String>,
        bodyBytes: ByteArray?,
        followRedirects: Boolean,
        nodeOffset: Int = 0
    ): GasRelayResponse {
        val isTelegramRpc = targetUrl.contains(".web.telegram.org/apiw", ignoreCase = true) || targetUrl.endsWith("/api")
        val isBatchableGet = method.equals("GET", ignoreCase = true) && (bodyBytes == null || bodyBytes.isEmpty())
        // Do not batch Telegram MTProto POSTs into UrlFetchApp.fetchAll: a single long-poll (http_wait)
        // blocks the entire batch and stalls fast sendMessage RPCs behind it.
        if (isBatchableGet) {
            val allNodes = selectOrderedCandidates(EndpointType.GAS_SCRIPT)
            if (allNodes.any { it.url !in batchUnsupportedNodes }) {
                val deferred = kotlinx.coroutines.CompletableDeferred<GasRelayResponse>()
                gasBatchQueue.add(
                    GasBatchItem(
                        targetUrl = targetUrl,
                        method = method,
                        headers = headers,
                        bodyBytes = bodyBytes,
                        followRedirects = followRedirects,
                        isTelegramRpc = isTelegramRpc,
                        deferred = deferred
                    )
                )
                triggerGasBatchLoop()
                return deferred.await()
            }
        }
        return relaySingleUncached(targetUrl, method, headers, bodyBytes, followRedirects, nodeOffset)
    }

    private fun triggerGasBatchLoop() {
        if (!gasBatchRunning.compareAndSet(false, true)) return
        scope.launch(Dispatchers.IO) {
            try {
                while (true) {
                    val first = gasBatchQueue.poll()
                    if (first == null) break
                    val batch = ArrayList<GasBatchItem>(6)
                    batch.add(first)
                    // Coalesce up to 5 more items arriving within 25ms without spinning when idle
                    val deadline = System.currentTimeMillis() + 25L
                    while (batch.size < 6) {
                        val next = gasBatchQueue.poll()
                        if (next != null) {
                            batch.add(next)
                        } else {
                            val rem = deadline - System.currentTimeMillis()
                            if (rem <= 0L) break
                            delay(rem.coerceAtMost(8L))
                        }
                    }
                    if (batch.size == 1) {
                        val single = batch[0]
                        scope.launch {
                            val res = try {
                                relaySingleUncached(single.targetUrl, single.method, single.headers, single.bodyBytes, single.followRedirects)
                            } catch (e: Exception) {
                                GasRelayResponse(false, 502, ByteArray(0), error = e.message ?: "batch single error")
                            }
                            single.deferred.complete(res)
                        }
                    } else {
                        scope.launch {
                            executeGasBatch(batch)
                        }
                    }
                    if (gasBatchQueue.isEmpty()) break
                }
            } finally {
                gasBatchRunning.set(false)
                if (gasBatchQueue.isNotEmpty()) triggerGasBatchLoop()
            }
        }
    }

    private suspend fun executeGasBatch(batch: List<GasBatchItem>) = withContext(Dispatchers.IO) {
        val allCandidates = selectOrderedCandidates(EndpointType.GAS_SCRIPT)
        val nowMs = System.currentTimeMillis()
        val candidates = allCandidates
            .filter { it.url !in batchUnsupportedNodes && (nodeCooldownUntil[it.url] ?: 0L) <= nowMs }
            .ifEmpty { allCandidates.filter { it.url !in batchUnsupportedNodes } }

        if (candidates.isEmpty()) {
            batch.forEach { item ->
                scope.launch {
                    val res = try {
                        relaySingleUncached(item.targetUrl, item.method, item.headers, item.bodyBytes, item.followRedirects)
                    } catch (e: Exception) {
                        GasRelayResponse(false, 502, ByteArray(0), error = e.message ?: "fallback error")
                    }
                    item.deferred.complete(res)
                }
            }
            return@withContext
        }

        val settings = currentSettings
        var handled = false
        for (node in candidates) {
            totalRequests.incrementAndGet()
            val t0 = System.nanoTime()
            val cleanIp = if (settings.cleanIpBinding) node.customCleanIp.ifBlank { settings.activeCleanGoogleIp }.trim() else ""
            try {
                val itemsArr = org.json.JSONArray()
                val allTelegram = batch.all { it.isTelegramRpc }
                for (item in batch) {
                    itemsArr.put(JSONObject().apply {
                        put("url", item.targetUrl)
                        put("method", item.method)
                        put("headers", JSONObject(canonicalHeaders(item.headers)))
                        put("followRedirects", item.followRedirects)
                        put("gzBody", !item.isTelegramRpc)
                        if (item.bodyBytes != null && item.bodyBytes.isNotEmpty()) {
                            put("bodyB64", Base64.encodeToString(item.bodyBytes, Base64.NO_WRAP))
                        }
                    })
                }
                val innerJson = JSONObject().apply {
                    put("action", "batch")
                    put("items", itemsArr)
                    put("light", true)
                    if (settings.randomPadding) put("pad", TunnelCrypto.randomPaddingString())
                }.toString().toByteArray(Charsets.UTF_8)

                val compLevel = if (settings.compressionLevel == CompressionLevel.OFF || (allTelegram && innerJson.size < 4096) || (settings.thermalGuardEnabled && thermalLevel >= 2 && innerJson.size < 2048)) CompressionLevel.OFF else if (settings.thermalGuardEnabled && thermalLevel >= 1) CompressionLevel.FAST_DEFLATE else CompressionLevel.ULTRA_GZIP
                val compressed = TunnelCrypto.compress(innerJson, compLevel)
                val encryptedBytes = TunnelCrypto.encryptStreamHmac(compressed.bytes, node.secretKey)
                val envelopeBytes = JSONObject().apply {
                    put("enc", true)
                    put("comp", if (compLevel != CompressionLevel.OFF && compressed.compressedSize < compressed.rawSize) "gzip" else "none")
                    put("data", Base64.encodeToString(encryptedBytes, Base64.NO_WRAP))
                }.toString().toByteArray(Charsets.UTF_8)

                recordTraffic(
                    upBytes = envelopeBytes.size.toLong(),
                    downBytes = 0L,
                    rawPayload = innerJson.size.toLong(),
                    compressedPayload = compressed.compressedSize.toLong()
                )

                TunnelStats.inc("gas.invocations")
                TunnelStats.add("gas.urlFetches", batch.size)
                TunnelStats.inc("gas.node:${node.name}")
                val response = executeGasPostWithFallback(
                    nodeUrl = normalizeHttpUrl(node.url),
                    envelopeBytes = envelopeBytes,
                    settings = settings,
                    cleanIp = cleanIp,
                    nodeName = node.name
                )
                response.use { res ->
                    val respText = res.body?.string().orEmpty()
                    val rtt = ((System.nanoTime() - t0) / 1_000_000L).toInt().coerceAtLeast(1)
                    recordTraffic(upBytes = 0L, downBytes = respText.toByteArray().size.toLong())
                    if (!res.isSuccessful || respText.trimStart().startsWith("<")) {
                        if (res.code == 429) coolDownNode(node.url, node.name, 300_000L, "HTTP 429")
                        failedRequests.incrementAndGet(); TunnelStats.inc("gas.failed")
                        continue
                    }
                    val outer = JSONObject(respText)
                    if (!outer.optBoolean("ok", false)) {
                        val err = outer.optString("error", "gas_error")
                        if (err == "missing_url") {
                            batchUnsupportedNodes.add(node.url)
                            TunnelLogger.w(LogCategory.GAS, "BATCH-UNSUP", "اسکریپت «${node.name}» از batch پشتیبانی نمی‌کند؛ بازگشت به حالت تکی")
                        } else {
                            coolDownIfQuota(node.url, node.name, err)
                        }
                        failedRequests.incrementAndGet(); TunnelStats.inc("gas.failed")
                        continue
                    }
                    var decoded = Base64.decode(outer.optString("data", ""), Base64.DEFAULT)
                    if (outer.optBoolean("enc", false)) {
                        decoded = TunnelCrypto.decryptStreamHmac(decoded, node.secretKey)
                            ?: throw IllegalStateException("HMAC verification failed")
                    }
                    val rawRespSize = decoded.size
                    if (outer.optString("comp") == "gzip") {
                        decoded = TunnelCrypto.decompressGzip(decoded)
                    }
                    recordTraffic(upBytes = 0L, downBytes = 0L, rawPayload = decoded.size.toLong(), compressedPayload = rawRespSize.toLong())
                    val innerResp = JSONObject(String(decoded, Charsets.UTF_8))
                    val outArr = innerResp.optJSONArray("items") ?: continue
                    nodeCooldownUntil.remove(node.url)
                    if (batch.size > 1) TunnelStats.add("gas.saved", batch.size - 1)
                    if (!(allTelegram && rtt > 8_000)) {
                        recordNodeLatency(normalizeHttpUrl(node.url), rtt)
                        TunnelStats.sample("t.gasRtt", rtt.toLong())
                    }
                    updateLatencyStats(rtt)
                    TunnelLogger.i(
                        LogCategory.GAS,
                        "RELAY-BATCH",
                        "رله گروهی ${batch.size} درخواست از «${node.name}» (${rtt}ms)"
                    )
                    for (i in batch.indices) {
                        val itemObj = outArr.optJSONObject(i)
                        if (itemObj == null || !itemObj.optBoolean("ok", false)) {
                            val itemErr = itemObj?.optString("error", "batch_item_err") ?: "batch_item_err"
                            batch[i].deferred.complete(GasRelayResponse(false, 502, ByteArray(0), error = itemErr))
                            continue
                        }
                        val statusCode = itemObj.optInt("status", 200)
                        var outBody = Base64.decode(itemObj.optString("bodyB64", ""), Base64.DEFAULT)
                        if (itemObj.optString("bodyEnc") == "gzip" && outBody.isNotEmpty()) {
                            outBody = TunnelCrypto.decompressGzip(outBody)
                        }
                        val respHeaders = mutableListOf<Pair<String, String>>()
                        val hdrObj = itemObj.optJSONObject("headers")
                        if (hdrObj != null) {
                            val keys = hdrObj.keys()
                            while (keys.hasNext()) {
                                val k = keys.next()
                                val v = hdrObj.opt(k)
                                when (v) {
                                    is org.json.JSONArray -> {
                                        for (j in 0 until v.length()) respHeaders.add(k to v.optString(j))
                                    }
                                    null, JSONObject.NULL -> {}
                                    else -> respHeaders.add(k to v.toString())
                                }
                            }
                        }
                        batch[i].deferred.complete(GasRelayResponse(true, statusCode, outBody, respHeaders))
                    }
                    handled = true
                    break
                }
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                failedRequests.incrementAndGet(); TunnelStats.inc("gas.failed")
            }
        }
        if (!handled) {
            batch.forEach { item ->
                scope.launch {
                    val res = try {
                        relaySingleUncached(item.targetUrl, item.method, item.headers, item.bodyBytes, item.followRedirects)
                    } catch (e: Exception) {
                        GasRelayResponse(false, 502, ByteArray(0), error = e.message ?: "batch fallback error")
                    }
                    item.deferred.complete(res)
                }
            }
        }
    }

    private suspend fun relaySingleUncached(
        targetUrl: String,
        method: String,
        headers: Map<String, String>,
        bodyBytes: ByteArray?,
        followRedirects: Boolean,
        nodeOffset: Int = 0
    ): GasRelayResponse = withContext(Dispatchers.IO) {
        val isTelegramRpc = targetUrl.contains(".web.telegram.org/apiw", ignoreCase = true) || targetUrl.endsWith("/api")
        if (!isTelegramRpc) {
            while (gasRelayInFlight.get() >= maxConcurrentGasRelays()) {
                kotlinx.coroutines.withTimeoutOrNull(if (thermalLevel >= 2) 200L else 100L) {
                    gasSlotSignal.receive()
                }
            }
        }
        if (!isTelegramRpc) gasRelayInFlight.incrementAndGet()
        try {
        val allCandidates = selectOrderedCandidates(EndpointType.GAS_SCRIPT)
        if (allCandidates.isEmpty()) {
            TunnelLogger.w(LogCategory.GAS, "RELAY-SKIP", "هیچ اسکریپت گوگل فعالی برای رله وجود ندارد")
            return@withContext GasRelayResponse(false, 503, ByteArray(0), error = "هیچ اسکریپت فعالی انتخاب نشده است")
        }

        // skip deployments that hit their quota; if every one is cooling down, try them all anyway
        val nowMs = System.currentTimeMillis()
        val healthyCandidates = allCandidates.filter { (nodeCooldownUntil[it.url] ?: 0L) <= nowMs }.ifEmpty { allCandidates }
        // hedged duplicate requests start from a different node than the primary one
        val candidates = if (nodeOffset > 0 && healthyCandidates.size > 1) {
            val k = nodeOffset % healthyCandidates.size
            healthyCandidates.drop(k) + healthyCandidates.take(k)
        } else healthyCandidates

        val settings = currentSettings
        var lastErr = "خطا در تمام اسکریپت‌های موازی"
        for (node in candidates) {
            totalRequests.incrementAndGet()
            val t0 = System.nanoTime()
            val cleanIp = if (settings.cleanIpBinding) node.customCleanIp.ifBlank { settings.activeCleanGoogleIp }.trim() else ""
            val useMac = isTelegramRpc && node.url !in macUnsupportedNodes
            try {
                val innerJson = JSONObject().apply {
                    put("action", "relay")
                    put("url", targetUrl)
                    put("method", method)
                    put("headers", JSONObject(canonicalHeaders(headers)))
                    put("followRedirects", followRedirects)
                    put("light", true)
                    put("gzBody", true)
                    if (useMac) put("nogz", true) // MTProto bytes are incompressible; skip gzip attempt in GAS
                    if (bodyBytes != null && bodyBytes.isNotEmpty()) {
                        put("bodyB64", Base64.encodeToString(bodyBytes, Base64.NO_WRAP))
                    }
                    if (settings.randomPadding) {
                        put("pad", TunnelCrypto.randomPaddingString())
                    }
                }.toString().toByteArray(Charsets.UTF_8)

                val compLevel = if (settings.compressionLevel == CompressionLevel.OFF || (isTelegramRpc && innerJson.size < 2048) || (settings.thermalGuardEnabled && thermalLevel >= 2 && innerJson.size < 2048)) CompressionLevel.OFF else if (settings.thermalGuardEnabled && thermalLevel >= 1) CompressionLevel.FAST_DEFLATE else CompressionLevel.ULTRA_GZIP
                val compressed = TunnelCrypto.compress(innerJson, compLevel)
                val encryptedBytes = if (useMac) TunnelCrypto.macOnly(compressed.bytes, node.secretKey)
                else TunnelCrypto.encryptStreamHmac(compressed.bytes, node.secretKey)

                val envelope = JSONObject().apply {
                    if (useMac) put("enc", "mac") else put("enc", true)
                    put("comp", if (compLevel != CompressionLevel.OFF && compressed.compressedSize < compressed.rawSize) "gzip" else "none")
                    put("data", Base64.encodeToString(encryptedBytes, Base64.NO_WRAP))
                }.toString()

                val envelopeBytes = envelope.toByteArray(Charsets.UTF_8)
                recordTraffic(
                    upBytes = envelopeBytes.size.toLong(),
                    downBytes = 0L,
                    rawPayload = innerJson.size.toLong(),
                    compressedPayload = compressed.compressedSize.toLong()
                )

                TunnelStats.inc("gas.invocations")
                TunnelStats.inc("gas.urlFetches")
                TunnelStats.inc("gas.node:${node.name}")
                val response = executeGasPostWithFallback(
                    nodeUrl = normalizeHttpUrl(node.url),
                    envelopeBytes = envelopeBytes,
                    settings = settings,
                    cleanIp = cleanIp,
                    nodeName = node.name
                )

                response.use { res ->
                    val respText = res.body?.string().orEmpty()
                    val rtt = ((System.nanoTime() - t0) / 1_000_000L).toInt().coerceAtLeast(1)
                    recordTraffic(upBytes = 0L, downBytes = respText.toByteArray().size.toLong())
                    if (!res.isSuccessful) {
                        if (res.code == 429) coolDownNode(node.url, node.name, 300_000L, "HTTP 429")
                        lastErr = if (res.code == 403 || res.code == 401) {
                            build403Diagnostic(res.request.url.toString(), respText)
                        } else {
                            "HTTP ${res.code}"
                        }
                        TunnelLogger.e(
                            LogCategory.GAS,
                            "RELAY-${res.code}",
                            "خطای رله روی «${node.name}»: $lastErr",
                            "Target=$targetUrl\nFinalURL=${res.request.url}\nSnippet=${respText.take(250)}"
                        )
                        failedRequests.incrementAndGet(); TunnelStats.inc("gas.failed")
                        continue
                    }
                    if (respText.trimStart().startsWith("<")) {
                        lastErr = "پاسخ HTML غیرمنتظره از گوگل (دسترسی Web App را روی Anyone بگذارید)"
                        TunnelLogger.e(
                            LogCategory.GAS,
                            "RELAY-HTML",
                            "پاسخ غیر JSON از «${node.name}»",
                            "FinalURL=${res.request.url}\nSnippet=${respText.take(250)}"
                        )
                        failedRequests.incrementAndGet(); TunnelStats.inc("gas.failed")
                        continue
                    }
                    val outer = JSONObject(respText)
                    if (!outer.optBoolean("ok", false)) {
                        lastErr = outer.optString("error", "gas_error")
                        if (useMac && (lastErr == "invalid_auth_or_encryption" || lastErr == "hmac_auth_failed")) {
                            // Old script deployment without the "mac" fast path: remember and retry with full encryption
                            macUnsupportedNodes.add(node.url)
                            TunnelLogger.w(LogCategory.GAS, "MAC-FALLBACK", "«${node.name}» حالت MAC را پشتیبانی نمی‌کند؛ اسکریپت را دوباره Deploy کنید", lastErr)
                            return@withContext relaySingleUncached(targetUrl, method, headers, bodyBytes, followRedirects, nodeOffset)
                        }
                        coolDownIfQuota(node.url, node.name, lastErr)
                        TunnelLogger.e(LogCategory.GAS, "RELAY-ERR", "خطای اسکریپت «${node.name}»: $lastErr", "Target=$targetUrl")
                        failedRequests.incrementAndGet(); TunnelStats.inc("gas.failed")
                        continue
                    }
                    val respDataB64 = outer.optString("data", "")
                    var decoded = Base64.decode(respDataB64, Base64.DEFAULT)
                    if (outer.optBoolean("enc", false)) {
                        decoded = TunnelCrypto.decryptStreamHmac(decoded, node.secretKey)
                            ?: throw IllegalStateException("HMAC verification failed")
                    }
                    val rawRespSize = decoded.size
                    if (outer.optString("comp") == "gzip") {
                        decoded = TunnelCrypto.decompressGzip(decoded)
                    }
                    recordTraffic(upBytes = 0L, downBytes = 0L, rawPayload = decoded.size.toLong(), compressedPayload = rawRespSize.toLong())
                    val innerResp = JSONObject(String(decoded, Charsets.UTF_8))
                    val statusCode = innerResp.optInt("status", 200)
                    var outBody = Base64.decode(innerResp.optString("bodyB64", ""), Base64.DEFAULT)
                    if (innerResp.optString("bodyEnc") == "gzip" && outBody.isNotEmpty()) {
                        outBody = TunnelCrypto.decompressGzip(outBody)
                    }
                    val respHeaders = mutableListOf<Pair<String, String>>()
                    val hdrObj = innerResp.optJSONObject("headers")
                    if (hdrObj != null) {
                        val keys = hdrObj.keys()
                        while (keys.hasNext()) {
                            val k = keys.next()
                            val v = hdrObj.opt(k)
                            when (v) {
                                is org.json.JSONArray -> {
                                    for (i in 0 until v.length()) {
                                        respHeaders.add(k to v.optString(i))
                                    }
                                }
                                null, JSONObject.NULL -> {}
                                else -> respHeaders.add(k to v.toString())
                            }
                        }
                    }
                    nodeCooldownUntil.remove(node.url)
                    if (!(isTelegramRpc && rtt > 8_000)) {
                        recordNodeLatency(normalizeHttpUrl(node.url), rtt)
                        TunnelStats.sample("t.gasRtt", rtt.toLong())
                    }
                    updateLatencyStats(rtt)
                    TunnelLogger.i(
                        LogCategory.GAS,
                        "RELAY-OK",
                        "رله موفق از «${node.name}» (${rtt}ms • $statusCode)",
                        "Target=$targetUrl, Raw=${innerJson.size}B -> Comp=${compressed.compressedSize}B, Resp=${outBody.size}B"
                    )
                    return@withContext GasRelayResponse(true, statusCode, outBody, respHeaders)
                }
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                failedRequests.incrementAndGet(); TunnelStats.inc("gas.failed")
                // a long-poll read timeout on a Telegram RPC is normal, not a sign the script is bad
                if (!(isTelegramRpc && e is java.net.SocketTimeoutException)) {
                    nodeCooldownUntil[node.url] = System.currentTimeMillis() + 10_000L
                }
                lastErr = e.localizedMessage ?: "خطای انتقال"
                TunnelLogger.e(
                    LogCategory.GAS,
                    "RELAY-EXC",
                    "استثنا در رله «${node.name}»: $lastErr",
                    "Target=$targetUrl\nCleanIP=${cleanIp.ifBlank { "system-dns" }}\nException=${e.javaClass.simpleName}: ${e.message}"
                )
            }
        }
        GasRelayResponse(false, 502, ByteArray(0), error = lastErr)
        } finally {
            if (!isTelegramRpc) {
                gasRelayInFlight.decrementAndGet()
                gasSlotSignal.trySend(Unit)
            }
        }
    }

    private fun executeGasPostWithFallback(
        nodeUrl: String,
        envelopeBytes: ByteArray,
        settings: BypassSettings,
        cleanIp: String,
        nodeName: String
    ): okhttp3.Response {
        val inflight = nodeInFlight.getOrPut(nodeUrl) { AtomicInteger(0) }
        inflight.incrementAndGet()
        try {
        val req = Request.Builder()
            .url(nodeUrl)
            .post(envelopeBytes.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        val client = BypassOkHttpFactory.createClient(settings = settings, overrideCleanIp = cleanIp, readTimeoutMs = 45_000L, reuse = true)
        return try {
            client.newCall(req).execute()
        } catch (e: SSLPeerUnverifiedException) {
            if (cleanIp.isNotBlank()) BypassOkHttpFactory.markBadCleanIp(cleanIp)
            if (cleanIp.isBlank()) throw e
            TunnelLogger.w(
                LogCategory.GAS,
                "RELAY-FALLBACK",
                "آی‌پی تمیز ($cleanIp) خطای SSL داد؛ تلاش مجدد «$nodeName» با DNS مستقیم",
                e.localizedMessage
            )
            val fallbackClient = BypassOkHttpFactory.createClient(settings = settings, disableCleanIp = true, readTimeoutMs = 45_000L, reuse = true)
            fallbackClient.newCall(req).execute()
        }
        } finally {
            inflight.decrementAndGet()
        }
    }

    suspend fun resolveDohPacket(dnsQueryWire: ByteArray): ByteArray? = withContext(Dispatchers.IO) {
        if (dnsQueryWire.size < 12) return@withContext null
        val cacheKey = Base64.encodeToString(dnsQueryWire.copyOfRange(12, dnsQueryWire.size), Base64.NO_WRAP)
        val cached = dnsCache[cacheKey]
        if (cached != null && System.currentTimeMillis() - cached.first < 1_800_000L) {
            val copy = cached.second.copyOf()
            if (copy.size >= 2) {
                copy[0] = dnsQueryWire[0]
                copy[1] = dnsQueryWire[1]
            }
            return@withContext copy
        }

        val settings = currentSettings
        // 1. Try GAS DoH first whenever any GAS_SCRIPT endpoint is active (unpoisoned Google-side DNS)
        val gasNodes = selectOrderedCandidates(EndpointType.GAS_SCRIPT)
            .filter { it.endpointType == EndpointType.GAS_SCRIPT }
        for (node in gasNodes) {
            runCatching {
                val inner = JSONObject().apply {
                    put("action", "doh")
                    put("dnsB64", Base64.encodeToString(dnsQueryWire, Base64.NO_WRAP))
                }.toString().toByteArray(Charsets.UTF_8)
                val encrypted = TunnelCrypto.encryptStreamHmac(inner, node.secretKey)
                val env = JSONObject().apply {
                    put("enc", true)
                    put("comp", "none")
                    put("data", Base64.encodeToString(encrypted, Base64.NO_WRAP))
                }.toString()
                val cleanIp = if (settings.cleanIpBinding) node.customCleanIp.ifBlank { settings.activeCleanGoogleIp }.trim() else ""
                TunnelStats.inc("gas.invocations")
                TunnelStats.inc("gas.urlFetches")
                executeGasPostWithFallback(
                    nodeUrl = normalizeHttpUrl(node.url),
                    envelopeBytes = env.toByteArray(Charsets.UTF_8),
                    settings = settings,
                    cleanIp = cleanIp,
                    nodeName = node.name
                ).use { res ->
                    val bodyStr = res.body?.string().orEmpty()
                    if (res.isSuccessful && !bodyStr.trimStart().startsWith("<")) {
                        val outer = JSONObject(bodyStr)
                        if (outer.optBoolean("ok", false)) {
                            var bytes = Base64.decode(outer.getString("data"), Base64.DEFAULT)
                            bytes = TunnelCrypto.decryptStreamHmac(bytes, node.secretKey) ?: return@use
                            if (outer.optString("comp") == "gzip") bytes = TunnelCrypto.decompressGzip(bytes)
                            val parsed = JSONObject(String(bytes, Charsets.UTF_8))
                            val ans = Base64.decode(parsed.getString("dnsB64"), Base64.DEFAULT)
                            if (!containsPoisonedIranIp(ans)) {
                                recordTraffic(env.length.toLong(), ans.size.toLong())
                                dnsCache[cacheKey] = System.currentTimeMillis() to ans.copyOf()
                                com.example.core.logging.TunnelStats.inc("dns.ok")
                                return@withContext ans
                            }
                        } else {
                            TunnelLogger.w(LogCategory.DNS_DOH, "DOH-GAS-FAIL", "پاسخ ناموفق DoH از «${node.name}»", outer.optString("error"))
                        }
                    } else {
                        TunnelLogger.w(LogCategory.DNS_DOH, "DOH-GAS-HTTP", "خطای DoH در «${node.name}»: HTTP ${res.code}")
                    }
                }
            }.onFailure { err ->
                TunnelLogger.w(LogCategory.DNS_DOH, "DOH-GAS-ERR", "خطای DoH در «${node.name}»", err.localizedMessage)
            }
        }

        // 2. Try Direct DoH by IP (8.8.8.8 & 1.1.1.1) + settings.dohUrl with TLS Fragmentation
        val dohTargets = listOf("https://8.8.8.8/dns-query", "https://1.1.1.1/dns-query", settings.dohUrl).distinct()
        for (url in dohTargets) {
            val ans = runCatching {
                val client = BypassOkHttpFactory.createClient(
                    settings = settings,
                    connectTimeoutMs = 3_500L,
                    readTimeoutMs = 4_500L,
                    disableCleanIp = url.contains("8.8.8.8") || url.contains("1.1.1.1")
                )
                val req = Request.Builder()
                    .url(url)
                    .header("Accept", "application/dns-message")
                    .post(dnsQueryWire.toRequestBody("application/dns-message".toMediaType()))
                    .build()
                client.newCall(req).execute().use { res ->
                    if (res.isSuccessful) res.body?.bytes() else null
                }
            }.getOrNull()

            if (ans != null && ans.size >= 12 && !containsPoisonedIranIp(ans)) {
                recordTraffic(dnsQueryWire.size.toLong(), ans.size.toLong())
                dnsCache[cacheKey] = System.currentTimeMillis() to ans.copyOf()
                com.example.core.logging.TunnelStats.inc("dns.ok")
                return@withContext ans
            }
        }

        // 3. Last resort: UDP 8.8.8.8:53 (rejecting 10.10.34.* poisoned responses)
        val udpAns = resolveUdpDnsFallback(dnsQueryWire, "8.8.8.8")
        if (udpAns != null) {
            dnsCache[cacheKey] = System.currentTimeMillis() to udpAns.copyOf()
        }
        return@withContext udpAns
    }

    private fun resolveUdpDnsFallback(dnsQueryWire: ByteArray, dnsServerIp: String): ByteArray? {
        return runCatching {
            DatagramSocket().use { sock ->
                BypassOkHttpFactory.datagramProtector?.invoke(sock)
                sock.soTimeout = 3_000
                val addr = InetAddress.getByName(dnsServerIp)
                sock.send(DatagramPacket(dnsQueryWire, dnsQueryWire.size, addr, 53))
                val buf = ByteArray(2048)
                val resp = DatagramPacket(buf, buf.size)
                sock.receive(resp)
                val ans = buf.copyOf(resp.length)
                if (containsPoisonedIranIp(ans)) {
                    com.example.core.logging.TunnelStats.inc("dns.poison")
                    TunnelLogger.w(LogCategory.DNS_DOH, "DNS-POISON", "پاسخ جعلی 10.10.34.x از $dnsServerIp مسدود شد")
                    return@runCatching null
                }
                recordTraffic(dnsQueryWire.size.toLong(), ans.size.toLong())
                TunnelLogger.d(LogCategory.DNS_DOH, "DNS-8888", "پاسخ DNS از $dnsServerIp (${ans.size}B)")
                ans
            }
        }.onFailure { err ->
            TunnelLogger.w(LogCategory.DNS_DOH, "DNS-UDP-ERR", "خطای DNS $dnsServerIp", err.localizedMessage)
        }.getOrNull()
    }

    private fun containsPoisonedIranIp(dnsWire: ByteArray): Boolean {
        // Detect 10.10.34.x (0x0A 0x0A 0x22 xx) anywhere in RDATA of A records
        for (i in 12 until dnsWire.size - 3) {
            if (dnsWire[i] == 10.toByte() && dnsWire[i + 1] == 10.toByte() && dnsWire[i + 2] == 34.toByte()) {
                return true
            }
        }
        return false
    }

    private val wsClientCache = java.util.concurrent.ConcurrentHashMap<String, okhttp3.OkHttpClient>()

    // ---- Pre-warmed WebSocket pool: removes the TLS+upgrade handshake from every new TCP stream ----
    private class WarmWs(val url: String, val secret: String) : WebSocketListener() {
        @Volatile var delegate: WebSocketListener? = null
        @Volatile var dead = false
        @Volatile var ws: WebSocket? = null
        @Volatile var createdAt = System.currentTimeMillis()
        // true until the socket became ready/failed; guards warmingCount against double-decrement
        val warming = java.util.concurrent.atomic.AtomicBoolean(true)
        var onIdleReady: ((WarmWs) -> Unit)? = null
        var onIdleGone: ((WarmWs) -> Unit)? = null

        override fun onOpen(webSocket: WebSocket, response: okhttp3.Response) {
            ws = webSocket
            val d = delegate
            if (d != null) d.onOpen(webSocket, response) else onIdleReady?.invoke(this)
        }
        override fun onMessage(webSocket: WebSocket, text: String) { delegate?.onMessage(webSocket, text) }
        override fun onMessage(webSocket: WebSocket, bytes: okio.ByteString) { delegate?.onMessage(webSocket, bytes) }
        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            dead = true
            val d = delegate
            if (d != null) d.onClosing(webSocket, code, reason) else onIdleGone?.invoke(this)
        }
        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            dead = true
            delegate?.onClosed(webSocket, code, reason)
        }
        override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) {
            dead = true
            val d = delegate
            if (d != null) d.onFailure(webSocket, t, response) else onIdleGone?.invoke(this)
        }
    }

    private val warmQueue = java.util.concurrent.ConcurrentLinkedQueue<WarmWs>()
    private val warmingCount = AtomicInteger(0)
    @Volatile private var warmEnabled = false
    // Lean pool: a few ready sockets are enough to hide the handshake; more only burns CPU/battery.
    private val warmTarget = 3
    private val warmMaxAgeMs = 45_000L
    // Stop topping up the pool when nothing has asked for a socket recently (screen off / idle).
    private val warmIdleStopMs = 20_000L
    private val refillRunning = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var lastDemandAt = 0L

    private fun clearWarmPool() {
        warmEnabled = false
        while (true) {
            val w = warmQueue.poll() ?: break
            runCatching { w.ws?.cancel() }
        }
    }

    private fun refillWarmPool(endpoint: ServerEndpointEntity) {
        if (!warmEnabled) return
        // Single-flight: before, every new connection started its own refill loop, so a burst of
        // 30 connections opened hundreds of sockets (ws-opened=368 for 34 real connections).
        if (!refillRunning.compareAndSet(false, true)) return
        scope.launch {
            try {
                while (warmEnabled &&
                    System.currentTimeMillis() - lastDemandAt < warmIdleStopMs &&
                    warmQueue.size + warmingCount.get() < warmTarget
                ) {
                    warmingCount.incrementAndGet()
                    val w = WarmWs(endpoint.url, endpoint.secretKey)
                    w.onIdleReady = { if (it.warming.compareAndSet(true, false)) warmingCount.decrementAndGet(); if (warmEnabled) warmQueue.add(it) else it.ws?.cancel() }
                    w.onIdleGone = { if (it.warming.compareAndSet(true, false)) warmingCount.decrementAndGet(); warmQueue.remove(it) }
                    runCatching { openWorkerWebSocket(endpoint, w) }.onFailure { if (w.warming.compareAndSet(true, false)) warmingCount.decrementAndGet() }
                    delay(150)
                }
            } finally {
                refillRunning.set(false)
            }
        }
    }

    /**
     * Returns a WebSocket ready for CONNECT. A pre-warmed idle socket is used when available
     * (onWarm is called immediately), otherwise a new one is opened (listener.onOpen fires later).
     */
    fun rotateCfCleanIp(failedIp: String): String? {
        val next = CleanIpScanner.rotateNextCleanIp(com.example.data.model.IpProvider.CLOUDFLARE, failedIp) ?: return null
        currentSettings = currentSettings.copy(activeCleanCfIp = next, cleanIpBinding = true)
        wsClientCache.clear()
        clearWarmPool()
        TunnelLogger.w(
            LogCategory.TLS_IP,
            "CLEAN-IP-ROTATE",
            "چرخش خودکار آی‌پی تمیز کلودفلر: $failedIp -> $next"
        )
        return next
    }

    fun acquireWorkerWebSocket(
        endpoint: ServerEndpointEntity,
        listener: WebSocketListener,
        onWarm: (WebSocket) -> Unit
    ): WebSocket {
        warmEnabled = true
        val now = System.currentTimeMillis()
        lastDemandAt = now
        while (true) {
            val c = warmQueue.poll() ?: break
            val sock = c.ws
            if (c.dead || sock == null || c.url != endpoint.url || c.secret != endpoint.secretKey ||
                now - c.createdAt > warmMaxAgeMs
            ) {
                runCatching { sock?.cancel() }
                com.example.core.logging.TunnelStats.inc("pool.discard")
                continue
            }
            c.delegate = listener
            if (c.dead) { c.delegate = null; continue }
            refillWarmPool(endpoint)
            com.example.core.logging.TunnelStats.inc("pool.warm")
            onWarm(sock)
            return sock
        }
        refillWarmPool(endpoint)
        com.example.core.logging.TunnelStats.inc("pool.cold")
        val w = WarmWs(endpoint.url, endpoint.secretKey)
        w.delegate = listener
        return openWorkerWebSocket(endpoint, w)
    }

    fun openWorkerWebSocket(
        endpoint: ServerEndpointEntity,
        listener: WebSocketListener
    ): WebSocket {
        val settings = currentSettings
        val wsUrl = normalizeWsUrl(endpoint.url)
        val cleanIp = when {
            endpoint.customCleanIp.isNotBlank() -> endpoint.customCleanIp.trim()
            settings.cleanIpBinding -> settings.activeCleanCfIp.trim()
            else -> ""
        }
        TunnelStats.inc("cf.requests")
        if (TunnelStats.inc("ws.opened") == 1) {
            TunnelLogger.i(
                LogCategory.CF_WS,
                "WS-OPEN",
                "اولین WebSocket به «${endpoint.name}»",
                "URL=$wsUrl, CleanIP=${cleanIp.ifBlank { "system-dns" }}"
            )
        }
        val cacheKey = "$cleanIp|${settings.tlsFragmentation}|${settings.adaptiveKeepAlive}|${settings.cleanIpBinding}"
        val client = wsClientCache.getOrPut(cacheKey) {
            BypassOkHttpFactory.createClient(settings, overrideCleanIp = cleanIp, connectTimeoutMs = 12_000L, readTimeoutMs = 0L)
                .newBuilder()
                .dispatcher(okhttp3.Dispatcher().apply { maxRequests = 256; maxRequestsPerHost = 256 })
                // FIX: no forced protocol ping - under upload backlog the pong was starved -> false 'no pong within 30000ms' kills
                .pingInterval(0, java.util.concurrent.TimeUnit.SECONDS)
                .build()
        }
        val (effectiveWsUrl, realHostHeader) = if (endpoint.customSniHost.isNotBlank()) {
            applySniSpoofUrl(wsUrl, endpoint.customSniHost)
        } else {
            wsUrl to null
        }
        val req = Request.Builder()
            .url(effectiveWsUrl)
            .header("X-Tunnel-Auth", endpoint.secretKey)
            .apply {
                // Real SNI Spoofing: TLS SNI = customSniHost (effectiveWsUrl), encrypted HTTP Host = real Worker host
                if (realHostHeader != null) {
                    header("Host", realHostHeader)
                }
            }
            .build()
        return client.newWebSocket(req, listener)
    }

    private fun updateLatencyStats(newRtt: Int) {
        val prev = lastLatencyMs
        lastJitterMs = if (prev == 0) 0 else abs(newRtt - prev)
        lastLatencyMs = if (prev == 0) newRtt else ((prev * 0.7f) + (newRtt * 0.3f)).toInt()
    }

    private fun computeStabilityScore(
        latencyMs: Int,
        jitterMs: Int,
        lossPct: Float,
        activeCount: Int
    ): Float {
        if (activeCount == 0) return 0f
        val latencyPenalty = (latencyMs / 25f).coerceAtMost(30f)
        val jitterPenalty = (jitterMs / 10f).coerceAtMost(20f)
        val lossPenalty = (lossPct * 1.5f).coerceAtMost(45f)
        val redundancyBonus = ((activeCount - 1) * 3f).coerceAtMost(9f)
        return (100f - latencyPenalty - jitterPenalty - lossPenalty + redundancyBonus).coerceIn(5f, 100f)
    }

    private fun buildPoolLabel(pool: List<ServerEndpointEntity>): String {
        return when {
            pool.isEmpty() -> "بدون سرور فعال"
            pool.size == 1 -> pool.first().name
            else -> "${pool.first().name} + ${pool.size - 1} موازی"
        }
    }

    private fun applySniSpoofUrl(rawUrl: String, customSniHost: String): Pair<String, String?> {
        val spoof = customSniHost.trim()
            .removePrefix("https://")
            .removePrefix("http://")
            .removePrefix("wss://")
            .removePrefix("ws://")
            .substringBefore('/')
            .substringBefore(':')
            .trim()
        if (spoof.isBlank()) return rawUrl to null
        val parsed = runCatching { java.net.URI(rawUrl) }.getOrNull() ?: return rawUrl to null
        val realHost = parsed.host ?: return rawUrl to null
        if (realHost.equals(spoof, ignoreCase = true)) return rawUrl to null
        val spoofedUrl = runCatching {
            java.net.URI(parsed.scheme, parsed.userInfo, spoof, parsed.port, parsed.rawPath, parsed.rawQuery, parsed.rawFragment).toString()
        }.getOrNull() ?: return rawUrl to null
        return spoofedUrl to realHost
    }

    private fun normalizeHttpUrl(raw: String): String {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("wss://") -> "https://" + trimmed.removePrefix("wss://")
            trimmed.startsWith("ws://") -> "http://" + trimmed.removePrefix("ws://")
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            else -> "https://$trimmed"
        }
    }

    private fun normalizeWsUrl(raw: String): String {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("https://") -> "wss://" + trimmed.removePrefix("https://")
            trimmed.startsWith("http://") -> "ws://" + trimmed.removePrefix("http://")
            trimmed.startsWith("wss://") || trimmed.startsWith("ws://") -> trimmed
            else -> "wss://$trimmed"
        }
    }
}
