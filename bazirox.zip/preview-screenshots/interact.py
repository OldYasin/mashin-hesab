import json
from playwright.sync_api import sync_playwright
from shot import HTML, MOCK, GAME

def touch(cdp, kind, pts):
    cdp.send('Input.dispatchTouchEvent', {'type':kind, 'touchPoints':[{'x':x,'y':y,'id':i} for i,(x,y) in pts.items()]})

with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={'width':390,'height':844}, device_scale_factor=2, has_touch=True, is_mobile=True)
    pg = ctx.new_page(); pg.add_init_script(MOCK); pg.add_init_script(GAME % 24)
    pg.goto(HTML); pg.wait_for_timeout(200)
    base = dict(neo=False,net=True,room='A7K3Q',slot=1,peerOn=True,ping=42,p2=False,slotNo=2,slotFull=True,name1='یاسین',name2='رضا',sat=24,sab=16)
    pg.evaluate("s=>EMU.state(s)", base)
    cdp = ctx.new_cdp_session(pg)
    def centre(sel, i=None):
        r = pg.evaluate("""([sel,i])=>{var e=i===null?document.querySelector(sel):document.querySelectorAll(sel)[i];var r=e.getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2]}""",[sel,i])
        return r
    log = lambda: pg.evaluate("window.__log.splice(0)")
    res = {}

    # 1) tap A and hold, then add B (two buttons), then release A, then B
    a = centre('.fb',3); bb = centre('.fb',4)
    touch(cdp,'touchStart',{1:a}); pg.wait_for_timeout(60)
    touch(cdp,'touchStart',{1:a,2:bb}); pg.wait_for_timeout(100)
    pg.screenshot(path='press_AB.png')
    touch(cdp,'touchEnd',{2:bb}); pg.wait_for_timeout(40)
    touch(cdp,'touchEnd',{}); pg.wait_for_timeout(40)
    res['AB_hold_release'] = log()

    # 2) roll the thumb from A to B without lifting
    touch(cdp,'touchStart',{1:a}); pg.wait_for_timeout(30)
    touch(cdp,'touchMove',{1:((a[0]+bb[0])/2,(a[1]+bb[1])/2)}); pg.wait_for_timeout(30)
    touch(cdp,'touchMove',{1:bb}); pg.wait_for_timeout(30)
    touch(cdp,'touchEnd',{}); pg.wait_for_timeout(30)
    res['roll_A_to_B'] = log()

    # 3) D-pad: right, then slide to up-right? (no diagonals unless both axes beyond zone), then up, release
    d = pg.evaluate("(()=>{var r=document.getElementById('dpadBox').getBoundingClientRect();return [r.left,r.top,r.width,r.height]})()")
    cx,cy = d[0]+d[2]/2, d[1]+d[3]/2
    touch(cdp,'touchStart',{1:(cx+d[2]*.35,cy)}); pg.wait_for_timeout(30)
    pg.screenshot(path='press_right.png')
    touch(cdp,'touchMove',{1:(cx+d[2]*.3,cy-d[3]*.3)}); pg.wait_for_timeout(30)   # diagonal
    touch(cdp,'touchMove',{1:(cx,cy-d[3]*.4)}); pg.wait_for_timeout(30)
    touch(cdp,'touchEnd',{}); pg.wait_for_timeout(30)
    res['dpad'] = log()

    # 4) START + dpad left + A at once (3 fingers)
    st = centre('.sb',1); lf=(cx-d[2]*.35,cy)
    touch(cdp,'touchStart',{1:lf,2:a,3:st}); pg.wait_for_timeout(40)
    res['three_fingers_down'] = log()
    touch(cdp,'touchEnd',{}); pg.wait_for_timeout(40)
    res['three_fingers_up'] = log()

    # 5) pointercancel / blur safety: hold A then blur
    touch(cdp,'touchStart',{1:a}); pg.wait_for_timeout(30); log()
    pg.evaluate("window.dispatchEvent(new Event('blur'))"); pg.wait_for_timeout(30)
    res['blur_releases'] = log()
    touch(cdp,'touchEnd',{})

    # 6) chat send from inline composer
    pg.fill('#inI','سلام!'); pg.click('#sendI'); pg.wait_for_timeout(60)
    res['chat_send'] = log()
    print(json.dumps(res, ensure_ascii=False, indent=1))
    b.close()
