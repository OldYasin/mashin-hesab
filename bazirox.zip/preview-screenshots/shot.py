import sys, json
from playwright.sync_api import sync_playwright

HTML = "file:///home/claude/bz/baz/app/src/main/assets/emu_ui/index.html"
MOCK = """
window.__log=[];
window.Android={pad:function(m){window.__log.push(['pad',m])},act:function(a){window.__log.push(['act',a])},
 chat:function(t){window.__log.push(['chat',t])},chatOpen:function(b){window.__log.push(['chatOpen',b])},ready:function(){}};
"""
GAME = """
(function(){
 function add(){
  var land = innerWidth>innerHeight, sat=%d;
  var d=document.createElement('div'); d.id='fakegame';
  var w = land ? innerHeight*320/224 : innerWidth, h = land ? innerHeight : innerWidth*224/320;
  d.style.cssText='position:fixed;z-index:-1;left:'+((innerWidth-w)/2)+'px;top:'+(land?0:sat)+'px;width:'+w+'px;height:'+h+'px;background:linear-gradient(#5aa9ff 0 55%%,#2e8b3a 55%% 100%%);overflow:hidden';
  d.innerHTML='<div style="position:absolute;left:12%%;top:48%%;width:14%%;height:24%%;background:#e44;border-radius:6px"></div><div style="position:absolute;right:15%%;top:40%%;width:12%%;height:30%%;background:#fc3;border-radius:6px"></div><div style="position:absolute;left:0;right:0;top:8%%;text-align:center;font:700 22px monospace;color:#fff;opacity:.8">GAME SCREEN 320x224</div>';
  document.body.prepend(d);
  document.body.style.background='#0b1020';
 }
 if(document.readyState!='loading') add(); else document.addEventListener('DOMContentLoaded',add);
})();
"""
def run(name, w, h, state, msgs=None, actions=None, sat=24, sab=16):
    with sync_playwright() as p:
        b = p.chromium.launch()
        ctx = b.new_context(viewport={'width':w,'height':h}, device_scale_factor=2, has_touch=True, is_mobile=True)
        pg = ctx.new_page()
        pg.add_init_script(MOCK)
        pg.add_init_script(GAME % sat)
        pg.goto(HTML)
        pg.wait_for_timeout(300)
        st = dict(state); st.update({'sat':sat,'sab':sab})
        pg.evaluate("s=>EMU.state(s)", st)
        if msgs:
            for slot,t in msgs: pg.evaluate("([s,t])=>EMU.addMsg(s,t)", [slot,t])
        if actions: actions(pg)
        pg.wait_for_timeout(500)
        pg.screenshot(path=f'/home/claude/preview/{name}.png')
        log = pg.evaluate("window.__log")
        b.close()
        return log

if __name__=='__main__':
    base = dict(neo=False,net=False,room='',slot=0,peerOn=False,ping=0,p2=False,slotNo=1,slotFull=False,name1='P1',name2='P2')
    online = dict(base, net=True, room='A7K3Q', slot=1, peerOn=True, ping=42, name1='یاسین', name2='رضا')
    M=[(2,'سلام داداش آماده‌ای؟'),(1,'آره بزن شروع کنیم'),(2,'این دفعه نمیذارم ببری 😈'),(1,'ببینیم چی میشه'),(2,'GG')]
    run('sega_offline', 390, 844, base)
    run('sega_online', 390, 844, online, M)
    run('neo_online', 390, 844, dict(online, neo=True, room='B4MX9'), M)
    run('land_offline', 844, 390, base)
    run('land_online', 844, 390, online, M)
    print('done')
