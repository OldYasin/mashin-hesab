// Bazirox netplay relay - Node.js version (replaces the Cloudflare Worker)
// Protocol is the same as NetplayClient.kt: /ws?room=CODE , /probe
const http = require('http');
const { WebSocketServer } = require('ws');

const rooms = new Map(); // code -> [ws|null, ws|null]

// The host may pass the full path (/netplay/probe); keep only the last part (/probe, /ws)
function cleanPath(p) {
  const last = p.replace(/\/+$/, '').split('/').pop();
  return last ? '/' + last : '/';
}

// --- debug log (last 30 requests) ---
const LOG = [];
function note(kind, req) {
  const h = req.headers || {};
  LOG.push({
    t: new Date().toISOString().slice(11, 19),
    kind,
    method: req.method,
    url: req.url,
    connection: h['connection'] || null,
    upgrade: h['upgrade'] || null,
    key: h['sec-websocket-key'] ? 'yes' : null,
    httpVersion: req.httpVersion,
  });
  if (LOG.length > 30) LOG.shift();
}

const server = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  note('request', req);
  if (cleanPath(u.pathname) === '/debug') {
    res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    return res.end(JSON.stringify(LOG, null, 1));
  }
  if (cleanPath(u.pathname) === '/probe') {
    res.writeHead(200, { 'content-type': 'text/plain', 'cache-control': 'no-store' });
    return res.end('ok');
  }
  if (cleanPath(u.pathname) === '/test') {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    return res.end(TEST_PAGE);
  }
  res.writeHead(200, { 'content-type': 'text/plain' });
  res.end('bazirox netplay relay');
});

const TEST_PAGE = `<!doctype html><meta name=viewport content="width=device-width"><body style="font:16px sans-serif;padding:16px"><h3>WebSocket test</h3><pre id=o></pre><script>
var o=document.getElementById('o');function log(m){o.textContent+=m+'\\n'}
var base=location.pathname.replace(/\\/test\\/?$/,'');
var url=(location.protocol==='https:'?'wss://':'ws://')+location.host+base+'/ws?room=TEST1';
log('connecting: '+url);
var w=new WebSocket(url);
w.onopen=function(){log('OPEN')};
w.onmessage=function(e){log('MSG: '+e.data)};
w.onerror=function(){log('ERROR')};
w.onclose=function(e){log('CLOSE code='+e.code)};
</script></body>`;

const wss = new WebSocketServer({ noServer: true, maxPayload: 8 * 1024 * 1024, perMessageDeflate: false });

server.on('upgrade', (req, socket, head) => {
  note('UPGRADE', req);
  const u = new URL(req.url, 'http://x');
  const room = u.searchParams.get('room') || '';
  if (cleanPath(u.pathname) !== '/ws' || !/^[A-Za-z0-9]{3,16}$/.test(room)) {
    socket.write('HTTP/1.1 400 Bad Request\r\n\r\n');
    return socket.destroy();
  }
  const slots = rooms.get(room) || [null, null];
  if (slots[0] && slots[1]) {
    socket.write('HTTP/1.1 409 Conflict\r\nContent-Length: 0\r\n\r\n');
    return socket.destroy();
  }
  wss.handleUpgrade(req, socket, head, (ws) => onConnect(ws, room));
});

function peerOf(room, ws) {
  const s = rooms.get(room);
  if (!s) return null;
  const other = s[0] === ws ? s[1] : s[0];
  return other && other.readyState === 1 ? other : null;
}

function onConnect(ws, room) {
  try { ws._socket.setNoDelay(true); } catch (e) {} // send small key messages immediately
  const slots = rooms.get(room) || [null, null];
  const idx = slots[0] ? 1 : 0;
  slots[idx] = ws;
  rooms.set(room, slots);
  ws.isAlive = true;
  ws.on('pong', () => (ws.isAlive = true));

  const peers = (slots[0] ? 1 : 0) + (slots[1] ? 1 : 0);
  ws.send(JSON.stringify({ t: 'hello', slot: idx + 1, peers }));
  const other = peerOf(room, ws);
  if (other) other.send(JSON.stringify({ t: 'peer', on: 1 }));

  ws.on('message', (data, isBinary) => {
    const o = peerOf(room, ws);
    if (!isBinary) {
      const text = data.toString();
      if (text.charCodeAt(0) === 123 && text.includes('"t":"p"')) {
        // server ping: echo back to sender, and forward to the other player (he answers with "q")
        try {
          const j = JSON.parse(text);
          if (j.t === 'p') ws.send(JSON.stringify({ t: 's', ts: j.ts }));
        } catch (e) {}
      }
      if (o) o.send(text);
    } else if (o) {
      // A save-state is big. If the previous one is still on its way to a slow peer, drop this one:
      // otherwise key presses queue up behind it and the peer's game stutters.
      if (data.length >= 13 && data[0] === 1) {
        // chunked state: [1][id:4][idx:2][total:2][base:4][payload]
        if (o.bufferedAmount > 16 * 1024 * 1024) return o.terminate();
        o.send(data, { binary: true });
      } else {
        // CRITICAL: Type 2 (lockstep frame input) and Type 3 (lockstep frame hash) must NEVER be dropped!
        const type = data.length > 0 ? data[0] : 0;
        const isLockstep = type === 2 || type === 3;
        if (!isLockstep && o.bufferedAmount > 200 * 1024) return;
        o.send(data, { binary: true });
      }
    }
  });

  ws.on('close', () => {
    const s = rooms.get(room);
    if (!s) return;
    if (s[0] === ws) s[0] = null;
    if (s[1] === ws) s[1] = null;
    if (!s[0] && !s[1]) rooms.delete(room);
    else {
      const o = s[0] || s[1];
      if (o && o.readyState === 1) o.send(JSON.stringify({ t: 'peer', on: 0 }));
    }
  });
  ws.on('error', () => {});
}

// drop dead connections
setInterval(() => {
  wss.clients.forEach((ws) => {
    if (!ws.isAlive) return ws.terminate();
    ws.isAlive = false;
    ws.ping();
  });
}, 30000);

server.listen(process.env.PORT || 3000);
