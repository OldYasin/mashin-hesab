package com.example.data

import android.graphics.Bitmap
import android.util.Base64
import android.util.LruCache
import com.example.security.CryptoManager
import java.io.File
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Coordinates local encrypted SecureVault and remote Iranian cPanel API.
 * Instant local-first UX with zero lag, plus live cPanel sync whenever configured.
 */
class MainRepository(
  private val vault: SecureVault,
  private val api: CPanelApiClient = CPanelApiClient(),
  private val imageDir: File? = null,
) {

  /** Latest per-user read marks of the last fetched chat (drives double blue ticks). */
  @Volatile var lastReads: Map<String, Long> = emptyMap()
    private set

  private fun imageFile(messageId: String): File? =
    imageDir?.let { File(it, "$messageId.jpg") }

  private fun serverOn(config: CPanelConfig) = config.apiBaseUrl.isNotBlank() && config.isConnected

  fun loadConfig(): CPanelConfig = vault.loadCPanelConfig()

  fun saveConfig(config: CPanelConfig) = vault.saveCPanelConfig(config)

  suspend fun testCPanelConnection(config: CPanelConfig): PingResult {
    val result = api.ping(config)
    val updated =
      config.copy(
        lastTestStatus = result.message,
        lastTestLatencyMs = result.latencyMs,
        isConnected = result.success,
      )
    vault.saveCPanelConfig(updated)
    return result
  }

  fun loadSession(): UserAccount? =
    vault.loadSession()?.also { api.authToken = it.authToken }

  fun logout() {
    api.authToken = ""
    vault.saveSession(null)
  }

  /** Device-local admin gate (slow PBKDF2 + lockout); nothing about it is stored in the APK. */
  fun adminAuth(password: String): AdminAuthResult = vault.adminAuth(password)

  /** Decrypts group name/preview with the local group key and builds the full invite code. */
  private fun decorateGroup(g: ChatGroup): ChatGroup {
    val key = vault.loadGroupKey(g.id)
    if (key == null) {
      return g.copy(
        name = if (g.name.startsWith("e1:")) "گروه رمزنگاری‌شده" else g.name,
        lastMessagePreview = if (g.lastMessagePreview.startsWith("e1:")) "" else g.lastMessagePreview,
      )
    }
    val name =
      if (g.name.startsWith("e1:")) {
        CryptoManager.e2eeDecrypt(g.name, key, CPanelApiClient.AAD_GROUP_NAME) ?: "گروه رمزنگاری‌شده"
      } else g.name
    val preview =
      if (g.lastMessagePreview.startsWith("e1:")) {
        CryptoManager.e2eeDecrypt(g.lastMessagePreview, key, CPanelApiClient.AAD_PREVIEW) ?: ""
      } else g.lastMessagePreview
    return g.copy(
      name = name,
      lastMessagePreview = preview,
      shareCode = g.inviteCode + "." + CryptoManager.encodeKey(key),
    )
  }

  suspend fun register(
    username: String,
    password: String,
    displayName: String,
    avatarColorIndex: Int,
  ): Result<UserAccount> {
    val cleanUser = username.trim()
    if (cleanUser.length < 3) {
      return Result.failure(IllegalArgumentException("نام کاربری باید حداقل ۳ کاراکتر باشد"))
    }
    if (password.length < 6) {
      return Result.failure(IllegalArgumentException("رمز عبور باید حداقل ۶ کاراکتر باشد"))
    }
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      val verifier =
        withContext(Dispatchers.Default) { CryptoManager.deriveLoginVerifier(cleanUser, password) }
      val remote =
        api.registerRemote(config, cleanUser, verifier, displayName.ifBlank { cleanUser }, avatarColorIndex)
      if (remote.isSuccess) {
        val acc = remote.getOrThrow()
        api.authToken = acc.authToken
        vault.saveSession(acc)
        return Result.success(acc)
      }
      return remote
    }
    return vault.registerLocalUser(cleanUser, password, displayName, avatarColorIndex)
  }

  suspend fun login(username: String, password: String): Result<UserAccount> {
    val cleanUser = username.trim()
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      val verifier =
        withContext(Dispatchers.Default) { CryptoManager.deriveLoginVerifier(cleanUser, password) }
      val remote = api.loginRemote(config, cleanUser, verifier)
      if (remote.isSuccess) {
        val acc = remote.getOrThrow()
        api.authToken = acc.authToken
        vault.saveSession(acc)
        return Result.success(acc)
      }
      // Fallback to local vault if user registered locally
      val local = vault.loginLocalUser(cleanUser, password)
      return if (local.isSuccess) local else remote
    }
    return vault.loginLocalUser(cleanUser, password)
  }

  suspend fun recordMatchResult(
    gameType: GameType,
    deltaScore: Int,
    didWin: Boolean,
  ): UserAccount? {
    val session = vault.loadSession() ?: return null
    val updated = vault.updateUserStats(session.username, deltaScore, didWin, gameType)
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      api.submitScore(config, session.authToken, session.username, gameType, deltaScore, didWin)
    }
    return updated
  }

  suspend fun getLeaderboard(currentUsername: String?): List<LeaderboardEntry> {
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      val remote = api.fetchLeaderboard(config, currentUsername)
      if (remote.isSuccess) return remote.getOrThrow()
    }
    return vault.getLocalLeaderboard(currentUsername)
  }

  // --- Chat Groups & Invites ---

  suspend fun getChatGroups(username: String?): List<ChatGroup> {
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected && !username.isNullOrBlank()) {
      val remote = api.fetchGroups(config, username)
      if (remote.isSuccess) {
        val list = remote.getOrThrow().map { decorateGroup(it) }
        vault.saveChatGroups(list)
        return list
      }
    }
    val local = vault.loadChatGroups()
    return if (username.isNullOrBlank()) local
    else local.filter { it.members.any { m -> m.equals(username, ignoreCase = true) } || it.ownerUsername.equals(username, ignoreCase = true) }
  }

  suspend fun createGroup(name: String, ownerUsername: String): Result<ChatGroup> {
    val cleanName = name.trim()
    if (cleanName.length < 2) {
      return Result.failure(IllegalArgumentException("نام گروه باید حداقل ۲ حرف باشد"))
    }
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      val key = CryptoManager.generateGroupKey()
      val encName = CryptoManager.e2eeEncrypt(cleanName, key, CPanelApiClient.AAD_GROUP_NAME)
      val remote = api.createOrJoinGroup(config, "group_create", ownerUsername, encName)
      if (remote.isSuccess) {
        val created = remote.getOrThrow()
        vault.saveGroupKey(created.id, key)
        val g = decorateGroup(created)
        vault.saveChatGroups(listOf(g) + vault.loadChatGroups().filterNot { it.id == g.id })
        return Result.success(g)
      }
      return remote
    }
    val inviteCode = CryptoManager.generateSaltHex(3).uppercase()
    val newGroup =
      ChatGroup(
        id = "grp_" + UUID.randomUUID().toString().take(8),
        name = cleanName,
        inviteCode = inviteCode,
        ownerUsername = ownerUsername,
        members = listOf(ownerUsername),
        lastMessagePreview = "گروه ساخته شد",
        lastMessageTime = System.currentTimeMillis(),
      )
    vault.saveChatGroups(listOf(newGroup) + vault.loadChatGroups())
    return Result.success(newGroup)
  }

  suspend fun joinGroupByCode(inviteCode: String, username: String): Result<ChatGroup> {
    val cleanCode = inviteCode.trim().uppercase()
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      val sep = inviteCode.trim().indexOf('.')
      val serverCode =
        (if (sep > 0) inviteCode.trim().substring(0, sep) else inviteCode.trim()).trim().uppercase()
      val key = if (sep > 0) CryptoManager.decodeKey(inviteCode.trim().substring(sep + 1).trim()) else null
      if (key == null) {
        return Result.failure(
          IllegalArgumentException("کد دعوت کامل را وارد کن (کد و کلید رمزنگاری، با یک نقطه بینشان)")
        )
      }
      val remote = api.createOrJoinGroup(config, "group_join", username, serverCode)
      if (remote.isSuccess) {
        val joined = remote.getOrThrow()
        if (CryptoManager.e2eeDecrypt(joined.name, key, CPanelApiClient.AAD_GROUP_NAME) == null) {
          return Result.failure(IllegalArgumentException("کلید رمزنگاری در کد دعوت اشتباه است"))
        }
        vault.saveGroupKey(joined.id, key)
        val g = decorateGroup(joined)
        vault.saveChatGroups(listOf(g) + vault.loadChatGroups().filterNot { it.id == g.id })
        return Result.success(g)
      }
      return remote
    }
    val existing = vault.loadChatGroups().toMutableList()
    val idx = existing.indexOfFirst { it.inviteCode.equals(cleanCode, ignoreCase = true) }
    if (idx < 0) {
      return Result.failure(IllegalArgumentException("گروهی با این کد دعوت پیدا نشد"))
    }
    val grp = existing[idx]
    val updated =
      if (grp.members.any { it.equals(username, ignoreCase = true) }) grp
      else grp.copy(members = grp.members + username)
    existing[idx] = updated
    vault.saveChatGroups(existing)
    return Result.success(updated)
  }

  suspend fun inviteMemberToGroup(groupId: String, targetUsername: String): Result<ChatGroup> {
    val cleanTarget = targetUsername.trim()
    if (cleanTarget.length < 2) {
      return Result.failure(IllegalArgumentException("نام کاربری معتبر نیست"))
    }
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      val remote = api.inviteMemberToGroup(config, groupId, cleanTarget)
      if (remote.isSuccess) {
        val g = decorateGroup(remote.getOrThrow())
        vault.saveChatGroups(vault.loadChatGroups().map { if (it.id == groupId) g else it })
        return Result.success(g)
      }
      return remote
    }
    val existing = vault.loadChatGroups().toMutableList()
    val idx = existing.indexOfFirst { it.id == groupId }
    if (idx < 0) return Result.failure(IllegalArgumentException("گروه یافت نشد"))
    val grp = existing[idx]
    val updated =
      if (grp.members.any { it.equals(cleanTarget, ignoreCase = true) }) grp
      else grp.copy(members = grp.members + cleanTarget)
    existing[idx] = updated
    vault.saveChatGroups(existing)
    return Result.success(updated)
  }

  suspend fun getMessages(groupId: String, viewer: String? = null): List<ChatMessage> {
    val config = vault.loadCPanelConfig()
    if (serverOn(config)) {
      val remote = api.fetchMessages(config, groupId, vault.loadGroupKey(groupId))
      if (remote.isSuccess) {
        val page = remote.getOrThrow()
        lastReads = page.reads
        val remoteIds = page.messages.mapTo(HashSet()) { it.id }
        // keep my not-yet-delivered / failed messages so they never "disappear" while polling
        val pending =
          vault.loadChatMessages(groupId).filter {
            it.sendState != SendState.SENT && it.id !in remoteIds
          }
        val merged = (page.messages + pending).sortedBy { it.timestamp }
        vault.saveChatMessages(groupId, merged)
        return merged
      }
    }
    return vault.loadChatMessages(groupId)
  }

  /** Saves the message locally right away (clock tick); [deliverMessage] then uploads it. */
  fun queueMessage(
    groupId: String,
    senderUsername: String,
    senderColorIndex: Int,
    text: String,
    gameInvite: GameInvite? = null,
    draftImage: File? = null,
    replyTo: ChatMessage? = null,
  ): Pair<ChatMessage, List<ChatMessage>> {
    val id = "msg_" + UUID.randomUUID().toString().take(10)
    var hasImage = false
    if (draftImage != null && draftImage.exists()) {
      val dest = imageFile(id)
      if (dest != null) {
        dest.parentFile?.mkdirs()
        draftImage.copyTo(dest, overwrite = true)
        draftImage.delete()
        hasImage = true
      }
    }
    val msg =
      ChatMessage(
        id = id,
        groupId = groupId,
        senderUsername = senderUsername,
        senderColorIndex = senderColorIndex,
        text = text.trim(),
        timestamp = System.currentTimeMillis(),
        gameInvite = gameInvite,
        hasImage = hasImage,
        replyToId = replyTo?.id,
        replyToSender = replyTo?.senderUsername,
        replyToText =
          replyTo?.let { (if (it.hasImage && it.text.isBlank()) "📷 عکس" else it.text).take(80) },
        sendState = if (serverOn(vault.loadCPanelConfig())) SendState.SENDING else SendState.SENT,
      )
    val current = vault.loadChatMessages(groupId) + msg
    vault.saveChatMessages(groupId, current)
    vault.saveChatGroups(
      vault.loadChatGroups().map { g ->
        if (g.id == groupId)
          g.copy(lastMessagePreview = previewOf(msg), lastMessageTime = msg.timestamp)
        else g
      }
    )
    return msg to current
  }

  suspend fun deliverMessage(msg: ChatMessage): List<ChatMessage> {
    val config = vault.loadCPanelConfig()
    if (!serverOn(config)) return vault.loadChatMessages(msg.groupId)
    // Never send plaintext: without the group key the message stays "failed" on this device.
    val key = vault.loadGroupKey(msg.groupId)
      ?: return setSendState(msg.groupId, msg.id, SendState.FAILED)
    val encImage =
      if (msg.hasImage) {
        withContext(Dispatchers.IO) {
          imageFile(msg.id)?.takeIf { it.exists() }?.let {
            CryptoManager.e2eeEncryptBytes(it.readBytes(), key, "${msg.groupId}|${msg.id}|img")
          }
        }
      } else null
    val ok = api.sendMessage(config, msg, encImage, key, previewOf(msg)).isSuccess
    return setSendState(msg.groupId, msg.id, if (ok) SendState.SENT else SendState.FAILED)
  }

  fun setSendState(groupId: String, messageId: String, state: Int): List<ChatMessage> {
    val updated =
      vault.loadChatMessages(groupId).map { if (it.id == messageId) it.copy(sendState = state) else it }
    vault.saveChatMessages(groupId, updated)
    return updated
  }

  fun findMessage(groupId: String, messageId: String): ChatMessage? =
    vault.loadChatMessages(groupId).firstOrNull { it.id == messageId }

  /** Convenience used for game invites: queue + deliver in one go. */
  suspend fun sendMessage(
    groupId: String,
    senderUsername: String,
    senderColorIndex: Int,
    text: String,
    gameInvite: GameInvite? = null,
  ): List<ChatMessage> {
    val (msg, _) = queueMessage(groupId, senderUsername, senderColorIndex, text, gameInvite)
    return deliverMessage(msg).ifEmpty { vault.loadChatMessages(groupId) }
  }

  private fun previewOf(m: ChatMessage): String =
    if (m.hasImage) "📷 " + m.text.ifBlank { "عکس" } else m.text

  fun newDraftFile(cacheDir: File): File = File(cacheDir, "draft_${System.currentTimeMillis()}.jpg")

  /** Loads (and caches) the bitmap of an image message; downloads it from the server if needed. */
  suspend fun loadImage(msg: ChatMessage, maxDim: Int = 900): Bitmap? =
    withContext(Dispatchers.IO) {
      val key = "${msg.id}@$maxDim"
      imageCache.get(key)?.let { return@withContext it }
      val file = imageFile(msg.id) ?: return@withContext null
      if (!file.exists() && msg.hasImage) {
        val config = vault.loadCPanelConfig()
        if (serverOn(config)) {
          val res = api.fetchMessageImage(config, msg.id)
          val enc = res.getOrNull().orEmpty()
          val key = vault.loadGroupKey(msg.groupId)
          if (enc.isNotEmpty() && key != null) {
            val bytes = CryptoManager.e2eeDecryptBytes(enc, key, "${msg.groupId}|${msg.id}|img")
            if (bytes != null) {
              try {
                file.parentFile?.mkdirs()
                file.writeBytes(bytes)
              } catch (_: Throwable) {}
            }
          }
        }
      }
      val bmp = ChatImageUtils.decodeSampled(file, maxDim)
      if (bmp != null) imageCache.put(key, bmp)
      bmp
    }

  // --- Online Game Rooms ---

  suspend fun createOnlineRoom(gameType: GameType, username: String): Result<OnlineRoom> {
    val code = "BZ" + CryptoManager.generateSaltHex(5).uppercase()
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      return api.createOrJoinRoom(config, "room_create", code, gameType, username)
    }
    // Local lobby preview mode when cPanel server is not yet attached
    return Result.success(
      OnlineRoom(
        roomCode = code,
        gameType = gameType,
        hostUsername = username,
        players = listOf(username),
        status = "waiting",
        version = 1,
      )
    )
  }

  suspend fun joinOnlineRoom(roomCode: String, gameType: GameType, username: String): Result<OnlineRoom> {
    val cleanCode = roomCode.trim().uppercase()
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      return api.createOrJoinRoom(config, "room_join", cleanCode, gameType, username)
    }
    return Result.failure(
      IllegalStateException("برای پیوستن به اتاق دوستان آنلاین، ابتدا هاست سی‌پنل ایران را در پنل مدیریت متصل کنید")
    )
  }

  suspend fun syncOnlineRoom(roomCode: String, gameType: GameType, username: String): Result<OnlineRoom> {
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      return api.createOrJoinRoom(config, "room_sync", roomCode, gameType, username)
    }
    return Result.failure(IllegalStateException("آفلاین"))
  }

  suspend fun pushOnlineMove(
    roomCode: String,
    username: String,
    stateJson: String,
    status: String,
    version: Int,
  ): Result<OnlineRoom> {
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      return api.pushRoomMove(config, roomCode, username, stateJson, status, version)
    }
    return Result.failure(IllegalStateException("آفلاین"))
  }

  private companion object {
    val imageCache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
      override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
  }
}
