package com.example.data

import com.example.security.CryptoManager
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

data class PingResult(
  val success: Boolean,
  val latencyMs: Long,
  val message: String,
  val serverTime: String = "",
)

/**
 * Lightweight OkHttp REST client targeting the user's Iranian cPanel PHP/MySQL endpoint.
 * Zero dependency on Google Play Services or Firebase.
 * Signs every call with HMAC-SHA256 + Timestamp + Nonce and optionally encrypts body with AES-256-GCM.
 */
class CPanelApiClient {

  private val client =
    OkHttpClient.Builder()
      .connectTimeout(8, TimeUnit.SECONDS)
      .readTimeout(10, TimeUnit.SECONDS)
      .writeTimeout(10, TimeUnit.SECONDS)
      .build()

  private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

  suspend fun ping(config: CPanelConfig): PingResult =
    withContext(Dispatchers.IO) {
      val baseUrl = config.apiBaseUrl.trim()
      if (baseUrl.isBlank()) {
        return@withContext PingResult(false, -1, "آدرس سرور سی‌پنل وارد نشده است")
      }
      if (!baseUrl.startsWith("https://")) {
        return@withContext PingResult(
          false,
          -1,
          "برای امنیت کامل، آدرس باید با https:// شروع شود (AutoSSL سی‌پنل)",
        )
      }
      val start = System.currentTimeMillis()
      val res = executeAction(config, "ping", JSONObject())
      val elapsed = System.currentTimeMillis() - start
      res.fold(
        onSuccess = { json ->
          val msg = json.optString("message", "اتصال امن برقرار شد")
          val dbOk = json.optBoolean("db_ok", true)
          PingResult(
            success = dbOk,
            latencyMs = elapsed,
            message = if (dbOk) "$msg (${elapsed}ms)" else "PHP متصل شد ولی دیتابیس MySQL خطا دارد",
            serverTime = json.optString("server_time", ""),
          )
        },
        onFailure = { err ->
          PingResult(false, elapsed, err.message ?: "خطا در اتصال به هاست")
        },
      )
    }

  suspend fun registerRemote(
    config: CPanelConfig,
    username: String,
    passwordHashClient: String,
    displayName: String,
    avatarColorIndex: Int,
  ): Result<UserAccount> {
    val payload =
      JSONObject().apply {
        put("username", username)
        put("password_hash", passwordHashClient)
        put("display_name", displayName)
        put("avatar_color", avatarColorIndex)
      }
    return executeAction(config, "register", payload).map { json ->
      val u = json.getJSONObject("user")
      UserAccount(
        username = u.getString("username"),
        displayName = u.optString("display_name", username),
        avatarColorIndex = u.optInt("avatar_color", avatarColorIndex),
        totalScore = u.optInt("total_score", 0),
        wins = u.optInt("wins", 0),
        gamesPlayed = u.optInt("games_played", 0),
        authToken = json.optString("token", ""),
      )
    }
  }

  suspend fun loginRemote(
    config: CPanelConfig,
    username: String,
    passwordHashClient: String,
  ): Result<UserAccount> {
    val payload =
      JSONObject().apply {
        put("username", username)
        put("password_hash", passwordHashClient)
      }
    return executeAction(config, "login", payload).map { json ->
      val u = json.getJSONObject("user")
      UserAccount(
        username = u.getString("username"),
        displayName = u.optString("display_name", username),
        avatarColorIndex = u.optInt("avatar_color", 0),
        totalScore = u.optInt("total_score", 0),
        wins = u.optInt("wins", 0),
        gamesPlayed = u.optInt("games_played", 0),
        authToken = json.optString("token", ""),
      )
    }
  }

  suspend fun submitScore(
    config: CPanelConfig,
    token: String,
    username: String,
    gameType: GameType,
    deltaScore: Int,
    didWin: Boolean,
  ): Result<Unit> {
    val payload =
      JSONObject().apply {
        put("token", token)
        put("username", username)
        put("game_type", gameType.id)
        put("delta_score", deltaScore)
        put("did_win", didWin)
      }
    return executeAction(config, "submit_score", payload).map {}
  }

  suspend fun fetchLeaderboard(
    config: CPanelConfig,
    currentUsername: String?,
  ): Result<List<LeaderboardEntry>> {
    return executeAction(config, "leaderboard", JSONObject()).map { json ->
      val arr = json.optJSONArray("entries") ?: JSONArray()
      buildList {
        for (i in 0 until arr.length()) {
          val o = arr.getJSONObject(i)
          val uname = o.getString("username")
          add(
            LeaderboardEntry(
              rank = i + 1,
              username = uname,
              displayName = o.optString("display_name", uname),
              avatarColorIndex = o.optInt("avatar_color", 0),
              totalScore = o.optInt("total_score", 0),
              wins = o.optInt("wins", 0),
              gamesPlayed = o.optInt("games_played", 0),
              favoriteGame =
                GameType.entries.firstOrNull { it.id == o.optString("favorite_game") }
                  ?: GameType.LUDO,
              isCurrentUser =
                currentUsername != null && uname.equals(currentUsername, ignoreCase = true),
            )
          )
        }
      }
    }
  }

  suspend fun createOrJoinGroup(
    config: CPanelConfig,
    action: String, // group_create | group_join
    username: String,
    nameOrCode: String,
  ): Result<ChatGroup> {
    val payload =
      JSONObject().apply {
        put("username", username)
        if (action == "group_create") put("name", nameOrCode) else put("invite_code", nameOrCode)
      }
    return executeAction(config, action, payload).map { json ->
      parseGroup(json.getJSONObject("group"))
    }
  }

  suspend fun inviteMemberToGroup(
    config: CPanelConfig,
    groupId: String,
    targetUsername: String,
  ): Result<ChatGroup> {
    val payload =
      JSONObject().apply {
        put("group_id", groupId)
        put("target_username", targetUsername)
      }
    return executeAction(config, "group_invite", payload).map { json ->
      parseGroup(json.getJSONObject("group"))
    }
  }

  suspend fun fetchGroups(config: CPanelConfig, username: String): Result<List<ChatGroup>> {
    val payload = JSONObject().apply { put("username", username) }
    return executeAction(config, "groups_list", payload).map { json ->
      val arr = json.optJSONArray("groups") ?: JSONArray()
      buildList {
        for (i in 0 until arr.length()) add(parseGroup(arr.getJSONObject(i)))
      }
    }
  }

  suspend fun sendMessage(
    config: CPanelConfig,
    message: ChatMessage,
    imageBase64: String? = null,
  ): Result<Unit> {
    val payload =
      JSONObject().apply {
        put("id", message.id)
        put("group_id", message.groupId)
        put("sender_username", message.senderUsername)
        put("sender_color", message.senderColorIndex)
        put("text", message.text)
        put("timestamp", message.timestamp)
        message.gameInvite?.let { inv ->
          put(
            "game_invite",
            JSONObject().apply {
              put("game_type", inv.gameType.id)
              put("room_code", inv.roomCode)
              put("host_username", inv.hostUsername)
            },
          )
        }
        if (message.replyToId != null) {
          put(
            "reply",
            JSONObject().apply {
              put("id", message.replyToId)
              put("sender", message.replyToSender ?: "")
              put("text", message.replyToText ?: "")
            },
          )
        }
        if (!imageBase64.isNullOrEmpty()) put("image_data", imageBase64)
      }
    return executeAction(config, "message_send", payload).map {}
  }

  suspend fun fetchMessages(
    config: CPanelConfig,
    groupId: String,
    viewer: String?,
  ): Result<MessagesPage> {
    val payload =
      JSONObject().apply {
        put("group_id", groupId)
        if (!viewer.isNullOrBlank()) put("viewer", viewer)
      }
    return executeAction(config, "messages_list", payload).map { json ->
      val arr = json.optJSONArray("messages") ?: JSONArray()
      val list = buildList {
        for (i in 0 until arr.length()) {
          val o = arr.getJSONObject(i)
          val inv = o.optJSONObject("game_invite")
          val reply = o.optJSONObject("reply")
          val hasImg = o.opt("has_image").let { it == true || it == 1 || it == "1" }
          add(
            ChatMessage(
              id = o.getString("id"),
              groupId = o.getString("group_id"),
              senderUsername = o.getString("sender_username"),
              senderColorIndex = o.optInt("sender_color", 0),
              text = o.optString("text", ""),
              timestamp = o.optLong("timestamp", 0L),
              gameInvite =
                if (inv != null) {
                  GameInvite(
                    gameType =
                      GameType.entries.firstOrNull { it.id == inv.optString("game_type") }
                        ?: GameType.LUDO,
                    roomCode = inv.optString("room_code", ""),
                    hostUsername = inv.optString("host_username", ""),
                  )
                } else null,
              hasImage = hasImg,
              replyToId = reply?.optString("id")?.ifBlank { null },
              replyToSender = reply?.optString("sender")?.ifBlank { null },
              replyToText = reply?.optString("text")?.ifBlank { null },
              sendState = SendState.SENT,
            )
          )
        }
      }
      val readsObj = json.optJSONObject("reads")
      val reads = buildMap<String, Long> {
        readsObj?.keys()?.forEach { k -> put(k, readsObj.optLong(k, 0L)) }
      }
      MessagesPage(list, reads)
    }
  }

  suspend fun fetchMessageImage(config: CPanelConfig, messageId: String): Result<String> {
    val payload = JSONObject().apply { put("id", messageId) }
    return executeAction(config, "message_image", payload).map { it.optString("image", "") }
  }

  suspend fun createOrJoinRoom(
    config: CPanelConfig,
    action: String, // room_create | room_join | room_sync
    roomCode: String,
    gameType: GameType,
    username: String,
  ): Result<OnlineRoom> {
    val payload =
      JSONObject().apply {
        put("room_code", roomCode)
        put("game_type", gameType.id)
        put("username", username)
      }
    return executeAction(config, action, payload).map { json -> parseRoom(json.getJSONObject("room")) }
  }

  suspend fun pushRoomMove(
    config: CPanelConfig,
    roomCode: String,
    username: String,
    stateJson: String,
    status: String,
    version: Int,
  ): Result<OnlineRoom> {
    val payload =
      JSONObject().apply {
        put("room_code", roomCode)
        put("username", username)
        put("state_json", stateJson)
        put("status", status)
        put("version", version)
      }
    return executeAction(config, "room_move", payload).map { json -> parseRoom(json.getJSONObject("room")) }
  }

  private suspend fun executeAction(
    config: CPanelConfig,
    action: String,
    rawPayload: JSONObject,
  ): Result<JSONObject> =
    withContext(Dispatchers.IO) {
      val baseUrl = config.apiBaseUrl.trim()
      if (baseUrl.isBlank()) {
        return@withContext Result.failure(IllegalStateException("سرور سی‌پنل تنظیم نشده"))
      }
      if (!baseUrl.startsWith("https://")) {
        return@withContext Result.failure(IllegalStateException("فقط آدرس HTTPS مجاز است"))
      }
      try {
        val plainBody =
          JSONObject().apply {
            put("action", action)
            put("data", rawPayload)
          }.toString()

        val wireBody =
          if (config.e2eeEnabled && config.apiSecret.isNotBlank()) {
            JSONObject().apply {
              put("enc", CryptoManager.encryptTransportPayload(plainBody, config.apiSecret))
            }.toString()
          } else {
            plainBody
          }

        val timestamp = (System.currentTimeMillis() / 1000L).toString()
        val nonce = CryptoManager.generateSaltHex(8)
        val signature =
          if (config.hmacEnabled && config.apiSecret.isNotBlank()) {
            CryptoManager.hmacSha256Hex("$action|$timestamp|$nonce|$wireBody", config.apiSecret)
          } else {
            ""
          }

        val sep = if (baseUrl.contains("?")) "&" else "?"
        val url = "$baseUrl${sep}action=$action"
        val request =
          Request.Builder()
            .url(url)
            .post(wireBody.toRequestBody(jsonMediaType))
            .header("X-BaziLand-Timestamp", timestamp)
            .header("X-BaziLand-Nonce", nonce)
            .header("X-BaziLand-Signature", signature)
            .header("X-BaziLand-Enc", if (config.e2eeEnabled) "1" else "0")
            .build()

        client.newCall(request).execute().use { response ->
          val bodyStr = response.body?.string().orEmpty()
          if (!response.isSuccessful) {
            return@withContext Result.failure(
              IllegalStateException("خطای سرور (${response.code})")
            )
          }
          val wrapper = JSONObject(bodyStr)
          val decryptedJson =
            if (wrapper.has("enc") && config.e2eeEnabled && config.apiSecret.isNotBlank()) {
              val dec =
                CryptoManager.decryptTransportPayload(wrapper.getString("enc"), config.apiSecret)
                  ?: return@withContext Result.failure(
                    IllegalStateException("خطا در رمزگشایی پاسخ سرور")
                  )
              JSONObject(dec)
            } else {
              wrapper
            }
          if (!decryptedJson.optBoolean("ok", true)) {
            return@withContext Result.failure(
              IllegalStateException(decryptedJson.optString("error", "درخواست ناموفق"))
            )
          }
          Result.success(decryptedJson)
        }
      } catch (e: Throwable) {
        Result.failure(IllegalStateException(e.message ?: "خطای شبکه"))
      }
    }

  private fun parseGroup(o: JSONObject): ChatGroup {
    val memArr = o.optJSONArray("members") ?: JSONArray()
    val members = buildList {
      for (i in 0 until memArr.length()) add(memArr.getString(i))
    }
    return ChatGroup(
      id = o.getString("id"),
      name = o.getString("name"),
      inviteCode = o.getString("invite_code"),
      ownerUsername = o.optString("owner_username", ""),
      members = members,
      lastMessagePreview = o.optString("last_message", ""),
      lastMessageTime = o.optLong("last_time", 0L),
    )
  }

  private fun parseRoom(o: JSONObject): OnlineRoom {
    val pArr = o.optJSONArray("players") ?: JSONArray()
    val players = buildList {
      for (i in 0 until pArr.length()) add(pArr.getString(i))
    }
    return OnlineRoom(
      roomCode = o.getString("room_code"),
      gameType =
        GameType.entries.firstOrNull { it.id == o.optString("game_type") } ?: GameType.LUDO,
      hostUsername = o.optString("host_username", ""),
      players = players,
      status = o.optString("status", "waiting"),
      version = o.optInt("version", 1),
      stateJson = o.optString("state_json", "{}"),
    )
  }
}
