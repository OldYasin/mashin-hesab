package com.example.data

import androidx.compose.runtime.Immutable

enum class GameType(
  val id: String,
  val titleFa: String,
  val subtitleFa: String,
  val playersRangeFa: String,
) {
  LUDO("ludo", "منچ", "رقابت کلاسیک چهارنفره", "۲ تا ۴ نفر"),
  TIC_TAC_TOE("tictactoe", "دوز", "نبرد سریع هوش و تاکتیک", "۲ نفره"),
  CONNECT_FOUR("connect4", "چهار خط", "چینش ۴ مهره هم‌رنگ", "۲ نفره"),
  SNAKES_LADDERS("snakes", "مار و پله", "صعود از پله و فرار از مار", "۲ تا ۴ نفر"),
}

enum class PlayMode(val titleFa: String) {
  VS_AI("بازی با هوش مصنوعی"),
  LOCAL_PASS_AND_PLAY("دو/چند نفره آفلاین"),
  ONLINE_ROOM("بازی آنلاین با دوستان"),
}

enum class MainTab(val titleFa: String) {
  GAMES("بازی‌ها"),
  CHAT("چت"),
  LEADERBOARD("لیدربرد"),
  PROFILE("پروفایل"),
}

@Immutable
data class UserAccount(
  val username: String,
  val displayName: String,
  val avatarColorIndex: Int = 0,
  val totalScore: Int = 0,
  val wins: Int = 0,
  val gamesPlayed: Int = 0,
  val authToken: String = "",
) {
  val level: Int
    get() = 1 + (totalScore / 150)

  val winRatePercent: Int
    get() = if (gamesPlayed <= 0) 0 else ((wins * 100f) / gamesPlayed).toInt().coerceIn(0, 100)
}

@Immutable
data class LeaderboardEntry(
  val rank: Int,
  val username: String,
  val displayName: String,
  val avatarColorIndex: Int,
  val totalScore: Int,
  val wins: Int,
  val gamesPlayed: Int,
  val favoriteGame: GameType = GameType.LUDO,
  val isCurrentUser: Boolean = false,
) {
  val winRatePercent: Int
    get() = if (gamesPlayed <= 0) 0 else ((wins * 100f) / gamesPlayed).toInt().coerceIn(0, 100)
}

@Immutable
data class GameInvite(
  val gameType: GameType,
  val roomCode: String,
  val hostUsername: String,
)

@Immutable
data class ChatGroup(
  val id: String,
  val name: String,
  val inviteCode: String,
  val ownerUsername: String,
  val members: List<String>,
  val lastMessagePreview: String = "",
  val lastMessageTime: Long = 0L,
  /** Full invite = server code + "." + group encryption key. The key never reaches the server. */
  val shareCode: String = "",
)

/** Result of the device-local admin gate (no credentials are stored inside the APK). */
sealed interface AdminAuthResult {
  data object Granted : AdminAuthResult
  data object Created : AdminAuthResult
  data object Wrong : AdminAuthResult
  data object TooWeak : AdminAuthResult
  data class Locked(val seconds: Long) : AdminAuthResult
}

@Immutable
data class ChatMessage(
  val id: String,
  val groupId: String,
  val senderUsername: String,
  val senderColorIndex: Int,
  val text: String,
  val timestamp: Long,
  val gameInvite: GameInvite? = null,
  val hasImage: Boolean = false,
  val replyToId: String? = null,
  val replyToSender: String? = null,
  val replyToText: String? = null,
  val sendState: Int = SendState.SENT,
)

object SendState {
  const val SENDING = 0
  const val SENT = 1
  const val FAILED = 2
}

/** Messages of one chat plus per-user "read up to" timestamps (for double-tick read receipts). */
data class MessagesPage(val messages: List<ChatMessage>, val reads: Map<String, Long>)

@Immutable
data class OnlineRoom(
  val roomCode: String,
  val gameType: GameType,
  val hostUsername: String,
  val players: List<String>,
  val status: String = "waiting", // waiting | playing | finished
  val version: Int = 1,
  val stateJson: String = "{}",
)

@Immutable
data class CPanelConfig(
  val apiBaseUrl: String = "",
  val dbHost: String = "localhost",
  val dbName: String = "",
  val dbUser: String = "",
  val dbPassword: String = "",
  val apiSecret: String = "",
  val hmacEnabled: Boolean = true,
  val e2eeEnabled: Boolean = true,
  val maintenanceMode: Boolean = false,
  val pollingIntervalMs: Int = 1800,
  val lastTestStatus: String = "تنظیم نشده",
  val lastTestLatencyMs: Long = -1L,
  val isConnected: Boolean = false,
)
