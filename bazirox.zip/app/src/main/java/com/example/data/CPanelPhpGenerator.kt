package com.example.data

/**
 * Generates the PHP 8 + MySQL files that run on the admin's cPanel host.
 *
 * Security model (v3):
 * - Every action except ping/register/login needs a per-user session token (stored hashed).
 * - The username is always taken from the token, never from the request body.
 * - Chat names, messages, replies, game invites, previews and images are encrypted on the phones
 *   with a per-group key that never reaches this server: the host only ever stores ciphertext.
 * - Passwords never reach the server: the app sends a slow PBKDF2 verifier, stored as Argon2id/bcrypt.
 *
 * The PHP source below uses the placeholder character "§" for the PHP dollar sign so that Kotlin
 * does not treat it as a string template. It is converted back before the config is embedded.
 */
object CPanelPhpGenerator {

  fun generateSchemaSql(): String =
    """
-- Bazirox Secure MySQL Schema v3 (utf8mb4)
-- If you installed an older version, DROP the old tables first:
-- users, chat_groups, chat_messages, chat_reads, game_rooms

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(32) NOT NULL UNIQUE,
  display_name VARCHAR(64) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  avatar_color INT NOT NULL DEFAULT 0,
  total_score INT NOT NULL DEFAULT 0,
  wins INT NOT NULL DEFAULT 0,
  games_played INT NOT NULL DEFAULT 0,
  favorite_game VARCHAR(24) NOT NULL DEFAULT 'ludo',
  last_submit BIGINT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sessions (
  token_hash CHAR(64) PRIMARY KEY,
  user_id INT NOT NULL,
  expires_at BIGINT NOT NULL,
  INDEX idx_sess_user (user_id),
  INDEX idx_sess_exp (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_fails (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(32) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  ts BIGINT NOT NULL,
  INDEX idx_lf_user (username, ts),
  INDEX idx_lf_ip (ip, ts)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS api_nonces (
  nonce VARCHAR(64) PRIMARY KEY,
  ts BIGINT NOT NULL,
  INDEX idx_nonce_ts (ts)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chat_groups (
  id VARCHAR(40) PRIMARY KEY,
  name TEXT NOT NULL,
  invite_code VARCHAR(16) NOT NULL UNIQUE,
  owner_username VARCHAR(32) NOT NULL,
  last_message TEXT NOT NULL,
  last_time BIGINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chat_members (
  group_id VARCHAR(40) NOT NULL,
  username VARCHAR(32) NOT NULL,
  joined_at BIGINT NOT NULL DEFAULT 0,
  PRIMARY KEY (group_id, username),
  INDEX idx_member_user (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chat_messages (
  id VARCHAR(48) PRIMARY KEY,
  group_id VARCHAR(40) NOT NULL,
  sender_username VARCHAR(32) NOT NULL,
  sender_color INT NOT NULL DEFAULT 0,
  text MEDIUMTEXT NOT NULL,
  image_data MEDIUMTEXT DEFAULT NULL,
  timestamp BIGINT NOT NULL,
  INDEX idx_group_time (group_id, timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chat_reads (
  group_id VARCHAR(40) NOT NULL,
  username VARCHAR(32) NOT NULL,
  last_ts BIGINT NOT NULL DEFAULT 0,
  PRIMARY KEY (group_id, username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS game_rooms (
  room_code VARCHAR(16) PRIMARY KEY,
  game_type VARCHAR(24) NOT NULL,
  host_username VARCHAR(32) NOT NULL,
  players_json TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'waiting',
  version INT NOT NULL DEFAULT 1,
  state_json MEDIUMTEXT NOT NULL,
  updated_at BIGINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
""".trimStart()

  fun generateApiPhp(config: CPanelConfig): String {
    val hmacFlag = if (config.hmacEnabled) "true" else "false"
    val encFlag = if (config.e2eeEnabled) "true" else "false"
    val maintFlag = if (config.maintenanceMode) "true" else "false"

    return API_TEMPLATE
      .replace('§', '$')
      .replace("__DB_HOST__", config.dbHost.ifBlank { "localhost" }.escapePhp())
      .replace("__DB_NAME__", config.dbName.ifBlank { "cpaneluser_bazirox" }.escapePhp())
      .replace("__DB_USER__", config.dbUser.ifBlank { "cpaneluser_dbuser" }.escapePhp())
      .replace("__DB_PASS__", config.dbPassword.escapePhp())
      .replace("__API_SECRET__", config.apiSecret.ifBlank { "CHANGE_ME_SECRET" }.escapePhp())
      .replace("__HMAC__", hmacFlag)
      .replace("__ENC__", encFlag)
      .replace("__MAINT__", maintFlag)
  }

  private fun String.escapePhp(): String = replace("\\", "\\\\").replace("'", "\\'")

  private val API_TEMPLATE =
    """<?php
// Bazirox Secure cPanel API v3 (PHP 8.x + PDO MySQL)
// Chats are end-to-end encrypted on the phones: this server stores ciphertext only.
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

define('DB_HOST', '__DB_HOST__');
define('DB_NAME', '__DB_NAME__');
define('DB_USER', '__DB_USER__');
define('DB_PASS', '__DB_PASS__');
define('API_SECRET', '__API_SECRET__');
define('ENABLE_HMAC', __HMAC__);
define('ENABLE_TRANSPORT_ENC', __ENC__);
define('MAINTENANCE_MODE', __MAINT__);
define('SESSION_TTL', 2592000);
define('MAX_BODY', 12000000);

function aesKey(): string {
  return hash('sha256', 'BaziLand_AES256_Key:' . API_SECRET, true);
}

function decryptPayload(string §b64): ?string {
  §raw = base64_decode(§b64, true);
  if (§raw === false || strlen(§raw) <= 28) return null;
  §iv = substr(§raw, 0, 12);
  §tag = substr(§raw, 12, 16);
  §cipher = substr(§raw, 28);
  §plain = openssl_decrypt(§cipher, 'aes-256-gcm', aesKey(), OPENSSL_RAW_DATA, §iv, §tag);
  return §plain === false ? null : §plain;
}

function encryptPayload(string §plain): string {
  §iv = random_bytes(12);
  §tag = '';
  §cipher = openssl_encrypt(§plain, 'aes-256-gcm', aesKey(), OPENSSL_RAW_DATA, §iv, §tag, '', 16);
  return base64_encode(§iv . §tag . §cipher);
}

function sendJson(array §payload, int §code = 200): void {
  http_response_code(§code);
  §json = json_encode(§payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
  if (ENABLE_TRANSPORT_ENC) {
    echo json_encode(['enc' => encryptPayload(§json)]);
  } else {
    echo §json;
  }
  exit;
}

function fail(string §msg, int §code = 400): void {
  sendJson(['ok' => false, 'error' => §msg], §code);
}

function nowMs(): int {
  return (int) round(microtime(true) * 1000);
}

function str(§v, int §max): string {
  if (!is_string(§v)) return '';
  return mb_substr(trim(§v), 0, §max);
}

function passwordAlgo() {
  return defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
}

if (MAINTENANCE_MODE && (§_GET['action'] ?? '') !== 'ping') {
  fail('سرور در حال بروزرسانی است', 503);
}

§rawBody = file_get_contents('php://input');
if (§rawBody === false) §rawBody = '';
if (strlen(§rawBody) > MAX_BODY) fail('Payload too large', 413);
§action = (string)(§_GET['action'] ?? '');
§ts = (int)(§_SERVER['HTTP_X_BAZILAND_TIMESTAMP'] ?? 0);
§nonce = (string)(§_SERVER['HTTP_X_BAZILAND_NONCE'] ?? '');
§sig = (string)(§_SERVER['HTTP_X_BAZILAND_SIGNATURE'] ?? '');

if (ENABLE_HMAC) {
  if (abs(time() - §ts) > 120 || §nonce === '' || strlen(§nonce) > 64 || §sig === '') {
    fail('Invalid security timestamp/nonce', 401);
  }
  §expected = hash_hmac('sha256', §action . '|' . §ts . '|' . §nonce . '|' . §rawBody, API_SECRET);
  if (!hash_equals(§expected, §sig)) fail('Invalid HMAC signature', 403);
}

§req = json_decode(§rawBody, true);
if (!is_array(§req)) §req = [];
if (isset(§req['enc'])) {
  if (!ENABLE_TRANSPORT_ENC) fail('Encryption is disabled on this server', 400);
  §dec = is_string(§req['enc']) ? decryptPayload(§req['enc']) : null;
  if (§dec === null) fail('Decrypt failed', 400);
  §req = json_decode(§dec, true);
  if (!is_array(§req)) §req = [];
} elseif (ENABLE_TRANSPORT_ENC) {
  fail('Encrypted request required', 400);
}
§data = (isset(§req['data']) && is_array(§req['data'])) ? §req['data'] : [];

try {
  §pdo = new PDO(
    'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
    DB_USER,
    DB_PASS,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
  );
} catch (Throwable §e) {
  sendJson(['ok' => false, 'db_ok' => false, 'error' => 'خطا در اتصال به MySQL'], 500);
}

if (ENABLE_HMAC) {
  try {
    §pdo->prepare('INSERT INTO api_nonces (nonce, ts) VALUES (?, ?)')->execute([§nonce, time()]);
  } catch (PDOException §e) {
    if ((int)(§e->errorInfo[1] ?? 0) === 1062) fail('Replay detected', 409);
    sendJson(['ok' => false, 'db_ok' => false, 'error' => 'جدول‌های دیتابیس نصب نشده‌اند (schema.sql را اجرا کن)'], 500);
  }
  if (random_int(1, 50) === 1) {
    try { §pdo->prepare('DELETE FROM api_nonces WHERE ts < ?')->execute([time() - 600]); } catch (Throwable §e) {}
  }
}

function requireUser(PDO §pdo, array §req): array {
  §token = §req['token'] ?? '';
  if (!is_string(§token) || strlen(§token) < 32 || strlen(§token) > 128) {
    fail('نشست نامعتبر است، دوباره وارد شوید', 401);
  }
  §st = §pdo->prepare('SELECT u.id, u.username, u.display_name, u.avatar_color FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?');
  §st->execute([hash('sha256', §token), time()]);
  §u = §st->fetch();
  if (!§u) fail('نشست نامعتبر است، دوباره وارد شوید', 401);
  return §u;
}

function issueSession(PDO §pdo, int §userId): string {
  §token = bin2hex(random_bytes(32));
  §pdo->prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)')
      ->execute([hash('sha256', §token), §userId, time() + SESSION_TTL]);
  if (random_int(1, 20) === 1) {
    try { §pdo->prepare('DELETE FROM sessions WHERE expires_at < ?')->execute([time()]); } catch (Throwable §e) {}
  }
  return §token;
}

function userOut(array §u): array {
  return [
    'username' => §u['username'],
    'display_name' => §u['display_name'],
    'avatar_color' => (int)(§u['avatar_color'] ?? 0),
    'total_score' => (int)(§u['total_score'] ?? 0),
    'wins' => (int)(§u['wins'] ?? 0),
    'games_played' => (int)(§u['games_played'] ?? 0),
  ];
}

function isMember(PDO §pdo, string §gid, string §username): bool {
  §st = §pdo->prepare('SELECT 1 FROM chat_members WHERE group_id = ? AND username = ?');
  §st->execute([§gid, §username]);
  return (bool)§st->fetchColumn();
}

function groupOut(PDO §pdo, array §g): array {
  §st = §pdo->prepare('SELECT username FROM chat_members WHERE group_id = ? ORDER BY joined_at');
  §st->execute([§g['id']]);
  return [
    'id' => §g['id'],
    'name' => §g['name'],
    'invite_code' => §g['invite_code'],
    'owner_username' => §g['owner_username'],
    'members' => §st->fetchAll(PDO::FETCH_COLUMN),
    'last_message' => §g['last_message'],
    'last_time' => (int)§g['last_time'],
  ];
}

function roomOut(array §r): array {
  §players = json_decode(§r['players_json'], true);
  return [
    'room_code' => §r['room_code'],
    'game_type' => §r['game_type'],
    'host_username' => §r['host_username'],
    'players' => is_array(§players) ? §players : [],
    'status' => §r['status'],
    'version' => (int)§r['version'],
    'state_json' => §r['state_json'],
  ];
}

function cleanRoomCode(§v): string {
  §code = strtoupper(str(§v, 16));
  if (!preg_match('/^[A-Z0-9]{6,16}§/', §code)) fail('کد اتاق نامعتبر است', 400);
  return §code;
}

§GAMES = ['ludo', 'tictactoe', 'connect4', 'snakes'];

switch (§action) {
  case 'ping':
    sendJson(['ok' => true, 'db_ok' => true, 'message' => 'هاست ایران متصل و امن است', 'server_time' => date('c')]);

  case 'register':
    §u = str(§data['username'] ?? '', 32);
    §ph = §data['password_hash'] ?? '';
    §dn = str(§data['display_name'] ?? '', 64);
    if (§dn === '') §dn = §u;
    §col = max(0, min(31, (int)(§data['avatar_color'] ?? 0)));
    if (!preg_match('/^[\p{L}\p{N}_.-]{3,32}§/u', §u)) fail('نام کاربری باید ۳ تا ۳۲ حرف یا عدد باشد', 400);
    if (!is_string(§ph) || !preg_match('/^[0-9a-f]{64}§/', §ph)) fail('ورودی نامعتبر', 400);
    §st = §pdo->prepare('SELECT id FROM users WHERE username = ?');
    §st->execute([§u]);
    if (§st->fetch()) fail('نام کاربری تکراری است', 409);
    §hash = password_hash(§ph, passwordAlgo());
    try {
      §pdo->prepare('INSERT INTO users (username, display_name, password_hash, avatar_color) VALUES (?, ?, ?, ?)')
          ->execute([§u, §dn, §hash, §col]);
    } catch (PDOException §e) {
      fail('نام کاربری تکراری است', 409);
    }
    §uid = (int)§pdo->lastInsertId();
    §token = issueSession(§pdo, §uid);
    sendJson(['ok' => true, 'token' => §token, 'user' => userOut(['username' => §u, 'display_name' => §dn, 'avatar_color' => §col])]);

  case 'login':
    §u = str(§data['username'] ?? '', 32);
    §ph = §data['password_hash'] ?? '';
    §ip = substr((string)(§_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
    §since = time() - 900;
    §c1 = §pdo->prepare('SELECT COUNT(*) FROM login_fails WHERE username = ? AND ts > ?');
    §c1->execute([§u, §since]);
    §c2 = §pdo->prepare('SELECT COUNT(*) FROM login_fails WHERE ip = ? AND ts > ?');
    §c2->execute([§ip, §since]);
    if ((int)§c1->fetchColumn() >= 8 || (int)§c2->fetchColumn() >= 60) {
      fail('تلاش‌های ناموفق زیاد است؛ چند دقیقه بعد دوباره امتحان کن', 429);
    }
    §st = §pdo->prepare('SELECT id, username, display_name, avatar_color, total_score, wins, games_played, password_hash FROM users WHERE username = ?');
    §st->execute([§u]);
    §row = §st->fetch();
    §validForm = is_string(§ph) && preg_match('/^[0-9a-f]{64}§/', §ph);
    if (§row && §validForm && password_verify(§ph, §row['password_hash'])) {
      try { §pdo->prepare('DELETE FROM login_fails WHERE username = ?')->execute([§u]); } catch (Throwable §e) {}
      §token = issueSession(§pdo, (int)§row['id']);
      sendJson(['ok' => true, 'token' => §token, 'user' => userOut(§row)]);
    }
    if (!§row) password_hash(is_string(§ph) ? §ph : '', passwordAlgo());
    try {
      §pdo->prepare('INSERT INTO login_fails (username, ip, ts) VALUES (?, ?, ?)')->execute([§u, §ip, time()]);
      if (random_int(1, 20) === 1) §pdo->prepare('DELETE FROM login_fails WHERE ts < ?')->execute([time() - 86400]);
    } catch (Throwable §e) {}
    fail('نام کاربری یا رمز عبور اشتباه است', 401);

  case 'submit_score':
    §me = requireUser(§pdo, §req);
    §ds = max(-100, min(300, (int)(§data['delta_score'] ?? 0)));
    §win = !empty(§data['did_win']) ? 1 : 0;
    §gt = (string)(§data['game_type'] ?? 'ludo');
    if (!in_array(§gt, §GAMES, true)) §gt = 'ludo';
    §now = time();
    §up = §pdo->prepare('UPDATE users SET total_score = GREATEST(0, total_score + ?), wins = wins + ?, games_played = games_played + 1, favorite_game = ?, last_submit = ? WHERE id = ? AND last_submit < ?');
    §up->execute([§ds, §win, §gt, §now, §me['id'], §now - 5]);
    sendJson(['ok' => true]);

  case 'leaderboard':
    requireUser(§pdo, §req);
    §rows = §pdo->query('SELECT username, display_name, avatar_color, total_score, wins, games_played, favorite_game FROM users ORDER BY total_score DESC, wins DESC LIMIT 50')->fetchAll();
    sendJson(['ok' => true, 'entries' => §rows]);

  case 'group_create':
    §me = requireUser(§pdo, §req);
    §name = §data['name'] ?? '';
    if (!is_string(§name) || §name === '' || strlen(§name) > 600) fail('نام گروه نامعتبر است', 400);
    §cnt = §pdo->prepare('SELECT COUNT(*) FROM chat_groups WHERE owner_username = ?');
    §cnt->execute([§me['username']]);
    if ((int)§cnt->fetchColumn() >= 30) fail('تعداد گروه‌های ساخته‌شده به سقف رسیده است', 429);
    §gid = 'grp_' . bin2hex(random_bytes(6));
    §code = strtoupper(bin2hex(random_bytes(5)));
    §t = nowMs();
    §pdo->prepare('INSERT INTO chat_groups (id, name, invite_code, owner_username, last_message, last_time) VALUES (?, ?, ?, ?, ?, ?)')
        ->execute([§gid, §name, §code, §me['username'], '', §t]);
    §pdo->prepare('INSERT INTO chat_members (group_id, username, joined_at) VALUES (?, ?, ?)')
        ->execute([§gid, §me['username'], §t]);
    §g = §pdo->prepare('SELECT * FROM chat_groups WHERE id = ?');
    §g->execute([§gid]);
    sendJson(['ok' => true, 'group' => groupOut(§pdo, §g->fetch())]);

  case 'group_join':
    §me = requireUser(§pdo, §req);
    §code = strtoupper(str(§data['invite_code'] ?? '', 16));
    if (!preg_match('/^[0-9A-F]{6,16}§/', §code)) fail('کد دعوت معتبر نیست', 404);
    §st = §pdo->prepare('SELECT * FROM chat_groups WHERE invite_code = ?');
    §st->execute([§code]);
    §g = §st->fetch();
    if (!§g) fail('کد دعوت معتبر نیست', 404);
    if (!isMember(§pdo, §g['id'], §me['username'])) {
      §mc = §pdo->prepare('SELECT COUNT(*) FROM chat_members WHERE group_id = ?');
      §mc->execute([§g['id']]);
      if ((int)§mc->fetchColumn() >= 100) fail('ظرفیت گروه تکمیل است', 409);
      §pdo->prepare('INSERT IGNORE INTO chat_members (group_id, username, joined_at) VALUES (?, ?, ?)')
          ->execute([§g['id'], §me['username'], nowMs()]);
    }
    sendJson(['ok' => true, 'group' => groupOut(§pdo, §g)]);

  case 'group_invite':
    §me = requireUser(§pdo, §req);
    §gid = str(§data['group_id'] ?? '', 40);
    §target = str(§data['target_username'] ?? '', 32);
    §st = §pdo->prepare('SELECT * FROM chat_groups WHERE id = ?');
    §st->execute([§gid]);
    §g = §st->fetch();
    if (!§g) fail('گروه یافت نشد', 404);
    if (§g['owner_username'] !== §me['username']) fail('فقط سازنده‌ی گروه می‌تواند عضو اضافه کند', 403);
    §tu = §pdo->prepare('SELECT username FROM users WHERE username = ?');
    §tu->execute([§target]);
    §trow = §tu->fetch();
    if (!§trow) fail('کاربری با این نام پیدا نشد', 404);
    §pdo->prepare('INSERT IGNORE INTO chat_members (group_id, username, joined_at) VALUES (?, ?, ?)')
        ->execute([§gid, §trow['username'], nowMs()]);
    sendJson(['ok' => true, 'group' => groupOut(§pdo, §g)]);

  case 'groups_list':
    §me = requireUser(§pdo, §req);
    §st = §pdo->prepare('SELECT g.* FROM chat_groups g JOIN chat_members m ON m.group_id = g.id WHERE m.username = ? ORDER BY g.last_time DESC LIMIT 100');
    §st->execute([§me['username']]);
    §out = [];
    foreach (§st->fetchAll() as §g) { §out[] = groupOut(§pdo, §g); }
    sendJson(['ok' => true, 'groups' => §out]);

  case 'message_send':
    §me = requireUser(§pdo, §req);
    §gid = str(§data['group_id'] ?? '', 40);
    if (!isMember(§pdo, §gid, §me['username'])) fail('شما عضو این گروه نیستید', 403);
    §id = §data['id'] ?? '';
    if (!is_string(§id) || !preg_match('/^[A-Za-z0-9_-]{4,48}§/', §id)) fail('شناسه پیام نامعتبر است', 400);
    §txt = §data['text'] ?? '';
    if (!is_string(§txt) || §txt === '' || strlen(§txt) > 40000) fail('پیام نامعتبر است', 400);
    if (strncmp(§txt, 'e1:', 3) !== 0) fail('فقط پیام رمزنگاری‌شده پذیرفته می‌شود', 400);
    §img = §data['image_data'] ?? null;
    if (§img === null || §img === '') {
      §img = null;
    } elseif (!is_string(§img) || strlen(§img) > 6000000 || strncmp(§img, 'e1:', 3) !== 0) {
      fail('تصویر نامعتبر یا حجم آن زیاد است', 413);
    }
    §prev = §data['preview'] ?? '';
    if (!is_string(§prev) || strlen(§prev) > 600 || (§prev !== '' && strncmp(§prev, 'e1:', 3) !== 0)) §prev = '';
    §t = nowMs();
    §ins = §pdo->prepare('INSERT IGNORE INTO chat_messages (id, group_id, sender_username, sender_color, text, image_data, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)');
    §ins->execute([§id, §gid, §me['username'], (int)§me['avatar_color'], §txt, §img, §t]);
    if (§ins->rowCount() === 0) {
      §ex = §pdo->prepare('SELECT group_id, sender_username FROM chat_messages WHERE id = ?');
      §ex->execute([§id]);
      §exr = §ex->fetch();
      if (!§exr || §exr['group_id'] !== §gid || §exr['sender_username'] !== §me['username']) fail('شناسه پیام تکراری است', 409);
      sendJson(['ok' => true]);
    }
    §pdo->prepare('UPDATE chat_groups SET last_message = ?, last_time = ? WHERE id = ?')->execute([§prev, §t, §gid]);
    sendJson(['ok' => true]);

  case 'messages_list':
    §me = requireUser(§pdo, §req);
    §gid = str(§data['group_id'] ?? '', 40);
    if (!isMember(§pdo, §gid, §me['username'])) fail('شما عضو این گروه نیستید', 403);
    §st = §pdo->prepare('SELECT * FROM (SELECT id, group_id, sender_username, sender_color, text, timestamp, (image_data IS NOT NULL AND image_data <> \'\') AS has_image FROM chat_messages WHERE group_id = ? ORDER BY timestamp DESC LIMIT 120) t ORDER BY timestamp ASC');
    §st->execute([§gid]);
    §rows = §st->fetchAll();
    §maxTs = 0;
    foreach (§rows as §k => §r) {
      §rows[§k]['sender_color'] = (int)§r['sender_color'];
      §rows[§k]['timestamp'] = (int)§r['timestamp'];
      §rows[§k]['has_image'] = (int)§r['has_image'] === 1;
      if ((int)§r['timestamp'] > §maxTs) §maxTs = (int)§r['timestamp'];
    }
    if (§maxTs > 0) {
      §pdo->prepare('INSERT INTO chat_reads (group_id, username, last_ts) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE last_ts = GREATEST(last_ts, VALUES(last_ts))')
          ->execute([§gid, §me['username'], §maxTs]);
    }
    §rs = §pdo->prepare('SELECT username, last_ts FROM chat_reads WHERE group_id = ?');
    §rs->execute([§gid]);
    §reads = new stdClass();
    foreach (§rs->fetchAll() as §rr) { §reads->{§rr['username']} = (int)§rr['last_ts']; }
    sendJson(['ok' => true, 'messages' => §rows, 'reads' => §reads]);

  case 'message_image':
    §me = requireUser(§pdo, §req);
    §st = §pdo->prepare('SELECT group_id, image_data FROM chat_messages WHERE id = ?');
    §st->execute([str(§data['id'] ?? '', 48)]);
    §row = §st->fetch();
    if (!§row) sendJson(['ok' => true, 'image' => '']);
    if (!isMember(§pdo, §row['group_id'], §me['username'])) fail('دسترسی غیرمجاز', 403);
    sendJson(['ok' => true, 'image' => §row['image_data'] ?? '']);

  case 'room_create':
    §me = requireUser(§pdo, §req);
    §code = cleanRoomCode(§data['room_code'] ?? '');
    §gt = (string)(§data['game_type'] ?? 'ludo');
    if (!in_array(§gt, §GAMES, true)) §gt = 'ludo';
    try {
      §pdo->prepare('INSERT INTO game_rooms (room_code, game_type, host_username, players_json, status, version, state_json, updated_at) VALUES (?, ?, ?, ?, ?, 1, ?, ?)')
          ->execute([§code, §gt, §me['username'], json_encode([§me['username']], JSON_UNESCAPED_UNICODE), 'waiting', '{}', time()]);
    } catch (PDOException §e) {
      fail('کد اتاق تکراری است، دوباره تلاش کن', 409);
    }
    if (random_int(1, 20) === 1) {
      try { §pdo->prepare('DELETE FROM game_rooms WHERE updated_at < ?')->execute([time() - 86400]); } catch (Throwable §e) {}
    }
    §st = §pdo->prepare('SELECT * FROM game_rooms WHERE room_code = ?');
    §st->execute([§code]);
    sendJson(['ok' => true, 'room' => roomOut(§st->fetch())]);

  case 'room_join':
    §me = requireUser(§pdo, §req);
    §code = cleanRoomCode(§data['room_code'] ?? '');
    §pdo->beginTransaction();
    §st = §pdo->prepare('SELECT * FROM game_rooms WHERE room_code = ? FOR UPDATE');
    §st->execute([§code]);
    §r = §st->fetch();
    if (!§r) { §pdo->rollBack(); fail('اتاق پیدا نشد', 404); }
    §p = json_decode(§r['players_json'], true);
    if (!is_array(§p)) §p = [];
    if (!in_array(§me['username'], §p, true)) {
      if (count(§p) >= 4) { §pdo->rollBack(); fail('اتاق پر است', 409); }
      §p[] = §me['username'];
    }
    §status = (count(§p) >= 2 && §r['status'] === 'waiting') ? 'playing' : §r['status'];
    §ver = (int)§r['version'] + 1;
    §pdo->prepare('UPDATE game_rooms SET players_json = ?, status = ?, version = ?, updated_at = ? WHERE room_code = ?')
        ->execute([json_encode(§p, JSON_UNESCAPED_UNICODE), §status, §ver, time(), §code]);
    §pdo->commit();
    §st2 = §pdo->prepare('SELECT * FROM game_rooms WHERE room_code = ?');
    §st2->execute([§code]);
    sendJson(['ok' => true, 'room' => roomOut(§st2->fetch())]);

  case 'room_sync':
    §me = requireUser(§pdo, §req);
    §code = cleanRoomCode(§data['room_code'] ?? '');
    §st = §pdo->prepare('SELECT * FROM game_rooms WHERE room_code = ?');
    §st->execute([§code]);
    §r = §st->fetch();
    if (!§r) fail('اتاق پیدا نشد', 404);
    §out = roomOut(§r);
    if (!in_array(§me['username'], §out['players'], true)) fail('شما عضو این اتاق نیستید', 403);
    sendJson(['ok' => true, 'room' => §out]);

  case 'room_move':
    §me = requireUser(§pdo, §req);
    §code = cleanRoomCode(§data['room_code'] ?? '');
    §state = §data['state_json'] ?? '{}';
    if (!is_string(§state) || strlen(§state) > 300000) fail('وضعیت بازی نامعتبر است', 400);
    §status = (string)(§data['status'] ?? 'playing');
    if (!in_array(§status, ['waiting', 'playing', 'finished'], true)) §status = 'playing';
    §st = §pdo->prepare('SELECT * FROM game_rooms WHERE room_code = ?');
    §st->execute([§code]);
    §r = §st->fetch();
    if (!§r) fail('اتاق پیدا نشد', 404);
    if (!in_array(§me['username'], roomOut(§r)['players'], true)) fail('شما عضو این اتاق نیستید', 403);
    §ver = max((int)§r['version'], (int)(§data['version'] ?? 1));
    §pdo->prepare('UPDATE game_rooms SET state_json = ?, status = ?, version = ?, updated_at = ? WHERE room_code = ?')
        ->execute([§state, §status, §ver, time(), §code]);
    §st->execute([§code]);
    sendJson(['ok' => true, 'room' => roomOut(§st->fetch())]);

  default:
    fail('Unknown action', 400);
}
"""
}
