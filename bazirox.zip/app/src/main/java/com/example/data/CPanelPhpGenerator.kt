package com.example.data

/**
 * Generates production-ready, SQL-injection-proof PHP 8 PDO + MySQL scripts
 * tailored to the admin's Iranian cPanel settings, with matching HMAC-SHA256
 * verification and AES-256-GCM payload encryption.
 */
object CPanelPhpGenerator {

  fun generateSchemaSql(): String =
    """
    -- Bazirox Secure MySQL Schema for Iranian cPanel (utf8mb4)
    CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(32) NOT NULL UNIQUE,
      display_name VARCHAR(64) NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      avatar_color INT NOT NULL DEFAULT 0,
      total_score INT NOT NULL DEFAULT 0,
      wins INT NOT NULL DEFAULT 0,
      games_played INT NOT NULL DEFAULT 0,
      favorite_game VARCHAR(24) NOT NULL DEFAULT 'ludo',
      auth_token VARCHAR(128) DEFAULT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS chat_groups (
      id VARCHAR(40) PRIMARY KEY,
      name VARCHAR(80) NOT NULL,
      invite_code VARCHAR(16) NOT NULL UNIQUE,
      owner_username VARCHAR(32) NOT NULL,
      members_json TEXT NOT NULL,
      last_message VARCHAR(255) DEFAULT '',
      last_time BIGINT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS chat_messages (
      id VARCHAR(48) PRIMARY KEY,
      group_id VARCHAR(40) NOT NULL,
      sender_username VARCHAR(32) NOT NULL,
      sender_color INT NOT NULL DEFAULT 0,
      text TEXT NOT NULL,
      game_invite_json TEXT DEFAULT NULL,
      extra_json TEXT DEFAULT NULL,
      image_data MEDIUMTEXT DEFAULT NULL,
      timestamp BIGINT NOT NULL,
      INDEX idx_group_time (group_id, timestamp)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS chat_reads (
      group_id VARCHAR(40) NOT NULL,
      username VARCHAR(32) NOT NULL,
      last_ts BIGINT NOT NULL DEFAULT 0,
      PRIMARY KEY (group_id, username)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    CREATE TABLE IF NOT EXISTS game_rooms (
      room_code VARCHAR(16) PRIMARY KEY,
      game_type VARCHAR(24) NOT NULL,
      host_username VARCHAR(32) NOT NULL,
      players_json TEXT NOT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'waiting',
      version INT NOT NULL DEFAULT 1,
      state_json MEDIUMTEXT NOT NULL,
      updated_at BIGINT NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    """.trimIndent()

  fun generateApiPhp(config: CPanelConfig): String {
    val dbHost = config.dbHost.ifBlank { "localhost" }.escapePhp()
    val dbName = config.dbName.ifBlank { "cpaneluser_baziland" }.escapePhp()
    val dbUser = config.dbUser.ifBlank { "cpaneluser_dbuser" }.escapePhp()
    val dbPass = config.dbPassword.escapePhp()
    val secret = config.apiSecret.ifBlank { "CHANGE_ME_SECRET" }.escapePhp()
    val hmacFlag = if (config.hmacEnabled) "true" else "false"
    val e2eeFlag = if (config.e2eeEnabled) "true" else "false"
    val maintFlag = if (config.maintenanceMode) "true" else "false"

    return """
    <?php
    // BaziLand Secure cPanel API (PHP 8.x + PDO MySQL + HMAC-SHA256 + AES-256-GCM)
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');

    define('DB_HOST', '$dbHost');
    define('DB_NAME', '$dbName');
    define('DB_USER', '$dbUser');
    define('DB_PASS', '$dbPass');
    define('API_SECRET', '$secret');
    define('ENABLE_HMAC', $hmacFlag);
    define('ENABLE_E2EE', $e2eeFlag);
    define('MAINTENANCE_MODE', $maintFlag);

    function aesKey(): string {
      return hash('sha256', 'BaziLand_AES256_Key:' . API_SECRET, true);
    }

    function decryptPayload(string ${'$'}b64): ?string {
      ${'$'}raw = base64_decode(${'$'}b64, true);
      if (${'$'}raw === false || strlen(${'$'}raw) <= 28) return null;
      ${'$'}iv = substr(${'$'}raw, 0, 12);
      ${'$'}tag = substr(${'$'}raw, 12, 16);
      ${'$'}cipher = substr(${'$'}raw, 28);
      ${'$'}plain = openssl_decrypt(${'$'}cipher, 'aes-256-gcm', aesKey(), OPENSSL_RAW_DATA, ${'$'}iv, ${'$'}tag);
      return ${'$'}plain === false ? null : ${'$'}plain;
    }

    function encryptPayload(string ${'$'}plain): string {
      ${'$'}iv = random_bytes(12);
      ${'$'}tag = '';
      ${'$'}cipher = openssl_encrypt(${'$'}plain, 'aes-256-gcm', aesKey(), OPENSSL_RAW_DATA, ${'$'}iv, ${'$'}tag, '', 16);
      return base64_encode(${'$'}iv . ${'$'}tag . ${'$'}cipher);
    }

    function sendJson(array ${'$'}payload, int ${'$'}code = 200): void {
      http_response_code(${'$'}code);
      ${'$'}json = json_encode(${'$'}payload, JSON_UNESCAPED_UNICODE);
      if (ENABLE_E2EE) {
        echo json_encode(['enc' => encryptPayload(${'$'}json)]);
      } else {
        echo ${'$'}json;
      }
      exit;
    }

    if (MAINTENANCE_MODE && (${'$'}_GET['action'] ?? '') !== 'ping') {
      sendJson(['ok' => false, 'error' => 'سرور در حال بروزرسانی است'], 503);
    }

    ${'$'}rawBody = file_get_contents('php://input') ?: '';
    ${'$'}action = ${'$'}_GET['action'] ?? '';
    ${'$'}ts = (int)(${'$'}_SERVER['HTTP_X_BAZILAND_TIMESTAMP'] ?? 0);
    ${'$'}nonce = ${'$'}_SERVER['HTTP_X_BAZILAND_NONCE'] ?? '';
    ${'$'}sig = ${'$'}_SERVER['HTTP_X_BAZILAND_SIGNATURE'] ?? '';

    if (ENABLE_HMAC) {
      if (abs(time() - ${'$'}ts) > 120 || ${'$'}nonce === '' || ${'$'}sig === '') {
        sendJson(['ok' => false, 'error' => 'Invalid security timestamp/nonce'], 401);
      }
      ${'$'}expected = hash_hmac('sha256', "${'$'}action|${'$'}ts|${'$'}nonce|${'$'}rawBody", API_SECRET);
      if (!hash_equals(${'$'}expected, ${'$'}sig)) {
        sendJson(['ok' => false, 'error' => 'Invalid HMAC signature'], 403);
      }
    }

    ${'$'}req = json_decode(${'$'}rawBody, true) ?? [];
    if (isset(${'$'}req['enc']) && ENABLE_E2EE) {
      ${'$'}dec = decryptPayload(${'$'}req['enc']);
      if (${'$'}dec === null) sendJson(['ok' => false, 'error' => 'Decrypt failed'], 400);
      ${'$'}req = json_decode(${'$'}dec, true) ?? [];
    }
    ${'$'}data = ${'$'}req['data'] ?? [];

    try {
      ${'$'}pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
      );
    } catch (Throwable ${'$'}e) {
      sendJson(['ok' => false, 'db_ok' => false, 'error' => 'خطا در اتصال به MySQL'], 500);
    }

    function ensureChatSchema(PDO ${'$'}pdo): void {
      ${'$'}flag = __DIR__ . '/.chat_schema_v2';
      if (file_exists(${'$'}flag)) return;
      foreach ([
        "ALTER TABLE chat_messages ADD COLUMN extra_json TEXT NULL",
        "ALTER TABLE chat_messages ADD COLUMN image_data MEDIUMTEXT NULL",
      ] as ${'$'}sql) { try { ${'$'}pdo->exec(${'$'}sql); } catch (Throwable ${'$'}e) {} }
      try {
        ${'$'}pdo->exec("CREATE TABLE IF NOT EXISTS chat_reads (group_id VARCHAR(40) NOT NULL, username VARCHAR(32) NOT NULL, last_ts BIGINT NOT NULL DEFAULT 0, PRIMARY KEY (group_id, username)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      } catch (Throwable ${'$'}e) {}
      @file_put_contents(${'$'}flag, '1');
    }

        switch (${'$'}action) {
      case 'ping':
        sendJson(['ok' => true, 'db_ok' => true, 'message' => 'هاست ایران متصل و امن است', 'server_time' => date('c')]);

      case 'register':
        ${'$'}u = trim(${'$'}data['username'] ?? '');
        ${'$'}ph = ${'$'}data['password_hash'] ?? '';
        ${'$'}dn = trim(${'$'}data['display_name'] ?? ${'$'}u);
        ${'$'}col = (int)(${'$'}data['avatar_color'] ?? 0);
        if (strlen(${'$'}u) < 3 || ${'$'}ph === '') sendJson(['ok' => false, 'error' => 'ورودی نامعتبر'], 400);
        ${'$'}stmt = ${'$'}pdo->prepare('SELECT id FROM users WHERE LOWER(username)=LOWER(?)');
        ${'$'}stmt->execute([${'$'}u]);
        if (${'$'}stmt->fetch()) sendJson(['ok' => false, 'error' => 'نام کاربری تکراری است'], 409);
        ${'$'}token = bin2hex(random_bytes(24));
        ${'$'}hash = password_hash(${'$'}ph, PASSWORD_ARGON2ID);
        ${'$'}ins = ${'$'}pdo->prepare('INSERT INTO users (username, display_name, password_hash, avatar_color, auth_token) VALUES (?, ?, ?, ?, ?)');
        ${'$'}ins->execute([${'$'}u, ${'$'}dn, ${'$'}hash, ${'$'}col, ${'$'}token]);
        sendJson(['ok' => true, 'token' => ${'$'}token, 'user' => ['username' => ${'$'}u, 'display_name' => ${'$'}dn, 'avatar_color' => ${'$'}col, 'total_score' => 0, 'wins' => 0, 'games_played' => 0]]);

      case 'login':
        ${'$'}u = trim(${'$'}data['username'] ?? '');
        ${'$'}ph = ${'$'}data['password_hash'] ?? '';
        ${'$'}stmt = ${'$'}pdo->prepare('SELECT * FROM users WHERE LOWER(username)=LOWER(?)');
        ${'$'}stmt->execute([${'$'}u]);
        ${'$'}row = ${'$'}stmt->fetch();
        if (!${'$'}row || !password_verify(${'$'}ph, ${'$'}row['password_hash'])) sendJson(['ok' => false, 'error' => 'نام کاربری یا رمز اشتباه است'], 401);
        ${'$'}token = bin2hex(random_bytes(24));
        ${'$'}pdo->prepare('UPDATE users SET auth_token=? WHERE id=?')->execute([${'$'}token, ${'$'}row['id']]);
        sendJson(['ok' => true, 'token' => ${'$'}token, 'user' => ${'$'}row]);

      case 'submit_score':
        ${'$'}u = trim(${'$'}data['username'] ?? '');
        ${'$'}ds = (int)(${'$'}data['delta_score'] ?? 0);
        ${'$'}win = !empty(${'$'}data['did_win']) ? 1 : 0;
        ${'$'}gt = ${'$'}data['game_type'] ?? 'ludo';
        ${'$'}pdo->prepare('UPDATE users SET total_score = GREATEST(0, total_score + ?), wins = wins + ?, games_played = games_played + 1, favorite_game = ? WHERE LOWER(username)=LOWER(?)')
            ->execute([${'$'}ds, ${'$'}win, ${'$'}gt, ${'$'}u]);
        sendJson(['ok' => true]);

      case 'leaderboard':
        ${'$'}rows = ${'$'}pdo->query('SELECT username, display_name, avatar_color, total_score, wins, games_played, favorite_game FROM users ORDER BY total_score DESC, wins DESC LIMIT 50')->fetchAll();
        sendJson(['ok' => true, 'entries' => ${'$'}rows]);

      case 'group_create':
        ${'$'}id = 'grp_' . bin2hex(random_bytes(6));
        ${'$'}code = strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
        ${'$'}owner = trim(${'$'}data['username'] ?? '');
        ${'$'}name = trim(${'$'}data['name'] ?? 'گروه جدید');
        ${'$'}members = json_encode([${'$'}owner], JSON_UNESCAPED_UNICODE);
        ${'$'}pdo->prepare('INSERT INTO chat_groups (id, name, invite_code, owner_username, members_json, last_time) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([${'$'}id, ${'$'}name, ${'$'}code, ${'$'}owner, ${'$'}members, (int)(microtime(true)*1000)]);
        sendJson(['ok' => true, 'group' => ['id' => ${'$'}id, 'name' => ${'$'}name, 'invite_code' => ${'$'}code, 'owner_username' => ${'$'}owner, 'members' => [${'$'}owner], 'last_message' => '', 'last_time' => 0]]);

      case 'group_join':
        ${'$'}code = strtoupper(trim(${'$'}data['invite_code'] ?? ''));
        ${'$'}u = trim(${'$'}data['username'] ?? '');
        ${'$'}stmt = ${'$'}pdo->prepare('SELECT * FROM chat_groups WHERE invite_code=?');
        ${'$'}stmt->execute([${'$'}code]);
        ${'$'}g = ${'$'}stmt->fetch();
        if (!${'$'}g) sendJson(['ok' => false, 'error' => 'کد دعوت معتبر نیست'], 404);
        ${'$'}m = json_decode(${'$'}g['members_json'], true) ?? [];
        if (!in_array(${'$'}u, ${'$'}m, true)) { ${'$'}m[] = ${'$'}u; }
        ${'$'}pdo->prepare('UPDATE chat_groups SET members_json=? WHERE id=?')->execute([json_encode(${'$'}m, JSON_UNESCAPED_UNICODE), ${'$'}g['id']]);
        ${'$'}g['members'] = ${'$'}m;
        sendJson(['ok' => true, 'group' => ${'$'}g]);

      case 'group_invite':
        ${'$'}gid = ${'$'}data['group_id'] ?? '';
        ${'$'}target = trim(${'$'}data['target_username'] ?? '');
        ${'$'}stmt = ${'$'}pdo->prepare('SELECT * FROM chat_groups WHERE id=?');
        ${'$'}stmt->execute([${'$'}gid]);
        ${'$'}g = ${'$'}stmt->fetch();
        if (!${'$'}g) sendJson(['ok' => false, 'error' => 'گروه یافت نشد'], 404);
        ${'$'}m = json_decode(${'$'}g['members_json'], true) ?? [];
        if (!in_array(${'$'}target, ${'$'}m, true)) { ${'$'}m[] = ${'$'}target; }
        ${'$'}pdo->prepare('UPDATE chat_groups SET members_json=? WHERE id=?')->execute([json_encode(${'$'}m, JSON_UNESCAPED_UNICODE), ${'$'}gid]);
        ${'$'}g['members'] = ${'$'}m;
        sendJson(['ok' => true, 'group' => ${'$'}g]);

      case 'groups_list':
        ${'$'}u = trim(${'$'}data['username'] ?? '');
        ${'$'}all = ${'$'}pdo->query('SELECT * FROM chat_groups ORDER BY last_time DESC LIMIT 100')->fetchAll();
        ${'$'}out = [];
        foreach (${'$'}all as ${'$'}g) {
          ${'$'}m = json_decode(${'$'}g['members_json'], true) ?? [];
          if (${'$'}u === '' || in_array(${'$'}u, ${'$'}m, true)) { ${'$'}g['members'] = ${'$'}m; ${'$'}out[] = ${'$'}g; }
        }
        sendJson(['ok' => true, 'groups' => ${'$'}out]);

      case 'message_send':
        ensureChatSchema(${'$'}pdo);
        ${'$'}gid = ${'$'}data['group_id'] ?? '';
        ${'$'}inv = isset(${'$'}data['game_invite']) ? json_encode(${'$'}data['game_invite'], JSON_UNESCAPED_UNICODE) : null;
        ${'$'}extra = isset(${'$'}data['reply']) ? json_encode(['reply' => ${'$'}data['reply']], JSON_UNESCAPED_UNICODE) : null;
        ${'$'}img = (isset(${'$'}data['image_data']) && ${'$'}data['image_data'] !== '') ? ${'$'}data['image_data'] : null;
        if (${'$'}img !== null && strlen(${'$'}img) > 6000000) sendJson(['ok' => false, 'error' => 'حجم عکس زیاد است'], 413);
        ${'$'}txt = (string)(${'$'}data['text'] ?? '');
        ${'$'}pdo->prepare('INSERT IGNORE INTO chat_messages (id, group_id, sender_username, sender_color, text, game_invite_json, extra_json, image_data, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([${'$'}data['id'], ${'$'}gid, ${'$'}data['sender_username'], (int)${'$'}data['sender_color'], ${'$'}txt, ${'$'}inv, ${'$'}extra, ${'$'}img, (int)${'$'}data['timestamp']]);
        ${'$'}preview = ${'$'}img !== null ? ('📷 ' . (${'$'}txt !== '' ? ${'$'}txt : 'عکس')) : ${'$'}txt;
        ${'$'}pdo->prepare('UPDATE chat_groups SET last_message=?, last_time=? WHERE id=?')->execute([mb_substr(${'$'}preview, 0, 60), (int)${'$'}data['timestamp'], ${'$'}gid]);
        sendJson(['ok' => true]);

      case 'messages_list':
        ensureChatSchema(${'$'}pdo);
        ${'$'}gid = ${'$'}data['group_id'] ?? '';
        ${'$'}viewer = trim(${'$'}data['viewer'] ?? '');
        ${'$'}stmt = ${'$'}pdo->prepare('SELECT * FROM (SELECT id, group_id, sender_username, sender_color, text, game_invite_json, extra_json, timestamp, (image_data IS NOT NULL AND image_data <> \'\') AS has_image FROM chat_messages WHERE group_id=? ORDER BY timestamp DESC LIMIT 120) t ORDER BY timestamp ASC');
        ${'$'}stmt->execute([${'$'}gid]);
        ${'$'}rows = ${'$'}stmt->fetchAll();
        ${'$'}maxTs = 0;
        foreach (${'$'}rows as &${'$'}r) {
          ${'$'}r['game_invite'] = ${'$'}r['game_invite_json'] ? json_decode(${'$'}r['game_invite_json'], true) : null;
          ${'$'}ex = ${'$'}r['extra_json'] ? json_decode(${'$'}r['extra_json'], true) : null;
          ${'$'}r['reply'] = ${'$'}ex['reply'] ?? null;
          ${'$'}r['has_image'] = (int)${'$'}r['has_image'] === 1;
          unset(${'$'}r['game_invite_json'], ${'$'}r['extra_json']);
          if ((int)${'$'}r['timestamp'] > ${'$'}maxTs) ${'$'}maxTs = (int)${'$'}r['timestamp'];
        }
        unset(${'$'}r);
        if (${'$'}viewer !== '' && ${'$'}maxTs > 0) {
          ${'$'}pdo->prepare('INSERT INTO chat_reads (group_id, username, last_ts) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE last_ts = GREATEST(last_ts, VALUES(last_ts))')
              ->execute([${'$'}gid, ${'$'}viewer, ${'$'}maxTs]);
        }
        ${'$'}rs = ${'$'}pdo->prepare('SELECT username, last_ts FROM chat_reads WHERE group_id=?');
        ${'$'}rs->execute([${'$'}gid]);
        ${'$'}reads = new stdClass();
        foreach (${'$'}rs->fetchAll() as ${'$'}rr) { ${'$'}reads->{${'$'}rr['username']} = (int)${'$'}rr['last_ts']; }
        sendJson(['ok' => true, 'messages' => ${'$'}rows, 'reads' => ${'$'}reads]);

      case 'message_image':
        ensureChatSchema(${'$'}pdo);
        ${'$'}st = ${'$'}pdo->prepare('SELECT image_data FROM chat_messages WHERE id=?');
        ${'$'}st->execute([${'$'}data['id'] ?? '']);
        ${'$'}row = ${'$'}st->fetch();
        sendJson(['ok' => true, 'image' => ${'$'}row['image_data'] ?? '']);

      case 'room_create':
        ${'$'}code = strtoupper(trim(${'$'}data['room_code'] ?? ''));
        ${'$'}gt = ${'$'}data['game_type'] ?? 'ludo';
        ${'$'}u = trim(${'$'}data['username'] ?? 'player');
        ${'$'}players = json_encode([${'$'}u], JSON_UNESCAPED_UNICODE);
        ${'$'}pdo->prepare('REPLACE INTO game_rooms (room_code, game_type, host_username, players_json, status, version, state_json, updated_at) VALUES (?, ?, ?, ?, ?, 1, ?, ?)')
            ->execute([${'$'}code, ${'$'}gt, ${'$'}u, ${'$'}players, 'waiting', '{}', time()]);
        sendJson(['ok' => true, 'room' => ['room_code' => ${'$'}code, 'game_type' => ${'$'}gt, 'host_username' => ${'$'}u, 'players' => [${'$'}u], 'status' => 'waiting', 'version' => 1, 'state_json' => '{}']]);

      case 'room_join':
        ${'$'}code = strtoupper(trim(${'$'}data['room_code'] ?? ''));
        ${'$'}u = trim(${'$'}data['username'] ?? 'guest');
        ${'$'}stmt = ${'$'}pdo->prepare('SELECT * FROM game_rooms WHERE room_code=?');
        ${'$'}stmt->execute([${'$'}code]);
        ${'$'}r = ${'$'}stmt->fetch();
        if (!${'$'}r) sendJson(['ok' => false, 'error' => 'اتاق پیدا نشد'], 404);
        ${'$'}p = json_decode(${'$'}r['players_json'], true) ?? [];
        if (!in_array(${'$'}u, ${'$'}p, true)) { ${'$'}p[] = ${'$'}u; }
        ${'$'}status = count(${'$'}p) >= 2 ? 'playing' : ${'$'}r['status'];
        ${'$'}ver = (int)${'$'}r['version'] + 1;
        ${'$'}pdo->prepare('UPDATE game_rooms SET players_json=?, status=?, version=?, updated_at=? WHERE room_code=?')
            ->execute([json_encode(${'$'}p, JSON_UNESCAPED_UNICODE), ${'$'}status, ${'$'}ver, time(), ${'$'}code]);
        ${'$'}r['players'] = ${'$'}p; ${'$'}r['status'] = ${'$'}status; ${'$'}r['version'] = ${'$'}ver;
        sendJson(['ok' => true, 'room' => ${'$'}r]);

      case 'room_sync':
        ${'$'}code = strtoupper(trim(${'$'}data['room_code'] ?? ''));
        ${'$'}stmt = ${'$'}pdo->prepare('SELECT * FROM game_rooms WHERE room_code=?');
        ${'$'}stmt->execute([${'$'}code]);
        ${'$'}r = ${'$'}stmt->fetch();
        if (!${'$'}r) sendJson(['ok' => false, 'error' => 'اتاق پیدا نشد'], 404);
        ${'$'}r['players'] = json_decode(${'$'}r['players_json'], true) ?? [];
        sendJson(['ok' => true, 'room' => ${'$'}r]);

      case 'room_move':
        ${'$'}code = strtoupper(trim(${'$'}data['room_code'] ?? ''));
        ${'$'}ver = (int)(${'$'}data['version'] ?? 1);
        ${'$'}pdo->prepare('UPDATE game_rooms SET state_json=?, status=?, version=?, updated_at=? WHERE room_code=?')
            ->execute([${'$'}data['state_json'], ${'$'}data['status'] ?? 'playing', ${'$'}ver, time(), ${'$'}code]);
        ${'$'}stmt = ${'$'}pdo->prepare('SELECT * FROM game_rooms WHERE room_code=?');
        ${'$'}stmt->execute([${'$'}code]);
        ${'$'}r = ${'$'}stmt->fetch();
        ${'$'}r['players'] = json_decode(${'$'}r['players_json'], true) ?? [];
        sendJson(['ok' => true, 'room' => ${'$'}r]);

      default:
        sendJson(['ok' => false, 'error' => 'Unknown action'], 400);
    }
    """.trimIndent()
  }

  private fun String.escapePhp(): String = replace("\\", "\\\\").replace("'", "\\'")
}
