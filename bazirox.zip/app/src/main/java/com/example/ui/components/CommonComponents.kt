package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.GameType
import com.example.data.PlayMode
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlayerBlue
import com.example.ui.theme.PlayerGreen
import com.example.ui.theme.PlayerRed
import com.example.ui.theme.PlayerYellow
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPulse
import kotlin.math.ceil
import kotlin.random.Random
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

val AvatarPalette = listOf(NeonCyan, VioletPulse, CyberGold, ElectricEmerald, CrimsonMagenta, PlayerBlue)

fun avatarColorFor(index: Int): Color = AvatarPalette[index.mod(AvatarPalette.size)]

fun playerColorFor(index: Int): Color =
  when (index.mod(4)) {
    0 -> PlayerRed
    1 -> PlayerGreen
    2 -> PlayerYellow
    else -> PlayerBlue
  }

/**
 * Frosted Glassmorphic Gradient container with specular top-left rim and soft inner tint.
 */
@Composable
fun GlassGradientCard(
  modifier: Modifier = Modifier,
  accentColor: Color = NeonCyan,
  cornerRadius: Dp = 22.dp,
  onClick: (() -> Unit)? = null,
  content: @Composable BoxScope.() -> Unit,
) {
  val shape: Shape = RoundedCornerShape(cornerRadius)
  val borderBrush =
    Brush.linearGradient(
      colors =
        listOf(
          Color.White.copy(alpha = 0.28f),
          accentColor.copy(alpha = 0.38f),
          Color.White.copy(alpha = 0.06f),
        )
    )
  val fillBrush =
    Brush.linearGradient(
      colors =
        listOf(
          Color(0xCC1B2542),
          Color(0xB3121A30),
          accentColor.copy(alpha = 0.12f),
        )
    )

  Box(
    modifier =
      modifier
        .clip(shape)
        .background(fillBrush)
        .border(1.2.dp, borderBrush, shape)
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
    content = content,
  )
}

/**
 * Deep aurora gradient backdrop used across all screens for a cohesive glassmorphic vibe.
 */
fun Modifier.auroraGamingBackdrop(
  primaryGlow: Color = NeonCyan,
  secondaryGlow: Color = VioletPulse,
): Modifier =
  this.background(
      Brush.verticalGradient(
        colors = listOf(Color(0xFF070B14), Color(0xFF0C1428), Color(0xFF080D1A))
      )
    )
    .drawBehind {
      drawCircle(
        brush =
          Brush.radialGradient(
            colors = listOf(primaryGlow.copy(alpha = 0.18f), Color.Transparent),
            center = Offset(size.width * 0.18f, size.height * 0.10f),
            radius = size.width * 0.72f,
          )
      )
      drawCircle(
        brush =
          Brush.radialGradient(
            colors = listOf(secondaryGlow.copy(alpha = 0.16f), Color.Transparent),
            center = Offset(size.width * 0.86f, size.height * 0.48f),
            radius = size.width * 0.68f,
          )
      )
    }

/**
 * Draws a rich, 3D-beveled glossy game token/pawn on Canvas with drop shadow,
 * inner metallic ring, and top-left specular glare.
 */
fun DrawScope.drawGlossyToken(
  center: Offset,
  radius: Float,
  baseColor: Color,
  isHighlighted: Boolean = false,
  pulseFactor: Float = 1f,
) {
  if (isHighlighted) {
    drawCircle(
      color = Color.White.copy(alpha = 0.30f),
      radius = radius * (1.42f + 0.18f * pulseFactor),
      center = center,
    )
    drawCircle(
      color = CyberGold,
      radius = radius * 1.28f,
      center = center,
      style = Stroke(width = (radius * 0.18f).coerceAtLeast(2.5f)),
    )
  }

  drawCircle(
    color = Color.Black.copy(alpha = 0.55f),
    radius = radius * 1.06f,
    center = Offset(center.x + radius * 0.10f, center.y + radius * 0.18f),
  )

  drawCircle(color = ObsidianBg, radius = radius * 1.04f, center = center)

  drawCircle(
    brush =
      Brush.radialGradient(
        colors = listOf(Color.White.copy(alpha = 0.88f), baseColor, baseColor.copy(alpha = 0.62f)),
        center = Offset(center.x - radius * 0.28f, center.y - radius * 0.28f),
        radius = radius * 1.32f,
      ),
    radius = radius * 0.92f,
    center = center,
  )

  drawCircle(
    color = Color.White.copy(alpha = 0.45f),
    radius = radius * 0.62f,
    center = center,
    style = Stroke(width = (radius * 0.10f).coerceAtLeast(1.5f)),
  )

  drawCircle(
    color = Color.White.copy(alpha = 0.75f),
    radius = radius * 0.22f,
    center = Offset(center.x - radius * 0.30f, center.y - radius * 0.30f),
  )
}

/**
 * Smooth 3D-tumbling dice. All motion runs on Animatables read inside graphicsLayer / draw
 * lambdas, so rolling never recomposes the parent game screen (no lag). Only the face value
 * changes via local state (~14 fps) while the dice tumbles; on stop it settles with a spring.
 */
@Composable
fun AnimatedGameDice(
  value: Int,
  isRolling: Boolean,
  accentColor: Color,
  modifier: Modifier = Modifier,
) {
  var tumbleFace by remember { mutableIntStateOf(value.coerceIn(1, 6)) }
  val spinZ = remember { Animatable(0f) }
  val spinX = remember { Animatable(0f) }
  val spinY = remember { Animatable(0f) }
  val hop = remember { Animatable(0f) }
  val pop = remember { Animatable(1f) }

  LaunchedEffect(isRolling) {
    if (isRolling) {
      coroutineScope {
        launch { pop.animateTo(1.14f, tween(120, easing = FastOutSlowInEasing)) }
        launch {
          while (isActive) spinZ.animateTo(spinZ.value + 360f, tween(520, easing = LinearEasing))
        }
        launch {
          while (isActive) spinX.animateTo(spinX.value + 360f, tween(680, easing = LinearEasing))
        }
        launch {
          while (isActive) spinY.animateTo(spinY.value + 360f, tween(860, easing = LinearEasing))
        }
        launch {
          while (isActive) {
            hop.animateTo(1f, tween(170, easing = FastOutSlowInEasing))
            hop.animateTo(0f, tween(150, easing = FastOutLinearInEasing))
          }
        }
        launch {
          while (isActive) {
            delay(70)
            var n: Int
            do {
              n = Random.nextInt(1, 7)
            } while (n == tumbleFace)
            tumbleFace = n
          }
        }
      }
    } else {
      val settle = spring<Float>(dampingRatio = 0.55f, stiffness = Spring.StiffnessMediumLow)
      coroutineScope {
        launch { spinZ.animateTo(ceil(spinZ.value / 360f) * 360f, settle) }
        launch { spinX.animateTo(ceil(spinX.value / 360f) * 360f, settle) }
        launch { spinY.animateTo(ceil(spinY.value / 360f) * 360f, settle) }
        launch { hop.animateTo(0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy)) }
        launch { pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy)) }
      }
    }
  }

  val shown = if (isRolling) tumbleFace else value.coerceIn(1, 6)
  val shape = RoundedCornerShape(16.dp)

  Box(modifier = modifier.size(72.dp), contentAlignment = Alignment.Center) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val lift = hop.value
      val w = size.width * (0.62f - 0.12f * lift)
      val h = size.height * (0.12f - 0.03f * lift)
      drawOval(
        color = Color.Black.copy(alpha = 0.40f - 0.20f * lift),
        topLeft = Offset((size.width - w) / 2f, size.height * 0.90f - h / 2f),
        size = androidx.compose.ui.geometry.Size(w, h),
      )
    }
    Box(
      modifier =
        Modifier.size(58.dp)
          .graphicsLayer {
            cameraDistance = 14f * density
            translationY = -hop.value * 14.dp.toPx()
            rotationZ = spinZ.value
            rotationX = spinX.value
            rotationY = spinY.value
            scaleX = pop.value
            scaleY = pop.value
          }
          .clip(shape)
          .background(Brush.verticalGradient(listOf(Color(0xFF2E3F68), Color(0xFF131B2E))))
          .border(2.dp, accentColor, shape)
    ) {
      Canvas(modifier = Modifier.fillMaxSize().padding(9.dp)) {
        val w = size.width
        val h = size.height
        val pipRadius = minOf(w, h) * 0.115f
        val c1 = 0.24f
        val c2 = 0.50f
        val c3 = 0.76f
        val pips: List<Pair<Float, Float>> =
          when (shown) {
            1 -> listOf(c2 to c2)
            2 -> listOf(c1 to c1, c3 to c3)
            3 -> listOf(c1 to c1, c2 to c2, c3 to c3)
            4 -> listOf(c1 to c1, c3 to c1, c1 to c3, c3 to c3)
            5 -> listOf(c1 to c1, c3 to c1, c2 to c2, c1 to c3, c3 to c3)
            else -> listOf(c1 to c1, c3 to c1, c1 to c2, c3 to c2, c1 to c3, c3 to c3)
          }
        pips.forEach { (px, py) ->
          val pos = Offset(w * px, h * py)
          drawCircle(color = accentColor.copy(alpha = 0.35f), radius = pipRadius * 1.45f, center = pos)
          drawCircle(color = if (shown == 6) CyberGold else TextPrimary, radius = pipRadius, center = pos)
        }
      }
    }
  }
}

@Composable
fun AvatarBadge(
  name: String,
  colorIndex: Int,
  size: Dp = 42.dp,
  modifier: Modifier = Modifier,
) {
  val bg = avatarColorFor(colorIndex)
  val letter = name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "ب"
  Box(
    modifier =
      modifier
        .size(size)
        .clip(CircleShape)
        .background(Brush.linearGradient(listOf(bg.copy(alpha = 0.92f), bg.copy(alpha = 0.35f))))
        .border(2.dp, bg, CircleShape),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = letter,
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.ExtraBold,
      color = TextPrimary,
    )
  }
}

@Composable
fun ServerStatusPill(isConnected: Boolean, modifier: Modifier = Modifier) {
  val color = if (isConnected) ElectricEmerald else CyberGold
  val infinite = rememberInfiniteTransition(label = "online_pulse")
  val dotAlpha by
    infinite.animateFloat(
      initialValue = 0.45f,
      targetValue = 1f,
      animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
      label = "dot_alpha",
    )

  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(50),
    color = color.copy(alpha = 0.14f),
    border = BorderStroke(1.dp, color.copy(alpha = 0.5f)),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Box(
        modifier =
          Modifier.size(8.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = if (isConnected) dotAlpha else 0.85f))
      )
      Text(
        text = if (isConnected) "آنلاین" else "آفلاین",
        style = MaterialTheme.typography.labelSmall,
        color = color,
        fontWeight = FontWeight.Bold,
      )
    }
  }
}

@Composable
fun GameTopBar(
  title: String,
  subtitle: String,
  accentColor: Color,
  onBack: () -> Unit,
  trailingContent: @Composable () -> Unit = {},
) {
  Surface(
    color = Color(0xCC121A2F),
    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        IconButton(
          onClick = onBack,
          modifier = Modifier.size(48.dp).testTag("game_back_button"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
            contentDescription = "بازگشت",
            tint = TextPrimary,
          )
        }
        Spacer(Modifier.width(6.dp))
        Column {
          Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = accentColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = subtitle,
            style = MaterialTheme.typography.labelMedium,
            color = TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
      trailingContent()
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameLobbyBottomSheet(
  gameType: GameType,
  isServerConnected: Boolean,
  statusMessage: String?,
  onDismiss: () -> Unit,
  onStartMode: (PlayMode, Int) -> Unit,
  onCreateOnlineRoom: () -> Unit,
  onJoinOnlineRoom: (String) -> Unit,
) {
  var selectedPlayers by remember(gameType) { mutableIntStateOf(if (gameType == GameType.LUDO || gameType == GameType.SNAKES_LADDERS) 4 else 2) }
  var roomCodeInput by remember { mutableStateOf("") }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    containerColor = Color(0xFF121A2E),
    contentColor = TextPrimary,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = "شروع بازی ${gameType.titleFa}",
            style = MaterialTheme.typography.headlineSmall,
            color = NeonCyan,
          )
          Text(
            text = gameType.subtitleFa,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
          )
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Rounded.Close, contentDescription = "بستن", tint = TextSecondary)
        }
      }

      if (gameType == GameType.LUDO || gameType == GameType.SNAKES_LADDERS) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("تعداد بازیکن:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
          listOf(2, 3, 4).forEach { count ->
            val selected = selectedPlayers == count
            Surface(
              onClick = { selectedPlayers = count },
              shape = RoundedCornerShape(12.dp),
              color = if (selected) NeonCyan.copy(alpha = 0.2f) else ElevatedCard,
              border = BorderStroke(1.dp, if (selected) NeonCyan else ElevatedCardStroke),
              modifier = Modifier.testTag("player_count_$count"),
            ) {
              Text(
                text = "$count نفره",
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) NeonCyan else TextPrimary,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
              )
            }
          }
        }
      }

      LobbyModeCard(
        title = "بازی با هوش مصنوعی",
        subtitle = "رقابت سریع و روان با ربات هوشمند",
        icon = BaziIcons.SportsEsports,
        accent = ElectricEmerald,
        testTag = "mode_vs_ai",
        onClick = { onStartMode(PlayMode.VS_AI, selectedPlayers) },
      )

      LobbyModeCard(
        title = "دو/چند نفره آفلاین (یک گوشی)",
        subtitle = "بازی نوبتی در کنار دوستان بدون نیاز به اینترنت",
        icon = BaziIcons.Groups,
        accent = CyberGold,
        testTag = "mode_pass_play",
        onClick = { onStartMode(PlayMode.LOCAL_PASS_AND_PLAY, selectedPlayers) },
      )

      GlassGradientCard(accentColor = VioletPulse, cornerRadius = 18.dp) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(BaziIcons.PublicGlobe, contentDescription = null, tint = VioletPulse)
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "بازی آنلاین با دوستان",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
              )
              Text(
                text =
                  if (isServerConnected) "اتصال زنده آنلاین آماده است"
                  else "پیش‌نمایش اتاق دوستان",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
              )
            }
          }

          Button(
            onClick = onCreateOnlineRoom,
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("create_online_room_button"),
            colors = ButtonDefaults.buttonColors(containerColor = VioletPulse),
            shape = RoundedCornerShape(12.dp),
          ) {
            Text("ساخت اتاق جدید و دریافت کد دعوت", fontWeight = FontWeight.Bold)
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            OutlinedTextField(
              value = roomCodeInput,
              onValueChange = { roomCodeInput = it.uppercase().take(10) },
              placeholder = { Text("کد اتاق (مثلاً BZ1A2B)") },
              singleLine = true,
              modifier = Modifier.weight(1f).testTag("join_room_code_input"),
              colors =
                OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = NeonCyan,
                  unfocusedBorderColor = ElevatedCardStroke,
                  focusedContainerColor = ObsidianBg,
                  unfocusedContainerColor = ObsidianBg,
                ),
              shape = RoundedCornerShape(12.dp),
            )
            OutlinedButton(
              onClick = { if (roomCodeInput.isNotBlank()) onJoinOnlineRoom(roomCodeInput) },
              modifier = Modifier.height(52.dp).testTag("join_online_room_button"),
              border = BorderStroke(1.dp, NeonCyan),
              shape = RoundedCornerShape(12.dp),
            ) {
              Text("ورود", color = NeonCyan, fontWeight = FontWeight.Bold)
            }
          }

          if (!statusMessage.isNullOrBlank()) {
            Text(
              text = statusMessage,
              style = MaterialTheme.typography.bodyMedium,
              color = CyberGold,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun LobbyModeCard(
  title: String,
  subtitle: String,
  icon: ImageVector,
  accent: Color,
  testTag: String,
  onClick: () -> Unit,
) {
  GlassGradientCard(
    accentColor = accent,
    cornerRadius = 16.dp,
    onClick = onClick,
    modifier = Modifier.fillMaxWidth().testTag(testTag),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Box(
        modifier =
          Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(accent.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(24.dp))
      }
      Column(modifier = Modifier.weight(1f)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
      }
    }
  }
}

@Composable
fun WinCelebrationBanner(
  winnerTitle: String,
  subtitle: String,
  accent: Color,
  onRematch: () -> Unit,
  onExit: () -> Unit,
) {
  GlassGradientCard(
    modifier = Modifier.fillMaxWidth(),
    accentColor = accent,
    cornerRadius = 22.dp,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(18.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
        imageVector = BaziIcons.Crown,
        contentDescription = null,
        tint = CyberGold,
        modifier = Modifier.size(42.dp),
      )
      Text(winnerTitle, style = MaterialTheme.typography.headlineSmall, color = accent)
      Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
      Row(
        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Button(
          onClick = onRematch,
          modifier = Modifier.weight(1f).height(48.dp).testTag("rematch_button"),
          colors = ButtonDefaults.buttonColors(containerColor = accent),
          shape = RoundedCornerShape(12.dp),
        ) {
          Text("بازی مجدد", color = ObsidianBg, fontWeight = FontWeight.Bold)
        }
        OutlinedButton(
          onClick = onExit,
          modifier = Modifier.weight(1f).height(48.dp).testTag("exit_after_win_button"),
          border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
          shape = RoundedCornerShape(12.dp),
        ) {
          Text("خروج", color = TextPrimary)
        }
      }
    }
  }
}

@Composable
fun SecurityShieldBadge(label: String, modifier: Modifier = Modifier) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(10.dp),
    color = ElectricEmerald.copy(alpha = 0.12f),
    border = BorderStroke(1.dp, ElectricEmerald.copy(alpha = 0.35f)),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Icon(Icons.Rounded.Lock, contentDescription = null, tint = ElectricEmerald, modifier = Modifier.size(14.dp))
      Text(label, style = MaterialTheme.typography.labelSmall, color = ElectricEmerald)
    }
  }
}
