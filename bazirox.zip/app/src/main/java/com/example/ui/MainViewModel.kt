package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CPanelConfig
import com.example.data.ChatGroup
import com.example.data.ChatImageUtils
import com.example.data.ChatMessage
import com.example.data.SendState
import com.example.data.GameInvite
import com.example.data.GameType
import com.example.data.LeaderboardEntry
import com.example.data.MainRepository
import com.example.data.MainTab
import com.example.data.OnlineRoom
import com.example.data.PingResult
import com.example.data.PlayMode
import com.example.data.SecureVault
import com.example.data.UserAccount
import com.example.security.CryptoManager
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class ActiveGameSession(
  val gameType: GameType,
  val playMode: PlayMode,
  val playerCount: Int = 2,
  val room: OnlineRoom? = null,
)

data class AppUiState(
  val activeTab: MainTab = MainTab.GAMES,
  val currentUser: UserAccount? = null,
  val authLoading: Boolean = false,
  val authError: String? = null,
  val cPanelConfig: CPanelConfig = CPanelConfig(),
  val pingLoading: Boolean = false,
  val pingResult: PingResult? = null,
  val showAdminPanel: Boolean = false,
  val lobbyGameType: GameType? = null,
  val activeGameSession: ActiveGameSession? = null,
  val leaderboard: List<LeaderboardEntry> = emptyList(),
  val leaderboardFilter: GameType? = null,
  val chatGroups: List<ChatGroup> = emptyList(),
  val selectedGroup: ChatGroup? = null,
  val chatMessages: List<ChatMessage> = emptyList(),
  val chatFeedback: String? = null,
  val chatReads: Map<String, Long> = emptyMap(),
  val chatDraftImage: String? = null,
  val chatReplyTo: ChatMessage? = null,
  val chatImageBusy: Boolean = false,
  val roomStatusMessage: String? = null,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

  private val appContext = application.applicationContext
  private val repository =
    MainRepository(
      SecureVault(appContext),
      imageDir = File(appContext.filesDir, "chat_images"),
    )

  private val _uiState = MutableStateFlow(AppUiState())
  val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()

  private var chatPollingJob: Job? = null
  private var roomPollingJob: Job? = null

  init {
    val session = repository.loadSession()
    val config = repository.loadConfig()
    _uiState.update { it.copy(currentUser = session, cPanelConfig = config) }
    refreshLeaderboard()
    refreshGroups()
  }

  fun selectTab(tab: MainTab) {
    _uiState.update { it.copy(activeTab = tab, authError = null, chatFeedback = null) }
    when (tab) {
      MainTab.LEADERBOARD -> refreshLeaderboard()
      MainTab.CHAT -> refreshGroups()
      else -> {}
    }
  }

  // --- Auth (Username + Password, or Admin shortcut leo + password) ---

  fun login(username: String, password: String) {
    if (CryptoManager.verifyAdminCredentials(username, password)) {
      _uiState.update {
        it.copy(
          showAdminPanel = true,
          authError = null,
        )
      }
      return
    }
    viewModelScope.launch {
      _uiState.update { it.copy(authLoading = true, authError = null) }
      val result = repository.login(username, password)
      result.fold(
        onSuccess = { acc ->
          _uiState.update { it.copy(currentUser = acc, authLoading = false, authError = null) }
          refreshGroups()
          refreshLeaderboard()
        },
        onFailure = { err ->
          _uiState.update {
            it.copy(authLoading = false, authError = err.message ?: "خطا در ورود")
          }
        },
      )
    }
  }

  fun register(username: String, password: String, displayName: String, avatarColorIndex: Int) {
    if (CryptoManager.verifyAdminCredentials(username, password)) {
      _uiState.update { it.copy(showAdminPanel = true, authError = null) }
      return
    }
    viewModelScope.launch {
      _uiState.update { it.copy(authLoading = true, authError = null) }
      val result = repository.register(username, password, displayName, avatarColorIndex)
      result.fold(
        onSuccess = { acc ->
          _uiState.update { it.copy(currentUser = acc, authLoading = false, authError = null) }
          refreshGroups()
          refreshLeaderboard()
        },
        onFailure = { err ->
          _uiState.update {
            it.copy(authLoading = false, authError = err.message ?: "خطا در ثبت‌نام")
          }
        },
      )
    }
  }

  fun logout() {
    repository.logout()
    _uiState.update { it.copy(currentUser = null, selectedGroup = null, activeGameSession = null) }
  }

  // --- Admin Panel & cPanel Config ---

  fun closeAdminPanel() {
    _uiState.update { it.copy(showAdminPanel = false) }
  }

  fun saveCPanelConfig(config: CPanelConfig) {
    repository.saveConfig(config)
    _uiState.update { it.copy(cPanelConfig = config) }
  }

  fun testCPanelConnection(config: CPanelConfig) {
    viewModelScope.launch {
      _uiState.update { it.copy(pingLoading = true, pingResult = null) }
      repository.saveConfig(config)
      val res = repository.testCPanelConnection(config)
      val reloaded = repository.loadConfig()
      _uiState.update {
        it.copy(pingLoading = false, pingResult = res, cPanelConfig = reloaded)
      }
    }
  }

  // --- Games & Online Rooms ---

  fun openGameLobby(gameType: GameType) {
    _uiState.update { it.copy(lobbyGameType = gameType, roomStatusMessage = null) }
  }

  fun dismissGameLobby() {
    _uiState.update { it.copy(lobbyGameType = null, roomStatusMessage = null) }
  }

  fun startGame(gameType: GameType, mode: PlayMode, playerCount: Int = 2) {
    _uiState.update {
      it.copy(
        lobbyGameType = null,
        activeGameSession = ActiveGameSession(gameType, mode, playerCount, null),
        roomStatusMessage = null,
      )
    }
  }

  fun createOnlineRoomAndPlay(gameType: GameType) {
    val username = _uiState.value.currentUser?.username ?: "بازیکن"
    viewModelScope.launch {
      _uiState.update { it.copy(roomStatusMessage = "در حال ساخت اتاق امن...") }
      val res = repository.createOnlineRoom(gameType, username)
      res.fold(
        onSuccess = { room ->
          _uiState.update {
            it.copy(
              lobbyGameType = null,
              activeGameSession = ActiveGameSession(gameType, PlayMode.ONLINE_ROOM, 2, room),
              roomStatusMessage = null,
            )
          }
          startRoomPolling(room.roomCode, gameType)
        },
        onFailure = { err ->
          _uiState.update { it.copy(roomStatusMessage = err.message ?: "خطا در ساخت اتاق") }
        },
      )
    }
  }

  fun joinOnlineRoomAndPlay(roomCode: String, gameType: GameType) {
    val username = _uiState.value.currentUser?.username ?: "مهمان"
    viewModelScope.launch {
      _uiState.update { it.copy(roomStatusMessage = "در حال اتصال به اتاق $roomCode...") }
      val res = repository.joinOnlineRoom(roomCode, gameType, username)
      res.fold(
        onSuccess = { room ->
          _uiState.update {
            it.copy(
              lobbyGameType = null,
              activeGameSession = ActiveGameSession(room.gameType, PlayMode.ONLINE_ROOM, 2, room),
              roomStatusMessage = null,
            )
          }
          startRoomPolling(room.roomCode, room.gameType)
        },
        onFailure = { err ->
          _uiState.update { it.copy(roomStatusMessage = err.message ?: "اتاق یافت نشد") }
        },
      )
    }
  }

  fun pushOnlineGameState(stateJson: String, status: String = "playing") {
    val session = _uiState.value.activeGameSession ?: return
    val room = session.room ?: return
    val username = _uiState.value.currentUser?.username ?: "بازیکن"
    viewModelScope.launch {
      val nextVersion = room.version + 1
      val res = repository.pushOnlineMove(room.roomCode, username, stateJson, status, nextVersion)
      res.onSuccess { updatedRoom ->
        _uiState.update { st ->
          if (st.activeGameSession?.room?.roomCode == updatedRoom.roomCode) {
            st.copy(activeGameSession = st.activeGameSession.copy(room = updatedRoom))
          } else st
        }
      }
    }
  }

  private fun startRoomPolling(roomCode: String, gameType: GameType) {
    roomPollingJob?.cancel()
    val config = _uiState.value.cPanelConfig
    if (!config.isConnected || config.apiBaseUrl.isBlank()) return
    val username = _uiState.value.currentUser?.username ?: "بازیکن"
    roomPollingJob =
      viewModelScope.launch {
        while (isActive) {
          delay(config.pollingIntervalMs.toLong())
          val res = repository.syncOnlineRoom(roomCode, gameType, username)
          res.onSuccess { synced ->
            _uiState.update { st ->
              val current = st.activeGameSession
              if (current != null && current.room?.roomCode == synced.roomCode) {
                if (synced.version > (current.room.version) || synced.players != current.room.players) {
                  st.copy(activeGameSession = current.copy(room = synced))
                } else st
              } else st
            }
          }
        }
      }
  }

  fun exitActiveGame() {
    roomPollingJob?.cancel()
    _uiState.update { it.copy(activeGameSession = null) }
    refreshLeaderboard()
  }

  fun recordGameFinish(gameType: GameType, didWin: Boolean, points: Int) {
    viewModelScope.launch {
      val updated = repository.recordMatchResult(gameType, points, didWin)
      if (updated != null) {
        _uiState.update { it.copy(currentUser = updated) }
      }
      refreshLeaderboard()
    }
  }

  // --- Leaderboard ---

  fun setLeaderboardFilter(filter: GameType?) {
    _uiState.update { it.copy(leaderboardFilter = filter) }
  }

  fun refreshLeaderboard() {
    viewModelScope.launch {
      val currentUser = _uiState.value.currentUser?.username
      val list = repository.getLeaderboard(currentUser)
      _uiState.update { it.copy(leaderboard = list) }
    }
  }

  // --- Chat & Group Invites ---

  fun refreshGroups() {
    viewModelScope.launch {
      val groups = repository.getChatGroups(_uiState.value.currentUser?.username)
      _uiState.update { st ->
        val updatedSelected =
          st.selectedGroup?.let { sel -> groups.firstOrNull { it.id == sel.id } ?: sel }
        st.copy(chatGroups = groups, selectedGroup = updatedSelected)
      }
    }
  }

  fun createGroup(name: String) {
    val username = _uiState.value.currentUser?.username
    if (username == null) {
      _uiState.update { it.copy(chatFeedback = "ابتدا از تب پروفایل وارد شوید") }
      return
    }
    viewModelScope.launch {
      val res = repository.createGroup(name, username)
      res.fold(
        onSuccess = { grp ->
          _uiState.update {
            it.copy(
              chatGroups = listOf(grp) + it.chatGroups.filterNot { g -> g.id == grp.id },
              selectedGroup = grp,
              chatFeedback = "گروه «${grp.name}» ساخته شد | کد دعوت: ${grp.inviteCode}",
            )
          }
          openGroupChat(grp)
        },
        onFailure = { err -> _uiState.update { it.copy(chatFeedback = err.message) } },
      )
    }
  }

  fun joinGroupByCode(code: String) {
    val username = _uiState.value.currentUser?.username
    if (username == null) {
      _uiState.update { it.copy(chatFeedback = "ابتدا از تب پروفایل وارد شوید") }
      return
    }
    viewModelScope.launch {
      val res = repository.joinGroupByCode(code, username)
      res.fold(
        onSuccess = { grp ->
          _uiState.update {
            it.copy(
              chatGroups = listOf(grp) + it.chatGroups.filterNot { g -> g.id == grp.id },
              selectedGroup = grp,
              chatFeedback = null,
            )
          }
          openGroupChat(grp)
        },
        onFailure = { err -> _uiState.update { it.copy(chatFeedback = err.message) } },
      )
    }
  }

  fun inviteMember(groupId: String, targetUsername: String) {
    viewModelScope.launch {
      val res = repository.inviteMemberToGroup(groupId, targetUsername)
      res.fold(
        onSuccess = { grp ->
          _uiState.update {
            it.copy(
              selectedGroup = grp,
              chatGroups = it.chatGroups.map { g -> if (g.id == grp.id) grp else g },
              chatFeedback = "کاربر «$targetUsername» به گروه دعوت شد",
            )
          }
        },
        onFailure = { err -> _uiState.update { it.copy(chatFeedback = err.message) } },
      )
    }
  }

  fun openGroupChat(group: ChatGroup) {
    _uiState.update {
      it.copy(selectedGroup = group, chatFeedback = null, chatReplyTo = null, chatDraftImage = null)
    }
    viewModelScope.launch {
      val msgs = repository.getMessages(group.id, _uiState.value.currentUser?.username)
      _uiState.update { it.copy(chatMessages = msgs, chatReads = repository.lastReads) }
    }
    startChatPolling(group.id)
  }

  fun closeGroupChat() {
    chatPollingJob?.cancel()
    _uiState.value.chatDraftImage?.let { File(it).delete() }
    _uiState.update {
      it.copy(selectedGroup = null, chatMessages = emptyList(), chatReplyTo = null, chatDraftImage = null)
    }
    refreshGroups()
  }

  fun sendGroupMessage(text: String) {
    val st = _uiState.value
    val group = st.selectedGroup ?: return
    val user = st.currentUser ?: return
    val draft = st.chatDraftImage?.let { File(it) }?.takeIf { it.exists() }
    if (text.isBlank() && draft == null) return
    val reply = st.chatReplyTo
    val (msg, local) =
      repository.queueMessage(
        groupId = group.id,
        senderUsername = user.username,
        senderColorIndex = user.avatarColorIndex,
        text = text,
        draftImage = draft,
        replyTo = reply,
      )
    _uiState.update {
      it.copy(chatMessages = local, chatReplyTo = null, chatDraftImage = null)
    }
    deliver(msg)
  }

  private fun deliver(msg: ChatMessage) {
    viewModelScope.launch {
      val updated = repository.deliverMessage(msg)
      _uiState.update { st ->
        if (st.selectedGroup?.id == msg.groupId) st.copy(chatMessages = updated) else st
      }
    }
  }

  fun retryMessage(msg: ChatMessage) {
    val updated = repository.setSendState(msg.groupId, msg.id, SendState.SENDING)
    _uiState.update { st ->
      if (st.selectedGroup?.id == msg.groupId) st.copy(chatMessages = updated) else st
    }
    deliver(msg.copy(sendState = SendState.SENDING))
  }

  fun setChatReply(msg: ChatMessage?) {
    _uiState.update { it.copy(chatReplyTo = msg) }
  }

  fun pickChatImage(uri: Uri) {
    viewModelScope.launch {
      _uiState.update { it.copy(chatImageBusy = true) }
      val out = repository.newDraftFile(appContext.cacheDir)
      val ok =
        withContext(Dispatchers.IO) { ChatImageUtils.compressToFile(appContext.contentResolver, uri, out) }
      _uiState.update { st ->
        st.chatDraftImage?.takeIf { ok }?.let { File(it).delete() }
        if (ok) st.copy(chatDraftImage = out.absolutePath, chatImageBusy = false)
        else st.copy(chatImageBusy = false, chatFeedback = "بارگذاری عکس ناموفق بود")
      }
    }
  }

  fun clearChatDraftImage() {
    _uiState.value.chatDraftImage?.let { File(it).delete() }
    _uiState.update { it.copy(chatDraftImage = null) }
  }

  suspend fun loadChatImage(msg: ChatMessage, maxDim: Int = 900): Bitmap? =
    repository.loadImage(msg, maxDim)

  fun sendGameInviteToGroup(gameType: GameType) {
    val group = _uiState.value.selectedGroup ?: return
    val user = _uiState.value.currentUser ?: return
    viewModelScope.launch {
      val roomRes = repository.createOnlineRoom(gameType, user.username)
      val roomCode = roomRes.getOrNull()?.roomCode ?: "BZ1024"
      val invite = GameInvite(gameType = gameType, roomCode = roomCode, hostUsername = user.username)
      val updated =
        repository.sendMessage(
          groupId = group.id,
          senderUsername = user.username,
          senderColorIndex = user.avatarColorIndex,
          text = "دعوت به بازی ${gameType.titleFa} (کد اتاق: $roomCode)",
          gameInvite = invite,
        )
      _uiState.update { it.copy(chatMessages = updated) }
    }
  }

  fun clearChatFeedback() {
    _uiState.update { it.copy(chatFeedback = null) }
  }

  private fun startChatPolling(groupId: String) {
    chatPollingJob?.cancel()
    val config = _uiState.value.cPanelConfig
    if (!config.isConnected || config.apiBaseUrl.isBlank()) return
    chatPollingJob =
      viewModelScope.launch {
        while (isActive) {
          delay(config.pollingIntervalMs.toLong())
          val msgs = repository.getMessages(groupId, _uiState.value.currentUser?.username)
          val reads = repository.lastReads
          _uiState.update { st ->
            if (st.selectedGroup?.id == groupId && (msgs != st.chatMessages || reads != st.chatReads)) {
              st.copy(chatMessages = msgs, chatReads = reads)
            } else st
          }
        }
      }
  }
}
