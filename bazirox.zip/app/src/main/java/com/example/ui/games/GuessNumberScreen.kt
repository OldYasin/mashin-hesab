package com.example.ui.games

import com.example.ui.theme.ElectricEmerald
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import com.example.ui.components.pressScale
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.data.GameType
import com.example.data.OnlineRoom
import com.example.data.PlayMode
import com.example.data.Sfx
import com.example.data.SoundManager
import com.example.ui.components.GameTopBar
import com.example.ui.components.LocalGameHud
import com.example.ui.components.PublishRoomHud
import com.example.ui.components.GameArea
import com.example.ui.components.GameTurnTimer
import com.example.ui.components.rememberTurnCountdown
import com.example.ui.components.fitBoard
import com.example.ui.components.boardWidth
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.WinCelebrationBanner
import com.example.ui.components.animatedOceanGameBackdrop
import com.example.ui.components.oceanGameBackdrop
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPulse
import kotlinx.coroutines.delay
import org.json.JSONObject
import kotlin.random.Random

private const val GN_MAX = 42
private const val GN_COLS = 7
private const val GN_TURN_SECONDS = 20

private fun faDigits(n: Int): String =
  n.toString().map { if (it in '0'..'9') ('۰' + (it - '0')) else it }.joinToString("")

/**
 * Number guessing: a secret number (1..42) is picked. Players take turns tapping a number. A wrong
 * guess shrinks the possible range (numbers outside it are greyed out) and passes the turn; the
 * player who hits the secret number wins. Each turn has a 20 second timer.
 */
@Composable
fun GuessNumberScreen(
  playMode: PlayMode,
  room: OnlineRoom?,
  currentUsername: String,
  onPushOnlineState: (String, String) -> Unit,
  onRecordResult: (Boolean, Int) -> Unit,
  onBack: () -> Unit,
) {
  BackHandler(onBack = onBack)

  val online = playMode == PlayMode.ONLINE_ROOM && room != null
  val mySide =
    remember(room, currentUsername) {
      if (!online) 0 else if (room!!.hostUsername.equals(currentUsername, ignoreCase = true)) 0 else 1
    }

  var target by remember { mutableIntStateOf(if (online) -1 else Random.nextInt(1, GN_MAX + 1)) }
  var lo by remember { mutableIntStateOf(1) }
  var hi by remember { mutableIntStateOf(GN_MAX) }
  var turn by remember { mutableIntStateOf(0) }
  var winner by remember { mutableIntStateOf(-1) }
  var hint by remember { mutableStateOf("عدد هدف را شکار کن!") }
  var lastGuess by remember { mutableIntStateOf(-1) }
  var guessCount by remember { mutableIntStateOf(0) }
  var secondsLeft by remember { mutableIntStateOf(GN_TURN_SECONDS) }
  var timerKey by remember { mutableIntStateOf(0) } // bump to restart the countdown
  var recorded by remember { mutableStateOf(false) }
  var roundId by remember { mutableIntStateOf(0) }

  val names =
    remember(room, playMode, currentUsername) {
      when (playMode) {
        PlayMode.VS_AI -> listOf("شما", "ربات")
        PlayMode.LOCAL_PASS_AND_PLAY -> listOf("بازیکن ۱", "بازیکن ۲")
        PlayMode.ONLINE_ROOM ->
          listOf(
            room?.players?.getOrNull(0) ?: "میزبان",
            room?.players?.getOrNull(1) ?: "در انتظار...",
          )
      }
    }

  fun pushState(status: String) {
    if (!online) return
    val j =
      JSONObject().apply {
        put("target", target)
        put("lo", lo)
        put("hi", hi)
        put("turn", turn)
        put("winner", winner)
        put("hint", hint)
        put("last", lastGuess)
        put("count", guessCount)
        put("round", roundId)
      }
    onPushOnlineState(j.toString(), status)
  }

  fun newRound() {
    target = Random.nextInt(1, GN_MAX + 1)
    lo = 1
    hi = GN_MAX
    turn = 0
    winner = -1
    hint = "عدد هدف را شکار کن!"
    lastGuess = -1
    guessCount = 0
    recorded = false
    roundId++
    timerKey++
    pushState("playing")
  }

  // Online: the host creates the secret number once, everybody else just reads the room state.
  LaunchedEffect(Unit) {
    if (online && mySide == 0 && (room?.stateJson?.length ?: 0) <= 4) newRound()
  }

  LaunchedEffect(room?.version, room?.stateJson) {
    if (online && room != null && room.stateJson.length > 4) {
      try {
        val j = JSONObject(room.stateJson)
        if (j.has("target")) {
          target = j.optInt("target", -1)
          lo = j.optInt("lo", 1)
          hi = j.optInt("hi", GN_MAX)
          val newTurn = j.optInt("turn", 0)
          if (newTurn != turn || j.optInt("round", 0) != roundId) timerKey++
          turn = newTurn
          winner = j.optInt("winner", -1)
          hint = j.optString("hint", hint)
          lastGuess = j.optInt("last", -1)
          guessCount = j.optInt("count", 0)
          roundId = j.optInt("round", roundId)
          if (winner == -1) recorded = false
        }
      } catch (_: Throwable) {}
    }
  }

  fun applyGuess(n: Int, by: Int) {
    if (winner != -1 || target < 1 || n !in lo..hi) return
    lastGuess = n
    guessCount++
    if (n == target) {
      winner = by
      hint = "${names[by]} عدد ${faDigits(n)} را درست حدس زد!"
    } else {
      if (n < target) {
        lo = n + 1
        hint = "عدد هدف بزرگ‌تر از ${faDigits(n)} است"
      } else {
        hi = n - 1
        hint = "عدد هدف کوچک‌تر از ${faDigits(n)} است"
      }
      turn = 1 - by
      timerKey++
    }
    pushState(if (winner == -1) "playing" else "finished")
  }

  fun isMyTurn(): Boolean =
    winner == -1 &&
      target > 0 &&
      when (playMode) {
        PlayMode.VS_AI -> turn == 0
        PlayMode.LOCAL_PASS_AND_PLAY -> true
        PlayMode.ONLINE_ROOM -> turn == mySide && (room?.players?.size ?: 0) >= 2
      }

  // Turn countdown. Only the player whose turn it is acts on a timeout (so online it fires once).
  LaunchedEffect(timerKey, winner, target) {
    if (winner != -1 || target < 1) return@LaunchedEffect
    secondsLeft = GN_TURN_SECONDS
    while (secondsLeft > 0) {
      delay(1000)
      secondsLeft--
    }
    val iOwnTurn =
      when (playMode) {
        PlayMode.VS_AI -> turn == 0
        PlayMode.LOCAL_PASS_AND_PLAY -> true
        PlayMode.ONLINE_ROOM -> turn == mySide
      }
    if (iOwnTurn && winner == -1) {
      hint = "زمان ${names[turn]} تمام شد"
      turn = 1 - turn
      timerKey++
      pushState("playing")
    }
  }

  // AI opponent: mostly bisects the remaining range, with a little randomness.
  LaunchedEffect(turn, winner, roundId, lastGuess) {
    if (playMode == PlayMode.VS_AI && turn == 1 && winner == -1) {
      delay(1100 + Random.nextLong(0, 900))
      if (turn == 1 && winner == -1) {
        val mid = (lo + hi) / 2
        val spread = ((hi - lo) / 4).coerceAtLeast(0)
        val pick = (mid + if (spread > 0) Random.nextInt(-spread, spread + 1) else 0).coerceIn(lo, hi)
        applyGuess(pick, 1)
      }
    }
  }

  // ---- Sound ----
  var lastSoundCount by remember { mutableIntStateOf(0) }
  LaunchedEffect(guessCount) {
    if (guessCount > lastSoundCount) SoundManager.play(Sfx.TAP)
    lastSoundCount = guessCount
  }
  var resultSoundPlayed by remember { mutableStateOf(false) }
  LaunchedEffect(winner) {
    if (winner == -1) {
      resultSoundPlayed = false
    } else if (!resultSoundPlayed) {
      resultSoundPlayed = true
      delay(200)
      val mine = if (playMode == PlayMode.ONLINE_ROOM) mySide else 0
      SoundManager.play(if (winner == mine) Sfx.WIN else Sfx.LOSE)
    }
  }

  LaunchedEffect(winner) {
    if (winner != -1 && !recorded) {
      recorded = true
      val mine = if (playMode == PlayMode.ONLINE_ROOM) mySide else 0
      onRecordResult(winner == mine, if (winner == mine) 30 else 8)
    }
  }

  val accent = if (turn == 0) NeonCyan else CrimsonMagenta
  val canTap = isMyTurn()

  Column(
    modifier = Modifier.fillMaxSize().animatedOceanGameBackdrop(accent).systemBarsPadding(),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {

    GameTopBar(
      title = GameType.GUESS_NUMBER.titleFa,
      subtitle =
        when (playMode) {
          PlayMode.VS_AI -> "در برابر هوش مصنوعی"
          PlayMode.LOCAL_PASS_AND_PLAY -> "دو نفره آفلاین"
          PlayMode.ONLINE_ROOM -> "اتاق آنلاین: ${room?.roomCode ?: "-"}"
        },
      accentColor = VioletPulse,
      onBack = onBack,
      copyText = if (playMode == PlayMode.ONLINE_ROOM) room?.roomCode else null,
      trailingContent = {
        IconButton(onClick = { newRound() }, modifier = Modifier.testTag("guess_reset_button")) {
          Icon(Icons.Rounded.Refresh, contentDescription = "شروع مجدد", tint = VioletPulse)
        }
      },
    )

    val hudOn = LocalGameHud.current != null
    PublishRoomHud(room = room, activeSeat = if (winner == -1) turn else -1)
    GameArea(maxWidth = 600.dp) {
      GameTurnTimer(secondsLeft, VioletPulse, total = GN_TURN_SECONDS, active = winner == -1)
      // Players + timer (online rooms show the turn on the avatar cards instead)
      if (!hudOn) Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (i in 0..1) {
          val active = winner == -1 && turn == i
          val c = if (i == 0) NeonCyan else CrimsonMagenta
          GlassGradientCard(
            accentColor = if (active) c else c.copy(alpha = 0.35f),
            cornerRadius = 14.dp,
            modifier = Modifier.weight(1f),
          ) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp, horizontal = 8.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              Text(
                if (online) (if (i == mySide) "شما" else "حریف") else names[i],
                style = MaterialTheme.typography.labelLarge,
                color = if (active) c else TextSecondary,
                maxLines = 1,
                fontWeight = FontWeight.Bold,
              )
              Text(
                if (active) "نوبت ${if (playMode != PlayMode.LOCAL_PASS_AND_PLAY && i == (if (playMode == PlayMode.ONLINE_ROOM) mySide else 0)) "شما" else "این بازیکن"}"
                else "منتظر",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
              )
            }
          }
        }
      }

      // Hint
      GlassGradientCard(accentColor = VioletPulse, cornerRadius = 16.dp, modifier = Modifier.fillMaxWidth()) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(10.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
          Text(
            text = hint,
            style = MaterialTheme.typography.titleSmall,
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
          )
          // Live range bar: shrinks smoothly after every wrong guess.
          val startF by animateFloatAsState((lo - 1) / GN_MAX.toFloat(), tween(350), label = "rangeStart")
          val endF by animateFloatAsState(hi / GN_MAX.toFloat(), tween(350), label = "rangeEnd")
          CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(faDigits(lo), style = MaterialTheme.typography.titleMedium, color = ElectricEmerald, fontWeight = FontWeight.ExtraBold)
                Text("بازه ممکن", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                Text(faDigits(hi), style = MaterialTheme.typography.titleMedium, color = ElectricEmerald, fontWeight = FontWeight.ExtraBold)
              }
              Box(
                modifier =
                  Modifier.fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color.White.copy(alpha = 0.08f))
                    .drawBehind {
                      drawRoundRect(
                        brush = Brush.horizontalGradient(listOf(NeonCyan, VioletPulse)),
                        topLeft = Offset(size.width * startF, 0f),
                        size = Size(size.width * (endF - startF).coerceAtLeast(0f), size.height),
                        cornerRadius = CornerRadius(size.height / 2f),
                      )
                    }
              )
            }
          }
          Text(
            text = "تعداد حدس‌ها: ${faDigits(guessCount)}",
            style = MaterialTheme.typography.labelMedium,
            color = TextSecondary,
          )
        }
      }

      if (winner == -1) {
        Text(
          text = if (canTap) "یکی از عددهای روشن را انتخاب کن" else "منتظر حدس حریف...",
          style = MaterialTheme.typography.labelLarge,
          color = if (canTap) accent else TextSecondary,
          fontWeight = FontWeight.Bold,
        )
      }

      // Number grid (always left-to-right, 1 at the bottom-left like a number pad)
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.width(boardWidth(262.dp, GN_COLS.toFloat() / (GN_MAX / GN_COLS)))) {
          val rows = GN_MAX / GN_COLS
          for (r in rows - 1 downTo 0) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
              for (c in 0 until GN_COLS) {
                val n = r * GN_COLS + c + 1
                val inRange = n in lo..hi
                val isLast = n == lastGuess
                val revealed = winner != -1 && n == target
                val enabled = canTap && inRange
                val src = remember { MutableInteractionSource() }
                Surface(
                  onClick = { applyGuess(n, if (playMode == PlayMode.LOCAL_PASS_AND_PLAY) turn else if (online) mySide else 0) },
                  enabled = enabled,
                  interactionSource = src,
                  shape = RoundedCornerShape(12.dp),
                  color =
                    when {
                      revealed -> CyberGold.copy(alpha = 0.9f)
                      isLast -> CrimsonMagenta.copy(alpha = 0.30f)
                      inRange -> VioletPulse.copy(alpha = 0.32f)
                      else -> Color.White.copy(alpha = 0.03f)
                    },
                  border =
                    BorderStroke(
                      if (isLast) 1.6.dp else 1.dp,
                      when {
                        isLast -> CrimsonMagenta
                        inRange -> VioletPulse.copy(alpha = 0.85f)
                        else -> Color.White.copy(alpha = 0.06f)
                      },
                    ),
                  modifier = Modifier.weight(1f).aspectRatio(1f).pressScale(src, 0.88f).testTag("guess_cell_$n"),
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Text(
                      text = faDigits(n),
                      style = MaterialTheme.typography.titleMedium,
                      fontWeight = FontWeight.ExtraBold,
                      color =
                        when {
                          revealed -> Color.Black
                          inRange -> Color.White
                          else -> TextSecondary.copy(alpha = 0.38f)
                        },
                    )
                  }
                }
              }
            }
          }
        }
      }

      if (winner != -1) {
        val mine = if (playMode == PlayMode.ONLINE_ROOM) mySide else 0
        WinCelebrationBanner(
          winnerTitle =
            if (playMode == PlayMode.LOCAL_PASS_AND_PLAY) "${names[winner]} برنده شد!"
            else if (winner == mine) "شما برنده شدید!" else "${names[winner]} برنده شد!",
          subtitle = "عدد هدف ${faDigits(target)} بود",
          accent = if (winner == mine) VioletPulse else CyberGold,
          onRematch = { newRound() },
          onExit = onBack,
        )
      }
    }
  }
}
