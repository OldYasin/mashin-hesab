package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.CPanelConfig
import com.example.data.GameType
import com.example.data.UserAccount
import com.example.ui.components.AvatarBadge
import com.example.ui.components.BaziIcons
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.ServerStatusPill
import com.example.ui.components.auroraGamingBackdrop
import com.example.ui.components.drawGlossyToken
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlayerBlue
import com.example.ui.theme.PlayerGreen
import com.example.ui.theme.PlayerRed
import com.example.ui.theme.PlayerYellow
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPulse

@Composable
fun HomeScreen(
  currentUser: UserAccount?,
  cPanelConfig: CPanelConfig,
  onSelectGame: (GameType) -> Unit,
  onQuickJoinRoom: (String, GameType) -> Unit,
  onOpenProfile: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var quickCode by remember { mutableStateOf("") }

  LazyColumn(
    modifier = modifier.fillMaxSize().auroraGamingBackdrop(NeonCyan, VioletPulse),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    // 1. Frosted Glass Player HUD Header
    item {
      GlassGradientCard(
        modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp),
        accentColor = NeonCyan,
        cornerRadius = 22.dp,
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Surface(
            onClick = onOpenProfile,
            color = Color.Transparent,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f).testTag("home_profile_chip"),
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              AvatarBadge(
                name = currentUser?.displayName ?: "مهمان",
                colorIndex = currentUser?.avatarColorIndex ?: 0,
                size = 48.dp,
              )
              Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                  text = currentUser?.displayName ?: "بازیکن مهمان • ورود",
                  style = MaterialTheme.typography.titleMedium,
                  color = TextPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = NeonCyan.copy(alpha = 0.16f),
                  ) {
                    Text(
                      text = "LVL ${currentUser?.level ?: 1}",
                      style = MaterialTheme.typography.labelSmall,
                      color = NeonCyan,
                      fontWeight = FontWeight.ExtraBold,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    )
                  }
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                  ) {
                    Icon(
                      BaziIcons.Trophy,
                      contentDescription = null,
                      tint = CyberGold,
                      modifier = Modifier.size(14.dp),
                    )
                    Text(
                      text = "${currentUser?.totalScore ?: 0}",
                      style = MaterialTheme.typography.labelMedium,
                      color = CyberGold,
                      fontWeight = FontWeight.Bold,
                    )
                  }
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                  ) {
                    Icon(
                      BaziIcons.Flame,
                      contentDescription = null,
                      tint = CrimsonMagenta,
                      modifier = Modifier.size(14.dp),
                    )
                    Text(
                      text = "${currentUser?.wins ?: 0} برد",
                      style = MaterialTheme.typography.labelSmall,
                      color = TextSecondary,
                    )
                  }
                }
                val xpProgress = ((currentUser?.totalScore ?: 0) % 150) / 150f
                LinearProgressIndicator(
                  progress = { xpProgress.coerceIn(0.08f, 1f) },
                  modifier = Modifier.fillMaxWidth(0.85f).height(4.dp).clip(CircleShape),
                  color = NeonCyan,
                  trackColor = ElevatedCardStroke,
                )
              }
            }
          }
          Spacer(Modifier.width(8.dp))
          ServerStatusPill(isConnected = cPanelConfig.isConnected)
        }
      }
    }

    // 2. Frosted Glass Gaming Hero Banner
    item {
      GlassGradientCard(
        modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp).height(202.dp),
        accentColor = NeonCyan,
        cornerRadius = 24.dp,
      ) {
        Box(modifier = Modifier.fillMaxSize()) {
          Image(
            painter = painterResource(id = R.drawable.img_gaming_hero),
            contentDescription = "آرنا بازی‌های Bazirox",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
          )
          Box(
            modifier =
              Modifier.fillMaxSize()
                .background(
                  Brush.horizontalGradient(
                    listOf(Color(0xEB080E1E), Color(0x66121C38))
                  )
                )
          )
          Column(
            modifier = Modifier.fillMaxSize().padding(18.dp),
            verticalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Surface(
                shape = RoundedCornerShape(50),
                color = CyberGold.copy(alpha = 0.22f),
                border = BorderStroke(1.dp, CyberGold.copy(alpha = 0.65f)),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                  Icon(
                    BaziIcons.Crown,
                    contentDescription = null,
                    tint = CyberGold,
                    modifier = Modifier.size(14.dp),
                  )
                  Text(
                    "آرنا رقابت و سرگرمی",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberGold,
                    fontWeight = FontWeight.Bold,
                  )
                }
              }

              Surface(
                shape = RoundedCornerShape(50),
                color = ElectricEmerald.copy(alpha = 0.18f),
                border = BorderStroke(1.dp, ElectricEmerald.copy(alpha = 0.4f)),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                  Icon(BaziIcons.Bolt, contentDescription = null, tint = ElectricEmerald, modifier = Modifier.size(13.dp))
                  Text("۶۰ فریم روان", style = MaterialTheme.typography.labelSmall, color = ElectricEmerald)
                }
              }
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text(
                text = "کلاب بازی‌های آنلاین Bazirox",
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary,
                fontWeight = FontWeight.ExtraBold,
              )
              Text(
                text = "با دوستانت اتاق بساز، گروه چت بزن و قهرمان جدول شو!",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              Button(
                onClick = { onSelectGame(GameType.LUDO) },
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                modifier = Modifier.height(42.dp).testTag("hero_play_ludo_button"),
              ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = ObsidianBg)
                Spacer(Modifier.width(4.dp))
                Text("شروع منچ", color = ObsidianBg, fontWeight = FontWeight.ExtraBold)
              }
              OutlinedButton(
                onClick = { onSelectGame(GameType.TIC_TAC_TOE) },
                border = BorderStroke(1.dp, TextPrimary.copy(alpha = 0.45f)),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                modifier = Modifier.height(42.dp),
              ) {
                Text("دوز سریع", color = TextPrimary, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }

    // 3. Glass Quick Join Friend Room Bar
    item {
      GlassGradientCard(
        modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp),
        accentColor = VioletPulse,
        cornerRadius = 20.dp,
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Box(
            modifier =
              Modifier.size(42.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                  Brush.linearGradient(listOf(VioletPulse.copy(alpha = 0.4f), NeonCyan.copy(alpha = 0.25f)))
                ),
            contentAlignment = Alignment.Center,
          ) {
            Icon(BaziIcons.Groups, contentDescription = null, tint = NeonCyan)
          }
          OutlinedTextField(
            value = quickCode,
            onValueChange = { quickCode = it.uppercase().take(10) },
            placeholder = { Text("کد اتاق دوستت (مثلاً BZ1A2B)") },
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("home_quick_room_input"),
            colors =
              OutlinedTextFieldDefaults.colors(
                focusedBorderColor = VioletPulse,
                unfocusedBorderColor = Color.White.copy(alpha = 0.14f),
                focusedContainerColor = Color(0x990A0F1D),
                unfocusedContainerColor = Color(0x880A0F1D),
              ),
            shape = RoundedCornerShape(14.dp),
          )
          Button(
            onClick = { if (quickCode.isNotBlank()) onQuickJoinRoom(quickCode, GameType.LUDO) },
            enabled = quickCode.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = VioletPulse),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.height(50.dp).testTag("home_quick_join_button"),
          ) {
            Text("ورود", fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // 4. Section Title
    item {
      Row(
        modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Icon(BaziIcons.SportsEsports, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(22.dp))
          Text(
            text = "انتخاب بازی",
            style = MaterialTheme.typography.headlineSmall,
            color = TextPrimary,
          )
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          Icon(BaziIcons.PublicGlobe, contentDescription = null, tint = ElectricEmerald, modifier = Modifier.size(16.dp))
          Text("آنلاین و آفلاین", style = MaterialTheme.typography.labelMedium, color = ElectricEmerald)
        }
      }
    }

    // 5. Frosted Glass 2x2 Gaming Cards Grid
    item {
      BoxWithConstraints(modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp)) {
        val isWide = maxWidth >= 520.dp
        val games = GameType.entries
        if (isWide) {
          Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            games.forEach { g ->
              GameArcadeCard(
                gameType = g,
                modifier = Modifier.weight(1f),
                onClick = { onSelectGame(g) },
              )
            }
          }
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
              GameArcadeCard(
                gameType = GameType.LUDO,
                modifier = Modifier.weight(1f),
                onClick = { onSelectGame(GameType.LUDO) },
              )
              GameArcadeCard(
                gameType = GameType.TIC_TAC_TOE,
                modifier = Modifier.weight(1f),
                onClick = { onSelectGame(GameType.TIC_TAC_TOE) },
              )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
              GameArcadeCard(
                gameType = GameType.CONNECT_FOUR,
                modifier = Modifier.weight(1f),
                onClick = { onSelectGame(GameType.CONNECT_FOUR) },
              )
              GameArcadeCard(
                gameType = GameType.SNAKES_LADDERS,
                modifier = Modifier.weight(1f),
                onClick = { onSelectGame(GameType.SNAKES_LADDERS) },
              )
            }
          }
        }
      }
    }

    item { Spacer(Modifier.height(8.dp)) }
  }
}

@Composable
private fun GameArcadeCard(
  gameType: GameType,
  modifier: Modifier = Modifier,
  onClick: () -> Unit,
) {
  val accent =
    when (gameType) {
      GameType.LUDO -> PlayerRed
      GameType.TIC_TAC_TOE -> NeonCyan
      GameType.CONNECT_FOUR -> CyberGold
      GameType.SNAKES_LADDERS -> ElectricEmerald
    }

  GlassGradientCard(
    accentColor = accent,
    cornerRadius = 24.dp,
    onClick = onClick,
    modifier = modifier.height(216.dp).testTag("game_card_${gameType.id}"),
  ) {
    Column(
      modifier = Modifier.fillMaxSize().padding(14.dp),
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top,
      ) {
        GameMiniBoardArtwork(gameType = gameType, accent = accent, modifier = Modifier.size(68.dp))
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = accent.copy(alpha = 0.2f),
          border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
        ) {
          Text(
            text = gameType.playersRangeFa,
            style = MaterialTheme.typography.labelSmall,
            color = accent,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }
      }

      Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(
          text = gameType.titleFa,
          style = MaterialTheme.typography.titleLarge,
          color = TextPrimary,
          fontWeight = FontWeight.ExtraBold,
        )
        Text(
          text = gameType.subtitleFa,
          style = MaterialTheme.typography.labelMedium,
          color = TextSecondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "بازی کن",
          style = MaterialTheme.typography.labelLarge,
          color = accent,
          fontWeight = FontWeight.ExtraBold,
        )
        Box(
          modifier = Modifier.size(32.dp).clip(CircleShape).background(accent),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            Icons.Rounded.PlayArrow,
            contentDescription = gameType.titleFa,
            tint = ObsidianBg,
            modifier = Modifier.size(20.dp),
          )
        }
      }
    }
  }
}

@Composable
private fun GameMiniBoardArtwork(
  gameType: GameType,
  accent: Color,
  modifier: Modifier = Modifier,
) {
  Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height
    drawRoundRect(
      brush = Brush.linearGradient(listOf(Color(0xFF1B2644), Color(0xFF0C1222))),
      cornerRadius = CornerRadius(18f, 18f),
    )
    drawRoundRect(
      color = accent.copy(alpha = 0.45f),
      cornerRadius = CornerRadius(18f, 18f),
      style = Stroke(width = 2.5f),
    )
    when (gameType) {
      GameType.LUDO -> {
        val pad = w * 0.14f
        val box = w * 0.30f
        drawRoundRect(PlayerRed.copy(alpha = 0.28f), Offset(pad, pad), Size(box, box), CornerRadius(7f, 7f))
        drawRoundRect(PlayerGreen.copy(alpha = 0.28f), Offset(w - pad - box, pad), Size(box, box), CornerRadius(7f, 7f))
        drawRoundRect(PlayerBlue.copy(alpha = 0.28f), Offset(pad, h - pad - box), Size(box, box), CornerRadius(7f, 7f))
        drawRoundRect(PlayerYellow.copy(alpha = 0.28f), Offset(w - pad - box, h - pad - box), Size(box, box), CornerRadius(7f, 7f))
        val r = w * 0.095f
        drawGlossyToken(Offset(pad + box * 0.5f, pad + box * 0.5f), r, PlayerRed)
        drawGlossyToken(Offset(w - pad - box * 0.5f, pad + box * 0.5f), r, PlayerGreen)
        drawGlossyToken(Offset(pad + box * 0.5f, h - pad - box * 0.5f), r, PlayerBlue)
        drawGlossyToken(Offset(w - pad - box * 0.5f, h - pad - box * 0.5f), r, PlayerYellow)
        drawCircle(CyberGold.copy(alpha = 0.85f), radius = w * 0.08f, center = Offset(w * 0.5f, h * 0.5f))
      }
      GameType.TIC_TAC_TOE -> {
        val step = w / 3f
        drawLine(NeonCyan.copy(alpha = 0.35f), Offset(step, 10f), Offset(step, h - 10f), 3f)
        drawLine(NeonCyan.copy(alpha = 0.35f), Offset(step * 2, 10f), Offset(step * 2, h - 10f), 3f)
        drawLine(NeonCyan.copy(alpha = 0.35f), Offset(10f, step), Offset(w - 10f, step), 3f)
        drawLine(NeonCyan.copy(alpha = 0.35f), Offset(10f, step * 2), Offset(w - 10f, step * 2), 3f)
        drawLine(NeonCyan.copy(alpha = 0.35f), Offset(13f, 13f), Offset(step - 6f, step - 6f), 10f, StrokeCap.Round)
        drawLine(NeonCyan, Offset(13f, 13f), Offset(step - 6f, step - 6f), 4.5f, StrokeCap.Round)
        drawLine(NeonCyan.copy(alpha = 0.35f), Offset(step - 6f, 13f), Offset(13f, step - 6f), 10f, StrokeCap.Round)
        drawLine(NeonCyan, Offset(step - 6f, 13f), Offset(13f, step - 6f), 4.5f, StrokeCap.Round)
        drawCircle(CrimsonMagenta.copy(alpha = 0.35f), radius = step * 0.31f, center = Offset(w * 0.5f, h * 0.5f), style = Stroke(9f))
        drawCircle(CrimsonMagenta, radius = step * 0.31f, center = Offset(w * 0.5f, h * 0.5f), style = Stroke(4.5f))
      }
      GameType.CONNECT_FOUR -> {
        val cols = 4
        val rows = 3
        val cw = (w - 14f) / cols
        val ch = (h - 14f) / rows
        for (r in 0 until rows) {
          for (c in 0 until cols) {
            val center = Offset(7f + (c + 0.5f) * cw, 7f + (r + 0.5f) * ch)
            drawCircle(ObsidianBg, radius = cw * 0.34f, center = center)
            when {
              (r == 2 && c in 0..1) || (r == 1 && c == 1) ->
                drawGlossyToken(center, cw * 0.32f, PlayerRed)
              (r == 2 && c in 2..3) || (r == 1 && c == 2) ->
                drawGlossyToken(center, cw * 0.32f, PlayerYellow)
            }
          }
        }
      }
      GameType.SNAKES_LADDERS -> {
        drawLine(ElectricEmerald, Offset(w * 0.24f, h * 0.82f), Offset(w * 0.44f, h * 0.18f), 5f, StrokeCap.Round)
        drawLine(ElectricEmerald, Offset(w * 0.40f, h * 0.82f), Offset(w * 0.60f, h * 0.18f), 5f, StrokeCap.Round)
        for (t in listOf(0.28f, 0.48f, 0.68f)) {
          val lx = w * (0.24f + 0.20f * t)
          val ly = h * (0.82f - 0.64f * t)
          drawLine(CyberGold, Offset(lx, ly), Offset(lx + w * 0.16f, ly), 3.5f, StrokeCap.Round)
        }
        val snakePath =
          Path().apply {
            moveTo(w * 0.72f, h * 0.24f)
            quadraticTo(w * 0.92f, h * 0.42f, w * 0.68f, h * 0.58f)
            quadraticTo(w * 0.54f, h * 0.70f, w * 0.78f, h * 0.82f)
          }
        drawPath(snakePath, CrimsonMagenta, style = Stroke(7f, cap = StrokeCap.Round))
        drawCircle(CrimsonMagenta, radius = w * 0.10f, center = Offset(w * 0.72f, h * 0.24f))
        drawCircle(Color.White, radius = w * 0.028f, center = Offset(w * 0.69f, h * 0.22f))
        drawCircle(Color.White, radius = w * 0.028f, center = Offset(w * 0.75f, h * 0.22f))
      }
    }
  }
}
