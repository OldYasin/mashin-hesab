package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

// Offline Persian fonts bundled in res/font (no network needed).
val BaziroxSansFamily =
  FontFamily(
    Font(R.font.bazirox_sans_regular, FontWeight.Normal),
    Font(R.font.bazirox_sans_regular, FontWeight.Medium),
    Font(R.font.bazirox_sans_bold, FontWeight.SemiBold),
    Font(R.font.bazirox_sans_bold, FontWeight.Bold),
    Font(R.font.bazirox_sans_bold, FontWeight.ExtraBold),
  )

val BaziroxNaskhFamily =
  FontFamily(
    Font(R.font.bazirox_naskh_regular, FontWeight.Normal),
    Font(R.font.bazirox_naskh_regular, FontWeight.Medium),
    Font(R.font.bazirox_naskh_bold, FontWeight.SemiBold),
    Font(R.font.bazirox_naskh_bold, FontWeight.Bold),
    Font(R.font.bazirox_naskh_bold, FontWeight.ExtraBold),
  )

// Active app font: switch to BaziroxNaskhFamily for a Naskh look.
val AppFontFamily = BaziroxSansFamily

val Typography =
  Typography(
    displaySmall =
      TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 28.sp,
        lineHeight = 36.sp,
      ),
    headlineMedium =
      TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 30.sp,
      ),
    headlineSmall =
      TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        lineHeight = 26.sp,
      ),
    titleLarge =
      TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 17.sp,
        lineHeight = 24.sp,
      ),
    titleMedium =
      TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        lineHeight = 22.sp,
      ),
    bodyLarge =
      TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 23.sp,
      ),
    bodyMedium =
      TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 20.sp,
      ),
    labelLarge =
      TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        lineHeight = 18.sp,
      ),
    labelMedium =
      TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.sp,
        lineHeight = 16.sp,
      ),
    labelSmall =
      TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp,
        lineHeight = 14.sp,
      ),
  )
