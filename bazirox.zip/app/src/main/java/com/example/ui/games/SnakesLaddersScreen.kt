package com.example.ui.games

import android.graphics.Paint
import android.graphics.Typeface
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.GameType
import com.example.data.OnlineRoom
import com.example.data.PlayMode
import com.example.ui.components.AnimatedGameDice
import com.example.ui.components.BaziIcons
import com.example.ui.components.GameTopBar
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.WinCelebrationBanner
import com.example.ui.components.auroraGamingBackdrop
import com.example.ui.components.drawGlossyToken
import com.example.ui.components.playerColorFor
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val Ladders =
  mapOf(
    4 to 25,
    13 to 46,
    33 to 49,
    42 to 63,
    50 to 69,
    62 to 81,
    74 to 92,
  )

private val Snakes =
  mapOf(
    27 to 5,
    40 to 3,
    43 to 18,
    54 to 31,
    66 to 45,
    76 to 58,
    89 to 53,
    99 to 41,
  )

@Composable
fun SnakesLaddersScreen(
  playMode: PlayMode,
  playerCount: Int,
  room: OnlineRoom?,
  currentUsername: String,
  onPushOnlineState: (String, String) -> Unit,
  onRecordResult: (Boolean, Int) -> Unit,
  onBack: () -> Unit,
) {
  BackHandler(onBack = onBack)

  val count = if (playMode == PlayMode.ONLINE_ROOM) 2 else playerCount.coerceIn(2, 4)
  var positions by remember(count) { mutableStateOf(List(count) { 1 }) }
  var currentTurn by remember { mutableIntStateOf(0) }
  var diceValue by remember { mutableIntStateOf(6) }
  var isRolling by remember { mutableStateOf(false) }
  var winnerIndex by remember { mutableIntStateOf(-1) }
  var eventBanner by remember { mutableStateOf("تاس بیندازید تا حرکت شروع شود!") }
  var recorded by remember { mutableStateOf(false) }
  var roundId by remember { mutableIntStateOf(0) }
  val scope = rememberCoroutineScope()

  val myOnlineSide =
    remember(room, currentUsername) {
      if (room == null) 0
      else if (room.hostUsername.equals(currentUsername, ignoreCase = true)) 0 else 1
    }

  LaunchedEffect(room?.version, room?.stateJson) {
    if (playMode == PlayMode.ONLINE_ROOM && room != null && room.stateJson.length > 4) {
      try {
        val j = JSONObject(room.stateJson)
        val arr = j.optJSONArray("positions")
        if (arr != null && arr.length() == count) {
          positions = List(count) { i -> arr.getInt(i) }
          currentTurn = j.optInt("turn", 0)
          diceValue = j.optInt("dice", 6)
          winnerIndex = j.optInt("winner", -1)
          eventBanner = j.optString("banner", eventBanner)
        }
      } catch (_: Throwable) {}
    }
  }

  // Animated token positions in cell units (col+0.5,row+0.5); read only while drawing
  val tokenAnims = remember(count) {
    List(count) { Animatable(squareCenter(1, 1f), Offset.VectorConverter) }
  }
  val lastTargets = remember(count) { MutableList(count) { 1 } }
  LaunchedEffect(positions) {
    coroutineScope {
      positions.forEachIndexed { i, to ->
        val from = lastTargets[i]
        lastTargets[i] = to
        if (to == from) return@forEachIndexed
        launch {
          val anim = tokenAnims[i]
          if (to > from && to - from <= 6) {
            for (sq in (from + 1)..to) {
              anim.animateTo(squareCenter(sq, 1f), tween(110, easing = LinearEasing))
            }
          } else {
            anim.animateTo(squareCenter(to, 1f), tween(650, easing = FastOutSlowInEasing))
          }
        }
      }
    }
  }

  fun playerName(idx: Int): String =
    when {
      playMode == PlayMode.VS_AI && idx == 0 -> "شما"
      playMode == PlayMode.VS_AI -> "ربات $idx"
      playMode == PlayMode.ONLINE_ROOM ->
        room?.players?.getOrNull(idx) ?: "بازیکن ${idx + 1}"
      else -> "بازیکن ${idx + 1}"
    }

  fun resetGame() {
    positions = List(count) { 1 }
    currentTurn = 0
    diceValue = 6
    isRolling = false
    winnerIndex = -1
    recorded = false
    roundId++
    eventBanner = "بازی جدید آغاز شد! نوبت ${playerName(0)}"
  }

  suspend fun performRollAndMove(playerIdx: Int) {
    if (isRolling || winnerIndex != -1) return
    val rolled: Int
    isRolling = true
    try {
      delay(750) // dice tumbles on its own (no per-frame recomposition)
      rolled = Random.nextInt(1, 7)
      diceValue = rolled
    } finally {
      isRolling = false
    }

    val startPos = positions[playerIdx]
    val targetRaw = startPos + rolled
    if (targetRaw > 100) {
      eventBanner = "${playerName(playerIdx)} عدد $rolled آورد (نیاز به عدد دقیق برای ۱۰۰)"
      delay(300)
    } else {
      val mutable = positions.toMutableList()
      mutable[playerIdx] = targetRaw
      positions = mutable.toList()
      delay(rolled * 120L + 120L) // token walks square by square (animated)
      var finalPos = targetRaw
      val ladderDest = Ladders[targetRaw]
      val snakeDest = Snakes[targetRaw]
      if (ladderDest != null) {
        eventBanner = "نردبان! ${playerName(playerIdx)} از $targetRaw به $ladderDest صعود کرد"
        delay(150)
        finalPos = ladderDest
        mutable[playerIdx] = finalPos
        positions = mutable.toList()
        delay(700)
      } else if (snakeDest != null) {
        eventBanner = "مار نیش زد! ${playerName(playerIdx)} از $targetRaw به $snakeDest سقوط کرد"
        delay(150)
        finalPos = snakeDest
        mutable[playerIdx] = finalPos
        positions = mutable.toList()
        delay(700)
      } else {
        eventBanner = "${playerName(playerIdx)} با تاس $rolled به خانه $finalPos رفت"
      }

      if (finalPos == 100) {
        winnerIndex = playerIdx
      }
    }

    val nextTurn = if (winnerIndex != -1) playerIdx else (playerIdx + 1) % count
    currentTurn = nextTurn

    if (playMode == PlayMode.ONLINE_ROOM && room != null) {
      val j =
        JSONObject().apply {
          put("positions", JSONArray(positions))
          put("turn", nextTurn)
          put("dice", rolled)
          put("winner", winnerIndex)
          put("banner", eventBanner)
        }
      onPushOnlineState(j.toString(), if (winnerIndex == -1) "playing" else "finished")
    }
  }

  // Key omits isRolling so setting isRolling=true never self-cancels AI turn!
  LaunchedEffect(currentTurn, winnerIndex, playMode, roundId) {
    if (playMode == PlayMode.VS_AI && currentTurn > 0 && winnerIndex == -1) {
      delay(420)
      if (currentTurn > 0 && winnerIndex == -1) {
        performRollAndMove(currentTurn)
      }
    }
  }

  LaunchedEffect(winnerIndex) {
    if (winnerIndex != -1 && !recorded) {
      recorded = true
      onRecordResult(winnerIndex == 0, if (winnerIndex == 0) 45 else 10)
    }
  }

  val textPaint = remember {
    Paint().apply {
      isAntiAlias = true
      textAlign = Paint.Align.CENTER
      typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
  }

  val activeColor = playerColorFor(currentTurn)

  Column(
    modifier =
      Modifier.fillMaxSize()
        .auroraGamingBackdrop(ElectricEmerald, activeColor)
        .systemBarsPadding(),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    GameTopBar(
      title = GameType.SNAKES_LADDERS.titleFa,
      subtitle =
        when (playMode) {
          PlayMode.VS_AI -> "$count بازیکن (در برابر هوش مصنوعی)"
          PlayMode.LOCAL_PASS_AND_PLAY -> "$count بازیکن آفلاین"
          PlayMode.ONLINE_ROOM -> "اتاق آنلاین: ${room?.roomCode ?: "-"}"
        },
      accentColor = ElectricEmerald,
      onBack = onBack,
      trailingContent = {
        IconButton(onClick = { resetGame() }, modifier = Modifier.testTag("snakes_reset_button")) {
          Icon(Icons.Rounded.Refresh, contentDescription = "شروع مجدد", tint = ElectricEmerald)
        }
      },
    )

    Column(
      modifier =
        Modifier.fillMaxSize()
          .widthIn(max = 600.dp)
          .verticalScroll(rememberScrollState())
          .padding(14.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        for (i in 0 until count) {
          val active = winnerIndex == -1 && currentTurn == i
          val pColor = playerColorFor(i)
          GlassGradientCard(
            modifier = Modifier.weight(1f),
            accentColor = if (active) pColor else Color.White.copy(alpha = 0.14f),
            cornerRadius = 15.dp,
          ) {
            Column(
              modifier =
                Modifier.fillMaxWidth()
                  .background(if (active) pColor.copy(alpha = 0.16f) else Color.Transparent)
                  .padding(vertical = 8.dp, horizontal = 6.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              Text(
                text = playerName(i),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (active) FontWeight.ExtraBold else FontWeight.Medium,
                color = if (active) pColor else TextPrimary,
                maxLines = 1,
              )
              Text(
                text = "خانه ${positions[i]}",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
              )
            }
          }
        }
      }

      // Detailed 10x10 Frosted Glass Board Canvas
      GlassGradientCard(
        modifier = Modifier.fillMaxWidth().aspectRatio(1f),
        accentColor = ElectricEmerald,
        cornerRadius = 22.dp,
      ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(7.dp)) {
          val cell = size.width / 10f
          textPaint.textSize = cell * 0.29f

          for (num in 1..100) {
            val (cx, cy) = squareCenter(num, cell)
            val left = cx - cell / 2f
            val top = cy - cell / 2f
            val isEven = ((num - 1) / 10 + (num - 1) % 10) % 2 == 0
            val cellColor =
              when {
                num == 100 -> CyberGold.copy(alpha = 0.34f)
                num == 1 -> ElectricEmerald.copy(alpha = 0.24f)
                Ladders.containsKey(num) -> ElectricEmerald.copy(alpha = 0.16f)
                Snakes.containsKey(num) -> CrimsonMagenta.copy(alpha = 0.17f)
                isEven -> Color(0xCC1B2644)
                else -> Color(0xCC10182E)
              }
            drawRoundRect(
              color = cellColor,
              topLeft = Offset(left + 1f, top + 1f),
              size = Size(cell - 2f, cell - 2f),
              cornerRadius = CornerRadius(4f, 4f),
            )
            drawRoundRect(
              color = ElevatedCardStroke.copy(alpha = 0.45f),
              topLeft = Offset(left + 1f, top + 1f),
              size = Size(cell - 2f, cell - 2f),
              cornerRadius = CornerRadius(4f, 4f),
              style = Stroke(width = 1f),
            )
            textPaint.color =
              when {
                num == 100 -> android.graphics.Color.rgb(255, 224, 130)
                Ladders.containsKey(num) -> android.graphics.Color.rgb(0, 230, 118)
                Snakes.containsKey(num) -> android.graphics.Color.rgb(255, 110, 145)
                else -> android.graphics.Color.rgb(166, 180, 212)
              }
            drawContext.canvas.nativeCanvas.drawText(
              num.toString(),
              cx,
              cy + textPaint.textSize * 0.35f,
              textPaint,
            )
          }

          Ladders.forEach { (start, end) ->
            val p1 = squareCenter(start, cell)
            val p2 = squareCenter(end, cell)
            val dx = p2.x - p1.x
            val dy = p2.y - p1.y
            val len = hypot(dx, dy).coerceAtLeast(1f)
            val nx = (-dy / len) * (cell * 0.17f)
            val ny = (dx / len) * (cell * 0.17f)

            drawLine(
              color = Color.Black.copy(alpha = 0.45f),
              start = Offset(p1.x + nx + 3f, p1.y + ny + 4f),
              end = Offset(p2.x + nx + 3f, p2.y + ny + 4f),
              strokeWidth = 7f,
              cap = StrokeCap.Round,
            )
            drawLine(
              color = Color.Black.copy(alpha = 0.45f),
              start = Offset(p1.x - nx + 3f, p1.y - ny + 4f),
              end = Offset(p2.x - nx + 3f, p2.y - ny + 4f),
              strokeWidth = 7f,
              cap = StrokeCap.Round,
            )

            drawLine(
              color = ElectricEmerald,
              start = Offset(p1.x + nx, p1.y + ny),
              end = Offset(p2.x + nx, p2.y + ny),
              strokeWidth = 5.5f,
              cap = StrokeCap.Round,
            )
            drawLine(
              color = ElectricEmerald,
              start = Offset(p1.x - nx, p1.y - ny),
              end = Offset(p2.x - nx, p2.y - ny),
              strokeWidth = 5.5f,
              cap = StrokeCap.Round,
            )

            val rungs = (len / (cell * 0.44f)).toInt().coerceIn(3, 10)
            for (r in 1 until rungs) {
              val t = r.toFloat() / rungs
              val rx = p1.x + dx * t
              val ry = p1.y + dy * t
              drawLine(
                color = CyberGold,
                start = Offset(rx + nx, ry + ny),
                end = Offset(rx - nx, ry - ny),
                strokeWidth = 4f,
                cap = StrokeCap.Round,
              )
            }
          }

          Snakes.forEach { (head, tail) ->
            val pHead = squareCenter(head, cell)
            val pTail = squareCenter(tail, cell)
            val midX = (pHead.x + pTail.x) / 2f
            val midY = (pHead.y + pTail.y) / 2f
            val path =
              Path().apply {
                moveTo(pHead.x, pHead.y)
                quadraticTo(midX + cell * 0.65f, (pHead.y + midY) / 2f, midX, midY)
                quadraticTo(midX - cell * 0.65f, (midY + pTail.y) / 2f, pTail.x, pTail.y)
              }
            drawPath(path, color = Color.Black.copy(alpha = 0.42f), style = Stroke(width = 12f, cap = StrokeCap.Round))
            drawPath(path, color = CrimsonMagenta, style = Stroke(width = 8.5f, cap = StrokeCap.Round))
            drawPath(path, color = Color(0xFFFF80AB).copy(alpha = 0.7f), style = Stroke(width = 3.2f, cap = StrokeCap.Round))

            drawCircle(color = Color.Black.copy(alpha = 0.4f), radius = cell * 0.22f, center = Offset(pHead.x + 2f, pHead.y + 3f))
            drawCircle(color = CrimsonMagenta, radius = cell * 0.21f, center = pHead)
            drawCircle(color = Color.White, radius = cell * 0.06f, center = Offset(pHead.x - cell * 0.07f, pHead.y - cell * 0.04f))
            drawCircle(color = Color.White, radius = cell * 0.06f, center = Offset(pHead.x + cell * 0.07f, pHead.y - cell * 0.04f))
            drawCircle(color = ObsidianBg, radius = cell * 0.03f, center = Offset(pHead.x - cell * 0.07f, pHead.y - cell * 0.04f))
            drawCircle(color = ObsidianBg, radius = cell * 0.03f, center = Offset(pHead.x + cell * 0.07f, pHead.y - cell * 0.04f))
          }
        }
        Canvas(modifier = Modifier.fillMaxSize().padding(7.dp)) {
          val cell = size.width / 10f
          positions.indices.forEach { idx ->
            val a = tokenAnims[idx]
            val sq = positions[idx]
            val offsetAngle = (idx * 90.0) * Math.PI / 180.0
            val off = if (positions.count { it == sq } > 1) cell * 0.17f else 0f
            val moving = a.isRunning
            val lift = if (moving) cell * 0.10f else 0f
            drawGlossyToken(
              center =
                Offset(
                  a.value.x * cell + (cos(offsetAngle) * off).toFloat(),
                  a.value.y * cell + (sin(offsetAngle) * off).toFloat() - lift,
                ),
              radius = cell * 0.24f,
              baseColor = playerColorFor(idx),
              isHighlighted = idx == currentTurn && winnerIndex == -1,
            )
          }
        }
      }

      GlassGradientCard(
        modifier = Modifier.fillMaxWidth(),
        accentColor = activeColor,
        cornerRadius = 16.dp,
      ) {
        Text(
          text = eventBanner,
          style = MaterialTheme.typography.bodyMedium,
          color = TextPrimary,
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
        )
      }

      if (winnerIndex != -1) {
        WinCelebrationBanner(
          winnerTitle = "${playerName(winnerIndex)} برنده شد!",
          subtitle = "به خانه ۱۰۰ رسید",
          accent = playerColorFor(winnerIndex),
          onRematch = { resetGame() },
          onExit = onBack,
        )
      } else {
        val canHumanRoll =
          !isRolling &&
            (playMode != PlayMode.VS_AI || currentTurn == 0) &&
            (playMode != PlayMode.ONLINE_ROOM || currentTurn == myOnlineSide)

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          AnimatedGameDice(
            value = diceValue,
            isRolling = isRolling,
            accentColor = activeColor,
          )

          Button(
            onClick = { scope.launch { performRollAndMove(currentTurn) } },
            enabled = canHumanRoll,
            modifier = Modifier.weight(1f).height(58.dp).testTag("snakes_roll_button"),
            colors = ButtonDefaults.buttonColors(containerColor = ElectricEmerald),
            shape = RoundedCornerShape(18.dp),
          ) {
            Icon(BaziIcons.Dice, contentDescription = null, tint = ObsidianBg)
            Spacer(Modifier.size(8.dp))
            Text(
              text = if (canHumanRoll) "انداختن تاس (${playerName(currentTurn)})" else "نوبت ربات / حریف...",
              color = ObsidianBg,
              fontWeight = FontWeight.ExtraBold,
            )
          }
        }
      }
      Spacer(Modifier.height(10.dp))
    }
  }
}

private fun squareCenter(num: Int, cellSize: Float): Offset {
  val n = num.coerceIn(1, 100) - 1
  val rowFromBottom = n / 10
  val colInRow = n % 10
  val col = if (rowFromBottom % 2 == 0) colInRow else 9 - colInRow
  val rowFromTop = 9 - rowFromBottom
  return Offset((col + 0.5f) * cellSize, (rowFromTop + 0.5f) * cellSize)
}
