package com.example.ui.screens

import androidx.activity.compose.BackHandler
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ChatImageUtils
import com.example.data.SendState
import java.io.File
import java.util.Calendar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.ChatGroup
import com.example.data.ChatMessage
import com.example.data.GameInvite
import com.example.data.GameType
import com.example.data.UserAccount
import com.example.ui.components.AvatarBadge
import com.example.ui.components.BaziIcons
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.auroraGamingBackdrop
import com.example.ui.components.avatarColorFor
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPulse
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(
  currentUser: UserAccount?,
  groups: List<ChatGroup>,
  selectedGroup: ChatGroup?,
  messages: List<ChatMessage>,
  feedbackMessage: String?,
  chatReads: Map<String, Long>,
  draftImagePath: String?,
  replyTo: ChatMessage?,
  imageBusy: Boolean,
  onPickImage: (Uri) -> Unit,
  onClearDraftImage: () -> Unit,
  onSetReply: (ChatMessage?) -> Unit,
  onRetryMessage: (ChatMessage) -> Unit,
  loadImage: suspend (ChatMessage, Int) -> Bitmap?,
  onCreateGroup: (String) -> Unit,
  onJoinGroupByCode: (String) -> Unit,
  onInviteMember: (String, String) -> Unit,
  onOpenGroup: (ChatGroup) -> Unit,
  onCloseGroup: () -> Unit,
  onSendMessage: (String) -> Unit,
  onSendGameInvite: (GameType) -> Unit,
  onJoinGameInvite: (GameInvite) -> Unit,
  onOpenAuth: () -> Unit,
  onClearFeedback: () -> Unit,
  modifier: Modifier = Modifier,
) {
  if (selectedGroup != null) {
    BackHandler(onBack = onCloseGroup)
    TelegramConversationView(
      currentUser = currentUser,
      group = selectedGroup,
      messages = messages,
      reads = chatReads,
      draftImagePath = draftImagePath,
      replyTo = replyTo,
      imageBusy = imageBusy,
      feedbackMessage = feedbackMessage,
      onPickImage = onPickImage,
      onClearDraftImage = onClearDraftImage,
      onSetReply = onSetReply,
      onRetry = onRetryMessage,
      loadImage = loadImage,
      onBack = onCloseGroup,
      onInviteMember = { username -> onInviteMember(selectedGroup.id, username) },
      onSendMessage = onSendMessage,
      onSendGameInvite = onSendGameInvite,
      onJoinGameInvite = onJoinGameInvite,
      onClearFeedback = onClearFeedback,
      modifier = modifier,
    )
    return
  }

  var showCreateDialog by remember { mutableStateOf(false) }
  var showJoinDialog by remember { mutableStateOf(false) }
  var searchQuery by remember { mutableStateOf("") }

  val filteredGroups =
    remember(groups, searchQuery) {
      if (searchQuery.isBlank()) groups
      else groups.filter { it.name.contains(searchQuery.trim(), ignoreCase = true) }
    }

  Box(
    modifier = modifier.fillMaxSize().auroraGamingBackdrop(NeonCyan, VioletPulse),
    contentAlignment = Alignment.TopCenter,
  ) {
    Column(
      modifier = Modifier.fillMaxSize().widthIn(max = 680.dp),
    ) {
      // Telegram-style Frosted Header
      Surface(
        color = Color(0xCC10182E),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              Box(
                modifier =
                  Modifier.size(38.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(NeonCyan, VioletPulse))),
                contentAlignment = Alignment.Center,
              ) {
                Icon(BaziIcons.Forum, contentDescription = null, tint = ObsidianBg, modifier = Modifier.size(20.dp))
              }
              Column {
                Text(
                  text = "چت‌های Bazirox",
                  style = MaterialTheme.typography.titleLarge,
                  color = TextPrimary,
                  fontWeight = FontWeight.ExtraBold,
                )
                Text(
                  text = if (currentUser == null) "مهمان" else "${groups.size} گروه فعال • پیام‌رسان سریع",
                  style = MaterialTheme.typography.labelSmall,
                  color = NeonCyan,
                )
              }
            }

            if (currentUser != null) {
              Surface(
                onClick = { showJoinDialog = true },
                shape = RoundedCornerShape(50),
                color = VioletPulse.copy(alpha = 0.2f),
                border = BorderStroke(1.dp, VioletPulse.copy(alpha = 0.6f)),
                modifier = Modifier.testTag("join_group_button"),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                  Icon(BaziIcons.Groups, contentDescription = null, tint = VioletPulse, modifier = Modifier.size(16.dp))
                  Text("عضویت با کد", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                }
              }
            }
          }

          if (currentUser != null) {
            OutlinedTextField(
              value = searchQuery,
              onValueChange = { searchQuery = it },
              placeholder = { Text("جستجو در گروه‌ها...", style = MaterialTheme.typography.bodyMedium) },
              leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = TextSecondary) },
              singleLine = true,
              modifier = Modifier.fillMaxWidth().height(48.dp),
              colors =
                OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = NeonCyan.copy(alpha = 0.65f),
                  unfocusedBorderColor = Color.White.copy(alpha = 0.1f),
                  focusedContainerColor = Color(0x990A1020),
                  unfocusedContainerColor = Color(0x880A1020),
                ),
              shape = RoundedCornerShape(50),
            )
          }
        }
      }

      if (!feedbackMessage.isNullOrBlank()) {
        Surface(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
          shape = RoundedCornerShape(14.dp),
          color = ElectricEmerald.copy(alpha = 0.16f),
          border = BorderStroke(1.dp, ElectricEmerald.copy(alpha = 0.45f)),
        ) {
          Text(
            text = feedbackMessage,
            style = MaterialTheme.typography.bodyMedium,
            color = ElectricEmerald,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
          )
        }
      }

      if (currentUser == null) {
        Box(modifier = Modifier.fillMaxSize().padding(18.dp), contentAlignment = Alignment.Center) {
          GlassGradientCard(accentColor = NeonCyan, cornerRadius = 24.dp, modifier = Modifier.fillMaxWidth()) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              Box(
                modifier =
                  Modifier.size(60.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(NeonCyan.copy(alpha = 0.3f), VioletPulse.copy(alpha = 0.3f)))),
                contentAlignment = Alignment.Center,
              ) {
                Icon(BaziIcons.Forum, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(30.dp))
              }
              Text("ورود به پیام‌رسان گروهی", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
              Text(
                "با یک نام کاربری دلخواه وارد شوید تا گروه بسازید، دوستانتان را دعوت کنید و به بازی دعوتشان کنید.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
              )
              Button(
                onClick = onOpenAuth,
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("chat_login_prompt_button"),
              ) {
                Text("ورود / ساخت پروفایل سریع", color = ObsidianBg, fontWeight = FontWeight.ExtraBold)
              }
            }
          }
        }
      } else if (filteredGroups.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
          GlassGradientCard(accentColor = VioletPulse, cornerRadius = 24.dp, modifier = Modifier.fillMaxWidth()) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(26.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Icon(BaziIcons.Forum, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(46.dp))
              Text(
                text = if (searchQuery.isNotBlank()) "گروهی پیدا نشد" else "هنوز در هیچ گروهی نیستید",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
              )
              Text(
                text = "دکمه + پایین را بزنید و اولین گروه گیمینگ خود را بسازید!",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
              )
            }
          }
        }
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(bottom = 88.dp),
        ) {
          items(filteredGroups, key = { it.id }) { group ->
            TelegramChatListRow(
              group = group,
              onClick = { onOpenGroup(group) },
            )
            HorizontalDivider(
              modifier = Modifier.padding(start = 82.dp, end = 16.dp),
              thickness = 0.6.dp,
              color = Color.White.copy(alpha = 0.08f),
            )
          }
        }
      }
    }

    // Telegram-style Floating Circular New Group FAB
    if (currentUser != null) {
      FloatingActionButton(
        onClick = { showCreateDialog = true },
        containerColor = NeonCyan,
        contentColor = ObsidianBg,
        shape = CircleShape,
        elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp),
        modifier =
          Modifier.align(Alignment.BottomEnd)
            .padding(20.dp)
            .size(58.dp)
            .testTag("create_group_button"),
      ) {
        Icon(Icons.Rounded.Add, contentDescription = "ساخت گروه جدید", modifier = Modifier.size(28.dp))
      }
    }
  }

  if (showCreateDialog) {
    var groupName by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showCreateDialog = false },
      containerColor = Color(0xFF141D36),
      title = { Text("ساخت گروه جدید", color = NeonCyan) },
      text = {
        OutlinedTextField(
          value = groupName,
          onValueChange = { groupName = it.take(36) },
          label = { Text("نام گروه (مثلاً اسکواد منچ)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("create_group_name_input"),
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (groupName.isNotBlank()) {
              onCreateGroup(groupName)
              showCreateDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
          modifier = Modifier.testTag("confirm_create_group_button"),
        ) {
          Text("ساخت گروه", color = ObsidianBg, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showCreateDialog = false }) { Text("انصراف", color = TextSecondary) }
      },
    )
  }

  if (showJoinDialog) {
    var codeInput by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showJoinDialog = false },
      containerColor = Color(0xFF141D36),
      title = { Text("عضویت در گروه با کد دعوت", color = VioletPulse) },
      text = {
        OutlinedTextField(
          value = codeInput,
          // The invite contains a case-sensitive encryption key: never change its case.
          onValueChange = { codeInput = it.trim().take(100) },
          label = { Text("کد دعوت کامل گروه") },
          placeholder = { Text("کد را همان‌طور که فرستاده شده بچسبان") },
          supportingText = { Text("شامل کد و کلید رمزنگاری با یک نقطه بینشان است") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("join_group_code_input"),
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (codeInput.isNotBlank()) {
              onJoinGroupByCode(codeInput)
              showJoinDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = VioletPulse),
          modifier = Modifier.testTag("confirm_join_group_button"),
        ) {
          Text("عضویت", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showJoinDialog = false }) { Text("انصراف", color = TextSecondary) }
      },
    )
  }
}

@Composable
private fun TelegramChatListRow(
  group: ChatGroup,
  onClick: () -> Unit,
) {
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .clickable(onClick = onClick)
        .padding(horizontal = 16.dp, vertical = 12.dp)
        .testTag("group_card_${group.id}"),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Box(contentAlignment = Alignment.BottomStart) {
      AvatarBadge(name = group.name, colorIndex = group.name.hashCode(), size = 54.dp)
      Box(
        modifier =
          Modifier.size(14.dp)
            .clip(CircleShape)
            .background(ElectricEmerald)
            .border(2.dp, Color(0xFF0C1428), CircleShape)
      )
    }

    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = group.name,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = TextPrimary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f),
        )
        Spacer(Modifier.width(8.dp))
        Text(
          text = if (group.lastMessageTime > 0L) formatClockTime(group.lastMessageTime) else "تازه",
          style = MaterialTheme.typography.labelSmall,
          color = NeonCyan,
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = group.lastMessagePreview.ifBlank { "کد دعوت: ${group.inviteCode}" },
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f),
        )
        Spacer(Modifier.width(8.dp))
        Surface(
          shape = RoundedCornerShape(50),
          color = NeonCyan.copy(alpha = 0.16f),
          border = BorderStroke(0.8.dp, NeonCyan.copy(alpha = 0.4f)),
        ) {
          Text(
            text = "${group.members.size} عضو",
            style = MaterialTheme.typography.labelSmall,
            color = NeonCyan,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
          )
        }
      }
    }
  }
}

private sealed interface ChatRow {
  data class DateHeader(val label: String) : ChatRow
  data class Msg(val msg: ChatMessage, val first: Boolean, val last: Boolean) : ChatRow
}

private enum class TickState { CLOCK, SENT, READ, FAILED }

private fun buildChatRows(messages: List<ChatMessage>): List<ChatRow> {
  val out = ArrayList<ChatRow>(messages.size + 8)
  var prevDay = ""
  messages.forEachIndexed { i, m ->
    val day = dayLabel(m.timestamp)
    if (day != prevDay) {
      out.add(ChatRow.DateHeader(day))
      prevDay = day
    }
    val prev = messages.getOrNull(i - 1)
    val next = messages.getOrNull(i + 1)
    fun sameBlock(a: ChatMessage?, b: ChatMessage) =
      a != null &&
        a.senderUsername.equals(b.senderUsername, ignoreCase = true) &&
        dayLabel(a.timestamp) == dayLabel(b.timestamp) &&
        kotlin.math.abs(a.timestamp - b.timestamp) < 5 * 60_000L
    out.add(ChatRow.Msg(m, first = !sameBlock(prev, m), last = !sameBlock(next, m)))
  }
  return out
}

private fun dayLabel(ts: Long): String {
  if (ts <= 0L) return "امروز"
  val cal = Calendar.getInstance()
  val today = cal.get(Calendar.YEAR) * 1000 + cal.get(Calendar.DAY_OF_YEAR)
  cal.timeInMillis = ts
  val d = cal.get(Calendar.YEAR) * 1000 + cal.get(Calendar.DAY_OF_YEAR)
  return when {
    d == today -> "امروز"
    d == today - 1 -> "دیروز"
    else -> SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date(ts))
  }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TelegramConversationView(
  currentUser: UserAccount?,
  group: ChatGroup,
  messages: List<ChatMessage>,
  reads: Map<String, Long>,
  draftImagePath: String?,
  replyTo: ChatMessage?,
  imageBusy: Boolean,
  feedbackMessage: String?,
  onBack: () -> Unit,
  onInviteMember: (String) -> Unit,
  onSendMessage: (String) -> Unit,
  onSendGameInvite: (GameType) -> Unit,
  onJoinGameInvite: (GameInvite) -> Unit,
  onPickImage: (Uri) -> Unit,
  onClearDraftImage: () -> Unit,
  onSetReply: (ChatMessage?) -> Unit,
  onRetry: (ChatMessage) -> Unit,
  loadImage: suspend (ChatMessage, Int) -> Bitmap?,
  onClearFeedback: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var messageText by remember { mutableStateOf("") }
  var showInviteMemberDialog by remember { mutableStateOf(false) }
  var showGameInvitePicker by remember { mutableStateOf(false) }
  var viewerMessage by remember { mutableStateOf<ChatMessage?>(null) }
  val clipboard = LocalClipboardManager.current
  val listState = rememberLazyListState()
  val scope = rememberCoroutineScope()
  val rows = remember(messages) { buildChatRows(messages) }
  val myName = currentUser?.username.orEmpty()

  val photoPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
      if (uri != null) onPickImage(uri)
    }

  val nearBottom by remember {
    derivedStateOf {
      val info = listState.layoutInfo
      val last = info.visibleItemsInfo.lastOrNull()
      last == null || last.index >= info.totalItemsCount - 3
    }
  }
  var firstScrollDone by remember(group.id) { mutableStateOf(false) }
  LaunchedEffect(rows.size) {
    if (rows.isEmpty()) return@LaunchedEffect
    val lastIsMine =
      (rows.last() as? ChatRow.Msg)?.msg?.senderUsername.equals(myName, ignoreCase = true)
    if (!firstScrollDone) {
      listState.scrollToItem(rows.lastIndex)
      firstScrollDone = true
    } else if (nearBottom || lastIsMine) {
      listState.animateScrollToItem(rows.lastIndex)
    }
  }

  Column(modifier = modifier.fillMaxSize()) {
    // 1. Telegram Top Chat Header
    Surface(
      color = Color(0xE6111B33),
      border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.1f)),
    ) {
      Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f),
          ) {
            IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
              Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت", tint = TextPrimary)
            }
            AvatarBadge(name = group.name, colorIndex = group.name.hashCode(), size = 40.dp)
            Spacer(Modifier.width(10.dp))
            Column {
              Text(
                text = group.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = "${group.members.size} عضو • آنلاین",
                style = MaterialTheme.typography.labelSmall,
                color = NeonCyan,
                maxLines = 1,
              )
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(
              onClick = { clipboard.setText(AnnotatedString(group.shareCode.ifBlank { group.inviteCode })) },
              shape = RoundedCornerShape(50),
              color = NeonCyan.copy(alpha = 0.12f),
              border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.4f)),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
              ) {
                Icon(BaziIcons.Copy, contentDescription = "کپی کد دعوت", tint = NeonCyan, modifier = Modifier.size(13.dp))
                Text(group.inviteCode, style = MaterialTheme.typography.labelSmall, color = NeonCyan)
              }
            }
            IconButton(
              onClick = { showInviteMemberDialog = true },
              modifier = Modifier.size(44.dp).testTag("invite_member_button"),
            ) {
              Icon(BaziIcons.PersonAdd, contentDescription = "دعوت عضو", tint = ElectricEmerald)
            }
          }
        }

        if (!feedbackMessage.isNullOrBlank()) {
          Text(
            text = feedbackMessage,
            style = MaterialTheme.typography.labelSmall,
            color = ElectricEmerald,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
          )
        }
      }
    }

    // 2. Wallpaper + Messages
    Box(
      modifier =
        Modifier.weight(1f)
          .fillMaxWidth()
          .background(
            Brush.verticalGradient(
              listOf(Color(0xFF070D1B), Color(0xFF0D1730), Color(0xFF080E1D))
            )
          )
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        val step = 76f
        val cols = (size.width / step).toInt() + 1
        val rowsN = (size.height / step).toInt() + 1
        for (r in 0..rowsN) {
          for (c in 0..cols) {
            val x = c * step + if (r % 2 == 0) 0f else step * 0.5f
            val y = r * step
            when ((r + c) % 3) {
              0 ->
                drawCircle(
                  color = NeonCyan.copy(alpha = 0.04f),
                  radius = 10f,
                  center = Offset(x, y),
                  style = Stroke(width = 2f),
                )
              1 ->
                drawLine(
                  color = VioletPulse.copy(alpha = 0.045f),
                  start = Offset(x - 7f, y - 7f),
                  end = Offset(x + 7f, y + 7f),
                  strokeWidth = 2f,
                  cap = StrokeCap.Round,
                )
              else ->
                drawCircle(
                  color = CyberGold.copy(alpha = 0.035f),
                  radius = 3.5f,
                  center = Offset(x, y),
                )
            }
          }
        }
      }

      LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
        contentPadding = PaddingValues(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        if (messages.isEmpty()) {
          item(key = "empty") {
            Box(
              modifier = Modifier.fillMaxWidth().padding(vertical = 36.dp),
              contentAlignment = Alignment.Center,
            ) {
              Surface(
                shape = RoundedCornerShape(50),
                color = Color(0x9916223F),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
              ) {
                Text(
                  text = "اولین پیام، عکس یا دعوت بازی را بفرستید!",
                  style = MaterialTheme.typography.bodyMedium,
                  color = TextSecondary,
                  modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
              }
            }
          }
        }

        items(
          rows,
          key = {
            when (it) {
              is ChatRow.DateHeader -> "d_${it.label}"
              is ChatRow.Msg -> it.msg.id
            }
          },
        ) { row ->
          when (row) {
            is ChatRow.DateHeader ->
              Box(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
              ) {
                Surface(shape = RoundedCornerShape(50), color = Color(0xAA16223F)) {
                  Text(
                    text = row.label,
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 3.dp),
                  )
                }
              }
            is ChatRow.Msg -> {
              val msg = row.msg
              val isMe = msg.senderUsername.equals(myName, ignoreCase = true)
              val tick =
                when {
                  !isMe -> TickState.SENT
                  msg.sendState == SendState.SENDING -> TickState.CLOCK
                  msg.sendState == SendState.FAILED -> TickState.FAILED
                  reads.any { (u, ts) -> !u.equals(myName, ignoreCase = true) && ts >= msg.timestamp } ->
                    TickState.READ
                  else -> TickState.SENT
                }
              TelegramMessageRow(
                msg = msg,
                isMe = isMe,
                showName = row.first && !isMe,
                showAvatar = row.last && !isMe,
                isLastInBlock = row.last,
                topGap = row.first,
                tick = tick,
                onJoinGameInvite = onJoinGameInvite,
                onReply = { onSetReply(msg) },
                onCopy = { clipboard.setText(AnnotatedString(msg.text)) },
                onRetry = { onRetry(msg) },
                onOpenImage = { viewerMessage = msg },
                loadImage = loadImage,
                onJumpTo = { id ->
                  val idx = rows.indexOfFirst { it is ChatRow.Msg && it.msg.id == id }
                  if (idx >= 0) scope.launch { listState.animateScrollToItem(idx) }
                },
              )
            }
          }
        }
      }

      if (!nearBottom && rows.isNotEmpty()) {
        Surface(
          onClick = { scope.launch { listState.animateScrollToItem(rows.lastIndex) } },
          shape = CircleShape,
          color = Color(0xF01B2542),
          border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
          shadowElevation = 6.dp,
          modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp).size(42.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(BaziIcons.ArrowDown, contentDescription = "پایین", tint = NeonCyan, modifier = Modifier.size(24.dp))
          }
        }
      }
    }

    // 3. Composer
    Surface(
      color = Color(0xEE0F172C),
      border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.1f)),
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {
        if (replyTo != null) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(BaziIcons.Reply, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
            Box(Modifier.width(3.dp).height(34.dp).clip(RoundedCornerShape(2.dp)).background(NeonCyan))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                "پاسخ به ${replyTo.senderUsername}",
                style = MaterialTheme.typography.labelMedium,
                color = NeonCyan,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = if (replyTo.hasImage && replyTo.text.isBlank()) "📷 عکس" else replyTo.text,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
            IconButton(onClick = { onSetReply(null) }, modifier = Modifier.size(36.dp)) {
              Icon(Icons.Rounded.Close, contentDescription = "لغو پاسخ", tint = TextSecondary)
            }
          }
        }

        if (draftImagePath != null || imageBusy) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            val thumb by
              produceState<ImageBitmap?>(null, draftImagePath) {
                value =
                  draftImagePath?.let { p ->
                    withContext(Dispatchers.IO) {
                      ChatImageUtils.decodeSampled(File(p), 256)?.asImageBitmap()
                    }
                  }
              }
            Box(
              modifier =
                Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x44000000)),
              contentAlignment = Alignment.Center,
            ) {
              val t = thumb
              if (t != null) {
                Image(t, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
              } else {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp, color = NeonCyan)
              }
            }
            Column(modifier = Modifier.weight(1f)) {
              Text("عکس آماده ارسال", style = MaterialTheme.typography.labelLarge, color = TextPrimary)
              Text(
                "در صورت تمایل توضیح بنویسید",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
              )
            }
            IconButton(onClick = onClearDraftImage, modifier = Modifier.size(36.dp)) {
              Icon(Icons.Rounded.Close, contentDescription = "حذف عکس", tint = TextSecondary)
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
          verticalAlignment = Alignment.Bottom,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Surface(
            onClick = { showGameInvitePicker = true },
            shape = CircleShape,
            color = CyberGold.copy(alpha = 0.16f),
            border = BorderStroke(1.dp, CyberGold.copy(alpha = 0.45f)),
            modifier = Modifier.size(44.dp).testTag("send_game_invite_button"),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(BaziIcons.SportsEsports, contentDescription = "دعوت به بازی", tint = CyberGold, modifier = Modifier.size(22.dp))
            }
          }

          Surface(
            onClick = { photoPicker.launch("image/*") },
            shape = CircleShape,
            color = NeonCyan.copy(alpha = 0.14f),
            border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.45f)),
            modifier = Modifier.size(44.dp).testTag("attach_photo_button"),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(BaziIcons.Photo, contentDescription = "ارسال عکس", tint = NeonCyan, modifier = Modifier.size(22.dp))
            }
          }

          OutlinedTextField(
            value = messageText,
            onValueChange = { messageText = it },
            placeholder = {
              Text(if (draftImagePath != null) "توضیح..." else "پیام...", color = TextMuted)
            },
            maxLines = 5,
            modifier = Modifier.weight(1f).testTag("chat_message_input"),
            colors =
              OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonCyan.copy(alpha = 0.65f),
                unfocusedBorderColor = Color.White.copy(alpha = 0.14f),
                focusedContainerColor = Color(0xCC090E1C),
                unfocusedContainerColor = Color(0xAA090E1C),
              ),
            shape = RoundedCornerShape(24.dp),
          )

          val canSend = (messageText.isNotBlank() || draftImagePath != null) && !imageBusy
          Box(
            modifier =
              Modifier.size(46.dp)
                .clip(CircleShape)
                .background(
                  if (canSend) Brush.linearGradient(listOf(NeonCyan, VioletPulse))
                  else Brush.linearGradient(listOf(Color(0xFF1F2B47), Color(0xFF1A2238)))
                )
                .clickable(enabled = canSend) {
                  onSendMessage(messageText)
                  messageText = ""
                  onClearFeedback()
                }
                .testTag("send_chat_message_button"),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Rounded.Send,
              contentDescription = "ارسال",
              tint = if (canSend) ObsidianBg else TextSecondary,
              modifier = Modifier.size(20.dp),
            )
          }
        }
      }
    }
  }

  viewerMessage?.let { vm ->
    ImageViewerDialog(msg = vm, loadImage = loadImage, onDismiss = { viewerMessage = null })
  }

  if (showInviteMemberDialog) {
    var targetUser by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showInviteMemberDialog = false },
      containerColor = Color(0xFF141D36),
      title = { Text("دعوت عضو به گروه", color = ElectricEmerald) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            "بهترین راه: دکمه‌ی کپی کد دعوت را بزن و کد کامل را برای دوستت بفرست (کلید رمزنگاری داخل آن است). عضوی که فقط با نام کاربری اضافه شود نمی‌تواند پیام‌ها را بخواند.",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
          )
          OutlinedTextField(
            value = targetUser,
            onValueChange = { targetUser = it.take(32) },
            label = { Text("نام کاربری دوست") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("invite_username_input"),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (targetUser.isNotBlank()) {
              onInviteMember(targetUser)
              showInviteMemberDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = ElectricEmerald),
          modifier = Modifier.testTag("confirm_invite_member_button"),
        ) {
          Text("افزودن به گروه", color = ObsidianBg, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showInviteMemberDialog = false }) { Text("بستن", color = TextSecondary) }
      },
    )
  }

  if (showGameInvitePicker) {
    AlertDialog(
      onDismissRequest = { showGameInvitePicker = false },
      containerColor = Color(0xFF141D36),
      title = { Text("ارسال دعوت بازی در گروه", color = CyberGold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          GameType.entries.forEach { g ->
            OutlinedButton(
              onClick = {
                onSendGameInvite(g)
                showGameInvitePicker = false
              },
              modifier = Modifier.fillMaxWidth().height(48.dp),
              border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f)),
              shape = RoundedCornerShape(12.dp),
            ) {
              Text("دعوت به ${g.titleFa}", color = TextPrimary)
            }
          }
        }
      },
      confirmButton = {},
      dismissButton = {
        TextButton(onClick = { showGameInvitePicker = false }) { Text("بستن", color = TextSecondary) }
      },
    )
  }
}

/** Swipe a bubble sideways to reply, exactly like Telegram. */
@Composable
private fun SwipeToReply(onReply: () -> Unit, content: @Composable () -> Unit) {
  val offsetX = remember { Animatable(0f) }
  val scope = rememberCoroutineScope()
  val haptic = LocalHapticFeedback.current
  val thresholdPx = with(LocalDensity.current) { 64.dp.toPx() }
  val maxPx = thresholdPx * 1.35f
  var triggered by remember { mutableStateOf(false) }
  val latestReply by rememberUpdatedState(onReply)

  Box(
    modifier =
      Modifier.fillMaxWidth().pointerInput(Unit) {
        detectHorizontalDragGestures(
          onDragStart = { triggered = false },
          onDragEnd = { scope.launch { offsetX.animateTo(0f, spring(stiffness = Spring.StiffnessMedium)) } },
          onDragCancel = { scope.launch { offsetX.animateTo(0f, spring(stiffness = Spring.StiffnessMedium)) } },
        ) { change, drag ->
          change.consume()
          val n = (offsetX.value + drag * 0.6f).coerceIn(-maxPx, maxPx)
          scope.launch { offsetX.snapTo(n) }
          if (!triggered && kotlin.math.abs(n) >= thresholdPx) {
            triggered = true
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            latestReply()
          }
        }
      }
  ) {
    val progress = (kotlin.math.abs(offsetX.value) / thresholdPx).coerceIn(0f, 1f)
    if (progress > 0.05f) {
      Box(
        modifier =
          Modifier.align(if (offsetX.value < 0) Alignment.CenterEnd else Alignment.CenterStart)
            .padding(horizontal = 14.dp)
            .size(30.dp)
            .graphicsLayer {
              alpha = progress
              scaleX = 0.6f + 0.4f * progress
              scaleY = 0.6f + 0.4f * progress
            }
            .clip(CircleShape)
            .background(Color(0x55000000)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(BaziIcons.Reply, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
      }
    }
    Box(modifier = Modifier.fillMaxWidth().graphicsLayer { translationX = offsetX.value }) { content() }
  }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TelegramMessageRow(
  msg: ChatMessage,
  isMe: Boolean,
  showName: Boolean,
  showAvatar: Boolean,
  isLastInBlock: Boolean,
  topGap: Boolean,
  tick: TickState,
  onJoinGameInvite: (GameInvite) -> Unit,
  onReply: () -> Unit,
  onCopy: () -> Unit,
  onRetry: () -> Unit,
  onOpenImage: () -> Unit,
  loadImage: suspend (ChatMessage, Int) -> Bitmap?,
  onJumpTo: (String) -> Unit,
) {
  // RTL layout: Arrangement.Start is RIGHT (outgoing), Arrangement.End is LEFT (incoming)
  val big = 18.dp
  val tail = 4.dp
  val bubbleShape =
    if (isMe) {
      RoundedCornerShape(topStart = big, topEnd = big, bottomStart = if (isLastInBlock) tail else big, bottomEnd = big)
    } else {
      RoundedCornerShape(topStart = big, topEnd = big, bottomStart = big, bottomEnd = if (isLastInBlock) tail else big)
    }

  val bubbleBrush =
    if (isMe) Brush.linearGradient(listOf(Color(0xD90E5B7D), Color(0xD9273B7A)))
    else Brush.linearGradient(listOf(Color(0xD91E2947), Color(0xD9131B32)))
  val borderColor = if (isMe) NeonCyan.copy(alpha = 0.42f) else Color.White.copy(alpha = 0.14f)
  var menuOpen by remember { mutableStateOf(false) }
  val photoOnly = msg.hasImage && msg.text.isBlank()

  SwipeToReply(onReply = onReply) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(top = if (topGap) 6.dp else 0.dp),
      horizontalArrangement = if (isMe) Arrangement.Start else Arrangement.End,
      verticalAlignment = Alignment.Bottom,
    ) {
      Row(
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Box {
          Box(
            modifier =
              (if (msg.hasImage) Modifier.width(264.dp) else Modifier.widthIn(min = 96.dp, max = 292.dp))
                .clip(bubbleShape)
                .background(bubbleBrush)
                .border(1.dp, borderColor, bubbleShape)
                .combinedClickable(onClick = {}, onLongClick = { menuOpen = true })
                .padding(
                  horizontal = if (msg.hasImage) 4.dp else 12.dp,
                  vertical = if (msg.hasImage) 4.dp else 8.dp,
                )
          ) {
            TelegramBubbleContent(
              msg = msg,
              isMe = isMe,
              showName = showName,
              photoOnly = photoOnly,
              tick = tick,
              onJoinGameInvite = onJoinGameInvite,
              onOpenImage = onOpenImage,
              onRetry = onRetry,
              loadImage = loadImage,
              onJumpTo = onJumpTo,
            )
          }
          DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            DropdownMenuItem(
              text = { Text("پاسخ") },
              leadingIcon = { Icon(BaziIcons.Reply, contentDescription = null, modifier = Modifier.size(20.dp)) },
              onClick = {
                menuOpen = false
                onReply()
              },
            )
            if (msg.text.isNotBlank()) {
              DropdownMenuItem(
                text = { Text("کپی متن") },
                leadingIcon = { Icon(BaziIcons.Copy, contentDescription = null, modifier = Modifier.size(20.dp)) },
                onClick = {
                  menuOpen = false
                  onCopy()
                },
              )
            }
            if (tick == TickState.FAILED) {
              DropdownMenuItem(
                text = { Text("تلاش دوباره") },
                onClick = {
                  menuOpen = false
                  onRetry()
                },
              )
            }
          }
        }
        if (!isMe) {
          if (showAvatar) {
            AvatarBadge(name = msg.senderUsername, colorIndex = msg.senderColorIndex, size = 30.dp)
          } else {
            Spacer(Modifier.size(30.dp))
          }
        }
      }
    }
  }
}

@Composable
private fun TelegramBubbleContent(
  msg: ChatMessage,
  isMe: Boolean,
  showName: Boolean,
  photoOnly: Boolean,
  tick: TickState,
  onJoinGameInvite: (GameInvite) -> Unit,
  onOpenImage: () -> Unit,
  onRetry: () -> Unit,
  loadImage: suspend (ChatMessage, Int) -> Bitmap?,
  onJumpTo: (String) -> Unit,
) {
  val pad = if (msg.hasImage) Modifier.padding(horizontal = 8.dp) else Modifier
  Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
    if (showName) {
      Text(
        text = msg.senderUsername,
        style = MaterialTheme.typography.labelMedium,
        color = avatarColorFor(msg.senderColorIndex),
        fontWeight = FontWeight.ExtraBold,
        modifier = if (msg.hasImage) Modifier.padding(start = 8.dp, top = 4.dp, end = 8.dp) else Modifier,
      )
    }

    if (msg.replyToId != null) {
      Row(
        modifier =
          Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0x33000000))
            .clickable { onJumpTo(msg.replyToId) }
            .padding(horizontal = 8.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(Modifier.width(3.dp).height(32.dp).clip(RoundedCornerShape(2.dp)).background(NeonCyan))
        Column {
          Text(
            msg.replyToSender ?: "",
            style = MaterialTheme.typography.labelSmall,
            color = NeonCyan,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
          )
          Text(
            msg.replyToText ?: "",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }

    if (msg.hasImage) {
      ChatImageView(
        msg = msg,
        loadImage = loadImage,
        onOpen = onOpenImage,
        overlay =
          if (photoOnly) {
            {
              Surface(
                shape = RoundedCornerShape(50),
                color = Color(0x99000000),
                modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp),
              ) {
                MessageMeta(msg, isMe, tick, onRetry, light = true, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
              }
            }
          } else null,
      )
    }

    if (msg.text.isNotBlank()) {
      Text(
        text = msg.text,
        style = MaterialTheme.typography.bodyLarge,
        color = TextPrimary,
        modifier = pad,
      )
    }

    msg.gameInvite?.let { invite ->
      Row(
        modifier =
          Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x660B1120))
            .border(1.dp, VioletPulse.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Box(
          modifier =
            Modifier.width(3.dp)
              .height(38.dp)
              .clip(RoundedCornerShape(2.dp))
              .background(CyberGold)
        )
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "دعوت بازی ${invite.gameType.titleFa}",
            style = MaterialTheme.typography.labelLarge,
            color = CyberGold,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = "کد اتاق: ${invite.roomCode}",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
          )
        }
        Button(
          onClick = { onJoinGameInvite(invite) },
          colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
          shape = RoundedCornerShape(50),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
          modifier = Modifier.height(34.dp),
        ) {
          Text("شروع", color = ObsidianBg, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold)
        }
      }
    }

    if (!photoOnly) {
      MessageMeta(
        msg, isMe, tick, onRetry, light = false,
        modifier = Modifier.align(Alignment.End).then(if (msg.hasImage) Modifier.padding(end = 8.dp, bottom = 2.dp) else Modifier),
      )
    }
  }
}

@Composable
private fun MessageMeta(
  msg: ChatMessage,
  isMe: Boolean,
  tick: TickState,
  onRetry: () -> Unit,
  light: Boolean,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier,
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(4.dp),
  ) {
    Text(
      text = formatClockTime(msg.timestamp),
      style = MaterialTheme.typography.labelSmall,
      color = if (light) Color.White else if (isMe) Color(0xFFB3E5FC) else TextMuted,
    )
    if (isMe) {
      TelegramTicks(
        state = tick,
        modifier = if (tick == TickState.FAILED) Modifier.clickable(onClick = onRetry) else Modifier,
      )
    }
  }
}

@Composable
private fun ChatImageView(
  msg: ChatMessage,
  loadImage: suspend (ChatMessage, Int) -> Bitmap?,
  onOpen: () -> Unit,
  overlay: (@Composable BoxScope.() -> Unit)?,
) {
  val loaded by
    produceState<Pair<Boolean, ImageBitmap?>>(false to null, msg.id) {
      value = true to loadImage(msg, 900)?.asImageBitmap()
    }
  val bmp = loaded.second
  val ratio = bmp?.let { (it.width.toFloat() / it.height).coerceIn(0.7f, 1.7f) } ?: 1.33f
  Box(
    modifier =
      Modifier.fillMaxWidth()
        .aspectRatio(ratio)
        .clip(RoundedCornerShape(14.dp))
        .background(Color(0x33000000))
        .clickable(enabled = bmp != null, onClick = onOpen),
    contentAlignment = Alignment.Center,
  ) {
    when {
      bmp != null ->
        Image(bmp, contentDescription = "عکس", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
      !loaded.first ->
        CircularProgressIndicator(modifier = Modifier.size(26.dp), strokeWidth = 2.dp, color = NeonCyan)
      else -> Icon(BaziIcons.Photo, contentDescription = null, tint = TextMuted, modifier = Modifier.size(34.dp))
    }
    overlay?.invoke(this)
  }
}

@Composable
private fun ImageViewerDialog(
  msg: ChatMessage,
  loadImage: suspend (ChatMessage, Int) -> Bitmap?,
  onDismiss: () -> Unit,
) {
  val bmp by produceState<ImageBitmap?>(null, msg.id) { value = loadImage(msg, 2000)?.asImageBitmap() }
  var scale by remember { mutableFloatStateOf(1f) }
  var pan by remember { mutableStateOf(Offset.Zero) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(Color(0xF2000000))
          .pointerInput(Unit) { detectTapGestures(onTap = { onDismiss() }, onDoubleTap = { scale = 1f; pan = Offset.Zero }) }
          .pointerInput(Unit) {
            detectTransformGestures { _, p, zoom, _ ->
              scale = (scale * zoom).coerceIn(1f, 5f)
              pan = if (scale > 1f) pan + p else Offset.Zero
            }
          },
      contentAlignment = Alignment.Center,
    ) {
      val b = bmp
      if (b != null) {
        Image(
          b,
          contentDescription = "عکس",
          contentScale = ContentScale.Fit,
          modifier =
            Modifier.fillMaxSize().graphicsLayer {
              scaleX = scale
              scaleY = scale
              translationX = pan.x
              translationY = pan.y
            },
        )
      } else {
        CircularProgressIndicator(color = NeonCyan)
      }
      IconButton(
        onClick = onDismiss,
        modifier = Modifier.align(Alignment.TopEnd).padding(12.dp).systemBarsPadding(),
      ) {
        Icon(Icons.Rounded.Close, contentDescription = "بستن", tint = Color.White)
      }
      Text(
        text = msg.senderUsername + if (msg.text.isNotBlank()) "  •  ${msg.text}" else "",
        style = MaterialTheme.typography.bodyMedium,
        color = Color.White,
        maxLines = 2,
        modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp).systemBarsPadding(),
      )
    }
  }
}

/** Telegram-style status: clock (sending), ✓ (sent), ✓✓ blue (read), red ! (failed). */
@Composable
private fun TelegramTicks(state: TickState, modifier: Modifier = Modifier) {
  val grey = Color(0xFFB3C7E6)
  val blue = Color(0xFF4FC3F7)
  Canvas(modifier = modifier.size(17.dp, 11.dp)) {
    val w = size.width
    val h = size.height
    val stroke = Stroke(width = 2.1f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    when (state) {
      TickState.CLOCK -> {
        val c = Offset(w * 0.78f, h * 0.5f)
        val r = h * 0.46f
        drawCircle(color = grey, radius = r, center = c, style = Stroke(width = 1.6f))
        drawLine(grey, c, Offset(c.x, c.y - r * 0.6f), strokeWidth = 1.6f, cap = StrokeCap.Round)
        drawLine(grey, c, Offset(c.x + r * 0.45f, c.y), strokeWidth = 1.6f, cap = StrokeCap.Round)
      }
      TickState.FAILED -> {
        val c = Offset(w * 0.78f, h * 0.5f)
        drawCircle(color = Color(0xFFFF5252), radius = h * 0.5f, center = c)
        drawLine(Color.White, Offset(c.x, c.y - h * 0.26f), Offset(c.x, c.y + h * 0.05f), strokeWidth = 2f, cap = StrokeCap.Round)
        drawCircle(color = Color.White, radius = 1.2f, center = Offset(c.x, c.y + h * 0.26f))
      }
      TickState.SENT -> {
        val p =
          Path().apply {
            moveTo(w * 0.52f, h * 0.55f)
            lineTo(w * 0.72f, h * 0.85f)
            lineTo(w * 1.0f - 1f, h * 0.12f)
          }
        drawPath(p, color = grey, style = stroke)
      }
      TickState.READ -> {
        val p1 =
          Path().apply {
            moveTo(1f, h * 0.55f)
            lineTo(w * 0.22f, h * 0.85f)
            lineTo(w * 0.52f, h * 0.12f)
          }
        val p2 =
          Path().apply {
            moveTo(w * 0.40f, h * 0.62f)
            lineTo(w * 0.60f, h * 0.85f)
            lineTo(w * 0.98f, h * 0.12f)
          }
        drawPath(p1, color = blue, style = stroke)
        drawPath(p2, color = blue, style = stroke)
      }
    }
  }
}

private fun formatClockTime(ts: Long): String {
  if (ts <= 0L) return "الان"
  return try {
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ts))
  } catch (_: Throwable) {
    "الان"
  }
}
