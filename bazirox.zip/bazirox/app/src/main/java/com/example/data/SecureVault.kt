package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.security.CryptoManager
import org.json.JSONArray
import org.json.JSONObject

/**
 * Encrypted local vault backed by Android KeyStore AES-256-GCM.
 * Sensitive credentials, tokens, chat history, and cPanel server config
 * are never written in plaintext to disk.
 */
class SecureVault(context: Context) {

  private val prefs: SharedPreferences =
    context.getSharedPreferences("baziland_secure_vault_v1", Context.MODE_PRIVATE)

  private fun putEncrypted(key: String, plainJson: String) {
    val encrypted = CryptoManager.encryptLocal(plainJson)
    prefs.edit().putString(key, encrypted).apply()
  }

  private fun getDecrypted(key: String): String? {
    val raw = prefs.getString(key, null) ?: return null
    return CryptoManager.decryptLocal(raw)
  }

  // --- cPanel Admin Configuration ---

  fun saveCPanelConfig(config: CPanelConfig) {
    val json =
      JSONObject().apply {
        put("apiBaseUrl", config.apiBaseUrl)
        put("dbHost", config.dbHost)
        put("dbName", config.dbName)
        put("dbUser", config.dbUser)
        put("apiSecret", config.apiSecret)
        put("hmacEnabled", config.hmacEnabled)
        put("e2eeEnabled", config.e2eeEnabled)
        put("maintenanceMode", config.maintenanceMode)
        put("pollingIntervalMs", config.pollingIntervalMs)
        put("lastTestStatus", config.lastTestStatus)
        put("lastTestLatencyMs", config.lastTestLatencyMs)
        put("isConnected", config.isConnected)
      }
    putEncrypted(KEY_CPANEL_CONFIG, json.toString())
  }

  /**
   * Server address + shared HMAC key are baked into the build (.env -> masked BuildConfig -> ServerConfig) so every
   * installed copy talks to the same server. Without this each phone generated its own random
   * key, which never matched the key inside api.php.
   */
  fun loadCPanelConfig(): CPanelConfig {
    val stored = loadStoredCPanelConfig()
    val url = ServerConfig.baseUrl
    if (url.isBlank()) return stored
    val secret = ServerConfig.secret
    return stored.copy(apiBaseUrl = url, apiSecret = secret.ifBlank { stored.apiSecret })
  }

  private fun loadStoredCPanelConfig(): CPanelConfig {
    val decrypted = getDecrypted(KEY_CPANEL_CONFIG) ?: return CPanelConfig(
      apiSecret = CryptoManager.generateSecureSecret(24)
    ).also { saveCPanelConfig(it) }
    return try {
      val j = JSONObject(decrypted)
      CPanelConfig(
        apiBaseUrl = j.optString("apiBaseUrl", ""),
        dbHost = j.optString("dbHost", "localhost"),
        dbName = j.optString("dbName", ""),
        dbUser = j.optString("dbUser", ""),
        dbPassword = j.optString("dbPassword", ""),
        apiSecret = j.optString("apiSecret", "").ifBlank { CryptoManager.generateSecureSecret(24) },
        hmacEnabled = j.optBoolean("hmacEnabled", true),
        e2eeEnabled = j.optBoolean("e2eeEnabled", true),
        maintenanceMode = j.optBoolean("maintenanceMode", false),
        pollingIntervalMs = j.optInt("pollingIntervalMs", 1800).coerceIn(800, 10000),
        lastTestStatus = j.optString("lastTestStatus", "تنظیم نشده"),
        lastTestLatencyMs = j.optLong("lastTestLatencyMs", -1L),
        isConnected = j.optBoolean("isConnected", false),
      )
    } catch (_: Throwable) {
      CPanelConfig(apiSecret = CryptoManager.generateSecureSecret(24))
    }
  }

  // --- User Accounts (Username + Password, zero phone/email) ---

  private data class StoredUserRecord(
    val username: String,
    val displayName: String,
    val saltHex: String,
    val passwordHashHex: String,
    val avatarColorIndex: Int,
    val totalScore: Int,
    val wins: Int,
    val gamesPlayed: Int,
    val favoriteGame: String,
  )

  private fun loadAllUsersMap(): MutableMap<String, StoredUserRecord> {
    val raw = getDecrypted(KEY_USERS_DB) ?: return mutableMapOf()
    val map = mutableMapOf<String, StoredUserRecord>()
    try {
      val arr = JSONArray(raw)
      for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        val uname = o.getString("username")
        map[uname.lowercase()] =
          StoredUserRecord(
            username = uname,
            displayName = o.optString("displayName", uname),
            saltHex = o.getString("saltHex"),
            passwordHashHex = o.getString("passwordHashHex"),
            avatarColorIndex = o.optInt("avatarColorIndex", 0),
            totalScore = o.optInt("totalScore", 0),
            wins = o.optInt("wins", 0),
            gamesPlayed = o.optInt("gamesPlayed", 0),
            favoriteGame = o.optString("favoriteGame", GameType.LUDO.id),
          )
      }
    } catch (_: Throwable) {
      // Ignore corrupt entry
    }
    return map
  }

  private fun saveAllUsersMap(map: Map<String, StoredUserRecord>) {
    val arr = JSONArray()
    map.values.forEach { u ->
      arr.put(
        JSONObject().apply {
          put("username", u.username)
          put("displayName", u.displayName)
          put("saltHex", u.saltHex)
          put("passwordHashHex", u.passwordHashHex)
          put("avatarColorIndex", u.avatarColorIndex)
          put("totalScore", u.totalScore)
          put("wins", u.wins)
          put("gamesPlayed", u.gamesPlayed)
          put("favoriteGame", u.favoriteGame)
        }
      )
    }
    putEncrypted(KEY_USERS_DB, arr.toString())
  }

  fun registerLocalUser(
    username: String,
    password: String,
    displayName: String,
    avatarColorIndex: Int,
  ): Result<UserAccount> {
    val cleanUser = username.trim()
    val users = loadAllUsersMap()
    if (users.containsKey(cleanUser.lowercase())) {
      return Result.failure(IllegalArgumentException("این نام کاربری قبلاً ثبت شده است"))
    }
    val salt = CryptoManager.generateSaltHex()
    val hash = CryptoManager.hashPasswordPbkdf2(password, salt)
    val record =
      StoredUserRecord(
        username = cleanUser,
        displayName = displayName.trim().ifBlank { cleanUser },
        saltHex = salt,
        passwordHashHex = hash,
        avatarColorIndex = avatarColorIndex,
        totalScore = 0,
        wins = 0,
        gamesPlayed = 0,
        favoriteGame = GameType.LUDO.id,
      )
    users[cleanUser.lowercase()] = record
    saveAllUsersMap(users)
    val account =
      UserAccount(
        username = record.username,
        displayName = record.displayName,
        avatarColorIndex = record.avatarColorIndex,
        totalScore = 0,
        wins = 0,
        gamesPlayed = 0,
        authToken = CryptoManager.generateSecureSecret(20),
      )
    saveSession(account)
    return Result.success(account)
  }

  fun loginLocalUser(username: String, password: String): Result<UserAccount> {
    val cleanUser = username.trim()
    val users = loadAllUsersMap()
    val record =
      users[cleanUser.lowercase()]
        ?: return Result.failure(IllegalArgumentException("نام کاربری یا رمز عبور اشتباه است"))
    if (!CryptoManager.verifyPasswordPbkdf2(password, record.saltHex, record.passwordHashHex)) {
      return Result.failure(IllegalArgumentException("نام کاربری یا رمز عبور اشتباه است"))
    }
    val account =
      UserAccount(
        username = record.username,
        displayName = record.displayName,
        avatarColorIndex = record.avatarColorIndex,
        totalScore = record.totalScore,
        wins = record.wins,
        gamesPlayed = record.gamesPlayed,
        authToken = CryptoManager.generateSecureSecret(20),
      )
    saveSession(account)
    return Result.success(account)
  }

  fun saveSession(account: UserAccount?) {
    if (account == null) {
      prefs.edit().remove(KEY_SESSION).apply()
      return
    }
    val j =
      JSONObject().apply {
        put("username", account.username)
        put("displayName", account.displayName)
        put("avatarColorIndex", account.avatarColorIndex)
        put("totalScore", account.totalScore)
        put("wins", account.wins)
        put("gamesPlayed", account.gamesPlayed)
        put("authToken", account.authToken)
      }
    putEncrypted(KEY_SESSION, j.toString())
  }

  fun loadSession(): UserAccount? {
    val raw = getDecrypted(KEY_SESSION) ?: return null
    return try {
      val j = JSONObject(raw)
      UserAccount(
        username = j.getString("username"),
        displayName = j.optString("displayName", j.getString("username")),
        avatarColorIndex = j.optInt("avatarColorIndex", 0),
        totalScore = j.optInt("totalScore", 0),
        wins = j.optInt("wins", 0),
        gamesPlayed = j.optInt("gamesPlayed", 0),
        authToken = j.optString("authToken", ""),
      )
    } catch (_: Throwable) {
      null
    }
  }

  fun updateUserStats(username: String, deltaScore: Int, didWin: Boolean, gameType: GameType): UserAccount? {
    val users = loadAllUsersMap()
    val key = username.lowercase()
    val current = users[key]
    val updated =
      if (current != null) {
        val next =
          current.copy(
            totalScore = (current.totalScore + deltaScore).coerceAtLeast(0),
            wins = current.wins + if (didWin) 1 else 0,
            gamesPlayed = current.gamesPlayed + 1,
            favoriteGame = gameType.id,
          )
        users[key] = next
        saveAllUsersMap(users)
        UserAccount(
          username = next.username,
          displayName = next.displayName,
          avatarColorIndex = next.avatarColorIndex,
          totalScore = next.totalScore,
          wins = next.wins,
          gamesPlayed = next.gamesPlayed,
          authToken = loadSession()?.authToken ?: "",
        )
      } else {
        loadSession()?.let { sess ->
          val next =
            sess.copy(
              totalScore = (sess.totalScore + deltaScore).coerceAtLeast(0),
              wins = sess.wins + if (didWin) 1 else 0,
              gamesPlayed = sess.gamesPlayed + 1,
            )
          saveSession(next)
          next
        }
      }
    if (updated != null) {
      saveSession(updated)
    }
    return updated
  }

  fun getLocalLeaderboard(currentUsername: String?): List<LeaderboardEntry> {
    val users = loadAllUsersMap().values.toList()
    val sorted = users.sortedWith(compareByDescending<StoredUserRecord> { it.totalScore }.thenByDescending { it.wins })
    return sorted.mapIndexed { idx, u ->
      LeaderboardEntry(
        rank = idx + 1,
        username = u.username,
        displayName = u.displayName,
        avatarColorIndex = u.avatarColorIndex,
        totalScore = u.totalScore,
        wins = u.wins,
        gamesPlayed = u.gamesPlayed,
        favoriteGame = GameType.entries.firstOrNull { it.id == u.favoriteGame } ?: GameType.LUDO,
        isCurrentUser = currentUsername != null && u.username.equals(currentUsername, ignoreCase = true),
      )
    }
  }

  // --- End-to-end encryption keys (one random key per chat group, device-only) ---

  fun saveGroupKey(groupId: String, key: ByteArray) {
    val obj =
      try {
        JSONObject(getDecrypted(KEY_GROUP_KEYS) ?: "{}")
      } catch (_: Throwable) {
        JSONObject()
      }
    obj.put(groupId, CryptoManager.encodeKey(key))
    putEncrypted(KEY_GROUP_KEYS, obj.toString())
  }

  /** Removes the encryption key and the cached messages of a group from this device. */
  fun removeGroupLocalData(groupId: String) {
    try {
      val obj = JSONObject(getDecrypted(KEY_GROUP_KEYS) ?: "{}")
      if (obj.has(groupId)) {
        obj.remove(groupId)
        putEncrypted(KEY_GROUP_KEYS, obj.toString())
      }
    } catch (_: Throwable) {}
    prefs.edit().remove("${KEY_CHAT_MESSAGES_PREFIX}$groupId").apply()
  }

  fun loadGroupKey(groupId: String): ByteArray? {
    val raw = getDecrypted(KEY_GROUP_KEYS) ?: return null
    return try {
      CryptoManager.decodeKey(JSONObject(raw).optString(groupId, ""))
    } catch (_: Throwable) {
      null
    }
  }

  // --- Server key backup support ---

  fun saveWrapKey(key: ByteArray?) {
    if (key == null) prefs.edit().remove(KEY_WRAP).apply()
    else putEncrypted(KEY_WRAP, CryptoManager.encodeBytes(key))
  }

  fun loadWrapKey(): ByteArray? = getDecrypted(KEY_WRAP)?.let { CryptoManager.decodeBytes(it) }

  /** My ECDH identity: Pair(public X509, private PKCS8), base64url. */
  fun loadIdentity(): Pair<String, String>? {
    val raw = getDecrypted(KEY_IDENTITY) ?: return null
    return try {
      val o = JSONObject(raw)
      val pub = o.optString("pub", "")
      val priv = o.optString("priv", "")
      if (pub.isBlank() || priv.isBlank()) null else pub to priv
    } catch (_: Throwable) {
      null
    }
  }

  fun saveIdentity(pub: String, priv: String) {
    putEncrypted(KEY_IDENTITY, JSONObject().put("pub", pub).put("priv", priv).toString())
  }

  /** All keys that must survive a reinstall: group keys + my identity. */
  fun exportKeyBundle(): String {
    val groups =
      try {
        JSONObject(getDecrypted(KEY_GROUP_KEYS) ?: "{}")
      } catch (_: Throwable) {
        JSONObject()
      }
    val out = JSONObject().put("v", 1).put("groups", groups)
    loadIdentity()?.let { out.put("identity", JSONObject().put("pub", it.first).put("priv", it.second)) }
    return out.toString()
  }

  /** Merges a bundle from the server into this device (existing local keys win). */
  fun importKeyBundle(json: String) {
    try {
      val src = JSONObject(json)
      val local =
        try {
          JSONObject(getDecrypted(KEY_GROUP_KEYS) ?: "{}")
        } catch (_: Throwable) {
          JSONObject()
        }
      val groups = src.optJSONObject("groups")
      var changed = false
      if (groups != null) {
        for (id in groups.keys()) {
          if (!local.has(id) && CryptoManager.decodeKey(groups.optString(id, "")) != null) {
            local.put(id, groups.getString(id))
            changed = true
          }
        }
      }
      if (changed) putEncrypted(KEY_GROUP_KEYS, local.toString())
      val ident = src.optJSONObject("identity")
      if (ident != null && loadIdentity() == null) {
        val pub = ident.optString("pub", "")
        val priv = ident.optString("priv", "")
        if (pub.isNotBlank() && priv.isNotBlank()) saveIdentity(pub, priv)
      }
    } catch (_: Throwable) {}
  }

  // --- Device-local admin gate: first use sets the password, later uses verify it ---

  fun adminAuth(password: String, now: Long = System.currentTimeMillis()): AdminAuthResult {
    val raw = getDecrypted(KEY_ADMIN)
    if (raw == null) {
      if (password.length < 10) return AdminAuthResult.TooWeak
      val salt = CryptoManager.generateSaltHex(16)
      val hash = CryptoManager.hashPasswordPbkdf2(password, salt, ADMIN_ITERATIONS)
      putEncrypted(
        KEY_ADMIN,
        JSONObject()
          .put("salt", salt)
          .put("hash", hash)
          .put("fails", 0)
          .put("lockedUntil", 0L)
          .toString(),
      )
      return AdminAuthResult.Created
    }
    val rec =
      try {
        JSONObject(raw)
      } catch (_: Throwable) {
        return AdminAuthResult.Wrong
      }
    val lockedUntil = rec.optLong("lockedUntil", 0L)
    if (now < lockedUntil) return AdminAuthResult.Locked((lockedUntil - now + 999L) / 1000L)
    val ok =
      CryptoManager.verifyPasswordPbkdf2(
        password,
        rec.optString("salt", "00"),
        rec.optString("hash", "00"),
        ADMIN_ITERATIONS,
      )
    if (ok) {
      rec.put("fails", 0)
      rec.put("lockedUntil", 0L)
      putEncrypted(KEY_ADMIN, rec.toString())
      return AdminAuthResult.Granted
    }
    val fails = rec.optInt("fails", 0) + 1
    rec.put("fails", fails)
    if (fails >= 5) {
      val waitSec = minOf(900L, 30L shl minOf(fails - 5, 5))
      rec.put("lockedUntil", now + waitSec * 1000L)
    }
    putEncrypted(KEY_ADMIN, rec.toString())
    return AdminAuthResult.Wrong
  }

  // --- Encrypted Chat Groups & Messages ---

  fun loadChatGroups(): List<ChatGroup> {
    val raw = getDecrypted(KEY_CHAT_GROUPS) ?: return emptyList()
    return try {
      val arr = JSONArray(raw)
      buildList {
        for (i in 0 until arr.length()) {
          val o = arr.getJSONObject(i)
          val memArr = o.optJSONArray("members") ?: JSONArray()
          val members = buildList {
            for (m in 0 until memArr.length()) add(memArr.getString(m))
          }
          add(
            ChatGroup(
              id = o.getString("id"),
              name = o.getString("name"),
              inviteCode = o.getString("inviteCode"),
              ownerUsername = o.optString("ownerUsername", ""),
              members = members,
              lastMessagePreview = o.optString("lastMessagePreview", ""),
              lastMessageTime = o.optLong("lastMessageTime", 0L),
              shareCode = o.optString("shareCode", ""),
              description = o.optString("description", ""),
              dmOrigin = o.optString("dmOrigin", ""),
              memberColors =
                o.optJSONObject("memberColors")?.let { mc ->
                  buildMap { mc.keys().forEach { k -> put(k, mc.optInt(k, 0)) } }
                } ?: emptyMap(),
            )
          )
        }
      }
    } catch (_: Throwable) {
      emptyList()
    }
  }

  fun saveChatGroups(groups: List<ChatGroup>) {
    val arr = JSONArray()
    groups.forEach { g ->
      arr.put(
        JSONObject().apply {
          put("id", g.id)
          put("name", g.name)
          put("inviteCode", g.inviteCode)
          put("ownerUsername", g.ownerUsername)
          put("members", JSONArray(g.members))
          put("lastMessagePreview", g.lastMessagePreview)
          put("lastMessageTime", g.lastMessageTime)
          put("shareCode", g.shareCode)
          put("description", g.description)
          put("dmOrigin", g.dmOrigin)
          put("memberColors", JSONObject().apply { g.memberColors.forEach { (k, v) -> put(k, v) } })
        }
      )
    }
    putEncrypted(KEY_CHAT_GROUPS, arr.toString())
  }

  fun loadChatMessages(groupId: String): List<ChatMessage> {
    val raw = getDecrypted("${KEY_CHAT_MESSAGES_PREFIX}$groupId") ?: return emptyList()
    return try {
      val arr = JSONArray(raw)
      buildList {
        for (i in 0 until arr.length()) {
          val o = arr.getJSONObject(i)
          val invObj = o.optJSONObject("gameInvite")
          val invite =
            if (invObj != null) {
              GameInvite(
                gameType =
                  GameType.entries.firstOrNull { it.id == invObj.optString("gameType") }
                    ?: GameType.LUDO,
                roomCode = invObj.optString("roomCode", ""),
                hostUsername = invObj.optString("hostUsername", ""),
              )
            } else {
              null
            }
          add(
            ChatMessage(
              id = o.getString("id"),
              groupId = o.getString("groupId"),
              senderUsername = o.getString("senderUsername"),
              senderColorIndex = o.optInt("senderColorIndex", 0),
              text = o.optString("text", ""),
              timestamp = o.optLong("timestamp", 0L),
              gameInvite = invite,
              hasImage = o.optBoolean("hasImage", false),
              replyToId = o.optString("replyToId", "").ifBlank { null },
              replyToSender = o.optString("replyToSender", "").ifBlank { null },
              replyToText = o.optString("replyToText", "").ifBlank { null },
              sendState = o.optInt("sendState", SendState.SENT),
              edited = o.optBoolean("edited", false),
            )
          )
        }
      }
    } catch (_: Throwable) {
      emptyList()
    }
  }

  fun saveChatMessages(groupId: String, messages: List<ChatMessage>) {
    val arr = JSONArray()
    messages.takeLast(150).forEach { msg ->
      arr.put(
        JSONObject().apply {
          put("id", msg.id)
          put("groupId", msg.groupId)
          put("senderUsername", msg.senderUsername)
          put("senderColorIndex", msg.senderColorIndex)
          put("text", msg.text)
          put("timestamp", msg.timestamp)
          put("hasImage", msg.hasImage)
          msg.replyToId?.let { put("replyToId", it) }
          msg.replyToSender?.let { put("replyToSender", it) }
          msg.replyToText?.let { put("replyToText", it) }
          put("sendState", msg.sendState)
          if (msg.edited) put("edited", true)
          msg.gameInvite?.let { inv ->
            put(
              "gameInvite",
              JSONObject().apply {
                put("gameType", inv.gameType.id)
                put("roomCode", inv.roomCode)
                put("hostUsername", inv.hostUsername)
              },
            )
          }
        }
      )
    }
    putEncrypted("${KEY_CHAT_MESSAGES_PREFIX}$groupId", arr.toString())
  }

  companion object {
    private const val KEY_CPANEL_CONFIG = "cpanel_config"
    private const val KEY_USERS_DB = "users_db"
    private const val KEY_SESSION = "active_session"
    private const val KEY_CHAT_GROUPS = "chat_groups"
    private const val KEY_CHAT_MESSAGES_PREFIX = "chat_msgs_"
    private const val KEY_GROUP_KEYS = "group_keys"
    private const val KEY_WRAP = "key_wrap"
    private const val KEY_IDENTITY = "ecdh_identity"
    private const val KEY_ADMIN = "admin_gate"
    private const val ADMIN_ITERATIONS = 210_000
  }
}
