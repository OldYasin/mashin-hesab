package com.example.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Lightweight, zero-dependency cryptographic engine using:
 * - Android KeyStore AES-256-GCM for local vault confidentiality & integrity
 * - PBKDF2-HMAC-SHA256 for user password hashing
 * - HMAC-SHA256 + Nonce for cPanel API request authentication
 * - Transport AES-256-GCM compatible with PHP openssl_encrypt('aes-256-gcm')
 */
object CryptoManager {

  private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
  private const val KEY_ALIAS = "baziland_vault_aes256_v1"
  private const val AES_GCM_TRANSFORMATION = "AES/GCM/NoPadding"
  private const val GCM_IV_LENGTH = 12
  private const val GCM_TAG_BITS = 128
  private const val PBKDF2_ITERATIONS = 12000

  /** Typing this as the username on the login screen opens the (device-local) admin gate. Not a secret. */
  const val ADMIN_TRIGGER_USER = "Yas2829+_!\"464646JsjI"
  /**
   * First-setup password: only works while the app is NOT connected to the server, so the admin
   * panel can be opened once to enter the server address. Only a slow salted hash is stored here
   * (never the password). After the server is connected, only the server-registered password works.
   */
  private const val BOOTSTRAP_SALT = "effbfaa2b40f1ae2f9b5245a11a41caa"
  private const val BOOTSTRAP_HASH = "dcd6e0978e41f52ee6cf2d5c88e1f2e59e29d60a1d514ac27972a83e925fd65e"
  private const val BOOTSTRAP_ITERATIONS = 210_000

  fun verifyBootstrapAdminPassword(password: String): Boolean =
    verifyPasswordPbkdf2(password, BOOTSTRAP_SALT, BOOTSTRAP_HASH, BOOTSTRAP_ITERATIONS)

  private const val LOGIN_VERIFIER_ITERATIONS = 100_000

  private val secureRandom = SecureRandom()

  fun isAdminTrigger(username: String): Boolean =
    username.trim() == ADMIN_TRIGGER_USER

  fun generateSaltHex(byteCount: Int = 16): String {
    val bytes = ByteArray(byteCount)
    secureRandom.nextBytes(bytes)
    return bytesToHex(bytes)
  }

  fun generateSecureSecret(byteCount: Int = 24): String {
    val bytes = ByteArray(byteCount)
    secureRandom.nextBytes(bytes)
    return encodeBase64(bytes, urlSafe = true)
  }

  fun hashPasswordPbkdf2(
    password: String,
    saltHex: String,
    iterations: Int = PBKDF2_ITERATIONS,
  ): String {
    val salt = hexToBytes(saltHex)
    val spec = PBEKeySpec(password.toCharArray(), salt, iterations, 256)
    val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
    val hash = factory.generateSecret(spec).encoded
    spec.clearPassword()
    return bytesToHex(hash)
  }

  fun verifyPasswordPbkdf2(
    password: String,
    saltHex: String,
    expectedHashHex: String,
    iterations: Int = PBKDF2_ITERATIONS,
  ): Boolean {
    val actual = hexToBytes(hashPasswordPbkdf2(password, saltHex, iterations))
    val expected = hexToBytes(expectedHashHex)
    return MessageDigest.isEqual(actual, expected)
  }

  /**
   * Slow password verifier sent to the server instead of the password itself (the server stores
   * only a hash of this value). Deterministic per username so login works from any device.
   */
  fun deriveLoginVerifier(username: String, password: String): String {
    val salt = "bazirox-login-v1:${username.trim().lowercase()}".toByteArray(StandardCharsets.UTF_8)
    val spec = PBEKeySpec(password.toCharArray(), salt, LOGIN_VERIFIER_ITERATIONS, 256)
    val hash = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    spec.clearPassword()
    return bytesToHex(hash)
  }

  // --- End-to-end encryption for chats: keys live only on the phones, never on the server ---

  fun generateGroupKey(): ByteArray {
    val key = ByteArray(32)
    secureRandom.nextBytes(key)
    return key
  }

  /** Key of a private chat, derived from the key of a group both people are in (never sent anywhere). */
  fun deriveDmKey(originKey: ByteArray, dmId: String): ByteArray {
    val mac = Mac.getInstance("HmacSHA256")
    mac.init(SecretKeySpec(originKey, "HmacSHA256"))
    return mac.doFinal(("bazirox-dm-v1|" + dmId).toByteArray(StandardCharsets.UTF_8))
  }

  // --- Key backup on the server: keys are wrapped with a key derived from the user's password, so
  //     the server only ever stores ciphertext it cannot read. ---

  private const val KEYWRAP_ITERATIONS = 100_000

  /** Wrapping key (32 bytes) derived from the password; differs from the login verifier. */
  fun deriveKeyWrapKey(username: String, password: String): ByteArray {
    val salt = "bazirox-keywrap-v1:${username.trim().lowercase()}".toByteArray(StandardCharsets.UTF_8)
    val spec = PBEKeySpec(password.toCharArray(), salt, KEYWRAP_ITERATIONS, 256)
    val out = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    spec.clearPassword()
    return out
  }

  /** Returns base64url text safe to upload (no "e1:" prefix, only URL-safe characters). */
  fun wrapBackup(plain: String, wrapKey: ByteArray): String =
    e2eeEncrypt(plain, wrapKey, "bazirox-keybackup-v1").removePrefix("e1:")

  fun unwrapBackup(blob: String, wrapKey: ByteArray): String? =
    e2eeDecrypt("e1:$blob", wrapKey, "bazirox-keybackup-v1")

  fun encodeBytes(data: ByteArray): String = encodeBase64(data, urlSafe = true)

  fun decodeBytes(text: String): ByteArray? = decodeBase64(text)

  // --- Private chats between people who share no group: ECDH (P-256) identity keys ---

  /** Returns Pair(publicKeyX509, privateKeyPkcs8), both base64url. */
  fun generateIdentityKeyPair(): Pair<String, String> {
    val gen = java.security.KeyPairGenerator.getInstance("EC")
    gen.initialize(java.security.spec.ECGenParameterSpec("secp256r1"), secureRandom)
    val kp = gen.generateKeyPair()
    return encodeBase64(kp.public.encoded, urlSafe = true) to encodeBase64(kp.private.encoded, urlSafe = true)
  }

  /** Chat key of a private chat from my private key + their public key (same on both sides). */
  fun deriveEcdhDmKey(myPrivatePkcs8: String, theirPublicX509: String, dmId: String): ByteArray? =
    deriveEcdhSharedKey(myPrivatePkcs8, theirPublicX509, "bazirox-dm-ecdh-v1|$dmId")

  /** Envelope key for securely sharing a group key with another user via ECDH. */
  fun deriveGroupEnvelopeKey(myPrivatePkcs8: String, theirPublicX509: String, groupId: String): ByteArray? =
    deriveEcdhSharedKey(myPrivatePkcs8, theirPublicX509, "bazirox-gkey-ecdh-v1|$groupId")

  private fun deriveEcdhSharedKey(myPrivatePkcs8: String, theirPublicX509: String, context: String): ByteArray? =
    try {
      val kf = java.security.KeyFactory.getInstance("EC")
      val priv = kf.generatePrivate(java.security.spec.PKCS8EncodedKeySpec(decodeBase64(myPrivatePkcs8)))
      val pub = kf.generatePublic(java.security.spec.X509EncodedKeySpec(decodeBase64(theirPublicX509)))
      val ka = javax.crypto.KeyAgreement.getInstance("ECDH")
      ka.init(priv)
      ka.doPhase(pub, true)
      val shared = ka.generateSecret()
      val mac = Mac.getInstance("HmacSHA256")
      mac.init(SecretKeySpec(shared, "HmacSHA256"))
      mac.doFinal(context.toByteArray(StandardCharsets.UTF_8))
    } catch (_: Throwable) {
      null
    }

  fun encodeKey(key: ByteArray): String = encodeBase64(key, urlSafe = true)

  fun decodeKey(encoded: String): ByteArray? {
    val raw = decodeBase64(encoded) ?: return null
    return if (raw.size == 32) raw else null
  }

  /** AES-256-GCM. Output: "e1:" + base64(iv[12] || ciphertext || tag). [aad] binds it to its context. */
  fun e2eeEncryptBytes(plain: ByteArray, key: ByteArray, aad: String): String {
    val iv = ByteArray(GCM_IV_LENGTH)
    secureRandom.nextBytes(iv)
    val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
    cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(GCM_TAG_BITS, iv))
    cipher.updateAAD(aad.toByteArray(StandardCharsets.UTF_8))
    val ct = cipher.doFinal(plain)
    return "e1:" + encodeBase64(iv + ct)
  }

  fun e2eeDecryptBytes(encoded: String, key: ByteArray, aad: String): ByteArray? {
    return try {
      if (!encoded.startsWith("e1:")) return null
      val raw = decodeBase64(encoded.removePrefix("e1:")) ?: return null
      if (raw.size <= GCM_IV_LENGTH + 16) return null
      val iv = raw.copyOfRange(0, GCM_IV_LENGTH)
      val ct = raw.copyOfRange(GCM_IV_LENGTH, raw.size)
      val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
      cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(GCM_TAG_BITS, iv))
      cipher.updateAAD(aad.toByteArray(StandardCharsets.UTF_8))
      cipher.doFinal(ct)
    } catch (_: Throwable) {
      null
    }
  }

  fun e2eeEncrypt(plaintext: String, key: ByteArray, aad: String): String =
    e2eeEncryptBytes(plaintext.toByteArray(StandardCharsets.UTF_8), key, aad)

  fun e2eeDecrypt(encoded: String, key: ByteArray, aad: String): String? =
    e2eeDecryptBytes(encoded, key, aad)?.let { String(it, StandardCharsets.UTF_8) }

  fun hmacSha256Hex(data: String, secret: String): String {
    val mac = Mac.getInstance("HmacSHA256")
    val keySpec = SecretKeySpec(secret.toByteArray(StandardCharsets.UTF_8), "HmacSHA256")
    mac.init(keySpec)
    return bytesToHex(mac.doFinal(data.toByteArray(StandardCharsets.UTF_8)))
  }

  /** Encrypts sensitive local data using hardware-backed Android KeyStore AES-256-GCM. */
  fun encryptLocal(plaintext: String): String {
    return try {
      val key = getOrCreateKeyStoreKey()
      val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
      cipher.init(Cipher.ENCRYPT_MODE, key)
      val iv = cipher.iv
      val ciphertext = cipher.doFinal(plaintext.toByteArray(StandardCharsets.UTF_8))
      val combined = ByteArray(iv.size + ciphertext.size)
      System.arraycopy(iv, 0, combined, 0, iv.size)
      System.arraycopy(ciphertext, 0, combined, iv.size, ciphertext.size)
      "v1:" + encodeBase64(combined)
    } catch (_: Throwable) {
      val fallbackKey = deriveTransportKey("baziland_local_fallback_key")
      "v0:" + encryptWithAesKey(plaintext, fallbackKey)
    }
  }

  /** Decrypts local data encrypted by [encryptLocal]. */
  fun decryptLocal(encoded: String): String? {
    return try {
      when {
        encoded.startsWith("v1:") -> {
          val raw = decodeBase64(encoded.removePrefix("v1:")) ?: return null
          if (raw.size <= GCM_IV_LENGTH) return null
          val iv = raw.copyOfRange(0, GCM_IV_LENGTH)
          val ciphertext = raw.copyOfRange(GCM_IV_LENGTH, raw.size)
          val key = getOrCreateKeyStoreKey()
          val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
          cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
          String(cipher.doFinal(ciphertext), StandardCharsets.UTF_8)
        }
        encoded.startsWith("v0:") -> {
          val fallbackKey = deriveTransportKey("baziland_local_fallback_key")
          decryptWithAesKey(encoded.removePrefix("v0:"), fallbackKey)
        }
        else -> null
      }
    } catch (_: Throwable) {
      null
    }
  }

  /**
   * Encrypts JSON payloads for cPanel transit using AES-256-GCM derived from API secret.
   * Format: base64(iv[12] || tag[16] || ciphertext) -> matches PHP openssl_decrypt/encrypt cleanly.
   */
  fun encryptTransportPayload(plaintext: String, apiSecret: String): String {
    val key = deriveTransportKey(apiSecret)
    return encryptWithAesKey(plaintext, key)
  }

  fun decryptTransportPayload(encoded: String, apiSecret: String): String? {
    val key = deriveTransportKey(apiSecret)
    return decryptWithAesKey(encoded, key)
  }

  private fun encryptWithAesKey(plaintext: String, key: SecretKeySpec): String {
    val iv = ByteArray(GCM_IV_LENGTH)
    secureRandom.nextBytes(iv)
    val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
    cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
    val encryptedAndTag = cipher.doFinal(plaintext.toByteArray(StandardCharsets.UTF_8))
    val tagOffset = encryptedAndTag.size - 16
    val ciphertext = encryptedAndTag.copyOfRange(0, tagOffset)
    val tag = encryptedAndTag.copyOfRange(tagOffset, encryptedAndTag.size)
    val combined = ByteArray(GCM_IV_LENGTH + 16 + ciphertext.size)
    System.arraycopy(iv, 0, combined, 0, GCM_IV_LENGTH)
    System.arraycopy(tag, 0, combined, GCM_IV_LENGTH, 16)
    System.arraycopy(ciphertext, 0, combined, GCM_IV_LENGTH + 16, ciphertext.size)
    return encodeBase64(combined)
  }

  private fun decryptWithAesKey(encoded: String, key: SecretKeySpec): String? {
    return try {
      val raw = decodeBase64(encoded) ?: return null
      if (raw.size <= GCM_IV_LENGTH + 16) return null
      val iv = raw.copyOfRange(0, GCM_IV_LENGTH)
      val tag = raw.copyOfRange(GCM_IV_LENGTH, GCM_IV_LENGTH + 16)
      val ciphertext = raw.copyOfRange(GCM_IV_LENGTH + 16, raw.size)
      val combinedCipherAndTag = ByteArray(ciphertext.size + 16)
      System.arraycopy(ciphertext, 0, combinedCipherAndTag, 0, ciphertext.size)
      System.arraycopy(tag, 0, combinedCipherAndTag, ciphertext.size, 16)
      val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
      cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
      String(cipher.doFinal(combinedCipherAndTag), StandardCharsets.UTF_8)
    } catch (_: Throwable) {
      null
    }
  }

  private fun deriveTransportKey(secret: String): SecretKeySpec {
    val hash = sha256Bytes("BaziLand_AES256_Key:$secret")
    return SecretKeySpec(hash, "AES")
  }

  @Volatile private var cachedKeyStoreKey: SecretKey? = null

  private fun getOrCreateKeyStoreKey(): SecretKey {
    cachedKeyStoreKey?.let { return it }
    return synchronized(this) { cachedKeyStoreKey ?: loadOrCreateKeyStoreKey().also { cachedKeyStoreKey = it } }
  }

  private fun loadOrCreateKeyStoreKey(): SecretKey {
    val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
    val existing = keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
    if (existing != null) return existing.secretKey

    val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
    val spec =
      KeyGenParameterSpec.Builder(
          KEY_ALIAS,
          KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
        )
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setKeySize(256)
        .setRandomizedEncryptionRequired(true)
        .build()
    keyGen.init(spec)
    return keyGen.generateKey()
  }

  private fun sha256Bytes(input: String): ByteArray {
    return MessageDigest.getInstance("SHA-256")
      .digest(input.toByteArray(StandardCharsets.UTF_8))
  }

  private fun bytesToHex(bytes: ByteArray): String {
    val sb = StringBuilder(bytes.size * 2)
    for (b in bytes) {
      sb.append(Character.forDigit((b.toInt() shr 4) and 0xF, 16))
      sb.append(Character.forDigit(b.toInt() and 0xF, 16))
    }
    return sb.toString()
  }

  private fun hexToBytes(hex: String): ByteArray {
    val len = hex.length
    val out = ByteArray(len / 2)
    var i = 0
    while (i < len) {
      out[i / 2] =
        ((Character.digit(hex[i], 16) shl 4) + Character.digit(hex[i + 1], 16)).toByte()
      i += 2
    }
    return out
  }

  private const val B64_STD = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  private const val B64_URL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"

  private fun encodeBase64(data: ByteArray, urlSafe: Boolean = false): String {
    val alphabet = if (urlSafe) B64_URL else B64_STD
    val out = StringBuilder(((data.size + 2) / 3) * 4)
    var i = 0
    while (i < data.size) {
      val b0 = data[i].toInt() and 0xFF
      val b1 = if (i + 1 < data.size) data[i + 1].toInt() and 0xFF else -1
      val b2 = if (i + 2 < data.size) data[i + 2].toInt() and 0xFF else -1
      out.append(alphabet[b0 shr 2])
      out.append(alphabet[((b0 and 0x03) shl 4) or (if (b1 >= 0) (b1 shr 4) else 0)])
      if (b1 >= 0) {
        out.append(alphabet[((b1 and 0x0F) shl 2) or (if (b2 >= 0) (b2 shr 6) else 0)])
      } else if (!urlSafe) {
        out.append('=')
      }
      if (b2 >= 0) {
        out.append(alphabet[b2 and 0x3F])
      } else if (!urlSafe) {
        out.append('=')
      }
      i += 3
    }
    return out.toString()
  }

  private fun decodeBase64(input: String): ByteArray? {
    val clean = input.trim().replace('-', '+').replace('_', '/')
    if (clean.isEmpty()) return ByteArray(0)
    val out = ArrayList<Byte>((clean.length * 3) / 4)
    var buf = 0
    var bits = 0
    for (ch in clean) {
      if (ch == '=') break
      val v = B64_STD.indexOf(ch)
      if (v < 0) return null
      buf = (buf shl 6) or v
      bits += 6
      if (bits >= 8) {
        bits -= 8
        out.add(((buf shr bits) and 0xFF).toByte())
      }
    }
    return out.toByteArray()
  }
}
