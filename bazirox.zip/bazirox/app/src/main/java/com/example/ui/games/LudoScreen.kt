package com.example.ui.games

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.GameType
import com.example.data.OnlineRoom
import com.example.data.PlayMode
import com.example.ui.components.AnimatedGameDice
import com.example.ui.components.BaziIcons
import com.example.ui.components.GameTopBar
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.WinCelebrationBanner
import com.example.ui.components.auroraGamingBackdrop
import com.example.ui.components.drawGlossyToken
import com.example.ui.components.playerColorFor
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlayerBlue
import com.example.ui.theme.PlayerGreen
import com.example.ui.theme.PlayerRed
import com.example.ui.theme.PlayerYellow
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val LudoOuterTrack: List<Pair<Int, Int>> =
  listOf(
    1 to 6, 2 to 6, 3 to 6, 4 to 6, 5 to 6,
    6 to 5, 6 to 4, 6 to 3, 6 to 2, 6 to 1, 6 to 0,
    7 to 0,
    8 to 0, 8 to 1, 8 to 2, 8 to 3, 8 to 4, 8 to 5,
    9 to 6, 10 to 6, 11 to 6, 12 to 6, 13 to 6, 14 to 6,
    14 to 7,
    14 to 8, 13 to 8, 12 to 8, 11 to 8, 10 to 8, 9 to 8,
    8 to 9, 8 to 10, 8 to 11, 8 to 12, 8 to 13, 8 to 14,
    7 to 14,
    6 to 14, 6 to 13, 6 to 12, 6 to 11, 6 to 10, 6 to 9,
    5 to 8, 4 to 8, 3 to 8, 2 to 8, 1 to 8, 0 to 8,
    0 to 7,
    0 to 6,
  )

internal val LudoStartOffsets = listOf(0, 13, 26, 39)
internal val LudoSafeTrackIndices = setOf(0, 8, 13, 21, 26, 34, 39, 47)

private val HomeStretchCoords: List<List<Pair<Int, Int>>> =
  listOf(
    listOf(1 to 7, 2 to 7, 3 to 7, 4 to 7, 5 to 7, 6 to 7),
    listOf(7 to 1, 7 to 2, 7 to 3, 7 to 4, 7 to 5, 7 to 6),
    listOf(13 to 7, 12 to 7, 11 to 7, 10 to 7, 9 to 7, 8 to 7),
    listOf(7 to 13, 7 to 12, 7 to 11, 7 to 10, 7 to 9, 7 to 8),
  )

private val YardCoords: List<List<Pair<Float, Float>>> =
  listOf(
    listOf(2.0f to 2.0f, 4.0f to 2.0f, 2.0f to 4.0f, 4.0f to 4.0f),
    listOf(11.0f to 2.0f, 13.0f to 2.0f, 11.0f to 4.0f, 13.0f to 4.0f),
    listOf(11.0f to 11.0f, 13.0f to 11.0f, 11.0f to 13.0f, 13.0f to 13.0f),
    listOf(2.0f to 11.0f, 4.0f to 11.0f, 2.0f to 13.0f, 4.0f to 13.0f),
  )

@Composable
fun LudoScreen(
  playMode: PlayMode,
  playerCount: Int,
  room: OnlineRoom?,
  currentUsername: String,
  onPushOnlineState: (String, String) -> Unit,
  onRecordResult: (Boolean, Int) -> Unit,
  onBack: () -> Unit,
) {
  BackHandler(onBack = onBack)

  val count = if (playMode == PlayMode.ONLINE_ROOM) 2 else playerCount.coerceIn(2, 4)
  val activePlayerIds =
    remember(count) {
      when (count) {
        2 -> listOf(0, 2)
        3 -> listOf(0, 1, 2)
        else -> listOf(0, 1, 2, 3)
      }
    }

  var tokens by remember(count) { mutableStateOf(List(4) { List(4) { -1 } }) }
  var turnSlot by remember { mutableIntStateOf(0) }
  var diceValue by remember { mutableIntStateOf(6) }
  var hasRolled by remember { mutableStateOf(false) }
  var isRolling by remember { mutableStateOf(false) }
  var winnerPlayerId by remember { mutableIntStateOf(-1) }
  var statusBanner by remember { mutableStateOf("نوبت قرمز! تاس بیندازید") }
  var recorded by remember { mutableStateOf(false) }
  var roundId by remember { mutableIntStateOf(0) }
  val scope = rememberCoroutineScope()

  fun currentPid(): Int = activePlayerIds[turnSlot.mod(activePlayerIds.size)]
  val currentPlayerId = currentPid()

  // Halo pulse only runs while a legal move is waiting to be picked. Before, an infinite
  // transition re-recorded the whole board on every frame, even when nothing was highlighted.
  val tokenPulseAnim = remember { Animatable(0f) }
  val needsPulse = hasRolled && !isRolling && winnerPlayerId == -1
  LaunchedEffect(needsPulse) {
    if (needsPulse) {
      while (isActive) {
        tokenPulseAnim.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
        tokenPulseAnim.animateTo(0f, tween(650, easing = FastOutSlowInEasing))
      }
    } else {
      tokenPulseAnim.snapTo(0f)
    }
  }

  // Smooth per-token progress (float) — read only in draw phase, so no recomposition per frame
  val progAnims = remember { List(16) { Animatable(-1f) } }
  LaunchedEffect(tokens) {
    coroutineScope {
      for (pid in 0..3) for (t in 0..3) {
        val target = tokens[pid][t].toFloat()
        val anim = progAnims[pid * 4 + t]
        launch {
          val diff = target - anim.value
          if (diff < 0f || diff == 0f) {
            anim.snapTo(target)
          } else {
            val ms = (diff * 120f).toInt().coerceIn(220, 1000)
            anim.animateTo(target, tween(ms, easing = FastOutSlowInEasing))
          }
        }
      }
    }
  }

  val myOnlineSlot =
    remember(room, currentUsername) {
      if (room == null) 0
      else if (room.hostUsername.equals(currentUsername, ignoreCase = true)) 0 else 1
    }

  LaunchedEffect(room?.version, room?.stateJson) {
    if (playMode == PlayMode.ONLINE_ROOM && room != null && room.stateJson.length > 4) {
      try {
        val j = JSONObject(room.stateJson)
        val tArr = j.optJSONArray("tokens")
        if (tArr != null && tArr.length() == 4) {
          tokens =
            List(4) { p ->
              val pArr = tArr.getJSONArray(p)
              List(4) { t -> pArr.getInt(t) }
            }
          turnSlot = j.optInt("turnSlot", 0)
          diceValue = j.optInt("dice", 6)
          hasRolled = j.optBoolean("hasRolled", false)
          winnerPlayerId = j.optInt("winner", -1)
          statusBanner = j.optString("banner", statusBanner)
        }
      } catch (_: Throwable) {}
    }
  }

  fun playerColorName(pid: Int): String =
    when (pid) {
      0 -> if (playMode == PlayMode.VS_AI) "شما (قرمز)" else "قرمز"
      1 -> if (playMode == PlayMode.VS_AI) "ربات سبز" else "سبز"
      2 -> if (playMode == PlayMode.VS_AI) "ربات طلایی" else "طلایی"
      else -> if (playMode == PlayMode.VS_AI) "ربات آبی" else "آبی"
    }

  fun pushSync() {
    if (playMode == PlayMode.ONLINE_ROOM && room != null) {
      val j =
        JSONObject().apply {
          put("tokens", JSONArray(tokens.map { JSONArray(it) }))
          put("turnSlot", turnSlot)
          put("dice", diceValue)
          put("hasRolled", hasRolled)
          put("winner", winnerPlayerId)
          put("banner", statusBanner)
        }
      onPushOnlineState(j.toString(), if (winnerPlayerId == -1) "playing" else "finished")
    }
  }

  fun resetGame() {
    tokens = List(4) { List(4) { -1 } }
    turnSlot = 0
    diceValue = 6
    hasRolled = false
    isRolling = false
    winnerPlayerId = -1
    recorded = false
    roundId++
    statusBanner = "بازی منچ آماده است! تاس بیندازید"
    pushSync()
  }

  fun executeTokenMove(pid: Int, tokenIdx: Int) {
    if (!hasRolled || winnerPlayerId != -1) return
    val currentProg = tokens[pid][tokenIdx]
    val nextProg =
      when {
        currentProg == -1 && diceValue == 6 -> 0
        currentProg >= 0 && currentProg + diceValue <= 56 -> currentProg + diceValue
        else -> return
      }

    val updated = tokens.map { it.toMutableList() }
    updated[pid][tokenIdx] = nextProg
    var captured = false

    if (nextProg in 0..50) {
      val globalIdx = (LudoStartOffsets[pid] + nextProg) % 52
      if (globalIdx !in LudoSafeTrackIndices) {
        for (otherPid in activePlayerIds) {
          if (otherPid == pid) continue
          for (ot in 0..3) {
            val otherProg = updated[otherPid][ot]
            if (otherProg in 0..50) {
              val otherGlobal = (LudoStartOffsets[otherPid] + otherProg) % 52
              if (otherGlobal == globalIdx) {
                updated[otherPid][ot] = -1
                captured = true
              }
            }
          }
        }
      }
    }

    tokens = updated.map { it.toList() }
    hasRolled = false

    if (updated[pid].all { it == 56 }) {
      winnerPlayerId = pid
      statusBanner = "${playerColorName(pid)} با هر ۴ مهره برنده شد!"
      pushSync()
      return
    }

    val bonusTurn = diceValue == 6 || captured || nextProg == 56
    if (bonusTurn) {
      statusBanner =
        when {
          captured -> "${playerColorName(pid)} مهره حریف را زد! جایزه تاس دوباره"
          nextProg == 56 -> "مهره به خانه رسید! جایزه تاس دوباره"
          else -> "تاس ۶ شد! ${playerColorName(pid)} دوباره تاس می‌اندازد"
        }
    } else {
      turnSlot = (turnSlot + 1) % activePlayerIds.size
      val nextPid = activePlayerIds[turnSlot]
      statusBanner = "نوبت ${playerColorName(nextPid)}"
    }
    pushSync()
  }

  suspend fun rollDice() {
    if (isRolling || hasRolled || winnerPlayerId != -1) return
    val pid = currentPid()
    isRolling = true
    val rolled: Int
    try {
      delay(600) // dice tumbles on its own (no per-frame recomposition)
      rolled = Random.nextInt(1, 7)
      diceValue = rolled
    } finally {
      isRolling = false
    }

    val legal = legalLudoTokensFor(tokens[pid], rolled)
    if (legal.isEmpty()) {
      statusBanner = "${playerColorName(pid)} عدد $rolled آورد (حرکتی موجود نیست)"
      hasRolled = false
      delay(440)
      turnSlot = (turnSlot + 1) % activePlayerIds.size
      statusBanner = "نوبت ${playerColorName(activePlayerIds[turnSlot])}"
      pushSync()
    } else {
      hasRolled = true
      statusBanner =
        if (playMode == PlayMode.VS_AI && pid != 0) "${playerColorName(pid)} تاس $rolled آورد..."
        else "${playerColorName(pid)}: یک مهره درخشان را لمس کنید"
      pushSync()
    }
  }

  fun handleBoardTap(tap: Offset, boardWidth: Float) {
    val pid = currentPid()
    if (!hasRolled || winnerPlayerId != -1 || isRolling) return
    if (playMode == PlayMode.VS_AI && pid != 0) return
    if (playMode == PlayMode.ONLINE_ROOM && turnSlot != myOnlineSlot) return
    val cell = boardWidth / 15f
    val legal = legalLudoTokensFor(tokens[pid], diceValue)
    var closestIdx = -1
    var minDist = Float.MAX_VALUE
    for (tIdx in legal) {
      val cur = tokens[pid][tIdx]
      val pos = tokenCanvasCoord(pid, tIdx, cur, cell)
      val dest = tokenCanvasCoord(pid, tIdx, if (cur == -1) 0 else cur + diceValue, cell)
      // tapping the token itself, or its highlighted destination, moves it
      val d = minOf(hypot(tap.x - pos.x, tap.y - pos.y), hypot(tap.x - dest.x, tap.y - dest.y))
      if (d < cell * 1.6f && d < minDist) {
        minDist = d
        closestIdx = tIdx
      }
    }
    if (closestIdx != -1) {
      executeTokenMove(pid, closestIdx)
    }
  }

  val latestBoardTap by rememberUpdatedState(::handleBoardTap)

  // AI Turn Loop — keys exclude isRolling & hasRolled so rollDice/move never self-cancel!
  LaunchedEffect(turnSlot, winnerPlayerId, playMode, roundId) {
    if (playMode != PlayMode.VS_AI) return@LaunchedEffect
    while (currentPid() != 0 && winnerPlayerId == -1) {
      val pid = currentPid()
      delay(450)
      if (winnerPlayerId != -1 || currentPid() != pid) break
      if (!hasRolled) {
        rollDice()
      }
      if (hasRolled && winnerPlayerId == -1 && currentPid() == pid) {
        delay(280)
        val legal = legalLudoTokensFor(tokens[pid], diceValue)
        if (legal.isNotEmpty()) {
          val chosen = pickBestLudoToken(pid, diceValue, legal, tokens, activePlayerIds)
          executeTokenMove(pid, chosen)
        }
      }
    }
  }

  LaunchedEffect(winnerPlayerId) {
    if (winnerPlayerId != -1 && !recorded) {
      recorded = true
      onRecordResult(winnerPlayerId == 0, if (winnerPlayerId == 0) 60 else 12)
    }
  }

  val legalMoves =
    remember(tokens, currentPlayerId, diceValue, hasRolled) {
      if (hasRolled) legalLudoTokensFor(tokens[currentPlayerId], diceValue) else emptyList()
    }

  val activePlayerColor = playerColorFor(currentPlayerId)

  Column(
    modifier =
      Modifier.fillMaxSize()
        .auroraGamingBackdrop(activePlayerColor, CyberGold)
        .systemBarsPadding(),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    GameTopBar(
      title = GameType.LUDO.titleFa,
      subtitle =
        when (playMode) {
          PlayMode.VS_AI -> "$count بازیکن (در برابر هوش مصنوعی)"
          PlayMode.LOCAL_PASS_AND_PLAY -> "$count بازیکن آفلاین"
          PlayMode.ONLINE_ROOM -> "اتاق آنلاین: ${room?.roomCode ?: "-"}"
        },
      accentColor = PlayerRed,
      onBack = onBack,
      trailingContent = {
        IconButton(onClick = { resetGame() }, modifier = Modifier.testTag("ludo_reset_button")) {
          Icon(Icons.Rounded.Refresh, contentDescription = "شروع مجدد", tint = PlayerRed)
        }
      },
    )

    Column(
      modifier =
        Modifier.fillMaxSize()
          .widthIn(max = 600.dp)
          .verticalScroll(rememberScrollState())
          .padding(14.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        activePlayerIds.forEach { pid ->
          val finished = tokens[pid].count { it == 56 }
          val active = winnerPlayerId == -1 && currentPlayerId == pid
          val col = playerColorFor(pid)
          GlassGradientCard(
            modifier = Modifier.weight(1f),
            accentColor = if (active) col else Color.White.copy(alpha = 0.14f),
            cornerRadius = 15.dp,
          ) {
            Column(
              modifier =
                Modifier.fillMaxWidth()
                  .background(if (active) col.copy(alpha = 0.16f) else Color.Transparent)
                  .padding(vertical = 8.dp, horizontal = 6.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              Text(
                text = playerColorName(pid),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (active) FontWeight.ExtraBold else FontWeight.Medium,
                color = if (active) col else TextPrimary,
                maxLines = 1,
              )
              Text(
                text = "رسیده: $finished / ۴",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
              )
            }
          }
        }
      }

      // Detailed 15x15 Frosted Glass Ludo Board
      GlassGradientCard(
        modifier = Modifier.fillMaxWidth().aspectRatio(1f),
        accentColor = activePlayerColor,
        cornerRadius = 24.dp,
      ) {
        Box(
          modifier =
            Modifier.fillMaxSize()
              .padding(8.dp)
              .pointerInput(Unit) {
                detectTapGestures { tap ->
                  latestBoardTap(tap, size.width.toFloat())
                }
              }
              .testTag("ludo_board_canvas")
        ) {
          // Static board: own layer, so it is recorded once and only replayed.
          Canvas(modifier = Modifier.fillMaxSize().graphicsLayer { }) {
            val cell = size.width / 15f

            drawRoundRect(
              brush = Brush.verticalGradient(listOf(Color(0xE6162038), Color(0xE60B1120))),
              cornerRadius = CornerRadius(24f, 24f),
            )

            drawLudoYardDetailed(0, 0, PlayerRed, cell, currentPlayerId == 0)
            drawLudoYardDetailed(9, 0, PlayerGreen, cell, currentPlayerId == 1)
            drawLudoYardDetailed(9, 9, PlayerYellow, cell, currentPlayerId == 2)
            drawLudoYardDetailed(0, 9, PlayerBlue, cell, currentPlayerId == 3)

            LudoOuterTrack.forEachIndexed { idx, (col, row) ->
              val tileColor =
                when (idx) {
                  0 -> PlayerRed.copy(alpha = 0.72f)
                  13 -> PlayerGreen.copy(alpha = 0.72f)
                  26 -> PlayerYellow.copy(alpha = 0.72f)
                  39 -> PlayerBlue.copy(alpha = 0.72f)
                  in LudoSafeTrackIndices -> Color(0xFF455A8C)
                  else -> Color(0xFF34466F)
                }
              val tl = Offset(col * cell + 1f, row * cell + 1f)
              val sz = Size(cell - 2f, cell - 2f)
              drawRoundRect(color = tileColor, topLeft = tl, size = sz, cornerRadius = CornerRadius(4f, 4f))
              drawRoundRect(
                color = Color.White.copy(alpha = 0.30f),
                topLeft = tl,
                size = sz,
                cornerRadius = CornerRadius(4f, 4f),
                style = Stroke(width = 1.4f),
              )
              if (idx in LudoSafeTrackIndices) {
                drawStarIcon(
                  center = Offset((col + 0.5f) * cell, (row + 0.5f) * cell),
                  outerRadius = cell * 0.30f,
                  color = if (idx in LudoStartOffsets) Color.White.copy(alpha = 0.85f) else CyberGold.copy(alpha = 0.85f),
                )
              }
            }

            // Route hint: faint line along the whole track + small direction arrows.
            val routePath = Path()
            LudoOuterTrack.forEachIndexed { i, (c, r) ->
              val x = (c + 0.5f) * cell
              val y = (r + 0.5f) * cell
              if (i == 0) routePath.moveTo(x, y) else routePath.lineTo(x, y)
            }
            routePath.close()
            drawPath(
              routePath,
              color = Color.White.copy(alpha = 0.16f),
              style = Stroke(width = cell * 0.10f, cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
            for (i in 0 until 52 step 3) {
              val (c1, r1) = LudoOuterTrack[i]
              val (c2, r2) = LudoOuterTrack[(i + 1) % 52]
              val ax = (c1 + c2 + 1) / 2f * cell
              val ay = (r1 + r2 + 1) / 2f * cell
              val ang = atan2((r2 - r1).toDouble(), (c2 - c1).toDouble())
              val sz = cell * 0.13f
              val tip = Offset(ax + (cos(ang) * sz).toFloat(), ay + (sin(ang) * sz).toFloat())
              val l = Offset(ax + (cos(ang + 2.5) * sz).toFloat(), ay + (sin(ang + 2.5) * sz).toFloat())
              val rr = Offset(ax + (cos(ang - 2.5) * sz).toFloat(), ay + (sin(ang - 2.5) * sz).toFloat())
              val arrow = Path().apply { moveTo(tip.x, tip.y); lineTo(l.x, l.y); lineTo(rr.x, rr.y); close() }
              drawPath(arrow, color = Color.White.copy(alpha = 0.45f))
            }

            HomeStretchCoords.forEachIndexed { pid, coords ->
              val pCol = playerColorFor(pid)
              coords.take(5).forEachIndexed { step, (col, row) ->
                val alpha = 0.32f + step * 0.11f
                drawRoundRect(
                  color = pCol.copy(alpha = alpha),
                  topLeft = Offset(col * cell + 1f, row * cell + 1f),
                  size = Size(cell - 2f, cell - 2f),
                  cornerRadius = CornerRadius(4f, 4f),
                )
                drawRoundRect(
                  color = pCol.copy(alpha = 0.8f),
                  topLeft = Offset(col * cell + 1f, row * cell + 1f),
                  size = Size(cell - 2f, cell - 2f),
                  cornerRadius = CornerRadius(4f, 4f),
                  style = Stroke(width = 1.2f),
                )
              }
            }

            val cLeft = 6 * cell
            val cTop = 6 * cell
            val cRight = 9 * cell
            val cBottom = 9 * cell
            val cx = 7.5f * cell
            val cy = 7.5f * cell
            drawTriangle(Offset(cLeft, cTop), Offset(cLeft, cBottom), Offset(cx, cy), PlayerRed)
            drawTriangle(Offset(cLeft, cTop), Offset(cRight, cTop), Offset(cx, cy), PlayerGreen)
            drawTriangle(Offset(cRight, cTop), Offset(cRight, cBottom), Offset(cx, cy), PlayerYellow)
            drawTriangle(Offset(cLeft, cBottom), Offset(cRight, cBottom), Offset(cx, cy), PlayerBlue)
            drawCircle(color = ObsidianBg, radius = cell * 0.52f, center = Offset(cx, cy))
            drawCircle(color = CyberGold, radius = cell * 0.44f, center = Offset(cx, cy), style = Stroke(3f))
            drawStarIcon(center = Offset(cx, cy), outerRadius = cell * 0.34f, color = CyberGold)

            YardCoords.forEachIndexed { pid, list ->
              val pCol = playerColorFor(pid)
              list.forEach { (c, r) ->
                val center = Offset(c * cell, r * cell)
                drawCircle(color = ObsidianBg, radius = cell * 0.56f, center = center)
                drawCircle(color = pCol.copy(alpha = 0.6f), radius = cell * 0.56f, center = center, style = Stroke(width = 2.5f))
              }
            }

          }
          // Moving tokens + halo: separate layer, invalidated alone.
          Canvas(modifier = Modifier.fillMaxSize().graphicsLayer { }) {
            val cell = size.width / 15f
            val drawList = ArrayList<Triple<Int, Int, Boolean>>(16)
            activePlayerIds.forEach { pid ->
              for (tIdx in 0..3) drawList.add(Triple(pid, tIdx, progAnims[pid * 4 + tIdx].isRunning))
            }
            // moving tokens are drawn on top
            drawList.sortBy { if (it.third) 1 else 0 }
            // Preview of where each movable token will land (route line + target ring).
            val canPick =
              hasRolled && !isRolling && winnerPlayerId == -1 &&
                (playMode != PlayMode.VS_AI || currentPlayerId == 0) &&
                (playMode != PlayMode.ONLINE_ROOM || turnSlot == myOnlineSlot)
            if (canPick) {
              val pCol = playerColorFor(currentPlayerId)
              for (tIdx in legalMoves) {
                val cur = tokens[currentPlayerId][tIdx]
                val next = if (cur == -1) 0 else cur + diceValue
                val from = tokenCanvasCoord(currentPlayerId, tIdx, cur, cell)
                val route = Path().apply { moveTo(from.x, from.y) }
                if (cur == -1) {
                  val to0 = tokenCanvasCoord(currentPlayerId, tIdx, 0, cell)
                  route.lineTo(to0.x, to0.y)
                } else {
                  for (stp in (cur + 1)..next) {
                    val q = tokenCanvasCoord(currentPlayerId, tIdx, stp, cell)
                    route.lineTo(q.x, q.y)
                  }
                }
                drawPath(
                  route,
                  color = pCol.copy(alpha = 0.85f),
                  style =
                    Stroke(
                      width = cell * 0.14f,
                      cap = StrokeCap.Round,
                      join = StrokeJoin.Round,
                      pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(cell * 0.22f, cell * 0.22f)),
                    ),
                )
                val dest = tokenCanvasCoord(currentPlayerId, tIdx, next, cell)
                drawCircle(color = pCol.copy(alpha = 0.22f + 0.18f * tokenPulseAnim.value), radius = cell * 0.46f, center = dest)
                drawCircle(color = pCol, radius = cell * (0.46f + 0.06f * tokenPulseAnim.value), center = dest, style = Stroke(width = 3.5f))
                drawCircle(color = Color.White, radius = cell * 0.10f, center = dest)
              }
            }
            for ((pid, tIdx, _) in drawList) {
              val pCol = playerColorFor(pid)
              val progF = progAnims[pid * 4 + tIdx].value
              val isLegal = pid == currentPlayerId && tIdx in legalMoves
              drawGlossyToken(
                center = tokenCanvasCoordF(pid, tIdx, progF, cell),
                radius = cell * 0.36f,
                baseColor = pCol,
                isHighlighted = isLegal,
                pulseFactor = tokenPulseAnim.value,
              )
            }
          }
        }
      }

      GlassGradientCard(
        modifier = Modifier.fillMaxWidth(),
        accentColor = activePlayerColor,
        cornerRadius = 16.dp,
      ) {
        Text(
          text = statusBanner,
          style = MaterialTheme.typography.bodyMedium,
          color = TextPrimary,
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
        )
      }

      if (winnerPlayerId != -1) {
        WinCelebrationBanner(
          winnerTitle = "${playerColorName(winnerPlayerId)} قهرمان منچ شد!",
          subtitle = "۶۰ امتیاز جایزه ثبت شد",
          accent = playerColorFor(winnerPlayerId),
          onRematch = { resetGame() },
          onExit = onBack,
        )
      } else {
        val canHumanAct =
          !isRolling &&
            (playMode != PlayMode.VS_AI || currentPlayerId == 0) &&
            (playMode != PlayMode.ONLINE_ROOM || turnSlot == myOnlineSlot)

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          AnimatedGameDice(
            value = diceValue,
            isRolling = isRolling,
            accentColor = activePlayerColor,
          )

          Button(
            onClick = { scope.launch { rollDice() } },
            enabled = canHumanAct && !hasRolled,
            modifier = Modifier.weight(1f).height(58.dp).testTag("ludo_roll_button"),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = NeonCyan,
                disabledContainerColor = Color(0xFF2A3350),
                disabledContentColor = TextSecondary,
              ),
            shape = RoundedCornerShape(18.dp),
          ) {
            Icon(BaziIcons.Dice, contentDescription = null, tint = androidx.compose.material3.LocalContentColor.current)
            Spacer(Modifier.size(8.dp))
            Text(
              text =
                when {
                  hasRolled && canHumanAct -> "مهره درخشان را لمس کنید"
                  canHumanAct -> "انداختن تاس (${playerColorName(currentPlayerId)})"
                  else -> "نوبت حریف..."
                },
              color = androidx.compose.material3.LocalContentColor.current,
              fontWeight = FontWeight.ExtraBold,
            )
          }
        }
      }
      Spacer(Modifier.height(10.dp))
    }
  }
}

internal fun legalLudoTokensFor(playerTokens: List<Int>, dice: Int): List<Int> {
  return (0..3).filter { idx ->
    val prog = playerTokens[idx]
    when {
      prog == -1 -> dice == 6
      prog in 0..55 -> prog + dice <= 56
      else -> false
    }
  }
}

internal fun pickBestLudoToken(
  pid: Int,
  dice: Int,
  legal: List<Int>,
  tokens: List<List<Int>>,
  activePlayerIds: List<Int>,
): Int {
  return legal.maxByOrNull { idx ->
    val p = tokens[pid][idx]
    val nextP = if (p == -1) 0 else p + dice
    var score = nextP
    if (p == -1) score += 110
    if (nextP == 56) score += 200
    if (nextP in 0..50) {
      val globalIdx = (LudoStartOffsets[pid] + nextP) % 52
      if (globalIdx in LudoSafeTrackIndices) score += 60
      else {
        val canCapture =
          activePlayerIds.any { otherPid ->
            otherPid != pid &&
              tokens[otherPid].any { op ->
                op in 0..50 && (LudoStartOffsets[otherPid] + op) % 52 == globalIdx
              }
          }
        if (canCapture) score += 180
      }
    }
    score
  } ?: legal.first()
}

private fun DrawScope.drawLudoYardDetailed(
  startCol: Int,
  startRow: Int,
  color: Color,
  cell: Float,
  isTurnActive: Boolean,
) {
  drawRoundRect(
    brush = Brush.linearGradient(listOf(color.copy(alpha = if (isTurnActive) 0.42f else 0.24f), color.copy(alpha = 0.12f))),
    topLeft = Offset(startCol * cell + 2f, startRow * cell + 2f),
    size = Size(6 * cell - 4f, 6 * cell - 4f),
    cornerRadius = CornerRadius(18f, 18f),
  )
  drawRoundRect(
    color = if (isTurnActive) color else color.copy(alpha = 0.65f),
    topLeft = Offset(startCol * cell + 2f, startRow * cell + 2f),
    size = Size(6 * cell - 4f, 6 * cell - 4f),
    cornerRadius = CornerRadius(18f, 18f),
    style = Stroke(width = if (isTurnActive) 4f else 2.5f),
  )
  drawRoundRect(
    color = CarbonSurface,
    topLeft = Offset((startCol + 0.78f) * cell, (startRow + 0.78f) * cell),
    size = Size(4.44f * cell, 4.44f * cell),
    cornerRadius = CornerRadius(14f, 14f),
  )
}

private fun DrawScope.drawTriangle(p1: Offset, p2: Offset, p3: Offset, color: Color) {
  val path =
    Path().apply {
      moveTo(p1.x, p1.y)
      lineTo(p2.x, p2.y)
      lineTo(p3.x, p3.y)
      close()
    }
  drawPath(path, color = color.copy(alpha = 0.78f))
  drawPath(path, color = ObsidianBg, style = Stroke(width = 2.5f))
}

private fun DrawScope.drawStarIcon(center: Offset, outerRadius: Float, color: Color) {
  val innerRadius = outerRadius * 0.45f
  val path = Path()
  for (i in 0 until 8) {
    val angle = (i * 45.0 - 90.0) * Math.PI / 180.0
    val r = if (i % 2 == 0) outerRadius else innerRadius
    val x = center.x + (cos(angle) * r).toFloat()
    val y = center.y + (sin(angle) * r).toFloat()
    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
  }
  path.close()
  drawPath(path, color = color)
}

private fun tokenCanvasCoord(pid: Int, tokenIdx: Int, prog: Int, cell: Float): Offset {
  return when {
    prog == -1 -> {
      val (c, r) = YardCoords[pid][tokenIdx]
      Offset(c * cell, r * cell)
    }
    prog in 0..50 -> {
      val globalIdx = (LudoStartOffsets[pid] + prog) % 52
      val (c, r) = LudoOuterTrack[globalIdx]
      Offset((c + 0.5f) * cell, (r + 0.5f) * cell)
    }
    else -> {
      val stepIdx = (prog - 51).coerceIn(0, 5)
      val (c, r) = HomeStretchCoords[pid][stepIdx]
      Offset((c + 0.5f) * cell, (r + 0.5f) * cell)
    }
  }
}

private fun tokenCanvasCoordF(pid: Int, tokenIdx: Int, prog: Float, cell: Float): Offset {
  val lo = kotlin.math.floor(prog).toInt()
  val frac = prog - lo
  val a = tokenCanvasCoord(pid, tokenIdx, lo.coerceIn(-1, 56), cell)
  if (frac < 0.001f) return a
  val b = tokenCanvasCoord(pid, tokenIdx, (lo + 1).coerceIn(-1, 56), cell)
  val hopLift = sin(Math.PI * frac).toFloat() * cell * 0.28f
  return Offset(a.x + (b.x - a.x) * frac, a.y + (b.y - a.y) * frac - hopLift)
}
