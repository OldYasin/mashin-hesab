package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TextMuted

/**
 * 3D tactile arcade "roll the dice" button shared by Ludo and Snakes & Ladders:
 * extruded 3D bottom lip that physically depresses on press, glossy bevelled face,
 * breathing neon aura, and a custom 3D isometric die icon.
 */
@Composable
fun RollDiceButton(
  title: String,
  subtitle: String?,
  enabled: Boolean,
  accent: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val src = remember { MutableInteractionSource() }
  val pressed by src.collectIsPressedAsState()
  val depth by animateDpAsState(
    targetValue = if (!enabled) 2.dp else if (pressed) 1.dp else 6.dp,
    animationSpec = spring(stiffness = 700f),
    label = "btn3dDepth",
  )
  val maxDepth = 6.dp
  val topOffset = maxDepth - depth
  val shape = RoundedCornerShape(20.dp)

  val inf = rememberInfiniteTransition(label = "rollGlow3d")
  val glow by
    inf.animateFloat(
      initialValue = 0.25f,
      targetValue = 0.85f,
      animationSpec = infiniteRepeatable(tween(1150, easing = FastOutSlowInEasing), RepeatMode.Reverse),
      label = "glow3d",
    )

  val topHighlight = lerp(accent, Color.White, 0.22f)
  val bottomShade = lerp(accent, Color.Black, 0.26f)
  val baseLipColor = if (enabled) lerp(accent, Color.Black, 0.56f) else Color(0xFF0C121E)
  val faceBrush =
    if (enabled) {
      Brush.verticalGradient(listOf(topHighlight, accent, bottomShade))
    } else {
      Brush.verticalGradient(listOf(Color(0xFF1E283D), Color(0xFF141B2B)))
    }

  Box(
    modifier =
      modifier
        .height(60.dp)
        .drawBehind {
          if (enabled) {
            val r = 20.dp.toPx()
            for (i in 1..3) {
              val grow = i * 3.5.dp.toPx()
              drawRoundRect(
                color = accent.copy(alpha = glow * 0.14f / i),
                topLeft = Offset(-grow, 2.dp.toPx() - grow),
                size = Size(size.width + grow * 2, size.height + grow * 2),
                cornerRadius = CornerRadius(r + grow),
              )
            }
          }
        }
        .clickable(
          interactionSource = src,
          indication = null,
          enabled = enabled,
          role = Role.Button,
          onClick = onClick,
        ),
  ) {
    // 3D Extruded Bottom Lip
    Box(
      modifier =
        Modifier.fillMaxWidth()
          .height(54.dp)
          .align(Alignment.BottomCenter)
          .clip(shape)
          .background(baseLipColor)
          .border(1.dp, Color.Black.copy(alpha = 0.45f), shape)
    )

    // 3D Raised Top Face
    Box(
      modifier =
        Modifier.fillMaxWidth()
          .height(54.dp)
          .offset(y = topOffset)
          .clip(shape)
          .background(faceBrush)
          .border(
            1.3.dp,
            Brush.verticalGradient(
              listOf(
                Color.White.copy(alpha = if (enabled) 0.55f else 0.12f),
                Color.White.copy(alpha = if (enabled) 0.12f else 0.03f),
              )
            ),
            shape,
          ),
      contentAlignment = Alignment.Center,
    ) {
      // Top glossy specular reflection
      Box(
        modifier =
          Modifier.fillMaxWidth()
            .height(22.dp)
            .align(Alignment.TopCenter)
            .background(
              Brush.verticalGradient(
                listOf(Color.White.copy(alpha = if (enabled) 0.28f else 0.06f), Color.Transparent)
              )
            )
      )

      Box(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
          Text(
            text = title,
            style =
              MaterialTheme.typography.titleMedium.copy(
                fontSize = 15.5.sp,
                shadow =
                  if (enabled) Shadow(Color.Black.copy(alpha = 0.45f), Offset(0f, 2f), 4f)
                  else null,
              ),
            color = if (enabled) Color.White else TextMuted,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          if (subtitle != null) {
            Box(
              modifier =
                Modifier.clip(RoundedCornerShape(50))
                  .background(if (enabled) Color.Black.copy(alpha = 0.24f) else Color.Transparent)
                  .padding(horizontal = 10.dp, vertical = 1.dp)
            ) {
              Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                color = if (enabled) Color.White.copy(alpha = 0.94f) else TextMuted.copy(alpha = 0.75f),
                fontWeight = FontWeight.Bold,
                maxLines = 1,
              )
            }
          }
        }
      }
    }
  }
}
