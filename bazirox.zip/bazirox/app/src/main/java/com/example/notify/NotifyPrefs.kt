package com.example.notify

import android.content.Context

/** Plain (non-secret) notification settings: switch, background cursor, one-time permission prompt flag. */
object NotifyPrefs {
  private const val FILE = "bazirox_notify"

  private fun p(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

  fun isEnabled(c: Context): Boolean = p(c).getBoolean("enabled", true)

  fun setEnabled(c: Context, value: Boolean) = p(c).edit().putBoolean("enabled", value).apply()

  /** Server time (ms) up to which notifications were already handled; 0 = not started yet. */
  fun cursor(c: Context): Long = p(c).getLong("cursor", 0L)

  fun setCursor(c: Context, value: Long) = p(c).edit().putLong("cursor", value).apply()

  fun resetCursor(c: Context) = p(c).edit().remove("cursor").apply()

  fun permissionAsked(c: Context): Boolean = p(c).getBoolean("perm_asked", false)

  fun setPermissionAsked(c: Context) = p(c).edit().putBoolean("perm_asked", true).apply()
}

/** True while the app is on screen: the background check stays quiet then (the chat polling already runs). */
object AppVisibility {
  @Volatile var foreground: Boolean = false
}
