package com.example.notify

import android.app.job.JobParameters
import android.app.job.JobService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** Runs the notification check in the background (system-scheduled, no always-on service). */
class MessageCheckJobService : JobService() {
  private var job: Job? = null

  override fun onStartJob(params: JobParameters): Boolean {
    job =
      CoroutineScope(Dispatchers.IO).launch {
        try {
          NotificationChecker.run(applicationContext)
        } catch (_: Throwable) {
          // A failed check is simply retried at the next period.
        }
        jobFinished(params, false)
      }
    return true
  }

  override fun onStopJob(params: JobParameters): Boolean {
    job?.cancel()
    return false
  }
}
