package com.example.data

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

/** Photo helpers for chat: downscale + EXIF-rotate + JPEG compress so uploads stay small (~100-250KB). */
object ChatImageUtils {

  fun compressToFile(
    resolver: ContentResolver,
    uri: Uri,
    out: File,
    maxDim: Int = 1280,
    quality: Int = 76,
  ): Boolean {
    return try {
      val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
      resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
      if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false
      val opts =
        BitmapFactory.Options().apply {
          inSampleSize = sampleSizeFor(bounds.outWidth, bounds.outHeight, maxDim)
        }
      var bmp =
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
          ?: return false
      val rotation =
        try {
          resolver.openInputStream(uri)?.use { exifRotation(ExifInterface(it)) } ?: 0
        } catch (_: Throwable) {
          0
        }
      val longest = maxOf(bmp.width, bmp.height)
      val scale = if (longest > maxDim) maxDim.toFloat() / longest else 1f
      if (rotation != 0 || scale < 1f) {
        val m = Matrix()
        if (scale < 1f) m.postScale(scale, scale)
        if (rotation != 0) m.postRotate(rotation.toFloat())
        val t = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        if (t !== bmp) bmp.recycle()
        bmp = t
      }
      out.parentFile?.mkdirs()
      FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
      bmp.recycle()
      true
    } catch (_: Throwable) {
      false
    }
  }

  fun decodeSampled(file: File, maxDim: Int): Bitmap? {
    return try {
      if (!file.exists()) return null
      val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
      BitmapFactory.decodeFile(file.absolutePath, bounds)
      if (bounds.outWidth <= 0) return null
      val opts =
        BitmapFactory.Options().apply {
          inSampleSize = sampleSizeFor(bounds.outWidth, bounds.outHeight, maxDim)
        }
      BitmapFactory.decodeFile(file.absolutePath, opts)
    } catch (_: Throwable) {
      null
    }
  }

  private fun sampleSizeFor(w: Int, h: Int, maxDim: Int): Int {
    var s = 1
    while (maxOf(w, h) / (s * 2) >= maxDim) s *= 2
    return s
  }

  private fun exifRotation(exif: ExifInterface): Int =
    when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
      ExifInterface.ORIENTATION_ROTATE_90 -> 90
      ExifInterface.ORIENTATION_ROTATE_180 -> 180
      ExifInterface.ORIENTATION_ROTATE_270 -> 270
      else -> 0
    }
}
