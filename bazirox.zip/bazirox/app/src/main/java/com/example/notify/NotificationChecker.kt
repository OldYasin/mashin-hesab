package com.example.notify

import android.content.Context
import com.example.data.CPanelApiClient
import com.example.data.NotifyItem
import com.example.data.SecureVault
import com.example.security.CryptoManager
import org.json.JSONObject

/**
 * One tiny request that asks the server for unread messages newer than the saved cursor, decrypts
 * them locally with the keys on this phone and shows one notification per chat.
 * Messages already read (on any device) are excluded by the server.
 */
object NotificationChecker {

  private fun client(context: Context): Triple<SecureVault, CPanelApiClient, com.example.data.CPanelConfig>? {
    val vault = SecureVault(context.applicationContext)
    val session = vault.loadSession() ?: return null
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isBlank()) return null
    return Triple(vault, CPanelApiClient().apply { authToken = session.authToken }, config)
  }

  /** Starts the cursor at "now" (server clock) so old messages never turn into a flood of notifications. */
  suspend fun ensureCursor(context: Context) {
    if (NotifyPrefs.cursor(context) > 0L) return
    val (_, api, config) = client(context) ?: return
    val now = api.notifyPoll(config, 0L).getOrNull()?.serverTimeMs ?: return
    if (now > 0L) NotifyPrefs.setCursor(context, now)
  }

  suspend fun run(context: Context) {
    if (!NotifyPrefs.isEnabled(context) || AppVisibility.foreground) return
    val since = NotifyPrefs.cursor(context)
    if (since <= 0L) {
      ensureCursor(context)
      return
    }
    val (vault, api, config) = client(context) ?: return
    val page = api.notifyPoll(config, since).getOrNull() ?: return
    if (page.items.isNotEmpty()) {
      val entries =
        page.items.groupBy { it.groupId }.map { (gid, items) -> buildEntry(vault, gid, items) }
      NotificationHelper.show(context, entries)
    }
    if (page.serverTimeMs > since) NotifyPrefs.setCursor(context, page.serverTimeMs)
  }

  private fun keyFor(vault: SecureVault, item: NotifyItem): ByteArray? {
    vault.loadGroupKey(item.groupId)?.let { return it }
    // Private chat of two people who share a group: its key comes from that group's key.
    if (item.isDm && item.dmOrigin.isNotBlank() && item.dmOrigin != "ecdh") {
      return vault.loadGroupKey(item.dmOrigin)?.let { CryptoManager.deriveDmKey(it, item.groupId) }
    }
    return null
  }

  private fun buildEntry(vault: SecureVault, groupId: String, items: List<NotifyItem>): NotificationHelper.Entry {
    val first = items.first()
    val key = keyFor(vault, first)
    val title =
      when {
        first.isDm -> first.sender
        first.groupName.startsWith("e1:") ->
          key?.let { CryptoManager.e2eeDecrypt(first.groupName, it, CPanelApiClient.AAD_GROUP_NAME) } ?: "گروه"
        else -> first.groupName.ifBlank { "گروه" }
      }
    val lines =
      items.map { m ->
        val text = previewOf(m, key)
        if (m.isDm) text else "${m.sender}: $text"
      }
    return NotificationHelper.Entry(groupId, title, lines)
  }

  private fun previewOf(item: NotifyItem, key: ByteArray?): String {
    val fallback = if (item.hasImage) "📷 عکس" else "پیام جدید"
    if (key == null || item.encText.isBlank()) return fallback
    val plain = CryptoManager.e2eeDecrypt(item.encText, key, "${item.groupId}|${item.id}") ?: return fallback
    return try {
      val j = JSONObject(plain)
      val t = j.optString("t", "").trim()
      val text =
        when {
          j.optJSONObject("g") != null -> "🎮 دعوت به بازی"
          item.hasImage && t.isBlank() -> "📷 عکس"
          item.hasImage -> "📷 $t"
          else -> t
        }
      text.ifBlank { fallback }.take(120)
    } catch (_: Throwable) {
      fallback
    }
  }
}
