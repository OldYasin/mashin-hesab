package com.example.ui.games

import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.res.Configuration
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.view.ContextThemeWrapper
import android.view.SurfaceControlViewHost
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.webkit.WebView
import androidx.activity.OnBackPressedDispatcher
import androidx.activity.OnBackPressedDispatcherOwner
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.activity.result.ActivityResultRegistry
import androidx.activity.result.ActivityResultRegistryOwner
import androidx.activity.result.contract.ActivityResultContract
import androidx.annotation.RequiresApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityOptionsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner

/*
 * TEST (username yasinm): TWO complete players on ONE screen.
 *
 *  - Left/top half  = the normal emulator screen, in the normal process (exactly the production code).
 *  - Right/bottom half = a second, completely independent emulator (own process ":p2" = own native core and
 *    own lockstep state, like a second phone), drawn INTO this window with SurfaceControlViewHost (Android 11+).
 *
 * Both halves are in ONE window/activity, so the phone (MIUI) can never pause or freeze one of them, and touches
 * on each half go to that player's pad. Window 1 and window 2 talk through the real relay like two phones.
 * Create the room in one half, join with the code in the other. Roms: the second half uses the same ROM library.
 */

private const val MSG_ATTACH = 1
private const val MSG_RESIZE = 2
private const val MSG_DETACH = 3
private const val MSG_PACKAGE = 4

@RequiresApi(Build.VERSION_CODES.R)
@Composable
internal fun EmulatorSplitTest(playerName: String, currentUsername: String, onClose: () -> Unit) {
  val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
  val second = (currentUsername.ifBlank { playerName }.ifBlank { "yasinm" }) + "_p2"
  if (landscape) {
    Row(Modifier.fillMaxSize()) {
      Box(Modifier.weight(1f).fillMaxHeight()) { EmulatorContent(playerName, currentUsername, onClose, onOpenSplit = null) }
      Box(Modifier.width(2.dp).fillMaxHeight().background(Color(0xFFFF3B30)))
      Box(Modifier.weight(1f).fillMaxHeight()) { RemoteEmulatorView(second) }
    }
  } else {
    Column(Modifier.fillMaxSize()) {
      Box(Modifier.weight(1f).fillMaxWidth()) { EmulatorContent(playerName, currentUsername, onClose, onOpenSplit = null) }
      Box(Modifier.height(2.dp).fillMaxWidth().background(Color(0xFFFF3B30)))
      Box(Modifier.weight(1f).fillMaxWidth()) { RemoteEmulatorView(second) }
    }
  }
}

@RequiresApi(Build.VERSION_CODES.R)
@Composable
private fun RemoteEmulatorView(name: String) {
  val context = LocalContext.current
  val conn = remember { RemoteConn(context.applicationContext, name) }
  DisposableEffect(conn) { onDispose { conn.close() } }
  AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx -> conn.createView(ctx) })
}

/** Client side (main process): binds the service of the :p2 process and shows its SurfacePackage in a SurfaceView. */
@RequiresApi(Build.VERSION_CODES.R)
private class RemoteConn(private val appCtx: Context, private val name: String) {
  private var sv: SurfaceView? = null
  private var service: Messenger? = null
  private var bound = false
  private var attached = false
  private var w = 0
  private var h = 0

  private val reply =
    Messenger(
      Handler(Looper.getMainLooper()) { m ->
        if (m.what == MSG_PACKAGE) {
          val pkg = m.data?.getParcelable<SurfaceControlViewHost.SurfacePackage>("pkg")
          if (pkg != null) sv?.setChildSurfacePackage(pkg)
        }
        true
      }
    )

  private val connection =
    object : ServiceConnection {
      override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
        service = Messenger(b)
        attached = false
        tryAttach()
      }

      override fun onServiceDisconnected(n: ComponentName?) {
        service = null
        attached = false
      }
    }

  fun createView(ctx: Context): SurfaceView {
    val v = SurfaceView(ctx)
    // The embedded surface must sit ABOVE the window: a SurfaceView behind the window leaves the host window's
    // (transparent) layer on top, which swallows every touch, so the second half's buttons never got a tap.
    v.setZOrderOnTop(true)
    v.holder.setFormat(android.graphics.PixelFormat.TRANSLUCENT)
    sv = v
    v.holder.addCallback(
      object : SurfaceHolder.Callback {
        override fun surfaceCreated(holder: SurfaceHolder) {}

        override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
          val first = w == 0
          w = width
          h = height
          if (!bound) {
            bound = appCtx.bindService(
              Intent(appCtx, EmulatorRemoteService::class.java),
              connection,
              Context.BIND_AUTO_CREATE or Context.BIND_IMPORTANT,
            )
          } else if (attached && !first) {
            send(MSG_RESIZE) { putInt("w", w); putInt("h", h) }
          } else {
            tryAttach()
          }
        }

        override fun surfaceDestroyed(holder: SurfaceHolder) {}
      }
    )
    return v
  }

  private fun send(what: Int, fill: Bundle.() -> Unit = {}) {
    val s = service ?: return
    val m = Message.obtain(null, what)
    m.replyTo = reply
    m.data = Bundle().apply(fill)
    try { s.send(m) } catch (_: Throwable) {}
  }

  private fun tryAttach() {
    val v = sv ?: return
    val token = v.hostToken ?: return
    if (service == null || w <= 0 || h <= 0 || attached) return
    attached = true
    send(MSG_ATTACH) {
      putBinder("token", token)
      putInt("display", v.display?.displayId ?: 0)
      putInt("w", w)
      putInt("h", h)
      putString("name", name)
    }
  }

  fun close() {
    send(MSG_DETACH)
    if (bound) {
      try { appCtx.unbindService(connection) } catch (_: Throwable) {}
      bound = false
    }
    service = null
    attached = false
    sv = null
  }
}

/** Lifecycle / saved-state / back / activity-result owner for a Compose tree that lives outside of an Activity. */
private class RemoteOwner :
  LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner, OnBackPressedDispatcherOwner, ActivityResultRegistryOwner {
  private val reg = LifecycleRegistry(this)
  private val ssc = SavedStateRegistryController.create(this)
  private val vms = ViewModelStore()
  private val backDispatcher = OnBackPressedDispatcher()
  private val resultRegistry =
    object : ActivityResultRegistry() {
      override fun <I, O> onLaunch(requestCode: Int, contract: ActivityResultContract<I, O>, input: I, options: ActivityOptionsCompat?) {
        // no activity here: the ROM picker does nothing in this half (pick the game from the library list)
      }
    }

  override val lifecycle: Lifecycle get() = reg
  override val savedStateRegistry: SavedStateRegistry get() = ssc.savedStateRegistry
  override val viewModelStore: ViewModelStore get() = vms
  override val onBackPressedDispatcher: OnBackPressedDispatcher get() = backDispatcher
  override val activityResultRegistry: ActivityResultRegistry get() = resultRegistry

  init {
    ssc.performAttach()
    ssc.performRestore(null)
    reg.currentState = Lifecycle.State.RESUMED
  }

  fun destroy() {
    reg.currentState = Lifecycle.State.DESTROYED
    vms.clear()
  }
}

/** Runs in process ":p2": renders a second complete player (EmulatorContent) into the SurfaceView of the main window. */
@RequiresApi(Build.VERSION_CODES.R)
class EmulatorRemoteService : Service() {
  private var host: SurfaceControlViewHost? = null
  private var owner: RemoteOwner? = null
  private var view: ComposeView? = null

  private val messenger =
    Messenger(
      Handler(Looper.getMainLooper()) { m ->
        when (m.what) {
          MSG_ATTACH -> try { attach(m) } catch (t: Throwable) { android.util.Log.e("EmuSplit", "attach failed", t); teardown() }
          MSG_RESIZE -> host?.relayout(m.data.getInt("w"), m.data.getInt("h"))
          MSG_DETACH -> teardown()
        }
        true
      }
    )

  override fun onCreate() {
    super.onCreate()
    EmuInstance.suffix = "_p2"
    // A second process may not share the WebView data folder (the game overlay is a WebView).
    try { WebView.setDataDirectorySuffix("p2") } catch (_: Throwable) {}
  }

  override fun onBind(intent: Intent?): IBinder? = messenger.binder

  override fun onDestroy() {
    teardown()
    super.onDestroy()
  }

  private fun attach(m: Message) {
    val d = m.data
    val token = d.getBinder("token")
    val w = d.getInt("w")
    val h = d.getInt("h")
    val name = d.getString("name") ?: "yasinm_p2"
    teardown()
    val display = getSystemService(DisplayManager::class.java).getDisplay(d.getInt("display")) ?: return
    val themed = ContextThemeWrapper(createDisplayContext(display), com.example.R.style.Theme_MyApplication)
    val o = RemoteOwner()
    val cv = ComposeView(themed)
    cv.setViewTreeLifecycleOwner(o)
    cv.setViewTreeSavedStateRegistryOwner(o)
    cv.setViewTreeViewModelStoreOwner(o)
    cv.setContent {
      CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Ltr,
        LocalActivityResultRegistryOwner provides o,
        LocalOnBackPressedDispatcherOwner provides o,
      ) {
        EmulatorContent(name, name, onBack = {}, onOpenSplit = null)
      }
    }
    val hst = SurfaceControlViewHost(themed, display, token)
    hst.setView(cv, w, h)
    host = hst
    owner = o
    view = cv
    val out = Message.obtain(null, MSG_PACKAGE)
    out.data = Bundle().apply { putParcelable("pkg", hst.surfacePackage) }
    try { m.replyTo?.send(out) } catch (_: Throwable) {}
  }

  private fun teardown() {
    try { view?.disposeComposition() } catch (_: Throwable) {}
    try { host?.release() } catch (_: Throwable) {}
    try { owner?.destroy() } catch (_: Throwable) {}
    host = null
    owner = null
    view = null
  }
}
