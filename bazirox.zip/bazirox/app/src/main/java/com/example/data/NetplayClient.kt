package com.example.data

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.net.Socket
import javax.net.SocketFactory
import java.util.concurrent.TimeUnit
import java.util.zip.DeflaterOutputStream
import java.util.zip.InflaterInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import org.json.JSONObject

/**
 * Two-player relay client for the Cloudflare Worker (see netplay-worker/worker.js).
 * Sends key presses and (host only) compressed save-states; all callbacks run on the main thread.
 */
class NetplayClient(
  baseUrl: String,
  val room: String,
  @Volatile var romKey: String,
  @Volatile var listener: Listener,
) {
  interface Listener {
    fun onHello(slot: Int, peers: Int)

    fun onPeer(on: Boolean)

    fun onKey(code: Int, down: Boolean)

    fun onState(bytes: ByteArray)

    fun onRomMismatch()

    /** The other player has the same game as me. */
    fun onRomOk() {}

    /** Round trip to the relay server itself (needs the updated worker). */
    fun onServerPing(rttMs: Long) {}

    /** Save/load requests and results between the two players (save, load, saved, loaded, ...). */
    fun onCmd(action: String)

    fun onPing(rttMs: Long)

    /** A chat message from the other player. */
    fun onChat(text: String) {}

    /** The other player's display name. */
    fun onPeerName(name: String) {}

    fun onClosed(reason: String)

    /** Lockstep: remote frame input arrived. */
    fun onFrameInput(frame: Int, mask: Int) {}

    /** Lockstep: remote state hash for desync detection. */
    fun onFrameHash(frame: Int, hash: Int) {}

    /** The other phone sent its complete diagnostic log (see [sendLog]). */
    fun onPeerLog(text: String) {}
  }

  companion object {
    /** Fixed buffer (ms) added on both sides to the travel time, so the friend's keys can be applied at a steady delay. */
    const val JITTER_BUFFER_MS = 25L
    private const val CHUNK = 4096
    private const val QUEUE_LIMIT = 8192L
    /** Feature flag: when true, prefer lockstep packets (type=2) over timed keys + periodic state. */
    const val USE_LOCKSTEP = true
  }

  private val main = Handler(Looper.getMainLooper())
  // TCP_NODELAY: without it Android's TCP (Nagle) holds each tiny 8-byte input packet until the previous one is ACKed,
  // so the 60 packets/s arrive in bursts (RX gaps > 100 ms, ping alternating ~110 / ~175 ms) and every frame waits for the peer.
  private val http =
    OkHttpClient.Builder().socketFactory(NoDelaySocketFactory()).pingInterval(20, TimeUnit.SECONDS).build()

  @Volatile private var ws: WebSocket? = null

  @Volatile private var closed = false
  @Volatile var lockstepSession: Int = 0

  /** Measured one-way latency (ms), clamped to 15..150: used as the input delay on both sides. */
  @Volatile
  var oneWayMs: Long = 50L
    private set

  @Volatile private var t0 = 0L

  private val rtts = ArrayDeque<Long>()

  // Longer history (last ~30 pings) used ONLY to choose the lockstep delay D. oneWayMs above follows the quietest
  // recent samples, so it said 53 ms when the route had really drifted to 100 ms and D stayed too low (constant stalls).
  private val rttLong = ArrayDeque<Long>()

  /** 75th percentile of the last ~30 round trips (ms); 0 until the first sample. Input for choosing D. */
  @Volatile
  var delayRttMs: Long = 0L
    private set

  /** Mean change between consecutive round trips (ms). */
  @Volatile
  var rttJitterMs: Long = 0L
    private set

  // ---- Timed key delivery: the friend's keys are applied at (his press time + travel time + a small fixed buffer) ----
  // so network jitter does not reach the screen. Offsets = (my clock at arrival) - (his clock at sending).
  private val offs = ArrayDeque<Long>()
  private var lastRemoteDue = 0L

  private fun addOffset(v: Long) =
    synchronized(offs) {
      offs.addLast(v)
      if (offs.size > 12) offs.removeFirst()
    }

  private fun minOffset(): Long? = synchronized(offs) { offs.minOrNull() }

  // ---- State transfer: sent in small chunks (keys can pass between them); as a delta against the previous state when possible ----
  @Volatile private var sentPrev: ByteArray? = null
  @Volatile private var sentId = 0
  @Volatile private var forceFull = false
  private var recvLast: ByteArray? = null
  private var recvId = 0
  private var asmId = 0
  private var asmBase = 0
  private var asmParts: Array<ByteArray?> = arrayOfNulls(0)
  private var asmCount = 0

  /** Time from connect() until the server said hello (ms); 0 until connected. */
  @Volatile
  var connectMs: Long = 0L
    private set

  private val wsUrl: String = normalize(baseUrl) + "/ws?room=" + room

  private fun normalize(u: String): String {
    val s = u.trim().trimEnd('/')
    return when {
      s.startsWith("https://") -> "wss://" + s.removePrefix("https://")
      s.startsWith("http://") -> "ws://" + s.removePrefix("http://")
      s.startsWith("wss://") || s.startsWith("ws://") -> s
      else -> "wss://$s"
    }
  }

  fun connect() {
    t0 = SystemClock.elapsedRealtime()
    ws =
      http.newWebSocket(
        Request.Builder().url(wsUrl).build(),
        object : WebSocketListener() {
          override fun onMessage(webSocket: WebSocket, text: String) {
            handleText(text)
          }

          override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            try {
              handleBinary(bytes.toByteArray())
            } catch (_: Throwable) {}
          }

          override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            fail("اتصال بسته شد")
          }

          override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            fail(if (response?.code == 409) "سشن پر است" else "اتصال به سرور ناموفق بود")
          }
        },
      )
    main.postDelayed(pinger, 300)
  }

  private fun fail(reason: String) {
    if (closed) return
    closed = true
    main.removeCallbacks(pinger)
    main.post { listener.onClosed(reason) }
  }

  private fun handleText(text: String) {
    try {
      val j = JSONObject(text)
      when (j.optString("t")) {
        "hello" -> {
          connectMs = SystemClock.elapsedRealtime() - t0
          val slot = j.optInt("slot")
          val peers = j.optInt("peers")
          main.post { if (!closed) listener.onHello(slot, peers) }
        }
        "peer" -> {
          val on = j.optInt("on") == 1
          main.post { if (!closed) listener.onPeer(on) }
        }
        "k" -> {
          val c = j.optInt("c")
          val d = j.optInt("d") == 1
          val s = j.optLong("s", -1L)
          val now = SystemClock.elapsedRealtime()
          var wait = 0L
          if (s > 0) {
            addOffset(now - s)
            val mo = minOffset()
            if (mo != null) {
              var due = s + mo + JITTER_BUFFER_MS
              due = maxOf(due, lastRemoteDue) // keep the order of his keys
              due = minOf(due, now + 300L) // never hold a key back for long, even if the clocks look odd
              lastRemoteDue = due
              wait = (due - now).coerceAtLeast(0L)
            }
          }
          val run = Runnable { if (!closed) listener.onKey(c, d) }
          if (wait <= 0L) main.post(run) else main.postDelayed(run, wait)
        }
        "p" -> {
          val ts = j.optLong("ts")
          if (ts > 0) addOffset(SystemClock.elapsedRealtime() - ts)
          ws?.send("""{"t":"q","ts":$ts}""")
        }
        "s" -> {
          val rtt = SystemClock.elapsedRealtime() - j.optLong("ts")
          main.post { if (!closed) listener.onServerPing(rtt) }
        }
        "q" -> {
          val rtt = SystemClock.elapsedRealtime() - j.optLong("ts")
          // While a save-state is travelling, pings are delayed behind it. Use the low quartile of the
          // last samples, so those spikes change neither the shown ping nor the input delay.
          val low =
            synchronized(rtts) {
              rtts.addLast(rtt)
              if (rtts.size > 9) rtts.removeFirst()
              rtts.sorted()[(rtts.size - 1) / 4]
            }
          oneWayMs = (low / 2).coerceIn(15L, 150L)
          synchronized(rttLong) {
            rttLong.addLast(rtt)
            if (rttLong.size > 30) rttLong.removeFirst()
            val sorted = rttLong.sorted()
            delayRttMs = sorted[(sorted.size - 1) * 3 / 4]
            rttJitterMs =
              if (rttLong.size < 2) 0L
              else rttLong.zipWithNext { a, b -> kotlin.math.abs(a - b) }.average().toLong()
          }
          main.post { if (!closed) listener.onPing(low) }
        }
        "nm" -> {
          val nm = j.optString("n")
          if (nm.isNotBlank()) main.post { if (!closed) listener.onPeerName(nm) }
        }
        "lslog" -> {
          // Diagnostic log from the other phone: deflated + base64, split in text frames.
          val id = j.optInt("id")
          val i = j.optInt("i")
          val n = j.optInt("n")
          val d = j.optString("d")
          if (n in 1..2000 && i in 0 until n) {
            if (id != logAsmId || logAsmParts.size != n) {
              logAsmId = id
              logAsmParts = arrayOfNulls(n)
              logAsmCount = 0
            }
            if (logAsmParts[i] == null) {
              logAsmParts[i] = d
              logAsmCount++
            }
            if (logAsmCount == n) {
              val b64 = logAsmParts.joinToString("") { it ?: "" }
              logAsmParts = arrayOfNulls(0)
              logAsmId = -1
              val text =
                try {
                  String(inflate(android.util.Base64.decode(b64, android.util.Base64.NO_WRAP)), Charsets.UTF_8)
                } catch (_: Throwable) {
                  ""
                }
              if (text.isNotEmpty()) main.post { if (!closed) listener.onPeerLog(text) }
            }
          }
        }
        "chat" -> {
          val m = j.optString("m")
          if (m.isNotBlank()) main.post { if (!closed) listener.onChat(m) }
        }
        "cmd" -> {
          val a = j.optString("a")
          if (a == "needfull") forceFull = true // the friend could not apply my delta: next state is a full one
          main.post { if (!closed) listener.onCmd(a) }
        }
        "r" ->
          if (romKey.isNotEmpty()) {
            // (I have no game yet -> ignore; the friend's check happens when I pick one.)
            if (j.optString("k") != romKey) main.post { if (!closed) listener.onRomMismatch() }
            else main.post { if (!closed) listener.onRomOk() }
            if (!j.optBoolean("re")) sendRom(true) // answer once so the sender gets my game too
          }
      }
    } catch (_: Throwable) {}
  }

  private val pinger =
    object : Runnable {
      override fun run() {
        if (closed) return
        ws?.send("""{"t":"p","ts":${SystemClock.elapsedRealtime()}}""")
        main.postDelayed(this, 1000)
      }
    }

  /** Lockstep: send one frame of button mask. Packet: [2][session:1][frame:4 LE][mask:2 LE] */
  fun sendFrameInput(frame: Int, mask: Int) {
    val b = ByteArray(8)
    b[0] = 2
    b[1] = (lockstepSession and 0xff).toByte()
    putInt(b, 2, frame)
    b[6] = (mask and 0xff).toByte()
    b[7] = ((mask shr 8) and 0xff).toByte()
    ws?.send(b.toByteString())
  }

  /** Lockstep desync check: [3][session:1][frame:4 BE][hash:4 BE] */
  fun sendFrameHash(frame: Int, hash: Int) {
    val b = ByteArray(10)
    b[0] = 3
    b[1] = (lockstepSession and 0xff).toByte()
    putInt(b, 2, frame)
    putInt(b, 6, hash)
    ws?.send(b.toByteString())
  }

  fun sendKey(code: Int, down: Boolean) {
    ws?.send("""{"t":"k","c":$code,"d":${if (down) 1 else 0},"s":${SystemClock.elapsedRealtime()}}""")
  }

  fun sendCmd(action: String) {
    LockstepLogger.cmd("TX", action)
    ws?.send("""{"t":"cmd","a":"$action"}""")
  }

  /** Bytes waiting in our own socket queue (diagnostics: a growing value = slow uplink or relay). */
  fun queueBytes(): Long = ws?.queueSize() ?: 0L

  fun sendName(name: String) {
    ws?.send(JSONObject().put("t", "nm").put("n", name.take(20)).toString())
  }

  // ---- diagnostic log transfer (this phone -> the other one) ----
  private var logSendId = 0
  private var logAsmId = -1
  private var logAsmParts: Array<String?> = arrayOfNulls(0)
  private var logAsmCount = 0

  /** Called from a background thread: sends a whole text file (deflated, base64, 12 KB text frames). The relay just forwards text. */
  fun sendLog(text: String) {
    val b64 = android.util.Base64.encodeToString(deflate(text.toByteArray(Charsets.UTF_8)), android.util.Base64.NO_WRAP)
    val size = 12_000
    val total = (b64.length + size - 1) / size
    val id = ++logSendId
    for (i in 0 until total) {
      val w = ws ?: return
      if (closed) return
      val part = b64.substring(i * size, minOf(b64.length, (i + 1) * size))
      var waited = 0
      while (w.queueSize() > QUEUE_LIMIT && !closed && waited < 3000) {
        Thread.sleep(2)
        waited += 2
      }
      w.send(JSONObject().put("t", "lslog").put("id", id).put("i", i).put("n", total).put("d", part).toString())
    }
  }

  fun sendChat(text: String) {
    ws?.send(JSONObject().put("t", "chat").put("m", text.take(300)).toString())
  }

  fun sendRom(reply: Boolean = false) {
    if (romKey.isEmpty()) return
    ws?.send("""{"t":"r","k":"$romKey"${if (reply) ""","re":true""" else ""}}""")
  }

  /** Called from a background thread. Delta against the previous state when possible, then sent in small paced chunks. */
  fun sendState(raw: ByteArray) {
    val prev = sentPrev
    val delta = prev != null && !forceFull && prev.size == raw.size
    forceFull = false
    val base = if (delta) sentId else 0
    val id = ++sentId
    sentPrev = raw
    val payload = deflate(if (delta) xor(raw, prev!!) else raw)
    val total = (payload.size + CHUNK - 1) / CHUNK
    for (i in 0 until total) {
      val w = ws ?: return
      if (closed) return
      val from = i * CHUNK
      val len = minOf(CHUNK, payload.size - from)
      val f = ByteArray(13 + len)
      f[0] = 1
      putInt(f, 1, id)
      f[5] = (i shr 8).toByte()
      f[6] = i.toByte()
      f[7] = (total shr 8).toByte()
      f[8] = total.toByte()
      putInt(f, 9, base)
      System.arraycopy(payload, from, f, 13, len)
      // Do not pile chunks up in the send queue: a key press must never wait behind a long line of them.
      var waited = 0
      while (w.queueSize() > QUEUE_LIMIT && !closed && waited < 3000) {
        Thread.sleep(2)
        waited += 2
      }
      w.send(f.toByteString())
    }
  }

  private fun handleBinary(b: ByteArray) {
    if (b.isEmpty()) return
    when (b[0].toInt() and 0xff) {
      2 -> { // lockstep input: [2][session:1][frame:4][mask:2]
        if (b.size >= 8) {
          val session = b[1].toInt() and 0xff
          if (session != (lockstepSession and 0xff)) return // Drop packets from stale sessions
          val frame = getInt(b, 2)
          val mask = (b[6].toInt() and 0xff) or ((b[7].toInt() and 0xff) shl 8)
          main.post { if (!closed) listener.onFrameInput(frame, mask) }
        }
        return
      }
      3 -> { // lockstep hash: [3][session:1][frame:4][hash:4]
        if (b.size >= 10) {
          val session = b[1].toInt() and 0xff
          if (session != (lockstepSession and 0xff)) return // Drop packets from stale sessions
          val frame = getInt(b, 2)
          val hash = getInt(b, 6)
          main.post { if (!closed) listener.onFrameHash(frame, hash) }
        }
        return
      }
    }
    if (b.size < 13 || b[0] != 1.toByte()) { // old format: one deflated state
      val raw = inflate(b)
      main.post { if (!closed) listener.onState(raw) }
      return
    }
    val id = getInt(b, 1)
    val idx = ((b[5].toInt() and 0xff) shl 8) or (b[6].toInt() and 0xff)
    val total = ((b[7].toInt() and 0xff) shl 8) or (b[8].toInt() and 0xff)
    val base = getInt(b, 9)
    if (total <= 0 || total > 8000 || idx >= total) return
    if (id < asmId) return // an older state, already replaced
    if (id > asmId) {
      asmId = id
      asmBase = base
      asmParts = arrayOfNulls(total)
      asmCount = 0
    }
    if (asmParts.size != total || asmParts[idx] != null) return
    asmParts[idx] = b.copyOfRange(13, b.size)
    asmCount++
    if (asmCount < total) return
    val o = ByteArrayOutputStream()
    for (p in asmParts) o.write(p!!)
    asmParts = arrayOfNulls(0)
    val out = inflate(o.toByteArray())
    val raw: ByteArray? =
      if (asmBase == 0) out
      else {
        val last = recvLast
        if (last != null && recvId == asmBase && last.size == out.size) xor(out, last) else null
      }
    if (raw == null) {
      ws?.send("""{"t":"cmd","a":"needfull"}""") // I missed the state this one builds on
      return
    }
    recvLast = raw
    recvId = id
    main.post { if (!closed) listener.onState(raw) }
  }

  private fun xor(a: ByteArray, b: ByteArray): ByteArray {
    val o = ByteArray(a.size)
    for (i in a.indices) o[i] = (a[i].toInt() xor b[i].toInt()).toByte()
    return o
  }

  private fun putInt(b: ByteArray, at: Int, v: Int) {
    b[at] = (v ushr 24).toByte()
    b[at + 1] = (v ushr 16).toByte()
    b[at + 2] = (v ushr 8).toByte()
    b[at + 3] = v.toByte()
  }

  private fun getInt(b: ByteArray, at: Int): Int =
    ((b[at].toInt() and 0xff) shl 24) or ((b[at + 1].toInt() and 0xff) shl 16) or
      ((b[at + 2].toInt() and 0xff) shl 8) or (b[at + 3].toInt() and 0xff)

  fun close() {
    closed = true
    main.removeCallbacks(pinger)
    try {
      ws?.close(1000, "bye")
    } catch (_: Throwable) {}
    http.dispatcher.executorService.shutdown()
  }

  private fun deflate(b: ByteArray): ByteArray {
    val o = ByteArrayOutputStream()
    DeflaterOutputStream(o).use { it.write(b) }
    return o.toByteArray()
  }

  private fun inflate(b: ByteArray): ByteArray = InflaterInputStream(ByteArrayInputStream(b)).use { it.readBytes() }
}

/**
 * Measures the relay regions. The first letter of a room code tells the worker where to place the
 * room (see worker.js: M = Middle East, W = Western Europe, E = Eastern Europe).
 */
object NetplayProbe {
  /** ms = median round trip, jitterMs = average change between samples, lossPct = failed requests. */
  class Result(val letter: Char, val name: String, val ms: Long?, val jitterMs: Long, val lossPct: Int) {
    /** Lower is better: latency plus a heavy penalty for instability and loss. */
    val score: Long get() = if (ms == null) Long.MAX_VALUE else ms + jitterMs * 3 + lossPct * 8L
  }

  // Middle East only. (Rooms whose code starts with another letter still connect: the worker routes by that letter.)
  private val regions = listOf('M' to "خاورمیانه")
  private val keys = mapOf('M' to "me")
  private const val SAMPLES = 3
  private const val WS_SAMPLES = 5

  fun regionName(code: String): String? = regions.firstOrNull { it.first == code.firstOrNull() }?.second

  /** The regions in display order (letter to name), so the UI can list them before any result arrives. */
  fun regionList(): List<Pair<Char, String>> = regions

  /**
   * Latency + stability of every region. All regions are measured in parallel and each result is
   * reported through [onResult] (on the main thread) the moment it is ready, so the list fills in
   * within a second or two instead of after one long sequential run.
   */
  suspend fun measure(baseUrl: String, onResult: (Result) -> Unit = {}): List<Result> =
    withContext(Dispatchers.IO) {
      val base = baseUrl.trim().trimEnd('/')
      kotlinx.coroutines.coroutineScope {
        regions.map { (letter, name) ->
          async {
            // Own client per region = own kept-alive connection, so samples measure the round
            // trip and not TLS setup.
            val client =
              OkHttpClient.Builder()
                .socketFactory(NoDelaySocketFactory())
                .connectTimeout(3, TimeUnit.SECONDS)
                .readTimeout(2, TimeUnit.SECONDS)
                .build()

            fun hit(): Long? {
              val t0 = SystemClock.elapsedRealtime()
              return try {
                val req = Request.Builder().url("$base/probe?r=${keys[letter]}&n=${System.nanoTime()}").build()
                client.newCall(req).execute().use { if (!it.isSuccessful) return null }
                SystemClock.elapsedRealtime() - t0
              } catch (_: Throwable) {
                null
              }
            }

            // Real ping = WebSocket round trip, exactly what the room shows once it is created.
            // (The plain HTTP request is only a fallback: it carries extra Worker overhead and reads too high.)
            val samples: List<Long?> =
              wsRtts(base, letter, WS_SAMPLES) ?: run {
                hit() // open the connection + wake the room object (not counted)
                (1..SAMPLES).map { hit() }
              }
            val ok = samples.filterNotNull()
            val median = ok.sorted().getOrNull(ok.size / 2)
            val jitter = if (ok.size < 2) 0L else ok.zipWithNext { x, y -> kotlin.math.abs(x - y) }.average().toLong()
            val loss = (samples.size - ok.size) * 100 / samples.size
            val r = Result(letter, name, median, jitter, loss)
            withContext(Dispatchers.Main) { onResult(r) }
            r
          }
        }.awaitAll()
      }
    }

  /**
   * Opens a throw-away WebSocket to a random room of the region and times [n] ping/echo round trips
   * (the first one is a warm-up and not counted). null = the socket could not be used (caller falls back to HTTP).
   */
  private fun wsRtts(base: String, letter: Char, n: Int): List<Long?>? {
    val wsBase =
      when {
        base.startsWith("https://") -> "wss://" + base.removePrefix("https://")
        base.startsWith("http://") -> "ws://" + base.removePrefix("http://")
        else -> base
      }
    val chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
    val code = letter.toString() + (1..4).map { chars.random() }.joinToString("")
    val client =
      OkHttpClient.Builder()
        .socketFactory(NoDelaySocketFactory())
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
    val opened = java.util.concurrent.CountDownLatch(1)
    val echoes = java.util.concurrent.LinkedBlockingQueue<Long>()
    val ok = java.util.concurrent.atomic.AtomicBoolean(false)
    val ws =
      client.newWebSocket(
        Request.Builder().url("$wsBase/ws?room=$code").build(),
        object : WebSocketListener() {
          override fun onOpen(webSocket: WebSocket, response: Response) {
            ok.set(true)
            opened.countDown()
          }

          override fun onMessage(webSocket: WebSocket, text: String) {
            try {
              val j = JSONObject(text)
              if (j.optString("t") == "s") echoes.offer(SystemClock.elapsedRealtime() - j.optLong("ts"))
            } catch (_: Throwable) {}
          }

          override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            opened.countDown()
          }
        },
      )
    return try {
      if (!opened.await(5, TimeUnit.SECONDS) || !ok.get()) return null
      val out = ArrayList<Long?>()
      var gotAny = false
      for (i in 0..n) {
        echoes.clear()
        ws.send("""{"t":"p","ts":${SystemClock.elapsedRealtime()}}""")
        val v = echoes.poll(1500, TimeUnit.MILLISECONDS)
        if (v != null) gotAny = true
        if (i > 0) out.add(v)
      }
      if (!gotAny) null else out
    } catch (_: Throwable) {
      null
    } finally {
      try {
        ws.close(1000, "probe")
      } catch (_: Throwable) {}
      client.dispatcher.executorService.shutdown()
    }
  }

  /** The most stable region (best score), or null if none answered. */
  fun best(results: List<Result>): Result? = results.filter { it.ms != null }.minByOrNull { it.score }
}

/** Plain sockets with Nagle's algorithm switched off (TCP_NODELAY), so small realtime packets leave immediately. */
class NoDelaySocketFactory(private val d: SocketFactory = SocketFactory.getDefault()) : SocketFactory() {
  private fun Socket.fast(): Socket = apply { try { tcpNoDelay = true } catch (_: Throwable) {} }

  override fun createSocket(): Socket = d.createSocket().fast()

  override fun createSocket(host: String?, port: Int): Socket = d.createSocket(host, port).fast()

  override fun createSocket(host: String?, port: Int, localHost: InetAddress?, localPort: Int): Socket =
    d.createSocket(host, port, localHost, localPort).fast()

  override fun createSocket(host: InetAddress?, port: Int): Socket = d.createSocket(host, port).fast()

  override fun createSocket(address: InetAddress?, port: Int, localAddress: InetAddress?, localPort: Int): Socket =
    d.createSocket(address, port, localAddress, localPort).fast()
}
