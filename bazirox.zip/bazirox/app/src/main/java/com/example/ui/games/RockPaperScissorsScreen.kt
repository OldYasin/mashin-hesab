package com.example.ui.games

import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import com.example.ui.components.pressScale
import com.example.ui.components.popIn
import com.example.ui.components.appear
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameType
import com.example.data.OnlineRoom
import com.example.data.PlayMode
import com.example.data.Sfx
import com.example.data.SoundManager
import com.example.ui.components.GameTopBar
import com.example.ui.components.LocalGameHud
import com.example.ui.components.PublishRoomHud
import com.example.ui.components.GameArea
import com.example.ui.components.GameTurnTimer
import com.example.ui.components.rememberTurnCountdown
import com.example.ui.components.fitBoard
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.WinCelebrationBanner
import com.example.ui.components.ArcadeGameBackdrop
import com.example.ui.components.animatedOceanGameBackdrop
import com.example.ui.components.oceanGameBackdrop
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPulse
import com.example.ui.components.ConfirmLeaveBackHandler
import com.example.ui.components.rememberRestartGuard
import com.example.ui.components.toFaDigits
import kotlinx.coroutines.delay
import org.json.JSONObject
import kotlin.random.Random

private const val RPS_WIN_SCORE = 3
private const val RPS_TURN_SECONDS = 15
private val RpsEmoji = listOf("✊", "✋", "✌️") // 0 = rock, 1 = paper, 2 = scissors
private val RpsName = listOf("سنگ", "کاغذ", "قیچی")
private val RpsColor = listOf(CyberGold, NeonCyan, CrimsonMagenta)

/** @return 0 = draw, 1 = first wins, 2 = second wins */
private fun rpsOutcome(a: Int, b: Int): Int =
  when {
    a == b -> 0
    (a == 0 && b == 2) || (a == 1 && b == 0) || (a == 2 && b == 1) -> 1
    else -> 2
  }

private fun faNum(n: Int): String = n.toFaDigits()

/**
 * Rock-Paper-Scissors, first to [RPS_WIN_SCORE] round wins.
 *
 * Online sync: the HOST is authoritative for scores/rounds. Each side writes its own pick into the
 * shared state; the host resolves the round once both picks are in. Picks are re-sent until the
 * room shows them (writes are last-write-wins), so a lost write never freezes a round.
 */
/** One side of the arena: a rounded tile with a modest emoji, a result-coloured rim and the player's name. */
private val RpsSubHint = listOf("برنده برابر قیچی", "برنده برابر سنگ", "برنده برابر کاغذ")

@Composable
private fun HandTile(
  emoji: String?,
  label: String,
  tone: Color,
  dim: Boolean,
  popKey: Any,
  modifier: Modifier = Modifier,
) {
  val bob by
    androidx.compose.animation.core.rememberInfiniteTransition(label = "handBob")
      .animateFloat(
        0f,
        1f,
        androidx.compose.animation.core.infiniteRepeatable(
          androidx.compose.animation.core.tween(900, easing = androidx.compose.animation.core.FastOutSlowInEasing),
          androidx.compose.animation.core.RepeatMode.Reverse,
        ),
        label = "bob",
      )
  Column(
    modifier = modifier,
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    Box(
      modifier =
        Modifier.size(96.dp)
          .graphicsLayer { translationY = if (emoji == null) -bob * 6.dp.toPx() else 0f }
          .popIn(popKey, from = 0.6f, skipInitial = true),
      contentAlignment = Alignment.Center,
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        drawCircle(
          brush = Brush.radialGradient(
            listOf(tone.copy(alpha = if (dim) 0.08f else 0.34f), Color.Transparent),
          ),
          radius = size.minDimension * 0.56f,
        )
      }
      Box(
        modifier =
          Modifier.size(86.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(
              Brush.verticalGradient(
                listOf(
                  tone.copy(alpha = if (dim) 0.08f else 0.26f),
                  Color(0xFF0C1324).copy(alpha = 0.90f),
                )
              )
            )
            .border(
              1.6.dp,
              Brush.linearGradient(
                listOf(
                  tone.copy(alpha = if (dim) 0.22f else 0.85f),
                  Color.White.copy(alpha = if (dim) 0.06f else 0.22f),
                )
              ),
              RoundedCornerShape(26.dp),
            ),
        contentAlignment = Alignment.Center,
      ) {
        if (emoji != null) Text(emoji, fontSize = 42.sp)
        else Text("؟", fontSize = 38.sp, color = TextSecondary.copy(alpha = 0.85f), fontWeight = FontWeight.ExtraBold)
      }
    }
    if (label.isNotBlank()) {
      Text(
        label,
        style = MaterialTheme.typography.labelLarge,
        color = if (dim) TextSecondary.copy(alpha = 0.55f) else TextPrimary,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
      )
    }
  }
}

@Composable
fun RockPaperScissorsScreen(
  playMode: PlayMode,
  room: OnlineRoom?,
  currentUsername: String,
  onPushOnlineState: (String, String) -> Unit,
  onRecordResult: (Boolean, Int) -> Unit,
  onBack: () -> Unit,
) {

  val online = playMode == PlayMode.ONLINE_ROOM && room != null
  val mySide =
    remember(room, currentUsername) {
      if (!online) 0 else if (room!!.hostUsername.equals(currentUsername, ignoreCase = true)) 0 else 1
    }
  val isHost = mySide == 0

  val names =
    remember(room, playMode) {
      when (playMode) {
        PlayMode.VS_AI -> listOf("شما", "ربات")
        PlayMode.LOCAL_PASS_AND_PLAY -> listOf("بازیکن ۱", "بازیکن ۲")
        PlayMode.ONLINE_ROOM ->
          listOf(room?.players?.getOrNull(0) ?: "میزبان", room?.players?.getOrNull(1) ?: "در انتظار...")
      }
    }

  // Authoritative (host / offline) state
  var s0 by remember { mutableIntStateOf(0) }
  var s1 by remember { mutableIntStateOf(0) }
  var round by remember { mutableIntStateOf(1) }
  var winner by remember { mutableIntStateOf(-1) }
  ConfirmLeaveBackHandler(gameOver = winner != -1, onLeave = onBack)
  var last0 by remember { mutableIntStateOf(-1) }
  var last1 by remember { mutableIntStateOf(-1) }
  var lastRes by remember { mutableIntStateOf(-1) } // 0 draw, 1 side0 won, 2 side1 won, -1 none
  // Current round picks (-1 = not yet)
  var pick0 by remember { mutableIntStateOf(-1) }
  var pick1 by remember { mutableIntStateOf(-1) }
  var secondsLeft by remember { mutableIntStateOf(RPS_TURN_SECONDS) }
  var showReveal by remember { mutableStateOf(false) }
  var recorded by remember { mutableStateOf(false) }
  var hint by remember { mutableStateOf("مشتت را قایم کن!") }

  fun pushState(c0: Int, c1: Int, status: String? = null) {
    if (!online) return
    val j =
      JSONObject().apply {
        put("s0", s0); put("s1", s1); put("round", round); put("winner", winner)
        put("l0", last0); put("l1", last1); put("lr", lastRes)
        put("c0", c0); put("c1", c1)
      }
    onPushOnlineState(j.toString(), status ?: if (winner == -1) "playing" else "finished")
  }

  fun resolveRound(a: Int, b: Int) {
    last0 = a
    last1 = b
    lastRes = rpsOutcome(a, b)
    if (lastRes == 1) s0++ else if (lastRes == 2) s1++
    round++
    pick0 = -1
    pick1 = -1
    winner = if (s0 >= RPS_WIN_SCORE) 0 else if (s1 >= RPS_WIN_SCORE) 1 else -1
    hint =
      when (lastRes) {
        0 -> "مساوی شد!"
        else -> "${names[lastRes - 1]} این دست را برد"
      }
    showReveal = true
    pushState(-1, -1)
  }

  fun resetAll() {
    s0 = 0; s1 = 0; round = 1; winner = -1
    last0 = -1; last1 = -1; lastRes = -1
    pick0 = -1; pick1 = -1
    recorded = false
    showReveal = false
    hint = "مشتت را قایم کن!"
    secondsLeft = RPS_TURN_SECONDS
    pushState(-1, -1, "playing")
  }

  // ---------------------------------------------------------------- online sync
  var lastSeenRound by remember { mutableIntStateOf(1) }
  LaunchedEffect(room?.version, room?.stateJson) {
    if (!online || room == null || room.stateJson.length <= 4) return@LaunchedEffect
    try {
      val j = JSONObject(room.stateJson)
      if (!j.has("round")) return@LaunchedEffect
      val rRound = j.optInt("round", 1)
      if (isHost) {
        // The host keeps its own authoritative copy and only learns the guest's pick.
        if (rRound == round && winner == -1) {
          val g = j.optInt("c1", -1)
          if (g >= 0 && pick1 < 0) pick1 = g
          if (pick0 >= 0 && pick1 >= 0) resolveRound(pick0, pick1)
        }
      } else {
        // Guest mirrors the host's state.
        val newWinner = j.optInt("winner", -1)
        val roundChanged = rRound != round
        s0 = j.optInt("s0", 0)
        s1 = j.optInt("s1", 0)
        last0 = j.optInt("l0", -1)
        last1 = j.optInt("l1", -1)
        lastRes = j.optInt("lr", -1)
        winner = newWinner
        if (roundChanged) {
          round = rRound
          pick0 = -1
          pick1 = -1
          if (lastRes >= 0) {
            hint = if (lastRes == 0) "مساوی شد!" else "${names[lastRes - 1]} این دست را برد"
            showReveal = true
          } else {
            hint = "مشتت را قایم کن!"
            showReveal = false
          }
          if (newWinner == -1) recorded = false
        }
      }
      lastSeenRound = rRound
    } catch (_: Throwable) {}
  }

  // Host: first time in the room, publish the initial state.
  LaunchedEffect(Unit) {
    if (online && isHost && (room?.stateJson?.length ?: 0) <= 4) pushState(-1, -1, "playing")
  }

  // Re-send my pick until the room shows it (writes are last-write-wins and may overwrite each other).
  val myPick = if (mySide == 0) pick0 else pick1
  LaunchedEffect(myPick, round, room?.version) {
    if (!online || myPick < 0 || winner != -1) return@LaunchedEffect
    delay(1500)
    try {
      val j = JSONObject(room?.stateJson ?: "{}")
      val key = if (mySide == 0) "c0" else "c1"
      if (j.optInt("round", -1) == round && j.optInt(key, -1) != myPick && myPick >= 0) {
        if (isHost) pushState(pick0, pick1) else {
          j.put(key, myPick)
          onPushOnlineState(j.toString(), "playing")
        }
      }
    } catch (_: Throwable) {}
  }
  // Host: if the guest overwrote the room with an older round, re-assert the authoritative state.
  LaunchedEffect(room?.version) {
    if (!online || !isHost || room == null || room.stateJson.length <= 4) return@LaunchedEffect
    try {
      val j = JSONObject(room.stateJson)
      if (j.has("round") && j.optInt("round", 1) < round) {
        delay(300)
        pushState(pick0, pick1)
      }
    } catch (_: Throwable) {}
  }

  // ---------------------------------------------------------------- picking
  fun submitPick(side: Int, choice: Int) {
    if (winner != -1 || showReveal) return
    when (playMode) {
      PlayMode.VS_AI -> {
        if (pick0 >= 0) return
        pick0 = choice
        hint = "..."
        resolveRound(choice, Random.nextInt(3))
      }
      PlayMode.LOCAL_PASS_AND_PLAY -> {
        if (side == 0 && pick0 < 0) {
          pick0 = choice
          hint = "حالا نوبت ${names[1]} است"
          secondsLeft = RPS_TURN_SECONDS
        } else if (side == 1 && pick0 >= 0 && pick1 < 0) {
          pick1 = choice
          resolveRound(pick0, choice)
        }
      }
      PlayMode.ONLINE_ROOM -> {
        if (mySide == 0) {
          if (pick0 >= 0) return
          pick0 = choice
          hint = "منتظر حریف..."
          if (pick1 >= 0) resolveRound(pick0, pick1) else pushState(pick0, pick1)
        } else {
          if (pick1 >= 0) return
          pick1 = choice
          hint = "منتظر حریف..."
          try {
            val j = JSONObject(room?.stateJson ?: "{}")
            j.put("c1", choice)
            if (!j.has("round")) j.put("round", round)
            onPushOnlineState(j.toString(), "playing")
          } catch (_: Throwable) {}
        }
      }
    }
  }

  val localSide = if (playMode == PlayMode.LOCAL_PASS_AND_PLAY) (if (pick0 < 0) 0 else 1) else mySide
  val canPick =
    winner == -1 &&
      !showReveal &&
      when (playMode) {
        PlayMode.VS_AI -> pick0 < 0
        PlayMode.LOCAL_PASS_AND_PLAY -> pick1 < 0
        PlayMode.ONLINE_ROOM -> (room?.players?.size ?: 0) >= 2 && myPick < 0
      }

  // Reveal banner lasts a moment, then the next round starts.
  LaunchedEffect(showReveal, round) {
    if (showReveal) {
      delay(1900)
      showReveal = false
      if (winner == -1) hint = "مشتت را قایم کن!"
    }
  }

  // Countdown; on timeout a random pick is made for whoever still has to choose.
  LaunchedEffect(round, winner, pick0, showReveal) {
    if (winner != -1 || showReveal) return@LaunchedEffect
    secondsLeft = RPS_TURN_SECONDS
    while (secondsLeft > 0) {
      delay(1000)
      secondsLeft--
    }
    if (canPick) submitPick(localSide, Random.nextInt(3))
  }

  // ---------------------------------------------------------------- sound
  LaunchedEffect(round) {
    if (round > 1 || lastRes >= 0) SoundManager.play(Sfx.TAP)
  }
  var resultSoundPlayed by remember { mutableStateOf(false) }
  LaunchedEffect(winner) {
    if (winner == -1) {
      resultSoundPlayed = false
    } else if (!resultSoundPlayed) {
      resultSoundPlayed = true
      delay(500)
      val mine = if (playMode == PlayMode.ONLINE_ROOM) mySide else 0
      SoundManager.play(if (winner == mine) Sfx.WIN else Sfx.LOSE)
    }
  }
  LaunchedEffect(winner) {
    if (winner != -1 && !recorded) {
      recorded = true
      val mine = if (playMode == PlayMode.ONLINE_ROOM) mySide else 0
      onRecordResult(winner == mine, if (winner == mine) 30 else 8)
    }
  }

  val activeBackdropColor = when {
    winner != -1 -> if (winner == (if (playMode == PlayMode.ONLINE_ROOM) mySide else 0)) ElectricEmerald else CrimsonMagenta
    pick0 >= 0 && pick1 < 0 -> CrimsonMagenta
    pick0 < 0 && pick1 >= 0 -> NeonCyan
    else -> VioletPulse
  }

  // ---------------------------------------------------------------- UI
  ArcadeGameBackdrop(accentColor = activeBackdropColor) {
  Column(
    modifier = Modifier.fillMaxSize().systemBarsPadding(),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {

    GameTopBar(
      title = GameType.ROCK_PAPER_SCISSORS.titleFa,
      subtitle =
        when (playMode) {
          PlayMode.VS_AI -> "در برابر هوش مصنوعی"
          PlayMode.LOCAL_PASS_AND_PLAY -> "دو نفره آفلاین"
          PlayMode.ONLINE_ROOM -> "اتاق آنلاین: ${room?.roomCode ?: "-"}"
        },
      accentColor = VioletPulse,
      onBack = onBack,
      copyText = if (playMode == PlayMode.ONLINE_ROOM) room?.roomCode else null,
      trailingContent = {
        if (!online || isHost) {
          val askRestart = rememberRestartGuard(gameOver = winner != -1) { resetAll() }
          IconButton(onClick = askRestart, modifier = Modifier.testTag("rps_reset_button")) {
            Icon(Icons.Rounded.Refresh, contentDescription = "شروع مجدد", tint = VioletPulse)
          }
        }
      },
    )

    val hudOn = LocalGameHud.current != null
    run {
      val waiting = winner == -1 && !showReveal
      PublishRoomHud(
        room = room,
        activeSeat = -1,
        activeSeats = buildSet {
          if (waiting && pick0 < 0) add(0)
          if (waiting && pick1 < 0) add(1)
        },
        scores = listOf(
          faNum(s0) + if (waiting && pick0 >= 0) " ✓" else "",
          faNum(s1) + if (waiting && pick1 >= 0) " ✓" else "",
        ),
        labelMe = "انتخاب کن!",
        labelOther = "در حال انتخاب…",
      )
    }
    GameArea(maxWidth = 600.dp) {
      GameTurnTimer(secondsLeft, VioletPulse, label = "دست ${faNum(round.coerceAtMost(99))}", total = RPS_TURN_SECONDS, active = winner == -1)

      // Modern Scoreboard with Round-Win Pips
      if (!hudOn) Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        for (i in 0..1) {
          val c = if (i == 0) NeonCyan else CrimsonMagenta
          val score = if (i == 0) s0 else s1
          val chosen = if (i == 0) pick0 >= 0 else pick1 >= 0
          Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color.Transparent,
            border = BorderStroke(1.dp, Brush.linearGradient(listOf(c.copy(alpha = 0.48f), Color.White.copy(alpha = 0.08f)))),
            modifier = Modifier.weight(1f),
          ) {
            Column(
              modifier =
                Modifier.fillMaxWidth()
                  .background(Brush.verticalGradient(listOf(Color(0xFF151E32), Color(0xFF0E1422))))
                  .padding(vertical = 10.dp, horizontal = 10.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                Text(
                  if (online) (if (i == mySide) "شما" else "حریف") else names[i],
                  style = MaterialTheme.typography.labelLarge,
                  color = c,
                  maxLines = 1,
                  fontWeight = FontWeight.ExtraBold,
                )
                if (winner == -1 && chosen && !showReveal) {
                  Surface(shape = RoundedCornerShape(50), color = ElectricEmerald.copy(alpha = 0.18f)) {
                    Text(
                      "آماده ✓",
                      style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                      color = ElectricEmerald,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp),
                    )
                  }
                }
              }
              Text(faNum(score), style = MaterialTheme.typography.headlineSmall, color = TextPrimary, fontWeight = FontWeight.ExtraBold)
              Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(RPS_WIN_SCORE) { pip ->
                  val filled = pip < score
                  Box(
                    modifier =
                      Modifier.size(width = 18.dp, height = 5.dp)
                        .clip(CircleShape)
                        .background(if (filled) c else Color.White.copy(alpha = 0.12f))
                  )
                }
              }
            }
          }
        }
      }

      // Hero Battle Arena
      Surface(
        shape = RoundedCornerShape(26.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, Brush.linearGradient(listOf(VioletPulse.copy(alpha = 0.50f), NeonCyan.copy(alpha = 0.20f), CrimsonMagenta.copy(alpha = 0.35f)))),
        modifier = Modifier.fillMaxWidth().appear(0),
      ) {
        Box(
          modifier =
            Modifier.fillMaxWidth()
              .background(Brush.verticalGradient(listOf(Color(0xFF161F35), Color(0xFF0E1525))))
        ) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp, horizontal = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceEvenly,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              val show = (showReveal || winner != -1) && last0 >= 0 && last1 >= 0
              fun tone(side: Int): Color =
                if (!show) VioletPulse
                else when {
                  lastRes == 0 -> CyberGold
                  lastRes == side + 1 -> ElectricEmerald
                  else -> CrimsonMagenta
                }
              HandTile(
                emoji = if (show) RpsEmoji[last0] else null,
                label = if (online) "" else names[0],
                tone = tone(0),
                dim = show && lastRes == 2,
                popKey = "$show$last0$round",
                modifier = Modifier.weight(1f),
              )

              Box(
                modifier =
                  Modifier.size(44.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(VioletPulse.copy(alpha = 0.30f), Color(0xFF151E33))))
                    .border(1.dp, Color.White.copy(alpha = 0.18f), CircleShape),
                contentAlignment = Alignment.Center,
              ) {
                Text(
                  "VS",
                  style = MaterialTheme.typography.labelLarge,
                  color = Color.White,
                  fontWeight = FontWeight.ExtraBold,
                )
              }

              HandTile(
                emoji = if (show) RpsEmoji[last1] else null,
                label = if (online) "" else names[1],
                tone = tone(1),
                dim = show && lastRes == 1,
                popKey = "$show$last1$round",
                modifier = Modifier.weight(1f),
              )
            }

            Surface(
              shape = RoundedCornerShape(50),
              color = Color(0xFF0A101C),
              border = BorderStroke(0.6.dp, Color.White.copy(alpha = 0.08f)),
            ) {
              Text(
                hint,
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 7.dp),
              )
            }
            if (playMode == PlayMode.LOCAL_PASS_AND_PLAY && winner == -1 && !showReveal) {
              Text(
                "نوبت ${names[localSide]} — دیگری چشمش را ببندد!",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary,
              )
            }
          }
        }
      }

      // Three Modern Choice Arcade Cards
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        for (i in 0..2) {
          val picked = myPick == i && playMode == PlayMode.ONLINE_ROOM
          val accent = RpsColor[i]
          val src = remember { MutableInteractionSource() }
          Surface(
            onClick = { submitPick(localSide, i) },
            interactionSource = src,
            enabled = canPick,
            shape = RoundedCornerShape(22.dp),
            color = Color.Transparent,
            border =
              BorderStroke(
                if (picked) 2.2.dp else 1.dp,
                Brush.verticalGradient(
                  listOf(
                    accent.copy(alpha = if (canPick || picked) 0.85f else 0.25f),
                    accent.copy(alpha = if (canPick || picked) 0.22f else 0.08f),
                  )
                ),
              ),
            modifier = Modifier.weight(1f).height(114.dp).appear(120 + i * 70).pressScale(src).testTag("rps_choice_$i"),
          ) {
            Column(
              modifier =
                Modifier.fillMaxSize()
                  .background(
                    Brush.verticalGradient(
                      listOf(
                        accent.copy(alpha = if (canPick || picked) 0.20f else 0.06f),
                        Color(0xFF0E1526),
                      )
                    )
                  )
                  .padding(vertical = 10.dp, horizontal = 6.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.SpaceBetween,
            ) {
              Box(
                modifier =
                  Modifier.size(48.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = if (canPick || picked) 0.18f else 0.08f))
                    .border(0.8.dp, accent.copy(alpha = 0.35f), CircleShape),
                contentAlignment = Alignment.Center,
              ) {
                Text(RpsEmoji[i], fontSize = 26.sp)
              }
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                  RpsName[i],
                  style = MaterialTheme.typography.titleSmall.copy(fontSize = 15.sp),
                  fontWeight = FontWeight.ExtraBold,
                  color = if (canPick || picked) Color.White else TextSecondary,
                )
                Text(
                  RpsSubHint[i],
                  style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                  color = accent.copy(alpha = 0.85f),
                  maxLines = 1,
                )
              }
            }
          }
        }
      }

      if (winner != -1) {
        val mine = if (playMode == PlayMode.ONLINE_ROOM) mySide else 0
        WinCelebrationBanner(
          winnerTitle =
            if (playMode == PlayMode.LOCAL_PASS_AND_PLAY) "${names[winner]} برنده شد!"
            else if (winner == mine) "شما برنده شدید!" else "${names[winner]} برنده شد!",
          subtitle = "نتیجه نهایی ${faNum(s0)} - ${faNum(s1)}",
          accent = if (winner == mine) VioletPulse else CyberGold,
          onRematch = {
            if (!online || isHost) resetAll() else hint = "فقط میزبان می‌تواند بازی را دوباره شروع کند"
          },
          onExit = onBack,
        )
      }
    }
  }
  }
}
