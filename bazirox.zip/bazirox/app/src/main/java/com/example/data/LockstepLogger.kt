package com.example.data

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.view.WindowManager
import java.io.File
import java.io.FileWriter
import java.io.PrintWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Lockstep diagnostics.
 *
 *  - log() only queues a line; a background thread writes the file (the emulator/main thread never waits for disk).
 *  - Per-packet lines (INPUT_TX/RX, HASH_*) are off by default (see [verbose]): they were ~240 lines/s and hid the real problem.
 *  - A METRICS line is written once per second: real fps, stall time, packet gaps, ping, jitter, send backlog.
 *  - WARN lines mark the moments that matter (stall, stuck, rx gap, low fps, ping spike, send backlog).
 *  - On stop a SUMMARY + DIAGNOSIS block is appended, and [finish] copies the file to Download/Bazirox so it can be sent.
 */
object LockstepLogger {
  private const val TAG = "LockstepDiagnostic"
  private const val MAX_LOGS = 800
  private const val KEEP_FILES = 10

  @Volatile
  var isRecording = false
    private set

  /** Per-packet lines (INPUT_TX / INPUT_RX / HASH_TX / HASH_RX). Heavy: only for a deliberate deep dive. */
  @Volatile var verbose = false

  private class Entry(val wall: Long, val elapsed: Long, val tag: String, val msg: String)

  private val pending = ConcurrentLinkedQueue<Entry>()
  private val logBuffer = ConcurrentLinkedQueue<String>()
  private val writeLock = Any()
  private val statLock = Any()
  private val df = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

  private var startTimeMs = 0L
  private var currentLogFile: File? = null
  private var writer: PrintWriter? = null
  private var thread: HandlerThread? = null
  private var handler: Handler? = null
  private val flusher =
    object : Runnable {
      override fun run() {
        drain()
        if (isRecording) handler?.postDelayed(this, 400)
      }
    }

  // ---- statistics (guarded by statLock) ----
  private var rxLastAt = 0L
  private var rxCountWin = 0
  private var rxGapMaxWin = 0L
  private var rxGapOver100 = 0
  private var rxGapOver250 = 0
  private var rxGapOver500 = 0
  private var rxGapWorst = 0L

  private val pings = ArrayList<Long>()
  private var pingBaseline = 0L

  private var tickPrevAt = 0L
  private var tickPrevFrame = -1
  private var prevStalls = 0
  private var prevStallMs = 0
  private var prevCatchUps = 0
  private var fpsSum = 0L
  private var fpsCount = 0
  private var fpsMin = Int.MAX_VALUE
  private var fpsLow = 0
  private var pausedSeconds = 0
  private var firstFrame = -1
  private var lastFrame = 0
  private var stallsLast = 0
  private var stallMsTotalLast = 0
  private var stallMsMaxLast = 0
  private var catchUpsLast = 0
  private var desyncsLast = 0
  private var diffMin = Int.MAX_VALUE
  private var diffMax = Int.MIN_VALUE
  private var dLast = 0
  private var peakQueue = 0L
  private val warns = HashMap<String, Int>()

  private var hsBeginAt = 0L
  private var hsCount = 0
  private var hsSum = 0L
  private var hsMax = 0L

  private var stateTxCount = 0
  private var stateTxBytes = 0L
  private var stateTxMsSum = 0L
  private var stateTxMsMax = 0L
  private var stateRxCount = 0
  private var stateRxLoadMsMax = 0L

  private fun resetStats() {
    synchronized(statLock) {
      rxLastAt = 0L; rxCountWin = 0; rxGapMaxWin = 0L
      rxGapOver100 = 0; rxGapOver250 = 0; rxGapOver500 = 0; rxGapWorst = 0L
      pings.clear(); pingBaseline = 0L
      tickPrevAt = 0L; tickPrevFrame = -1; prevStalls = 0; prevStallMs = 0; prevCatchUps = 0
      fpsSum = 0L; fpsCount = 0; fpsMin = Int.MAX_VALUE; fpsLow = 0; pausedSeconds = 0
      firstFrame = -1; lastFrame = 0
      stallsLast = 0; stallMsTotalLast = 0; stallMsMaxLast = 0; catchUpsLast = 0; desyncsLast = 0
      diffMin = Int.MAX_VALUE; diffMax = Int.MIN_VALUE; dLast = 0; peakQueue = 0L
      warns.clear()
      hsBeginAt = 0L; hsCount = 0; hsSum = 0L; hsMax = 0L
      stateTxCount = 0; stateTxBytes = 0L; stateTxMsSum = 0L; stateTxMsMax = 0L
      stateRxCount = 0; stateRxLoadMsMax = 0L
    }
  }

  fun start(context: Context, username: String, room: String, slot: Int, core: String, extra: String = ""): String {
    stop()
    startTimeMs = SystemClock.elapsedRealtime()
    pending.clear()
    logBuffer.clear()
    resetStats()

    val logDir = File(context.filesDir, "lockstep_logs").apply { mkdirs() }
    // keep only the newest files so the folder never grows forever
    try {
      logDir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(KEEP_FILES - 1)?.forEach { it.delete() }
    } catch (_: Throwable) {}
    val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    val file = File(logDir, "lockstep_${username}_${room}_$timeStamp.txt")
    currentLogFile = file

    try {
      synchronized(writeLock) { writer = PrintWriter(FileWriter(file, true), false) }
      isRecording = true
      thread = HandlerThread("ls-log").also { it.start() }
      handler = Handler(thread!!.looper)
      handler?.postDelayed(flusher, 400)

      val refresh =
        try {
          @Suppress("DEPRECATION")
          (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.refreshRate
        } catch (_: Throwable) {
          0f
        }
      log("HEADER", "============ BAZIROX LOCKSTEP DIAGNOSTIC LOG ============")
      log("HEADER", "User=$username Room=$room Slot=$slot Core=$core")
      log("HEADER", "Device=${Build.MANUFACTURER} ${Build.MODEL} Android=${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}) display=${refresh}Hz")
      log("HEADER", "Started=${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())} ${if (extra.isNotBlank()) extra else ""}")
      log("HEADER", "How to read: METRICS = 1 line/s | WARN = problem moment | HANDSHAKE/CMD = resync timeline | SUMMARY+DIAGNOSIS at the end")
    } catch (e: Exception) {
      Log.e(TAG, "Failed to create log file", e)
      isRecording = false
    }
    return file.absolutePath
  }

  fun log(tag: String, msg: String) {
    if (!isRecording) return
    pending.add(Entry(System.currentTimeMillis(), SystemClock.elapsedRealtime() - startTimeMs, tag, msg))
  }

  /** Per-packet detail: only written when [verbose] is on. */
  fun logV(tag: String, msg: String) {
    if (verbose) log(tag, msg)
  }

  private fun drain() {
    synchronized(writeLock) {
      val w = writer
      var e = pending.poll()
      while (e != null) {
        val line = "[" + df.format(Date(e.wall)) + " +" + e.elapsed + "ms] [" + e.tag + "] " + e.msg
        Log.d(TAG, line)
        try { w?.println(line) } catch (_: Throwable) {}
        logBuffer.add(line)
        while (logBuffer.size > MAX_LOGS) logBuffer.poll()
        e = pending.poll()
      }
      try { w?.flush() } catch (_: Throwable) {}
    }
  }

  // ------------------------------------------------------------------ event hooks

  /** A lockstep input packet arrived from the peer (call once per packet). */
  fun noteRx() {
    if (!isRecording) return
    val now = SystemClock.elapsedRealtime()
    synchronized(statLock) {
      if (rxLastAt != 0L) {
        val gap = now - rxLastAt
        if (gap > rxGapMaxWin) rxGapMaxWin = gap
        if (gap > rxGapWorst) rxGapWorst = gap
        if (gap > 100) rxGapOver100++
        if (gap > 250) rxGapOver250++
        if (gap > 500) rxGapOver500++
      }
      rxLastAt = now
      rxCountWin++
    }
  }

  fun notePing(rttMs: Long) {
    if (!isRecording) return
    synchronized(statLock) {
      if (pings.size < 5000) pings.add(rttMs)
      pingBaseline = if (pingBaseline == 0L) rttMs else (pingBaseline * 9 + rttMs) / 10
    }
  }

  fun noteStateTx(bytes: Int, ms: Long) {
    if (!isRecording) return
    synchronized(statLock) {
      stateTxCount++
      stateTxBytes += bytes
      stateTxMsSum += ms
      if (ms > stateTxMsMax) stateTxMsMax = ms
    }
    log("STATE_TX", "raw=${bytes}B sendTime=${ms}ms")
  }

  fun noteStateRx(bytes: Int, loadMs: Long) {
    if (!isRecording) return
    synchronized(statLock) {
      stateRxCount++
      if (loadMs > stateRxLoadMsMax) stateRxLoadMsMax = loadMs
    }
    log("STATE_RX", "raw=${bytes}B loadTime=${loadMs}ms")
  }

  /**
   * A save/load/resync command crossed the wire. Builds the handshake timeline:
   * the first lspause/lsinit/needfull starts the clock, lsgo stops it.
   */
  fun cmd(dir: String, action: String) {
    if (!isRecording) return
    val now = SystemClock.elapsedRealtime()
    var since = -1L
    var done = false
    synchronized(statLock) {
      val begins = action.startsWith("lspause") || action.startsWith("lsinit") || action == "needfull"
      if (begins && hsBeginAt == 0L) { hsBeginAt = now; rxLastAt = 0L }
      if (hsBeginAt != 0L) since = now - hsBeginAt
      if (action.startsWith("lsgo") && hsBeginAt != 0L) {
        hsCount++
        hsSum += since
        if (since > hsMax) hsMax = since
        hsBeginAt = 0L
        rxLastAt = 0L // the pause is not a network gap
        done = true
      }
    }
    log("CMD_$dir", action + (if (since >= 0) "  (+${since}ms since handshake start${if (done) ", HANDSHAKE DONE" else ""})" else ""))
  }

  // ------------------------------------------------------------------ 1 Hz metrics

  /**
   * Called once per second with LibretroDroid.lsStats():
   * [curFrame, peerMax, stalls, D, desyncs, stallMsTotal, stallMsMax, curStallMs, catchUps]
   */
  fun tick(stats: IntArray?, pingMs: Long, oneWayMs: Long, wsQueueBytes: Long) {
    if (!isRecording || stats == null || stats.size < 5) return
    val now = SystemClock.elapsedRealtime()
    val cur = stats[0]
    val peerMax = stats[1]
    val stalls = stats[2]
    val d = stats[3]
    val desyncs = stats[4]
    val stallMsTotal = stats.getOrElse(5) { 0 }
    val stallMsMax = stats.getOrElse(6) { 0 }
    val curStall = stats.getOrElse(7) { 0 }
    val catchUps = stats.getOrElse(8) { 0 }

    val warnList = ArrayList<String>()
    var line = ""
    synchronized(statLock) {
      val dt = if (tickPrevAt == 0L) 0L else now - tickPrevAt
      // a restart (new lsStart) resets the native counters: re-base instead of showing negative deltas
      if (cur < tickPrevFrame || stalls < prevStalls) {
        tickPrevFrame = -1; prevStalls = 0; prevStallMs = 0; prevCatchUps = 0
      }
      val fps = if (tickPrevFrame >= 0 && dt > 0) ((cur - tickPrevFrame) * 1000L / dt).toInt() else -1
      val dStalls = if (tickPrevFrame >= 0) stalls - prevStalls else 0
      val dStallMs = if (tickPrevFrame >= 0) stallMsTotal - prevStallMs else 0
      val dCatch = if (tickPrevFrame >= 0) catchUps - prevCatchUps else 0
      val diff = peerMax - cur

      if (firstFrame < 0) firstFrame = cur
      lastFrame = cur
      stallsLast = stalls; stallMsTotalLast = stallMsTotal; stallMsMaxLast = stallMsMax
      catchUpsLast = catchUps; desyncsLast = desyncs; dLast = d
      if (diff < diffMin) diffMin = diff
      if (diff > diffMax) diffMax = diff
      if (wsQueueBytes > peakQueue) peakQueue = wsQueueBytes

      val paused = fps == 0 && curStall == 0
      if (fps >= 0) {
        if (paused) pausedSeconds++
        else {
          fpsSum += fps; fpsCount++
          if (fps < fpsMin) fpsMin = fps
          if (fps < 50) fpsLow++
        }
      }

      // ping jitter = mean change between the last samples
      val recent = pings.takeLast(10)
      val jitter = if (recent.size < 2) 0L else recent.zipWithNext { a, b -> kotlin.math.abs(a - b) }.average().toLong()

      val rxN = rxCountWin
      val rxGap = rxGapMaxWin
      rxCountWin = 0
      rxGapMaxWin = 0L

      line =
        (if (paused) "[PAUSED] " else "") +
          "fps=$fps cur=$cur diff=$diff D=$d stalls=+$dStalls(tot $stalls) stallMs=+$dStallMs(max $stallMsMax) curStall=${curStall}ms " +
          "rxPkts=$rxN rxGapMax=${rxGap}ms ping=${pingMs}ms oneWay=${oneWayMs}ms jitter=${jitter}ms wsQueue=${wsQueueBytes}B " +
          "catchUp=+$dCatch desyncs=$desyncs"

      if (!paused && fps in 0..49) warnList.add("LOW_FPS fps=$fps (core wants ~60): the phone cannot keep up")
      if (dStallMs >= 150) warnList.add("STALL +${dStallMs}ms in the last second ($dStalls episodes): waiting for peer input, D=$d may be too low for this network")
      if (curStall >= 1000) warnList.add("STUCK waiting ${curStall}ms for peer input at frame $cur (peerMax=$peerMax): network stall or lost packet")
      if (rxGap >= 250) warnList.add("RX_GAP ${rxGap}ms with no input packet from peer")
      if (pingMs > 200 && pingBaseline in 1..(pingMs / 2)) warnList.add("PING_SPIKE ping=${pingMs}ms (baseline ~${pingBaseline}ms)")
      if (wsQueueBytes > 64 * 1024) warnList.add("SEND_BACKLOG ${wsQueueBytes}B waiting in our socket: uplink/relay is slow")
      if (dCatch > 20) warnList.add("CATCH_UP ${dCatch} double-steps: this side keeps falling behind the peer")

      tickPrevAt = now
      tickPrevFrame = cur
      prevStalls = stalls
      prevStallMs = stallMsTotal
      prevCatchUps = catchUps
      for (w in warnList) {
        val k = w.substringBefore(' ')
        warns[k] = (warns[k] ?: 0) + 1
      }
    }
    log("METRICS", line)
    for (w in warnList) log("WARN", w)
  }

  // ------------------------------------------------------------------ summary

  private fun percentile(sorted: List<Long>, p: Int): Long =
    if (sorted.isEmpty()) 0L else sorted[((sorted.size - 1) * p / 100).coerceIn(0, sorted.size - 1)]

  private fun buildSummary(): List<String> {
    val out = ArrayList<String>()
    synchronized(statLock) {
      val durSec = ((SystemClock.elapsedRealtime() - startTimeMs) / 1000L).coerceAtLeast(1L)
      val sortedPings = pings.sorted()
      val p50 = percentile(sortedPings, 50)
      val p95 = percentile(sortedPings, 95)
      val pMax = sortedPings.lastOrNull() ?: 0L
      val jit = if (pings.size < 2) 0L else pings.zipWithNext { a, b -> kotlin.math.abs(a - b) }.average().toLong()
      val avgFps = if (fpsCount > 0) (fpsSum / fpsCount).toInt() else -1
      val frames = (lastFrame - firstFrame).coerceAtLeast(0)
      val activeSec = (fpsCount + pausedSeconds).coerceAtLeast(1)
      val stallPct = stallMsTotalLast * 100.0 / (durSec * 1000.0)
      val stallsPerMin = stalls60(durSec)
      val lowFpsPct = if (fpsCount > 0) fpsLow * 100 / fpsCount else 0

      out.add("Duration=${durSec}s  frames=$frames  D(last)=$dLast")
      out.add("FPS: avg=$avgFps min=${if (fpsMin == Int.MAX_VALUE) -1 else fpsMin} secondsBelow50=$fpsLow (${lowFpsPct}%)  pausedSeconds=$pausedSeconds")
      out.add("STALLS: episodes=$stallsLast (${"%.1f".format(stallsPerMin)}/min)  totalTime=${stallMsTotalLast}ms (${"%.1f".format(stallPct)}% of session)  longest=${stallMsMaxLast}ms")
      out.add("RX GAPS (no peer input): >100ms=$rxGapOver100  >250ms=$rxGapOver250  >500ms=$rxGapOver500  worst=${rxGapWorst}ms")
      out.add("PING: samples=${pings.size} p50=${p50}ms p95=${p95}ms max=${pMax}ms jitter=${jit}ms")
      out.add("PEER LEAD (peerMax-cur): min=${if (diffMin == Int.MAX_VALUE) 0 else diffMin} max=${if (diffMax == Int.MIN_VALUE) 0 else diffMax}  catchUpSteps=$catchUpsLast")
      out.add("DESYNCS=$desyncsLast  handshakes=$hsCount avg=${if (hsCount > 0) hsSum / hsCount else 0}ms max=${hsMax}ms")
      out.add("STATE TX: n=$stateTxCount bytes=$stateTxBytes avgSend=${if (stateTxCount > 0) stateTxMsSum / stateTxCount else 0}ms max=${stateTxMsMax}ms | RX: n=$stateRxCount maxLoad=${stateRxLoadMsMax}ms")
      out.add("SEND BACKLOG peak=${peakQueue}B  warnings=${warns.entries.joinToString { it.key + "x" + it.value }}")

      // ---- diagnosis ----
      val dx = ArrayList<String>()
      val network = p95 > 150 || rxGapOver250 >= 3 || rxGapWorst >= 1000 || peakQueue > 64 * 1024
      if (desyncsLast > 0)
        dx.add("DESYNC x$desyncsLast: the two emulators diverged (core not deterministic, or an input was lost). Every desync triggers a state push = the visible 'jump'. Look at DESYNC lines and the METRICS just before them.")
      if (stallsPerMin > 6 || stallPct > 3.0) {
        if (network)
          dx.add("NETWORK: frequent stalls with high ping/jitter or packet gaps. Fix: higher D, shorter route to the relay, or resend the last few inputs in every packet.")
        else if (lowFpsPct > 10)
          dx.add("DEVICE: stalls come together with low fps: the slower phone holds the other back.")
        else
          dx.add("D TOO LOW: stalls without bad ping. D=$dLast frames (~${(dLast * 16.7).toInt()}ms) is below the real one-way delay + jitter (p50=${p50}ms RTT).")
      }
      if (lowFpsPct > 10 && fpsCount > 0)
        dx.add("LOW FPS on ${lowFpsPct}% of seconds (min ${if (fpsMin == Int.MAX_VALUE) -1 else fpsMin}): the phone/core cannot hold full speed (heavy core, thermal throttling, background load).")
      if (rxGapWorst >= 1000)
        dx.add("HICCUPS: a ${rxGapWorst}ms silence from the peer. Relay/host hiccup (cPanel process restarted or throttled), mobile network switch, or the peer app went to the background.")
      if (hsMax > 4000)
        dx.add("SLOW HANDSHAKE: longest resync ${hsMax}ms. State transfer is slow (state size ${if (stateTxCount > 0) stateTxBytes / stateTxCount else 0}B average).")
      if (hsCount > 2)
        dx.add("MANY RESYNCS ($hsCount): something keeps restarting lockstep (desyncs, loads or resync timeouts).")
      if (dx.isEmpty()) dx.add("No problem detected in this session (stalls, fps, ping and desyncs are all within normal range).")
      out.add("---- DIAGNOSIS ----")
      out.addAll(dx)
    }
    return out
  }

  private fun stalls60(durSec: Long): Double = stallsLast * 60.0 / durSec.coerceAtLeast(1L)

  // ------------------------------------------------------------------ stop / export

  fun stop(): File? {
    if (!isRecording) return currentLogFile
    try {
      log("SUMMARY", "================= SESSION SUMMARY =================")
      for (l in buildSummary()) log("SUMMARY", l)
    } catch (e: Throwable) {
      log("SUMMARY", "summary failed: $e")
    }
    log("INFO", "Diagnostic session stopped.")
    isRecording = false
    handler?.removeCallbacks(flusher)
    drain()
    synchronized(writeLock) {
      try { writer?.flush(); writer?.close() } catch (_: Throwable) {}
      writer = null
    }
    try { thread?.quitSafely() } catch (_: Throwable) {}
    thread = null
    handler = null
    return currentLogFile
  }

  /**
   * Stops recording and copies the log to Download/Bazirox (visible in any file manager, easy to send).
   * Returns a short text to show the user.
   */
  fun finish(context: Context): String {
    val f = stop() ?: return ""
    return exportFile(context, f)
  }

  /** Copies a log file to Download/Bazirox; returns the path to show (or the private path if copying failed). */
  fun exportFile(context: Context, f: File): String = exportToDownloads(context, f) ?: f.absolutePath

  private fun exportToDownloads(context: Context, file: File): String? {
    return try {
      if (Build.VERSION.SDK_INT >= 29) {
        val v =
          ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, file.name)
            put(MediaStore.Downloads.MIME_TYPE, "text/plain")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/Bazirox")
          }
        val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return null
        context.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
        "Download/Bazirox/" + file.name
      } else {
        val dir = File(context.getExternalFilesDir(null), "lockstep_logs").apply { mkdirs() }
        val dst = File(dir, file.name)
        file.copyTo(dst, overwrite = true)
        dst.absolutePath
      }
    } catch (_: Throwable) {
      null
    }
  }

  /**
   * Writes ONE file with both phones: a combined summary on top (so the answer is on the first screen),
   * then the full log of this phone and of the other phone. [peerText] = null when the other log did not arrive.
   * Returns the place to show the user.
   */
  fun mergeAndExport(context: Context, own: File, peerText: String?, mySlot: Int, room: String): String {
    val ownText = try { own.readText() } catch (_: Throwable) { "(could not read own log)" }
    val peerSlot = if (mySlot == 1) 2 else 1
    fun summaryOf(text: String): String =
      text.lineSequence().filter { it.contains("] [SUMMARY] ") }.joinToString("\n") { it.substringAfter("] [SUMMARY] ") }

    val sb = StringBuilder()
    sb.append("##### BAZIROX LOCKSTEP - COMBINED REPORT (both phones) #####\n")
    sb.append("Room=$room\n")
    sb.append("PHONE A = the phone that pressed the button (slot $mySlot) | PHONE B = the other phone (slot $peerSlot)\n")
    sb.append("Times: every line has '+Nms since logging started'. B started about one network delay (one-way ping) after A, so the same moment is ~ +oneWay ms later on A's clock than B's.\n")
    sb.append("How to compare: the phone with LOW_FPS / low fps in its SUMMARY is the one holding the game back. STALL/STUCK on both = network. DESYNC lines = determinism.\n\n")
    sb.append("===== SUMMARY - PHONE A (slot $mySlot) =====\n").append(summaryOf(ownText)).append("\n\n")
    sb.append("===== SUMMARY - PHONE B (slot $peerSlot) =====\n")
    if (peerText != null) sb.append(summaryOf(peerText)).append("\n\n")
    else sb.append("NOT RECEIVED (the other phone is on an old app version, disconnected, or took more than 25 s to send it).\n\n")
    sb.append("##########################  FULL LOG - PHONE A (slot $mySlot)  ##########################\n").append(ownText).append("\n\n")
    sb.append("##########################  FULL LOG - PHONE B (slot $peerSlot)  ##########################\n")
    sb.append(peerText ?: "(not received)").append("\n")

    val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    val out = File(own.parentFile ?: context.filesDir, "lockstep_BOTH_${room}_$ts.txt")
    return try {
      out.writeText(sb.toString())
      exportToDownloads(context, out) ?: out.absolutePath
    } catch (_: Throwable) {
      exportToDownloads(context, own) ?: own.absolutePath
    }
  }

  fun getRecentLogs(): List<String> = logBuffer.toList()

  fun getCurrentLogFilePath(): String? = currentLogFile?.absolutePath
}
