package com.example.notify

import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context

/** Registers / cancels the periodic background check (system minimum period: 15 minutes). */
object NotificationScheduler {
  private const val JOB_ID = 4201
  private const val PERIOD_MS = 15 * 60 * 1000L

  /** [active] = logged in to a server account. The notification switch in the profile also has to be on. */
  fun apply(context: Context, active: Boolean) {
    val app = context.applicationContext
    val js = app.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
    if (!active || !NotifyPrefs.isEnabled(app)) {
      js.cancel(JOB_ID)
      return
    }
    // Already registered: leave it alone so the period is not restarted on every app start.
    if (js.getPendingJob(JOB_ID) != null) return
    val info =
      JobInfo.Builder(JOB_ID, ComponentName(app, MessageCheckJobService::class.java))
        .setPeriodic(PERIOD_MS)
        .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
        .setPersisted(true)
        .build()
    js.schedule(info)
  }
}
