package com.example.ui.games

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONArray
import org.json.JSONObject

/*
 * The in-game emulator UI (pads, system buttons, chips, names, chat) is HTML/CSS in
 * assets/emu_ui/index.html, shown in a transparent WebView on top of the GL game view.
 *
 * JS -> Kotlin (window.Android, runs on a WebView thread, everything is re-posted to the main thread in order):
 *   pad(mask)        all held buttons as one bit mask (bit order = BIT in index.html)
 *   act(name)        copy | swap | duo | slot | save | load | exit
 *   chat(text)       the player sent a chat message
 *   chatOpen(bool)   the chat sheet opened/closed (so Back can close it)
 *   ready()          the page finished loading: Kotlin pushes the state + chat history
 *   hidePads(bool)   the chat sheet / keyboard covers the pad area: Kotlin hides the native pads (EmuPads in ConsoleControls.kt)
 * The pads themselves (d-pad / stick, face buttons, START/MODE) are NOT in the WebView any more: they are native
 * Compose sprites that send keys through EmuUi.key(). pad(mask) stays only for old callers.
 * Kotlin -> JS: EMU.state(obj), EMU.setMsgs(arr), EMU.addMsg(slot, text), EMU.closeChat(), EMU.releaseAll()
 *
 * Keys are sent as a mask (not as down/up events), so a lost "up" can never leave a key stuck:
 * the next mask always carries the full truth and Kotlin only acts on the difference.
 */
internal class EmuUi(@Suppress("unused") private val context: Context) {
  /** Key code for each mask bit (-1 = not on this console): U D L R A B C X Y Z D(neo) START MODE/COIN. */
  var keys: IntArray = IntArray(13) { -1 }
  var onKey: (Int, Boolean) -> Unit = { _, _ -> }
  var onAct: (String) -> Unit = {}
  var onChat: (String) -> Unit = {}
  var onChatOpen: (Boolean) -> Unit = {}

  /** Bumped when the WebView renderer process dies, so the view is rebuilt instead of the controls vanishing. */
  var generation by mutableIntStateOf(0)
    private set

  /** True while the chat sheet or the keyboard covers the pad area: the native pads are hidden (set from index.html). */
  var padsHidden by mutableStateOf(false)
    private set

  /** Keys currently held by the native pads, so they can all be released when the pads disappear. */
  private val held = HashSet<Int>()

  /** The native pads (EmuPads) send their key events through here. */
  fun key(code: Int, down: Boolean) {
    if (down) held.add(code) else held.remove(code)
    onKey(code, down)
  }

  private val main = Handler(Looper.getMainLooper())
  private var web: WebView? = null
  private var ready = false
  private var lastState: String? = null
  private var pushed: String? = null
  private val history = ArrayList<Pair<Int, String>>()
  private var prevMask = 0

  private inner class Bridge {
    @JavascriptInterface fun pad(mask: Int) { main.post { padMask(mask) } }
    @JavascriptInterface fun act(name: String) { main.post { if (name == "swap" || name == "exit") releaseKeys(); onAct(name) } }
    @JavascriptInterface fun hidePads(hidden: Boolean) { main.post { applyPadsHidden(hidden) } }
    @JavascriptInterface fun chat(text: String) { main.post { onChat(text) } }
    @JavascriptInterface fun chatOpen(open: Boolean) { main.post { onChatOpen(open) } }
    @JavascriptInterface fun ready() { main.post { onReady() } }
  }

  private fun applyPadsHidden(hidden: Boolean) {
    if (padsHidden == hidden) return
    padsHidden = hidden
    if (hidden) releaseKeys()
  }

  private fun padMask(m: Int) {
    val changed = m xor prevMask
    prevMask = m
    if (changed == 0) return
    var rising = false
    for (i in keys.indices) {
      val bit = 1 shl i
      if (changed and bit != 0 && keys[i] >= 0) {
        val down = m and bit != 0
        if (down) rising = true
        onKey(keys[i], down)
      }
    }
    if (rising) web?.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
  }

  private fun js(code: String) {
    web?.evaluateJavascript(code, null)
  }

  private fun onReady() {
    ready = true
    pushed = null
    val arr = JSONArray()
    history.forEach { arr.put(JSONObject().put("slot", it.first).put("text", it.second)) }
    js("EMU.setMsgs($arr)")
    lastState?.let { push(it) }
  }

  /** Sends the screen state (a JSON object). Identical states are skipped. */
  fun push(json: String) {
    lastState = json
    if (!ready || json == pushed) return
    pushed = json
    js("EMU.state($json)")
  }

  fun addMsg(slot: Int, text: String) {
    history.add(slot to text)
    while (history.size > 120) history.removeAt(0)
    if (ready) js("EMU.addMsg($slot,${JSONObject.quote(text)})")
  }

  fun closeChat() = js("EMU.closeChat()")

  /** Let go of every key (app paused, player swapped, leaving). */
  fun releaseKeys() {
    padMask(0)
    if (held.isNotEmpty()) {
      val heldKeys = held.toList()
      held.clear()
      heldKeys.forEach { onKey(it, false) }
    }
    js("EMU.releaseAll()")
  }

  @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
  fun create(ctx: Context): WebView {
    padMask(0)
    ready = false
    pushed = null
    padsHidden = false
    val w = WebView(ctx)
    w.setBackgroundColor(Color.TRANSPARENT)
    w.setLayerType(View.LAYER_TYPE_HARDWARE, null)
    w.overScrollMode = View.OVER_SCROLL_NEVER
    w.isVerticalScrollBarEnabled = false
    w.isHorizontalScrollBarEnabled = false
    w.isLongClickable = false
    w.settings.apply {
      javaScriptEnabled = true
      domStorageEnabled = false
      allowFileAccess = false // file:///android_asset is always readable
      allowContentAccess = false
      blockNetworkLoads = true
      setGeolocationEnabled(false)
      setSupportMultipleWindows(false)
      javaScriptCanOpenWindowsAutomatically = false
      mediaPlaybackRequiresUserGesture = true
      // Local page only: skip the Safe Browsing check/initialisation (faster first paint).
      if (android.os.Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = false
      setSupportZoom(false)
      builtInZoomControls = false
      displayZoomControls = false
      textZoom = 100
    }
    w.webViewClient =
      object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
          main.post { generation++ }
          return true
        }
      }
    w.addJavascriptInterface(Bridge(), "Android")
    web = w
    w.loadUrl("file:///android_asset/emu_ui/index.html")
    return w
  }

  fun destroy(w: WebView) {
    if (web === w) {
      web = null
      ready = false
    }
    w.removeJavascriptInterface("Android")
    w.stopLoading()
    w.destroy()
  }
}

@Composable
internal fun EmuOverlay(ui: EmuUi, modifier: Modifier) {
  key(ui.generation) {
    AndroidView(factory = { ui.create(it) }, modifier = modifier, onRelease = { ui.destroy(it) })
  }
}
