package com.example.ui.games

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat

/**
 * TEST ONLY: a second, completely independent emulator window.
 *
 * It runs in its OWN PROCESS (android:process=":p2" in the manifest), so it has its own copy of the native
 * LibretroDroid core and its own lockstep state, exactly like a second phone. It runs the SAME EmulatorScreen
 * code as the normal app, so whatever is fixed here is fixed for the normal mode too.
 *
 * Use: window 1 (yasinm) creates the room, window 2 joins with the code (or the other way round to test as P2).
 */
class EmulatorTestActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    // Safety: never run inside the main process (it would share the native core with window 1).
    val proc = if (Build.VERSION.SDK_INT >= 28) Application.getProcessName() else null
    if (proc != null && !proc.endsWith(":p2")) {
      super.onCreate(savedInstanceState)
      Toast.makeText(this, "EmulatorTestActivity must have android:process=\":p2\" in the manifest", Toast.LENGTH_LONG).show()
      finish()
      return
    }
    EmuInstance.suffix = "_p2"
    // A second process may NOT share the WebView data directory (the game overlay is a WebView): without this it crashes.
    if (Build.VERSION.SDK_INT >= 28) {
      try { WebView.setDataDirectorySuffix("p2") } catch (_: Throwable) {}
    }
    super.onCreate(savedInstanceState)
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    WindowCompat.setDecorFitsSystemWindows(window, false)
    val name = intent.getStringExtra(EXTRA_NAME) ?: "yasinm_p2"
    setContent { EmulatorScreen(playerName = name, currentUsername = name, onBack = { finish() }) }
  }

  companion object {
    const val EXTRA_NAME = "name"
  }
}

/** Opens the second window. Works side by side when this window is already in split-screen; otherwise it opens full screen (then use Recents -> split screen). */
fun launchSecondEmulatorWindow(context: Context, baseName: String) {
  val i =
    Intent(context, EmulatorTestActivity::class.java)
      .putExtra(EmulatorTestActivity.EXTRA_NAME, baseName + "_p2")
      .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
  context.startActivity(i)
}
