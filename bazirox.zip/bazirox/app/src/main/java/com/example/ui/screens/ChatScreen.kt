package com.example.ui.screens

import androidx.activity.compose.BackHandler
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ChatImageUtils
import com.example.data.SendState
import java.io.File
import java.util.Calendar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.layout.requiredHeight
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.runtime.CompositionLocalProvider
import com.example.data.AvatarImage
import com.example.data.ChatGroup
import com.example.data.UserProfile
import com.example.data.titleFor
import com.example.data.ChatMessage
import com.example.data.GameInvite
import com.example.data.GameType
import com.example.data.JoinRequest
import com.example.data.UserAccount
import com.example.ui.components.AvatarBadge
import com.example.ui.components.BaziIcons
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.auroraGamingBackdrop
import com.example.ui.components.avatarColorFor
import com.example.ui.components.stableColorIndex
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPulse
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(
  currentUser: UserAccount?,
  groups: List<ChatGroup>,
  selectedGroup: ChatGroup?,
  messages: List<ChatMessage>,
  feedbackMessage: String?,
  chatReads: Map<String, Long>,
  userPresence: Map<String, Long> = emptyMap(),
  typingUsers: List<String> = emptyList(),
  onTyping: () -> Unit = {},
  onTypingStopped: () -> Unit = {},
  draftImagePath: String?,
  replyTo: ChatMessage?,
  imageBusy: Boolean,
  onPickImage: (Uri) -> Unit,
  onClearDraftImage: () -> Unit,
  onSetReply: (ChatMessage?) -> Unit,
  editing: ChatMessage? = null,
  onStartEdit: (ChatMessage) -> Unit = {},
  onCancelEdit: () -> Unit = {},
  onRetryMessage: (ChatMessage) -> Unit,
  onDeleteMessage: (ChatMessage) -> Unit,
  joinRequests: List<JoinRequest>,
  onResolveJoinRequest: (String, Boolean) -> Unit,
  loadImage: suspend (ChatMessage, Int) -> Bitmap?,
  onCreateGroup: (String) -> Unit,
  onJoinGroupByCode: (String) -> Unit,
  onInviteMember: (String, String) -> Unit,
  onLeaveGroup: (String) -> Unit,
  onDeleteGroup: (String) -> Unit,
  onUpdateGroup: (String, String, String) -> Unit,
  onSetGroupAvatar: (String, Uri) -> Unit = { _, _ -> },
  onRemoveGroupAvatar: (String) -> Unit = {},
  avatars: Map<String, AvatarImage>,
  senderNames: Map<String, String> = emptyMap(),
  viewedUser: String?,
  viewedProfile: UserProfile?,
  viewedProfileError: String?,
  onOpenUserProfile: (String) -> Unit,
  onCloseUserProfile: () -> Unit,
  onStartDm: (String) -> Unit,
  onStartDmByUsername: (String) -> Unit = {},
  onOpenGroup: (ChatGroup) -> Unit,
  onCloseGroup: () -> Unit,
  onSendMessage: (String) -> Unit,
  onSendGameInvite: (GameType) -> Unit,
  onJoinGameInvite: (GameInvite) -> Unit,
  onOpenAuth: () -> Unit,
  onClearFeedback: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val names = remember(senderNames, currentUser?.username, currentUser?.displayName) {
    val me = currentUser
    if (me == null || me.displayName.isBlank()) senderNames else senderNames + (me.username.lowercase() to me.displayName)
  }
  // Status messages ("added to group", "saved"...) disappear by themselves instead of staying forever.
  androidx.compose.runtime.LaunchedEffect(feedbackMessage) {
    if (!feedbackMessage.isNullOrBlank()) {
      delay(3500)
      onClearFeedback()
    }
  }
  if (selectedGroup != null) {
    BackHandler(onBack = onCloseGroup)
    var showProfile by remember(selectedGroup.id) { mutableStateOf(false) }
    BackHandler(enabled = showProfile) { showProfile = false }
    BackHandler(enabled = viewedUser != null) { onCloseUserProfile() }
    Box(modifier = modifier.fillMaxSize()) {
    TelegramConversationView(
      currentUser = currentUser,
      group = selectedGroup,
      messages = messages,
      reads = chatReads,
      userPresence = userPresence,
      typingUsers = typingUsers,
      onTyping = onTyping,
      onTypingStopped = onTypingStopped,
      draftImagePath = draftImagePath,
      replyTo = replyTo,
      imageBusy = imageBusy,
      feedbackMessage = feedbackMessage,
      onPickImage = onPickImage,
      onClearDraftImage = onClearDraftImage,
      onSetReply = onSetReply,
      editing = editing,
      onStartEdit = onStartEdit,
      onCancelEdit = onCancelEdit,
      onRetry = onRetryMessage,
      onDeleteMessage = onDeleteMessage,
      joinRequests = joinRequests,
      onResolveJoinRequest = onResolveJoinRequest,
      loadImage = loadImage,
      onBack = onCloseGroup,
      onInviteMember = { username -> onInviteMember(selectedGroup.id, username) },
      onLeaveGroup = { onLeaveGroup(selectedGroup.id) },
      onDeleteGroup = { onDeleteGroup(selectedGroup.id) },
      onSendMessage = onSendMessage,
      onSendGameInvite = onSendGameInvite,
      onJoinGameInvite = onJoinGameInvite,
      onClearFeedback = onClearFeedback,
      onOpenProfile = { showProfile = true },
      onOpenUserProfile = onOpenUserProfile,
      avatars = avatars,
      senderNames = names,
      modifier = Modifier,
    )
    if (showProfile) {
      GroupProfileScreen(
        group = selectedGroup,
        myName = currentUser?.username.orEmpty(),
        feedbackMessage = feedbackMessage,
        avatars = avatars,
        senderNames = names,
        onBack = { showProfile = false },
        onSave = { n, d -> onUpdateGroup(selectedGroup.id, n, d) },
        onPickAvatar = { onSetGroupAvatar(selectedGroup.id, it) },
        onRemoveAvatar = { onRemoveGroupAvatar(selectedGroup.id) },
        onMemberClick = onOpenUserProfile,
      )
    }
    if (viewedUser != null) {
      val me = currentUser?.username.orEmpty()
      UserProfileScreen(
        username = viewedUser,
        profile = viewedProfile,
        error = viewedProfileError,
        avatar = avatars[viewedUser.lowercase()]?.bitmap,
        initialColorIndex = selectedGroup.colorOf(viewedUser),
        initialDisplayName = names[viewedUser.lowercase()],
        isSelf = viewedUser.equals(me, ignoreCase = true),
        canMessage = !selectedGroup.isDm && !viewedUser.equals(me, ignoreCase = true),
        onMessage = { onStartDm(viewedUser) },
        onBack = onCloseUserProfile,
      )
    }
    }
    return
  }

  var groupMenuTarget by remember { mutableStateOf<ChatGroup?>(null) }
  var listLeaveTarget by remember { mutableStateOf<ChatGroup?>(null) }
  var listDeleteTarget by remember { mutableStateOf<ChatGroup?>(null) }
  var showCreateDialog by remember { mutableStateOf(false) }
  var showJoinDialog by remember { mutableStateOf(false) }
  var showDmDialog by remember { mutableStateOf(false) }
  var searchQuery by remember { mutableStateOf("") }

  val filteredGroups =
    remember(groups, searchQuery, currentUser?.username) {
      if (searchQuery.isBlank()) groups
      else groups.filter { it.titleFor(currentUser?.username.orEmpty()).contains(searchQuery.trim(), ignoreCase = true) }
    }

  Box(
    modifier = modifier.fillMaxSize().auroraGamingBackdrop(NeonCyan, VioletPulse),
    contentAlignment = Alignment.TopCenter,
  ) {
    Column(
      modifier = Modifier.fillMaxSize().widthIn(max = 680.dp),
    ) {
      // Compact Frosted Header
      Surface(
        color = Color(0xCC0C1322),
        border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.07f)),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Box(
                modifier =
                  Modifier.size(32.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Brush.linearGradient(listOf(NeonCyan, VioletPulse))),
                contentAlignment = Alignment.Center,
              ) {
                Icon(BaziIcons.Forum, contentDescription = null, tint = ObsidianBg, modifier = Modifier.size(17.dp))
              }
              Text(
                text = "چت‌های Bazirox",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.ExtraBold,
              )
            }
            Surface(
              shape = RoundedCornerShape(50),
              color = NeonCyan.copy(alpha = 0.12f),
              border = BorderStroke(0.8.dp, NeonCyan.copy(alpha = 0.3f)),
            ) {
              Text(
                text = if (currentUser == null) "مهمان" else "${groups.size} گفتگو",
                style = MaterialTheme.typography.labelSmall,
                color = NeonCyan,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
              )
            }
          }

          if (currentUser != null) {
            OutlinedTextField(
              value = searchQuery,
              onValueChange = { searchQuery = it },
              placeholder = { Text("جستجو...", style = MaterialTheme.typography.bodySmall, color = TextSecondary) },
              leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp)) },
              trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                  IconButton(onClick = { searchQuery = "" }) {
                    Icon(Icons.Rounded.Close, contentDescription = "پاک کردن جستجو", tint = TextSecondary, modifier = Modifier.size(18.dp))
                  }
                }
              },
              singleLine = true,
              textStyle = MaterialTheme.typography.bodySmall.copy(color = TextPrimary),
              keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
              modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp),
              colors =
                OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = NeonCyan.copy(alpha = 0.6f),
                  unfocusedBorderColor = Color.White.copy(alpha = 0.08f),
                  focusedContainerColor = Color(0x990B1020),
                  unfocusedContainerColor = Color(0x880B1020),
                ),
              shape = RoundedCornerShape(14.dp),
            )
          }
        }
      }

      if (!feedbackMessage.isNullOrBlank()) {
        Surface(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
          shape = RoundedCornerShape(14.dp),
          color = ElectricEmerald.copy(alpha = 0.16f),
          border = BorderStroke(1.dp, ElectricEmerald.copy(alpha = 0.45f)),
        ) {
          Text(
            text = feedbackMessage,
            style = MaterialTheme.typography.bodyMedium,
            color = ElectricEmerald,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
          )
        }
      }

      if (currentUser == null) {
        Box(modifier = Modifier.fillMaxSize().padding(18.dp), contentAlignment = Alignment.Center) {
          GlassGradientCard(accentColor = NeonCyan, cornerRadius = 24.dp, modifier = Modifier.fillMaxWidth()) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              Box(
                modifier =
                  Modifier.size(60.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(NeonCyan.copy(alpha = 0.3f), VioletPulse.copy(alpha = 0.3f)))),
                contentAlignment = Alignment.Center,
              ) {
                Icon(BaziIcons.Forum, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(30.dp))
              }
              Text("ورود به پیام‌رسان گروهی", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
              Text(
                "با یک نام کاربری دلخواه وارد شوید تا گروه بسازید، دوستانتان را دعوت کنید و به بازی دعوتشان کنید.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
              )
              Button(
                onClick = onOpenAuth,
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("chat_login_prompt_button"),
              ) {
                Text("ورود / ساخت پروفایل سریع", color = ObsidianBg, fontWeight = FontWeight.ExtraBold)
              }
            }
          }
        }
      } else if (filteredGroups.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
          GlassGradientCard(accentColor = VioletPulse, cornerRadius = 24.dp, modifier = Modifier.fillMaxWidth()) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(26.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Icon(BaziIcons.Forum, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(46.dp))
              Text(
                text = if (searchQuery.isNotBlank()) "گروهی پیدا نشد" else "هنوز در هیچ گروهی نیستید",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
              )
              Text(
                text = "دکمه + پایین را بزنید و اولین گروه گیمینگ خود را بسازید!",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
              )
            }
          }
        }
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 88.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          items(filteredGroups, key = { it.id }) { group ->
            Box {
              TelegramChatListRow(
                group = group,
                me = currentUser?.username.orEmpty(),
                userPresence = userPresence,
                dmName = if (group.isDm) names[group.titleFor(currentUser?.username.orEmpty()).lowercase()] else null,
                avatar = if (group.isDm) null else avatars["g:${group.id}".lowercase()]?.bitmap,
                onClick = { onOpenGroup(group) },
                onLongClick = { groupMenuTarget = group },
              )
              DropdownMenu(
                expanded = groupMenuTarget?.id == group.id,
                onDismissRequest = { groupMenuTarget = null },
              ) {
                DropdownMenuItem(
                  text = { Text(if (group.isDm) "حذف گفتگو" else "خروج از گروه") },
                  leadingIcon = { Icon(BaziIcons.Logout, contentDescription = null, modifier = Modifier.size(20.dp)) },
                  onClick = {
                    groupMenuTarget = null
                    listLeaveTarget = group
                  },
                )
                if (!group.isDm && group.ownerUsername.equals(currentUser?.username.orEmpty(), ignoreCase = true)) {
                  DropdownMenuItem(
                    text = { Text("حذف گروه برای همه", color = Color(0xFFF87171)) },
                    leadingIcon = {
                      Icon(Icons.Rounded.Delete, contentDescription = null, tint = Color(0xFFF87171), modifier = Modifier.size(20.dp))
                    },
                    onClick = {
                      groupMenuTarget = null
                      listDeleteTarget = group
                    },
                  )
                }
              }
            }
          }
        }
      }
    }

    // Telegram-style Floating Circular New Group FAB
    if (currentUser != null) {
      var fabMenu by remember { mutableStateOf(false) }
      Box(modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) {
      DropdownMenu(expanded = fabMenu, onDismissRequest = { fabMenu = false }) {
        DropdownMenuItem(text = { Text("ساخت گروه جدید") }, onClick = { fabMenu = false; showCreateDialog = true })
        DropdownMenuItem(text = { Text("عضویت با کد") }, onClick = { fabMenu = false; showJoinDialog = true })
        DropdownMenuItem(text = { Text("پیام خصوصی با آیدی") }, onClick = { fabMenu = false; showDmDialog = true })
      }
      FloatingActionButton(
        onClick = { fabMenu = true },
        containerColor = NeonCyan,
        contentColor = ObsidianBg,
        shape = RoundedCornerShape(16.dp),
        elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp),
        modifier =
          Modifier.size(52.dp).testTag("create_group_button"),
      ) {
        Icon(Icons.Rounded.Add, contentDescription = "جدید", modifier = Modifier.size(26.dp))
      }
      }
    }
  }

  listLeaveTarget?.let { g ->
    AlertDialog(
      onDismissRequest = { listLeaveTarget = null },
      containerColor = Color(0xFF182238),
      title = { Text(if (g.isDm) "حذف گفتگو" else "خروج از گروه", color = CyberGold) },
      text = {
        Text(
          "از گروه «${g.name}» خارج می‌شوی و پیام‌های آن از روی این دستگاه پاک می‌شود. برای برگشتن باید دوباره کد دعوت را وارد کنی.",
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary,
        )
      },
      confirmButton = {
        Button(
          onClick = {
            listLeaveTarget = null
            onLeaveGroup(g.id)
          },
          colors = ButtonDefaults.buttonColors(containerColor = CyberGold),
        ) {
          Text("خروج", color = ObsidianBg, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { listLeaveTarget = null }) { Text("انصراف", color = TextSecondary) }
      },
    )
  }

  listDeleteTarget?.let { g ->
    AlertDialog(
      onDismissRequest = { listDeleteTarget = null },
      containerColor = Color(0xFF182238),
      title = { Text("حذف گروه", color = Color(0xFFF87171)) },
      text = {
        Text(
          "گروه «${g.name}» و همه‌ی پیام‌هایش برای همه‌ی اعضا از سرور پاک می‌شود و قابل بازگشت نیست.",
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary,
        )
      },
      confirmButton = {
        Button(
          onClick = {
            listDeleteTarget = null
            onDeleteGroup(g.id)
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF87171)),
        ) {
          Text("حذف برای همه", color = Color.White, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { listDeleteTarget = null }) { Text("انصراف", color = TextSecondary) }
      },
    )
  }

  if (showCreateDialog) {
    var groupName by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showCreateDialog = false },
      containerColor = Color(0xFF182238),
      title = { Text("ساخت گروه جدید", color = NeonCyan) },
      text = {
        OutlinedTextField(
          value = groupName,
          onValueChange = { groupName = it.take(36) },
          label = { Text("نام گروه (مثلاً اسکواد منچ)") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
          keyboardActions = KeyboardActions(onDone = {
            if (groupName.isNotBlank()) {
              onCreateGroup(groupName)
              showCreateDialog = false
            }
          }),
          modifier = Modifier.fillMaxWidth().testTag("create_group_name_input"),
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (groupName.isNotBlank()) {
              onCreateGroup(groupName)
              showCreateDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
          modifier = Modifier.testTag("confirm_create_group_button"),
        ) {
          Text("ساخت گروه", color = ObsidianBg, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showCreateDialog = false }) { Text("انصراف", color = TextSecondary) }
      },
    )
  }

  if (showDmDialog) {
    var dmTarget by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showDmDialog = false },
      containerColor = Color(0xFF182238),
      title = { Text("پیام خصوصی با آیدی", color = NeonCyan) },
      text = {
        OutlinedTextField(
          value = dmTarget,
          onValueChange = { dmTarget = it.trim().take(32) },
          label = { Text("نام کاربری (آیدی)") },
          supportingText = { Text("نیازی نیست عضو گروه مشترک باشید") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Done),
          keyboardActions = KeyboardActions(onDone = {
            if (dmTarget.isNotBlank()) {
              onStartDmByUsername(dmTarget)
              showDmDialog = false
            }
          }),
          modifier = Modifier.fillMaxWidth().testTag("dm_username_input"),
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (dmTarget.isNotBlank()) {
              onStartDmByUsername(dmTarget)
              showDmDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
        ) {
          Text("شروع گفتگو", color = ObsidianBg, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showDmDialog = false }) { Text("انصراف", color = TextSecondary) }
      },
    )
  }

  if (showJoinDialog) {
    var codeInput by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showJoinDialog = false },
      containerColor = Color(0xFF182238),
      title = { Text("عضویت در گروه با کد دعوت", color = VioletPulse) },
      text = {
        OutlinedTextField(
          value = codeInput,
          // The invite contains a case-sensitive encryption key: never change its case.
          onValueChange = { codeInput = it.trim().take(100) },
          label = { Text("کد دعوت کامل گروه") },
          placeholder = { Text("کد را همان‌طور که فرستاده شده بچسبان") },
          supportingText = { Text("شامل کد و کلید رمزنگاری با یک نقطه بینشان است") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Done),
          keyboardActions = KeyboardActions(onDone = {
            if (codeInput.isNotBlank()) {
              onJoinGroupByCode(codeInput)
              showJoinDialog = false
            }
          }),
          modifier = Modifier.fillMaxWidth().testTag("join_group_code_input"),
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (codeInput.isNotBlank()) {
              onJoinGroupByCode(codeInput)
              showJoinDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = VioletPulse),
          modifier = Modifier.testTag("confirm_join_group_button"),
        ) {
          Text("عضویت", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showJoinDialog = false }) { Text("انصراف", color = TextSecondary) }
      },
    )
  }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun TelegramChatListRow(
  group: ChatGroup,
  me: String,
  userPresence: Map<String, Long> = emptyMap(),
  dmName: String? = null,
  avatar: androidx.compose.ui.graphics.ImageBitmap?,
  onClick: () -> Unit,
  onLongClick: () -> Unit,
) {
  val shownTitle = dmName ?: group.titleFor(me)
  val isOnline = remember(group, userPresence, me) {
    if (group.isDm) {
      val other = group.members.firstOrNull { !it.equals(me, ignoreCase = true) }
      isUserOnline(other?.let { userPresence[it.lowercase()] })
    } else {
      group.members.any { !it.equals(me, ignoreCase = true) && isUserOnline(userPresence[it.lowercase()]) }
    }
  }
  val badgeColor = if (group.isDm) VioletPulse else NeonCyan
  Surface(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .combinedClickable(onClick = onClick, onLongClick = onLongClick)
        .testTag("group_card_${group.id}"),
    shape = RoundedCornerShape(16.dp),
    color = Color(0xBA10192D),
    border = BorderStroke(0.9.dp, Color.White.copy(alpha = 0.08f)),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Box(contentAlignment = Alignment.BottomStart) {
        val rowTitle = shownTitle
        AvatarBadge(
          name = rowTitle,
          colorIndex = if (group.isDm) group.colorOf(group.members.firstOrNull { !it.equals(me, ignoreCase = true) } ?: group.id) else stableColorIndex(group.id),
          size = 46.dp,
          image = avatar,
        )
        if (isOnline) {
          Box(
            modifier =
              Modifier.size(12.dp)
                .clip(CircleShape)
                .background(ElectricEmerald)
                .border(2.dp, Color(0xFF10192D), CircleShape)
          )
        }
      }

      Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = shownTitle,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
          )
          Spacer(Modifier.width(8.dp))
          Text(
            text = if (group.lastMessageTime > 0L) formatClockTime(group.lastMessageTime) else "تازه",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = group.lastMessagePreview.ifBlank { if (group.isDm) "پیام خصوصی" else "کد دعوت: ${group.inviteCode}" },
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
          )
          Spacer(Modifier.width(8.dp))
          if (group.pendingCount > 0) {
            Surface(
              shape = RoundedCornerShape(50),
              color = CyberGold.copy(alpha = 0.16f),
              border = BorderStroke(0.8.dp, CyberGold.copy(alpha = 0.45f)),
            ) {
              Text(
                text = "${group.pendingCount} درخواست",
                style = MaterialTheme.typography.labelSmall,
                color = CyberGold,
                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
              )
            }
            Spacer(Modifier.width(5.dp))
          }
          Surface(
            shape = RoundedCornerShape(50),
            color = badgeColor.copy(alpha = 0.14f),
            border = BorderStroke(0.8.dp, badgeColor.copy(alpha = 0.35f)),
          ) {
            Text(
              text = if (group.isDm) "خصوصی" else "${group.members.size} عضو",
              style = MaterialTheme.typography.labelSmall,
              color = badgeColor,
              modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
            )
          }
        }
      }
    }
  }
}

private sealed interface ChatRow {
  data class DateHeader(val label: String) : ChatRow
  data class Msg(val msg: ChatMessage, val first: Boolean, val last: Boolean) : ChatRow
}

private enum class TickState { CLOCK, SENT, READ, FAILED }

private fun buildChatRows(messages: List<ChatMessage>): List<ChatRow> {
  val out = ArrayList<ChatRow>(messages.size + 8)
  var prevDay = ""
  messages.forEachIndexed { i, m ->
    val day = dayLabel(m.timestamp)
    if (day != prevDay) {
      out.add(ChatRow.DateHeader(day))
      prevDay = day
    }
    val prev = messages.getOrNull(i - 1)
    val next = messages.getOrNull(i + 1)
    fun sameBlock(a: ChatMessage?, b: ChatMessage) =
      a != null &&
        a.senderUsername.equals(b.senderUsername, ignoreCase = true) &&
        dayLabel(a.timestamp) == dayLabel(b.timestamp) &&
        kotlin.math.abs(a.timestamp - b.timestamp) < 5 * 60_000L
    out.add(ChatRow.Msg(m, first = !sameBlock(prev, m), last = !sameBlock(next, m)))
  }
  return out
}

private fun dayLabel(ts: Long): String {
  if (ts <= 0L) return "امروز"
  val cal = Calendar.getInstance()
  val today = cal.get(Calendar.YEAR) * 1000 + cal.get(Calendar.DAY_OF_YEAR)
  cal.timeInMillis = ts
  val d = cal.get(Calendar.YEAR) * 1000 + cal.get(Calendar.DAY_OF_YEAR)
  return when {
    d == today -> "امروز"
    d == today - 1 -> "دیروز"
    else -> SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(ts))
  }
}

/** Public profile of another user (opened from a group). Shows bio + stats and can start a private chat. */
@Composable
private fun UserProfileScreen(
  username: String,
  profile: UserProfile?,
  error: String?,
  avatar: androidx.compose.ui.graphics.ImageBitmap?,
  initialColorIndex: Int = stableColorIndex(username),
  initialDisplayName: String? = null,
  isSelf: Boolean,
  canMessage: Boolean,
  onMessage: () -> Unit,
  onBack: () -> Unit,
) {
  Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0B1020)) {
    Column(modifier = Modifier.fillMaxSize()) {
      Surface(color = Color(0xE6141D33), border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.1f))) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          IconButton(onClick = onBack, modifier = Modifier.size(44.dp).testTag("user_profile_back")) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت", tint = TextPrimary)
          }
          Text(
            text = if (isSelf) "پروفایل شما" else "پروفایل کاربر",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold,
            color = TextPrimary,
            modifier = Modifier.padding(horizontal = 8.dp),
          )
        }
      }

      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        item {
          AvatarBadge(
            name = profile?.displayName ?: initialDisplayName ?: username,
            colorIndex = profile?.avatarColorIndex ?: initialColorIndex,
            size = 104.dp,
            image = avatar,
          )
        }
        item {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = profile?.displayName ?: initialDisplayName ?: username,
              style = MaterialTheme.typography.headlineSmall,
              fontWeight = FontWeight.ExtraBold,
              color = TextPrimary,
            )
            Text(text = "\u2066@$username\u2069", style = MaterialTheme.typography.bodyMedium, color = NeonCyan)
          }
        }
        if (profile == null && error == null) {
          item { androidx.compose.material3.CircularProgressIndicator(color = NeonCyan, modifier = Modifier.size(28.dp)) }
        }
        if (profile != null) {
          item {
            Surface(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(16.dp),
              color = Color(0x66182238),
              border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
            ) {
              Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("بیوگرافی", style = MaterialTheme.typography.labelLarge, color = NeonCyan, fontWeight = FontWeight.Bold)
                Text(
                  text = profile.bio.ifBlank { "بیوگرافی ثبت نشده است." },
                  style = MaterialTheme.typography.bodyMedium,
                  color = if (profile.bio.isBlank()) TextSecondary else TextPrimary,
                )
              }
            }
          }
          item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              listOf("امتیاز" to profile.totalScore, "برد" to profile.wins, "بازی" to profile.gamesPlayed).forEach { (label, value) ->
                Surface(
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(14.dp),
                  color = Color(0x66182238),
                  border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                ) {
                  Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                  ) {
                    Text(value.toString(), style = MaterialTheme.typography.titleLarge, color = CyberGold, fontWeight = FontWeight.ExtraBold)
                    Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                  }
                }
              }
            }
          }
          if (canMessage) {
            item {
              Button(
                onClick = onMessage,
                modifier = Modifier.fillMaxWidth().testTag("user_profile_message_button"),
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
              ) {
                Text("ارسال پیام", color = ObsidianBg, fontWeight = FontWeight.ExtraBold)
              }
            }
          }
        }
        if (!error.isNullOrBlank()) {
          item { Text(error, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFF87171)) }
        }
      }
    }
  }
}

/** Group profile: everybody sees name / description / members; only the owner (admin) can edit. */
@Composable
private fun GroupProfileScreen(
  group: ChatGroup,
  myName: String,
  feedbackMessage: String?,
  avatars: Map<String, AvatarImage>,
  senderNames: Map<String, String> = emptyMap(),
  onBack: () -> Unit,
  onSave: (String, String) -> Unit,
  onPickAvatar: (Uri) -> Unit,
  onRemoveAvatar: () -> Unit,
  onMemberClick: (String) -> Unit,
) {
  val isOwner = group.ownerUsername.equals(myName, ignoreCase = true)
  val groupPhoto = avatars["g:${group.id}".lowercase()]?.bitmap
  val photoPicker =
    androidx.activity.compose.rememberLauncherForActivityResult(
      androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri -> if (uri != null) onPickAvatar(uri) }
  var editing by remember(group.id) { mutableStateOf(false) }
  var nameDraft by remember(group.id, editing) { mutableStateOf(group.name) }
  var descDraft by remember(group.id, editing) { mutableStateOf(group.description) }
  val fieldColors =
    OutlinedTextFieldDefaults.colors(
      focusedTextColor = TextPrimary,
      unfocusedTextColor = TextPrimary,
      focusedBorderColor = NeonCyan,
      unfocusedBorderColor = Color.White.copy(alpha = 0.25f),
      focusedLabelColor = NeonCyan,
      unfocusedLabelColor = TextSecondary,
      cursorColor = NeonCyan,
    )

  Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0B1020)) {
    Column(modifier = Modifier.fillMaxSize()) {
      Surface(color = Color(0xE6141D33), border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.1f))) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت", tint = TextPrimary)
          }
          Text(
            text = "پروفایل گروه",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold,
            color = TextPrimary,
            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
          )
          if (isOwner && !editing) {
            TextButton(onClick = { editing = true }, modifier = Modifier.testTag("group_edit_button")) {
              Text("ویرایش", color = NeonCyan, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        item {
          Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Box(
              modifier =
                Modifier.size(110.dp)
                  .then(
                    if (isOwner) {
                      Modifier.clickable(
                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                        indication = null,
                      ) { photoPicker.launch("image/*") }.testTag("group_avatar_edit")
                    } else Modifier
                  ),
              contentAlignment = Alignment.Center,
            ) {
              AvatarBadge(name = group.name, colorIndex = stableColorIndex(group.id), size = 102.dp, image = groupPhoto)
              if (isOwner) {
                Box(
                  modifier =
                    Modifier.align(Alignment.BottomEnd)
                      .padding(2.dp)
                      .size(32.dp)
                      .clip(CircleShape)
                      .background(NeonCyan)
                      .border(2.5.dp, Color(0xFF0B1020), CircleShape),
                  contentAlignment = Alignment.Center,
                ) {
                  Icon(Icons.Rounded.Edit, contentDescription = "تغییر عکس گروه", tint = ObsidianBg, modifier = Modifier.size(16.dp))
                }
              }
            }
            if (isOwner && groupPhoto != null) {
              TextButton(onClick = onRemoveAvatar) { Text("حذف عکس گروه", color = TextSecondary) }
            }
          }
        }
        if (!editing) {
          item {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = group.name,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary,
              )
              Text(
                text = "${group.members.size} عضو",
                style = MaterialTheme.typography.labelLarge,
                color = TextSecondary,
              )
            }
          }
          item {
            Surface(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(16.dp),
              color = Color(0x66182238),
              border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
            ) {
              Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("درباره‌ی گروه", style = MaterialTheme.typography.labelLarge, color = NeonCyan, fontWeight = FontWeight.Bold)
                Text(
                  text = group.description.ifBlank { "توضیحی برای این گروه ثبت نشده است." },
                  style = MaterialTheme.typography.bodyMedium,
                  color = if (group.description.isBlank()) TextSecondary else TextPrimary,
                )
              }
            }
          }
        } else {
          item {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              OutlinedTextField(
                value = nameDraft,
                onValueChange = { nameDraft = it.take(36) },
                label = { Text("نام گروه") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth().testTag("group_edit_name_input"),
              )
              OutlinedTextField(
                value = descDraft,
                onValueChange = { descDraft = it.take(200) },
                label = { Text("توضیحات گروه") },
                minLines = 3,
                maxLines = 6,
                supportingText = { Text("${descDraft.length}/200", color = TextSecondary) },
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth().testTag("group_edit_desc_input"),
              )
              val changed = nameDraft.trim() != group.name || descDraft.trim() != group.description
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                  onClick = {
                    onSave(nameDraft, descDraft)
                    editing = false
                  },
                  enabled = nameDraft.trim().length >= 2 && changed,
                  modifier = Modifier.testTag("group_edit_save"),
                ) { Text("ذخیره") }
                TextButton(onClick = { editing = false }) { Text("انصراف", color = TextSecondary) }
              }
            }
          }
        }

        if (!feedbackMessage.isNullOrBlank()) {
          item { Text(feedbackMessage, style = MaterialTheme.typography.labelMedium, color = ElectricEmerald) }
        }

        item {
          Text(
            text = "اعضا (${group.members.size})",
            style = MaterialTheme.typography.titleSmall,
            color = TextSecondary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth(),
          )
        }
        items(group.members, key = { it }) { member ->
          val memberIsOwner = member.equals(group.ownerUsername, ignoreCase = true)
          Surface(
            onClick = { onMemberClick(member) },
            modifier = Modifier.fillMaxWidth().testTag("group_member_$member"),
            shape = RoundedCornerShape(14.dp),
            color = Color(0x66182238),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              val shownName = senderNames[member.lowercase()] ?: member
              AvatarBadge(name = shownName, colorIndex = group.colorOf(member), size = 44.dp, image = avatars[member.lowercase()]?.bitmap)
              Text(
                text = if (member.equals(myName, ignoreCase = true)) "$shownName (شما)" else shownName,
                style = MaterialTheme.typography.bodyLarge,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
              )
              if (memberIsOwner) {
                Surface(
                  shape = RoundedCornerShape(50),
                  color = CyberGold.copy(alpha = 0.16f),
                  border = BorderStroke(1.dp, CyberGold.copy(alpha = 0.6f)),
                ) {
                  Text(
                    "ادمین",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberGold,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TelegramConversationView(
  currentUser: UserAccount?,
  group: ChatGroup,
  messages: List<ChatMessage>,
  reads: Map<String, Long>,
  userPresence: Map<String, Long> = emptyMap(),
  typingUsers: List<String> = emptyList(),
  onTyping: () -> Unit = {},
  onTypingStopped: () -> Unit = {},
  draftImagePath: String?,
  replyTo: ChatMessage?,
  imageBusy: Boolean,
  feedbackMessage: String?,
  onBack: () -> Unit,
  onInviteMember: (String) -> Unit,
  onLeaveGroup: () -> Unit,
  onDeleteGroup: () -> Unit,
  onOpenProfile: () -> Unit,
  onOpenUserProfile: (String) -> Unit,
  avatars: Map<String, AvatarImage>,
  senderNames: Map<String, String> = emptyMap(),
  onSendMessage: (String) -> Unit,
  onSendGameInvite: (GameType) -> Unit,
  onJoinGameInvite: (GameInvite) -> Unit,
  onPickImage: (Uri) -> Unit,
  onClearDraftImage: () -> Unit,
  onSetReply: (ChatMessage?) -> Unit,
  editing: ChatMessage? = null,
  onStartEdit: (ChatMessage) -> Unit = {},
  onCancelEdit: () -> Unit = {},
  onRetry: (ChatMessage) -> Unit,
  onDeleteMessage: (ChatMessage) -> Unit,
  joinRequests: List<JoinRequest>,
  onResolveJoinRequest: (String, Boolean) -> Unit,
  loadImage: suspend (ChatMessage, Int) -> Bitmap?,
  onClearFeedback: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var showRequestsDialog by remember { mutableStateOf(false) }
  var deleteTarget by remember { mutableStateOf<ChatMessage?>(null) }
  var messageText by remember { mutableStateOf("") }
  // Starting an edit puts the old text in the composer; Back cancels the edit instead of leaving the chat.
  LaunchedEffect(editing?.id) { if (editing != null) messageText = editing.text }
  BackHandler(enabled = editing != null) {
    messageText = ""
    onCancelEdit()
  }
  var showInviteMemberDialog by remember { mutableStateOf(false) }
  var groupMenuOpen by remember { mutableStateOf(false) }
  var showLeaveDialog by remember { mutableStateOf(false) }
  var showDeleteDialog by remember { mutableStateOf(false) }
  var showGameInvitePicker by remember { mutableStateOf(false) }
  var viewerMessage by remember { mutableStateOf<ChatMessage?>(null) }
  val clipboard = LocalClipboardManager.current
  val ctx = androidx.compose.ui.platform.LocalContext.current
  val listState = rememberLazyListState()
  val scope = rememberCoroutineScope()
  val rows = remember(messages) { buildChatRows(messages) }
  val myName = currentUser?.username.orEmpty()
  val dmOther = remember(group.members, myName) { group.members.firstOrNull { !it.equals(myName, ignoreCase = true) } }
  val headerTitle = group.titleFor(myName).let { t -> if (group.isDm) senderNames[t.lowercase()] ?: t else t }

  val photoPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
      if (uri != null) onPickImage(uri)
    }

  val nearBottom by remember {
    derivedStateOf {
      val info = listState.layoutInfo
      val last = info.visibleItemsInfo.lastOrNull()
      last == null || last.index >= info.totalItemsCount - 3
    }
  }
  var firstScrollDone by remember(group.id) { mutableStateOf(false) }
  // Sound for incoming messages: only when a new message from someone else arrives at the end
  // of an already-loaded conversation (opening the chat or loading history stays silent).
  var lastSeenMsgId by remember(group.id) { mutableStateOf<Any?>(null) }
  var soundArmed by remember(group.id) { mutableStateOf(false) }
  LaunchedEffect(messages) {
    val last = messages.lastOrNull()
    if (last == null) return@LaunchedEffect
    if (!soundArmed) {
      soundArmed = true
      lastSeenMsgId = last.id
      return@LaunchedEffect
    }
    if (last.id != lastSeenMsgId) {
      lastSeenMsgId = last.id
      if (!last.senderUsername.equals(myName, ignoreCase = true)) {
        com.example.data.SoundManager.play(com.example.data.Sfx.MSG_RECEIVE)
      }
    }
  }
  LaunchedEffect(rows.size) {
    if (rows.isEmpty()) return@LaunchedEffect
    val lastIsMine =
      (rows.last() as? ChatRow.Msg)?.msg?.senderUsername.equals(myName, ignoreCase = true)
    if (!firstScrollDone) {
      listState.scrollToItem(rows.lastIndex)
      firstScrollDone = true
    } else if (nearBottom || lastIsMine) {
      listState.animateScrollToItem(rows.lastIndex)
    }
  }

  Column(modifier = modifier.fillMaxSize()) {
    // 1. Telegram Top Chat Header
    Surface(
      color = Color(0xE6141D33),
      border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.1f)),
    ) {
      Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f),
          ) {
            IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
              Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت", tint = TextPrimary)
            }
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier =
                Modifier.weight(1f)
                  .clip(RoundedCornerShape(12.dp))
                  .clickable(onClick = { if (group.isDm) dmOther?.let(onOpenUserProfile) else onOpenProfile() })
                  .padding(vertical = 2.dp, horizontal = 2.dp)
                  .testTag("group_header_profile"),
            ) {
              AvatarBadge(
                name = headerTitle,
                colorIndex = if (group.isDm) group.colorOf(dmOther ?: group.id) else stableColorIndex(group.id),
                size = 44.dp,
                image = if (group.isDm) null else avatars["g:${group.id}".lowercase()]?.bitmap,
              )
              Spacer(Modifier.width(10.dp))
              Column {
                Text(
                  text = headerTitle,
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.ExtraBold,
                  color = TextPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                val statusText = remember(group, userPresence, dmOther) {
                  if (group.isDm) {
                    val lastSeen = dmOther?.let { userPresence[it.lowercase()] }
                    formatPresenceStatus(lastSeen)
                  } else {
                    val count = group.members.count { isUserOnline(userPresence[it.lowercase()]) }
                    if (count > 0) "${group.members.size} عضو • $count نفر آنلاین" else "${group.members.size} عضو"
                  }
                }
                val isOnlineNow = remember(group, userPresence, dmOther) {
                  if (group.isDm) {
                    isUserOnline(dmOther?.let { userPresence[it.lowercase()] })
                  } else {
                    group.members.any { isUserOnline(userPresence[it.lowercase()]) }
                  }
                }
                val typingText =
                  if (typingUsers.isEmpty()) null
                  else if (group.isDm) "در حال تایپ…"
                  else typingUsers.take(2).joinToString("، ") { senderNames[it.lowercase()] ?: it } + " در حال تایپ…"
                Text(
                  text = typingText ?: statusText,
                  style = MaterialTheme.typography.labelSmall,
                  color = if (typingText != null || isOnlineNow) NeonCyan else TextMuted,
                  maxLines = 1,
                )
              }
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!group.isDm) {
              IconButton(
                onClick = { showInviteMemberDialog = true },
                modifier = Modifier.size(44.dp).testTag("invite_member_button"),
              ) {
                Icon(BaziIcons.PersonAdd, contentDescription = "دعوت عضو", tint = ElectricEmerald)
              }
            }
            Box {
              IconButton(
                onClick = { groupMenuOpen = true },
                modifier = Modifier.size(40.dp).testTag("group_menu_button"),
              ) {
                Text("⋮", color = TextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
              }
              if (group.ownerUsername.equals(myName, ignoreCase = true) && joinRequests.isNotEmpty()) {
                Box(
                  modifier =
                    Modifier.align(Alignment.TopEnd)
                      .padding(top = 8.dp, end = 8.dp)
                      .size(9.dp)
                      .clip(CircleShape)
                      .background(CyberGold)
                )
              }
              DropdownMenu(expanded = groupMenuOpen, onDismissRequest = { groupMenuOpen = false }) {
                if (!group.isDm) DropdownMenuItem(
                  text = { Text("کپی لینک دعوت") },
                  leadingIcon = { Icon(BaziIcons.Copy, contentDescription = null, modifier = Modifier.size(20.dp)) },
                  modifier = Modifier.testTag("copy_invite_menu_item"),
                  onClick = {
                    groupMenuOpen = false
                    clipboard.setText(AnnotatedString(group.shareCode.ifBlank { group.inviteCode }))
                    android.widget.Toast.makeText(ctx, "لینک دعوت کپی شد", android.widget.Toast.LENGTH_SHORT).show()
                  },
                )
                DropdownMenuItem(
                  text = { Text(if (group.isDm) "حذف گفتگو" else "خروج از گروه") },
                  leadingIcon = { Icon(BaziIcons.Logout, contentDescription = null, modifier = Modifier.size(20.dp)) },
                  onClick = {
                    groupMenuOpen = false
                    showLeaveDialog = true
                  },
                )
                if (!group.isDm && group.ownerUsername.equals(myName, ignoreCase = true)) {
                  DropdownMenuItem(
                    text = { Text(if (joinRequests.isEmpty()) "درخواست‌های عضویت" else "درخواست‌های عضویت (${joinRequests.size})") },
                    leadingIcon = { Icon(BaziIcons.PersonAdd, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    onClick = {
                      groupMenuOpen = false
                      showRequestsDialog = true
                    },
                  )
                  DropdownMenuItem(
                    text = { Text("حذف گروه برای همه", color = Color(0xFFF87171)) },
                    onClick = {
                      groupMenuOpen = false
                      showDeleteDialog = true
                    },
                  )
                }
              }
            }
          }
        }

        if (!feedbackMessage.isNullOrBlank()) {
          Text(
            text = feedbackMessage,
            style = MaterialTheme.typography.labelSmall,
            color = ElectricEmerald,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
          )
        }
      }
    }

    // 2. Wallpaper + Messages
    val wallpaperHeight = LocalConfiguration.current.screenHeightDp.dp
    Box(
      modifier =
        Modifier.weight(1f)
          .fillMaxWidth()
          .clipToBounds()
          .background(
            Brush.verticalGradient(
              listOf(Color(0xFF060A14), Color(0xFF0E1626), Color(0xFF050812))
            )
          )
    ) {
      // Default chat wallpaper: fixed to screen height + TopCenter so opening the keyboard never shifts or zooms it.
      Image(
        painter = androidx.compose.ui.res.painterResource(com.example.R.drawable.bg_chat_cats),
        contentDescription = null,
        modifier = Modifier.fillMaxWidth().requiredHeight(wallpaperHeight).align(Alignment.TopCenter),
        contentScale = ContentScale.Crop,
        alignment = Alignment.TopCenter,
      )

      LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
        contentPadding = PaddingValues(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        if (messages.isEmpty()) {
          item(key = "empty") {
            Box(
              modifier = Modifier.fillMaxWidth().padding(vertical = 36.dp),
              contentAlignment = Alignment.Center,
            ) {
              Surface(
                shape = RoundedCornerShape(50),
                color = Color(0x991B2540),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
              ) {
                Text(
                  text = "اولین پیام، عکس یا دعوت بازی را بفرستید!",
                  style = MaterialTheme.typography.bodyMedium,
                  color = TextSecondary,
                  modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
              }
            }
          }
        }

        items(
          rows,
          key = {
            when (it) {
              is ChatRow.DateHeader -> "d_${it.label}"
              is ChatRow.Msg -> it.msg.id
            }
          },
        ) { row ->
          when (row) {
            is ChatRow.DateHeader ->
              Box(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
              ) {
                Surface(shape = RoundedCornerShape(50), color = Color(0xAA1B2540)) {
                  Text(
                    text = row.label,
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 3.dp),
                  )
                }
              }
            is ChatRow.Msg -> {
              val msg = row.msg
              val isMe = msg.senderUsername.equals(myName, ignoreCase = true)
              val tick =
                when {
                  !isMe -> TickState.SENT
                  msg.sendState == SendState.SENDING -> TickState.CLOCK
                  msg.sendState == SendState.FAILED -> TickState.FAILED
                  reads.any { (u, ts) -> !u.equals(myName, ignoreCase = true) && ts >= msg.timestamp } ->
                    TickState.READ
                  else -> TickState.SENT
                }
              TelegramMessageRow(
                msg = msg,
                isMe = isMe,
                showName = row.first && !isMe,
                showAvatar = row.last && !isMe,
                onAvatarClick = { onOpenUserProfile(msg.senderUsername) },
                avatarImage = avatars[msg.senderUsername.lowercase()]?.bitmap,
                displayName = senderNames[msg.senderUsername.lowercase()] ?: msg.senderUsername,
                replyName = msg.replyToSender?.let { senderNames[it.lowercase()] ?: it } ?: "",
                isLastInBlock = row.last,
                topGap = row.first,
                tick = tick,
                onJoinGameInvite = onJoinGameInvite,
                onReply = { onSetReply(msg) },
                onCopy = { clipboard.setText(AnnotatedString(msg.text)) },
                onEdit =
                  if (
                    isMe &&
                      msg.gameInvite == null &&
                      msg.sendState != SendState.SENDING &&
                      (msg.text.isNotBlank() || msg.hasImage) &&
                      !msg.text.startsWith("🔒")
                  ) {
                    { onStartEdit(msg) }
                  } else null,
                onDelete =
                  if (isMe || (!group.isDm && group.ownerUsername.equals(myName, ignoreCase = true))) {
                    { deleteTarget = msg }
                  } else null,
                onRetry = { onRetry(msg) },
                onOpenImage = { viewerMessage = msg },
                loadImage = loadImage,
                onJumpTo = { id ->
                  val idx = rows.indexOfFirst { it is ChatRow.Msg && it.msg.id == id }
                  if (idx >= 0) scope.launch { listState.animateScrollToItem(idx) }
                },
              )
            }
          }
        }
      }

      if (!nearBottom && rows.isNotEmpty()) {
        Surface(
          onClick = { scope.launch { listState.animateScrollToItem(rows.lastIndex) } },
          shape = CircleShape,
          color = Color(0xF01B2540),
          border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
          shadowElevation = 6.dp,
          modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp).size(42.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(BaziIcons.ArrowDown, contentDescription = "پایین", tint = NeonCyan, modifier = Modifier.size(24.dp))
          }
        }
      }
    }

    // 3. Composer
    Surface(
      color = Color(0xF20F172A),
      border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {
        if (editing != null) {
          Row(
            modifier =
              Modifier.fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x2200E5FF))
                .border(1.dp, NeonCyan.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(Icons.Rounded.Edit, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
            Box(Modifier.width(3.dp).height(32.dp).clip(RoundedCornerShape(2.dp)).background(NeonCyan))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                "ویرایش پیام",
                style = MaterialTheme.typography.labelMedium,
                color = NeonCyan,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = if (editing.hasImage && editing.text.isBlank()) "📷 عکس" else editing.text,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
            IconButton(onClick = { messageText = ""; onCancelEdit() }, modifier = Modifier.size(44.dp)) {
              Icon(Icons.Rounded.Close, contentDescription = "لغو ویرایش", tint = TextSecondary)
            }
          }
        }
        if (replyTo != null) {
          Row(
            modifier =
              Modifier.fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x2200E5FF))
                .border(1.dp, NeonCyan.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(BaziIcons.Reply, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
            Box(Modifier.width(3.dp).height(32.dp).clip(RoundedCornerShape(2.dp)).background(NeonCyan))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                "پاسخ به ${replyTo.senderUsername}",
                style = MaterialTheme.typography.labelMedium,
                color = NeonCyan,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = if (replyTo.hasImage && replyTo.text.isBlank()) "📷 عکس" else replyTo.text,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
            IconButton(onClick = { onSetReply(null) }, modifier = Modifier.size(44.dp)) {
              Icon(Icons.Rounded.Close, contentDescription = "لغو پاسخ", tint = TextSecondary)
            }
          }
        }

        if (draftImagePath != null || imageBusy) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            val thumb by
              produceState<ImageBitmap?>(null, draftImagePath) {
                value =
                  draftImagePath?.let { p ->
                    withContext(Dispatchers.IO) {
                      ChatImageUtils.decodeSampled(File(p), 256)?.asImageBitmap()
                    }
                  }
              }
            Box(
              modifier =
                Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x44000000)),
              contentAlignment = Alignment.Center,
            ) {
              val t = thumb
              if (t != null) {
                Image(t, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
              } else {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp, color = NeonCyan)
              }
            }
            Column(modifier = Modifier.weight(1f)) {
              Text("عکس آماده ارسال", style = MaterialTheme.typography.labelLarge, color = TextPrimary)
              Text(
                "در صورت تمایل توضیح بنویسید",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
              )
            }
            IconButton(onClick = onClearDraftImage, modifier = Modifier.size(44.dp)) {
              Icon(Icons.Rounded.Close, contentDescription = "حذف عکس", tint = TextSecondary)
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
          verticalAlignment = Alignment.Bottom,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Surface(
            onClick = { showGameInvitePicker = true },
            shape = CircleShape,
            color = CyberGold.copy(alpha = 0.16f),
            border = BorderStroke(1.dp, CyberGold.copy(alpha = 0.45f)),
            modifier = Modifier.size(44.dp).testTag("send_game_invite_button"),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(BaziIcons.SportsEsports, contentDescription = "دعوت به بازی", tint = CyberGold, modifier = Modifier.size(22.dp))
            }
          }

          Surface(
            onClick = { photoPicker.launch("image/*") },
            shape = CircleShape,
            color = NeonCyan.copy(alpha = 0.14f),
            border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.45f)),
            modifier = Modifier.size(44.dp).testTag("attach_photo_button"),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(BaziIcons.Photo, contentDescription = "ارسال عکس", tint = NeonCyan, modifier = Modifier.size(22.dp))
            }
          }

          BasicTextField(
            value = messageText,
            onValueChange = {
              messageText = it
              if (it.isNotBlank()) onTyping() else onTypingStopped()
            },
            maxLines = 5,
            textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
            cursorBrush = SolidColor(NeonCyan),
            modifier = Modifier.weight(1f).testTag("chat_message_input"),
            decorationBox = { inner ->
              Box(
                modifier =
                  Modifier.fillMaxWidth()
                    .heightIn(min = 44.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0xCC0A101D))
                    .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(22.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                contentAlignment = Alignment.CenterStart,
              ) {
                if (messageText.isEmpty()) {
                  Text(
                    if (draftImagePath != null) "توضیح..." else "پیام...",
                    color = TextMuted,
                    style = MaterialTheme.typography.bodyMedium,
                  )
                }
                inner()
              }
            },
          )

          val canSend =
            if (editing != null) messageText.isNotBlank() || editing.hasImage
            else (messageText.isNotBlank() || draftImagePath != null) && !imageBusy
          Box(
            modifier =
              Modifier.size(44.dp)
                .clip(CircleShape)
                .background(
                  if (canSend) Brush.linearGradient(listOf(NeonCyan, Color(0xFF673AB7)))
                  else Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A)))
                )
                .border(
                  width = 1.dp,
                  brush = if (canSend) Brush.linearGradient(listOf(NeonCyan, ElectricEmerald)) else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.08f), Color.Transparent)),
                  shape = CircleShape,
                )
                .clickable(enabled = canSend) {
                  onSendMessage(messageText)
                  onTypingStopped()
                  com.example.data.SoundManager.play(com.example.data.Sfx.MSG_SEND)
                  messageText = ""
                  onClearFeedback()
                }
                .testTag("send_chat_message_button"),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Rounded.Send,
              contentDescription = "ارسال",
              tint = if (canSend) Color.White else TextSecondary,
              modifier = Modifier.size(20.dp),
            )
          }
        }
      }
    }
  }

  if (showRequestsDialog) {
    AlertDialog(
      onDismissRequest = { showRequestsDialog = false },
      containerColor = Color(0xFF182238),
      title = { Text("درخواست‌های عضویت", color = NeonCyan) },
      text = {
        if (joinRequests.isEmpty()) {
          Text("درخواستی در انتظار تأیید نیست.", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            joinRequests.forEach { req ->
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                AvatarBadge(name = req.username, colorIndex = group.colorOf(req.username), size = 34.dp)
                Text(
                  text = req.username,
                  color = TextPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier.weight(1f),
                )
                TextButton(onClick = { onResolveJoinRequest(req.username, false) }) {
                  Text("رد", color = Color(0xFFF87171))
                }
                Button(
                  onClick = { onResolveJoinRequest(req.username, true) },
                  colors = ButtonDefaults.buttonColors(containerColor = ElectricEmerald),
                ) {
                  Text("تأیید", color = ObsidianBg, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showRequestsDialog = false }) { Text("بستن", color = NeonCyan) }
      },
    )
  }

  deleteTarget?.let { target ->
    val notSent = target.sendState != SendState.SENT
    AlertDialog(
      onDismissRequest = { deleteTarget = null },
      containerColor = Color(0xFF182238),
      title = { Text("حذف پیام", color = Color(0xFFF87171)) },
      text = {
        Text(
          if (notSent) "این پیام فقط از روی این دستگاه حذف می‌شود."
          else "این پیام برای همه‌ی اعضای گروه حذف می‌شود و قابل بازگشت نیست.",
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary,
        )
      },
      confirmButton = {
        Button(
          onClick = {
            deleteTarget = null
            onDeleteMessage(target)
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF87171)),
          modifier = Modifier.testTag("confirm_delete_message_button"),
        ) {
          Text("حذف", color = Color.White, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { deleteTarget = null }) { Text("انصراف", color = TextSecondary) }
      },
    )
  }

  viewerMessage?.let { vm ->
    ImageViewerDialog(msg = vm, loadImage = loadImage, onDismiss = { viewerMessage = null })
  }

  if (showInviteMemberDialog) {
    var targetUser by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showInviteMemberDialog = false },
      containerColor = Color(0xFF182238),
      title = { Text("دعوت عضو به گروه", color = ElectricEmerald) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            "نام کاربری دوستت را وارد کن تا به گروه اضافه شود و کلید رمزنگاری به‌صورت خودکار و امن برایش ارسال شود. همچنین می‌توانی کد دعوت کامل را کپی کرده و برایش بفرستی.",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
          )
          OutlinedTextField(
            value = targetUser,
            onValueChange = { targetUser = it.take(32) },
            label = { Text("نام کاربری دوست") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = {
              if (targetUser.isNotBlank()) {
                onInviteMember(targetUser)
                showInviteMemberDialog = false
              }
            }),
            modifier = Modifier.fillMaxWidth().testTag("invite_username_input"),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (targetUser.isNotBlank()) {
              onInviteMember(targetUser)
              showInviteMemberDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = ElectricEmerald),
          modifier = Modifier.testTag("confirm_invite_member_button"),
        ) {
          Text("افزودن به گروه", color = ObsidianBg, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showInviteMemberDialog = false }) { Text("بستن", color = TextSecondary) }
      },
    )
  }

  if (showLeaveDialog) {
    AlertDialog(
      onDismissRequest = { showLeaveDialog = false },
      containerColor = Color(0xFF182238),
      title = { Text("خروج از گروه", color = CyberGold) },
      text = {
        Text(
          buildString {
            if (group.isDm) append("این گفتگو و پیام‌های آن از روی این دستگاه پاک می‌شود. با شروع دوباره‌ی گفتگو، پیام‌های جدید دوباره می‌آیند.")
            else append("از گروه «${group.name}» خارج می‌شوی و پیام‌های آن از روی این دستگاه پاک می‌شود. برای برگشتن باید دوباره کد دعوت را وارد کنی.")
            if (!group.isDm && group.ownerUsername.equals(myName, ignoreCase = true) && group.members.size > 1) {
              append("\nچون سازنده‌ی گروه هستی، مالکیت گروه به عضو بعدی منتقل می‌شود.")
            }
          },
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary,
        )
      },
      confirmButton = {
        Button(
          onClick = {
            showLeaveDialog = false
            onLeaveGroup()
          },
          colors = ButtonDefaults.buttonColors(containerColor = CyberGold),
          modifier = Modifier.testTag("confirm_leave_group_button"),
        ) {
          Text("خروج", color = ObsidianBg, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showLeaveDialog = false }) { Text("انصراف", color = TextSecondary) }
      },
    )
  }

  if (showDeleteDialog) {
    AlertDialog(
      onDismissRequest = { showDeleteDialog = false },
      containerColor = Color(0xFF182238),
      title = { Text("حذف گروه", color = Color(0xFFF87171)) },
      text = {
        Text(
          "گروه «${group.name}» و همه‌ی پیام‌هایش برای همه‌ی اعضا از سرور پاک می‌شود و قابل بازگشت نیست.",
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary,
        )
      },
      confirmButton = {
        Button(
          onClick = {
            showDeleteDialog = false
            onDeleteGroup()
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF87171)),
          modifier = Modifier.testTag("confirm_delete_group_button"),
        ) {
          Text("حذف برای همه", color = Color.White, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showDeleteDialog = false }) { Text("انصراف", color = TextSecondary) }
      },
    )
  }

  if (showGameInvitePicker) {
    AlertDialog(
      onDismissRequest = { showGameInvitePicker = false },
      containerColor = Color(0xFF182238),
      title = { Text("ارسال دعوت بازی در گروه", color = CyberGold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          GameType.entries.forEach { g ->
            OutlinedButton(
              onClick = {
                onSendGameInvite(g)
                showGameInvitePicker = false
              },
              modifier = Modifier.fillMaxWidth().height(48.dp),
              border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f)),
              shape = RoundedCornerShape(12.dp),
            ) {
              Text("دعوت به ${g.titleFa}", color = TextPrimary)
            }
          }
        }
      },
      confirmButton = {},
      dismissButton = {
        TextButton(onClick = { showGameInvitePicker = false }) { Text("بستن", color = TextSecondary) }
      },
    )
  }
}

/** Swipe a bubble sideways to reply, exactly like Telegram. */
@Composable
private fun SwipeToReply(onReply: () -> Unit, content: @Composable () -> Unit) {
  val offsetX = remember { Animatable(0f) }
  val scope = rememberCoroutineScope()
  val haptic = LocalHapticFeedback.current
  val thresholdPx = with(LocalDensity.current) { 64.dp.toPx() }
  val maxPx = thresholdPx * 1.35f
  var triggered by remember { mutableStateOf(false) }
  val latestReply by rememberUpdatedState(onReply)

  Box(
    modifier =
      Modifier.fillMaxWidth().pointerInput(Unit) {
        detectHorizontalDragGestures(
          onDragStart = { triggered = false },
          onDragEnd = { scope.launch { offsetX.animateTo(0f, spring(stiffness = Spring.StiffnessMedium)) } },
          onDragCancel = { scope.launch { offsetX.animateTo(0f, spring(stiffness = Spring.StiffnessMedium)) } },
        ) { change, drag ->
          change.consume()
          val n = (offsetX.value + drag * 0.6f).coerceIn(-maxPx, maxPx)
          scope.launch { offsetX.snapTo(n) }
          if (!triggered && kotlin.math.abs(n) >= thresholdPx) {
            triggered = true
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            latestReply()
          }
        }
      }
  ) {
    val progress = (kotlin.math.abs(offsetX.value) / thresholdPx).coerceIn(0f, 1f)
    if (progress > 0.05f) {
      Box(
        modifier =
          Modifier.align(if (offsetX.value < 0) Alignment.CenterEnd else Alignment.CenterStart)
            .padding(horizontal = 14.dp)
            .size(30.dp)
            .graphicsLayer {
              alpha = progress
              scaleX = 0.6f + 0.4f * progress
              scaleY = 0.6f + 0.4f * progress
            }
            .clip(CircleShape)
            .background(Color(0x55000000)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(BaziIcons.Reply, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
      }
    }
    Box(modifier = Modifier.fillMaxWidth().graphicsLayer { translationX = offsetX.value }) { content() }
  }
}

/**
 * Telegram-style direction: the first strong letter of the message decides whether the whole bubble
 * (sender name, reply quote, text, time) is laid out RTL or LTR, so every part of one bubble lines up
 * on the same edge. No letters at all (numbers / emoji) -> RTL, this is a Persian app.
 */
private fun isRtlText(text: String): Boolean {
  for (ch in text) {
    if (!Character.isLetter(ch)) continue
    val d = Character.getDirectionality(ch)
    return d == Character.DIRECTIONALITY_RIGHT_TO_LEFT || d == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC
  }
  return true
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TelegramMessageRow(
  msg: ChatMessage,
  isMe: Boolean,
  showName: Boolean,
  showAvatar: Boolean,
  onAvatarClick: () -> Unit,
  avatarImage: androidx.compose.ui.graphics.ImageBitmap?,
  displayName: String,
  replyName: String,
  isLastInBlock: Boolean,
  topGap: Boolean,
  tick: TickState,
  onJoinGameInvite: (GameInvite) -> Unit,
  onReply: () -> Unit,
  onCopy: () -> Unit,
  onEdit: (() -> Unit)? = null,
  onDelete: (() -> Unit)?,
  onRetry: () -> Unit,
  onOpenImage: () -> Unit,
  loadImage: suspend (ChatMessage, Int) -> Bitmap?,
  onJumpTo: (String) -> Unit,
) {
  // RTL layout: Arrangement.Start is RIGHT (outgoing), Arrangement.End is LEFT (incoming)
  val big = 18.dp
  val tail = 5.dp
  // Bubbles never exceed ~80% of the screen, so layout is the same on every phone size.
  val screenW = LocalConfiguration.current.screenWidthDp
  val maxBubble = (screenW * 0.8f).coerceIn(240f, 380f).dp
  val avatarSize = 40.dp
  val bubbleShape =
    if (isMe) {
      RoundedCornerShape(topStart = big, topEnd = big, bottomStart = if (isLastInBlock) tail else big, bottomEnd = big)
    } else {
      RoundedCornerShape(topStart = big, topEnd = big, bottomStart = big, bottomEnd = if (isLastInBlock) tail else big)
    }

  val bubbleBrush =
    if (isMe) Brush.linearGradient(listOf(Color(0xFF2B5278), Color(0xFF2A4A75)))
    else Brush.linearGradient(listOf(Color(0xFF182533), Color(0xFF17222F)))
  val borderColor = if (isMe) Color.White.copy(alpha = 0.06f) else Color.White.copy(alpha = 0.05f)
  var menuOpen by remember { mutableStateOf(false) }
  val photoOnly = msg.hasImage && msg.text.isBlank()

  SwipeToReply(onReply = onReply) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(top = if (topGap) 8.dp else 0.dp),
      horizontalArrangement = if (isMe) Arrangement.Start else Arrangement.End,
      verticalAlignment = Alignment.Bottom,
    ) {
      Row(
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Box {
          Box(
            modifier =
              (if (msg.hasImage) Modifier.width(minOf(if (photoOnly) 272.dp else 280.dp, maxBubble)) else Modifier.widthIn(min = 80.dp, max = maxBubble))
                .clip(bubbleShape)
                .background(bubbleBrush)
                .border(1.dp, borderColor, bubbleShape)
                .combinedClickable(onClick = {}, onLongClick = { menuOpen = true })
                .padding(
                  horizontal = if (msg.hasImage) 3.dp else 12.dp,
                  vertical = if (msg.hasImage) 3.dp else 7.dp,
                )
          ) {
            val bubbleDir = remember(msg.text) { if (isRtlText(msg.text)) LayoutDirection.Rtl else LayoutDirection.Ltr }
            CompositionLocalProvider(LocalLayoutDirection provides bubbleDir) {
              TelegramBubbleContent(
                msg = msg,
                isMe = isMe,
                showName = showName,
                displayName = displayName,
                replyName = replyName,
                photoOnly = photoOnly,
                tick = tick,
                onJoinGameInvite = onJoinGameInvite,
                onOpenImage = onOpenImage,
                onRetry = onRetry,
                loadImage = loadImage,
                onJumpTo = onJumpTo,
              )
            }
          }
          DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            DropdownMenuItem(
              text = { Text("پاسخ") },
              leadingIcon = { Icon(BaziIcons.Reply, contentDescription = null, modifier = Modifier.size(20.dp)) },
              onClick = {
                menuOpen = false
                onReply()
              },
            )
            if (msg.text.isNotBlank()) {
              DropdownMenuItem(
                text = { Text("کپی متن") },
                leadingIcon = { Icon(BaziIcons.Copy, contentDescription = null, modifier = Modifier.size(20.dp)) },
                onClick = {
                  menuOpen = false
                  onCopy()
                },
              )
            }
            if (onEdit != null) {
              DropdownMenuItem(
                text = { Text("ویرایش") },
                leadingIcon = { Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(20.dp)) },
                onClick = {
                  menuOpen = false
                  onEdit()
                },
              )
            }
            if (tick == TickState.FAILED) {
              DropdownMenuItem(
                text = { Text("تلاش دوباره") },
                onClick = {
                  menuOpen = false
                  onRetry()
                },
              )
            }
            if (onDelete != null) {
              DropdownMenuItem(
                text = { Text("حذف پیام", color = Color(0xFFF87171)) },
                leadingIcon = {
                  Icon(Icons.Rounded.Delete, contentDescription = null, tint = Color(0xFFF87171), modifier = Modifier.size(20.dp))
                },
                onClick = {
                  menuOpen = false
                  onDelete()
                },
              )
            }
          }
        }
        if (!isMe) {
          if (showAvatar) {
            AvatarBadge(
              name = msg.senderUsername,
              colorIndex = msg.senderColorIndex,
              size = avatarSize,
              image = avatarImage,
              modifier = Modifier.clickable(onClick = onAvatarClick).testTag("msg_avatar_${msg.senderUsername}"),
            )
          } else {
            Spacer(Modifier.size(avatarSize))
          }
        }
      }
    }
  }
}

@Composable
private fun TelegramBubbleContent(
  msg: ChatMessage,
  isMe: Boolean,
  showName: Boolean,
  displayName: String,
  replyName: String,
  photoOnly: Boolean,
  tick: TickState,
  onJoinGameInvite: (GameInvite) -> Unit,
  onOpenImage: () -> Unit,
  onRetry: () -> Unit,
  loadImage: suspend (ChatMessage, Int) -> Bitmap?,
  onJumpTo: (String) -> Unit,
) {
  val pad = if (msg.hasImage) Modifier.padding(horizontal = 7.dp, vertical = 2.dp) else Modifier
  val bubbleTextDir =
    if (LocalLayoutDirection.current == LayoutDirection.Rtl) TextDirection.Rtl else TextDirection.Ltr
  // IntrinsicSize.Max: every part of the bubble (name, reply quote, text, time) shares the width of
  // the widest one, so bubbles hug their content instead of some stretching to full width.
  Column(
    modifier = if (msg.hasImage) Modifier else Modifier.width(androidx.compose.foundation.layout.IntrinsicSize.Max),
    verticalArrangement = Arrangement.spacedBy(2.dp),
  ) {
    if (showName) {
      Text(
        text = displayName,
        style = MaterialTheme.typography.labelMedium.copy(textDirection = bubbleTextDir, textAlign = TextAlign.Left),
        color = avatarColorFor(msg.senderColorIndex),
        fontWeight = FontWeight.ExtraBold,
        modifier = Modifier.fillMaxWidth().then(if (msg.hasImage) Modifier.padding(start = 7.dp, top = 3.dp, end = 7.dp) else Modifier),
      )
    }

    if (msg.replyToId != null) {
      Row(
        modifier =
          Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0x33000000))
            .clickable { onJumpTo(msg.replyToId) }
            .padding(horizontal = 8.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(Modifier.width(3.dp).height(32.dp).clip(RoundedCornerShape(2.dp)).background(NeonCyan))
        Column(modifier = Modifier.weight(1f)) {
          Text(
            replyName,
            style = MaterialTheme.typography.labelSmall.copy(textDirection = bubbleTextDir, textAlign = TextAlign.Start),
            color = NeonCyan,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            modifier = Modifier.fillMaxWidth(),
          )
          Text(
            msg.replyToText ?: "",
            modifier = Modifier.fillMaxWidth(),
            style = MaterialTheme.typography.bodySmall.copy(textDirection = bubbleTextDir, textAlign = TextAlign.Start),
            color = TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }

    if (msg.hasImage) {
      ChatImageView(
        msg = msg,
        loadImage = loadImage,
        onOpen = onOpenImage,
        overlay =
          if (photoOnly) {
            {
              Surface(
                shape = RoundedCornerShape(50),
                color = Color(0x99000000),
                modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp),
              ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                  MessageMeta(msg, isMe, tick, onRetry, light = true, modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp))
                }
              }
            }
          } else null,
      )
    }

    if (msg.text.isNotBlank()) {
      Text(
        text = msg.text,
        style = MaterialTheme.typography.bodyLarge.copy(fontSize = 15.sp, lineHeight = 23.sp, textDirection = TextDirection.Content, textAlign = TextAlign.Start),
        color = TextPrimary,
        modifier = pad.fillMaxWidth(),
      )
    }

    msg.gameInvite?.let { invite ->
      Row(
        modifier =
          Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x661B2540))
            .border(1.dp, VioletPulse.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Box(
          modifier =
            Modifier.width(3.dp)
              .height(38.dp)
              .clip(RoundedCornerShape(2.dp))
              .background(CyberGold)
        )
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "دعوت بازی ${invite.gameType.titleFa}",
            style = MaterialTheme.typography.labelLarge,
            color = CyberGold,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = "کد اتاق: ${invite.roomCode}",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
          )
        }
        Button(
          onClick = { onJoinGameInvite(invite) },
          colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
          shape = RoundedCornerShape(50),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
          modifier = Modifier.height(34.dp),
        ) {
          Text("شروع", color = ObsidianBg, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold)
        }
      }
    }

    if (!photoOnly) {
      MessageMeta(
        msg, isMe, tick, onRetry, light = false,
        modifier = Modifier.align(Alignment.End).then(if (msg.hasImage) Modifier.padding(end = 7.dp, bottom = 1.dp) else Modifier),
      )
    }
  }
}

@Composable
private fun MessageMeta(
  msg: ChatMessage,
  isMe: Boolean,
  tick: TickState,
  onRetry: () -> Unit,
  light: Boolean,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier,
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(4.dp),
  ) {
    if (msg.edited) {
      Text(
        text = "ویرایش‌شده",
        style = MaterialTheme.typography.labelSmall,
        color = if (light) Color.White else if (isMe) Color(0xFFB3E5FC) else TextMuted,
      )
    }
    Text(
      text = formatClockTime(msg.timestamp),
      style = MaterialTheme.typography.labelSmall,
      color = if (light) Color.White else if (isMe) Color(0xFFB3E5FC) else TextMuted,
    )
    if (isMe) {
      TelegramTicks(
        state = tick,
        modifier = if (tick == TickState.FAILED) Modifier.clickable(onClick = onRetry) else Modifier,
      )
    }
  }
}

@Composable
private fun ChatImageView(
  msg: ChatMessage,
  loadImage: suspend (ChatMessage, Int) -> Bitmap?,
  onOpen: () -> Unit,
  overlay: (@Composable BoxScope.() -> Unit)?,
) {
  val loaded by
    produceState<Pair<Boolean, ImageBitmap?>>(false to null, msg.id) {
      value = true to loadImage(msg, 900)?.asImageBitmap()
    }
  val bmp = loaded.second
  val ratio = bmp?.let { (it.width.toFloat() / it.height).coerceIn(0.8f, 1.5f) } ?: 1.2f
  Box(
    modifier =
      Modifier.fillMaxWidth()
        .aspectRatio(ratio)
        .clip(RoundedCornerShape(13.dp))
        .background(Color(0x33000000))
        .clickable(enabled = bmp != null, onClick = onOpen),
    contentAlignment = Alignment.Center,
  ) {
    when {
      bmp != null ->
        Image(bmp, contentDescription = "عکس", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
      !loaded.first ->
        CircularProgressIndicator(modifier = Modifier.size(26.dp), strokeWidth = 2.dp, color = NeonCyan)
      else -> Icon(BaziIcons.Photo, contentDescription = null, tint = TextMuted, modifier = Modifier.size(34.dp))
    }
    overlay?.invoke(this)
  }
}

@Composable
private fun ImageViewerDialog(
  msg: ChatMessage,
  loadImage: suspend (ChatMessage, Int) -> Bitmap?,
  onDismiss: () -> Unit,
) {
  val bmp by produceState<ImageBitmap?>(null, msg.id) { value = loadImage(msg, 2000)?.asImageBitmap() }
  var scale by remember { mutableFloatStateOf(1f) }
  var pan by remember { mutableStateOf(Offset.Zero) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(Color(0xF2000000))
          .pointerInput(Unit) { detectTapGestures(onTap = { onDismiss() }, onDoubleTap = { scale = 1f; pan = Offset.Zero }) }
          .pointerInput(Unit) {
            detectTransformGestures { _, p, zoom, _ ->
              scale = (scale * zoom).coerceIn(1f, 5f)
              pan = if (scale > 1f) pan + p else Offset.Zero
            }
          },
      contentAlignment = Alignment.Center,
    ) {
      val b = bmp
      if (b != null) {
        Image(
          b,
          contentDescription = "عکس",
          contentScale = ContentScale.Fit,
          modifier =
            Modifier.fillMaxSize().graphicsLayer {
              scaleX = scale
              scaleY = scale
              translationX = pan.x
              translationY = pan.y
            },
        )
      } else {
        CircularProgressIndicator(color = NeonCyan)
      }
      IconButton(
        onClick = onDismiss,
        modifier = Modifier.align(Alignment.TopEnd).padding(12.dp).systemBarsPadding(),
      ) {
        Icon(Icons.Rounded.Close, contentDescription = "بستن", tint = Color.White)
      }
      Text(
        text = msg.senderUsername + if (msg.text.isNotBlank()) "  •  ${msg.text}" else "",
        style = MaterialTheme.typography.bodyMedium,
        color = Color.White,
        maxLines = 2,
        modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp).systemBarsPadding(),
      )
    }
  }
}

/** Telegram-style status: clock (sending), ✓ (sent), ✓✓ blue (read), red ! (failed). */
@Composable
private fun TelegramTicks(state: TickState, modifier: Modifier = Modifier) {
  val grey = Color(0xFFA9C1E3)
  val blue = Color(0xFF38BDF8)
  Canvas(modifier = modifier.size(17.dp, 11.dp)) {
    val w = size.width
    val h = size.height
    val stroke = Stroke(width = 2.1f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    when (state) {
      TickState.CLOCK -> {
        val c = Offset(w * 0.78f, h * 0.5f)
        val r = h * 0.46f
        drawCircle(color = grey, radius = r, center = c, style = Stroke(width = 1.6f))
        drawLine(grey, c, Offset(c.x, c.y - r * 0.6f), strokeWidth = 1.6f, cap = StrokeCap.Round)
        drawLine(grey, c, Offset(c.x + r * 0.45f, c.y), strokeWidth = 1.6f, cap = StrokeCap.Round)
      }
      TickState.FAILED -> {
        val c = Offset(w * 0.78f, h * 0.5f)
        drawCircle(color = Color(0xFFF43F5E), radius = h * 0.5f, center = c)
        drawLine(Color.White, Offset(c.x, c.y - h * 0.26f), Offset(c.x, c.y + h * 0.05f), strokeWidth = 2f, cap = StrokeCap.Round)
        drawCircle(color = Color.White, radius = 1.2f, center = Offset(c.x, c.y + h * 0.26f))
      }
      TickState.SENT -> {
        val p =
          Path().apply {
            moveTo(w * 0.52f, h * 0.55f)
            lineTo(w * 0.72f, h * 0.85f)
            lineTo(w * 1.0f - 1f, h * 0.12f)
          }
        drawPath(p, color = grey, style = stroke)
      }
      TickState.READ -> {
        val p1 =
          Path().apply {
            moveTo(1f, h * 0.55f)
            lineTo(w * 0.22f, h * 0.85f)
            lineTo(w * 0.52f, h * 0.12f)
          }
        val p2 =
          Path().apply {
            moveTo(w * 0.40f, h * 0.62f)
            lineTo(w * 0.60f, h * 0.85f)
            lineTo(w * 0.98f, h * 0.12f)
          }
        drawPath(p1, color = blue, style = stroke)
        drawPath(p2, color = blue, style = stroke)
      }
    }
  }
}

private fun formatClockTime(ts: Long): String {
  if (ts <= 0L) return "الان"
  return try {
    SimpleDateFormat("HH:mm", Locale.US).format(Date(ts))
  } catch (_: Throwable) {
    "الان"
  }
}

fun isUserOnline(lastSeen: Long?): Boolean {
  if (lastSeen == null || lastSeen <= 0L) return false
  return (System.currentTimeMillis() - lastSeen) < 150_000L // 2.5 minutes
}

fun formatPresenceStatus(lastSeen: Long?): String {
  if (lastSeen == null || lastSeen <= 0L) return "آخرین بازدید خیلی وقت پیش"
  val diff = System.currentTimeMillis() - lastSeen
  if (diff < 150_000L) return "آنلاین"
  if (diff < 300_000L) return "آخرین بازدید لحظاتی پیش"
  val minutes = diff / 60_000L
  if (minutes < 60L) return "آخرین بازدید ${minutes} دقیقه پیش"

  val calNow = Calendar.getInstance()
  val calThen = Calendar.getInstance().apply { timeInMillis = lastSeen }

  val isToday = calNow.get(Calendar.YEAR) == calThen.get(Calendar.YEAR) &&
    calNow.get(Calendar.DAY_OF_YEAR) == calThen.get(Calendar.DAY_OF_YEAR)
  val isYesterday = calNow.get(Calendar.YEAR) == calThen.get(Calendar.YEAR) &&
    calNow.get(Calendar.DAY_OF_YEAR) - calThen.get(Calendar.DAY_OF_YEAR) == 1

  val timeStr = SimpleDateFormat("HH:mm", Locale.US).format(Date(lastSeen))
  return when {
    isToday -> "آخرین بازدید امروز در $timeStr"
    isYesterday -> "آخرین بازدید دیروز در $timeStr"
    else -> {
      val dateStr = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(lastSeen))
      "آخرین بازدید $dateStr"
    }
  }
}
