package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameType
import com.example.data.LeaderboardEntry
import com.example.ui.components.AvatarBadge
import com.example.ui.components.BaziIcons
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.auroraGamingBackdrop
import com.example.ui.components.fadeSlideIn
import com.example.ui.components.toFaDigits
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPulse

@Composable
fun LeaderboardScreen(
  entries: List<LeaderboardEntry>,
  avatars: Map<String, com.example.data.AvatarImage> = emptyMap(),
  selectedFilter: GameType?,
  onSelectFilter: (GameType?) -> Unit,
  onRefresh: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val filtered =
    if (selectedFilter == null) entries
    else entries.filter { it.favoriteGame == selectedFilter }

  Column(
    modifier =
      modifier.fillMaxSize()
        .auroraGamingBackdrop(CyberGold, VioletPulse)
        .padding(horizontal = 14.dp, vertical = 12.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    // 1. Cyber-Gaming Header
    Row(
      modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Box(
          modifier =
            Modifier.size(44.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(Brush.linearGradient(listOf(CyberGold.copy(alpha = 0.28f), Color(0xFFD97706).copy(alpha = 0.16f))))
              .border(0.8.dp, CyberGold.copy(alpha = 0.45f), RoundedCornerShape(14.dp)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(BaziIcons.Trophy, contentDescription = null, tint = CyberGold, modifier = Modifier.size(23.dp))
        }
        Column {
          Text(
            text = "تالار قهرمانان",
            style = MaterialTheme.typography.titleLarge.copy(fontSize = 21.sp),
            color = Color.White,
            fontWeight = FontWeight.ExtraBold,
          )
          Text(
            text = "برترین بازیکنان و رکوردداران آرنا",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
            color = Color(0xFF94A3B8),
          )
        }
      }

      var spinTarget by remember { mutableFloatStateOf(0f) }
      val spin by animateFloatAsState(spinTarget, tween(700, easing = FastOutSlowInEasing), label = "refresh_spin")
      Surface(
        onClick = {
          spinTarget += 360f
          onRefresh()
        },
        shape = CircleShape,
        color = Color(0xFF172133),
        border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.1f)),
        modifier = Modifier.size(42.dp).testTag("leaderboard_refresh"),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(Icons.Rounded.Refresh, contentDescription = "بروزرسانی", tint = NeonCyan, modifier = Modifier.size(21.dp).rotate(spin))
        }
      }
    }

    // 2. Gradient Filter Pills
    Row(
      modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp).horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      FilterChipPill(
        label = "همه بازی‌ها",
        selected = selectedFilter == null,
        onClick = { onSelectFilter(null) },
      )
      GameType.entries.forEach { g ->
        FilterChipPill(
          label = g.titleFa,
          selected = selectedFilter == g,
          onClick = { onSelectFilter(g) },
        )
      }
    }

    if (filtered.isEmpty()) {
      GlassGradientCard(
        modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp),
        accentColor = CyberGold,
        cornerRadius = 22.dp,
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(28.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          val bob by
            rememberInfiniteTransition(label = "trophy_bob")
              .animateFloat(
                initialValue = -6f,
                targetValue = 6f,
                animationSpec = infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                label = "trophy_bob_y",
              )
          Icon(
            BaziIcons.Trophy,
            contentDescription = null,
            tint = CyberGold,
            modifier = Modifier.size(46.dp).graphicsLayer { translationY = bob },
          )
          Text(
            if (entries.isNotEmpty()) "برای این بازی هنوز امتیازی ثبت نشده است" else "هنوز امتیازی ثبت نشده است",
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
          )
          Text(
            if (entries.isNotEmpty()) "اولین نفر باش! یا فیلتر «همه بازی‌ها» را بزن تا کل جدول را ببینی."
            else "با نام کاربری وارد شوید و اولین مسابقه خود را ببرید تا در صدر لیدربرد قرار بگیرید!",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
          )
        }
      }
    } else {
      // 3. Epic Gaming Podium (Top 3)
      val top3 = filtered.take(3)
      Row(
        modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom,
      ) {
        val podiumOrder = listOf(1, 0, 2).filter { it < top3.size }
        podiumOrder.forEach { idx ->
          val entry = top3[idx]
          val medalColor =
            when (idx) {
              0 -> CyberGold
              1 -> Color(0xFFE2E8F0)
              else -> Color(0xFFF59E0B)
            }
          val ringColor = if (entry.isCurrentUser) NeonCyan else medalColor
          val isFirst = idx == 0

          Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.Transparent,
            border =
              BorderStroke(
                width = if (isFirst) 1.2.dp else 0.8.dp,
                brush = Brush.verticalGradient(listOf(ringColor.copy(alpha = 0.65f), Color.White.copy(alpha = 0.06f))),
              ),
            modifier = Modifier.weight(1f).padding(top = if (isFirst) 0.dp else 20.dp).fadeSlideIn(2 - idx),
          ) {
            Box(
              modifier =
                Modifier.fillMaxWidth()
                  .background(
                    Brush.verticalGradient(
                      listOf(
                        if (isFirst) Color(0xFF1C2338) else Color(0xFF141D2E),
                        Color(0xFF0D1320),
                      )
                    )
                  )
            ) {
              Canvas(modifier = Modifier.matchParentSize()) {
                drawCircle(
                  brush = Brush.radialGradient(
                    listOf(ringColor.copy(alpha = if (isFirst) 0.25f else 0.14f), Color.Transparent),
                    center = Offset(size.width * 0.5f, size.height * 0.28f),
                    radius = size.width * 0.72f,
                  ),
                  center = Offset(size.width * 0.5f, size.height * 0.28f),
                  radius = size.width * 0.72f,
                )
              }

              Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                if (isFirst) {
                  Icon(BaziIcons.Crown, contentDescription = null, tint = CyberGold, modifier = Modifier.size(24.dp))
                } else {
                  Surface(
                    shape = RoundedCornerShape(50),
                    color = ringColor.copy(alpha = 0.16f),
                  ) {
                    Text(
                      text = "#${(idx + 1).toFaDigits()}",
                      style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                      color = ringColor,
                      fontWeight = FontWeight.ExtraBold,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                    )
                  }
                }

                Box(
                  modifier =
                    Modifier.size(if (isFirst) 64.dp else 52.dp)
                      .clip(CircleShape)
                      .border(2.dp, ringColor, CircleShape)
                      .padding(3.dp),
                  contentAlignment = Alignment.Center,
                ) {
                  AvatarBadge(
                    name = entry.displayName,
                    colorIndex = entry.avatarColorIndex,
                    size = if (isFirst) 56.dp else 44.dp,
                    image = avatars[entry.username.lowercase()]?.bitmap,
                  )
                }

                Text(
                  text = entry.displayName,
                  style = MaterialTheme.typography.labelLarge.copy(fontSize = if (isFirst) 14.sp else 13.sp),
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )

                Surface(
                  shape = RoundedCornerShape(50),
                  color = ringColor.copy(alpha = 0.18f),
                ) {
                  Text(
                    text = "${entry.totalScore.toFaDigits()} امتیاز",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                    color = ringColor,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
                  )
                }
              }
            }
          }
        }
      }

      // 4. Ranked List (4th+)
      LazyColumn(
        modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp).weight(1f),
        contentPadding = PaddingValues(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        itemsIndexed(filtered.drop(3), key = { _, e -> e.username }) { i, entry ->
          val rank = i + 4
          val winRatio = (entry.winRatePercent / 100f).coerceIn(0f, 1f)
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (entry.isCurrentUser) Color(0xFF15273E) else Color(0xFF131B2B),
            border =
              BorderStroke(
                0.8.dp,
                if (entry.isCurrentUser) NeonCyan.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.07f),
              ),
            modifier = Modifier.fillMaxWidth().fadeSlideIn(i),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              // Rank badge
              Box(
                modifier =
                  Modifier.size(32.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (entry.isCurrentUser) NeonCyan.copy(alpha = 0.2f) else Color(0xFF1B263B)),
                contentAlignment = Alignment.Center,
              ) {
                Text(
                  text = rank.toFaDigits(),
                  style = MaterialTheme.typography.labelLarge,
                  color = if (entry.isCurrentUser) NeonCyan else Color(0xFF94A3B8),
                  fontWeight = FontWeight.ExtraBold,
                )
              }

              AvatarBadge(
                name = entry.displayName,
                colorIndex = entry.avatarColorIndex,
                size = 42.dp,
                image = avatars[entry.username.lowercase()]?.bitmap,
              )

              Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                  text = entry.displayName,
                  style = MaterialTheme.typography.titleSmall.copy(fontSize = 14.5.sp),
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  Box(
                    modifier =
                      Modifier.width(54.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.08f))
                  ) {
                    Box(
                      modifier =
                        Modifier.fillMaxWidth(winRatio)
                          .height(4.dp)
                          .clip(CircleShape)
                          .background(Brush.horizontalGradient(listOf(ElectricEmerald, NeonCyan)))
                    )
                  }
                  Text(
                    text = "${entry.wins.toFaDigits()} برد (${entry.winRatePercent.toFaDigits()}٪)",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                    color = Color(0xFF94A3B8),
                    maxLines = 1,
                  )
                }
              }

              Surface(
                shape = RoundedCornerShape(10.dp),
                color = ElectricEmerald.copy(alpha = 0.14f),
              ) {
                Text(
                  text = "${entry.totalScore.toFaDigits()} امتیاز",
                  style = MaterialTheme.typography.labelMedium.copy(fontSize = 12.sp),
                  color = ElectricEmerald,
                  fontWeight = FontWeight.ExtraBold,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun FilterChipPill(
  label: String,
  selected: Boolean,
  onClick: () -> Unit,
) {
  Box(
    modifier =
      Modifier.clip(RoundedCornerShape(50))
        .then(
          if (selected) Modifier.background(Brush.horizontalGradient(listOf(NeonCyan, VioletPulse)))
          else Modifier.background(Color(0xFF151E2E)).border(0.8.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(50))
        )
        .clickable(onClick = onClick)
        .padding(horizontal = 14.dp, vertical = 8.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      color = if (selected) Color.White else Color(0xFF94A3B8),
      fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
    )
  }
}
