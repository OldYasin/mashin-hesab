package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.GameType
import com.example.data.LeaderboardEntry
import com.example.ui.components.AvatarBadge
import com.example.ui.components.BaziIcons
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.auroraGamingBackdrop
import com.example.ui.components.toFaDigits
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.graphicsLayer
import com.example.ui.components.fadeSlideIn

@Composable
fun LeaderboardScreen(
  entries: List<LeaderboardEntry>,
  avatars: Map<String, com.example.data.AvatarImage> = emptyMap(),
  selectedFilter: GameType?,
  onSelectFilter: (GameType?) -> Unit,
  onRefresh: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val filtered =
    if (selectedFilter == null) entries
    else entries.filter { it.favoriteGame == selectedFilter }

  Column(
    modifier =
      modifier.fillMaxSize()
        .auroraGamingBackdrop(CyberGold, NeonCyan)
        .padding(horizontal = 16.dp, vertical = 14.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column {
        Text("لیدربرد قهرمانان", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
        Text(
          "رتبه‌بندی امتیازات و پیروزی‌های بازیکنان",
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary,
        )
      }
      var spinTarget by remember { mutableFloatStateOf(0f) }
      val spin by animateFloatAsState(spinTarget, tween(700, easing = FastOutSlowInEasing), label = "refresh_spin")
      IconButton(
        onClick = {
          spinTarget += 360f
          onRefresh()
        },
        modifier = Modifier.size(48.dp).testTag("leaderboard_refresh"),
      ) {
        Icon(Icons.Rounded.Refresh, contentDescription = "بروزرسانی", tint = NeonCyan, modifier = Modifier.rotate(spin))
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp).horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      FilterChipPill(
        label = "همه بازی‌ها",
        selected = selectedFilter == null,
        onClick = { onSelectFilter(null) },
      )
      GameType.entries.forEach { g ->
        FilterChipPill(
          label = g.titleFa,
          selected = selectedFilter == g,
          onClick = { onSelectFilter(g) },
        )
      }
    }

    if (filtered.isEmpty()) {
      GlassGradientCard(
        modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp),
        accentColor = CyberGold,
        cornerRadius = 22.dp,
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(28.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          val bob by
            rememberInfiniteTransition(label = "trophy_bob")
              .animateFloat(
                initialValue = -6f,
                targetValue = 6f,
                animationSpec = infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                label = "trophy_bob_y",
              )
          Icon(
            BaziIcons.Trophy,
            contentDescription = null,
            tint = CyberGold,
            modifier = Modifier.size(44.dp).graphicsLayer { translationY = bob },
          )
          Text(
            if (entries.isNotEmpty()) "برای این بازی هنوز امتیازی ثبت نشده است" else "هنوز امتیازی ثبت نشده است",
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary,
          )
          Text(
            if (entries.isNotEmpty()) "اولین نفر باش! یا فیلتر «همه بازی‌ها» را بزن تا کل جدول را ببینی."
            else "با نام کاربری وارد شوید و اولین مسابقه خود را ببرید تا در صدر لیدربرد قرار بگیرید!",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
          )
        }
      }
    } else {
      val top3 = filtered.take(3)
      Row(
        modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom,
      ) {
        // Podium order: 2nd - 1st - 3rd, the winner stands taller.
        val podiumOrder = listOf(1, 0, 2).filter { it < top3.size }
        podiumOrder.forEach { idx ->
          val entry = top3[idx]
          val medalColor =
            when (idx) {
              0 -> CyberGold
              1 -> Color(0xFFCBD5E1)
              else -> Color(0xFFCD7F32)
            }
          GlassGradientCard(
            modifier = Modifier.weight(1f).padding(top = if (idx == 0) 0.dp else 24.dp).fadeSlideIn(2 - idx),
            accentColor = if (entry.isCurrentUser) NeonCyan else medalColor,
            cornerRadius = 18.dp,
          ) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(12.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              if (idx == 0) {
                Icon(BaziIcons.Crown, contentDescription = null, tint = CyberGold, modifier = Modifier.size(22.dp))
              }
              Text(
                text = "رتبه ${(idx + 1).toFaDigits()}",
                style = MaterialTheme.typography.titleMedium,
                color = medalColor,
                fontWeight = FontWeight.ExtraBold,
              )
              AvatarBadge(name = entry.displayName, colorIndex = entry.avatarColorIndex, size = if (idx == 0) 54.dp else 44.dp, image = avatars[entry.username.lowercase()]?.bitmap)
              Text(
                text = entry.displayName,
                style = MaterialTheme.typography.labelLarge,
                color = TextPrimary,
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
              )
              Text(
                text = "${entry.totalScore.toFaDigits()} امتیاز",
                style = MaterialTheme.typography.labelMedium,
                color = medalColor,
                fontWeight = FontWeight.Bold,
              )
            }
          }
        }
      }

      LazyColumn(
        modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp).weight(1f),
        contentPadding = PaddingValues(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        itemsIndexed(filtered.drop(3), key = { _, e -> e.username }) { i, entry ->
          GlassGradientCard(
            modifier = Modifier.fadeSlideIn(i),
            accentColor = if (entry.isCurrentUser) NeonCyan else Color.White.copy(alpha = 0.14f),
            cornerRadius = 16.dp,
          ) {
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .background(if (entry.isCurrentUser) NeonCyan.copy(alpha = 0.12f) else Color.Transparent)
                  .padding(horizontal = 14.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(
                modifier = Modifier.weight(1f).padding(end = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Text(
                  text = (i + 4).toFaDigits(),
                  style = MaterialTheme.typography.titleMedium,
                  color = TextSecondary,
                  fontWeight = FontWeight.ExtraBold,
                )
                AvatarBadge(name = entry.displayName, colorIndex = entry.avatarColorIndex, size = 38.dp, image = avatars[entry.username.lowercase()]?.bitmap)
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    entry.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                  )
                  Text(
                    text = "${entry.wins.toFaDigits()} برد از ${entry.gamesPlayed.toFaDigits()} بازی (${entry.winRatePercent.toFaDigits()}٪)",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                  )
                }
              }
              Column(horizontalAlignment = Alignment.End) {
                Text(
                  text = entry.totalScore.toFaDigits(),
                  style = MaterialTheme.typography.titleLarge,
                  color = ElectricEmerald,
                  fontWeight = FontWeight.ExtraBold,
                )
                Text("امتیاز", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun FilterChipPill(
  label: String,
  selected: Boolean,
  onClick: () -> Unit,
) {
  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(50),
    color = if (selected) NeonCyan.copy(alpha = 0.22f) else ElevatedCard.copy(alpha = 0.6f),
    border = BorderStroke(1.dp, if (selected) NeonCyan else ElevatedCardStroke),
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      color = if (selected) NeonCyan else TextSecondary,
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
    )
  }
}
