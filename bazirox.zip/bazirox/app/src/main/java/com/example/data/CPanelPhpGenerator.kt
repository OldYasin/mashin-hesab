package com.example.data

/**
 * Generates the PHP 8 + MySQL files that run on the admin's cPanel host.
 *
 * Security model (v3):
 * - Every action except ping/register/login needs a per-user session token (stored hashed).
 * - The username is always taken from the token, never from the request body.
 * - Chat names, messages, replies, game invites, previews and images are encrypted on the phones
 *   with a per-group key that never reaches this server: the host only ever stores ciphertext.
 * - Passwords never reach the server: the app sends a slow PBKDF2 verifier, stored as Argon2id/bcrypt.
 *
 * The PHP source below uses the placeholder character "§" for the PHP dollar sign so that Kotlin
 * does not treat it as a string template. It is converted back before the config is embedded.
 */
object CPanelPhpGenerator {

  fun generateSchemaSql(): String =
    """
-- Bazirox Secure MySQL Schema v3 (utf8mb4)
-- If you installed an older version, DROP the old tables first:
-- users, chat_groups, chat_messages, chat_reads, game_rooms

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(32) NOT NULL UNIQUE,
  display_name VARCHAR(64) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  avatar_color INT NOT NULL DEFAULT 0,
  total_score INT NOT NULL DEFAULT 0,
  wins INT NOT NULL DEFAULT 0,
  games_played INT NOT NULL DEFAULT 0,
  favorite_game VARCHAR(24) NOT NULL DEFAULT 'ludo',
  last_submit BIGINT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sessions (
  token_hash CHAR(64) PRIMARY KEY,
  user_id INT NOT NULL,
  expires_at BIGINT NOT NULL,
  INDEX idx_sess_user (user_id),
  INDEX idx_sess_exp (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_fails (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(32) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  ts BIGINT NOT NULL,
  INDEX idx_lf_user (username, ts),
  INDEX idx_lf_ip (ip, ts)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS api_nonces (
  nonce VARCHAR(64) PRIMARY KEY,
  ts BIGINT NOT NULL,
  INDEX idx_nonce_ts (ts)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chat_groups (
  id VARCHAR(40) PRIMARY KEY,
  name TEXT NOT NULL,
  invite_code VARCHAR(16) NOT NULL UNIQUE,
  owner_username VARCHAR(32) NOT NULL,
  last_message TEXT NOT NULL,
  last_time BIGINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chat_members (
  group_id VARCHAR(40) NOT NULL,
  username VARCHAR(32) NOT NULL,
  joined_at BIGINT NOT NULL DEFAULT 0,
  PRIMARY KEY (group_id, username),
  INDEX idx_member_user (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chat_messages (
  id VARCHAR(48) PRIMARY KEY,
  group_id VARCHAR(40) NOT NULL,
  sender_username VARCHAR(32) NOT NULL,
  sender_color INT NOT NULL DEFAULT 0,
  text MEDIUMTEXT NOT NULL,
  image_data MEDIUMTEXT DEFAULT NULL,
  timestamp BIGINT NOT NULL,
  INDEX idx_group_time (group_id, timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chat_reads (
  group_id VARCHAR(40) NOT NULL,
  username VARCHAR(32) NOT NULL,
  last_ts BIGINT NOT NULL DEFAULT 0,
  PRIMARY KEY (group_id, username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chat_join_requests (
  group_id VARCHAR(40) NOT NULL,
  username VARCHAR(32) NOT NULL,
  requested_at BIGINT NOT NULL DEFAULT 0,
  PRIMARY KEY (group_id, username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS game_rooms (
  room_code VARCHAR(16) PRIMARY KEY,
  game_type VARCHAR(24) NOT NULL,
  host_username VARCHAR(32) NOT NULL,
  players_json TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'waiting',
  version INT NOT NULL DEFAULT 1,
  state_json MEDIUMTEXT NOT NULL,
  updated_at BIGINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
""".trimStart()

  fun generateApiPhp(config: CPanelConfig): String {
    val hmacFlag = if (config.hmacEnabled) "true" else "false"
    val encFlag = if (config.e2eeEnabled) "true" else "false"
    val maintFlag = if (config.maintenanceMode) "true" else "false"

    return API_TEMPLATE
      .replace('§', '$')
      .replace("__DB_HOST__", config.dbHost.ifBlank { "localhost" }.escapePhp())
      .replace("__DB_NAME__", config.dbName.ifBlank { "cpaneluser_bazirox" }.escapePhp())
      .replace("__DB_USER__", config.dbUser.ifBlank { "cpaneluser_dbuser" }.escapePhp())
      .replace("__DB_PASS__", config.dbPassword.escapePhp())
      .replace("__API_SECRET__", config.apiSecret.ifBlank { "CHANGE_ME_SECRET" }.escapePhp())
      .replace("__HMAC__", hmacFlag)
      .replace("__ENC__", encFlag)
      .replace("__MAINT__", maintFlag)
  }

  private fun String.escapePhp(): String = replace("\\", "\\\\").replace("'", "\\'")

  private val API_TEMPLATE =
    """<?php
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');
define('DB_HOST', '__DB_HOST__');
define('DB_NAME', '__DB_NAME__');
define('DB_USER', '__DB_USER__');
define('DB_PASS', '__DB_PASS__');
define('API_SECRET', '__API_SECRET__');
define('ENABLE_HMAC', __HMAC__);
define('ENABLE_TRANSPORT_ENC', __ENC__);
define('MAINTENANCE_MODE', __MAINT__);
define('SESSION_TTL', 2592000);
define('MAX_BODY', 12000000);
function aesKey(): string {
return hash('sha256', 'BaziLand_AES256_Key:' . API_SECRET, true);
}
function decryptPayload(string §_2): ?string {
§_2d = base64_decode(§_2, true);
if (§_2d === false || strlen(§_2d) <= 28) return null;
§_19 = substr(§_2d, 0, 12);
§_3c = substr(§_2d, 12, 16);
§_5 = substr(§_2d, 28);
§_29 = openssl_decrypt(§_5, 'aes-256-gcm', aesKey(), OPENSSL_RAW_DATA, §_19, §_3c);
return §_29 === false ? null : §_29;
}
function encryptPayload(string §_29): string {
§_19 = random_bytes(12);
§_3c = '';
§_5 = openssl_encrypt(§_29, 'aes-256-gcm', aesKey(), OPENSSL_RAW_DATA, §_19, §_3c, '', 16);
return base64_encode(§_19 . §_3c . §_5);
}
function sendJson(array §_26, int §_7 = 200): void {
http_response_code(§_7);
§_1a = json_encode(§_26, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
if (ENABLE_TRANSPORT_ENC) {
echo json_encode(['enc' => encryptPayload(§_1a)]);
} else {
echo §_1a;
}
exit;
}
function fail(string §_20, int §_7 = 400): void {
sendJson(['ok' => false, 'error' => §_20], §_7);
}
function nowMs(): int {
return (int) round(microtime(true) * 1000);
}
function str(§_48, int §_1c): string {
if (!is_string(§_48)) return '';
return mb_substr(trim(§_48), 0, §_1c);
}
function passwordAlgo() {
return defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
}
if (MAINTENANCE_MODE && (§_GET['action'] ?? '') !== 'ping') {
fail('سرور در حال بروزرسانی است', 503);
}
§_2e = file_get_contents('php://input');
if (§_2e === false) §_2e = '';
if (strlen(§_2e) > MAX_BODY) fail('Payload too large', 413);
§_1 = (string)(§_GET['action'] ?? '');
§_40 = (int)(§_SERVER['HTTP_X_BAZILAND_TIMESTAMP'] ?? 0);
§_22 = (string)(§_SERVER['HTTP_X_BAZILAND_NONCE'] ?? '');
§_35 = (string)(§_SERVER['HTTP_X_BAZILAND_SIGNATURE'] ?? '');
if (ENABLE_HMAC) {
if (abs(time() - §_40) > 120 || §_22 === '' || strlen(§_22) > 64 || §_35 === '') {
fail('Invalid security timestamp/nonce', 401);
}
§_f = hash_hmac('sha256', §_1 . '|' . §_40 . '|' . §_22 . '|' . §_2e, API_SECRET);
if (!hash_equals(§_f, §_35)) fail('Invalid HMAC signature', 403);
}
§_30 = json_decode(§_2e, true);
if (!is_array(§_30)) §_30 = [];
if (isset(§_30['enc'])) {
if (!ENABLE_TRANSPORT_ENC) fail('Encryption is disabled on this server', 400);
§_a = is_string(§_30['enc']) ? decryptPayload(§_30['enc']) : null;
if (§_a === null) fail('Decrypt failed', 400);
§_30 = json_decode(§_a, true);
if (!is_array(§_30)) §_30 = [];
} elseif (ENABLE_TRANSPORT_ENC) {
fail('Encrypted request required', 400);
}
§_9 = (isset(§_30['data']) && is_array(§_30['data'])) ? §_30['data'] : [];
if (§_1 === 'room_peek') {
§_p2 = @file_get_contents(roomTokPath(cleanRoomCode(§_9['room_code'] ?? '')));
sendJson(['ok' => true, 'tok' => §_p2 === false ? '' : §_p2]);
}
try {
§_27 = new PDO(
'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
DB_USER,
DB_PASS,
[PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
);
} catch (Throwable §_d) {
sendJson(['ok' => false, 'db_ok' => false, 'error' => 'خطا در اتصال به MySQL'], 500);
}
if (ENABLE_HMAC) {
try {
§_27->prepare('INSERT INTO api_nonces (nonce, ts) VALUES (?, ?)')->execute([§_22, time()]);
} catch (PDOException §_d) {
if ((int)(§_d->errorInfo[1] ?? 0) === 1062) fail('Replay detected', 409);
sendJson(['ok' => false, 'db_ok' => false, 'error' => 'جدول‌های دیتابیس نصب نشده‌اند (schema.sql را اجرا کن)'], 500);
}
if (random_int(1, 50) === 1) {
try { §_27->prepare('DELETE FROM api_nonces WHERE ts < ?')->execute([time() - 600]); } catch (Throwable §_d) {}
}
}
function requireUser(PDO §_27, array §_30): array {
§_3e = §_30['token'] ?? '';
if (!is_string(§_3e) || strlen(§_3e) < 32 || strlen(§_3e) > 128) {
fail('نشست نامعتبر است، دوباره وارد شوید', 401);
}
§_37 = §_27->prepare('SELECT u.id, u.username, u.display_name, u.avatar_color FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?');
§_37->execute([hash('sha256', §_3e), time()]);
§_43 = §_37->fetch();
if (!§_43) fail('نشست نامعتبر است، دوباره وارد شوید', 401);
return §_43;
}
function issueSession(PDO §_27, int §_46): string {
§_3e = bin2hex(random_bytes(32));
§_27->prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)')
->execute([hash('sha256', §_3e), §_46, time() + SESSION_TTL]);
if (random_int(1, 20) === 1) {
try { §_27->prepare('DELETE FROM sessions WHERE expires_at < ?')->execute([time()]); } catch (Throwable §_d) {}
}
return §_3e;
}
function userOut(array §_43): array {
return [
'username' => §_43['username'],
'display_name' => §_43['display_name'],
'avatar_color' => (int)(§_43['avatar_color'] ?? 0),
'total_score' => (int)(§_43['total_score'] ?? 0),
'wins' => (int)(§_43['wins'] ?? 0),
'games_played' => (int)(§_43['games_played'] ?? 0),
];
}
function isMember(PDO §_27, string §_12, string §_47): bool {
§_37 = §_27->prepare('SELECT 1 FROM chat_members WHERE group_id = ? AND username = ?');
§_37->execute([§_12, §_47]);
return (bool)§_37->fetchColumn();
}
function groupOut(PDO §_27, array §_11): array {
§_37 = §_27->prepare('SELECT username FROM chat_members WHERE group_id = ? ORDER BY joined_at');
§_37->execute([§_11['id']]);
return [
'id' => §_11['id'],
'name' => §_11['name'],
'invite_code' => §_11['invite_code'],
'owner_username' => §_11['owner_username'],
'members' => §_37->fetchAll(PDO::FETCH_COLUMN),
'last_message' => §_11['last_message'],
'last_time' => (int)§_11['last_time'],
];
}
function deleteGroupData(PDO §_27, string §_12): void {
foreach (['chat_messages', 'chat_reads', 'chat_members'] as §_g0) {
§_27->prepare('DELETE FROM ' . §_g0 . ' WHERE group_id = ?')->execute([§_12]);
}
try { §_27->prepare('DELETE FROM chat_join_requests WHERE group_id = ?')->execute([§_12]); } catch (Throwable §_d) {}
§_27->prepare('DELETE FROM chat_groups WHERE id = ?')->execute([§_12]);
}
function ensureJoinRequestsTable(PDO §_27): void {
§_27->exec("CREATE TABLE IF NOT EXISTS chat_join_requests (group_id VARCHAR(40) NOT NULL, username VARCHAR(32) NOT NULL, requested_at BIGINT NOT NULL DEFAULT 0, PRIMARY KEY (group_id, username)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}
function roomOut(array §_2c): array {
§_2a = json_decode(§_2c['players_json'], true);
return [
'room_code' => §_2c['room_code'],
'game_type' => §_2c['game_type'],
'host_username' => §_2c['host_username'],
'players' => is_array(§_2a) ? §_2a : [],
'status' => §_2c['status'],
'version' => (int)§_2c['version'],
'state_json' => §_2c['state_json'],
];
}
function roomTokPath(string §_7): string {
return rtrim(sys_get_temp_dir(), '/') . '/bzr_' . md5(API_SECRET . '|' . §_7);
}
function roomTokTouch(string §_7): void {
@file_put_contents(roomTokPath(§_7), microtime(true) . '|' . mt_rand(), LOCK_EX);
if (mt_rand(1, 300) === 1) {
foreach ((array)@glob(rtrim(sys_get_temp_dir(), '/') . '/bzr_*') as §_p1) {
if (@filemtime(§_p1) < time() - 86400) @unlink(§_p1);
}
}
}
function cleanRoomCode(§_48): string {
§_7 = strtoupper(str(§_48, 16));
if (!preg_match('/^[A-Z0-9]{6,16}§/', §_7)) fail('کد اتاق نامعتبر است', 400);
return §_7;
}
§_0 = ['ludo', 'tictactoe', 'connect4', 'snakes'];
switch (§_1) {
case 'ping':
sendJson(['ok' => true, 'db_ok' => true, 'message' => 'هاست ایران متصل و امن است', 'server_time' => date('c')]);
case 'register':
§_43 = str(§_9['username'] ?? '', 32);
§_28 = §_9['password_hash'] ?? '';
§_b = str(§_9['display_name'] ?? '', 64);
if (§_b === '') §_b = §_43;
§_8 = max(0, min(31, (int)(§_9['avatar_color'] ?? 0)));
if (!preg_match('/^[\p{L}\p{N}_.-]{3,32}§/u', §_43)) fail('نام کاربری باید ۳ تا ۳۲ حرف یا عدد باشد', 400);
if (!is_string(§_28) || !preg_match('/^[0-9a-f]{64}§/', §_28)) fail('ورودی نامعتبر', 400);
§_37 = §_27->prepare('SELECT id FROM users WHERE username = ?');
§_37->execute([§_43]);
if (§_37->fetch()) fail('نام کاربری تکراری است', 409);
§_14 = password_hash(§_28, passwordAlgo());
try {
§_27->prepare('INSERT INTO users (username, display_name, password_hash, avatar_color) VALUES (?, ?, ?, ?)')
->execute([§_43, §_b, §_14, §_8]);
} catch (PDOException §_d) {
fail('نام کاربری تکراری است', 409);
}
§_44 = (int)§_27->lastInsertId();
§_3e = issueSession(§_27, §_44);
sendJson(['ok' => true, 'token' => §_3e, 'user' => userOut(['username' => §_43, 'display_name' => §_b, 'avatar_color' => §_8])]);
case 'login':
§_43 = str(§_9['username'] ?? '', 32);
§_28 = §_9['password_hash'] ?? '';
§_18 = substr((string)(§_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
§_36 = time() - 900;
§_3 = §_27->prepare('SELECT COUNT(*) FROM login_fails WHERE username = ? AND ts > ?');
§_3->execute([§_43, §_36]);
§_4 = §_27->prepare('SELECT COUNT(*) FROM login_fails WHERE ip = ? AND ts > ?');
§_4->execute([§_18, §_36]);
if ((int)§_3->fetchColumn() >= 8 || (int)§_4->fetchColumn() >= 60) {
fail('تلاش‌های ناموفق زیاد است؛ چند دقیقه بعد دوباره امتحان کن', 429);
}
§_37 = §_27->prepare('SELECT id, username, display_name, avatar_color, total_score, wins, games_played, password_hash FROM users WHERE username = ?');
§_37->execute([§_43]);
§_31 = §_37->fetch();
§_49 = is_string(§_28) && preg_match('/^[0-9a-f]{64}§/', §_28);
if (§_31 && §_49 && password_verify(§_28, §_31['password_hash'])) {
try { §_27->prepare('DELETE FROM login_fails WHERE username = ?')->execute([§_43]); } catch (Throwable §_d) {}
§_3e = issueSession(§_27, (int)§_31['id']);
sendJson(['ok' => true, 'token' => §_3e, 'user' => userOut(§_31)]);
}
if (!§_31) password_hash(is_string(§_28) ? §_28 : '', passwordAlgo());
try {
§_27->prepare('INSERT INTO login_fails (username, ip, ts) VALUES (?, ?, ?)')->execute([§_43, §_18, time()]);
if (random_int(1, 20) === 1) §_27->prepare('DELETE FROM login_fails WHERE ts < ?')->execute([time() - 86400]);
} catch (Throwable §_d) {}
fail('نام کاربری یا رمز عبور اشتباه است', 401);
case 'admin_gate':
§_28 = §_9['password_hash'] ?? '';
if (!is_string(§_28) || !preg_match('/^[0-9a-f]{64}§/', §_28)) fail('ورودی نامعتبر', 400);
§_27->exec("CREATE TABLE IF NOT EXISTS admin_gate (id TINYINT NOT NULL PRIMARY KEY, password_hash VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
§_18 = substr((string)(§_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
§_36 = time() - 900;
§_3 = §_27->prepare('SELECT COUNT(*) FROM login_fails WHERE username = ? AND ts > ?');
§_3->execute(['__admin_gate__', §_36]);
if ((int)§_3->fetchColumn() >= 5) fail('تلاش‌های ناموفق زیاد است؛ چند دقیقه بعد دوباره امتحان کن', 429);
§_37 = §_27->prepare('SELECT password_hash FROM admin_gate WHERE id = 1');
§_37->execute();
§_31 = §_37->fetch();
if (!§_31) {
try {
§_27->prepare('INSERT INTO admin_gate (id, password_hash) VALUES (1, ?)')->execute([password_hash(§_28, passwordAlgo())]);
} catch (PDOException §_d) {
fail('تلاش مجدد', 409);
}
sendJson(['ok' => true, 'created' => true]);
}
if (password_verify(§_28, §_31['password_hash'])) {
try { §_27->prepare('DELETE FROM login_fails WHERE username = ?')->execute(['__admin_gate__']); } catch (Throwable §_d) {}
sendJson(['ok' => true, 'created' => false]);
}
try {
§_27->prepare('INSERT INTO login_fails (username, ip, ts) VALUES (?, ?, ?)')->execute(['__admin_gate__', §_18, time()]);
} catch (Throwable §_d) {}
fail('نام کاربری یا رمز عبور اشتباه است', 401);
case 'submit_score':
§_1f = requireUser(§_27, §_30);
§_c = max(-100, min(300, (int)(§_9['delta_score'] ?? 0)));
§_4b = !empty(§_9['did_win']) ? 1 : 0;
§_13 = (string)(§_9['game_type'] ?? 'ludo');
if (!in_array(§_13, §_0, true)) §_13 = 'ludo';
§_23 = time();
§_45 = §_27->prepare('UPDATE users SET total_score = GREATEST(0, total_score + ?), wins = wins + ?, games_played = games_played + 1, favorite_game = ?, last_submit = ? WHERE id = ? AND last_submit < ?');
§_45->execute([§_c, §_4b, §_13, §_23, §_1f['id'], §_23 - 5]);
sendJson(['ok' => true]);
case 'leaderboard':
requireUser(§_27, §_30);
§_32 = §_27->query('SELECT username, display_name, avatar_color, total_score, wins, games_played, favorite_game FROM users ORDER BY total_score DESC, wins DESC LIMIT 50')->fetchAll();
sendJson(['ok' => true, 'entries' => §_32]);
case 'group_create':
§_1f = requireUser(§_27, §_30);
§_21 = §_9['name'] ?? '';
if (!is_string(§_21) || §_21 === '' || strlen(§_21) > 600) fail('نام گروه نامعتبر است', 400);
§_6 = §_27->prepare('SELECT COUNT(*) FROM chat_groups WHERE owner_username = ?');
§_6->execute([§_1f['username']]);
if ((int)§_6->fetchColumn() >= 30) fail('تعداد گروه‌های ساخته‌شده به سقف رسیده است', 429);
§_12 = 'grp_' . bin2hex(random_bytes(6));
§_7 = strtoupper(bin2hex(random_bytes(5)));
§_3b = nowMs();
§_27->prepare('INSERT INTO chat_groups (id, name, invite_code, owner_username, last_message, last_time) VALUES (?, ?, ?, ?, ?, ?)')
->execute([§_12, §_21, §_7, §_1f['username'], '', §_3b]);
§_27->prepare('INSERT INTO chat_members (group_id, username, joined_at) VALUES (?, ?, ?)')
->execute([§_12, §_1f['username'], §_3b]);
§_11 = §_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
§_11->execute([§_12]);
sendJson(['ok' => true, 'group' => groupOut(§_27, §_11->fetch())]);
case 'group_join':
§_1f = requireUser(§_27, §_30);
§_7 = strtoupper(str(§_9['invite_code'] ?? '', 16));
if (!preg_match('/^[0-9A-F]{6,16}§/', §_7)) fail('کد دعوت معتبر نیست', 404);
§_37 = §_27->prepare('SELECT * FROM chat_groups WHERE invite_code = ?');
§_37->execute([§_7]);
§_11 = §_37->fetch();
if (!§_11) fail('کد دعوت معتبر نیست', 404);
if (isMember(§_27, §_11['id'], §_1f['username'])) {
sendJson(['ok' => true, 'group' => groupOut(§_27, §_11)]);
}
ensureJoinRequestsTable(§_27);
§_1e = §_27->prepare('SELECT COUNT(*) FROM chat_join_requests WHERE group_id = ?');
§_1e->execute([§_11['id']]);
if ((int)§_1e->fetchColumn() >= 50) fail('تعداد درخواست‌های در انتظار این گروه پر شده است', 429);
§_27->prepare('INSERT IGNORE INTO chat_join_requests (group_id, username, requested_at) VALUES (?, ?, ?)')
->execute([§_11['id'], §_1f['username'], nowMs()]);
sendJson(['ok' => true, 'pending' => true, 'group' => ['id' => §_11['id'], 'name' => §_11['name']]]);
case 'group_requests':
§_1f = requireUser(§_27, §_30);
§_12 = str(§_9['group_id'] ?? '', 40);
§_37 = §_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
§_37->execute([§_12]);
§_11 = §_37->fetch();
if (!§_11) fail('گروه یافت نشد', 404);
if (§_11['owner_username'] !== §_1f['username']) fail('فقط سازنده‌ی گروه می‌تواند درخواست‌ها را ببیند', 403);
ensureJoinRequestsTable(§_27);
§_37 = §_27->prepare('SELECT username, requested_at FROM chat_join_requests WHERE group_id = ? ORDER BY requested_at ASC LIMIT 100');
§_37->execute([§_12]);
§_24 = [];
foreach (§_37->fetchAll() as §_m6) { §_24[] = ['username' => §_m6['username'], 'requested_at' => (int)§_m6['requested_at']]; }
sendJson(['ok' => true, 'requests' => §_24]);
case 'group_request_resolve':
§_1f = requireUser(§_27, §_30);
§_12 = str(§_9['group_id'] ?? '', 40);
§_3d = str(§_9['username'] ?? '', 32);
§_m7 = !empty(§_9['approve']);
§_37 = §_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
§_37->execute([§_12]);
§_11 = §_37->fetch();
if (!§_11) fail('گروه یافت نشد', 404);
if (§_11['owner_username'] !== §_1f['username']) fail('فقط سازنده‌ی گروه می‌تواند درخواست‌ها را بررسی کند', 403);
ensureJoinRequestsTable(§_27);
§_m8 = §_27->prepare('SELECT 1 FROM chat_join_requests WHERE group_id = ? AND username = ?');
§_m8->execute([§_12, §_3d]);
if (!§_m8->fetchColumn()) fail('درخواست یافت نشد', 404);
if (§_m7) {
§_1e = §_27->prepare('SELECT COUNT(*) FROM chat_members WHERE group_id = ?');
§_1e->execute([§_12]);
if ((int)§_1e->fetchColumn() >= 100) fail('ظرفیت گروه تکمیل است', 409);
§_27->prepare('INSERT IGNORE INTO chat_members (group_id, username, joined_at) VALUES (?, ?, ?)')
->execute([§_12, §_3d, nowMs()]);
}
§_27->prepare('DELETE FROM chat_join_requests WHERE group_id = ? AND username = ?')->execute([§_12, §_3d]);
sendJson(['ok' => true, 'group' => groupOut(§_27, §_11)]);
case 'group_invite':
§_1f = requireUser(§_27, §_30);
§_12 = str(§_9['group_id'] ?? '', 40);
§_3d = str(§_9['target_username'] ?? '', 32);
§_37 = §_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
§_37->execute([§_12]);
§_11 = §_37->fetch();
if (!§_11) fail('گروه یافت نشد', 404);
if (§_11['owner_username'] !== §_1f['username']) fail('فقط سازنده‌ی گروه می‌تواند عضو اضافه کند', 403);
§_41 = §_27->prepare('SELECT username FROM users WHERE username = ?');
§_41->execute([§_3d]);
§_3f = §_41->fetch();
if (!§_3f) fail('کاربری با این نام پیدا نشد', 404);
§_27->prepare('INSERT IGNORE INTO chat_members (group_id, username, joined_at) VALUES (?, ?, ?)')
->execute([§_12, §_3f['username'], nowMs()]);
sendJson(['ok' => true, 'group' => groupOut(§_27, §_11)]);
case 'group_leave':
§_1f = requireUser(§_27, §_30);
§_12 = str(§_9['group_id'] ?? '', 40);
§_37 = §_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
§_37->execute([§_12]);
§_11 = §_37->fetch();
if (!§_11) fail('گروه یافت نشد', 404);
if (!isMember(§_27, §_12, §_1f['username'])) fail('شما عضو این گروه نیستید', 403);
§_27->beginTransaction();
§_27->prepare('DELETE FROM chat_members WHERE group_id = ? AND username = ?')->execute([§_12, §_1f['username']]);
§_27->prepare('DELETE FROM chat_reads WHERE group_id = ? AND username = ?')->execute([§_12, §_1f['username']]);
§_g1 = §_27->prepare('SELECT username FROM chat_members WHERE group_id = ? ORDER BY joined_at ASC LIMIT 1');
§_g1->execute([§_12]);
§_g2 = §_g1->fetchColumn();
if (§_g2 === false) {
deleteGroupData(§_27, §_12);
} elseif (§_11['owner_username'] === §_1f['username']) {
§_27->prepare('UPDATE chat_groups SET owner_username = ? WHERE id = ?')->execute([§_g2, §_12]);
}
§_27->commit();
sendJson(['ok' => true]);
case 'group_delete':
§_1f = requireUser(§_27, §_30);
§_12 = str(§_9['group_id'] ?? '', 40);
§_37 = §_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
§_37->execute([§_12]);
§_11 = §_37->fetch();
if (!§_11) fail('گروه یافت نشد', 404);
if (§_11['owner_username'] !== §_1f['username']) fail('فقط سازنده‌ی گروه می‌تواند آن را حذف کند', 403);
§_27->beginTransaction();
deleteGroupData(§_27, §_12);
§_27->commit();
sendJson(['ok' => true]);
case 'groups_list':
§_1f = requireUser(§_27, §_30);
§_37 = §_27->prepare('SELECT g.* FROM chat_groups g JOIN chat_members m ON m.group_id = g.id WHERE m.username = ? ORDER BY g.last_time DESC LIMIT 100');
§_37->execute([§_1f['username']]);
§_24 = [];
foreach (§_37->fetchAll() as §_11) {
§_m9 = groupOut(§_27, §_11);
if (§_11['owner_username'] === §_1f['username']) {
try {
§_m8 = §_27->prepare('SELECT COUNT(*) FROM chat_join_requests WHERE group_id = ?');
§_m8->execute([§_11['id']]);
§_m9['pending_count'] = (int)§_m8->fetchColumn();
} catch (Throwable §_d) { §_m9['pending_count'] = 0; }
}
§_24[] = §_m9;
}
sendJson(['ok' => true, 'groups' => §_24]);
case 'message_send':
§_1f = requireUser(§_27, §_30);
§_12 = str(§_9['group_id'] ?? '', 40);
if (!isMember(§_27, §_12, §_1f['username'])) fail('شما عضو این گروه نیستید', 403);
§_15 = §_9['id'] ?? '';
if (!is_string(§_15) || !preg_match('/^[A-Za-z0-9_-]{4,48}§/', §_15)) fail('شناسه پیام نامعتبر است', 400);
§_42 = §_9['text'] ?? '';
if (!is_string(§_42) || §_42 === '' || strlen(§_42) > 40000) fail('پیام نامعتبر است', 400);
if (strncmp(§_42, 'e1:', 3) !== 0) fail('فقط پیام رمزنگاری‌شده پذیرفته می‌شود', 400);
§_16 = §_9['image_data'] ?? null;
if (§_16 === null || §_16 === '') {
§_16 = null;
} elseif (!is_string(§_16) || strlen(§_16) > 6000000 || strncmp(§_16, 'e1:', 3) !== 0) {
fail('تصویر نامعتبر یا حجم آن زیاد است', 413);
}
§_2b = §_9['preview'] ?? '';
if (!is_string(§_2b) || strlen(§_2b) > 600 || (§_2b !== '' && strncmp(§_2b, 'e1:', 3) !== 0)) §_2b = '';
§_3b = nowMs();
§_17 = §_27->prepare('INSERT IGNORE INTO chat_messages (id, group_id, sender_username, sender_color, text, image_data, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)');
§_17->execute([§_15, §_12, §_1f['username'], (int)§_1f['avatar_color'], §_42, §_16, §_3b]);
if (§_17->rowCount() === 0) {
§_e = §_27->prepare('SELECT group_id, sender_username FROM chat_messages WHERE id = ?');
§_e->execute([§_15]);
§_10 = §_e->fetch();
if (!§_10 || §_10['group_id'] !== §_12 || §_10['sender_username'] !== §_1f['username']) fail('شناسه پیام تکراری است', 409);
sendJson(['ok' => true]);
}
§_27->prepare('UPDATE chat_groups SET last_message = ?, last_time = ? WHERE id = ?')->execute([§_2b, §_3b, §_12]);
sendJson(['ok' => true]);
case 'message_delete':
§_1f = requireUser(§_27, §_30);
§_m1 = str(§_9['id'] ?? '', 48);
§_m2 = §_27->prepare('SELECT id, group_id, sender_username, timestamp FROM chat_messages WHERE id = ?');
§_m2->execute([§_m1]);
§_m3 = §_m2->fetch();
if (!§_m3) sendJson(['ok' => true]);
if (!isMember(§_27, §_m3['group_id'], §_1f['username'])) fail('دسترسی غیرمجاز', 403);
§_m4 = §_27->prepare('SELECT owner_username FROM chat_groups WHERE id = ?');
§_m4->execute([§_m3['group_id']]);
§_m5 = §_m4->fetchColumn();
if (§_m3['sender_username'] !== §_1f['username'] && §_m5 !== §_1f['username']) fail('فقط فرستنده‌ی پیام یا سازنده‌ی گروه می‌تواند آن را حذف کند', 403);
§_27->prepare('DELETE FROM chat_messages WHERE id = ?')->execute([§_m1]);
§_27->prepare('UPDATE chat_groups SET last_message = ? WHERE id = ? AND last_time = ?')->execute(['', §_m3['group_id'], (int)§_m3['timestamp']]);
sendJson(['ok' => true]);
case 'messages_list':
§_1f = requireUser(§_27, §_30);
§_12 = str(§_9['group_id'] ?? '', 40);
if (!isMember(§_27, §_12, §_1f['username'])) fail('شما عضو این گروه نیستید', 403);
§_37 = §_27->prepare('SELECT * FROM (SELECT id, group_id, sender_username, sender_color, text, timestamp, (image_data IS NOT NULL AND image_data <> \'\') AS has_image FROM chat_messages WHERE group_id = ? ORDER BY timestamp DESC LIMIT 120) t ORDER BY timestamp ASC');
§_37->execute([§_12]);
§_32 = §_37->fetchAll();
§_1d = 0;
foreach (§_32 as §_1b => §_2c) {
§_32[§_1b]['sender_color'] = (int)§_2c['sender_color'];
§_32[§_1b]['timestamp'] = (int)§_2c['timestamp'];
§_32[§_1b]['has_image'] = (int)§_2c['has_image'] === 1;
if ((int)§_2c['timestamp'] > §_1d) §_1d = (int)§_2c['timestamp'];
}
if (§_1d > 0) {
§_27->prepare('INSERT INTO chat_reads (group_id, username, last_ts) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE last_ts = GREATEST(last_ts, VALUES(last_ts))')
->execute([§_12, §_1f['username'], §_1d]);
}
§_34 = §_27->prepare('SELECT username, last_ts FROM chat_reads WHERE group_id = ?');
§_34->execute([§_12]);
§_2f = new stdClass();
foreach (§_34->fetchAll() as §_33) { §_2f->{§_33['username']} = (int)§_33['last_ts']; }
sendJson(['ok' => true, 'messages' => §_32, 'reads' => §_2f]);
case 'message_image':
§_1f = requireUser(§_27, §_30);
§_37 = §_27->prepare('SELECT group_id, image_data FROM chat_messages WHERE id = ?');
§_37->execute([str(§_9['id'] ?? '', 48)]);
§_31 = §_37->fetch();
if (!§_31) sendJson(['ok' => true, 'image' => '']);
if (!isMember(§_27, §_31['group_id'], §_1f['username'])) fail('دسترسی غیرمجاز', 403);
sendJson(['ok' => true, 'image' => §_31['image_data'] ?? '']);
case 'room_create':
§_1f = requireUser(§_27, §_30);
§_7 = cleanRoomCode(§_9['room_code'] ?? '');
§_13 = (string)(§_9['game_type'] ?? 'ludo');
if (!in_array(§_13, §_0, true)) §_13 = 'ludo';
try {
§_27->prepare('INSERT INTO game_rooms (room_code, game_type, host_username, players_json, status, version, state_json, updated_at) VALUES (?, ?, ?, ?, ?, 1, ?, ?)')
->execute([§_7, §_13, §_1f['username'], json_encode([§_1f['username']], JSON_UNESCAPED_UNICODE), 'waiting', '{}', time()]);
} catch (PDOException §_d) {
fail('کد اتاق تکراری است، دوباره تلاش کن', 409);
}
if (random_int(1, 20) === 1) {
try { §_27->prepare('DELETE FROM game_rooms WHERE updated_at < ?')->execute([time() - 86400]); } catch (Throwable §_d) {}
}
roomTokTouch(§_7);
§_37 = §_27->prepare('SELECT * FROM game_rooms WHERE room_code = ?');
§_37->execute([§_7]);
sendJson(['ok' => true, 'room' => roomOut(§_37->fetch())]);
case 'room_join':
§_1f = requireUser(§_27, §_30);
§_7 = cleanRoomCode(§_9['room_code'] ?? '');
§_27->beginTransaction();
§_37 = §_27->prepare('SELECT * FROM game_rooms WHERE room_code = ? FOR UPDATE');
§_37->execute([§_7]);
§_2c = §_37->fetch();
if (!§_2c) { §_27->rollBack(); fail('اتاق پیدا نشد', 404); }
§_25 = json_decode(§_2c['players_json'], true);
if (!is_array(§_25)) §_25 = [];
if (!in_array(§_1f['username'], §_25, true)) {
if (count(§_25) >= 4) { §_27->rollBack(); fail('اتاق پر است', 409); }
§_25[] = §_1f['username'];
}
§_3a = (count(§_25) >= 2 && §_2c['status'] === 'waiting') ? 'playing' : §_2c['status'];
§_4a = (int)§_2c['version'] + 1;
§_27->prepare('UPDATE game_rooms SET players_json = ?, status = ?, version = ?, updated_at = ? WHERE room_code = ?')
->execute([json_encode(§_25, JSON_UNESCAPED_UNICODE), §_3a, §_4a, time(), §_7]);
§_27->commit();
roomTokTouch(§_7);
§_38 = §_27->prepare('SELECT * FROM game_rooms WHERE room_code = ?');
§_38->execute([§_7]);
sendJson(['ok' => true, 'room' => roomOut(§_38->fetch())]);
case 'room_sync':
§_1f = requireUser(§_27, §_30);
§_7 = cleanRoomCode(§_9['room_code'] ?? '');
§_37 = §_27->prepare('SELECT * FROM game_rooms WHERE room_code = ?');
§_37->execute([§_7]);
§_2c = §_37->fetch();
if (!§_2c) fail('اتاق پیدا نشد', 404);
§_24 = roomOut(§_2c);
if (!in_array(§_1f['username'], §_24['players'], true)) fail('شما عضو این اتاق نیستید', 403);
sendJson(['ok' => true, 'room' => §_24]);
case 'room_move':
§_1f = requireUser(§_27, §_30);
§_7 = cleanRoomCode(§_9['room_code'] ?? '');
§_39 = §_9['state_json'] ?? '{}';
if (!is_string(§_39) || strlen(§_39) > 300000) fail('وضعیت بازی نامعتبر است', 400);
§_3a = (string)(§_9['status'] ?? 'playing');
if (!in_array(§_3a, ['waiting', 'playing', 'finished'], true)) §_3a = 'playing';
§_37 = §_27->prepare('SELECT * FROM game_rooms WHERE room_code = ?');
§_37->execute([§_7]);
§_2c = §_37->fetch();
if (!§_2c) fail('اتاق پیدا نشد', 404);
if (!in_array(§_1f['username'], roomOut(§_2c)['players'], true)) fail('شما عضو این اتاق نیستید', 403);
§_4a = max((int)§_2c['version'], (int)(§_9['version'] ?? 1));
§_27->prepare('UPDATE game_rooms SET state_json = ?, status = ?, version = ?, updated_at = ? WHERE room_code = ?')
->execute([§_39, §_3a, §_4a, time(), §_7]);
roomTokTouch(§_7);
§_37->execute([§_7]);
sendJson(['ok' => true, 'room' => roomOut(§_37->fetch())]);
default:
fail('Unknown action', 400);
}"""
}
