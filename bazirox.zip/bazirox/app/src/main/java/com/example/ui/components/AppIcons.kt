package com.example.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Bazirox Duotone Gaming Icon Pack.
 * Combines soft duotone fills (alpha 0.22) with crisp 1.75dp rounded strokes
 * so every icon adapts cleanly to any Compose Icon tint while looking modern and unique.
 */
object BaziIcons {
  private val ink = SolidColor(Color.Black)

  private fun vec(name: String, block: ImageVector.Builder.() -> Unit): ImageVector =
    ImageVector.Builder(
        name = name,
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f,
      )
      .apply(block)
      .build()

  val SportsEsports: ImageVector by lazy {
    vec("SportsEsports") {
      path(
        fill = ink,
        fillAlpha = 0.22f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(6.8f, 6.5f)
        horizontalLineTo(17.2f)
        curveTo(19.3f, 6.5f, 20.9f, 8.0f, 21.2f, 10.1f)
        lineTo(21.9f, 15.6f)
        curveTo(22.15f, 17.4f, 20.75f, 19.0f, 18.9f, 19.0f)
        curveTo(17.85f, 19.0f, 16.9f, 18.45f, 16.35f, 17.55f)
        lineTo(15.2f, 15.6f)
        horizontalLineTo(8.8f)
        lineTo(7.65f, 17.55f)
        curveTo(7.1f, 18.45f, 6.15f, 19.0f, 5.1f, 19.0f)
        curveTo(3.25f, 19.0f, 1.85f, 17.4f, 2.1f, 15.6f)
        lineTo(2.8f, 10.1f)
        curveTo(3.1f, 8.0f, 4.7f, 6.5f, 6.8f, 6.5f)
        close()
      }
      // D-pad
      path(
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
      ) {
        moveTo(8f, 9.5f)
        verticalLineTo(13.1f)
        moveTo(6.2f, 11.3f)
        horizontalLineTo(9.8f)
      }
      // Action buttons
      path(fill = ink) {
        moveTo(15.6f, 10.2f)
        arcTo(1.05f, 1.05f, 0f, true, true, 13.5f, 10.2f)
        arcTo(1.05f, 1.05f, 0f, true, true, 15.6f, 10.2f)
        moveTo(18.0f, 12.6f)
        arcTo(1.05f, 1.05f, 0f, true, true, 15.9f, 12.6f)
        arcTo(1.05f, 1.05f, 0f, true, true, 18.0f, 12.6f)
      }
    }
  }

  val Forum: ImageVector by lazy {
    vec("Forum") {
      // Back bubble (duotone)
      path(
        fill = ink,
        fillAlpha = 0.22f,
        stroke = ink,
        strokeLineWidth = 1.6f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(17.5f, 7.5f)
        horizontalLineTo(19f)
        curveTo(20.66f, 7.5f, 22f, 8.84f, 22f, 10.5f)
        verticalLineTo(20.5f)
        lineTo(18.8f, 18f)
        horizontalLineTo(10.5f)
        curveTo(9.1f, 18f, 7.9f, 17.0f, 7.6f, 15.7f)
      }
      // Front primary bubble
      path(
        fill = ink,
        fillAlpha = 0.16f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(5.5f, 3.5f)
        horizontalLineTo(14.5f)
        curveTo(16.16f, 3.5f, 17.5f, 4.84f, 17.5f, 6.5f)
        verticalLineTo(11.5f)
        curveTo(17.5f, 13.16f, 16.16f, 14.5f, 14.5f, 14.5f)
        horizontalLineTo(6.2f)
        lineTo(2.5f, 17.2f)
        verticalLineTo(6.5f)
        curveTo(2.5f, 4.84f, 3.84f, 3.5f, 5.5f, 3.5f)
        close()
      }
      // Chat dots
      path(fill = ink) {
        moveTo(7.8f, 9f)
        arcTo(0.95f, 0.95f, 0f, true, true, 5.9f, 9f)
        arcTo(0.95f, 0.95f, 0f, true, true, 7.8f, 9f)
        moveTo(10.95f, 9f)
        arcTo(0.95f, 0.95f, 0f, true, true, 9.05f, 9f)
        arcTo(0.95f, 0.95f, 0f, true, true, 10.95f, 9f)
        moveTo(14.1f, 9f)
        arcTo(0.95f, 0.95f, 0f, true, true, 12.2f, 9f)
        arcTo(0.95f, 0.95f, 0f, true, true, 14.1f, 9f)
      }
    }
  }

  val Trophy: ImageVector by lazy {
    vec("Trophy") {
      // Cup body
      path(
        fill = ink,
        fillAlpha = 0.24f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(7f, 4f)
        horizontalLineTo(17f)
        verticalLineTo(10.2f)
        curveTo(17f, 13.0f, 14.76f, 15.2f, 12f, 15.2f)
        curveTo(9.24f, 15.2f, 7f, 13.0f, 7f, 10.2f)
        verticalLineTo(4f)
        close()
      }
      // Handles & stem/base
      path(
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(7f, 5.8f)
        horizontalLineTo(4.6f)
        curveTo(3.7f, 5.8f, 3f, 6.5f, 3f, 7.4f)
        verticalLineTo(8.3f)
        curveTo(3f, 10.1f, 4.3f, 11.6f, 6.1f, 11.9f)
        moveTo(17f, 5.8f)
        horizontalLineTo(19.4f)
        curveTo(20.3f, 5.8f, 21f, 6.5f, 21f, 7.4f)
        verticalLineTo(8.3f)
        curveTo(21f, 10.1f, 19.7f, 11.6f, 17.9f, 11.9f)
        moveTo(12f, 15.2f)
        verticalLineTo(19.5f)
        moveTo(8f, 20f)
        horizontalLineTo(16f)
      }
    }
  }

  val Crown: ImageVector by lazy {
    vec("Crown") {
      path(
        fill = ink,
        fillAlpha = 0.24f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(4.5f, 16.5f)
        lineTo(3f, 7.5f)
        lineTo(8.2f, 11.2f)
        lineTo(12f, 4.5f)
        lineTo(15.8f, 11.2f)
        lineTo(21f, 7.5f)
        lineTo(19.5f, 16.5f)
        close()
      }
      path(
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
      ) {
        moveTo(5.5f, 19.8f)
        horizontalLineTo(18.5f)
      }
    }
  }

  val Flame: ImageVector by lazy {
    vec("Flame") {
      path(
        fill = ink,
        fillAlpha = 0.24f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(12.8f, 2.2f)
        curveTo(12.8f, 2.2f, 18.8f, 6.8f, 18.8f, 13.6f)
        curveTo(18.8f, 18.1f, 15.6f, 21.5f, 12f, 21.5f)
        curveTo(8.4f, 21.5f, 5.2f, 18.1f, 5.2f, 13.6f)
        curveTo(5.2f, 10.4f, 6.8f, 7.5f, 8.6f, 5.8f)
        curveTo(8.5f, 8.2f, 10.0f, 9.6f, 11.4f, 9.6f)
        curveTo(13.0f, 9.6f, 13.5f, 7.2f, 12.8f, 2.2f)
        close()
      }
      path(fill = ink) {
        moveTo(12f, 19f)
        curveTo(10.3f, 19f, 9.2f, 17.8f, 9.2f, 16.2f)
        curveTo(9.2f, 14.7f, 10.5f, 13.5f, 12.1f, 12.6f)
        curveTo(13.4f, 13.6f, 14.8f, 14.8f, 14.8f, 16.2f)
        curveTo(14.8f, 17.8f, 13.7f, 19f, 12f, 19f)
        close()
      }
    }
  }

  val Dice: ImageVector by lazy {
    vec("Dice") {
      path(
        fill = ink,
        fillAlpha = 0.22f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(6f, 3.5f)
        horizontalLineTo(18f)
        curveTo(19.38f, 3.5f, 20.5f, 4.62f, 20.5f, 6f)
        verticalLineTo(18f)
        curveTo(20.5f, 19.38f, 19.38f, 20.5f, 18f, 20.5f)
        horizontalLineTo(6f)
        curveTo(4.62f, 20.5f, 3.5f, 19.38f, 3.5f, 18f)
        verticalLineTo(6f)
        curveTo(3.5f, 4.62f, 4.62f, 3.5f, 6f, 3.5f)
        close()
      }
      path(fill = ink) {
        moveTo(9.1f, 8f)
        arcTo(1.1f, 1.1f, 0f, true, true, 6.9f, 8f)
        arcTo(1.1f, 1.1f, 0f, true, true, 9.1f, 8f)
        moveTo(17.1f, 8f)
        arcTo(1.1f, 1.1f, 0f, true, true, 14.9f, 8f)
        arcTo(1.1f, 1.1f, 0f, true, true, 17.1f, 8f)
        moveTo(13.1f, 12f)
        arcTo(1.1f, 1.1f, 0f, true, true, 10.9f, 12f)
        arcTo(1.1f, 1.1f, 0f, true, true, 13.1f, 12f)
        moveTo(9.1f, 16f)
        arcTo(1.1f, 1.1f, 0f, true, true, 6.9f, 16f)
        arcTo(1.1f, 1.1f, 0f, true, true, 9.1f, 16f)
        moveTo(17.1f, 16f)
        arcTo(1.1f, 1.1f, 0f, true, true, 14.9f, 16f)
        arcTo(1.1f, 1.1f, 0f, true, true, 17.1f, 16f)
      }
    }
  }

  val Shield: ImageVector by lazy {
    vec("Shield") {
      path(
        fill = ink,
        fillAlpha = 0.22f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(12f, 2.5f)
        lineTo(4.5f, 5.5f)
        verticalLineTo(11.2f)
        curveTo(4.5f, 16.0f, 7.6f, 20.2f, 12f, 21.5f)
        curveTo(16.4f, 20.2f, 19.5f, 16.0f, 19.5f, 11.2f)
        verticalLineTo(5.5f)
        close()
      }
      path(
        stroke = ink,
        strokeLineWidth = 1.85f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(9.2f, 12.1f)
        lineTo(11.2f, 14.1f)
        lineTo(15.0f, 10.1f)
      }
    }
  }

  val Cloud: ImageVector by lazy {
    vec("Cloud") {
      path(
        fill = ink,
        fillAlpha = 0.22f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(6.8f, 19f)
        horizontalLineTo(17.6f)
        curveTo(20.0f, 19f, 21.8f, 17.2f, 21.8f, 14.9f)
        curveTo(21.8f, 12.7f, 20.2f, 10.9f, 18.0f, 10.7f)
        curveTo(17.3f, 7.4f, 14.4f, 5.0f, 11.0f, 5.0f)
        curveTo(7.3f, 5.0f, 4.4f, 7.8f, 4.2f, 11.4f)
        curveTo(2.7f, 12.0f, 1.8f, 13.4f, 1.8f, 15.0f)
        curveTo(1.8f, 17.2f, 3.6f, 19f, 5.8f, 19f)
        close()
      }
    }
  }

  val Groups: ImageVector by lazy {
    vec("Groups") {
      // Secondary user (duotone)
      path(
        fill = ink,
        fillAlpha = 0.22f,
        stroke = ink,
        strokeLineWidth = 1.6f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(16.2f, 10.5f)
        arcTo(2.6f, 2.6f, 0f, true, true, 16.2f, 5.3f)
        arcTo(2.6f, 2.6f, 0f, true, true, 16.2f, 10.5f)
        moveTo(16.5f, 13.8f)
        curveTo(19.2f, 13.8f, 21.4f, 15.3f, 21.8f, 17.8f)
        horizontalLineTo(16.5f)
      }
      // Primary user
      path(
        fill = ink,
        fillAlpha = 0.22f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(9.0f, 11.2f)
        arcTo(3.1f, 3.1f, 0f, true, true, 9.0f, 5.0f)
        arcTo(3.1f, 3.1f, 0f, true, true, 9.0f, 11.2f)
        moveTo(2.5f, 18.8f)
        curveTo(2.8f, 15.6f, 5.5f, 13.6f, 9.0f, 13.6f)
        curveTo(12.5f, 13.6f, 15.2f, 15.6f, 15.5f, 18.8f)
        close()
      }
    }
  }

  val PersonAdd: ImageVector by lazy {
    vec("PersonAdd") {
      path(
        fill = ink,
        fillAlpha = 0.22f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(14.5f, 11.2f)
        arcTo(3.2f, 3.2f, 0f, true, true, 14.5f, 4.8f)
        arcTo(3.2f, 3.2f, 0f, true, true, 14.5f, 11.2f)
        moveTo(8.0f, 19.2f)
        curveTo(8.3f, 15.8f, 11.0f, 13.8f, 14.5f, 13.8f)
        curveTo(18.0f, 13.8f, 20.7f, 15.8f, 21.0f, 19.2f)
        close()
      }
      path(
        stroke = ink,
        strokeLineWidth = 1.85f,
        strokeLineCap = StrokeCap.Round,
      ) {
        moveTo(5.2f, 8.0f)
        verticalLineTo(13.2f)
        moveTo(2.6f, 10.6f)
        horizontalLineTo(7.8f)
      }
    }
  }

  val PublicGlobe: ImageVector by lazy {
    vec("PublicGlobe") {
      path(
        fill = ink,
        fillAlpha = 0.18f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(12f, 2.5f)
        arcTo(9.5f, 9.5f, 0f, true, true, 11.99f, 2.5f)
        close()
      }
      path(
        stroke = ink,
        strokeLineWidth = 1.5f,
        strokeLineCap = StrokeCap.Round,
      ) {
        moveTo(2.8f, 12f)
        horizontalLineTo(21.2f)
        moveTo(12f, 2.6f)
        curveTo(14.8f, 5.6f, 14.8f, 18.4f, 12f, 21.4f)
        moveTo(12f, 2.6f)
        curveTo(9.2f, 5.6f, 9.2f, 18.4f, 12f, 21.4f)
      }
    }
  }

  val Bolt: ImageVector by lazy {
    vec("Bolt") {
      path(
        fill = ink,
        fillAlpha = 0.26f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(13.5f, 2.5f)
        lineTo(5.5f, 13.2f)
        horizontalLineTo(11.5f)
        lineTo(10.5f, 21.5f)
        lineTo(18.5f, 10.8f)
        horizontalLineTo(12.5f)
        close()
      }
    }
  }

  val Photo: ImageVector by lazy {
    vec("Photo") {
      path(
        fill = ink,
        fillAlpha = 0.18f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(5.5f, 3.8f)
        horizontalLineTo(18.5f)
        curveTo(19.7f, 3.8f, 20.5f, 4.6f, 20.5f, 5.8f)
        verticalLineTo(18.2f)
        curveTo(20.5f, 19.4f, 19.7f, 20.2f, 18.5f, 20.2f)
        horizontalLineTo(5.5f)
        curveTo(4.3f, 20.2f, 3.5f, 19.4f, 3.5f, 18.2f)
        verticalLineTo(5.8f)
        curveTo(3.5f, 4.6f, 4.3f, 3.8f, 5.5f, 3.8f)
        close()
      }
      path(
        stroke = ink,
        strokeLineWidth = 1.65f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(4.2f, 17.0f)
        lineTo(8.8f, 12.2f)
        lineTo(12.2f, 15.4f)
        lineTo(15.2f, 12.6f)
        lineTo(19.8f, 17.2f)
      }
      path(fill = ink) {
        moveTo(10.2f, 8.6f)
        arcTo(1.3f, 1.3f, 0f, true, true, 7.6f, 8.6f)
        arcTo(1.3f, 1.3f, 0f, true, true, 10.2f, 8.6f)
      }
    }
  }

  val Reply: ImageVector by lazy {
    vec("Reply") {
      path(
        stroke = ink,
        strokeLineWidth = 1.9f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(9.5f, 7f)
        lineTo(4.5f, 11.8f)
        lineTo(9.5f, 16.6f)
        moveTo(5.0f, 11.8f)
        horizontalLineTo(14.0f)
        curveTo(17.5f, 11.8f, 19.8f, 14.0f, 20.0f, 17.8f)
      }
    }
  }

  val ArrowDown: ImageVector by lazy {
    vec("ArrowDown") {
      path(
        stroke = ink,
        strokeLineWidth = 2.0f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(6.5f, 9.5f)
        lineTo(12f, 15f)
        lineTo(17.5f, 9.5f)
      }
    }
  }

  val VolumeUp: ImageVector by lazy {
    vec("VolumeUp") {
      path(
        fill = ink,
        fillAlpha = 0.24f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(3.5f, 9.5f)
        horizontalLineTo(7.2f)
        lineTo(12.2f, 5.2f)
        verticalLineTo(18.8f)
        lineTo(7.2f, 14.5f)
        horizontalLineTo(3.5f)
        close()
      }
      path(
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
      ) {
        moveTo(15.5f, 9.2f)
        curveTo(16.7f, 10.6f, 16.7f, 13.4f, 15.5f, 14.8f)
        moveTo(18.2f, 6.8f)
        curveTo(20.6f, 9.6f, 20.6f, 14.4f, 18.2f, 17.2f)
      }
    }
  }

  val VolumeOff: ImageVector by lazy {
    vec("VolumeOff") {
      path(
        fill = ink,
        fillAlpha = 0.20f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(3.5f, 9.5f)
        horizontalLineTo(7.2f)
        lineTo(12.2f, 5.2f)
        verticalLineTo(18.8f)
        lineTo(7.2f, 14.5f)
        horizontalLineTo(3.5f)
        close()
      }
      path(
        stroke = ink,
        strokeLineWidth = 1.85f,
        strokeLineCap = StrokeCap.Round,
      ) {
        moveTo(16f, 9.5f)
        lineTo(20.5f, 14.5f)
        moveTo(20.5f, 9.5f)
        lineTo(16f, 14.5f)
      }
    }
  }

  val Copy: ImageVector by lazy {
    vec("Copy") {
      path(
        fill = ink,
        fillAlpha = 0.20f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(9.5f, 8.2f)
        horizontalLineTo(18.5f)
        curveTo(19.6f, 8.2f, 20.5f, 9.1f, 20.5f, 10.2f)
        verticalLineTo(19.2f)
        curveTo(20.5f, 20.3f, 19.6f, 21.2f, 18.5f, 21.2f)
        horizontalLineTo(9.5f)
        curveTo(8.4f, 21.2f, 7.5f, 20.3f, 7.5f, 19.2f)
        verticalLineTo(10.2f)
        curveTo(7.5f, 9.1f, 8.4f, 8.2f, 9.5f, 8.2f)
        close()
      }
      path(
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(15.5f, 5.2f)
        verticalLineTo(4.6f)
        curveTo(15.5f, 3.6f, 14.7f, 2.8f, 13.7f, 2.8f)
        horizontalLineTo(5.3f)
        curveTo(4.3f, 2.8f, 3.5f, 3.6f, 3.5f, 4.6f)
        verticalLineTo(14.0f)
        curveTo(3.5f, 15.0f, 4.3f, 15.8f, 5.3f, 15.8f)
        horizontalLineTo(5.8f)
      }
    }
  }

  val Code: ImageVector by lazy {
    vec("Code") {
      path(
        stroke = ink,
        strokeLineWidth = 1.9f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(8.5f, 7.5f)
        lineTo(3.5f, 12f)
        lineTo(8.5f, 16.5f)
        moveTo(15.5f, 7.5f)
        lineTo(20.5f, 12f)
        lineTo(15.5f, 16.5f)
        moveTo(13.5f, 5.5f)
        lineTo(10.5f, 18.5f)
      }
    }
  }

  val Key: ImageVector by lazy {
    vec("Key") {
      path(
        fill = ink,
        fillAlpha = 0.24f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(7.5f, 16.5f)
        arcTo(4.5f, 4.5f, 0f, true, true, 7.5f, 7.5f)
        arcTo(4.5f, 4.5f, 0f, true, true, 7.5f, 16.5f)
      }
      path(
        stroke = ink,
        strokeLineWidth = 1.85f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(12.0f, 12.0f)
        horizontalLineTo(21.2f)
        moveTo(17.5f, 12.0f)
        verticalLineTo(15.2f)
        moveTo(20.5f, 12.0f)
        verticalLineTo(14.5f)
      }
    }
  }

  val Visibility: ImageVector by lazy {
    vec("Visibility") {
      path(
        fill = ink,
        fillAlpha = 0.16f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(2.2f, 12f)
        curveTo(4.5f, 7.8f, 8.0f, 5.8f, 12f, 5.8f)
        curveTo(16.0f, 5.8f, 19.5f, 7.8f, 21.8f, 12f)
        curveTo(19.5f, 16.2f, 16.0f, 18.2f, 12f, 18.2f)
        curveTo(8.0f, 18.2f, 4.5f, 16.2f, 2.2f, 12f)
        close()
      }
      path(
        fill = ink,
        fillAlpha = 0.35f,
        stroke = ink,
        strokeLineWidth = 1.6f,
      ) {
        moveTo(14.6f, 12f)
        arcTo(2.6f, 2.6f, 0f, true, true, 9.4f, 12f)
        arcTo(2.6f, 2.6f, 0f, true, true, 14.6f, 12f)
      }
    }
  }

  val Logout: ImageVector by lazy {
    vec("Logout") {
      path(
        fill = ink,
        fillAlpha = 0.16f,
        stroke = ink,
        strokeLineWidth = 1.75f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(11.5f, 3.8f)
        horizontalLineTo(6.2f)
        curveTo(4.9f, 3.8f, 3.8f, 4.9f, 3.8f, 6.2f)
        verticalLineTo(17.8f)
        curveTo(3.8f, 19.1f, 4.9f, 20.2f, 6.2f, 20.2f)
        horizontalLineTo(11.5f)
      }
      path(
        stroke = ink,
        strokeLineWidth = 1.85f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(10.0f, 12f)
        horizontalLineTo(20.2f)
        moveTo(16.5f, 8.2f)
        lineTo(20.4f, 12f)
        lineTo(16.5f, 15.8f)
      }
    }
  }
}
