package com.example.ui.screens

import android.app.Activity
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CPanelConfig
import com.example.data.CPanelPhpGenerator
import com.example.data.PingResult
import com.example.security.CryptoManager
import com.example.ui.components.BaziIcons
import com.example.ui.components.SecurityShieldBadge
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPulse

@Composable
fun AdminPanelScreen(
  initialConfig: CPanelConfig,
  pingLoading: Boolean,
  pingResult: PingResult?,
  onSaveConfig: (CPanelConfig) -> Unit,
  onTestConnection: (CPanelConfig) -> Unit,
  onClose: () -> Unit,
) {
  BackHandler(onBack = onClose)

  // Block screenshots/screen recording while Admin secrets are visible
  val context = LocalContext.current
  DisposableEffect(Unit) {
    val window = (context as? Activity)?.window
    window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
    onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
  }

  var apiBaseUrl by remember(initialConfig) { mutableStateOf(initialConfig.apiBaseUrl) }
  var dbHost by remember(initialConfig) { mutableStateOf(initialConfig.dbHost) }
  var dbName by remember(initialConfig) { mutableStateOf(initialConfig.dbName) }
  var dbUser by remember(initialConfig) { mutableStateOf(initialConfig.dbUser) }
  var dbPassword by remember { mutableStateOf(initialConfig.dbPassword) }
  var apiSecret by remember(initialConfig) { mutableStateOf(initialConfig.apiSecret) }
  var confirmNewKey by remember { mutableStateOf(false) }
  var hmacEnabled by remember(initialConfig) { mutableStateOf(initialConfig.hmacEnabled) }
  var e2eeEnabled by remember(initialConfig) { mutableStateOf(initialConfig.e2eeEnabled) }
  var maintenanceMode by remember(initialConfig) { mutableStateOf(initialConfig.maintenanceMode) }
  var savedBanner by remember { mutableStateOf<String?>(null) }
  var showPhpCodeDialog by remember { mutableStateOf(false) }
  var showSqlCodeDialog by remember { mutableStateOf(false) }
  val clipboard = LocalClipboardManager.current
  val clearHandler = remember { android.os.Handler(android.os.Looper.getMainLooper()) }
  // Copied code contains the DB password / secret: wipe the clipboard after 60 seconds.
  fun copySecret(text: String) {
    clipboard.setText(AnnotatedString(text))
    clearHandler.postDelayed({ clipboard.setText(AnnotatedString("")) }, 60_000L)
  }

  fun buildConfig(): CPanelConfig =
    initialConfig.copy(
      apiBaseUrl = apiBaseUrl.trim(),
      dbHost = dbHost.trim().ifBlank { "localhost" },
      dbName = dbName.trim(),
      dbUser = dbUser.trim(),
      dbPassword = dbPassword,
      apiSecret = apiSecret.trim(),
      hmacEnabled = hmacEnabled,
      e2eeEnabled = e2eeEnabled,
      maintenanceMode = maintenanceMode,
    )

  Column(
    modifier = Modifier.fillMaxSize().background(ObsidianBg).systemBarsPadding(),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    // Admin Top Bar
    Surface(
      color = CarbonSurface,
      border = BorderStroke(1.dp, VioletPulse.copy(alpha = 0.5f)),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(onClick = onClose, modifier = Modifier.size(48.dp).testTag("admin_back_button")) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "خروج از پنل", tint = TextPrimary)
          }
          Spacer(Modifier.width(6.dp))
          Column {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Icon(BaziIcons.Shield, contentDescription = null, tint = VioletPulse, modifier = Modifier.size(20.dp))
              Text("پنل مدیریت امن", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
            }
            Text("تنظیمات اتصال به هاست سی‌پنل ایران و رمزنگاری", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
          }
        }
      }
    }

    Column(
      modifier =
        Modifier.fillMaxSize()
          .widthIn(max = 640.dp)
          .verticalScroll(rememberScrollState())
          .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      SecurityShieldBadge(label = "محافظت‌شده با FLAG_SECURE و کلید سخت‌افزاری Android KeyStore")

      // 1. Iranian cPanel Endpoint Section
      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
        border = BorderStroke(1.dp, ElevatedCardStroke),
        shape = RoundedCornerShape(20.dp),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(BaziIcons.Cloud, contentDescription = null, tint = NeonCyan)
            Text("آدرس سرور و دیتابیس سی‌پنل ایران", style = MaterialTheme.typography.titleMedium, color = NeonCyan)
          }

          AdminField(
            value = apiBaseUrl,
            onValueChange = { apiBaseUrl = it },
            label = "آدرس API فایل PHP روی هاست (HTTPS)",
            placeholder = "https://yourdomain.ir/bazirox/api.php",
            testTag = "admin_api_url_input",
          )

          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AdminField(
              value = dbHost,
              onValueChange = { dbHost = it },
              label = "MySQL Host",
              placeholder = "localhost",
              modifier = Modifier.weight(1f),
              testTag = "admin_db_host_input",
            )
            AdminField(
              value = dbName,
              onValueChange = { dbName = it },
              label = "نام دیتابیس سی‌پنل",
              placeholder = "user_bazirox",
              modifier = Modifier.weight(1f),
              testTag = "admin_db_name_input",
            )
          }

          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AdminField(
              value = dbUser,
              onValueChange = { dbUser = it },
              label = "یوزر دیتابیس",
              placeholder = "user_dbadmin",
              modifier = Modifier.weight(1f),
              testTag = "admin_db_user_input",
            )
            AdminField(
              value = dbPassword,
              onValueChange = { dbPassword = it },
              label = "رمز دیتابیس",
              placeholder = "••••••••",
              isSecret = true,
              modifier = Modifier.weight(1f),
              testTag = "admin_db_pass_input",
            )
          }
        }
      }

      // 2. Cryptographic & Security Controls
      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
        border = BorderStroke(1.dp, ElevatedCardStroke),
        shape = RoundedCornerShape(20.dp),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(BaziIcons.Shield, contentDescription = null, tint = ElectricEmerald)
            Text("لایه امنیتی و رمزنگاری ارتباط", style = MaterialTheme.typography.titleMedium, color = ElectricEmerald)
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            AdminField(
              value = apiSecret,
              onValueChange = { apiSecret = it },
              label = "کلید HMAC + رمزنگاری انتقال",
              placeholder = "کلید مشترک با api.php",
              modifier = Modifier.weight(1f),
              testTag = "admin_secret_input",
            )
            OutlinedButton(
              onClick = {
                if (apiSecret.isBlank()) apiSecret = CryptoManager.generateSecureSecret(24)
                else confirmNewKey = true
              },
              modifier = Modifier.height(54.dp),
              border = BorderStroke(1.dp, CyberGold),
              shape = RoundedCornerShape(12.dp),
            ) {
              Icon(BaziIcons.Key, contentDescription = "تولید کلید", tint = CyberGold)
            }
          }

          SecuritySwitchRow(
            title = "امضای HMAC-SHA256 + Anti-Replay",
            subtitle = "جلوگیری از دستکاری درخواست‌ها و حملات تکرار",
            checked = hmacEnabled,
            onCheckedChange = { hmacEnabled = it },
          )
          SecuritySwitchRow(
            title = "رمزنگاری انتقال AES-256-GCM",
            subtitle = "رمزنگاری بدنه‌ی درخواست‌ها بین اپ و PHP (چت‌ها جدا و همیشه روی گوشی رمز می‌شوند)",
            checked = e2eeEnabled,
            onCheckedChange = { e2eeEnabled = it },
          )
          SecuritySwitchRow(
            title = "حالت نگهداری سرور (Maintenance)",
            subtitle = "مسدودسازی موقت درخواست‌های جدید به سرور",
            checked = maintenanceMode,
            onCheckedChange = { maintenanceMode = it },
          )
        }
      }

      // 3. Save & Test Connection Buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Button(
          onClick = {
            val cfg = buildConfig()
            onSaveConfig(cfg)
            savedBanner = "تنظیمات ذخیره شد (رمز دیتابیس هرگز روی دستگاه ذخیره نمی‌شود)"
          },
          modifier = Modifier.weight(1f).height(52.dp).testTag("admin_save_button"),
          colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
          shape = RoundedCornerShape(14.dp),
        ) {
          Icon(Icons.Rounded.Check, contentDescription = null, tint = ObsidianBg)
          Spacer(Modifier.width(6.dp))
          Text("ذخیره تنظیمات", color = ObsidianBg, fontWeight = FontWeight.ExtraBold)
        }

        Button(
          onClick = { onTestConnection(buildConfig()) },
          enabled = !pingLoading,
          modifier = Modifier.weight(1f).height(52.dp).testTag("admin_test_connection_button"),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = ElectricEmerald,
              disabledContainerColor = Color(0xFF232E4D),
              disabledContentColor = Color(0xFFCBD5E1),
            ),
          shape = RoundedCornerShape(14.dp),
        ) {
          if (pingLoading) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = ObsidianBg, strokeWidth = 2.dp)
          } else {
            Icon(BaziIcons.PublicGlobe, contentDescription = null, tint = androidx.compose.material3.LocalContentColor.current)
            Spacer(Modifier.width(6.dp))
            Text("تست اتصال", color = androidx.compose.material3.LocalContentColor.current, fontWeight = FontWeight.ExtraBold)
          }
        }
      }

      if (!savedBanner.isNullOrBlank()) {
        Text(savedBanner!!, style = MaterialTheme.typography.bodyMedium, color = NeonCyan)
      }

      pingResult?.let { res ->
        val col = if (res.success) ElectricEmerald else CrimsonMagenta
        Surface(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          color = col.copy(alpha = 0.14f),
          border = BorderStroke(1.dp, col.copy(alpha = 0.55f)),
        ) {
          Text(
            text = res.message,
            style = MaterialTheme.typography.bodyMedium,
            color = col,
            modifier = Modifier.padding(12.dp),
          )
        }
      }

      // 4. Ready-to-Deploy cPanel PHP + SQL Script Generator
      Card(
        colors = CardDefaults.cardColors(containerColor = ElevatedCard),
        border = BorderStroke(1.dp, CyberGold.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(20.dp),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(BaziIcons.Code, contentDescription = null, tint = CyberGold)
            Text("اسکریپت آماده نصب روی هاست سی‌پنل ایران", style = MaterialTheme.typography.titleMedium, color = CyberGold)
          }
          Text(
            "با زدن دکمه‌های زیر، کد امن PHP 8 (با PDO و رمزنگاری مطابق تنظیمات بالا) و جدول‌های MySQL را کپی کرده و در File Manager / phpMyAdmin سی‌پنل قرار دهید.",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
          )
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
              onClick = { showPhpCodeDialog = true },
              modifier = Modifier.weight(1f).height(48.dp).testTag("admin_view_php_button"),
              border = BorderStroke(1.dp, CyberGold),
              shape = RoundedCornerShape(12.dp),
            ) {
              Text("کد api.php", color = CyberGold, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
              onClick = { showSqlCodeDialog = true },
              modifier = Modifier.weight(1f).height(48.dp).testTag("admin_view_sql_button"),
              border = BorderStroke(1.dp, NeonCyan),
              shape = RoundedCornerShape(12.dp),
            ) {
              Text("کد schema.sql", color = NeonCyan, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
      Spacer(Modifier.height(16.dp))
    }
  }

  if (confirmNewKey) {
    AlertDialog(
      onDismissRequest = { confirmNewKey = false },
      containerColor = Color(0xFF182238),
      title = { Text("ساخت کلید جدید؟", color = CyberGold) },
      text = {
        Text(
          "کلید فعلی جایگزین می‌شود. تا وقتی همین کلید را در api.php روی سرور هم عوض نکنی، اپ به سرور وصل نمی‌شود.",
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary,
        )
      },
      confirmButton = {
        Button(
          onClick = {
            apiSecret = CryptoManager.generateSecureSecret(24)
            confirmNewKey = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = CyberGold),
        ) { Text("جایگزین کن", color = ObsidianBg, fontWeight = FontWeight.Bold) }
      },
      dismissButton = {
        TextButton(onClick = { confirmNewKey = false }) { Text("انصراف", color = TextSecondary) }
      },
    )
  }

  if (showPhpCodeDialog) {
    val phpCode = remember(apiBaseUrl, dbHost, dbName, dbUser, dbPassword, apiSecret, hmacEnabled, e2eeEnabled, maintenanceMode) {
      CPanelPhpGenerator.generateApiPhp(buildConfig())
    }
    CodePreviewDialog(
      title = "api.php (آپلود در public_html)",
      code = phpCode,
      onCopy = { copySecret(phpCode) },
      onDismiss = { showPhpCodeDialog = false },
    )
  }

  if (showSqlCodeDialog) {
    val sqlCode = remember { CPanelPhpGenerator.generateSchemaSql() }
    CodePreviewDialog(
      title = "schema.sql (اجرا در phpMyAdmin)",
      code = sqlCode,
      onCopy = { copySecret(sqlCode) },
      onDismiss = { showSqlCodeDialog = false },
    )
  }
}

@Composable
private fun AdminField(
  value: String,
  onValueChange: (String) -> Unit,
  label: String,
  placeholder: String,
  testTag: String,
  isSecret: Boolean = false,
  modifier: Modifier = Modifier,
) {
  OutlinedTextField(
    value = value,
    onValueChange = onValueChange,
    label = { Text(label, maxLines = 1) },
    placeholder = { Text(placeholder) },
    singleLine = true,
    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
      capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.None,
      keyboardType = if (isSecret) androidx.compose.ui.text.input.KeyboardType.Password else androidx.compose.ui.text.input.KeyboardType.Ascii,
      imeAction = androidx.compose.ui.text.input.ImeAction.Next,
    ),
    visualTransformation = if (isSecret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
    modifier = modifier.fillMaxWidth().testTag(testTag),
    colors =
      OutlinedTextFieldDefaults.colors(
        focusedBorderColor = NeonCyan,
        unfocusedBorderColor = ElevatedCardStroke,
        focusedContainerColor = ObsidianBg,
        unfocusedContainerColor = ObsidianBg,
      ),
    shape = RoundedCornerShape(12.dp),
  )
}

@Composable
private fun SecuritySwitchRow(
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
      Text(title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
      Text(subtitle, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    }
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      colors = SwitchDefaults.colors(checkedThumbColor = ObsidianBg, checkedTrackColor = ElectricEmerald),
    )
  }
}

@Composable
private fun CodePreviewDialog(
  title: String,
  code: String,
  onCopy: () -> Unit,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = CarbonSurface,
    title = { Text(title, color = NeonCyan) },
    text = {
      Box(
        modifier =
          Modifier.fillMaxWidth()
            .height(300.dp)
            .background(ObsidianBg, RoundedCornerShape(12.dp))
            .padding(10.dp)
            .verticalScroll(rememberScrollState())
            .horizontalScroll(rememberScrollState())
      ) {
        Text(
          text = code,
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
          lineHeight = 16.sp,
          color = ElectricEmerald,
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onCopy()
          onDismiss()
        },
        colors = ButtonDefaults.buttonColors(containerColor = CyberGold),
      ) {
        Icon(BaziIcons.Copy, contentDescription = null, tint = ObsidianBg)
        Spacer(Modifier.width(6.dp))
        Text("کپی کل کد", color = ObsidianBg, fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("بستن", color = TextSecondary) }
    },
  )
}
