package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import com.example.ui.theme.TextMuted
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.CPanelConfig
import com.example.data.GameType
import com.example.data.UserAccount
import com.example.ui.components.AvatarBadge
import com.example.ui.components.BaziIcons
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.appear
import com.example.ui.components.auroraGamingBackdrop
import com.example.ui.components.drawGlossyToken
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlayerBlue
import com.example.ui.theme.PlayerGreen
import com.example.ui.theme.PlayerRed
import com.example.ui.theme.PlayerYellow
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPulse
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.graphics.graphicsLayer
import com.example.ui.components.fadeSlideIn
import com.example.ui.components.toFaDigits

@Composable
fun HomeScreen(
  currentUser: UserAccount?,
  cPanelConfig: CPanelConfig,
  onSelectGame: (GameType) -> Unit,
  onQuickJoinRoom: (String, GameType) -> Unit,
  onOpenProfile: () -> Unit,
  onOpenEmulator: () -> Unit = {},
  avatar: androidx.compose.ui.graphics.ImageBitmap? = null,
  modifier: Modifier = Modifier,
) {
  var quickCode by remember { mutableStateOf("") }

  LazyColumn(
    modifier = modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF090E18), Color(0xFF0E1524), Color(0xFF080C14)))),
    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    // 1. Modern Player Header + Live Status
    item {
      val score = currentUser?.totalScore ?: 0
      val xpProgress = (score % 150) / 150f
      var xpGoal by remember { mutableFloatStateOf(0.08f) }
      LaunchedEffect(xpProgress) { xpGoal = xpProgress.coerceIn(0.08f, 1f) }
      val xpAnim by animateFloatAsState(xpGoal, tween(900, easing = FastOutSlowInEasing), label = "xp_fill")

      Row(
        modifier =
          Modifier.fillMaxWidth()
            .widthIn(max = 680.dp)
            .padding(top = 4.dp, bottom = 2.dp)
            .fadeSlideIn(0),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          modifier =
            Modifier.weight(1f)
              .clip(RoundedCornerShape(16.dp))
              .clickable(onClick = onOpenProfile)
              .padding(vertical = 2.dp)
              .testTag("home_profile_chip"),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Box(
            modifier =
              Modifier.size(46.dp)
                .clip(CircleShape)
                .border(1.8.dp, Brush.linearGradient(listOf(NeonCyan, VioletPulse)), CircleShape)
                .padding(2.dp),
            contentAlignment = Alignment.Center,
          ) {
            AvatarBadge(
              name = currentUser?.displayName ?: "مهمان",
              colorIndex = currentUser?.avatarColorIndex ?: 0,
              size = 40.dp,
              image = avatar,
            )
          }
          Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              Text(
                text = currentUser?.displayName ?: "بازیکن مهمان • ورود",
                style = MaterialTheme.typography.titleMedium.copy(fontSize = 15.5.sp),
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Surface(
                shape = RoundedCornerShape(50),
                color = Color(0xFF17253B),
              ) {
                Text(
                  text = "سطح ${(currentUser?.level ?: 1).toFaDigits()}",
                  style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                  color = NeonCyan,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                )
              }
            }
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Box(
                modifier =
                  Modifier.weight(1f)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.08f))
              ) {
                Box(
                  modifier =
                    Modifier.fillMaxWidth(xpAnim)
                      .height(4.dp)
                      .clip(CircleShape)
                      .background(Brush.horizontalGradient(listOf(NeonCyan, VioletPulse)))
                )
              }
              Text(
                text = "${(score % 150).toFaDigits()}/۱۵۰ XP",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                color = Color(0xFF8B98A5),
              )
            }
          }
        }

      }
    }

    // 2. Unified Modern Gaming Hub (Stats + Quick Launch + Room Code Join)
    item {
      val score = currentUser?.totalScore ?: 0
      Surface(
        modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp).fadeSlideIn(1),
        shape = RoundedCornerShape(24.dp),
        color = Color.Transparent,
        border =
          BorderStroke(
            0.8.dp,
            Brush.linearGradient(listOf(Color.White.copy(alpha = 0.14f), VioletPulse.copy(alpha = 0.25f), NeonCyan.copy(alpha = 0.22f))),
          ),
      ) {
        Box(
          modifier =
            Modifier.fillMaxWidth()
              .background(Brush.verticalGradient(listOf(Color(0xFF141D30), Color(0xFF0E1524))))
        ) {
          Canvas(modifier = Modifier.matchParentSize()) {
            drawCircle(
              brush = Brush.radialGradient(
                listOf(VioletPulse.copy(alpha = 0.18f), Color.Transparent),
                center = Offset(size.width * 0.12f, size.height * 0.15f),
                radius = size.width * 0.50f,
              ),
              center = Offset(size.width * 0.12f, size.height * 0.15f),
              radius = size.width * 0.50f,
            )
            drawCircle(
              brush = Brush.radialGradient(
                listOf(NeonCyan.copy(alpha = 0.14f), Color.Transparent),
                center = Offset(size.width * 0.88f, size.height * 0.85f),
                radius = size.width * 0.45f,
              ),
              center = Offset(size.width * 0.88f, size.height * 0.85f),
              radius = size.width * 0.45f,
            )
          }

          Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            // Sleek 4-Stat Bar
            Surface(
              shape = RoundedCornerShape(16.dp),
              color = Color(0xFF0B101C),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                HomeStatChip(score.toFaDigits(), "امتیاز", CyberGold, Modifier.weight(1f))
                Box(Modifier.width(0.8.dp).height(24.dp).background(Color.White.copy(alpha = 0.08f)))
                HomeStatChip((currentUser?.wins ?: 0).toFaDigits(), "برد", CrimsonMagenta, Modifier.weight(1f))
                Box(Modifier.width(0.8.dp).height(24.dp).background(Color.White.copy(alpha = 0.08f)))
                HomeStatChip((currentUser?.gamesPlayed ?: 0).toFaDigits(), "بازی", NeonCyan, Modifier.weight(1f))
                Box(Modifier.width(0.8.dp).height(24.dp).background(Color.White.copy(alpha = 0.08f)))
                HomeStatChip("${(currentUser?.winRatePercent ?: 0).toFaDigits()}٪", "درصد برد", ElectricEmerald, Modifier.weight(1f))
              }
            }

            // Two Modern Quick-Launch Pills
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Box(
                modifier =
                  Modifier.weight(1f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF0EA5E9), Color(0xFF3B82F6))))
                    .clickable { onSelectGame(GameType.LUDO) }
                    .testTag("hero_play_ludo_button"),
                contentAlignment = Alignment.Center,
              ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(19.dp))
                  Text("شروع منچ", color = Color.White, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.labelLarge)
                }
              }
              Surface(
                onClick = { onSelectGame(GameType.TIC_TAC_TOE) },
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF1A2538),
                border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.1f)),
                modifier = Modifier.weight(1f).height(44.dp),
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Text("دوز سریع", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                }
              }
            }

            // Unified Room-Code Join Pill
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = Color(0xFF0A0F1A),
              border = BorderStroke(0.7.dp, Color.White.copy(alpha = 0.09f)),
              modifier = Modifier.fillMaxWidth().height(46.dp),
            ) {
              Row(
                modifier = Modifier.fillMaxSize().padding(start = 10.dp, end = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Icon(BaziIcons.PublicGlobe, contentDescription = null, tint = Color(0xFF8B5CF6), modifier = Modifier.size(18.dp))
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                  if (quickCode.isEmpty()) {
                    Text("کد اتاق دوستت (مثلاً BZ1A2B)", style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.5.sp), color = Color(0xFF64748B))
                  }
                  BasicTextField(
                    value = quickCode,
                    onValueChange = { quickCode = it.uppercase().take(16) },
                    singleLine = true,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                      capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Characters,
                      keyboardType = androidx.compose.ui.text.input.KeyboardType.Ascii,
                      imeAction = androidx.compose.ui.text.input.ImeAction.Go,
                    ),
                    keyboardActions = androidx.compose.foundation.text.KeyboardActions(onGo = {
                      if (quickCode.isNotBlank()) onQuickJoinRoom(quickCode, GameType.LUDO)
                    }),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                      color = Color.White,
                      textDirection = androidx.compose.ui.text.style.TextDirection.Ltr,
                      fontWeight = FontWeight.Bold,
                      letterSpacing = 1.sp,
                    ),
                    cursorBrush = SolidColor(NeonCyan),
                    modifier = Modifier.fillMaxWidth().testTag("home_quick_room_input"),
                  )
                }

                val canQuickJoin = quickCode.isNotBlank()
                Box(
                  modifier =
                    Modifier.height(34.dp)
                      .clip(RoundedCornerShape(10.dp))
                      .background(
                        if (canQuickJoin) Brush.horizontalGradient(listOf(VioletPulse, Color(0xFF3B82F6)))
                        else Brush.horizontalGradient(listOf(Color(0xFF1B2436), Color(0xFF1B2436)))
                      )
                      .clickable(enabled = canQuickJoin) { onQuickJoinRoom(quickCode, GameType.LUDO) }
                      .padding(horizontal = 16.dp)
                      .testTag("home_quick_join_button"),
                  contentAlignment = Alignment.Center,
                ) {
                  Text(
                    text = "ورود",
                    color = if (canQuickJoin) Color.White else Color(0xFF64748B),
                    fontWeight = FontWeight.ExtraBold,
                    style = MaterialTheme.typography.labelMedium,
                  )
                }
              }
            }
          }
        }
      }
    }

    // 4a. Console games: title + emulator entry banner
    item {
      HomeSectionTitle(title = "بازی های کنسول", trailing = "Sega · Neo Geo", trailingTint = CyberGold)
    }
    item {
      Image(
        painter = painterResource(id = R.drawable.img_emulator_banner),
        contentDescription = "بخش امولاتور",
        contentScale = ContentScale.FillWidth,
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 680.dp)
          .clip(RoundedCornerShape(18.dp))
          .clickable(
            onClickLabel = "ورود به بخش امولاتور",
            role = androidx.compose.ui.semantics.Role.Button,
            onClick = onOpenEmulator,
          )
          .testTag("home_emulator_banner"),
      )
    }

    // 4b. Regular games: title
    item {
      HomeSectionTitle(title = "بازی های عادی", trailing = "آنلاین و آفلاین", trailingTint = ElectricEmerald, showGlobe = true)
    }

    // 5. Modern 2-column square game cards
    item {
      val games = GameType.entries
      Column(
        modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        games.chunked(2).forEach { pair ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            pair.forEach { g ->
              GameArcadeCard(
                gameType = g,
                modifier = Modifier.weight(1f).aspectRatio(0.95f).appear(games.indexOf(g) * 55),
                onClick = { onSelectGame(g) },
              )
            }
            if (pair.size == 1) {
              Spacer(Modifier.weight(1f))
            }
          }
        }
      }
    }

    item { Spacer(Modifier.height(8.dp)) }
  }
}

@Composable
private fun HomeSectionTitle(title: String, trailing: String, trailingTint: Color, showGlobe: Boolean = false) {
  Row(
    modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp).padding(top = 2.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
      Icon(BaziIcons.SportsEsports, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(18.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = TextPrimary,
        fontWeight = FontWeight.Bold,
      )
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
      if (showGlobe) Icon(BaziIcons.PublicGlobe, contentDescription = null, tint = trailingTint, modifier = Modifier.size(14.dp))
      Text(trailing, style = MaterialTheme.typography.labelSmall, color = trailingTint)
    }
  }
}

@Composable
private fun HomeStatChip(value: String, label: String, tint: Color, modifier: Modifier = Modifier) {
  Column(
    modifier = modifier.padding(horizontal = 4.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(1.dp),
  ) {
    Text(value, style = MaterialTheme.typography.titleSmall, color = tint, fontWeight = FontWeight.ExtraBold, maxLines = 1)
    Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary, maxLines = 1)
  }
}

@Composable
private fun GameArcadeCard(
  gameType: GameType,
  modifier: Modifier = Modifier,
  onClick: () -> Unit,
) {
  val (accent, gradEnd) =
    when (gameType) {
      GameType.LUDO -> Color(0xFFF43F5E) to Color(0xFFE11D48)
      GameType.TIC_TAC_TOE -> Color(0xFF38BDF8) to Color(0xFF0284C7)
      GameType.CONNECT_FOUR -> Color(0xFFFBBF24) to Color(0xFFD97706)
      GameType.SNAKES_LADDERS -> Color(0xFF34D399) to Color(0xFF059669)
      GameType.GUESS_NUMBER -> Color(0xFFA78BFA) to Color(0xFF7C3AED)
      GameType.ROCK_PAPER_SCISSORS -> Color(0xFFF472B6) to Color(0xFFDB2777)
    }

  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(24.dp),
    color = Color.Transparent,
    border =
      BorderStroke(
        1.dp,
        Brush.linearGradient(
          listOf(accent.copy(alpha = 0.55f), Color.White.copy(alpha = 0.10f), gradEnd.copy(alpha = 0.25f))
        ),
      ),
    modifier = modifier.testTag("game_card_${gameType.id}"),
  ) {
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(
            Brush.verticalGradient(
              listOf(Color(0xFF172136), Color(0xFF101829), Color(0xFF0B111E))
            )
          )
    ) {
      // Ambient spotlight behind artwork + subtle bottom corner tint
      Canvas(modifier = Modifier.matchParentSize()) {
        drawCircle(
          brush = Brush.radialGradient(
            listOf(accent.copy(alpha = 0.26f), Color.Transparent),
            center = Offset(size.width * 0.5f, size.height * 0.44f),
            radius = size.width * 0.52f,
          ),
          center = Offset(size.width * 0.5f, size.height * 0.44f),
          radius = size.width * 0.52f,
        )
        drawCircle(
          brush = Brush.radialGradient(
            listOf(gradEnd.copy(alpha = 0.14f), Color.Transparent),
            center = Offset(size.width * 0.12f, size.height * 0.92f),
            radius = size.width * 0.36f,
          ),
          center = Offset(size.width * 0.12f, size.height * 0.92f),
          radius = size.width * 0.36f,
        )
      }

      Column(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        // Top bar: player count badge + compact play button
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Surface(
            shape = RoundedCornerShape(50),
            color = accent.copy(alpha = 0.16f),
            border = BorderStroke(0.6.dp, accent.copy(alpha = 0.35f)),
          ) {
            Text(
              text = gameType.playersRangeFa,
              style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
              color = accent,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            )
          }

          Box(
            modifier =
              Modifier.size(30.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(accent, gradEnd)))
                .border(0.8.dp, Color.White.copy(alpha = 0.32f), CircleShape),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              Icons.Rounded.PlayArrow,
              contentDescription = gameType.titleFa,
              tint = Color.White,
              modifier = Modifier.size(18.dp),
            )
          }
        }

        // Center hero artwork
        Box(
          modifier =
            Modifier.weight(1f)
              .fillMaxWidth()
              .padding(vertical = 6.dp),
          contentAlignment = Alignment.Center,
        ) {
          Box(
            modifier =
              Modifier.size(88.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF0A101D).copy(alpha = 0.72f))
                .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(22.dp))
                .padding(4.dp),
            contentAlignment = Alignment.Center,
          ) {
            GameMiniBoardArtwork(gameType = gameType, accent = accent, modifier = Modifier.fillMaxSize())
          }
        }

        // Bottom title + subtitle
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
          Text(
            text = gameType.titleFa,
            style = MaterialTheme.typography.titleMedium.copy(fontSize = 16.sp),
            color = Color.White,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = gameType.subtitleFa,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
            color = Color(0xFF94A3B8),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }
  }
}

@Composable
private fun GameMiniBoardArtwork(
  gameType: GameType,
  accent: Color,
  modifier: Modifier = Modifier,
) {
  Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height
    drawRoundRect(
      brush = Brush.linearGradient(listOf(Color(0xFF19243D), Color(0xFF0A101D))),
      cornerRadius = CornerRadius(24f, 24f),
    )
    drawRoundRect(
      brush = Brush.linearGradient(listOf(accent.copy(alpha = 0.55f), Color.White.copy(alpha = 0.12f))),
      cornerRadius = CornerRadius(24f, 24f),
      style = Stroke(width = 2.2f),
    )
    when (gameType) {
      GameType.LUDO -> {
        val pad = w * 0.11f
        val box = w * 0.31f
        // Cross track lines
        drawRoundRect(Color.White.copy(alpha = 0.08f), Offset(w * 0.42f, pad), Size(w * 0.16f, h - 2 * pad), CornerRadius(6f, 6f))
        drawRoundRect(Color.White.copy(alpha = 0.08f), Offset(pad, h * 0.42f), Size(w - 2 * pad, h * 0.16f), CornerRadius(6f, 6f))
        // 4 quadrant bases
        drawRoundRect(PlayerRed.copy(alpha = 0.30f), Offset(pad, pad), Size(box, box), CornerRadius(12f, 12f))
        drawRoundRect(PlayerRed.copy(alpha = 0.65f), Offset(pad, pad), Size(box, box), CornerRadius(12f, 12f), style = Stroke(2f))
        drawRoundRect(PlayerGreen.copy(alpha = 0.30f), Offset(w - pad - box, pad), Size(box, box), CornerRadius(12f, 12f))
        drawRoundRect(PlayerGreen.copy(alpha = 0.65f), Offset(w - pad - box, pad), Size(box, box), CornerRadius(12f, 12f), style = Stroke(2f))
        drawRoundRect(PlayerBlue.copy(alpha = 0.30f), Offset(pad, h - pad - box), Size(box, box), CornerRadius(12f, 12f))
        drawRoundRect(PlayerBlue.copy(alpha = 0.65f), Offset(pad, h - pad - box), Size(box, box), CornerRadius(12f, 12f), style = Stroke(2f))
        drawRoundRect(PlayerYellow.copy(alpha = 0.30f), Offset(w - pad - box, h - pad - box), Size(box, box), CornerRadius(12f, 12f))
        drawRoundRect(PlayerYellow.copy(alpha = 0.65f), Offset(w - pad - box, h - pad - box), Size(box, box), CornerRadius(12f, 12f), style = Stroke(2f))
        // Glossy tokens
        val r = w * 0.095f
        drawGlossyToken(Offset(pad + box * 0.5f, pad + box * 0.5f), r, PlayerRed)
        drawGlossyToken(Offset(w - pad - box * 0.5f, pad + box * 0.5f), r, PlayerGreen)
        drawGlossyToken(Offset(pad + box * 0.5f, h - pad - box * 0.5f), r, PlayerBlue)
        drawGlossyToken(Offset(w - pad - box * 0.5f, h - pad - box * 0.5f), r, PlayerYellow)
        // Center golden home diamond
        val cPath = Path().apply {
          moveTo(w * 0.5f, h * 0.39f)
          lineTo(w * 0.61f, h * 0.5f)
          lineTo(w * 0.5f, h * 0.61f)
          lineTo(w * 0.39f, h * 0.5f)
          close()
        }
        drawPath(cPath, CyberGold)
      }
      GameType.TIC_TAC_TOE -> {
        val m = w * 0.14f
        val inner = w - 2 * m
        val step = inner / 3f
        // Glowing grid
        for (i in 1..2) {
          drawLine(Color.White.copy(alpha = 0.22f), Offset(m + step * i, m), Offset(m + step * i, h - m), 3f, StrokeCap.Round)
          drawLine(Color.White.copy(alpha = 0.22f), Offset(m, m + step * i), Offset(w - m, m + step * i), 3f, StrokeCap.Round)
        }
        fun drawX(cx: Float, cy: Float, r: Float) {
          drawLine(NeonCyan.copy(alpha = 0.35f), Offset(cx - r, cy - r), Offset(cx + r, cy + r), 11f, StrokeCap.Round)
          drawLine(NeonCyan, Offset(cx - r, cy - r), Offset(cx + r, cy + r), 5f, StrokeCap.Round)
          drawLine(NeonCyan.copy(alpha = 0.35f), Offset(cx + r, cy - r), Offset(cx - r, cy + r), 11f, StrokeCap.Round)
          drawLine(NeonCyan, Offset(cx + r, cy - r), Offset(cx - r, cy + r), 5f, StrokeCap.Round)
        }
        fun drawO(cx: Float, cy: Float, r: Float) {
          drawCircle(CrimsonMagenta.copy(alpha = 0.32f), radius = r, center = Offset(cx, cy), style = Stroke(10f))
          drawCircle(CrimsonMagenta, radius = r, center = Offset(cx, cy), style = Stroke(4.5f))
        }
        val xr = step * 0.28f
        drawX(m + step * 0.5f, m + step * 0.5f, xr)
        drawX(m + step * 1.5f, m + step * 1.5f, xr)
        drawX(m + step * 2.5f, m + step * 2.5f, xr)
        drawO(m + step * 2.5f, m + step * 0.5f, step * 0.30f)
        drawO(m + step * 0.5f, m + step * 2.5f, step * 0.30f)
        // Winning diagonal glow beam
        drawLine(NeonCyan.copy(alpha = 0.45f), Offset(m + step * 0.25f, m + step * 0.25f), Offset(w - m - step * 0.25f, h - m - step * 0.25f), 4f, StrokeCap.Round)
      }
      GameType.CONNECT_FOUR -> {
        val pad = w * 0.10f
        drawRoundRect(
          brush = Brush.verticalGradient(listOf(Color(0xFF1D4ED8), Color(0xFF1E3A8A))),
          topLeft = Offset(pad, pad * 1.15f),
          size = Size(w - 2 * pad, h - 2.3f * pad),
          cornerRadius = CornerRadius(14f, 14f),
        )
        val cols = 4
        val rows = 3
        val cw = (w - 2 * pad - 10f) / cols
        val ch = (h - 2.3f * pad - 10f) / rows
        for (r in 0 until rows) {
          for (c in 0 until cols) {
            val center = Offset(pad + 5f + (c + 0.5f) * cw, pad * 1.15f + 5f + (r + 0.5f) * ch)
            drawCircle(Color(0xFF080E1B), radius = cw * 0.36f, center = center)
            when {
              (r == 2 && c in 0..2) || (r == 1 && c == 1) ->
                drawGlossyToken(center, cw * 0.32f, PlayerRed)
              (r == 2 && c == 3) || (r == 1 && c in 2..3) || (r == 0 && c == 3) ->
                drawGlossyToken(center, cw * 0.32f, PlayerYellow)
            }
          }
        }
      }
      GameType.SNAKES_LADDERS -> {
        // Subtle board cells
        val m = w * 0.14f
        val cs = (w - 2 * m) / 3f
        for (r in 0..2) for (c in 0..2) {
          if ((r + c) % 2 == 0) {
            drawRoundRect(Color.White.copy(alpha = 0.05f), Offset(m + c * cs, m + r * cs), Size(cs - 2f, cs - 2f), CornerRadius(6f, 6f))
          }
        }
        // Golden ladder
        drawLine(CyberGold.copy(alpha = 0.35f), Offset(w * 0.24f, h * 0.82f), Offset(w * 0.42f, h * 0.18f), 9f, StrokeCap.Round)
        drawLine(CyberGold, Offset(w * 0.24f, h * 0.82f), Offset(w * 0.42f, h * 0.18f), 4.5f, StrokeCap.Round)
        drawLine(CyberGold.copy(alpha = 0.35f), Offset(w * 0.40f, h * 0.82f), Offset(w * 0.58f, h * 0.18f), 9f, StrokeCap.Round)
        drawLine(CyberGold, Offset(w * 0.40f, h * 0.82f), Offset(w * 0.58f, h * 0.18f), 4.5f, StrokeCap.Round)
        for (t in listOf(0.24f, 0.48f, 0.72f)) {
          val lx = w * (0.24f + 0.18f * t)
          val ly = h * (0.82f - 0.64f * t)
          drawLine(Color(0xFFFDE68A), Offset(lx, ly), Offset(lx + w * 0.16f, ly), 3.8f, StrokeCap.Round)
        }
        // Cute glowing snake
        val snakePath =
          Path().apply {
            moveTo(w * 0.72f, h * 0.24f)
            quadraticTo(w * 0.90f, h * 0.42f, w * 0.67f, h * 0.57f)
            quadraticTo(w * 0.53f, h * 0.70f, w * 0.77f, h * 0.82f)
          }
        drawPath(snakePath, CrimsonMagenta.copy(alpha = 0.35f), style = Stroke(13f, cap = StrokeCap.Round))
        drawPath(snakePath, CrimsonMagenta, style = Stroke(7f, cap = StrokeCap.Round))
        drawCircle(CrimsonMagenta, radius = w * 0.105f, center = Offset(w * 0.72f, h * 0.24f))
        drawCircle(Color.White, radius = w * 0.030f, center = Offset(w * 0.685f, h * 0.22f))
        drawCircle(Color.White, radius = w * 0.030f, center = Offset(w * 0.755f, h * 0.22f))
        drawCircle(Color(0xFF0A101D), radius = w * 0.014f, center = Offset(w * 0.685f, h * 0.22f))
        drawCircle(Color(0xFF0A101D), radius = w * 0.014f, center = Offset(w * 0.755f, h * 0.22f))
      }
      GameType.ROCK_PAPER_SCISSORS -> {
        // 3 mini arcade badges: Rock (gold), Paper (cyan), Scissors (magenta)
        // Rock
        val rCenter = Offset(w * 0.29f, h * 0.65f)
        drawCircle(CyberGold.copy(alpha = 0.25f), radius = w * 0.19f, center = rCenter)
        drawCircle(CyberGold, radius = w * 0.145f, center = rCenter)
        drawCircle(Color.White.copy(alpha = 0.45f), radius = w * 0.045f, center = Offset(rCenter.x - w * 0.04f, rCenter.y - w * 0.04f))
        // Paper
        val pTopLeft = Offset(w * 0.38f, h * 0.16f)
        val pSize = Size(w * 0.25f, h * 0.31f)
        drawRoundRect(NeonCyan.copy(alpha = 0.25f), Offset(pTopLeft.x - 3f, pTopLeft.y - 3f), Size(pSize.width + 6f, pSize.height + 6f), CornerRadius(10f, 10f))
        drawRoundRect(NeonCyan, pTopLeft, pSize, CornerRadius(8f, 8f))
        drawLine(Color(0xFF0A101D), Offset(pTopLeft.x + 7f, pTopLeft.y + pSize.height * 0.38f), Offset(pTopLeft.x + pSize.width - 7f, pTopLeft.y + pSize.height * 0.38f), 3f, StrokeCap.Round)
        drawLine(Color(0xFF0A101D), Offset(pTopLeft.x + 7f, pTopLeft.y + pSize.height * 0.62f), Offset(pTopLeft.x + pSize.width - 10f, pTopLeft.y + pSize.height * 0.62f), 3f, StrokeCap.Round)
        // Scissors
        drawCircle(CrimsonMagenta.copy(alpha = 0.22f), radius = w * 0.19f, center = Offset(w * 0.72f, h * 0.65f))
        drawLine(CrimsonMagenta, Offset(w * 0.60f, h * 0.74f), Offset(w * 0.84f, h * 0.52f), 5.5f, StrokeCap.Round)
        drawLine(CrimsonMagenta, Offset(w * 0.84f, h * 0.74f), Offset(w * 0.60f, h * 0.52f), 5.5f, StrokeCap.Round)
        drawCircle(CrimsonMagenta, radius = w * 0.055f, center = Offset(w * 0.61f, h * 0.76f), style = Stroke(3.5f))
        drawCircle(CrimsonMagenta, radius = w * 0.055f, center = Offset(w * 0.83f, h * 0.76f), style = Stroke(3.5f))
      }
      GameType.GUESS_NUMBER -> {
        val m = w * 0.14f
        val cols = 3
        val rows = 3
        val cw = (w - 2 * m) / cols
        val ch = (h - 2 * m) / rows
        for (r in 0 until rows) for (c in 0 until cols) {
          val hot = r == 1 && c == 1
          val tl = Offset(m + c * cw + 3f, m + r * ch + 3f)
          val sz = Size(cw - 6f, ch - 6f)
          if (hot) {
            drawRoundRect(CyberGold.copy(alpha = 0.35f), Offset(tl.x - 3f, tl.y - 3f), Size(sz.width + 6f, sz.height + 6f), CornerRadius(12f, 12f))
            drawRoundRect(Brush.linearGradient(listOf(Color(0xFFFDE047), CyberGold)), tl, sz, CornerRadius(10f, 10f))
          } else {
            drawRoundRect(VioletPulse.copy(alpha = 0.32f), tl, sz, CornerRadius(10f, 10f))
            drawRoundRect(VioletPulse.copy(alpha = 0.55f), tl, sz, CornerRadius(10f, 10f), style = Stroke(1.5f))
          }
        }
        // Crisp '?' in center tile
        val qPath = Path().apply {
          moveTo(w * 0.44f, h * 0.43f)
          quadraticTo(w * 0.50f, h * 0.36f, w * 0.56f, h * 0.42f)
          quadraticTo(w * 0.58f, h * 0.47f, w * 0.50f, h * 0.51f)
          lineTo(w * 0.50f, h * 0.54f)
        }
        drawPath(qPath, Color(0xFF0A101D), style = Stroke(4.5f, cap = StrokeCap.Round))
        drawCircle(Color(0xFF0A101D), radius = w * 0.025f, center = Offset(w * 0.50f, h * 0.595f))
      }
    }
  }
}
