package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import com.example.ui.theme.TextMuted
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.CPanelConfig
import com.example.data.GameType
import com.example.data.UserAccount
import com.example.ui.components.AvatarBadge
import com.example.ui.components.BaziIcons
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.appear
import com.example.ui.components.ServerStatusPill
import com.example.ui.components.auroraGamingBackdrop
import com.example.ui.components.drawGlossyToken
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlayerBlue
import com.example.ui.theme.PlayerGreen
import com.example.ui.theme.PlayerRed
import com.example.ui.theme.PlayerYellow
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPulse
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.graphics.graphicsLayer
import com.example.ui.components.fadeSlideIn
import com.example.ui.components.toFaDigits

@Composable
fun HomeScreen(
  currentUser: UserAccount?,
  cPanelConfig: CPanelConfig,
  onSelectGame: (GameType) -> Unit,
  onQuickJoinRoom: (String, GameType) -> Unit,
  onOpenProfile: () -> Unit,
  onOpenEmulator: () -> Unit = {},
  avatar: androidx.compose.ui.graphics.ImageBitmap? = null,
  modifier: Modifier = Modifier,
) {
  var quickCode by remember { mutableStateOf("") }

  LazyColumn(
    modifier = modifier.fillMaxSize().auroraGamingBackdrop(NeonCyan, VioletPulse),
    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    // 1. Sleek compact player bar
    item {
      val score = currentUser?.totalScore ?: 0
      val xpProgress = (score % 150) / 150f
      var xpGoal by remember { mutableFloatStateOf(0.08f) }
      LaunchedEffect(xpProgress) { xpGoal = xpProgress.coerceIn(0.08f, 1f) }
      val xpAnim by animateFloatAsState(xpGoal, tween(900, easing = FastOutSlowInEasing), label = "xp_fill")

      Row(
        modifier =
          Modifier.fillMaxWidth()
            .widthIn(max = 680.dp)
            .padding(horizontal = 2.dp, vertical = 2.dp)
            .fadeSlideIn(0),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          modifier =
            Modifier.weight(1f)
              .clip(RoundedCornerShape(14.dp))
              .clickable(onClick = onOpenProfile)
              .padding(vertical = 2.dp)
              .testTag("home_profile_chip"),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Box(
            modifier =
              Modifier.size(46.dp)
                .clip(CircleShape)
                .border(1.5.dp, Brush.linearGradient(listOf(NeonCyan, VioletPulse)), CircleShape)
                .padding(2.dp),
            contentAlignment = Alignment.Center,
          ) {
            AvatarBadge(
              name = currentUser?.displayName ?: "مهمان",
              colorIndex = currentUser?.avatarColorIndex ?: 0,
              size = 42.dp,
              image = avatar,
            )
          }
          Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              Text(
                text = currentUser?.displayName ?: "بازیکن مهمان • ورود",
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = NeonCyan.copy(alpha = 0.14f),
                border = BorderStroke(0.6.dp, NeonCyan.copy(alpha = 0.35f)),
              ) {
                Text(
                  text = "سطح ${(currentUser?.level ?: 1).toFaDigits()}",
                  style = MaterialTheme.typography.labelSmall,
                  color = NeonCyan,
                  fontWeight = FontWeight.ExtraBold,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp),
                )
              }
            }
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Box(
                modifier =
                  Modifier.weight(1f)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.08f))
              ) {
                Box(
                  modifier =
                    Modifier.fillMaxWidth(xpAnim)
                      .height(4.dp)
                      .clip(CircleShape)
                      .background(Brush.horizontalGradient(listOf(NeonCyan, VioletPulse)))
                )
              }
              Text(
                text = "${(score % 150).toFaDigits()}/۱۵۰ XP",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
              )
            }
          }
        }
        Spacer(Modifier.width(8.dp))
        ServerStatusPill(isConnected = cPanelConfig.isConnected)
      }
    }

    // 2. Unified modern arena hero + stats card
    item {
      val score = currentUser?.totalScore ?: 0
      Surface(
        modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp).fadeSlideIn(1),
        shape = RoundedCornerShape(22.dp),
        color = Color.Transparent,
        border = BorderStroke(
          1.dp,
          Brush.linearGradient(listOf(NeonCyan.copy(alpha = 0.36f), VioletPulse.copy(alpha = 0.28f))),
        ),
      ) {
        Box(
          modifier =
            Modifier.fillMaxWidth()
              .background(
                Brush.linearGradient(
                  listOf(Color(0xFF0E182E), Color(0xFF131530), Color(0xFF0B1224))
                )
              )
        ) {
          Canvas(modifier = Modifier.matchParentSize()) {
            drawCircle(
              brush = Brush.radialGradient(
                listOf(NeonCyan.copy(alpha = 0.18f), Color.Transparent),
                center = Offset(size.width * 0.1f, size.height * 0.15f),
                radius = size.width * 0.45f,
              ),
              center = Offset(size.width * 0.1f, size.height * 0.15f),
              radius = size.width * 0.45f,
            )
            drawCircle(
              brush = Brush.radialGradient(
                listOf(VioletPulse.copy(alpha = 0.22f), Color.Transparent),
                center = Offset(size.width * 0.9f, size.height * 0.85f),
                radius = size.width * 0.48f,
              ),
              center = Offset(size.width * 0.9f, size.height * 0.85f),
              radius = size.width * 0.48f,
            )
          }

          Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Surface(
                shape = RoundedCornerShape(50),
                color = CyberGold.copy(alpha = 0.14f),
                border = BorderStroke(0.8.dp, CyberGold.copy(alpha = 0.45f)),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                  Icon(BaziIcons.Crown, contentDescription = null, tint = CyberGold, modifier = Modifier.size(12.dp))
                  Text(
                    "آرنا رقابت و سرگرمی",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberGold,
                    fontWeight = FontWeight.Bold,
                  )
                }
              }
              Text(
                text = "${score.toFaDigits()} امتیاز  •  ${(currentUser?.wins ?: 0).toFaDigits()} برد",
                style = MaterialTheme.typography.labelSmall,
                color = NeonCyan,
                fontWeight = FontWeight.Bold,
              )
            }

            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
              Text(
                text = "کلاب بازی‌های آنلاین Bazirox",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = "با دوستانت اتاق بساز، چت بزن و قهرمان جدول شو!",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Button(
                onClick = { onSelectGame(GameType.LUDO) },
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                modifier = Modifier.height(38.dp).testTag("hero_play_ludo_button"),
              ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = ObsidianBg, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(4.dp))
                Text("شروع منچ", color = ObsidianBg, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.labelLarge)
              }
              OutlinedButton(
                onClick = { onSelectGame(GameType.TIC_TAC_TOE) },
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.22f)),
                colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White.copy(alpha = 0.06f)),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                modifier = Modifier.height(38.dp),
              ) {
                Text("دوز سریع", color = TextPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
              }
            }

            // Unified stats bar integrated into the card
            Surface(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(13.dp),
              color = Color(0x66060B16),
              border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.06f)),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                HomeStatChip(score.toFaDigits(), "امتیاز", CyberGold, Modifier.weight(1f))
                Box(Modifier.width(0.8.dp).height(22.dp).background(Color.White.copy(alpha = 0.08f)))
                HomeStatChip((currentUser?.wins ?: 0).toFaDigits(), "برد", CrimsonMagenta, Modifier.weight(1f))
                Box(Modifier.width(0.8.dp).height(22.dp).background(Color.White.copy(alpha = 0.08f)))
                HomeStatChip((currentUser?.gamesPlayed ?: 0).toFaDigits(), "بازی", NeonCyan, Modifier.weight(1f))
                Box(Modifier.width(0.8.dp).height(22.dp).background(Color.White.copy(alpha = 0.08f)))
                HomeStatChip("${(currentUser?.winRatePercent ?: 0).toFaDigits()}٪", "درصد برد", ElectricEmerald, Modifier.weight(1f))
              }
            }
          }
        }
      }
    }

    // 3. Slim quick-join bar
    item {
      GlassGradientCard(
        modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp).fadeSlideIn(2),
        accentColor = VioletPulse,
        cornerRadius = 18.dp,
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Box(
            modifier =
              Modifier.size(36.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(
                  Brush.linearGradient(listOf(VioletPulse.copy(alpha = 0.4f), NeonCyan.copy(alpha = 0.25f)))
                ),
            contentAlignment = Alignment.Center,
          ) {
            Icon(BaziIcons.Groups, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
          }
          Box(
            modifier =
              Modifier.weight(1f)
                .height(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x880B1020))
                .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.CenterStart,
          ) {
            if (quickCode.isEmpty()) {
              Text("کد اتاق دوستت", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            }
            BasicTextField(
              value = quickCode,
              onValueChange = { quickCode = it.uppercase().take(16) },
              singleLine = true,
              keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Characters,
                keyboardType = androidx.compose.ui.text.input.KeyboardType.Ascii,
                imeAction = androidx.compose.ui.text.input.ImeAction.Go,
              ),
              keyboardActions = androidx.compose.foundation.text.KeyboardActions(onGo = {
                if (quickCode.isNotBlank()) onQuickJoinRoom(quickCode, GameType.LUDO)
              }),
              textStyle = MaterialTheme.typography.bodyMedium.copy(
                color = TextPrimary,
                textDirection = androidx.compose.ui.text.style.TextDirection.Ltr,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
              ),
              cursorBrush = SolidColor(NeonCyan),
              modifier = Modifier.fillMaxWidth().testTag("home_quick_room_input"),
            )
          }
          Button(
            onClick = { if (quickCode.isNotBlank()) onQuickJoinRoom(quickCode, GameType.LUDO) },
            enabled = quickCode.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = VioletPulse),
            shape = RoundedCornerShape(12.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            modifier = Modifier.height(48.dp).testTag("home_quick_join_button"),
          ) {
            Text("ورود", fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // 4a. Console games: title + emulator entry banner
    item {
      HomeSectionTitle(title = "بازی های کنسول", trailing = "Sega · Neo Geo", trailingTint = CyberGold)
    }
    item {
      Image(
        painter = painterResource(id = R.drawable.img_emulator_banner),
        contentDescription = "بخش امولاتور",
        contentScale = ContentScale.FillWidth,
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 680.dp)
          .clip(RoundedCornerShape(18.dp))
          .clickable(
            onClickLabel = "ورود به بخش امولاتور",
            role = androidx.compose.ui.semantics.Role.Button,
            onClick = onOpenEmulator,
          )
          .testTag("home_emulator_banner"),
      )
    }

    // 4b. Regular games: title
    item {
      HomeSectionTitle(title = "بازی های عادی", trailing = "آنلاین و آفلاین", trailingTint = ElectricEmerald, showGlobe = true)
    }

    // 5. Compact 2x2 game cards
    item {
      BoxWithConstraints(modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp)) {
        val isWide = maxWidth >= 520.dp
        val games = GameType.entries
        if (isWide) {
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            games.forEach { g ->
              GameArcadeCard(gameType = g, modifier = Modifier.weight(1f).appear(games.indexOf(g) * 70), onClick = { onSelectGame(g) })
            }
          }
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            games.chunked(2).forEach { pair ->
              Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { g ->
                  GameArcadeCard(gameType = g, modifier = Modifier.weight(1f).appear(games.indexOf(g) * 70), onClick = { onSelectGame(g) })
                }
              }
            }
          }
        }
      }
    }

    item { Spacer(Modifier.height(8.dp)) }
  }
}

@Composable
private fun HomeSectionTitle(title: String, trailing: String, trailingTint: Color, showGlobe: Boolean = false) {
  Row(
    modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp).padding(top = 2.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
      Icon(BaziIcons.SportsEsports, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(18.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = TextPrimary,
        fontWeight = FontWeight.Bold,
      )
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
      if (showGlobe) Icon(BaziIcons.PublicGlobe, contentDescription = null, tint = trailingTint, modifier = Modifier.size(14.dp))
      Text(trailing, style = MaterialTheme.typography.labelSmall, color = trailingTint)
    }
  }
}

@Composable
private fun HomeStatChip(value: String, label: String, tint: Color, modifier: Modifier = Modifier) {
  Column(
    modifier = modifier.padding(horizontal = 4.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(1.dp),
  ) {
    Text(value, style = MaterialTheme.typography.titleSmall, color = tint, fontWeight = FontWeight.ExtraBold, maxLines = 1)
    Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary, maxLines = 1)
  }
}

@Composable
private fun GameArcadeCard(
  gameType: GameType,
  modifier: Modifier = Modifier,
  onClick: () -> Unit,
) {
  val accent =
    when (gameType) {
      GameType.LUDO -> PlayerRed
      GameType.TIC_TAC_TOE -> NeonCyan
      GameType.CONNECT_FOUR -> CyberGold
      GameType.SNAKES_LADDERS -> ElectricEmerald
      GameType.GUESS_NUMBER -> VioletPulse
      GameType.ROCK_PAPER_SCISSORS -> CrimsonMagenta
    }

  GlassGradientCard(
    accentColor = accent,
    cornerRadius = 20.dp,
    onClick = onClick,
    modifier = modifier.height(122.dp).testTag("game_card_${gameType.id}"),
  ) {
    Column(
      modifier = Modifier.fillMaxSize().padding(12.dp),
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        GameMiniBoardArtwork(gameType = gameType, accent = accent, modifier = Modifier.size(50.dp))
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
          Text(
            text = gameType.titleFa,
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
          )
          Text(
            text = gameType.subtitleFa,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = accent.copy(alpha = 0.2f),
          border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
        ) {
          Text(
            text = gameType.playersRangeFa,
            style = MaterialTheme.typography.labelSmall,
            color = accent,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
          )
        }
        Box(
          modifier = Modifier.size(30.dp).clip(CircleShape).background(accent),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            Icons.Rounded.PlayArrow,
            contentDescription = gameType.titleFa,
            tint = ObsidianBg,
            modifier = Modifier.size(19.dp),
          )
        }
      }
    }
  }
}

@Composable
private fun GameMiniBoardArtwork(
  gameType: GameType,
  accent: Color,
  modifier: Modifier = Modifier,
) {
  Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height
    drawRoundRect(
      brush = Brush.linearGradient(listOf(Color(0xFF162036), Color(0xFF0A101D))),
      cornerRadius = CornerRadius(18f, 18f),
    )
    drawRoundRect(
      color = accent.copy(alpha = 0.45f),
      cornerRadius = CornerRadius(18f, 18f),
      style = Stroke(width = 2.5f),
    )
    when (gameType) {
      GameType.LUDO -> {
        val pad = w * 0.14f
        val box = w * 0.30f
        drawRoundRect(PlayerRed.copy(alpha = 0.28f), Offset(pad, pad), Size(box, box), CornerRadius(7f, 7f))
        drawRoundRect(PlayerGreen.copy(alpha = 0.28f), Offset(w - pad - box, pad), Size(box, box), CornerRadius(7f, 7f))
        drawRoundRect(PlayerBlue.copy(alpha = 0.28f), Offset(pad, h - pad - box), Size(box, box), CornerRadius(7f, 7f))
        drawRoundRect(PlayerYellow.copy(alpha = 0.28f), Offset(w - pad - box, h - pad - box), Size(box, box), CornerRadius(7f, 7f))
        val r = w * 0.095f
        drawGlossyToken(Offset(pad + box * 0.5f, pad + box * 0.5f), r, PlayerRed)
        drawGlossyToken(Offset(w - pad - box * 0.5f, pad + box * 0.5f), r, PlayerGreen)
        drawGlossyToken(Offset(pad + box * 0.5f, h - pad - box * 0.5f), r, PlayerBlue)
        drawGlossyToken(Offset(w - pad - box * 0.5f, h - pad - box * 0.5f), r, PlayerYellow)
        drawCircle(CyberGold.copy(alpha = 0.85f), radius = w * 0.08f, center = Offset(w * 0.5f, h * 0.5f))
      }
      GameType.TIC_TAC_TOE -> {
        val step = w / 3f
        drawLine(NeonCyan.copy(alpha = 0.35f), Offset(step, 10f), Offset(step, h - 10f), 3f)
        drawLine(NeonCyan.copy(alpha = 0.35f), Offset(step * 2, 10f), Offset(step * 2, h - 10f), 3f)
        drawLine(NeonCyan.copy(alpha = 0.35f), Offset(10f, step), Offset(w - 10f, step), 3f)
        drawLine(NeonCyan.copy(alpha = 0.35f), Offset(10f, step * 2), Offset(w - 10f, step * 2), 3f)
        drawLine(NeonCyan.copy(alpha = 0.35f), Offset(13f, 13f), Offset(step - 6f, step - 6f), 10f, StrokeCap.Round)
        drawLine(NeonCyan, Offset(13f, 13f), Offset(step - 6f, step - 6f), 4.5f, StrokeCap.Round)
        drawLine(NeonCyan.copy(alpha = 0.35f), Offset(step - 6f, 13f), Offset(13f, step - 6f), 10f, StrokeCap.Round)
        drawLine(NeonCyan, Offset(step - 6f, 13f), Offset(13f, step - 6f), 4.5f, StrokeCap.Round)
        drawCircle(CrimsonMagenta.copy(alpha = 0.35f), radius = step * 0.31f, center = Offset(w * 0.5f, h * 0.5f), style = Stroke(9f))
        drawCircle(CrimsonMagenta, radius = step * 0.31f, center = Offset(w * 0.5f, h * 0.5f), style = Stroke(4.5f))
      }
      GameType.CONNECT_FOUR -> {
        val cols = 4
        val rows = 3
        val cw = (w - 14f) / cols
        val ch = (h - 14f) / rows
        for (r in 0 until rows) {
          for (c in 0 until cols) {
            val center = Offset(7f + (c + 0.5f) * cw, 7f + (r + 0.5f) * ch)
            drawCircle(ObsidianBg, radius = cw * 0.34f, center = center)
            when {
              (r == 2 && c in 0..1) || (r == 1 && c == 1) ->
                drawGlossyToken(center, cw * 0.32f, PlayerRed)
              (r == 2 && c in 2..3) || (r == 1 && c == 2) ->
                drawGlossyToken(center, cw * 0.32f, PlayerYellow)
            }
          }
        }
      }
      GameType.SNAKES_LADDERS -> {
        drawLine(ElectricEmerald, Offset(w * 0.24f, h * 0.82f), Offset(w * 0.44f, h * 0.18f), 5f, StrokeCap.Round)
        drawLine(ElectricEmerald, Offset(w * 0.40f, h * 0.82f), Offset(w * 0.60f, h * 0.18f), 5f, StrokeCap.Round)
        for (t in listOf(0.28f, 0.48f, 0.68f)) {
          val lx = w * (0.24f + 0.20f * t)
          val ly = h * (0.82f - 0.64f * t)
          drawLine(CyberGold, Offset(lx, ly), Offset(lx + w * 0.16f, ly), 3.5f, StrokeCap.Round)
        }
        val snakePath =
          Path().apply {
            moveTo(w * 0.72f, h * 0.24f)
            quadraticTo(w * 0.92f, h * 0.42f, w * 0.68f, h * 0.58f)
            quadraticTo(w * 0.54f, h * 0.70f, w * 0.78f, h * 0.82f)
          }
        drawPath(snakePath, CrimsonMagenta, style = Stroke(7f, cap = StrokeCap.Round))
        drawCircle(CrimsonMagenta, radius = w * 0.10f, center = Offset(w * 0.72f, h * 0.24f))
        drawCircle(Color.White, radius = w * 0.028f, center = Offset(w * 0.69f, h * 0.22f))
        drawCircle(Color.White, radius = w * 0.028f, center = Offset(w * 0.75f, h * 0.22f))
      }
      GameType.ROCK_PAPER_SCISSORS -> {
        val r = w * 0.17f
        drawCircle(CyberGold.copy(alpha = 0.9f), radius = r, center = Offset(w * 0.28f, h * 0.62f))
        drawRoundRect(
          NeonCyan.copy(alpha = 0.85f),
          topLeft = Offset(w * 0.40f, h * 0.18f),
          size = Size(w * 0.24f, h * 0.30f),
          cornerRadius = CornerRadius(8f, 8f),
        )
        drawLine(CrimsonMagenta, Offset(w * 0.62f, h * 0.82f), Offset(w * 0.86f, h * 0.48f), 6f, StrokeCap.Round)
        drawLine(CrimsonMagenta, Offset(w * 0.86f, h * 0.82f), Offset(w * 0.62f, h * 0.48f), 6f, StrokeCap.Round)
      }
      GameType.GUESS_NUMBER -> {
        val cols = 3
        val rows = 3
        val cw = (w - 20f) / cols
        val ch = (h - 20f) / rows
        for (r in 0 until rows) for (c in 0 until cols) {
          val hot = r == 1 && c == 1
          drawRoundRect(
            color = if (hot) CyberGold else VioletPulse.copy(alpha = 0.45f),
            topLeft = Offset(10f + c * cw + 4f, 10f + r * ch + 4f),
            size = Size(cw - 8f, ch - 8f),
            cornerRadius = CornerRadius(8f, 8f),
          )
        }
      }
    }
  }
}
