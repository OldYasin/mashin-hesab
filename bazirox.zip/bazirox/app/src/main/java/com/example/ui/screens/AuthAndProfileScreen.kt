package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Edit
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import kotlinx.coroutines.delay
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.VerticalDivider
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.CPanelConfig
import com.example.data.UserAccount
import com.example.ui.components.AvatarBadge
import com.example.ui.components.AvatarPalette
import com.example.ui.components.BaziIcons
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.auroraGamingBackdrop
import com.example.ui.components.toFaDigits
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPulse
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.graphicsLayer
import com.example.ui.components.fadeSlideIn
import com.example.ui.components.rememberCountUp

@Composable
fun AuthAndProfileScreen(
  currentUser: UserAccount?,
  cPanelConfig: CPanelConfig,
  authLoading: Boolean,
  authError: String?,
  onLogin: (String, String) -> Unit,
  onRegister: (String, String, String, Int) -> Unit,
  onLogout: () -> Unit,
  modifier: Modifier = Modifier,
  onChangePassword: (String, String, (String?) -> Unit) -> Unit = { _, _, _ -> },
  notificationsEnabled: Boolean = true,
  onToggleNotifications: (Boolean) -> Unit = {},
  avatar: ImageBitmap? = null,
  profileBusy: Boolean = false,
  profileMessage: String? = null,
  onPickAvatar: (Uri) -> Unit = {},
  onRemoveAvatar: () -> Unit = {},
  onChangeName: (String) -> Unit = {},
  onClearProfileMessage: () -> Unit = {},
  myBio: String = "",
  onSaveBio: (String) -> Unit = {},
) {
  Column(
    modifier =
      modifier.fillMaxSize()
        .background(Color(0xFF151E27))
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 14.dp, vertical = 10.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    if (currentUser == null) {
      AuthFormCard(
        authLoading = authLoading,
        authError = authError,
        onLogin = onLogin,
        onRegister = onRegister,
      )
    } else {
      ProfileDashboardCard(
        user = currentUser,
        cPanelConfig = cPanelConfig,
        onLogout = onLogout,
        onChangePassword = onChangePassword,
        avatar = avatar,
        busy = profileBusy,
        message = profileMessage,
        onPickAvatar = onPickAvatar,
        onRemoveAvatar = onRemoveAvatar,
        onChangeName = onChangeName,
        onClearMessage = onClearProfileMessage,
        myBio = myBio,
        onSaveBio = onSaveBio,
      )
      TelegramSettingsSection(
        notificationsEnabled = notificationsEnabled,
        onToggleNotifications = onToggleNotifications,
        onLogout = onLogout,
      )
    }

    Spacer(Modifier.height(14.dp))
  }
}

@Composable
private fun AuthFormCard(
  authLoading: Boolean,
  authError: String?,
  onLogin: (String, String) -> Unit,
  onRegister: (String, String, String, Int) -> Unit,
) {
  var isRegisterMode by remember { mutableStateOf(false) }
  var username by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var displayName by remember { mutableStateOf("") }
  var selectedColor by remember { mutableIntStateOf(0) }
  var showPassword by remember { mutableStateOf(false) }
  val usernameOk = Regex("^[\\p{L}\\p{N}_.-]{3,32}\$").matches(username.trim())

  GlassGradientCard(
    modifier = Modifier.fillMaxWidth().widthIn(max = 560.dp).fadeSlideIn(0),
    accentColor = NeonCyan,
    cornerRadius = 24.dp,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        listOf(false to "ورود به حساب", true to "ثبت‌نام سریع").forEach { (reg, label) ->
          val active = isRegisterMode == reg
          Surface(
            onClick = { isRegisterMode = reg },
            modifier = Modifier.weight(1f).height(44.dp).testTag(if (reg) "auth_tab_register" else "auth_tab_login"),
            shape = RoundedCornerShape(12.dp),
            color = if (active) NeonCyan.copy(alpha = 0.2f) else ElevatedCard.copy(alpha = 0.6f),
            border = BorderStroke(1.dp, if (active) NeonCyan else ElevatedCardStroke),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Text(
                label,
                style = MaterialTheme.typography.labelLarge,
                color = if (active) NeonCyan else TextSecondary,
              )
            }
          }
        }
      }

      Text(
        text = "بدون نیاز به شماره موبایل یا ایمیل — فقط نام کاربری و رمز عبور",
        style = MaterialTheme.typography.bodyMedium,
        color = TextSecondary,
      )

      val authFocus = LocalFocusManager.current
      OutlinedTextField(
        value = username,
        onValueChange = { username = it.take(32) },
        label = { Text("نام کاربری (Username)") },
        leadingIcon = { Icon(Icons.Rounded.Person, contentDescription = null, tint = NeonCyan) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(
          capitalization = KeyboardCapitalization.None,
          keyboardType = KeyboardType.Ascii,
          imeAction = ImeAction.Next,
        ),
        keyboardActions = KeyboardActions(onNext = { authFocus.moveFocus(FocusDirection.Down) }),
        isError = isRegisterMode && username.isNotBlank() && !usernameOk,
        supportingText =
          if (isRegisterMode) {
            { Text("حروف، عدد و _ . - (۳ تا ۳۲ کاراکتر)") }
          } else null,
        modifier = Modifier.fillMaxWidth().testTag("auth_username_input"),
        colors =
          OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonCyan,
            unfocusedBorderColor = Color.White.copy(alpha = 0.14f),
            focusedContainerColor = Color(0x990B1020),
            unfocusedContainerColor = Color(0x880B1020),
          ),
        shape = RoundedCornerShape(14.dp),
      )

      AnimatedVisibility(
        visible = isRegisterMode,
        enter = fadeIn(tween(220)) + expandVertically(tween(260)),
        exit = fadeOut(tween(150)) + shrinkVertically(tween(200)),
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        OutlinedTextField(
          value = displayName,
          onValueChange = { displayName = it.take(32) },
          label = { Text("نام نمایشی در بازی (اختیاری)") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
          keyboardActions = KeyboardActions(onNext = { authFocus.moveFocus(FocusDirection.Down) }),
          modifier = Modifier.fillMaxWidth().testTag("auth_displayname_input"),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = NeonCyan,
              unfocusedBorderColor = Color.White.copy(alpha = 0.14f),
              focusedContainerColor = Color(0x990B1020),
              unfocusedContainerColor = Color(0x880B1020),
            ),
          shape = RoundedCornerShape(14.dp),
        )

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Text("رنگ آواتار:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
          AvatarPalette.forEachIndexed { idx, col ->
            val sel = selectedColor == idx
            Box(
              modifier =
                Modifier.size(40.dp)
                  .clip(CircleShape)
                  .background(col)
                  .border(if (sel) 2.5.dp else 0.dp, TextPrimary, CircleShape)
                  .clickable { selectedColor = idx },
              contentAlignment = Alignment.Center,
            ) {
              if (sel) Icon(Icons.Rounded.Check, contentDescription = null, tint = ObsidianBg, modifier = Modifier.size(18.dp))
            }
          }
        }
        }
      }

      OutlinedTextField(
        value = password,
        onValueChange = { password = it },
        label = { Text("رمز عبور") },
        leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null, tint = NeonCyan) },
        trailingIcon = {
          IconButton(onClick = { showPassword = !showPassword }) {
            Icon(
              BaziIcons.Visibility,
              contentDescription = if (showPassword) "پنهان کردن رمز" else "نمایش رمز",
              tint = TextSecondary,
            )
          }
        },
        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
        singleLine = true,
        keyboardOptions = KeyboardOptions(
          capitalization = KeyboardCapitalization.None,
          keyboardType = KeyboardType.Password,
          imeAction = ImeAction.Done,
        ),
        keyboardActions = KeyboardActions(onDone = {
          authFocus.clearFocus()
          if (!authLoading && username.isNotBlank() && password.isNotBlank() && (!isRegisterMode || usernameOk)) {
            if (isRegisterMode) onRegister(username, password, displayName, selectedColor)
            else onLogin(username, password)
          }
        }),
        modifier = Modifier.fillMaxWidth().testTag("auth_password_input"),
        colors =
          OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonCyan,
            unfocusedBorderColor = Color.White.copy(alpha = 0.14f),
            focusedContainerColor = Color(0x990B1020),
            unfocusedContainerColor = Color(0x880B1020),
          ),
        shape = RoundedCornerShape(14.dp),
      )

      val shake = remember { Animatable(0f) }
      LaunchedEffect(authError) {
        if (!authError.isNullOrBlank()) {
          repeat(3) {
            shake.animateTo(10f, tween(50))
            shake.animateTo(-10f, tween(50))
          }
          shake.animateTo(0f, tween(50))
        }
      }
      AnimatedVisibility(
        visible = !authError.isNullOrBlank(),
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
      ) {
        Text(
          text = authError.orEmpty(),
          style = MaterialTheme.typography.bodyMedium,
          color = CrimsonMagenta,
          modifier = Modifier.graphicsLayer { translationX = shake.value },
        )
      }

      Button(
        onClick = {
          if (isRegisterMode) onRegister(username, password, displayName, selectedColor)
          else onLogin(username, password)
        },
        enabled = !authLoading && username.isNotBlank() && password.isNotBlank() && (!isRegisterMode || usernameOk),
        modifier = Modifier.fillMaxWidth().height(52.dp).testTag("auth_submit_button"),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = NeonCyan,
            disabledContainerColor = Color(0xFF232E4D),
            disabledContentColor = TextSecondary,
          ),
        shape = RoundedCornerShape(14.dp),
      ) {
        if (authLoading) {
          CircularProgressIndicator(modifier = Modifier.size(22.dp), color = ObsidianBg, strokeWidth = 2.5.dp)
        } else {
          Text(
            text = if (isRegisterMode) "ساخت حساب و ورود" else "ورود به Bazirox",
            color = androidx.compose.material3.LocalContentColor.current,
            fontWeight = FontWeight.ExtraBold,
          )
        }
      }
    }
  }
}

@Composable
private fun ProfileDashboardCard(
  user: UserAccount,
  cPanelConfig: CPanelConfig,
  onLogout: () -> Unit,
  onChangePassword: (String, String, (String?) -> Unit) -> Unit,
  avatar: ImageBitmap?,
  busy: Boolean,
  message: String?,
  onPickAvatar: (Uri) -> Unit,
  onRemoveAvatar: () -> Unit,
  onChangeName: (String) -> Unit,
  onClearMessage: () -> Unit,
  myBio: String,
  onSaveBio: (String) -> Unit,
) {
  var showEdit by remember { mutableStateOf(false) }
  var showChangePassword by remember { mutableStateOf(false) }
  var menuOpen by remember { mutableStateOf(false) }
  val photoPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
      if (uri != null) onPickAvatar(uri)
    }
  LaunchedEffect(message) {
    if (message != null) {
      delay(3500)
      onClearMessage()
    }
  }

  if (showEdit) {
    EditProfileDialog(
      user = user,
      avatar = avatar,
      busy = busy,
      onPickPhoto = { photoPicker.launch("image/*") },
      onRemovePhoto = onRemoveAvatar,
      onSaveName = { onChangeName(it) },
      bio = myBio,
      onSaveBio = onSaveBio,
      onDismiss = { showEdit = false },
    )
  }

  if (showChangePassword) {
    ChangePasswordDialog(
      busy = busy,
      onSubmit = onChangePassword,
      onDismiss = { showChangePassword = false },
    )
  }

  Column(
    modifier = Modifier.fillMaxWidth().widthIn(max = 560.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    // Top bar: circular ⋮ menu (Telegram profile header)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.End,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box {
        Surface(
          onClick = { menuOpen = true },
          shape = CircleShape,
          color = Color(0xFF1E2936),
          modifier = Modifier.size(40.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Text("⋮", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          }
        }
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
          DropdownMenuItem(
            text = { Text("تنظیم عکس پروفایل") },
            onClick = { menuOpen = false; photoPicker.launch("image/*") },
          )
          DropdownMenuItem(
            text = { Text("ویرایش اطلاعات") },
            onClick = { menuOpen = false; showEdit = true },
          )
          DropdownMenuItem(
            text = { Text("تغییر رمز عبور") },
            onClick = { menuOpen = false; showChangePassword = true },
          )
          DropdownMenuItem(
            text = { Text("خروج از حساب کاربری", color = Color(0xFFF87171)) },
            onClick = { menuOpen = false; onLogout() },
          )
        }
      }
    }

    // Centered Avatar + Camera Badge + Name + Online Status
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Box(
        modifier = Modifier.size(102.dp).clickable { photoPicker.launch("image/*") }.testTag("profile_avatar"),
        contentAlignment = Alignment.Center,
      ) {
        AvatarBadge(name = user.displayName, colorIndex = user.avatarColorIndex, size = 96.dp, image = avatar)
        Box(
          modifier =
            Modifier.align(Alignment.BottomEnd)
              .padding(2.dp)
              .size(30.dp)
              .clip(CircleShape)
              .background(Color(0xFF4E8AD1))
              .border(2.5.dp, Color(0xFF151E27), CircleShape),
          contentAlignment = Alignment.Center,
        ) {
          Icon(BaziIcons.Photo, contentDescription = "تغییر عکس", tint = Color.White, modifier = Modifier.size(15.dp))
        }
      }
      Text(
        text = user.displayName,
        style = MaterialTheme.typography.titleLarge.copy(fontSize = 21.sp),
        color = Color.White,
        fontWeight = FontWeight.Bold,
      )
      Text(
        text = "آنلاین • سطح ${user.level.toFaDigits()}",
        style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
        color = Color(0xFF5EB5F7),
      )
    }

    // 3 Telegram-style Rounded Action Buttons: Set Photo | Edit Info | Change Password
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      TelegramProfileActionButton(
        icon = BaziIcons.Photo,
        label = "تنظیم عکس",
        onClick = { photoPicker.launch("image/*") },
        modifier = Modifier.weight(1f),
      )
      TelegramProfileActionButton(
        icon = Icons.Rounded.Edit,
        label = "ویرایش پروفایل",
        onClick = { showEdit = true },
        modifier = Modifier.weight(1f).testTag("edit_profile_button"),
      )
      TelegramProfileActionButton(
        icon = Icons.Rounded.Lock,
        label = "تغییر رمز",
        onClick = { showChangePassword = true },
        modifier = Modifier.weight(1f).testTag("change_password_button"),
      )
    }

    if (message != null) {
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF1C2631),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Text(
          text = message,
          style = MaterialTheme.typography.bodySmall,
          color = if (message.contains("اشتباه") || message.contains("ناموفق") || message.contains("خطا") || message.contains("باید") || message.contains("نمی")) CrimsonMagenta else ElectricEmerald,
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
        )
      }
    }

    // Telegram-style Info Card (Username + Bio)
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color(0xFF1C2631),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
          verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
          Text(
            text = "⁦@${user.username}⁩",
            style = MaterialTheme.typography.bodyLarge.copy(fontSize = 15.5.sp),
            color = Color.White,
          )
          Text(
            text = "نام کاربری",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.5.sp),
            color = Color(0xFF7D8B99),
          )
        }
        HorizontalDivider(thickness = 0.5.dp, color = Color.Black.copy(alpha = 0.28f))
        Column(
          modifier = Modifier.fillMaxWidth().clickable { showEdit = true }.padding(horizontal = 16.dp, vertical = 12.dp),
          verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
          Text(
            text = myBio.ifBlank { "بیوگرافی ثبت نشده است — برای افزودن کلیک کنید" },
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.5.sp),
            color = if (myBio.isBlank()) Color(0xFF7D8B99) else Color.White,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = "بیوگرافی",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.5.sp),
            color = Color(0xFF7D8B99),
          )
        }
      }
    }

    // Clean Telegram-style Stats Card
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color(0xFF1C2631),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        TelegramStatCell("امتیاز کل", rememberCountUp(user.totalScore).toFaDigits(), CyberGold, Modifier.weight(1f))
        VerticalDivider(modifier = Modifier.height(34.dp), thickness = 0.5.dp, color = Color.Black.copy(alpha = 0.3f))
        TelegramStatCell("پیروزی", rememberCountUp(user.wins).toFaDigits(), Color(0xFF4CAF50), Modifier.weight(1f))
        VerticalDivider(modifier = Modifier.height(34.dp), thickness = 0.5.dp, color = Color.Black.copy(alpha = 0.3f))
        TelegramStatCell("نرخ برد", "${rememberCountUp(user.winRatePercent).toFaDigits()}٪", Color(0xFF5EB5F7), Modifier.weight(1f))
      }
    }
  }
}

@Composable
private fun TelegramProfileActionButton(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(14.dp),
    color = Color(0xFF1E2936),
    modifier = modifier.height(64.dp),
  ) {
    Column(
      modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(21.dp))
      Spacer(Modifier.height(4.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.5.sp),
        color = Color.White,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center,
      )
    }
  }
}

@Composable
private fun TelegramStatCell(
  label: String,
  value: String,
  accent: Color,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier.padding(horizontal = 4.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(2.dp),
  ) {
    Text(value, style = MaterialTheme.typography.titleLarge.copy(fontSize = 19.sp), color = accent, fontWeight = FontWeight.Bold)
    Text(label, style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.5.sp), color = Color(0xFF7D8B99))
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChangePasswordDialog(
  busy: Boolean,
  onSubmit: (String, String, (String?) -> Unit) -> Unit,
  onDismiss: () -> Unit,
) {
  var oldPw by remember { mutableStateOf("") }
  var newPw by remember { mutableStateOf("") }
  var confirmPw by remember { mutableStateOf("") }
  var error by remember { mutableStateOf<String?>(null) }
  val fieldColors =
    OutlinedTextFieldDefaults.colors(
      focusedBorderColor = Color(0xFF4E8AD1),
      unfocusedBorderColor = Color.Transparent,
      focusedContainerColor = Color(0xFF1F2B38),
      unfocusedContainerColor = Color(0xFF1F2B38),
      focusedTextColor = Color.White,
      unfocusedTextColor = Color.White,
      focusedLabelColor = Color(0xFF5EB5F7),
      unfocusedLabelColor = Color(0xFF8B98A5),
      cursorColor = Color(0xFF5EB5F7),
    )
  val canSubmit = !busy && oldPw.isNotEmpty() && newPw.isNotEmpty() && confirmPw.isNotEmpty()

  ModalBottomSheet(
    onDismissRequest = { if (!busy) onDismiss() },
    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    containerColor = Color(0xFF151E27),
    contentColor = Color.White,
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    dragHandle = {
      Box(
        modifier =
          Modifier.padding(top = 12.dp, bottom = 6.dp)
            .width(40.dp)
            .height(4.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.2f))
      )
    },
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 26.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Text(
        text = "تغییر رمز عبور",
        style = MaterialTheme.typography.titleLarge,
        color = Color.White,
        fontWeight = FontWeight.Bold,
      )
      listOf(
          Triple("رمز فعلی", oldPw, { v: String -> oldPw = v; error = null }),
          Triple("رمز جدید", newPw, { v: String -> newPw = v; error = null }),
          Triple("تکرار رمز جدید", confirmPw, { v: String -> confirmPw = v; error = null }),
        )
        .forEach { (label, value, setter) ->
          OutlinedTextField(
            value = value,
            onValueChange = setter,
            singleLine = true,
            enabled = !busy,
            label = { Text(label) },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = fieldColors,
          )
        }
      if (error != null) {
        Text(error!!, style = MaterialTheme.typography.bodySmall, color = CrimsonMagenta)
      }
      Button(
        onClick = {
          when {
            newPw.length < 6 -> error = "رمز جدید باید حداقل ۶ کاراکتر باشد"
            newPw != confirmPw -> error = "تکرار رمز جدید با رمز جدید یکی نیست"
            else ->
              onSubmit(oldPw, newPw) { err ->
                if (err == null) onDismiss() else error = err
              }
          }
        },
        enabled = canSubmit,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4E8AD1), disabledContainerColor = Color(0xFF23303E)),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().height(48.dp),
      ) {
        if (busy) {
          CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
        } else {
          Text("ذخیره رمز جدید", color = Color.White, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditProfileDialog(
  user: UserAccount,
  avatar: ImageBitmap?,
  busy: Boolean,
  onPickPhoto: () -> Unit,
  onRemovePhoto: () -> Unit,
  onSaveName: (String) -> Unit,
  bio: String,
  onSaveBio: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  var name by remember { mutableStateOf(user.displayName) }
  var bioDraft by remember { mutableStateOf(bio) }
  val nameChanged = name.trim().isNotEmpty() && name.trim() != user.displayName
  val bioChanged = bioDraft.trim() != bio.trim()
  val changed = nameChanged || bioChanged
  val fieldColors =
    OutlinedTextFieldDefaults.colors(
      focusedBorderColor = Color(0xFF4E8AD1),
      unfocusedBorderColor = Color.Transparent,
      focusedContainerColor = Color(0xFF1F2B38),
      unfocusedContainerColor = Color(0xFF1F2B38),
      focusedTextColor = Color.White,
      unfocusedTextColor = Color.White,
      focusedLabelColor = Color(0xFF5EB5F7),
      unfocusedLabelColor = Color(0xFF8B98A5),
      cursorColor = Color(0xFF5EB5F7),
    )

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    containerColor = Color(0xFF151E27),
    contentColor = Color.White,
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    dragHandle = {
      Box(
        modifier =
          Modifier.padding(top = 12.dp, bottom = 6.dp)
            .width(40.dp)
            .height(4.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.2f))
      )
    },
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 26.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text("ویرایش پروفایل", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
        TextButton(onClick = onDismiss) { Text("بستن", color = Color(0xFF8B98A5)) }
      }

      Box(
        modifier = Modifier.size(96.dp).clickable(enabled = !busy) { onPickPhoto() },
        contentAlignment = Alignment.Center,
      ) {
        AvatarBadge(name = name.ifBlank { user.displayName }, colorIndex = user.avatarColorIndex, size = 92.dp, image = avatar)
        Box(
          modifier =
            Modifier.align(Alignment.BottomEnd)
              .size(28.dp)
              .clip(CircleShape)
              .background(Color(0xFF4E8AD1))
              .border(2.5.dp, Color(0xFF151E27), CircleShape),
          contentAlignment = Alignment.Center,
        ) {
          if (busy) {
            CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(14.dp))
          } else {
            Icon(BaziIcons.Photo, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
          }
        }
      }

      Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(
          onClick = onPickPhoto,
          enabled = !busy,
          shape = RoundedCornerShape(50),
          color = Color(0xFF1F2B38),
        ) {
          Text(
            "انتخاب عکس",
            style = MaterialTheme.typography.labelMedium,
            color = Color(0xFF5EB5F7),
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
          )
        }
        if (avatar != null) {
          Surface(
            onClick = onRemovePhoto,
            enabled = !busy,
            shape = RoundedCornerShape(50),
            color = Color(0xFF2B1E24),
          ) {
            Text(
              "حذف عکس",
              style = MaterialTheme.typography.labelMedium,
              color = Color(0xFFF87171),
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            )
          }
        }
      }

      OutlinedTextField(
        value = name,
        onValueChange = { if (it.length <= 32) name = it },
        singleLine = true,
        label = { Text("نام نمایشی") },
        modifier = Modifier.fillMaxWidth().testTag("edit_name_field"),
        shape = RoundedCornerShape(14.dp),
        colors = fieldColors,
      )

      OutlinedTextField(
        value = bioDraft,
        onValueChange = { if (it.length <= 300) bioDraft = it },
        minLines = 2,
        maxLines = 4,
        label = { Text("بیوگرافی") },
        supportingText = { Text("${bioDraft.length}/300", color = Color(0xFF7D8B99)) },
        modifier = Modifier.fillMaxWidth().testTag("edit_bio_field"),
        shape = RoundedCornerShape(14.dp),
        colors = fieldColors,
      )

      Button(
        onClick = {
          if (nameChanged) onSaveName(name.trim())
          if (bioChanged) onSaveBio(bioDraft.trim())
          onDismiss()
        },
        enabled = !busy,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4E8AD1)),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("edit_profile_save"),
      ) {
        Text(if (changed) "ذخیره تغییرات" else "تأیید", color = Color.White, fontWeight = FontWeight.Bold)
      }
    }
  }
}

@Composable
private fun StatBox(
  label: String,
  value: String,
  accent: Color,
  modifier: Modifier = Modifier,
) {
  GlassGradientCard(
    modifier = modifier,
    accentColor = accent,
    cornerRadius = 14.dp,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(vertical = 9.dp, horizontal = 6.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(value, style = MaterialTheme.typography.headlineSmall, color = accent, fontWeight = FontWeight.ExtraBold)
      Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    }
  }
}

// ---- Storage settings: see sizes, clear cache, delete downloaded files ----

private class StorageItem(
  val title: String,
  val hint: String,
  val dirs: List<File>,
  val dangerous: Boolean = false,
)

private fun dirSize(f: File): Long =
  if (f.isFile) f.length() else f.listFiles()?.sumOf { dirSize(it) } ?: 0L

/** Deletes everything inside [dirs] but keeps the folders themselves. */
private fun wipe(dirs: List<File>) {
  dirs.forEach { d -> d.listFiles()?.forEach { runCatching { it.deleteRecursively() } } }
}

private fun fmtSize(b: Long): String {
  val str = when {
    b < 1024 -> "$b B"
    b < 1024L * 1024 -> "%.1f KB".format(b / 1024.0)
    b < 1024L * 1024 * 1024 -> "%.1f MB".format(b / 1048576.0)
    else -> "%.2f GB".format(b / 1073741824.0)
  }
  return str.toFaDigits()
}

@Composable
private fun TelegramSettingsSection(
  notificationsEnabled: Boolean,
  onToggleNotifications: (Boolean) -> Unit,
  onLogout: () -> Unit,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val items =
    remember {
      val fd = context.filesDir
      listOf(
        StorageItem("کش برنامه", "فایل‌های موقت؛ بدون خطر پاک می‌شود", listOfNotNull(context.cacheDir, context.externalCacheDir)),
        StorageItem("تصاویر چت", "عکس‌های دانلودشده؛ دوباره از سرور می‌آیند", listOf(File(fd, "chat_images"))),
        StorageItem("هسته‌ی نئوجئو", "حدود چند ده مگ؛ دوباره قابل دانلود است", listOf(File(fd, "cores"))),
        StorageItem("بازی‌ها و تصاویر امولاتور", "فایل بازی‌هایی که انتخاب کرده‌ای", listOf(File(fd, "roms"), File(fd, "thumbs"))),
        StorageItem("ذخیره‌ی بازی‌ها", "سیوها و استیت‌ها؛ برگشت ندارد", listOf(File(fd, "saves")), dangerous = true),
      )
    }
  var sizes by remember { mutableStateOf(List(items.size) { -1L }) }
  var storageExpanded by remember { mutableStateOf(false) }
  var confirm by remember { mutableStateOf<Int?>(null) }
  var toast by remember { mutableStateOf<String?>(null) }

  fun refresh() {
    scope.launch {
      val r = withContext(Dispatchers.IO) { items.map { it.dirs.sumOf { d -> dirSize(d) } } }
      sizes = r
    }
  }
  LaunchedEffect(Unit) { refresh() }
  LaunchedEffect(toast) {
    if (toast != null) {
      delay(3000)
      toast = null
    }
  }

  confirm?.let { idx ->
    val it = items[idx]
    AlertDialog(
      onDismissRequest = { confirm = null },
      containerColor = Color(0xFF1C2631),
      title = { Text("پاک کردن «${it.title}»؟", color = Color.White) },
      text = { Text(if (it.dangerous) "این کار قابل بازگشت نیست و سیو بازی‌ها از بین می‌رود." else "${it.hint}.", color = Color(0xFF8B98A5)) },
      confirmButton = {
        TextButton(
          onClick = {
            confirm = null
            scope.launch {
              withContext(Dispatchers.IO) { wipe(it.dirs) }
              toast = "«${it.title}» پاک شد"
              refresh()
            }
          },
        ) { Text("پاک کن", color = CrimsonMagenta, fontWeight = FontWeight.Bold) }
      },
      dismissButton = { TextButton(onClick = { confirm = null }) { Text("انصراف", color = Color(0xFF8B98A5)) } },
    )
  }

  val total = sizes.filter { it >= 0 }.sum()
  val totalStr = if (sizes.any { it < 0 }) "…" else fmtSize(total)

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color(0xFF1C2631),
    modifier = Modifier.fillMaxWidth().widthIn(max = 560.dp),
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      // 1. Notifications row
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Box(
          modifier = Modifier.size(32.dp).clip(RoundedCornerShape(9.dp)).background(Color(0xFFE05252)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(BaziIcons.Forum, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
          Text("اعلان پیام‌ها", style = MaterialTheme.typography.bodyLarge.copy(fontSize = 15.sp), color = Color.White, fontWeight = FontWeight.Medium)
          Text("صدا و نوتیفیکیشن پیام‌های جدید", style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp), color = Color(0xFF7D8B99))
        }
        Switch(
          checked = notificationsEnabled,
          onCheckedChange = onToggleNotifications,
          colors = SwitchDefaults.colors(
            checkedTrackColor = Color(0xFF4E8AD1),
            checkedThumbColor = Color.White,
            uncheckedTrackColor = Color(0xFF2B3745),
            uncheckedThumbColor = Color(0xFF8B98A5),
          ),
          modifier = Modifier.testTag("notifications_switch"),
        )
      }

      HorizontalDivider(modifier = Modifier.padding(start = 58.dp), thickness = 0.5.dp, color = Color.Black.copy(alpha = 0.28f))

      // 2. Data and Storage expandable row
      Row(
        modifier = Modifier.fillMaxWidth().clickable { storageExpanded = !storageExpanded }.padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Box(
          modifier = Modifier.size(32.dp).clip(RoundedCornerShape(9.dp)).background(Color(0xFF4E8AD1)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(BaziIcons.SportsEsports, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
          Text("داده و حافظه", style = MaterialTheme.typography.bodyLarge.copy(fontSize = 15.sp), color = Color.White, fontWeight = FontWeight.Medium)
          Text("حجم اشغال‌شده: $totalStr", style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp), color = Color(0xFF7D8B99))
        }
        Text(
          text = if (storageExpanded) "▲" else "▼",
          style = MaterialTheme.typography.labelSmall,
          color = Color(0xFF7D8B99),
        )
      }

      AnimatedVisibility(visible = storageExpanded) {
        Column(
          modifier = Modifier.fillMaxWidth().background(Color(0xFF17202A)).padding(horizontal = 14.dp, vertical = 8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          items.forEachIndexed { i, it ->
            val size = sizes[i]
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(it.title, style = MaterialTheme.typography.bodyMedium, color = Color.White, fontWeight = FontWeight.Medium)
                Text(if (size < 0) "…" else fmtSize(size), style = MaterialTheme.typography.labelSmall, color = Color(0xFF7D8B99))
              }
              OutlinedButton(
                onClick = { confirm = i },
                enabled = size != 0L,
                border = BorderStroke(0.8.dp, (if (it.dangerous) Color(0xFFF87171) else Color(0xFF5EB5F7)).copy(alpha = 0.55f)),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                modifier = Modifier.height(30.dp),
              ) {
                Text(
                  if (i == 0) "پاک‌سازی" else "حذف",
                  style = MaterialTheme.typography.labelSmall,
                  color = if (it.dangerous) Color(0xFFF87171) else Color(0xFF5EB5F7),
                  fontWeight = FontWeight.Bold,
                )
              }
            }
          }
          toast?.let { Text(it, color = ElectricEmerald, style = MaterialTheme.typography.bodySmall) }
        }
      }

      HorizontalDivider(modifier = Modifier.padding(start = 58.dp), thickness = 0.5.dp, color = Color.Black.copy(alpha = 0.28f))

      // 3. Logout row
      Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onLogout).padding(horizontal = 14.dp, vertical = 12.dp).testTag("logout_button"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Box(
          modifier = Modifier.size(32.dp).clip(RoundedCornerShape(9.dp)).background(Color(0xFFD94A4A)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(BaziIcons.Logout, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        Text(
          text = "خروج از حساب کاربری",
          style = MaterialTheme.typography.bodyLarge.copy(fontSize = 15.sp),
          color = Color(0xFFF87171),
          fontWeight = FontWeight.Medium,
        )
      }
    }
  }
}
