package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.GameType
import com.example.data.MainTab
import com.example.ui.MainViewModel
import com.example.ui.components.BaziIcons
import com.example.ui.components.GameLobbyBottomSheet
import com.example.ui.games.ConnectFourScreen
import com.example.ui.games.LudoScreen
import com.example.ui.games.SnakesLaddersScreen
import com.example.ui.games.TicTacToeScreen
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.AuthAndProfileScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.theme.BaziroxTheme
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(0xFF070B14.toInt()),
    )
    setContent {
      BaziroxTheme {
        // Fixed text scale: UI sizes must not change with the phone's system font size.
        val baseDensity = androidx.compose.ui.platform.LocalDensity.current
        CompositionLocalProvider(
          LocalLayoutDirection provides LayoutDirection.Rtl,
          androidx.compose.ui.platform.LocalDensity provides
            androidx.compose.ui.unit.Density(baseDensity.density, fontScale = 1f),
        ) {
          BaziroxApp()
        }
      }
    }
  }
}

@Composable
fun BaziroxApp(viewModel: MainViewModel = viewModel()) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()

  // Priority full-screen overlays: Admin Panel & Active Games
  if (state.showAdminPanel) {
    AdminPanelScreen(
      initialConfig = state.cPanelConfig,
      pingLoading = state.pingLoading,
      pingResult = state.pingResult,
      onSaveConfig = { viewModel.saveCPanelConfig(it) },
      onTestConnection = { viewModel.testCPanelConnection(it) },
      onClose = { viewModel.closeAdminPanel() },
    )
    return
  }

  state.activeGameSession?.let { session ->
    val myUsername = state.currentUser?.username ?: "شما"
    when (session.gameType) {
      GameType.LUDO ->
        LudoScreen(
          playMode = session.playMode,
          playerCount = session.playerCount,
          room = session.room,
          currentUsername = myUsername,
          onPushOnlineState = { json, status -> viewModel.pushOnlineGameState(json, status) },
          onRecordResult = { win, pts -> viewModel.recordGameFinish(GameType.LUDO, win, pts) },
          onBack = { viewModel.exitActiveGame() },
        )
      GameType.TIC_TAC_TOE ->
        TicTacToeScreen(
          playMode = session.playMode,
          room = session.room,
          currentUsername = myUsername,
          onPushOnlineState = { json, status -> viewModel.pushOnlineGameState(json, status) },
          onRecordResult = { win, pts -> viewModel.recordGameFinish(GameType.TIC_TAC_TOE, win, pts) },
          onBack = { viewModel.exitActiveGame() },
        )
      GameType.CONNECT_FOUR ->
        ConnectFourScreen(
          playMode = session.playMode,
          room = session.room,
          currentUsername = myUsername,
          onPushOnlineState = { json, status -> viewModel.pushOnlineGameState(json, status) },
          onRecordResult = { win, pts -> viewModel.recordGameFinish(GameType.CONNECT_FOUR, win, pts) },
          onBack = { viewModel.exitActiveGame() },
        )
      GameType.SNAKES_LADDERS ->
        SnakesLaddersScreen(
          playMode = session.playMode,
          playerCount = session.playerCount,
          room = session.room,
          currentUsername = myUsername,
          onPushOnlineState = { json, status -> viewModel.pushOnlineGameState(json, status) },
          onRecordResult = { win, pts -> viewModel.recordGameFinish(GameType.SNAKES_LADDERS, win, pts) },
          onBack = { viewModel.exitActiveGame() },
        )
    }
    return
  }

  // Keyboard open -> hide bottom bar and lift content above the keyboard.
  // derivedStateOf: only recomposes when the keyboard opens/closes, not on every frame of its animation.
  val imeInsets = WindowInsets.ime
  val imeDensity = androidx.compose.ui.platform.LocalDensity.current
  val imeOpen by androidx.compose.runtime.remember {
    androidx.compose.runtime.derivedStateOf { imeInsets.getBottom(imeDensity) > 0 }
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = ObsidianBg,
    contentWindowInsets = WindowInsets.statusBars,
    bottomBar = {
      if (!imeOpen) {
        ModernGamingBottomBar(
          activeTab = state.activeTab,
          onSelectTab = { viewModel.selectTab(it) },
        )
      }
    },
  ) { innerPadding ->
    Box(
      modifier =
        Modifier.fillMaxSize()
          .padding(innerPadding)
          .then(if (imeOpen) Modifier.imePadding() else Modifier)
    ) {
      AnimatedContent(
        targetState = state.activeTab,
        transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(140)) },
        label = "main_tab_transition",
      ) { tab ->
        when (tab) {
          MainTab.GAMES ->
            HomeScreen(
              currentUser = state.currentUser,
              cPanelConfig = state.cPanelConfig,
              onSelectGame = { viewModel.openGameLobby(it) },
              onQuickJoinRoom = { code, gameType -> viewModel.joinOnlineRoomAndPlay(code, gameType) },
              onOpenProfile = { viewModel.selectTab(MainTab.PROFILE) },
            )
          MainTab.CHAT ->
            ChatScreen(
              currentUser = state.currentUser,
              groups = state.chatGroups,
              selectedGroup = state.selectedGroup,
              messages = state.chatMessages,
              feedbackMessage = state.chatFeedback,
              chatReads = state.chatReads,
              draftImagePath = state.chatDraftImage,
              replyTo = state.chatReplyTo,
              imageBusy = state.chatImageBusy,
              onPickImage = { viewModel.pickChatImage(it) },
              onClearDraftImage = { viewModel.clearChatDraftImage() },
              onSetReply = { viewModel.setChatReply(it) },
              onRetryMessage = { viewModel.retryMessage(it) },
              loadImage = { m, d -> viewModel.loadChatImage(m, d) },
              onCreateGroup = { viewModel.createGroup(it) },
              onJoinGroupByCode = { viewModel.joinGroupByCode(it) },
              onInviteMember = { gid, target -> viewModel.inviteMember(gid, target) },
              onOpenGroup = { viewModel.openGroupChat(it) },
              onCloseGroup = { viewModel.closeGroupChat() },
              onSendMessage = { viewModel.sendGroupMessage(it) },
              onSendGameInvite = { viewModel.sendGameInviteToGroup(it) },
              onJoinGameInvite = { inv -> viewModel.joinOnlineRoomAndPlay(inv.roomCode, inv.gameType) },
              onOpenAuth = { viewModel.selectTab(MainTab.PROFILE) },
              onClearFeedback = { viewModel.clearChatFeedback() },
            )
          MainTab.LEADERBOARD ->
            LeaderboardScreen(
              entries = state.leaderboard,
              selectedFilter = state.leaderboardFilter,
              onSelectFilter = { viewModel.setLeaderboardFilter(it) },
              onRefresh = { viewModel.refreshLeaderboard() },
            )
          MainTab.PROFILE ->
            AuthAndProfileScreen(
              currentUser = state.currentUser,
              cPanelConfig = state.cPanelConfig,
              authLoading = state.authLoading,
              authError = state.authError,
              onLogin = { u, p -> viewModel.login(u, p) },
              onRegister = { u, p, d, c -> viewModel.register(u, p, d, c) },
              onLogout = { viewModel.logout() },
            )
        }
      }
    }
  }

  state.lobbyGameType?.let { gameType ->
    GameLobbyBottomSheet(
      gameType = gameType,
      isServerConnected = state.cPanelConfig.isConnected,
      statusMessage = state.roomStatusMessage,
      onDismiss = { viewModel.dismissGameLobby() },
      onStartMode = { mode, players -> viewModel.startGame(gameType, mode, players) },
      onCreateOnlineRoom = { viewModel.createOnlineRoomAndPlay(gameType) },
      onJoinOnlineRoom = { code -> viewModel.joinOnlineRoomAndPlay(code, gameType) },
    )
  }
}

@Composable
private fun ModernGamingBottomBar(
  activeTab: MainTab,
  onSelectTab: (MainTab) -> Unit,
) {
  val barShape = RoundedCornerShape(26.dp)
  val borderBrush =
    androidx.compose.ui.graphics.Brush.linearGradient(
      colors =
        listOf(
          Color.White.copy(alpha = 0.28f),
          NeonCyan.copy(alpha = 0.36f),
          Color.White.copy(alpha = 0.08f),
        )
    )
  val fillBrush =
    androidx.compose.ui.graphics.Brush.linearGradient(
      colors =
        listOf(
          Color(0xE018223F),
          Color(0xD90E1529),
        )
    )

  Surface(
    modifier =
      Modifier.fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp)
        .windowInsetsPadding(WindowInsets.navigationBars)
        .clip(barShape)
        .background(fillBrush)
        .border(1.2.dp, borderBrush, barShape),
    shape = barShape,
    color = Color.Transparent,
    tonalElevation = 0.dp,
  ) {
    NavigationBar(
      modifier = Modifier.height(68.dp),
      containerColor = Color.Transparent,
      tonalElevation = 0.dp,
      windowInsets = WindowInsets(0.dp),
    ) {
      MainTab.entries.forEach { tab ->
        val selected = activeTab == tab
        val icon =
          when (tab) {
            MainTab.GAMES -> BaziIcons.SportsEsports
            MainTab.CHAT -> BaziIcons.Forum
            MainTab.LEADERBOARD -> BaziIcons.Trophy
            MainTab.PROFILE -> if (selected) Icons.Rounded.Person else Icons.Outlined.Person
          }
        NavigationBarItem(
          selected = selected,
          onClick = { onSelectTab(tab) },
          modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}"),
          icon = {
            Icon(
              imageVector = icon,
              contentDescription = tab.titleFa,
              modifier = Modifier.size(24.dp),
            )
          },
          label = {
            Text(
              text = tab.titleFa,
              style = MaterialTheme.typography.labelMedium,
              fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium,
            )
          },
          colors =
            NavigationBarItemDefaults.colors(
              selectedIconColor = NeonCyan,
              selectedTextColor = NeonCyan,
              indicatorColor = NeonCyan.copy(alpha = 0.18f),
              unselectedIconColor = TextSecondary,
              unselectedTextColor = TextSecondary,
            ),
        )
      }
    }
  }
}
