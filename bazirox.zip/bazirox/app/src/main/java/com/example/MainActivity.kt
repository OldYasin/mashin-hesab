package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.GameType
import com.example.data.MainTab
import com.example.data.PlayMode
import com.example.ui.MainViewModel
import com.example.ui.components.BaziIcons
import com.example.ui.components.GameLobbyBottomSheet
import com.example.ui.components.GameHudState
import com.example.ui.components.LocalGameHud
import com.example.ui.components.LocalGameTopExtra
import com.example.ui.components.RoomChatBar
import com.example.ui.components.RoomChatOverlay
import com.example.ui.components.RoomPlayersStrip
import com.example.ui.components.rememberRoomChatState
import com.example.ui.components.gamingBackdrop
import androidx.compose.runtime.setValue
import com.example.ui.games.ConnectFourScreen
import com.example.ui.games.EmulatorScreen
import com.example.ui.games.LudoScreen
import com.example.ui.games.SnakesLaddersScreen
import com.example.ui.games.GuessNumberScreen
import com.example.ui.games.RockPaperScissorsScreen
import com.example.ui.games.TicTacToeScreen
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.AuthAndProfileScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.theme.BaziroxTheme
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {
  // Same instance the UI gets from viewModel() (both are scoped to this activity).
  private val mainVm: MainViewModel by viewModels()

  override fun onStart() {
    super.onStart()
    com.example.notify.AppVisibility.foreground = true
  }

  override fun onStop() {
    com.example.notify.AppVisibility.foreground = false
    super.onStop()
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    openChatFromIntent(intent)
  }

  private fun openChatFromIntent(intent: Intent?) {
    val i = intent ?: return
    val gid = i.getStringExtra(com.example.notify.NotificationHelper.EXTRA_GROUP_ID) ?: return
    i.removeExtra(com.example.notify.NotificationHelper.EXTRA_GROUP_ID)
    mainVm.openGroupFromNotification(gid)
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    com.example.data.SoundManager.init(applicationContext)
    if (savedInstanceState == null) openChatFromIntent(intent)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(0xFF0B1226.toInt()),
    )
    setContent {
      BaziroxTheme {
        // Fixed text scale: UI sizes must not change with the phone's system font size.
        val baseDensity = androidx.compose.ui.platform.LocalDensity.current
        CompositionLocalProvider(
          LocalLayoutDirection provides LayoutDirection.Rtl,
          androidx.compose.ui.platform.LocalDensity provides
            androidx.compose.ui.unit.Density(baseDensity.density, fontScale = 1f),
        ) {
          BaziroxApp()
        }
      }
    }
  }
}

@Composable
fun BaziroxApp(viewModel: MainViewModel = viewModel()) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()

  // Android 13+: ask for the notification permission once, after the first login.
  val notifContext = androidx.compose.ui.platform.LocalContext.current
  val notifPermLauncher =
    androidx.activity.compose.rememberLauncherForActivityResult(
      androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) {}
  androidx.compose.runtime.LaunchedEffect(state.currentUser != null, state.notificationsEnabled) {
    if (
      state.currentUser != null &&
        state.notificationsEnabled &&
        android.os.Build.VERSION.SDK_INT >= 33 &&
        !com.example.notify.NotifyPrefs.permissionAsked(notifContext) &&
        androidx.core.content.ContextCompat.checkSelfPermission(
          notifContext,
          android.Manifest.permission.POST_NOTIFICATIONS,
        ) != android.content.pm.PackageManager.PERMISSION_GRANTED
    ) {
      com.example.notify.NotifyPrefs.setPermissionAsked(notifContext)
      notifPermLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
    }
  }

  // Priority full-screen overlays: Admin Panel & Active Games
  if (state.showAdminPanel) {
    AdminPanelScreen(
      initialConfig = state.cPanelConfig,
      pingLoading = state.pingLoading,
      pingResult = state.pingResult,
      onSaveConfig = { viewModel.saveCPanelConfig(it) },
      onTestConnection = { viewModel.testCPanelConnection(it) },
      onClose = { viewModel.closeAdminPanel() },
    )
    return
  }

  // Login is mandatory: no guest mode. Wait for the saved session to load, then either show the
  // main app (already logged in -> stays logged in until "logout") or the full-screen login.
  if (!state.sessionLoaded) {
    Box(
      modifier = Modifier.fillMaxSize().background(ObsidianBg),
      contentAlignment = androidx.compose.ui.Alignment.Center,
    ) {
      androidx.compose.material3.CircularProgressIndicator(color = NeonCyan)
    }
    return
  }
  if (state.currentUser == null) {
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(ObsidianBg)
          .gamingBackdrop()
          .windowInsetsPadding(WindowInsets.statusBars)
          .imePadding()
    ) {
      AuthAndProfileScreen(
        currentUser = null,
        cPanelConfig = state.cPanelConfig,
        authLoading = state.authLoading,
        authError = state.authError,
        onLogin = { u, p -> viewModel.login(u, p) },
        onRegister = { u, p, d, c -> viewModel.register(u, p, d, c) },
        onLogout = {},
      )
    }
    return
  }

  var showEmulator by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf(false) }
  if (showEmulator) {
    EmulatorScreen(playerName = state.currentUser?.displayName ?: "", currentUsername = state.currentUser?.username ?: "", onBack = { showEmulator = false })
    return
  }

  state.activeGameSession?.let { session ->
    val myUsername = state.currentUser?.username ?: "شما"
    val onlineRoom = if (session.playMode == PlayMode.ONLINE_ROOM) session.room else null
    // Online rooms get a chat strip (player avatars + bubbles + chat box) under the game.
    Column(
      modifier =
        Modifier.fillMaxSize()
          .background(ObsidianBg)
          .then(if (onlineRoom != null) Modifier.navigationBarsPadding().imePadding() else Modifier)
    ) {
      val chatState = rememberRoomChatState(state.roomChat, state.roomChatReady, myUsername)
      val hud = androidx.compose.runtime.remember(session.gameType, onlineRoom?.roomCode) { GameHudState() }
      val topExtra: (@Composable () -> Unit)? =
        if (onlineRoom != null) {
          {
            RoomPlayersStrip(
              state = chatState,
              players = onlineRoom.players,
              playerInfo = state.roomPlayers,
              avatars = state.avatars,
              me = myUsername,
              hud = hud,
              capacity =
                if (onlineRoom.status == "waiting" &&
                  (onlineRoom.gameType == GameType.LUDO || onlineRoom.gameType == GameType.SNAKES_LADDERS)
                ) 4 else 2,
            )
          }
        } else null
      androidx.compose.runtime.CompositionLocalProvider(
        LocalGameTopExtra provides topExtra,
        LocalGameHud provides (if (onlineRoom != null) hud else null),
      ) {
      Box(modifier = Modifier.weight(1f)) {
        when (session.gameType) {
          GameType.LUDO ->
            LudoScreen(
              playMode = session.playMode,
              playerCount = session.playerCount,
              room = session.room,
              currentUsername = myUsername,
              onPushOnlineState = { json, status -> viewModel.pushOnlineGameState(json, status) },
              onRecordResult = { win, pts -> viewModel.recordGameFinish(GameType.LUDO, win, pts) },
              onBack = { viewModel.exitActiveGame() },
            )
          GameType.TIC_TAC_TOE ->
            TicTacToeScreen(
              playMode = session.playMode,
              room = session.room,
              currentUsername = myUsername,
              onPushOnlineState = { json, status -> viewModel.pushOnlineGameState(json, status) },
              onRecordResult = { win, pts -> viewModel.recordGameFinish(GameType.TIC_TAC_TOE, win, pts) },
              onBack = { viewModel.exitActiveGame() },
            )
          GameType.CONNECT_FOUR ->
            ConnectFourScreen(
              playMode = session.playMode,
              room = session.room,
              currentUsername = myUsername,
              onPushOnlineState = { json, status -> viewModel.pushOnlineGameState(json, status) },
              onRecordResult = { win, pts -> viewModel.recordGameFinish(GameType.CONNECT_FOUR, win, pts) },
              onBack = { viewModel.exitActiveGame() },
            )
          GameType.SNAKES_LADDERS ->
            SnakesLaddersScreen(
              playMode = session.playMode,
              playerCount = session.playerCount,
              room = session.room,
              currentUsername = myUsername,
              onPushOnlineState = { json, status -> viewModel.pushOnlineGameState(json, status) },
              onRecordResult = { win, pts -> viewModel.recordGameFinish(GameType.SNAKES_LADDERS, win, pts) },
              onBack = { viewModel.exitActiveGame() },
            )
          GameType.GUESS_NUMBER ->
            GuessNumberScreen(
              playMode = session.playMode,
              room = session.room,
              currentUsername = myUsername,
              onPushOnlineState = { json, status -> viewModel.pushOnlineGameState(json, status) },
              onRecordResult = { win, pts -> viewModel.recordGameFinish(GameType.GUESS_NUMBER, win, pts) },
              onBack = { viewModel.exitActiveGame() },
            )
          GameType.ROCK_PAPER_SCISSORS ->
            RockPaperScissorsScreen(
              playMode = session.playMode,
              room = session.room,
              currentUsername = myUsername,
              onPushOnlineState = { json, status -> viewModel.pushOnlineGameState(json, status) },
              onRecordResult = { win, pts -> viewModel.recordGameFinish(GameType.ROCK_PAPER_SCISSORS, win, pts) },
              onBack = { viewModel.exitActiveGame() },
            )
        }
        if (onlineRoom != null) {
          RoomChatOverlay(
            state = chatState,
            playerInfo = state.roomPlayers,
            avatars = state.avatars,
            messages = state.roomChat,
            me = myUsername,
            onSend = { viewModel.sendRoomChat(it) },
            modifier = Modifier.align(androidx.compose.ui.Alignment.BottomCenter),
          )
        }
      }
      }
      if (onlineRoom != null) {
        RoomChatBar(
          state = chatState,
          playerInfo = state.roomPlayers,
          avatars = state.avatars,
          messages = state.roomChat,
          me = myUsername,
          onSend = { viewModel.sendRoomChat(it) },
        )
      }
    }
    return
  }

  // Keyboard open -> hide bottom bar and lift content above the keyboard.
  // derivedStateOf: only recomposes when the keyboard opens/closes, not on every frame of its animation.
  val imeInsets = WindowInsets.ime
  val imeDensity = androidx.compose.ui.platform.LocalDensity.current
  val imeOpen by androidx.compose.runtime.remember {
    androidx.compose.runtime.derivedStateOf { imeInsets.getBottom(imeDensity) > 0 }
  }

  Scaffold(
    modifier = Modifier.fillMaxSize().background(ObsidianBg).gamingBackdrop(),
    containerColor = Color.Transparent,
    contentWindowInsets = WindowInsets.statusBars,
    bottomBar = {
      if (!imeOpen) {
        ModernGamingBottomBar(
          activeTab = state.activeTab,
          onSelectTab = { viewModel.selectTab(it) },
        )
      }
    },
  ) { innerPadding ->
    Box(
      modifier =
        Modifier.fillMaxSize()
          .padding(innerPadding)
          .then(if (imeOpen) Modifier.imePadding() else Modifier)
    ) {
      // No cross-fade between tabs: every tab paints its own full-screen backdrop, and fading two of them
      // over each other made the chat background look like it was sliding/shaking.
      AnimatedContent(
        targetState = state.activeTab,
        modifier = Modifier.fillMaxSize(),
        transitionSpec = { EnterTransition.None togetherWith ExitTransition.None },
        label = "main_tab_transition",
      ) { tab ->
        when (tab) {
          MainTab.GAMES ->
            HomeScreen(
              currentUser = state.currentUser,
              cPanelConfig = state.cPanelConfig,
              onSelectGame = { viewModel.openGameLobby(it) },
              onQuickJoinRoom = { code, gameType -> viewModel.joinOnlineRoomAndPlay(code, gameType) },
              onOpenProfile = { viewModel.selectTab(MainTab.PROFILE) },
              onOpenEmulator = { showEmulator = true },
            )
          MainTab.CHAT ->
            ChatScreen(
              currentUser = state.currentUser,
              groups = state.chatGroups,
              selectedGroup = state.selectedGroup,
              messages = state.chatMessages,
              feedbackMessage = state.chatFeedback,
              chatReads = state.chatReads,
              userPresence = state.userPresence,
              typingUsers = state.typingUsers,
              onTyping = { viewModel.onUserTyping() },
              onTypingStopped = { viewModel.onTypingStopped() },
              draftImagePath = state.chatDraftImage,
              replyTo = state.chatReplyTo,
              imageBusy = state.chatImageBusy,
              onPickImage = { viewModel.pickChatImage(it) },
              onClearDraftImage = { viewModel.clearChatDraftImage() },
              onSetReply = { viewModel.setChatReply(it) },
              editing = state.chatEditing,
              onStartEdit = { viewModel.startEditMessage(it) },
              onCancelEdit = { viewModel.cancelEditMessage() },
              onRetryMessage = { viewModel.retryMessage(it) },
              onDeleteMessage = { viewModel.deleteChatMessage(it) },
              joinRequests = state.joinRequests,
              onResolveJoinRequest = { user, ok -> viewModel.resolveJoinRequest(user, ok) },
              loadImage = { m, d -> viewModel.loadChatImage(m, d) },
              onCreateGroup = { viewModel.createGroup(it) },
              onJoinGroupByCode = { viewModel.joinGroupByCode(it) },
              onInviteMember = { gid, target -> viewModel.inviteMember(gid, target) },
              onLeaveGroup = { viewModel.leaveGroup(it) },
              onDeleteGroup = { viewModel.deleteGroup(it) },
              onUpdateGroup = { gid, n, d -> viewModel.updateGroup(gid, n, d) },
              onSetGroupAvatar = { gid, uri -> viewModel.setGroupAvatarFromUri(gid, uri) },
              onRemoveGroupAvatar = { viewModel.removeGroupAvatar(it) },
              avatars = state.avatars,
              senderNames = state.senderNames,
              viewedUser = state.viewedUser,
              viewedProfile = state.viewedProfile,
              viewedProfileError = state.viewedProfileError,
              onOpenUserProfile = { viewModel.openUserProfile(it) },
              onCloseUserProfile = { viewModel.closeUserProfile() },
              onStartDm = { viewModel.startDirectMessage(it) },
              onStartDmByUsername = { viewModel.startDirectMessageByUsername(it) },
              onOpenGroup = { viewModel.openGroupChat(it) },
              onCloseGroup = { viewModel.closeGroupChat() },
              onSendMessage = { viewModel.sendGroupMessage(it) },
              onSendGameInvite = { viewModel.sendGameInviteToGroup(it) },
              onJoinGameInvite = { inv -> viewModel.joinOnlineRoomAndPlay(inv.roomCode, inv.gameType) },
              onOpenAuth = { viewModel.selectTab(MainTab.PROFILE) },
              onClearFeedback = { viewModel.clearChatFeedback() },
            )
          MainTab.LEADERBOARD ->
            LeaderboardScreen(
              entries = state.leaderboard,
              avatars = state.avatars,
              selectedFilter = state.leaderboardFilter,
              onSelectFilter = { viewModel.setLeaderboardFilter(it) },
              onRefresh = { viewModel.refreshLeaderboard() },
            )
          MainTab.PROFILE ->
            AuthAndProfileScreen(
              currentUser = state.currentUser,
              cPanelConfig = state.cPanelConfig,
              authLoading = state.authLoading,
              authError = state.authError,
              onLogin = { u, p -> viewModel.login(u, p) },
              onRegister = { u, p, d, c -> viewModel.register(u, p, d, c) },
              onLogout = { viewModel.logout() },
              onChangePassword = { o, n, cb -> viewModel.changePassword(o, n, cb) },
              notificationsEnabled = state.notificationsEnabled,
              onToggleNotifications = { viewModel.setNotificationsEnabled(it) },
              avatar = state.currentUser?.let { state.avatars[it.username.lowercase()]?.bitmap },
              profileBusy = state.profileBusy,
              profileMessage = state.profileMessage,
              onPickAvatar = { viewModel.setAvatarFromUri(it) },
              onRemoveAvatar = { viewModel.removeAvatar() },
              onChangeName = { viewModel.updateDisplayName(it) },
              myBio = state.myBio,
              onSaveBio = { viewModel.saveBio(it) },
              onClearProfileMessage = { viewModel.clearProfileMessage() },
            )
        }
      }
    }
  }

  state.lobbyGameType?.let { gameType ->
    GameLobbyBottomSheet(
      gameType = gameType,
      isServerConnected = state.cPanelConfig.isConnected,
      statusMessage = state.roomStatusMessage,
      onDismiss = { viewModel.dismissGameLobby() },
      onStartMode = { mode, players -> viewModel.startGame(gameType, mode, players) },
      onCreateOnlineRoom = { viewModel.createOnlineRoomAndPlay(gameType) },
      onJoinOnlineRoom = { code -> viewModel.joinOnlineRoomAndPlay(code, gameType) },
    )
  }
}

@Composable
private fun ModernGamingBottomBar(
  activeTab: MainTab,
  onSelectTab: (MainTab) -> Unit,
) {
  val barShape = RoundedCornerShape(26.dp)
  val tap = com.example.ui.components.rememberTapHaptic()
  val borderBrush =
    androidx.compose.ui.graphics.Brush.linearGradient(
      colors =
        listOf(
          Color.White.copy(alpha = 0.28f),
          NeonCyan.copy(alpha = 0.36f),
          Color.White.copy(alpha = 0.08f),
        )
    )
  val fillBrush =
    androidx.compose.ui.graphics.Brush.linearGradient(
      colors =
        listOf(
          Color(0xE0111A2E),
          Color(0xD90C1322),
        )
    )

  Surface(
    modifier =
      Modifier.fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp)
        .windowInsetsPadding(WindowInsets.navigationBars)
        .clip(barShape)
        .background(fillBrush)
        .border(1.2.dp, borderBrush, barShape),
    shape = barShape,
    color = Color.Transparent,
    tonalElevation = 0.dp,
  ) {
    NavigationBar(
      modifier = Modifier.height(68.dp),
      containerColor = Color.Transparent,
      tonalElevation = 0.dp,
      windowInsets = WindowInsets(0.dp),
    ) {
      MainTab.entries.forEach { tab ->
        val selected = activeTab == tab
        val icon =
          when (tab) {
            MainTab.GAMES -> BaziIcons.SportsEsports
            MainTab.CHAT -> BaziIcons.Forum
            MainTab.LEADERBOARD -> BaziIcons.Trophy
            MainTab.PROFILE -> if (selected) Icons.Rounded.Person else Icons.Outlined.Person
          }
        NavigationBarItem(
          selected = selected,
          onClick = {
            if (!selected) tap()
            onSelectTab(tab)
          },
          modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}"),
          icon = {
            Icon(
              imageVector = icon,
              contentDescription = tab.titleFa,
              modifier = Modifier.size(24.dp),
            )
          },
          label = {
            Text(
              text = tab.titleFa,
              style = MaterialTheme.typography.labelMedium,
              fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium,
            )
          },
          colors =
            NavigationBarItemDefaults.colors(
              selectedIconColor = NeonCyan,
              selectedTextColor = NeonCyan,
              indicatorColor = NeonCyan.copy(alpha = 0.18f),
              unselectedIconColor = TextSecondary,
              unselectedTextColor = TextSecondary,
            ),
        )
      }
    }
  }
}
