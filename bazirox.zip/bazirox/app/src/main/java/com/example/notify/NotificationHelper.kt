package com.example.notify

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R

/** One notification per chat; tapping it opens that chat. */
object NotificationHelper {
  const val CHANNEL_ID = "messages"
  const val EXTRA_GROUP_ID = "open_group_id"

  class Entry(val groupId: String, val title: String, val lines: List<String>)

  private fun ensureChannel(context: Context) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (nm.getNotificationChannel(CHANNEL_ID) != null) return
    nm.createNotificationChannel(
      NotificationChannel(CHANNEL_ID, "پیام‌های جدید", NotificationManager.IMPORTANCE_DEFAULT)
    )
  }

  @SuppressLint("MissingPermission") // areNotificationsEnabled() covers the Android 13 permission
  fun show(context: Context, entries: List<Entry>) {
    val app = context.applicationContext
    val nm = NotificationManagerCompat.from(app)
    if (!nm.areNotificationsEnabled()) return
    ensureChannel(app)
    // On the lock screen only a generic line is shown: chat text is end-to-end encrypted.
    val publicVersion =
      NotificationCompat.Builder(app, CHANNEL_ID)
        .setSmallIcon(R.drawable.ic_stat_message)
        .setContentTitle(app.getString(R.string.app_name))
        .setContentText("پیام جدید")
        .build()
    for (e in entries) {
      val open =
        Intent(app, MainActivity::class.java).apply {
          flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
          putExtra(EXTRA_GROUP_ID, e.groupId)
        }
      val pending =
        PendingIntent.getActivity(
          app,
          e.groupId.hashCode(),
          open,
          PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
      val count = e.lines.size
      val style =
        if (count > 1) {
          NotificationCompat.InboxStyle().also { s -> e.lines.takeLast(5).forEach { s.addLine(it) } }
        } else {
          NotificationCompat.BigTextStyle().bigText(e.lines.last())
        }
      val b =
        NotificationCompat.Builder(app, CHANNEL_ID)
          .setSmallIcon(R.drawable.ic_stat_message)
          .setContentTitle(if (count > 1) "${e.title} ($count پیام)" else e.title)
          .setContentText(e.lines.last())
          .setStyle(style)
          .setCategory(NotificationCompat.CATEGORY_MESSAGE)
          .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
          .setPublicVersion(publicVersion)
          .setAutoCancel(true)
          .setContentIntent(pending)
      nm.notify(e.groupId, e.groupId.hashCode(), b.build())
    }
  }

  fun cancelAll(context: Context) {
    NotificationManagerCompat.from(context.applicationContext).cancelAll()
  }
}
