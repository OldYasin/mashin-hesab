package com.example.ui.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.SecureVault
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VazirmatnFamily
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Lightweight Apple Color Emoji support (< 10KB in APK).
 * If you place `AppleColorEmoji.ttf` next to `api.php` on your own Iran host, the app downloads
 * and caches it once in internal storage and uses it as a fallback font for Vazirmatn.
 */
object EmojiFontManager {
  @Volatile private var cachedFamily: FontFamily? = null
  @Volatile private var attempted = false

  fun cachedFontFile(context: Context): File =
    File(File(context.filesDir, "fonts"), "AppleColorEmoji.ttf")

  fun currentFamily(context: Context): FontFamily {
    cachedFamily?.let { return it }
    val file = cachedFontFile(context)
    if (file.exists() && file.length() > 100_000L) {
      val built = runCatching { buildFallbackFamily(file) }.getOrNull()
      if (built != null) {
        cachedFamily = built
        return built
      }
    }
    return VazirmatnFamily
  }

  private fun buildFallbackFamily(emojiFile: File): FontFamily =
    FontFamily(
      Font(R.font.vazirmatn_regular, FontWeight.Normal),
      Font(R.font.vazirmatn_medium, FontWeight.Medium),
      Font(R.font.vazirmatn_semibold, FontWeight.SemiBold),
      Font(R.font.vazirmatn_bold, FontWeight.Bold),
      Font(R.font.vazirmatn_extrabold, FontWeight.ExtraBold),
      Font(emojiFile, FontWeight.Normal),
      Font(emojiFile, FontWeight.Medium),
      Font(emojiFile, FontWeight.SemiBold),
      Font(emojiFile, FontWeight.Bold),
      Font(emojiFile, FontWeight.ExtraBold),
    )

  suspend fun ensureFromHost(context: Context): FontFamily {
    val existing = currentFamily(context)
    if (cachedFamily != null || attempted) return existing
    attempted = true
    val file = cachedFontFile(context)
    withContext(Dispatchers.IO) {
      val baseUrl = SecureVault(context.applicationContext).loadCPanelConfig().apiBaseUrl.trim()
      if (baseUrl.isBlank()) return@withContext
      val dirUrl = baseUrl.substringBefore("?").substringBeforeLast("/", "")
      if (dirUrl.isBlank()) return@withContext
      val fontUrl = "$dirUrl/AppleColorEmoji.ttf"
      val tmp = File(file.parentFile?.apply { mkdirs() }, "AppleColorEmoji.ttf.tmp")
      runCatching {
        val conn = (URL(fontUrl).openConnection() as HttpURLConnection).apply {
          connectTimeout = 5000
          readTimeout = 15000
          instanceFollowRedirects = true
        }
        try {
          if (conn.responseCode == 200) {
            conn.inputStream.use { input ->
              tmp.outputStream().use { out -> input.copyTo(out) }
            }
            // Verify TTF/OTF header and reasonable size before committing
            if (tmp.length() > 100_000L) {
              val head = tmp.inputStream().use { s -> ByteArray(4).also { s.read(it) } }
              val isFont =
                (head[0] == 0x00.toByte() && head[1] == 0x01.toByte()) ||
                  (head[0] == 'O'.code.toByte() && head[1] == 'T'.code.toByte()) ||
                  (head[0] == 't'.code.toByte() && head[1] == 't'.code.toByte())
              if (isFont) {
                tmp.renameTo(file)
              } else {
                tmp.delete()
              }
            } else {
              tmp.delete()
            }
          }
        } finally {
          conn.disconnect()
        }
      }.onFailure { tmp.delete() }
    }
    return currentFamily(context)
  }
}

@Composable
fun rememberChatEmojiFontFamily(): FontFamily {
  val context = LocalContext.current
  var family by remember { mutableStateOf(EmojiFontManager.currentFamily(context)) }
  LaunchedEffect(Unit) {
    family = EmojiFontManager.ensureFromHost(context)
  }
  return family
}

private data class EmojiCategory(val title: String, val emojis: List<String>)

private val EmojiCategories =
  listOf(
    EmojiCategory(
      "پرکاربرد",
      listOf(
        "😂", "❤️", "😍", "🔥", "👍", "😭", "🙏", "😎",
        "🤣", "😘", "🥳", "🤩", "👏", "💯", "✨", "😁",
        "😉", "🤔", "😴", "🤯", "🥺", "😡", "🤝", "✌️",
      ),
    ),
    EmojiCategory(
      "احساسات",
      listOf(
        "😀", "😃", "😄", "😅", "😊", "😇", "🙂", "🙃",
        "😋", "😜", "🤪", "🤨", "🧐", "🤓", "😏", "😒",
        "😔", "😞", "😟", "😢", "😤", "🤬", "😱", "🤗",
      ),
    ),
    EmojiCategory(
      "بازی و رقابت",
      listOf(
        "🎮", "🎲", "🏆", "🥇", "🥈", "🥉", "🎯", "⚡",
        "👑", "💎", "🚀", "💥", "🎉", "🎊", "🃏", "♟️",
        "⚽", "🏀", "🎧", "🕹️", "🛡️", "⚔️", "🔔", "⭐",
      ),
    ),
    EmojiCategory(
      "قلب و دست",
      listOf(
        "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍",
        "💔", "❤️‍🔥", "💖", "💘", "👌", "🤏", "🤞", "🤟",
        "🤙", "💪", "🙌", "🫶", "👀", "💀", "🌹", "☕",
      ),
    ),
  )

@Composable
fun TelegramEmojiPanel(
  emojiFontFamily: FontFamily,
  onPickEmoji: (String) -> Unit,
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  Column(
    modifier =
      Modifier.fillMaxWidth()
        .height(210.dp)
        .background(Color(0xF00B1120))
        .padding(top = 6.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp),
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      EmojiCategories.forEachIndexed { idx, cat ->
        val sel = selectedTab == idx
        Surface(
          onClick = { selectedTab = idx },
          shape = RoundedCornerShape(10.dp),
          color = if (sel) NeonCyan.copy(alpha = 0.16f) else Color.Transparent,
        ) {
          Text(
            text = cat.title,
            style = MaterialTheme.typography.labelSmall,
            color = if (sel) NeonCyan else TextSecondary,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
          )
        }
      }
    }

    LazyVerticalGrid(
      columns = GridCells.Adaptive(minSize = 42.dp),
      modifier = Modifier.fillMaxWidth().weight(1f),
      contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(2.dp),
      verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
      items(EmojiCategories[selectedTab].emojis) { emoji ->
        Box(
          modifier =
            Modifier.size(42.dp)
              .clip(RoundedCornerShape(10.dp))
              .clickable { onPickEmoji(emoji) },
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = emoji,
            fontSize = 23.sp,
            fontFamily = emojiFontFamily,
            color = TextPrimary,
          )
        }
      }
    }
  }
}
