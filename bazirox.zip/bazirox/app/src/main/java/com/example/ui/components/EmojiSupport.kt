package com.example.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.isSpecified
import androidx.compose.ui.unit.sp
import com.example.R

/**
 * Bundled Apple-style emoji pack (res/drawable-nodpi/emoji_*.webp, 128px).
 * The picker offers exactly this pack, and any of these emojis inside a message
 * (bubbles, chat-list preview, reply preview, input box) is drawn as the webp image.
 */
private data class PackEmoji(val unicode: String, @DrawableRes val res: Int, val aliases: List<String> = emptyList())

private val EmojiPack =
  listOf(
    PackEmoji("😂", R.drawable.emoji_joy),
    PackEmoji("🤣", R.drawable.emoji_rofl),
    PackEmoji("😃", R.drawable.emoji_grin, listOf("😄")),
    PackEmoji("🙂", R.drawable.emoji_smile),
    PackEmoji("😇", R.drawable.emoji_angel),
    PackEmoji("😐", R.drawable.emoji_neutral),
    PackEmoji("😟", R.drawable.emoji_worried),
    PackEmoji("😭", R.drawable.emoji_crying),
    PackEmoji("🙏", R.drawable.emoji_pray),
    PackEmoji("👍", R.drawable.emoji_thumbs_up),
    PackEmoji("👎", R.drawable.emoji_thumbs_down),
  )

private val EmojiLookup: Map<String, Int> =
  buildMap {
    EmojiPack.forEach { e ->
      put(e.unicode, e.res)
      e.aliases.forEach { put(it, e.res) }
    }
  }

// Matches any pack emoji, optionally followed by U+FE0F.
private val EmojiRegex: Regex =
  Regex(EmojiLookup.keys.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) } + "\uFE0F?")

fun containsPackEmoji(text: String): Boolean = EmojiRegex.containsMatchIn(text)

private fun lookupEmoji(match: String): Int? = EmojiLookup[match.removeSuffix("\uFE0F")]

/**
 * Text that renders the bundled webp emojis inline.
 * A message made only of emojis (a few of them) is drawn big, like Telegram; mixed text uses ~1.7x the font size.
 */
@Composable
fun EmojiText(
  text: String,
  style: TextStyle,
  color: Color,
  modifier: Modifier = Modifier,
  maxLines: Int = Int.MAX_VALUE,
  overflow: TextOverflow = TextOverflow.Clip,
  emojiScale: Float? = null,
  onTextLayout: ((androidx.compose.ui.text.TextLayoutResult) -> Unit)? = null,
) {
  if (!containsPackEmoji(text)) {
    Text(
      text = text,
      style = style,
      color = color,
      modifier = modifier,
      maxLines = maxLines,
      overflow = overflow,
      onTextLayout = onTextLayout ?: {},
    )
    return
  }
  val fontSize: TextUnit = if (style.fontSize.isSpecified) style.fontSize else 15.sp
  val scale =
    emojiScale
      ?: run {
        val onlyEmoji = EmojiRegex.replace(text, "").isBlank()
        if (onlyEmoji && EmojiRegex.findAll(text).count() <= 12) 2.6f else 1.7f
      }
  val size = fontSize * scale
  val built =
    remember(text) {
      val used = linkedMapOf<String, Int>()
      val annotated =
        buildAnnotatedString {
          var last = 0
          EmojiRegex.findAll(text).forEach { m ->
            if (m.range.first > last) append(text.substring(last, m.range.first))
            val res = lookupEmoji(m.value)
            if (res != null) {
              val id = "emoji_$res"
              used[id] = res
              appendInlineContent(id, m.value.removeSuffix("\uFE0F"))
            } else {
              append(m.value)
            }
            last = m.range.last + 1
          }
          if (last < text.length) append(text.substring(last))
        }
      annotated to used.toMap()
    }
  val inline =
    built.second.mapValues { (_, res) ->
      InlineTextContent(
        Placeholder(width = size, height = size, placeholderVerticalAlign = PlaceholderVerticalAlign.TextCenter)
      ) {
        Image(painter = painterResource(res), contentDescription = null, modifier = Modifier.fillMaxSize())
      }
    }
  Text(
    text = built.first,
    inlineContent = inline,
    style = style,
    color = color,
    modifier = modifier,
    maxLines = maxLines,
    overflow = overflow,
    onTextLayout = onTextLayout ?: {},
  )
}

/** Emoji picker: the 11 webp emojis, centred in rows of 6, large touch targets. */
@Composable
fun TelegramEmojiPanel(onPickEmoji: (String) -> Unit) {
  Column(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
        .background(Color(0xF00B1120))
        .padding(horizontal = 12.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    EmojiPack.chunked(6).forEach { row ->
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
      ) {
        row.forEach { e ->
          Box(
            modifier =
              Modifier.size(52.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color.White.copy(alpha = 0.05f))
                .clickable { onPickEmoji(e.unicode) },
            contentAlignment = Alignment.Center,
          ) {
            Image(
              painter = painterResource(e.res),
              contentDescription = e.unicode,
              modifier = Modifier.size(40.dp),
            )
          }
        }
      }
    }
  }
}

// Two em spaces reserve the slot the webp is drawn over inside the input box.
private const val EmojiSlot = "\u2003\u2003"

/**
 * Input-field helper: swaps every pack emoji for [EmojiSlot] so caret/selection stay aligned,
 * while [EmojiInputOverlay] draws the webp images on top of those slots.
 */
object EmojiVisualTransformation : VisualTransformation {
  override fun filter(text: AnnotatedString): TransformedText {
    val src = text.text
    val sb = StringBuilder()
    val toTransformed = IntArray(src.length + 1)
    val toOriginal = ArrayList<Int>(src.length + 2)
    var last = 0
    fun copyPlain(from: Int, to: Int) {
      for (i in from until to) {
        toTransformed[i] = sb.length
        toOriginal.add(i)
        sb.append(src[i])
      }
    }
    EmojiRegex.findAll(src).forEach { m ->
      copyPlain(last, m.range.first)
      toTransformed[m.range.first] = sb.length
      for (k in EmojiSlot.indices) toOriginal.add(m.range.first)
      sb.append(EmojiSlot)
      for (i in m.range.first + 1..m.range.last) toTransformed[i] = sb.length
      last = m.range.last + 1
    }
    copyPlain(last, src.length)
    toTransformed[src.length] = sb.length
    toOriginal.add(src.length)
    val mapping =
      object : OffsetMapping {
        override fun originalToTransformed(offset: Int) = toTransformed[offset.coerceIn(0, src.length)]
        override fun transformedToOriginal(offset: Int) = toOriginal[offset.coerceIn(0, toOriginal.size - 1)]
      }
    return TransformedText(AnnotatedString(sb.toString()), mapping)
  }
}

/** Draws [text] (with webp emojis) exactly over a BasicTextField that uses [EmojiVisualTransformation]. */
@Composable
fun EmojiInputOverlay(
  text: String,
  style: TextStyle,
  modifier: Modifier = Modifier,
) {
  val measurer = rememberTextMeasurer()
  val density = LocalDensity.current
  val slotWidth = remember(style) { with(density) { measurer.measure(EmojiSlot, style).size.width.toSp() } }
  val base = if (style.fontSize.isSpecified) style.fontSize else 14.sp
  val slotHeight = base * 1.75f
  val built =
    remember(text) {
      val used = linkedMapOf<String, Int>()
      var n = 0
      val annotated =
        buildAnnotatedString {
          var last = 0
          EmojiRegex.findAll(text).forEach { m ->
            if (m.range.first > last) append(text.substring(last, m.range.first))
            val res = lookupEmoji(m.value)
            if (res != null) {
              val id = "slot_${n++}"
              used[id] = res
              appendInlineContent(id, " ")
            } else {
              append(m.value)
            }
            last = m.range.last + 1
          }
          if (last < text.length) append(text.substring(last))
        }
      annotated to used.toMap()
    }
  val inline =
    built.second.mapValues { (_, res) ->
      InlineTextContent(
        Placeholder(width = slotWidth, height = slotHeight, placeholderVerticalAlign = PlaceholderVerticalAlign.TextCenter)
      ) {
        Image(painter = painterResource(res), contentDescription = null, modifier = Modifier.fillMaxSize())
      }
    }
  Text(text = built.first, inlineContent = inline, style = style, modifier = modifier)
}
