#include "lockstep.h"
#include "log.h"
#include <algorithm>

namespace libretrodroid {

void Lockstep::start(int localPort_, int delayFrames_, int startFrame) {
    std::lock_guard<std::mutex> g(mu);
    localPort = localPort_ & 1;
    delayFrames = std::max(1, std::min(delayFrames_, 12)); // Kotlin clamps to 2..10
    currentFrame.store(startFrame, std::memory_order_relaxed);
    peerFrameMax.store(startFrame, std::memory_order_relaxed);
    stalls.store(0, std::memory_order_relaxed);
    desyncCount_.store(0, std::memory_order_relaxed);
    desyncDetected.store(false, std::memory_order_relaxed);
    stallMsTotal_.store(0, std::memory_order_relaxed);
    stallMsMax_.store(0, std::memory_order_relaxed);
    catchUps_.store(0, std::memory_order_relaxed);
    stallStartMs.store(0, std::memory_order_relaxed);
    sessionId.fetch_add(1, std::memory_order_relaxed);
    currentLocalMask = 0;
    wasStalled = false;

    sendQueue.clear();
    hashSendQueue.clear();
    localHashes.clear();
    peerHashes.clear();

    for (auto& s : ring) {
        s.masks[0] = s.masks[1] = 0;
        s.ready[0] = s.ready[1] = false;
    }

    // Pre-fill initial delay window [startFrame, startFrame + delayFrames)
    // with neutral input (0) on both ports so both sides start simultaneously.
    for (int i = 0; i < delayFrames; ++i) {
        int f = startFrame + i;
        auto& s = slotFor(f);
        s.masks[0] = s.masks[1] = 0;
        s.ready[0] = s.ready[1] = true;
    }

    // Schedule local inputs starting from startFrame + delayFrames
    nextScheduledFrame = startFrame + delayFrames;

    // Immediately schedule and queue local input for nextScheduledFrame
    auto& s0 = slotFor(nextScheduledFrame);
    s0.masks[localPort] = 0;
    s0.ready[localPort] = true;
    sendQueue.push_back({nextScheduledFrame, 0});
    nextScheduledFrame++;

    enabled.store(true, std::memory_order_release);
    LOGI("Lockstep started: session=%d port=%d delay=%d startFrame=%d nextScheduled=%d",
         sessionId.load(), localPort, delayFrames, startFrame, nextScheduledFrame);
}

void Lockstep::stop() {
    enabled.store(false, std::memory_order_release);
    std::lock_guard<std::mutex> g(mu);
    sendQueue.clear();
    hashSendQueue.clear();
    localHashes.clear();
    peerHashes.clear();
    wasStalled = false;
    LOGI("Lockstep stopped");
}

void Lockstep::setLocalMask(uint16_t mask) {
    if (!enabled.load(std::memory_order_acquire)) return;
    std::lock_guard<std::mutex> g(mu);
    currentLocalMask = mask;
}

void Lockstep::pushRemote(int f, uint16_t mask) {
    if (!enabled.load(std::memory_order_acquire)) return;

    // Reject stale packets from before current frame or packets outside valid ring window
    int cur = currentFrame.load(std::memory_order_relaxed);
    if (f < cur || f >= cur + RING - 1) {
        return;
    }

    int remotePort = 1 - localPort;
    {
        std::lock_guard<std::mutex> g(mu);
        cur = currentFrame.load(std::memory_order_relaxed);
        if (f < cur || f >= cur + RING - 1) return;

        auto& s = slotFor(f);
        s.masks[remotePort] = mask;
        s.ready[remotePort] = true;

        int pf = peerFrameMax.load(std::memory_order_relaxed);
        if (f + 1 > pf) {
            peerFrameMax.store(f + 1, std::memory_order_relaxed);
        }
    }
}

bool Lockstep::stepFrame(std::function<void(int port, uint16_t mask)> applyInput) {
    if (!enabled.load(std::memory_order_acquire)) return false;

    std::lock_guard<std::mutex> g(mu);
    int f = currentFrame.load(std::memory_order_relaxed);

    // Commit future local inputs up to f + delayFrames
    while (nextScheduledFrame <= f + delayFrames) {
        auto& s = slotFor(nextScheduledFrame);
        s.masks[localPort] = currentLocalMask;
        s.ready[localPort] = true;
        sendQueue.push_back({nextScheduledFrame, currentLocalMask});
        nextScheduledFrame++;
    }

    // Check if inputs for frame f are ready on BOTH ports
    auto& curSlot = slotFor(f);
    if (!curSlot.ready[0] || !curSlot.ready[1]) {
        // Count stall events (episodes), not individual draw attempts
        if (!wasStalled) {
            stalls.fetch_add(1, std::memory_order_relaxed);
            wasStalled = true;
            stallStartMs.store(nowMs(), std::memory_order_relaxed);
        }
        return false;
    }

    // Both inputs ready: close the stall episode (if any) and record how long it lasted
    if (wasStalled) {
        int64_t startedAt = stallStartMs.exchange(0, std::memory_order_relaxed);
        if (startedAt > 0) {
            int ms = static_cast<int>(nowMs() - startedAt);
            stallMsTotal_.fetch_add(ms, std::memory_order_relaxed);
            if (ms > stallMsMax_.load(std::memory_order_relaxed)) {
                stallMsMax_.store(ms, std::memory_order_relaxed);
            }
        }
    }
    wasStalled = false;

    // Apply inputs for this frame
    applyInput(0, curSlot.masks[0]);
    applyInput(1, curSlot.masks[1]);

    // Reset current slot
    curSlot.ready[0] = false;
    curSlot.ready[1] = false;
    curSlot.masks[0] = 0;
    curSlot.masks[1] = 0;

    // Advance frame counter
    currentFrame.store(f + 1, std::memory_order_relaxed);
    return true;
}

bool Lockstep::isBehindPeer() const {
    if (!enabled.load(std::memory_order_relaxed)) return false;
    int f = currentFrame.load(std::memory_order_relaxed);
    int peer = peerFrameMax.load(std::memory_order_relaxed);
    return (peer > f + delayFrames + 1);
}

std::vector<int32_t> Lockstep::takeSendQueue() {
    std::vector<int32_t> result;
    std::lock_guard<std::mutex> g(mu);
    if (sendQueue.empty()) return result;
    result.reserve(sendQueue.size() * 2);
    for (const auto& item : sendQueue) {
        result.push_back(item.frame);
        result.push_back(static_cast<int32_t>(item.mask));
    }
    sendQueue.clear();
    return result;
}

std::vector<int32_t> Lockstep::takeHashSendQueue() {
    std::vector<int32_t> result;
    std::lock_guard<std::mutex> g(mu);
    if (hashSendQueue.empty()) return result;
    result.reserve(hashSendQueue.size() * 2);
    for (const auto& item : hashSendQueue) {
        result.push_back(item.frame);
        result.push_back(static_cast<int32_t>(item.hash));
    }
    hashSendQueue.clear();
    return result;
}

void Lockstep::recordLocalHash(int f, uint32_t hash) {
    int interval = hashInterval.load(std::memory_order_relaxed);
    if (interval <= 0) return;

    std::lock_guard<std::mutex> g(mu);

    // Guard: ignore comparisons before hashInterval to prevent false desync on startup/recovery
    if (f < interval) return;

    // Peer hash for this frame already here (peer is slightly ahead): compare now and drop BOTH entries.
    // (Old code kept our local entry after a match, so a late/duplicate peer packet for the same frame label
    // could be compared against it long afterwards and raise a bogus DESYNC.)
    auto it = peerHashes.find(f);
    if (it != peerHashes.end()) {
        uint32_t peerH = it->second;
        peerHashes.erase(it);
        if (peerH != hash) {
            desyncCount_.fetch_add(1, std::memory_order_relaxed);
            desyncDetected.store(true, std::memory_order_relaxed);
            LOGE("Lockstep DESYNC on frame %d: local=0x%08X peer=0x%08X", f, hash, peerH);
        } else {
            LOGI("Lockstep SYNC verified on frame %d (hash 0x%08X)", f, hash);
        }
    } else {
        localHashes[f] = hash;
    }

    // Our hash always goes to the peer, whichever side compares first.
    hashSendQueue.push_back({f, hash});

    // Drop entries that can never be compared any more (older than 4 intervals behind).
    int threshold = f - 4 * interval;
    for (auto i = localHashes.begin(); i != localHashes.end(); ) {
        if (i->first < threshold) i = localHashes.erase(i); else ++i;
    }
    for (auto i = peerHashes.begin(); i != peerHashes.end(); ) {
        if (i->first < threshold) i = peerHashes.erase(i); else ++i;
    }
}

bool Lockstep::pushRemoteHash(int f, uint32_t hash) {
    int interval = hashInterval.load(std::memory_order_relaxed);
    if (interval <= 0) return false;

    std::lock_guard<std::mutex> g(mu);
    // Guard: ignore comparisons before hashInterval to prevent false desync on startup/recovery
    if (f < interval) return false;

    int cur = currentFrame.load(std::memory_order_relaxed);
    // A hash from the future beyond the input window, or far in the past, cannot belong to this run: ignore it.
    if (f > cur + RING || f < cur - 4 * interval) return false;

    auto it = localHashes.find(f);
    if (it != localHashes.end()) {
        uint32_t localH = it->second;
        localHashes.erase(it);
        if (localH != hash) {
            desyncCount_.fetch_add(1, std::memory_order_relaxed);
            desyncDetected.store(true, std::memory_order_relaxed);
            LOGE("Lockstep DESYNC on frame %d: local=0x%08X peer=0x%08X", f, localH, hash);
            return true;
        }
        LOGI("Lockstep SYNC verified on frame %d (hash 0x%08X)", f, hash);
        return false;
    }
    // We have not reached this frame yet: keep the peer hash until our own arrives (recordLocalHash compares it).
    peerHashes[f] = hash;
    return false;
}

std::vector<int32_t> Lockstep::stats() const {
    // Indexes 0..4 are used by older Kotlin code: keep their order, new fields only at the end.
    int64_t st = stallStartMs.load(std::memory_order_relaxed);
    int curStallMs = st > 0 ? static_cast<int>(nowMs() - st) : 0;
    return {
        currentFrame.load(std::memory_order_relaxed),
        peerFrameMax.load(std::memory_order_relaxed),
        stalls.load(std::memory_order_relaxed),
        delayFrames,
        desyncCount_.load(std::memory_order_relaxed),
        stallMsTotal_.load(std::memory_order_relaxed),  // 5: total ms spent waiting for the peer
        stallMsMax_.load(std::memory_order_relaxed),    // 6: longest finished stall (ms)
        curStallMs,                                     // 7: current stall length (0 = not stalled)
        catchUps_.load(std::memory_order_relaxed)       // 8: double-step catch-up count
    };
}

} // namespace libretrodroid
