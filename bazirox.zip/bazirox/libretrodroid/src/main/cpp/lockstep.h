#pragma once

#include <cstdint>
#include <array>
#include <vector>
#include <unordered_map>
#include <atomic>
#include <mutex>
#include <functional>
#include <chrono>

namespace libretrodroid {

class Lockstep {
public:
    static constexpr int RING = 2048; // Buffer size (power of 2)

    Lockstep() = default;

    void start(int localPort, int delayFrames, int startFrame);
    void stop();

    bool isEnabled() const { return enabled.load(std::memory_order_relaxed); }

    void setHashInterval(int interval) { hashInterval.store(interval, std::memory_order_relaxed); }
    int getHashInterval() const { return hashInterval.load(std::memory_order_relaxed); }

    void setLocalMask(uint16_t mask);
    void pushRemote(int frame, uint16_t mask);

    /**
     * Executes one frame if both local and remote inputs are ready.
     * Commits future local inputs for (currentFrame + delayFrames).
     * If ready: invokes applyInput(port, mask) for each port, advances currentFrame, and returns true.
     * If stalled: returns false (no emulation step should be performed).
     */
    bool stepFrame(std::function<void(int port, uint16_t mask)> applyInput);

    /** True if local player is behind peer and can execute a catch-up step. */
    bool isBehindPeer() const;

    /** Drains all pending local inputs [frame0, mask0, frame1, mask1, ...] to send to peer. */
    std::vector<int32_t> takeSendQueue();

    /** Drains all pending state hashes [frame0, hash0, frame1, hash1, ...] to send to peer. */
    std::vector<int32_t> takeHashSendQueue();

    /** Records local state hash calculated at frame boundary. */
    void recordLocalHash(int frame, uint32_t hash);

    /** Pushes remote state hash received from peer. Returns true if desync detected. */
    bool pushRemoteHash(int frame, uint32_t hash);

    bool isDesyncDetected() const { return desyncDetected.load(std::memory_order_relaxed); }
    int desyncCount() const { return desyncCount_.load(std::memory_order_relaxed); }
    int localFrame() const { return currentFrame.load(std::memory_order_relaxed); }
    int peerFrame() const { return peerFrameMax.load(std::memory_order_relaxed); }
    int stallCount() const { return stalls.load(std::memory_order_relaxed); }
    int delay() const { return delayFrames; }
    int currentSessionId() const { return sessionId.load(std::memory_order_relaxed); }

    /** Diagnostics: counts a step where this side ran two frames to catch up with the peer. */
    void noteCatchUp() { catchUps_.fetch_add(1, std::memory_order_relaxed); }

    std::vector<int32_t> stats() const;

private:
    struct Slot {
        uint16_t masks[2] = {0, 0};
        bool ready[2] = {false, false};
    };

    struct SendItem {
        int32_t frame;
        uint16_t mask;
    };

    struct HashItem {
        int32_t frame;
        uint32_t hash;
    };

    std::array<Slot, RING> ring{};
    mutable std::mutex mu;

    std::atomic<bool> enabled{false};
    std::atomic<int> currentFrame{0};
    std::atomic<int> peerFrameMax{0};
    std::atomic<int> stalls{0};
    std::atomic<int> desyncCount_{0};
    std::atomic<bool> desyncDetected{false};
    std::atomic<int> sessionId{0};
    std::atomic<int> hashInterval{300};

    // Stall diagnostics: how long we waited for the peer's input (steady clock, ms).
    std::atomic<int> stallMsTotal_{0};
    std::atomic<int> stallMsMax_{0};
    std::atomic<int> catchUps_{0};
    std::atomic<int64_t> stallStartMs{0}; // 0 = not stalled right now

    static int64_t nowMs() {
        return std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
    }

    int localPort = 0;
    int delayFrames = 3;
    uint16_t currentLocalMask = 0;
    int nextScheduledFrame = 0;
    bool wasStalled = false;

    std::vector<SendItem> sendQueue;
    std::vector<HashItem> hashSendQueue;

    std::unordered_map<int, uint32_t> localHashes;
    std::unordered_map<int, uint32_t> peerHashes;

    Slot& slotFor(int f) {
        return ring[((f % RING) + RING) % RING];
    }
};

} // namespace libretrodroid
