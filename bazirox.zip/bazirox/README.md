# Bazirox - Development Status & Messenger Overhaul

Bazirox is a secure multiplayer game and encrypted chat platform built with Android (Jetpack Compose) and a PHP/MySQL backend.

---

## ✅ Completed Work (100%)

### 1. Server-side API Enhancements (`public/api.php`)
- **Automatic Schema Migration (`last_seen`)**:
  - Implemented `ensureLastSeenColumn(PDO $db)` to automatically add `last_seen BIGINT NOT NULL DEFAULT 0` to the `users` table without needing manual database schema modifications.
- **Automatic Presence Tracking (`touchUserPresence`)**:
  - Automatically updates the user's `last_seen` timestamp on every authenticated request (sending messages, listing messages, syncing groups, posting scores, etc.).
- **Presence Ping Action (`presence_ping`)**:
  - Added lightweight ping endpoint so active messenger clients stay marked as online without incurring heavy MySQL read/write overhead.
- **Presence Metadata in API Responses**:
  - `groups_list`: Returns `presence: { username: last_seen_ms }` and `server_time_ms`.
  - `messages_list`: Returns member presence mappings.
  - `profile_get`: Returns the user's exact `last_seen` timestamp.

### 2. Client Data Layer (`app/src/main/java/com/example/data/`)
- **Models (`Models.kt`)**:
  - Added `lastSeen: Long` to `UserProfile`.
  - Extended `MessagesPage` with `val presence: Map<String, Long> = emptyMap()`.
- **API Client (`CPanelApiClient.kt`)**:
  - Added support for parsing presence maps and `last_seen` fields from server responses.
  - Implemented `pingPresence()` method.
- **Repository (`MainRepository.kt`)**:
  - Added `@Volatile var lastPresence: Map<String, Long>`.
  - Integrated `pingPresence()` and cached presence updating in `getChatGroupsImpl` and `getMessagesImpl`.

### 3. ViewModel & State Management (`MainViewModel.kt` & `AppUiState`)
- **Presence State Tracking**:
  - Stored `userPresence: Map<String, Long>` inside `AppUiState`.
  - Periodically dispatch `pingPresence()` every 60 seconds whenever the chat tab or active conversation is visible.
  - Presence polling cleanly stops when switching away from chat or logging out.
  - Merged presence timestamps whenever `refreshGroups()`, `openGroupChat()`, or `startChatPolling()` completes.

### 4. Messenger UI & UX Modernization (`ChatScreen.kt` & `MainActivity.kt`)
- **Dynamic Online Indicator**:
  - Replaced legacy static green dot in `TelegramChatListRow` with `isUserOnline(lastSeenMs)` (< 2.5 minutes / 150,000 ms threshold).
- **Conversation Header Presence**:
  - **Direct Messages (PV / DM)**: Persian presence status ("آنلاین", "آخرین بازدید لحظاتی پیش", "آخرین بازدید X دقیقه پیش", "آخرین بازدید امروز در HH:mm", "آخرین بازدید دیروز در HH:mm", or date).
  - **Group Chats**: Shows total member count and active online count (e.g. `۵ عضو • ۳ نفر آنلاین`).
- **Visual Polish & Styling**:
  - Polished message composer bar with sleek frosted container, glowing cyan reply preview bar, and vibrant gradient send button with active border stroke.
  - Refined message bubble corners, spacing, and subtle borders.
  - Wired `userPresence` through `MainActivity.kt` into `ChatScreen`.

---

*Updated: November 2026*
