<?php
/*
 * Bazirox API gateway with Live Presence / Online Tracking & Modern Messenger support.
 * Configuration is read from a private .env file (see .env.example), never from this file.
 */
ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);
mb_internal_encoding('UTF-8');
header_remove('X-Powered-By');
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'");
header('Cache-Control: no-store, max-age=0');
header('X-Robots-Tag: noindex, nofollow');

function envLoad(): array {
    $_e1 = [];
    $_e2 = [];
    $_e3 = getenv('BAZIROX_ENV_FILE');
    if (is_string($_e3) && $_e3 !== '') $_e2[] = $_e3;
    $_e4 = (string)($_SERVER['DOCUMENT_ROOT'] ?? '');
    if ($_e4 !== '') $_e2[] = dirname($_e4) . '/.env';
    $_e2[] = __DIR__ . '/.env';
    foreach ($_e2 as $_e5) {
        if (!@is_file($_e5) || !@is_readable($_e5)) continue;
        $_e6 = @file($_e5, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($_e6 === false) continue;
        foreach ($_e6 as $_e7) {
            $_e7 = trim(ltrim($_e7, "\xEF\xBB\xBF"));
            if ($_e7 === '' || $_e7[0] === '#') continue;
            if (strncmp($_e7, 'export ', 7) === 0) $_e7 = ltrim(substr($_e7, 7));
            $_e8 = strpos($_e7, '=');
            if ($_e8 === false || $_e8 < 1) continue;
            $_e9 = trim(substr($_e7, 0, $_e8));
            $_ea = trim(substr($_e7, $_e8 + 1));
            $_eb = strlen($_ea);
            if ($_eb >= 2 && (($_ea[0] === '"' && $_ea[$_eb - 1] === '"') || ($_ea[0] === "'" && $_ea[$_eb - 1] === "'"))) {
                $_ea = substr($_ea, 1, -1);
            }
            $_e1[$_e9] = $_ea;
        }
        break;
    }
    return $_e1;
}

function envBool(array $_e1, string $_e9, bool $_ec): bool {
    if (!isset($_e1[$_e9]) || $_e1[$_e9] === '') return $_ec;
    $_ed = filter_var($_e1[$_e9], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
    return $_ed === null ? $_ec : $_ed;
}

function envInt(array $_e1, string $_e9, int $_ec, int $_ee, int $_ef): int {
    if (!isset($_e1[$_e9]) || !preg_match('/^[0-9]{1,10}$/', $_e1[$_e9])) return $_ec;
    return max($_ee, min($_ef, (int)$_e1[$_e9]));
}

$_eE = envLoad();
$_eM = [];
foreach (['DB_HOST', 'DB_NAME', 'DB_USER', 'API_SECRET'] as $_e9) {
    if (!isset($_eE[$_e9]) || $_eE[$_e9] === '') $_eM[] = $_e9;
}
if (!array_key_exists('DB_PASS', $_eE)) $_eM[] = 'DB_PASS';
if (isset($_eE['API_SECRET']) && strlen($_eE['API_SECRET']) < 24) $_eM[] = 'API_SECRET(length)';
if ($_eM) {
    error_log('bazirox: invalid configuration: ' . implode(', ', $_eM));
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'پیکربندی سرور ناقص است'], JSON_UNESCAPED_UNICODE);
    exit;
}

define('DB_HOST', $_eE['DB_HOST']);
define('DB_NAME', $_eE['DB_NAME']);
define('DB_USER', $_eE['DB_USER']);
define('DB_PASS', $_eE['DB_PASS']);
define('API_SECRET', $_eE['API_SECRET']);
define('ENABLE_HMAC', envBool($_eE, 'ENABLE_HMAC', true));
define('ENABLE_TRANSPORT_ENC', envBool($_eE, 'ENABLE_TRANSPORT_ENC', true));
define('MAINTENANCE_MODE', envBool($_eE, 'MAINTENANCE_MODE', false));
define('ADMIN_GATE_ENABLED', envBool($_eE, 'ADMIN_GATE_ENABLED', true));
define('SESSION_TTL', envInt($_eE, 'SESSION_TTL', 2592000, 3600, 31536000));
define('MAX_BODY', envInt($_eE, 'MAX_BODY', 12000000, 100000, 50000000));
define('REG_LIMIT_PER_HOUR', envInt($_eE, 'REG_LIMIT_PER_HOUR', 10, 1, 1000));
define('SCORE_MAX_DELTA', envInt($_eE, 'SCORE_MAX_DELTA', 60, 1, 1000));
define('SCORE_MIN_INTERVAL', envInt($_eE, 'SCORE_MIN_INTERVAL', 10, 0, 3600));
unset($_eE, $_eM, $_e9);

function aesKey(): string {
    return hash('sha256', 'BaziLand_AES256_Key:' . API_SECRET, true);
}

function decryptPayload(string $_2): ?string {
    $_2d = base64_decode($_2, true);
    if ($_2d === false || strlen($_2d) <= 28) return null;
    $_19 = substr($_2d, 0, 12);
    $_3c = substr($_2d, 12, 16);
    $_5 = substr($_2d, 28);
    $_29 = openssl_decrypt($_5, 'aes-256-gcm', aesKey(), OPENSSL_RAW_DATA, $_19, $_3c);
    return $_29 === false ? null : $_29;
}

function encryptPayload(string $_29): string {
    $_19 = random_bytes(12);
    $_3c = '';
    $_5 = openssl_encrypt($_29, 'aes-256-gcm', aesKey(), OPENSSL_RAW_DATA, $_19, $_3c, '', 16);
    return base64_encode($_19 . $_3c . $_5);
}

function sendJson(array $_26, int $_7 = 200): void {
    http_response_code($_7);
    $_1a = json_encode($_26, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    if (ENABLE_TRANSPORT_ENC) {
        echo json_encode(['enc' => encryptPayload($_1a)]);
    } else {
        echo $_1a;
    }
    exit;
}

function fail(string $_20, int $_7 = 400): void {
    sendJson(['ok' => false, 'error' => $_20], $_7);
}

function nowMs(): int {
    return (int) round(microtime(true) * 1000);
}

function str($_48, int $_1c): string {
    if (!is_string($_48)) return '';
    return mb_substr(trim($_48), 0, $_1c);
}

function passwordAlgo() {
    return defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
}

set_exception_handler(function (Throwable $_d): void {
    error_log('bazirox: ' . get_class($_d) . ': ' . $_d->getMessage());
    sendJson(['ok' => false, 'error' => 'خطای داخلی سرور'], 500);
});

$_em = (string)($_SERVER['REQUEST_METHOD'] ?? 'GET');
if ($_em !== 'POST' && $_em !== 'GET') fail('Method not allowed', 405);
if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > MAX_BODY) fail('Payload too large', 413);
if (MAINTENANCE_MODE && ($_GET['action'] ?? '') !== 'ping') {
    fail('سرور در حال بروزرسانی است', 503);
}

$_2e = file_get_contents('php://input');
if ($_2e === false) $_2e = '';
if (strlen($_2e) > MAX_BODY) fail('Payload too large', 413);
$_1 = (string)($_GET['action'] ?? '');
$_40 = (int)($_SERVER['HTTP_X_BAZILAND_TIMESTAMP'] ?? 0);
$_22 = (string)($_SERVER['HTTP_X_BAZILAND_NONCE'] ?? '');
$_35 = (string)($_SERVER['HTTP_X_BAZILAND_SIGNATURE'] ?? '');
if (ENABLE_HMAC) {
    if (abs(time() - $_40) > 120 || $_22 === '' || strlen($_22) > 64 || $_35 === '') {
        fail('Invalid security timestamp/nonce', 401);
    }
    $_f = hash_hmac('sha256', $_1 . '|' . $_40 . '|' . $_22 . '|' . $_2e, API_SECRET);
    if (!hash_equals($_f, $_35)) fail('Invalid HMAC signature', 403);
}

$_30 = json_decode($_2e, true);
if (!is_array($_30)) $_30 = [];
if (isset($_30['enc'])) {
    if (!ENABLE_TRANSPORT_ENC) fail('Encryption is disabled on this server', 400);
    $_a = is_string($_30['enc']) ? decryptPayload($_30['enc']) : null;
    if ($_a === null) fail('Decrypt failed', 400);
    $_30 = json_decode($_a, true);
    if (!is_array($_30)) $_30 = [];
} elseif (ENABLE_TRANSPORT_ENC) {
    fail('Encrypted request required', 400);
}
$_9 = (isset($_30['data']) && is_array($_30['data'])) ? $_30['data'] : [];

if ($_1 === 'room_peek') {
    $_pc = cleanRoomCode($_9['room_code'] ?? '');
    $_p2 = @file_get_contents(roomTokPath($_pc));
    $_p3 = @file_get_contents(roomChatTokPath($_pc));
    sendJson(['ok' => true, 'tok' => $_p2 === false ? '' : $_p2, 'ctok' => $_p3 === false ? '' : $_p3]);
}

try {
    $_27 = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (Throwable $_d) {
    sendJson(['ok' => false, 'db_ok' => false, 'error' => 'خطا در اتصال به MySQL'], 500);
}

if (ENABLE_HMAC) {
    try {
        $_27->prepare('INSERT INTO api_nonces (nonce, ts) VALUES (?, ?)')->execute([$_22, time()]);
    } catch (PDOException $_d) {
        if ((int)($_d->errorInfo[1] ?? 0) === 1062) fail('Replay detected', 409);
        sendJson(['ok' => false, 'db_ok' => false, 'error' => 'جدول‌های دیتابیس نصب نشده‌اند (schema.sql را اجرا کن)'], 500);
    }
    if (random_int(1, 50) === 1) {
        try { $_27->prepare('DELETE FROM api_nonces WHERE ts < ?')->execute([time() - 600]); } catch (Throwable $_d) {}
    }
}

function ensureLastSeenColumn(PDO $_27): void {
    static $done = false;
    if ($done) return;
    try {
        $_c = $_27->query("SHOW COLUMNS FROM users LIKE 'last_seen'")->fetch();
        if (!$_c) {
            $_27->exec("ALTER TABLE users ADD COLUMN last_seen BIGINT NOT NULL DEFAULT 0");
        }
        $done = true;
    } catch (Throwable $_d) {}
}

function touchUserPresence(PDO $_27, int $userId): void {
    ensureLastSeenColumn($_27);
    try {
        $_27->prepare('UPDATE users SET last_seen = ? WHERE id = ?')->execute([nowMs(), $userId]);
    } catch (Throwable $_d) {}
}

function requireUser(PDO $_27, array $_30): array {
    $_3e = $_30['token'] ?? '';
    if (!is_string($_3e) || strlen($_3e) < 32 || strlen($_3e) > 128) {
        fail('نشست نامعتبر است، دوباره وارد شوید', 401);
    }
    $_37 = $_27->prepare('SELECT u.id, u.username, u.display_name, u.avatar_color FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?');
    $_37->execute([hash('sha256', $_3e), time()]);
    $_43 = $_37->fetch();
    if (!$_43) fail('نشست نامعتبر است، دوباره وارد شوید', 401);
    touchUserPresence($_27, (int)$_43['id']);
    return $_43;
}

function issueSession(PDO $_27, int $_46): string {
    $_3e = bin2hex(random_bytes(32));
    $_27->prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)')
        ->execute([hash('sha256', $_3e), $_46, time() + SESSION_TTL]);
    touchUserPresence($_27, $_46);
    if (random_int(1, 20) === 1) {
        try { $_27->prepare('DELETE FROM sessions WHERE expires_at < ?')->execute([time()]); } catch (Throwable $_d) {}
    }
    return $_3e;
}

function userOut(array $_43): array {
    return [
        'username' => $_43['username'],
        'display_name' => $_43['display_name'],
        'avatar_color' => (int)($_43['avatar_color'] ?? 0),
        'total_score' => (int)($_43['total_score'] ?? 0),
        'wins' => (int)($_43['wins'] ?? 0),
        'games_played' => (int)($_43['games_played'] ?? 0),
    ];
}

function isMember(PDO $_27, string $_12, string $_47): bool {
    $_37 = $_27->prepare('SELECT 1 FROM chat_members WHERE group_id = ? AND username = ?');
    $_37->execute([$_12, $_47]);
    return (bool)$_37->fetchColumn();
}

function groupOut(PDO $_27, array $_11): array {
    $_37 = $_27->prepare('SELECT username FROM chat_members WHERE group_id = ? ORDER BY joined_at');
    $_37->execute([$_11['id']]);
    return [
        'id' => $_11['id'],
        'name' => $_11['name'],
        'invite_code' => $_11['invite_code'],
        'owner_username' => $_11['owner_username'],
        'members' => $_37->fetchAll(PDO::FETCH_COLUMN),
        'last_message' => $_11['last_message'],
        'last_time' => (int)$_11['last_time'],
        'description' => (string)($_11['description'] ?? ''),
        'dm_origin' => (string)($_11['dm_origin'] ?? ''),
    ];
}

function deleteGroupData(PDO $_27, string $_12): void {
    foreach (['chat_messages', 'chat_reads', 'chat_members'] as $_g0) {
        $_27->prepare('DELETE FROM ' . $_g0 . ' WHERE group_id = ?')->execute([$_12]);
    }
    try { $_27->prepare('DELETE FROM chat_join_requests WHERE group_id = ?')->execute([$_12]); } catch (Throwable $_d) {}
    $_27->prepare('DELETE FROM chat_groups WHERE id = ?')->execute([$_12]);
}

function ensureJoinRequestsTable(PDO $_27): void {
    $_27->exec("CREATE TABLE IF NOT EXISTS chat_join_requests (group_id VARCHAR(40) NOT NULL, username VARCHAR(32) NOT NULL, requested_at BIGINT NOT NULL DEFAULT 0, PRIMARY KEY (group_id, username)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function ensureGroupDescColumn(PDO $_27): void {
    try {
        $_c = $_27->query("SHOW COLUMNS FROM chat_groups LIKE 'description'")->fetch();
        if (!$_c) { $_27->exec("ALTER TABLE chat_groups ADD COLUMN description TEXT NULL"); }
    } catch (Throwable $_d) {}
}

function ensureBioColumn(PDO $_27): void {
    try {
        $_c = $_27->query("SHOW COLUMNS FROM users LIKE 'bio'")->fetch();
        if (!$_c) { $_27->exec("ALTER TABLE users ADD COLUMN bio VARCHAR(400) NOT NULL DEFAULT ''"); }
    } catch (Throwable $_d) {}
}

function ensureDmColumn(PDO $_27): void {
    try {
        $_c = $_27->query("SHOW COLUMNS FROM chat_groups LIKE 'dm_origin'")->fetch();
        if (!$_c) { $_27->exec("ALTER TABLE chat_groups ADD COLUMN dm_origin VARCHAR(40) NULL"); }
    } catch (Throwable $_d) {}
}

function roomOut(array $_2c): array {
    $_2a = json_decode($_2c['players_json'], true);
    return [
        'room_code' => $_2c['room_code'],
        'game_type' => $_2c['game_type'],
        'host_username' => $_2c['host_username'],
        'players' => is_array($_2a) ? $_2a : [],
        'status' => $_2c['status'],
        'version' => (int)$_2c['version'],
        'state_json' => $_2c['state_json'],
    ];
}

function roomTokPath(string $_7): string {
    return rtrim(sys_get_temp_dir(), '/') . '/bzr_' . md5(API_SECRET . '|' . $_7);
}

function roomTokTouch(string $_7): void {
    @file_put_contents(roomTokPath($_7), microtime(true) . '|' . mt_rand(), LOCK_EX);
    if (mt_rand(1, 300) === 1) {
        foreach ((array)@glob(rtrim(sys_get_temp_dir(), '/') . '/bzr_*') as $_p1) {
            if (@filemtime($_p1) < time() - 86400) @unlink($_p1);
        }
    }
}

function ensureRoomChatTable(PDO $_27): void {
    $_27->exec("CREATE TABLE IF NOT EXISTS room_chat (id VARCHAR(48) NOT NULL PRIMARY KEY, room_code VARCHAR(16) NOT NULL, sender_username VARCHAR(32) NOT NULL, text VARCHAR(600) NOT NULL, ts BIGINT NOT NULL, INDEX idx_rc_room (room_code, ts)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function roomChatTokPath(string $_7): string {
    return rtrim(sys_get_temp_dir(), '/') . '/bzc_' . md5(API_SECRET . '|c|' . $_7);
}

function roomChatTokTouch(string $_7): void {
    @file_put_contents(roomChatTokPath($_7), microtime(true) . '|' . mt_rand(), LOCK_EX);
    if (mt_rand(1, 300) === 1) {
        foreach ((array)@glob(rtrim(sys_get_temp_dir(), '/') . '/bzc_*') as $_p1) {
            if (@filemtime($_p1) < time() - 86400) @unlink($_p1);
        }
    }
}

function roomPlayersOf(PDO $_27, string $_7, string $_u): array {
    $_37 = $_27->prepare('SELECT players_json FROM game_rooms WHERE room_code = ?');
    $_37->execute([$_7]);
    $_2c = $_37->fetch();
    if (!$_2c) fail('اتاق پیدا نشد', 404);
    $_2a = json_decode($_2c['players_json'], true);
    if (!is_array($_2a) || !in_array($_u, $_2a, true)) fail('شما عضو این اتاق نیستید', 403);
    return $_2a;
}

function ensureAvatarTable(PDO $_27): void {
    $_27->exec("CREATE TABLE IF NOT EXISTS user_avatars (username VARCHAR(32) NOT NULL PRIMARY KEY, ver BIGINT NOT NULL DEFAULT 0, image MEDIUMTEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function cleanRoomCode($_48): string {
    $_7 = strtoupper(str($_48, 16));
    if (!preg_match('/^[A-Z0-9]{6,16}$/', $_7)) fail('کد اتاق نامعتبر است', 400);
    return $_7;
}

$_0 = ['ludo', 'tictactoe', 'connect4', 'snakes', 'guess', 'rps'];

switch ($_1) {
    case 'ping':
        sendJson(['ok' => true, 'db_ok' => true, 'message' => 'هاست ایران متصل و امن است', 'server_time' => date('c'), 'now_ms' => nowMs()]);

    case 'register':
        $_43 = str($_9['username'] ?? '', 32);
        $_28 = $_9['password_hash'] ?? '';
        $_b = str($_9['display_name'] ?? '', 64);
        if ($_b === '') $_b = $_43;
        $_8 = max(0, min(31, (int)($_9['avatar_color'] ?? 0)));
        if (!preg_match('/^[\p{L}\p{N}_.-]{3,32}$/u', $_43)) fail('نام کاربری باید ۳ تا ۳۲ حرف یا عدد باشد', 400);
        if (!is_string($_28) || !preg_match('/^[0-9a-f]{64}$/', $_28)) fail('ورودی نامعتبر', 400);
        $_18 = substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
        $_r1 = $_27->prepare('SELECT COUNT(*) FROM login_fails WHERE username = ? AND ip = ? AND ts > ?');
        $_r1->execute(['@register', $_18, time() - 3600]);
        if ((int)$_r1->fetchColumn() >= REG_LIMIT_PER_HOUR) fail('تعداد ثبت‌نام از این شبکه زیاد است؛ بعداً دوباره امتحان کن', 429);
        $_27->prepare('INSERT INTO login_fails (username, ip, ts) VALUES (?, ?, ?)')->execute(['@register', $_18, time()]);
        $_37 = $_27->prepare('SELECT id FROM users WHERE username = ?');
        $_37->execute([$_43]);
        if ($_37->fetch()) fail('نام کاربری تکراری است', 409);
        $_14 = password_hash($_28, passwordAlgo());
        ensureLastSeenColumn($_27);
        try {
            $_27->prepare('INSERT INTO users (username, display_name, password_hash, avatar_color, last_seen) VALUES (?, ?, ?, ?, ?)')
                ->execute([$_43, $_b, $_14, $_8, nowMs()]);
        } catch (PDOException $_d) {
            fail('نام کاربری تکراری است', 409);
        }
        $_44 = (int)$_27->lastInsertId();
        $_3e = issueSession($_27, $_44);
        sendJson(['ok' => true, 'token' => $_3e, 'user' => userOut(['username' => $_43, 'display_name' => $_b, 'avatar_color' => $_8])]);

    case 'login':
        $_43 = str($_9['username'] ?? '', 32);
        $_28 = $_9['password_hash'] ?? '';
        $_18 = substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
        $_36 = time() - 900;
        $_3 = $_27->prepare('SELECT COUNT(*) FROM login_fails WHERE username = ? AND ts > ?');
        $_3->execute([$_43, $_36]);
        $_4 = $_27->prepare('SELECT COUNT(*) FROM login_fails WHERE ip = ? AND ts > ?');
        $_4->execute([$_18, $_36]);
        if ((int)$_3->fetchColumn() >= 8 || (int)$_4->fetchColumn() >= 60) {
            fail('تلاش‌های ناموفق زیاد است؛ چند دقیقه بعد دوباره امتحان کن', 429);
        }
        $_37 = $_27->prepare('SELECT id, username, display_name, avatar_color, total_score, wins, games_played, password_hash FROM users WHERE username = ?');
        $_37->execute([$_43]);
        $_31 = $_37->fetch();
        $_49 = is_string($_28) && preg_match('/^[0-9a-f]{64}$/', $_28);
        if ($_31 && $_49 && password_verify($_28, $_31['password_hash'])) {
            try { $_27->prepare('DELETE FROM login_fails WHERE username = ?')->execute([$_43]); } catch (Throwable $_d) {}
            $_3e = issueSession($_27, (int)$_31['id']);
            sendJson(['ok' => true, 'token' => $_3e, 'user' => userOut($_31)]);
        }
        if (!$_31) password_hash(is_string($_28) ? $_28 : '', passwordAlgo());
        try {
            $_27->prepare('INSERT INTO login_fails (username, ip, ts) VALUES (?, ?, ?)')->execute([$_43, $_18, time()]);
            if (random_int(1, 20) === 1) $_27->prepare('DELETE FROM login_fails WHERE ts < ?')->execute([time() - 86400]);
        } catch (Throwable $_d) {}
        fail('نام کاربری یا رمز عبور اشتباه است', 401);

    case 'admin_gate':
        if (!ADMIN_GATE_ENABLED) fail('غیرفعال است', 403);
        $_28 = $_9['password_hash'] ?? '';
        if (!is_string($_28) || !preg_match('/^[0-9a-f]{64}$/', $_28)) fail('ورودی نامعتبر', 400);
        $_27->exec("CREATE TABLE IF NOT EXISTS admin_gate (id TINYINT NOT NULL PRIMARY KEY, password_hash VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $_18 = substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
        $_36 = time() - 900;
        $_3 = $_27->prepare('SELECT COUNT(*) FROM login_fails WHERE username = ? AND ip = ? AND ts > ?');
        $_3->execute(['@admin_gate', $_18, $_36]);
        if ((int)$_3->fetchColumn() >= 5) fail('تلاش‌های ناموفق زیاد است؛ چند دقیقه بعد دوباره امتحان کن', 429);
        $_37 = $_27->prepare('SELECT password_hash FROM admin_gate WHERE id = 1');
        $_37->execute();
        $_31 = $_37->fetch();
        if (!$_31) {
            try {
                $_27->prepare('INSERT INTO admin_gate (id, password_hash) VALUES (1, ?)')->execute([password_hash($_28, passwordAlgo())]);
            } catch (PDOException $_d) {
                fail('تلاش مجدد', 409);
            }
            sendJson(['ok' => true, 'created' => true]);
        }
        if (password_verify($_28, $_31['password_hash'])) {
            try { $_27->prepare('DELETE FROM login_fails WHERE username = ? AND ip = ?')->execute(['@admin_gate', $_18]); } catch (Throwable $_d) {}
            sendJson(['ok' => true, 'created' => false]);
        }
        try {
            $_27->prepare('INSERT INTO login_fails (username, ip, ts) VALUES (?, ?, ?)')->execute(['@admin_gate', $_18, time()]);
        } catch (Throwable $_d) {}
        fail('نام کاربری یا رمز عبور اشتباه است', 401);

    case 'submit_score':
        $_1f = requireUser($_27, $_30);
        $_c = max(0, min(SCORE_MAX_DELTA, (int)($_9['delta_score'] ?? 0)));
        $_4b = !empty($_9['did_win']) ? 1 : 0;
        $_13 = (string)($_9['game_type'] ?? 'ludo');
        if (!in_array($_13, $_0, true)) $_13 = 'ludo';
        $_23 = time();
        $_45 = $_27->prepare('UPDATE users SET total_score = GREATEST(0, total_score + ?), wins = wins + ?, games_played = games_played + 1, favorite_game = ?, last_submit = ? WHERE id = ? AND last_submit < ?');
        $_45->execute([$_c, $_4b, $_13, $_23, $_1f['id'], $_23 - SCORE_MIN_INTERVAL]);
        sendJson(['ok' => true]);

    case 'leaderboard':
        requireUser($_27, $_30);
        ensureLastSeenColumn($_27);
        $_32 = $_27->query('SELECT username, display_name, avatar_color, total_score, wins, games_played, favorite_game, last_seen FROM users ORDER BY total_score DESC, wins DESC LIMIT 50')->fetchAll();
        sendJson(['ok' => true, 'entries' => $_32]);

    case 'group_create':
        $_1f = requireUser($_27, $_30);
        $_21 = $_9['name'] ?? '';
        if (!is_string($_21) || $_21 === '' || strlen($_21) > 600) fail('نام گروه نامعتبر است', 400);
        $_6 = $_27->prepare("SELECT COUNT(*) FROM chat_groups WHERE owner_username = ? AND SUBSTRING(id, 1, 3) <> 'dm_'");
        $_6->execute([$_1f['username']]);
        if ((int)$_6->fetchColumn() >= 30) fail('تعداد گروه‌های ساخته‌شده به سقف رسیده است', 429);
        $_12 = 'grp_' . bin2hex(random_bytes(6));
        $_7 = strtoupper(bin2hex(random_bytes(5)));
        $_3b = nowMs();
        $_27->prepare('INSERT INTO chat_groups (id, name, invite_code, owner_username, last_message, last_time) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$_12, $_21, $_7, $_1f['username'], '', $_3b]);
        $_27->prepare('INSERT INTO chat_members (group_id, username, joined_at) VALUES (?, ?, ?)')
            ->execute([$_12, $_1f['username'], $_3b]);
        $_11 = $_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
        $_11->execute([$_12]);
        sendJson(['ok' => true, 'group' => groupOut($_27, $_11->fetch())]);

    case 'group_join':
        $_1f = requireUser($_27, $_30);
        $_7 = strtoupper(str($_9['invite_code'] ?? '', 16));
        if (!preg_match('/^[0-9A-F]{6,16}$/', $_7)) fail('کد دعوت معتبر نیست', 404);
        $_37 = $_27->prepare('SELECT * FROM chat_groups WHERE invite_code = ?');
        $_37->execute([$_7]);
        $_11 = $_37->fetch();
        if (!$_11) fail('کد دعوت معتبر نیست', 404);
        if (isMember($_27, $_11['id'], $_1f['username'])) {
            sendJson(['ok' => true, 'group' => groupOut($_27, $_11)]);
        }
        ensureJoinRequestsTable($_27);
        $_1e = $_27->prepare('SELECT COUNT(*) FROM chat_join_requests WHERE group_id = ?');
        $_1e->execute([$_11['id']]);
        if ((int)$_1e->fetchColumn() >= 50) fail('تعداد درخواست‌های در انتظار این گروه پر شده است', 429);
        $_27->prepare('INSERT IGNORE INTO chat_join_requests (group_id, username, requested_at) VALUES (?, ?, ?)')
            ->execute([$_11['id'], $_1f['username'], nowMs()]);
        sendJson(['ok' => true, 'pending' => true, 'group' => ['id' => $_11['id'], 'name' => $_11['name']]]);

    case 'group_requests':
        $_1f = requireUser($_27, $_30);
        $_12 = str($_9['group_id'] ?? '', 40);
        $_37 = $_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
        $_37->execute([$_12]);
        $_11 = $_37->fetch();
        if (!$_11) fail('گروه یافت نشد', 404);
        if ($_11['owner_username'] !== $_1f['username']) fail('فقط سازنده‌ی گروه می‌تواند درخواست‌ها را ببیند', 403);
        ensureJoinRequestsTable($_27);
        $_37 = $_27->prepare('SELECT username, requested_at FROM chat_join_requests WHERE group_id = ? ORDER BY requested_at ASC LIMIT 100');
        $_37->execute([$_12]);
        $_24 = [];
        foreach ($_37->fetchAll() as $_m6) { $_24[] = ['username' => $_m6['username'], 'requested_at' => (int)$_m6['requested_at']]; }
        sendJson(['ok' => true, 'requests' => $_24]);

    case 'group_request_resolve':
        $_1f = requireUser($_27, $_30);
        $_12 = str($_9['group_id'] ?? '', 40);
        $_3d = str($_9['username'] ?? '', 32);
        $_m7 = !empty($_9['approve']);
        $_37 = $_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
        $_37->execute([$_12]);
        $_11 = $_37->fetch();
        if (!$_11) fail('گروه یافت نشد', 404);
        if ($_11['owner_username'] !== $_1f['username']) fail('فقط سازنده‌ی گروه می‌تواند درخواست‌ها را بررسی کند', 403);
        ensureJoinRequestsTable($_27);
        $_m8 = $_27->prepare('SELECT 1 FROM chat_join_requests WHERE group_id = ? AND username = ?');
        $_m8->execute([$_12, $_3d]);
        if (!$_m8->fetchColumn()) fail('درخواست یافت نشد', 404);
        if ($_m7) {
            $_1e = $_27->prepare('SELECT COUNT(*) FROM chat_members WHERE group_id = ?');
            $_1e->execute([$_12]);
            if ((int)$_1e->fetchColumn() >= 100) fail('ظرفیت گروه تکمیل است', 409);
            $_27->prepare('INSERT IGNORE INTO chat_members (group_id, username, joined_at) VALUES (?, ?, ?)')
                ->execute([$_12, $_3d, nowMs()]);
        }
        $_27->prepare('DELETE FROM chat_join_requests WHERE group_id = ? AND username = ?')->execute([$_12, $_3d]);
        sendJson(['ok' => true, 'group' => groupOut($_27, $_11)]);

    case 'group_invite':
        $_1f = requireUser($_27, $_30);
        $_12 = str($_9['group_id'] ?? '', 40);
        $_3d = str($_9['target_username'] ?? '', 32);
        $_37 = $_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
        $_37->execute([$_12]);
        $_11 = $_37->fetch();
        if (!$_11) fail('گروه یافت نشد', 404);
        if (substr($_12, 0, 3) === 'dm_') fail('امکان افزودن عضو به گفتگوی خصوصی نیست', 400);
        if ($_11['owner_username'] !== $_1f['username']) fail('فقط سازنده‌ی گروه می‌تواند عضو اضافه کند', 403);
        $_41 = $_27->prepare('SELECT username FROM users WHERE username = ?');
        $_41->execute([$_3d]);
        $_3f = $_41->fetch();
        if (!$_3f) fail('کاربری با این نام پیدا نشد', 404);
        $_27->prepare('INSERT IGNORE INTO chat_members (group_id, username, joined_at) VALUES (?, ?, ?)')
            ->execute([$_12, $_3f['username'], nowMs()]);
        sendJson(['ok' => true, 'group' => groupOut($_27, $_11)]);

    case 'group_leave':
        $_1f = requireUser($_27, $_30);
        $_12 = str($_9['group_id'] ?? '', 40);
        $_37 = $_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
        $_37->execute([$_12]);
        $_11 = $_37->fetch();
        if (!$_11) fail('گروه یافت نشد', 404);
        if (!isMember($_27, $_12, $_1f['username'])) fail('شما عضو این گروه نیستید', 403);
        $_27->beginTransaction();
        $_27->prepare('DELETE FROM chat_members WHERE group_id = ? AND username = ?')->execute([$_12, $_1f['username']]);
        $_27->prepare('DELETE FROM chat_reads WHERE group_id = ? AND username = ?')->execute([$_12, $_1f['username']]);
        $_g1 = $_27->prepare('SELECT username FROM chat_members WHERE group_id = ? ORDER BY joined_at ASC LIMIT 1');
        $_g1->execute([$_12]);
        $_g2 = $_g1->fetchColumn();
        if ($_g2 === false) {
            deleteGroupData($_27, $_12);
        } elseif ($_11['owner_username'] === $_1f['username']) {
            $_27->prepare('UPDATE chat_groups SET owner_username = ? WHERE id = ?')->execute([$_g2, $_12]);
        }
        $_27->commit();
        sendJson(['ok' => true]);

    case 'group_delete':
        $_1f = requireUser($_27, $_30);
        $_12 = str($_9['group_id'] ?? '', 40);
        $_37 = $_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
        $_37->execute([$_12]);
        $_11 = $_37->fetch();
        if (!$_11) fail('گروه یافت نشد', 404);
        if ($_11['owner_username'] !== $_1f['username']) fail('فقط سازنده‌ی گروه می‌تواند آن را حذف کند', 403);
        $_27->beginTransaction();
        deleteGroupData($_27, $_12);
        $_27->commit();
        sendJson(['ok' => true]);

    case 'profile_get':
        $_1f = requireUser($_27, $_30);
        $_pu = str($_9['username'] ?? '', 32);
        if ($_pu === '') fail('کاربر نامعتبر است', 400);
        if (strcasecmp($_pu, $_1f['username']) !== 0) {
            $_ps = $_27->prepare('SELECT 1 FROM chat_members a JOIN chat_members b ON a.group_id = b.group_id WHERE a.username = ? AND b.username = ? LIMIT 1');
            $_ps->execute([$_1f['username'], $_pu]);
            if (!$_ps->fetchColumn()) fail('دسترسی به این پروفایل مجاز نیست', 403);
        }
        ensureBioColumn($_27);
        ensureLastSeenColumn($_27);
        $_pq = $_27->prepare('SELECT username, display_name, avatar_color, total_score, wins, games_played, favorite_game, bio, last_seen FROM users WHERE username = ?');
        $_pq->execute([$_pu]);
        $_pr = $_pq->fetch();
        if (!$_pr) fail('کاربری با این نام پیدا نشد', 404);
        sendJson(['ok' => true, 'profile' => [
            'username' => $_pr['username'],
            'display_name' => $_pr['display_name'],
            'avatar_color' => (int)$_pr['avatar_color'],
            'bio' => (string)($_pr['bio'] ?? ''),
            'total_score' => (int)$_pr['total_score'],
            'wins' => (int)$_pr['wins'],
            'games_played' => (int)$_pr['games_played'],
            'favorite_game' => $_pr['favorite_game'],
            'last_seen' => (int)($_pr['last_seen'] ?? 0),
        ]]);

    case 'bio_set':
        $_1f = requireUser($_27, $_30);
        $_bi = $_9['bio'] ?? '';
        if (!is_string($_bi)) fail('ورودی نامعتبر', 400);
        $_bi = str(preg_replace('/[^\P{Cc}\n]/u', '', $_bi), 300);
        ensureBioColumn($_27);
        $_27->prepare('UPDATE users SET bio = ? WHERE id = ?')->execute([$_bi, (int)$_1f['id']]);
        sendJson(['ok' => true, 'bio' => $_bi]);

    case 'dm_open':
        $_1f = requireUser($_27, $_30);
        $_3d = str($_9['target_username'] ?? '', 32);
        $_og = str($_9['origin_group_id'] ?? '', 40);
        if ($_3d === '' || strcasecmp($_3d, $_1f['username']) === 0) fail('کاربر نامعتبر است', 400);
        if (!isMember($_27, $_og, $_1f['username'])) fail('شما عضو این گروه نیستید', 403);
        $_41 = $_27->prepare('SELECT username FROM users WHERE username = ?');
        $_41->execute([$_3d]);
        $_3f = $_41->fetch();
        if (!$_3f) fail('کاربری با این نام پیدا نشد', 404);
        $_ta = $_3f['username'];
        if (!isMember($_27, $_og, $_ta)) fail('این کاربر عضو گروه نیست', 403);
        ensureDmColumn($_27);
        $_pa = [strtolower($_1f['username']), strtolower($_ta)];
        sort($_pa);
        $_di = 'dm_' . substr(hash('sha256', $_pa[0] . '|' . $_pa[1]), 0, 16);
        $_37 = $_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
        $_37->execute([$_di]);
        $_11 = $_37->fetch();
        $_3b = nowMs();
        if (!$_11) {
            $_7 = strtoupper(bin2hex(random_bytes(5)));
            $_27->beginTransaction();
            $_27->prepare('INSERT INTO chat_groups (id, name, invite_code, owner_username, last_message, last_time, dm_origin) VALUES (?, ?, ?, ?, ?, ?, ?)')
                ->execute([$_di, 'dm', $_7, $_1f['username'], '', $_3b, $_og]);
            $_27->prepare('INSERT IGNORE INTO chat_members (group_id, username, joined_at) VALUES (?, ?, ?)')->execute([$_di, $_1f['username'], $_3b]);
            $_27->prepare('INSERT IGNORE INTO chat_members (group_id, username, joined_at) VALUES (?, ?, ?)')->execute([$_di, $_ta, $_3b]);
            $_27->commit();
        } else {
            $_27->prepare('INSERT IGNORE INTO chat_members (group_id, username, joined_at) VALUES (?, ?, ?)')->execute([$_di, $_1f['username'], $_3b]);
        }
        $_gr = $_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
        $_gr->execute([$_di]);
        sendJson(['ok' => true, 'group' => groupOut($_27, $_gr->fetch())]);

    case 'group_update':
        $_1f = requireUser($_27, $_30);
        $_12 = str($_9['group_id'] ?? '', 40);
        $_37 = $_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
        $_37->execute([$_12]);
        $_11 = $_37->fetch();
        if (!$_11) fail('گروه یافت نشد', 404);
        if (substr($_12, 0, 3) === 'dm_') fail('گفتگوی خصوصی قابل ویرایش نیست', 400);
        if ($_11['owner_username'] !== $_1f['username']) fail('فقط سازنده‌ی گروه می‌تواند مشخصات را تغییر دهد', 403);
        $_gn = $_9['name'] ?? null;
        $_gd = $_9['description'] ?? null;
        if ($_gn !== null) {
            if (!is_string($_gn) || strncmp($_gn, 'e1:', 3) !== 0 || strlen($_gn) > 600) fail('نام گروه نامعتبر است', 400);
            $_27->prepare('UPDATE chat_groups SET name = ? WHERE id = ?')->execute([$_gn, $_12]);
        }
        if ($_gd !== null) {
            if (!is_string($_gd) || strlen($_gd) > 4000 || ($_gd !== '' && strncmp($_gd, 'e1:', 3) !== 0)) fail('توضیحات نامعتبر است', 400);
            ensureGroupDescColumn($_27);
            $_27->prepare('UPDATE chat_groups SET description = ? WHERE id = ?')->execute([$_gd, $_12]);
        }
        $_gr = $_27->prepare('SELECT * FROM chat_groups WHERE id = ?');
        $_gr->execute([$_12]);
        sendJson(['ok' => true, 'group' => groupOut($_27, $_gr->fetch())]);

    case 'groups_list':
        $_1f = requireUser($_27, $_30);
        ensureLastSeenColumn($_27);
        $_37 = $_27->prepare('SELECT g.* FROM chat_groups g JOIN chat_members m ON m.group_id = g.id WHERE m.username = ? ORDER BY g.last_time DESC LIMIT 100');
        $_37->execute([$_1f['username']]);
        $_24 = [];
        $_allMembers = [];
        $rawGroups = $_37->fetchAll();
        foreach ($rawGroups as $_11) {
            $_m9 = groupOut($_27, $_11);
            if ($_11['owner_username'] === $_1f['username']) {
                try {
                    $_m8 = $_27->prepare('SELECT COUNT(*) FROM chat_join_requests WHERE group_id = ?');
                    $_m8->execute([$_11['id']]);
                    $_m9['pending_count'] = (int)$_m8->fetchColumn();
                } catch (Throwable $_d) { $_m9['pending_count'] = 0; }
            }
            $_24[] = $_m9;
            foreach ($_m9['members'] as $mem) {
                $_allMembers[strtolower($mem)] = $mem;
            }
        }
        // Fetch last seen timestamps for presence awareness across chats
        $_seenMap = [];
        if (!empty($_allMembers)) {
            $memList = array_values($_allMembers);
            $chunks = array_chunk($memList, 50);
            foreach ($chunks as $chunk) {
                $ph = implode(',', array_fill(0, count($chunk), '?'));
                $q = $_27->prepare('SELECT username, last_seen FROM users WHERE username IN (' . $ph . ')');
                $q->execute($chunk);
                foreach ($q->fetchAll() as $row) {
                    $_seenMap[$row['username']] = (int)($row['last_seen'] ?? 0);
                }
            }
        }
        sendJson(['ok' => true, 'groups' => $_24, 'presence' => $_seenMap, 'server_time_ms' => nowMs()]);

    case 'presence_ping':
        $_1f = requireUser($_27, $_30);
        sendJson(['ok' => true, 'now_ms' => nowMs()]);

    case 'message_send':
        $_1f = requireUser($_27, $_30);
        $_12 = str($_9['group_id'] ?? '', 40);
        if (!isMember($_27, $_12, $_1f['username'])) fail('شما عضو این گروه نیستید', 403);
        $_15 = $_9['id'] ?? '';
        if (!is_string($_15) || !preg_match('/^[A-Za-z0-9_-]{4,48}$/', $_15)) fail('شناسه پیام نامعتبر است', 400);
        $_42 = $_9['text'] ?? '';
        if (!is_string($_42) || $_42 === '' || strlen($_42) > 40000) fail('پیام نامعتبر است', 400);
        if (strncmp($_42, 'e1:', 3) !== 0) fail('فقط پیام رمزنگاری‌شده پذیرفته می‌شود', 400);
        $_16 = $_9['image_data'] ?? null;
        if ($_16 === null || $_16 === '') {
            $_16 = null;
        } elseif (!is_string($_16) || strlen($_16) > 6000000 || strncmp($_16, 'e1:', 3) !== 0) {
            fail('تصویر نامعتبر یا حجم آن زیاد است', 413);
        }
        $_2b = $_9['preview'] ?? '';
        if (!is_string($_2b) || strlen($_2b) > 600 || ($_2b !== '' && strncmp($_2b, 'e1:', 3) !== 0)) $_2b = '';
        $_3b = nowMs();
        $_17 = $_27->prepare('INSERT IGNORE INTO chat_messages (id, group_id, sender_username, sender_color, text, image_data, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $_17->execute([$_15, $_12, $_1f['username'], (int)$_1f['avatar_color'], $_42, $_16, $_3b]);
        if ($_17->rowCount() === 0) {
            $_e = $_27->prepare('SELECT group_id, sender_username FROM chat_messages WHERE id = ?');
            $_e->execute([$_15]);
            $_10 = $_e->fetch();
            if (!$_10 || $_10['group_id'] !== $_12 || $_10['sender_username'] !== $_1f['username']) fail('شناسه پیام تکراری است', 409);
            sendJson(['ok' => true]);
        }
        $_27->prepare('UPDATE chat_groups SET last_message = ?, last_time = ? WHERE id = ?')->execute([$_2b, $_3b, $_12]);
        sendJson(['ok' => true]);

    case 'message_delete':
        $_1f = requireUser($_27, $_30);
        $_m1 = str($_9['id'] ?? '', 48);
        $_m2 = $_27->prepare('SELECT id, group_id, sender_username, timestamp FROM chat_messages WHERE id = ?');
        $_m2->execute([$_m1]);
        $_m3 = $_m2->fetch();
        if (!$_m3) sendJson(['ok' => true]);
        if (!isMember($_27, $_m3['group_id'], $_1f['username'])) fail('دسترسی غیرمجاز', 403);
        $_m4 = $_27->prepare('SELECT owner_username FROM chat_groups WHERE id = ?');
        $_m4->execute([$_m3['group_id']]);
        $_m5 = $_m4->fetchColumn();
        if ($_m3['sender_username'] !== $_1f['username'] && ($_m5 !== $_1f['username'] || substr($_m3['group_id'], 0, 3) === 'dm_')) fail('فقط فرستنده‌ی پیام یا سازنده‌ی گروه می‌تواند آن را حذف کند', 403);
        $_27->prepare('DELETE FROM chat_messages WHERE id = ?')->execute([$_m1]);
        $_27->prepare('UPDATE chat_groups SET last_message = ? WHERE id = ? AND last_time = ?')->execute(['', $_m3['group_id'], (int)$_m3['timestamp']]);
        sendJson(['ok' => true]);

    case 'messages_list':
        $_1f = requireUser($_27, $_30);
        $_12 = str($_9['group_id'] ?? '', 40);
        if (!isMember($_27, $_12, $_1f['username'])) fail('شما عضو این گروه نیستید', 403);
        $_37 = $_27->prepare('SELECT * FROM (SELECT id, group_id, sender_username, sender_color, text, timestamp, (image_data IS NOT NULL AND image_data <> \'\') AS has_image FROM chat_messages WHERE group_id = ? ORDER BY timestamp DESC LIMIT 120) t ORDER BY timestamp ASC');
        $_37->execute([$_12]);
        $_32 = $_37->fetchAll();
        $_1d = 0;
        foreach ($_32 as $_1b => $_2c) {
            $_32[$_1b]['sender_color'] = (int)$_2c['sender_color'];
            $_32[$_1b]['timestamp'] = (int)$_2c['timestamp'];
            $_32[$_1b]['has_image'] = (int)$_2c['has_image'] === 1;
            if ((int)$_2c['timestamp'] > $_1d) $_1d = (int)$_2c['timestamp'];
        }
        if ($_1d > 0) {
            $_27->prepare('INSERT INTO chat_reads (group_id, username, last_ts) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE last_ts = GREATEST(last_ts, VALUES(last_ts))')
                ->execute([$_12, $_1f['username'], $_1d]);
        }
        $_34 = $_27->prepare('SELECT username, last_ts FROM chat_reads WHERE group_id = ?');
        $_34->execute([$_12]);
        $_2f = new stdClass();
        foreach ($_34->fetchAll() as $_33) { $_2f->{$_33['username']} = (int)$_33['last_ts']; }

        // Fetch presence for members of this group
        $_memQ = $_27->prepare('SELECT username FROM chat_members WHERE group_id = ?');
        $_memQ->execute([$_12]);
        $_members = $_memQ->fetchAll(PDO::FETCH_COLUMN);
        $_presence = [];
        if (!empty($_members)) {
            ensureLastSeenColumn($_27);
            $_ph = implode(',', array_fill(0, count($_members), '?'));
            $_pq = $_27->prepare('SELECT username, last_seen FROM users WHERE username IN (' . $_ph . ')');
            $_pq->execute($_members);
            foreach ($_pq->fetchAll() as $_r) {
                $_presence[$_r['username']] = (int)($_r['last_seen'] ?? 0);
            }
        }

        sendJson(['ok' => true, 'messages' => $_32, 'reads' => $_2f, 'presence' => $_presence, 'server_time_ms' => nowMs()]);

    case 'message_image':
        $_1f = requireUser($_27, $_30);
        $_37 = $_27->prepare('SELECT group_id, image_data FROM chat_messages WHERE id = ?');
        $_37->execute([str($_9['id'] ?? '', 48)]);
        $_31 = $_37->fetch();
        if (!$_31) sendJson(['ok' => true, 'image' => '']);
        if (!isMember($_27, $_31['group_id'], $_1f['username'])) fail('دسترسی غیرمجاز', 403);
        sendJson(['ok' => true, 'image' => $_31['image_data'] ?? '']);

    case 'room_create':
        $_1f = requireUser($_27, $_30);
        $_7 = cleanRoomCode($_9['room_code'] ?? '');
        $_13 = (string)($_9['game_type'] ?? 'ludo');
        if (!in_array($_13, $_0, true)) $_13 = 'ludo';
        try {
            $_27->prepare('INSERT INTO game_rooms (room_code, game_type, host_username, players_json, status, version, state_json, updated_at) VALUES (?, ?, ?, ?, ?, 1, ?, ?)')
                ->execute([$_7, $_13, $_1f['username'], json_encode([$_1f['username']], JSON_UNESCAPED_UNICODE), 'waiting', '{}', time()]);
        } catch (PDOException $_d) {
            fail('کد اتاق تکراری است، دوباره تلاش کن', 409);
        }
        if (random_int(1, 20) === 1) {
            try { $_27->prepare('DELETE FROM game_rooms WHERE updated_at < ?')->execute([time() - 86400]); } catch (Throwable $_d) {}
        }
        roomTokTouch($_7);
        $_37 = $_27->prepare('SELECT * FROM game_rooms WHERE room_code = ?');
        $_37->execute([$_7]);
        sendJson(['ok' => true, 'room' => roomOut($_37->fetch())]);

    case 'room_join':
        $_1f = requireUser($_27, $_30);
        $_7 = cleanRoomCode($_9['room_code'] ?? '');
        $_27->beginTransaction();
        $_37 = $_27->prepare('SELECT * FROM game_rooms WHERE room_code = ? FOR UPDATE');
        $_37->execute([$_7]);
        $_2c = $_37->fetch();
        if (!$_2c) { $_27->rollBack(); fail('اتاق پیدا نشد', 404); }
        $_25 = json_decode($_2c['players_json'], true);
        if (!is_array($_25)) $_25 = [];
        if (!in_array($_1f['username'], $_25, true)) {
            if (count($_25) >= 4) { $_27->rollBack(); fail('اتاق پر است', 409); }
            $_25[] = $_1f['username'];
        }
        $_3a = (count($_25) >= 2 && $_2c['status'] === 'waiting') ? 'playing' : $_2c['status'];
        $_4a = (int)$_2c['version'] + 1;
        $_27->prepare('UPDATE game_rooms SET players_json = ?, status = ?, version = ?, updated_at = ? WHERE room_code = ?')
            ->execute([json_encode($_25, JSON_UNESCAPED_UNICODE), $_3a, $_4a, time(), $_7]);
        $_27->commit();
        roomTokTouch($_7);
        $_38 = $_27->prepare('SELECT * FROM game_rooms WHERE room_code = ?');
        $_38->execute([$_7]);
        sendJson(['ok' => true, 'room' => roomOut($_38->fetch())]);

    case 'room_sync':
        $_1f = requireUser($_27, $_30);
        $_7 = cleanRoomCode($_9['room_code'] ?? '');
        $_37 = $_27->prepare('SELECT * FROM game_rooms WHERE room_code = ?');
        $_37->execute([$_7]);
        $_2c = $_37->fetch();
        if (!$_2c) fail('اتاق پیدا نشد', 404);
        $_24 = roomOut($_2c);
        if (!in_array($_1f['username'], $_24['players'], true)) fail('شما عضو این اتاق نیستید', 403);
        sendJson(['ok' => true, 'room' => $_24]);

    case 'room_move':
        $_1f = requireUser($_27, $_30);
        $_7 = cleanRoomCode($_9['room_code'] ?? '');
        $_39 = $_9['state_json'] ?? '{}';
        if (!is_string($_39) || strlen($_39) > 300000) fail('وضعیت بازی نامعتبر است', 400);
        $_3a = (string)($_9['status'] ?? 'playing');
        if (!in_array($_3a, ['waiting', 'playing', 'finished'], true)) $_3a = 'playing';
        $_37 = $_27->prepare('SELECT * FROM game_rooms WHERE room_code = ?');
        $_37->execute([$_7]);
        $_2c = $_37->fetch();
        if (!$_2c) fail('اتاق پیدا نشد', 404);
        if (!in_array($_1f['username'], roomOut($_2c)['players'], true)) fail('شما عضو این اتاق نیستید', 403);
        $_4a = max((int)$_2c['version'], (int)($_9['version'] ?? 1));
        $_27->prepare('UPDATE game_rooms SET state_json = ?, status = ?, version = ?, updated_at = ? WHERE room_code = ?')
            ->execute([$_39, $_3a, $_4a, time(), $_7]);
        roomTokTouch($_7);
        $_37->execute([$_7]);
        sendJson(['ok' => true, 'room' => roomOut($_37->fetch())]);

    case 'room_chat_send':
        $_1f = requireUser($_27, $_30);
        $_7 = cleanRoomCode($_9['room_code'] ?? '');
        $_15 = $_9['id'] ?? '';
        if (!is_string($_15) || !preg_match('/^[A-Za-z0-9_-]{4,48}$/', $_15)) fail('شناسه پیام نامعتبر است', 400);
        $_42 = str($_9['text'] ?? '', 200);
        if ($_42 === '') fail('پیام خالی است', 400);
        roomPlayersOf($_27, $_7, $_1f['username']);
        ensureRoomChatTable($_27);
        $_3b = nowMs();
        $_rl = $_27->prepare('SELECT COUNT(*) FROM room_chat WHERE room_code = ? AND sender_username = ? AND ts > ?');
        $_rl->execute([$_7, $_1f['username'], $_3b - 3000]);
        if ((int)$_rl->fetchColumn() >= 5) fail('آهسته‌تر پیام بده', 429);
        $_17 = $_27->prepare('INSERT IGNORE INTO room_chat (id, room_code, sender_username, text, ts) VALUES (?, ?, ?, ?, ?)');
        $_17->execute([$_15, $_7, $_1f['username'], $_42, $_3b]);
        if ($_17->rowCount() > 0) roomChatTokTouch($_7);
        if (random_int(1, 40) === 1) {
            try { $_27->prepare('DELETE FROM room_chat WHERE ts < ?')->execute([$_3b - 86400000]); } catch (Throwable $_d) {}
        }
        sendJson(['ok' => true, 'ts' => $_3b]);

    case 'room_chat_list':
        $_1f = requireUser($_27, $_30);
        $_7 = cleanRoomCode($_9['room_code'] ?? '');
        $_2a = roomPlayersOf($_27, $_7, $_1f['username']);
        ensureRoomChatTable($_27);
        $_rs = max(0, (int)($_9['since'] ?? 0));
        $_37 = $_27->prepare('SELECT * FROM (SELECT id, sender_username, text, ts FROM room_chat WHERE room_code = ? AND ts >= ? ORDER BY ts DESC LIMIT 60) t ORDER BY ts ASC');
        $_37->execute([$_7, $_rs]);
        $_32 = $_37->fetchAll();
        foreach ($_32 as $_1b => $_2c) { $_32[$_1b]['ts'] = (int)$_2c['ts']; }
        $_pi = [];
        if (count($_2a) > 0) {
            $_ph = implode(',', array_fill(0, count($_2a), '?'));
            $_pq = $_27->prepare('SELECT username, display_name, avatar_color FROM users WHERE username IN (' . $_ph . ')');
            $_pq->execute(array_values($_2a));
            foreach ($_pq->fetchAll() as $_pr) {
                $_pi[] = ['username' => $_pr['username'], 'display_name' => $_pr['display_name'], 'avatar_color' => (int)$_pr['avatar_color']];
            }
        }
        sendJson(['ok' => true, 'messages' => $_32, 'players' => $_pi]);

    case 'profile_update':
        $_1f = requireUser($_27, $_30);
        $_pn = str($_9['display_name'] ?? '', 32);
        $_pn = trim((string)preg_replace('/[\x00-\x1F\x7F]/u', '', $_pn));
        if ($_pn === '') fail('نام نمی‌تواند خالی باشد', 400);
        $_27->prepare('UPDATE users SET display_name = ? WHERE id = ?')->execute([$_pn, (int)$_1f['id']]);
        sendJson(['ok' => true, 'display_name' => $_pn]);

    case 'avatar_set':
        $_1f = requireUser($_27, $_30);
        ensureAvatarTable($_27);
        $_ai = $_9['image'] ?? '';
        $_av = nowMs();
        if (!is_string($_ai)) fail('تصویر نامعتبر است', 400);
        if ($_ai === '') {
            $_27->prepare('INSERT INTO user_avatars (username, ver, image) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE ver = VALUES(ver), image = VALUES(image)')->execute([$_1f['username'], $_av, '']);
            sendJson(['ok' => true, 'ver' => $_av]);
        }
        if (strlen($_ai) > 160000) fail('حجم عکس زیاد است', 413);
        $_ab = base64_decode($_ai, true);
        if ($_ab === false || strlen($_ab) < 100 || substr($_ab, 0, 3) !== "\xFF\xD8\xFF") fail('فقط عکس JPEG پذیرفته می‌شود', 400);
        $_az = @getimagesizefromstring($_ab);
        if (!$_az || $_az[0] > 600 || $_az[1] > 600) fail('ابعاد عکس نامعتبر است', 400);
        $_ar = $_27->prepare('SELECT ver FROM user_avatars WHERE username = ?');
        $_ar->execute([$_1f['username']]);
        $_al = $_ar->fetchColumn();
        if ($_al !== false && (int)$_al > $_av - 2000) fail('آهسته‌تر؛ چند ثانیه بعد دوباره امتحان کن', 429);
        $_27->prepare('INSERT INTO user_avatars (username, ver, image) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE ver = VALUES(ver), image = VALUES(image)')->execute([$_1f['username'], $_av, $_ai]);
        sendJson(['ok' => true, 'ver' => $_av]);

    case 'group_avatar_set':
        $_1f = requireUser($_27, $_30);
        ensureAvatarTable($_27);
        $_gid = str($_9['group_id'] ?? '', 40);
        if (substr($_gid, 0, 4) !== 'grp_') fail('گروه نامعتبر است', 400);
        $_gq = $_27->prepare('SELECT owner_username FROM chat_groups WHERE id = ?');
        $_gq->execute([$_gid]);
        $_go = $_gq->fetchColumn();
        if ($_go === false) fail('گروه یافت نشد', 404);
        if ($_go !== $_1f['username']) fail('فقط سازنده‌ی گروه می‌تواند عکس را تغییر دهد', 403);
        $_gk = 'g:' . $_gid;
        $_ai = $_9['image'] ?? '';
        $_av = nowMs();
        if (!is_string($_ai)) fail('تصویر نامعتبر است', 400);
        if ($_ai === '') {
            $_27->prepare('INSERT INTO user_avatars (username, ver, image) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE ver = VALUES(ver), image = VALUES(image)')->execute([$_gk, $_av, '']);
            sendJson(['ok' => true, 'ver' => $_av]);
        }
        if (strlen($_ai) > 160000) fail('حجم عکس زیاد است', 413);
        $_ab = base64_decode($_ai, true);
        if ($_ab === false || strlen($_ab) < 100 || substr($_ab, 0, 3) !== "\xFF\xD8\xFF") fail('فقط عکس JPEG پذیرفته می‌شود', 400);
        $_az = @getimagesizefromstring($_ab);
        if (!$_az || $_az[0] > 600 || $_az[1] > 600) fail('ابعاد عکس نامعتبر است', 400);
        $_ar = $_27->prepare('SELECT ver FROM user_avatars WHERE username = ?');
        $_ar->execute([$_gk]);
        $_al = $_ar->fetchColumn();
        if ($_al !== false && (int)$_al > $_av - 2000) fail('آهسته‌تر؛ چند ثانیه بعد دوباره امتحان کن', 429);
        $_27->prepare('INSERT INTO user_avatars (username, ver, image) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE ver = VALUES(ver), image = VALUES(image)')->execute([$_gk, $_av, $_ai]);
        sendJson(['ok' => true, 'ver' => $_av]);

    case 'avatar_get':
        $_1f = requireUser($_27, $_30);
        ensureAvatarTable($_27);
        $_an = $_9['usernames'] ?? [];
        $_ah = $_9['have'] ?? [];
        if (!is_array($_an)) fail('ورودی نامعتبر', 400);
        if (!is_array($_ah)) $_ah = [];
        $_ak = [];
        foreach ($_an as $_ax) { $_ax = str($_ax, 32); if ($_ax !== '') $_ak[strtolower($_ax)] = $_ax; }
        $_ak = array_slice(array_values($_ak), 0, 8);
        $_ao = [];
        if (count($_ak) > 0) {
            $_ph = implode(',', array_fill(0, count($_ak), '?'));
            $_aq = $_27->prepare('SELECT username, ver, image FROM user_avatars WHERE username IN (' . $_ph . ')');
            $_aq->execute($_ak);
            foreach ($_aq->fetchAll() as $_ay) {
                $_hv = (int)($_ah[strtolower($_ay['username'])] ?? -1);
                if ($_hv === (int)$_ay['ver']) continue;
                $_ao[] = ['username' => $_ay['username'], 'ver' => (int)$_ay['ver'], 'image' => $_ay['image']];
            }
        }
        sendJson(['ok' => true, 'avatars' => $_ao]);

    default:
        fail('Unknown action', 400);
}
