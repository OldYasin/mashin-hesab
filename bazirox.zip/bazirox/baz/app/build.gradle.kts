import java.security.SecureRandom
import com.google.gms.googleservices.GoogleServicesPlugin.MissingGoogleServicesStrategy

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.google.services)
}

// --- Server address + shared key -------------------------------------------------------------
// Read from .env (or environment variables) at build time and stored in the APK only in masked
// form (random one-time pad, XOR). They never appear as plain text in the APK's strings.
fun parseDotEnv(text: String): Map<String, String> {
  val out = HashMap<String, String>()
  for (raw in text.lines()) {
    val line = raw.trim().trimStart('\uFEFF')
    if (line.isEmpty() || line.startsWith("#")) continue
    val i = line.indexOf('=')
    if (i < 1) continue
    var v = line.substring(i + 1).trim()
    if (v.length >= 2 && ((v.first() == '"' && v.last() == '"') || (v.first() == '\'' && v.last() == '\''))) {
      v = v.substring(1, v.length - 1)
    }
    out[line.substring(0, i).trim()] = v
  }
  return out
}

fun maskPair(plain: String): Pair<String, String> {
  val data = plain.toByteArray(Charsets.UTF_8)
  val pad = ByteArray(data.size)
  SecureRandom().nextBytes(pad)
  val masked = ByteArray(data.size) { i -> (data[i].toInt() xor pad[i].toInt()).toByte() }
  fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
  return hex(masked) to hex(pad)
}

val exampleEnvText =
  providers.fileContents(rootProject.layout.projectDirectory.file(".env.example")).asText.orElse("")
val realEnvText =
  providers.fileContents(rootProject.layout.projectDirectory.file(".env")).asText.orElse("")
val dotEnv: Map<String, String> = parseDotEnv(exampleEnvText.get()) + parseDotEnv(realEnvText.get())
val serverUrl: String =
  (providers.environmentVariable("API_BASE_URL").orNull?.takeIf { it.isNotBlank() } ?: dotEnv["API_BASE_URL"])
    .orEmpty().trim()
val serverKey: String =
  (providers.environmentVariable("API_SECRET").orNull?.takeIf { it.isNotBlank() } ?: dotEnv["API_SECRET"])
    .orEmpty().trim()
if (serverUrl.isBlank() || serverKey.isBlank()) {
  logger.warn("WARNING: API_BASE_URL / API_SECRET missing in .env - the app will have no server.")
}

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = "vicious.cycle.bazirox"
    minSdk = 24
    targetSdk = 36
    versionCode = 1
    versionName = "1.0"

    val (urlA, urlB) = maskPair(serverUrl)
    val (keyA, keyB) = maskPair(serverKey)
    buildConfigField("String", "SRV_U_A", "\"$urlA\"")
    buildConfigField("String", "SRV_U_B", "\"$urlB\"")
    buildConfigField("String", "SRV_K_A", "\"$keyA\"")
    buildConfigField("String", "SRV_K_B", "\"$keyB\"")

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = System.getenv("KEY_ALIAS")?.takeIf { it.isNotBlank() } ?: "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = true
      isShrinkResources = true
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName("release")
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
}

googleServices { missingGoogleServicesStrategy = MissingGoogleServicesStrategy.WARN }

// Unused dependencies (Firebase, Room, Retrofit, Moshi, KSP) are commented out
// to ensure zero external cloud dependency and keep APK size well under 10 MB.
dependencies {
  implementation(platform(libs.androidx.compose.bom))
  // implementation(platform(libs.firebase.bom))
  // implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  // implementation(libs.androidx.camera.camera2)
  // implementation(libs.androidx.camera.core)
  // implementation(libs.androidx.camera.lifecycle)
  // implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  // implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  // Installs the baseline profile on first launch (faster cold start / less first-use jank).
  implementation("androidx.profileinstaller:profileinstaller:1.4.1")
  // implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  // implementation(libs.androidx.navigation.compose)
  // implementation(libs.androidx.room.ktx)
  // implementation(libs.androidx.room.runtime)
  // implementation(libs.coil.compose)
  // implementation(libs.converter.moshi)
  // implementation(libs.firebase.ai)
  // implementation(libs.firebase.firestore)
  // implementation(libs.firebase.auth)
  // implementation(libs.androidx.credentials)
  // implementation(libs.androidx.credentials.play.services)
  // implementation(libs.googleid)
  // implementation(libs.firebase.appcheck.recaptcha)
  // implementation(libs.firebase.appcheck.debug)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  // implementation(libs.logging.interceptor)
  // implementation(libs.moshi.kotlin)
  implementation(libs.okhttp)
  // implementation(libs.play.services.location)
  // implementation(libs.retrofit)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  // "ksp"(libs.androidx.room.compiler)
  // "ksp"(libs.moshi.kotlin.codegen)
}
