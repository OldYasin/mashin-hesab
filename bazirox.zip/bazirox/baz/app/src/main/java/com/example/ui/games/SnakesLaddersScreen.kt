package com.example.ui.games

import com.example.ui.components.RollDiceButton
import android.graphics.Paint
import android.graphics.Typeface
import androidx.activity.compose.BackHandler
import androidx.core.content.res.ResourcesCompat
import com.example.R
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.GameType
import com.example.data.OnlineRoom
import com.example.data.PlayMode
import com.example.data.Sfx
import com.example.data.SoundManager
import com.example.ui.components.AnimatedGameDice
import com.example.ui.components.BaziIcons
import com.example.ui.components.GameTopBar
import com.example.ui.components.GameArea
import com.example.ui.components.GameTurnTimer
import com.example.ui.components.rememberTurnCountdown
import com.example.ui.components.fitBoard
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.WinCelebrationBanner
import com.example.ui.components.oceanGameBackdrop
import com.example.ui.components.drawGlossyToken
import com.example.ui.components.playerColorFor
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val Ladders =
  mapOf(
    4 to 25,
    13 to 46,
    33 to 49,
    42 to 63,
    50 to 69,
    62 to 81,
    74 to 92,
  )

private val Snakes =
  mapOf(
    27 to 5,
    40 to 3,
    43 to 18,
    54 to 31,
    66 to 45,
    76 to 58,
    89 to 53,
    99 to 41,
  )

@Composable
fun SnakesLaddersScreen(
  playMode: PlayMode,
  playerCount: Int,
  room: OnlineRoom?,
  currentUsername: String,
  onPushOnlineState: (String, String) -> Unit,
  onRecordResult: (Boolean, Int) -> Unit,
  onBack: () -> Unit,
) {
  BackHandler(onBack = onBack)

  val count = if (playMode == PlayMode.ONLINE_ROOM) 2 else playerCount.coerceIn(2, 4)
  var positions by remember(count) { mutableStateOf(List(count) { 1 }) }
  var currentTurn by remember { mutableIntStateOf(0) }
  var diceValue by remember { mutableIntStateOf(6) }
  var isRolling by remember { mutableStateOf(false) }
  var winnerIndex by remember { mutableIntStateOf(-1) }
  var eventBanner by remember { mutableStateOf("تاس بیندازید تا حرکت شروع شود!") }
  var recorded by remember { mutableStateOf(false) }
  var roundId by remember { mutableIntStateOf(0) }
  val scope = rememberCoroutineScope()

  val myOnlineSide =
    remember(room, currentUsername) {
      if (room == null) 0
      else if (room.hostUsername.equals(currentUsername, ignoreCase = true)) 0 else 1
    }

  LaunchedEffect(room?.version, room?.stateJson) {
    if (playMode == PlayMode.ONLINE_ROOM && room != null && room.stateJson.length > 4) {
      try {
        val j = JSONObject(room.stateJson)
        val arr = j.optJSONArray("positions")
        if (arr != null && arr.length() == count) {
          positions = List(count) { i -> arr.getInt(i) }
          currentTurn = j.optInt("turn", 0)
          diceValue = j.optInt("dice", 6)
          winnerIndex = j.optInt("winner", -1)
          eventBanner = j.optString("banner", eventBanner)
        }
      } catch (_: Throwable) {}
    }
  }

  // Animated token positions in cell units (col+0.5,row+0.5); read only while drawing
  val tokenAnims = remember(count) {
    List(count) { Animatable(squareCenter(1, 1f), Offset.VectorConverter) }
  }
  val lastTargets = remember(count) { MutableList(count) { 1 } }
  LaunchedEffect(positions) {
    coroutineScope {
      positions.forEachIndexed { i, to ->
        val from = lastTargets[i]
        lastTargets[i] = to
        if (to == from) return@forEachIndexed
        launch {
          val anim = tokenAnims[i]
          if (to > from && to - from <= 6) {
            for (sq in (from + 1)..to) {
              anim.animateTo(squareCenter(sq, 1f), tween(110, easing = LinearEasing))
            }
          } else {
            anim.animateTo(squareCenter(to, 1f), tween(650, easing = FastOutSlowInEasing))
          }
        }
      }
    }
  }

  fun playerName(idx: Int): String =
    when {
      playMode == PlayMode.VS_AI && idx == 0 -> "شما"
      playMode == PlayMode.VS_AI -> "ربات $idx"
      playMode == PlayMode.ONLINE_ROOM ->
        room?.players?.getOrNull(idx) ?: "بازیکن ${idx + 1}"
      else -> "بازیکن ${idx + 1}"
    }

  fun resetGame() {
    positions = List(count) { 1 }
    currentTurn = 0
    diceValue = 6
    isRolling = false
    winnerIndex = -1
    recorded = false
    roundId++
    eventBanner = "بازی جدید آغاز شد! نوبت ${playerName(0)}"
  }

  suspend fun performRollAndMove(playerIdx: Int) {
    if (isRolling || winnerIndex != -1) return
    val rolled: Int
    isRolling = true
    try {
      delay(750) // dice tumbles on its own (no per-frame recomposition)
      rolled = Random.nextInt(1, 7)
      diceValue = rolled
    } finally {
      isRolling = false
    }

    val startPos = positions[playerIdx]
    val targetRaw = startPos + rolled
    if (targetRaw > 100) {
      eventBanner = "${playerName(playerIdx)} عدد $rolled آورد (نیاز به عدد دقیق برای ۱۰۰)"
      delay(300)
    } else {
      val mutable = positions.toMutableList()
      mutable[playerIdx] = targetRaw
      positions = mutable.toList()
      delay(rolled * 120L + 120L) // token walks square by square (animated)
      var finalPos = targetRaw
      val ladderDest = Ladders[targetRaw]
      val snakeDest = Snakes[targetRaw]
      if (ladderDest != null) {
        eventBanner = "نردبان! ${playerName(playerIdx)} از $targetRaw به $ladderDest صعود کرد"
        delay(150)
        finalPos = ladderDest
        mutable[playerIdx] = finalPos
        positions = mutable.toList()
        delay(700)
      } else if (snakeDest != null) {
        eventBanner = "مار نیش زد! ${playerName(playerIdx)} از $targetRaw به $snakeDest سقوط کرد"
        delay(150)
        finalPos = snakeDest
        mutable[playerIdx] = finalPos
        positions = mutable.toList()
        delay(700)
      } else {
        eventBanner = "${playerName(playerIdx)} با تاس $rolled به خانه $finalPos رفت"
      }

      if (finalPos == 100) {
        winnerIndex = playerIdx
      }
    }

    val nextTurn = if (winnerIndex != -1) playerIdx else (playerIdx + 1) % count
    currentTurn = nextTurn

    if (playMode == PlayMode.ONLINE_ROOM && room != null) {
      val j =
        JSONObject().apply {
          put("positions", JSONArray(positions))
          put("turn", nextTurn)
          put("dice", rolled)
          put("winner", winnerIndex)
          put("banner", eventBanner)
        }
      onPushOnlineState(j.toString(), if (winnerIndex == -1) "playing" else "finished")
    }
  }

  // Key omits isRolling so setting isRolling=true never self-cancels AI turn!
  LaunchedEffect(currentTurn, winnerIndex, playMode, roundId) {
    if (playMode == PlayMode.VS_AI && currentTurn > 0 && winnerIndex == -1) {
      delay(420)
      if (currentTurn > 0 && winnerIndex == -1) {
        performRollAndMove(currentTurn)
      }
    }
  }

  // ---- Sound effects ----
  LaunchedEffect(isRolling) { if (isRolling) SoundManager.play(Sfx.DICE) }

  var prevPositionsForSfx by remember { mutableStateOf<List<Int>?>(null) }
  LaunchedEffect(positions) {
    val prev = prevPositionsForSfx
    prevPositionsForSfx = positions
    if (prev == null || prev.size != positions.size) return@LaunchedEffect
    if (positions.all { it == 1 }) return@LaunchedEffect // new round, not a snake
    positions.forEachIndexed { i, to ->
      val from = prev[i]
      when {
        to == from -> Unit
        to < from -> SoundManager.play(Sfx.SNAKE)
        to - from <= 6 -> {
          repeat(to - from) {
            SoundManager.play(Sfx.STEP)
            delay(110)
          }
        }
        else -> SoundManager.play(Sfx.LADDER)
      }
    }
  }

  var resultSoundPlayed by remember { mutableStateOf(false) }
  LaunchedEffect(winnerIndex) {
    if (winnerIndex == -1) {
      resultSoundPlayed = false
    } else if (!resultSoundPlayed) {
      resultSoundPlayed = true
      val mine = if (playMode == PlayMode.ONLINE_ROOM) myOnlineSide else 0
      delay(600)
      SoundManager.play(if (winnerIndex == mine) Sfx.WIN else Sfx.LOSE)
    }
  }

  LaunchedEffect(winnerIndex) {
    if (winnerIndex != -1 && !recorded) {
      recorded = true
      onRecordResult(winnerIndex == 0, if (winnerIndex == 0) 45 else 10)
    }
  }

  val context = androidx.compose.ui.platform.LocalContext.current
  val textPaint = remember {
    Paint().apply {
      isAntiAlias = true
      textAlign = Paint.Align.LEFT
      typeface = ResourcesCompat.getFont(context, R.font.vazirmatn_bold) ?: Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
  }

  val activeColor = playerColorFor(currentTurn)

  Column(
    modifier =
      Modifier.fillMaxSize()
        .oceanGameBackdrop(activeColor)
        .systemBarsPadding(),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    val turnLeft =
      rememberTurnCountdown(key = listOf(currentTurn, winnerIndex, isRolling, diceValue), running = winnerIndex == -1 && !isRolling) {
        val mine =
          !isRolling && winnerIndex == -1 &&
            (playMode != PlayMode.VS_AI || currentTurn == 0) &&
            (playMode != PlayMode.ONLINE_ROOM || currentTurn == myOnlineSide)
        if (mine) scope.launch { performRollAndMove(currentTurn) }
      }
    GameTopBar(
      title = GameType.SNAKES_LADDERS.titleFa,
      subtitle =
        when (playMode) {
          PlayMode.VS_AI -> "$count بازیکن (در برابر هوش مصنوعی)"
          PlayMode.LOCAL_PASS_AND_PLAY -> "$count بازیکن آفلاین"
          PlayMode.ONLINE_ROOM -> "اتاق آنلاین: ${room?.roomCode ?: "-"}"
        },
      accentColor = ElectricEmerald,
      onBack = onBack,
      copyText = if (playMode == PlayMode.ONLINE_ROOM) room?.roomCode else null,
      trailingContent = {
        IconButton(onClick = { resetGame() }, modifier = Modifier.testTag("snakes_reset_button")) {
          Icon(Icons.Rounded.Refresh, contentDescription = "شروع مجدد", tint = ElectricEmerald)
        }
      },
    )

    GameArea(maxWidth = 600.dp) {
      GameTurnTimer(turnLeft, activeColor, active = winnerIndex == -1)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        for (i in 0 until count) {
          val active = winnerIndex == -1 && currentTurn == i
          val pColor = playerColorFor(i)
          val cardScale by
            androidx.compose.animation.core.animateFloatAsState(
              if (active) 1.05f else 1f,
              androidx.compose.animation.core.spring(dampingRatio = 0.55f, stiffness = 400f),
              label = "snakeCardScale",
            )
          GlassGradientCard(
            modifier = Modifier.weight(1f).graphicsLayer { scaleX = cardScale; scaleY = cardScale },
            accentColor = if (active) pColor else Color.White.copy(alpha = 0.14f),
            cornerRadius = 15.dp,
          ) {
            Column(
              modifier =
                Modifier.fillMaxWidth()
                  .background(if (active) pColor.copy(alpha = 0.16f) else Color.Transparent)
                  .padding(vertical = 4.dp, horizontal = 6.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              Text(
                text = playerName(i),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (active) FontWeight.ExtraBold else FontWeight.Medium,
                color = if (active) pColor else TextPrimary,
                maxLines = 1,
              )
              Text(
                text = "خانه ${positions[i]}",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
              )
            }
          }
        }
      }

      // Detailed 10x10 Frosted Glass Board Canvas
      GlassGradientCard(
        modifier = Modifier.fitBoard(222.dp),
        accentColor = ElectricEmerald,
        cornerRadius = 22.dp,
      ) {
        // Static board (100 cells, snakes, ladders, numbers): own layer, drawn once.
        Canvas(modifier = Modifier.fillMaxSize().graphicsLayer { }.padding(7.dp)) {
          val cell = size.width / 10f
          textPaint.textSize = cell * 0.22f

          for (num in 1..100) {
            val (cx, cy) = squareCenter(num, cell)
            val left = cx - cell / 2f
            val top = cy - cell / 2f
            val isEven = ((num - 1) / 10 + (num - 1) % 10) % 2 == 0
            val cellColor =
              when {
                num == 100 -> CyberGold.copy(alpha = 0.55f)
                num == 1 -> ElectricEmerald.copy(alpha = 0.40f)
                isEven -> Color(0xFF1C2640)
                else -> Color(0xFF172036)
              }
            drawRoundRect(
              color = cellColor,
              topLeft = Offset(left + 1.5f, top + 1.5f),
              size = Size(cell - 3f, cell - 3f),
              cornerRadius = CornerRadius(6f, 6f),
            )
          }

          Ladders.forEach { (start, end) ->
            drawLadder(squareCenter(start, cell), squareCenter(end, cell), cell)
          }
          Snakes.entries.forEachIndexed { i, (head, tail) ->
            drawSnake(squareCenter(head, cell), squareCenter(tail, cell), cell, SnakePalette[i % SnakePalette.size], i)
          }

          // Numbers on top of the art, with a dark outline so they stay readable.
          textPaint.textSize = cell * 0.24f
          for (num in 1..100) {
            val (cx, cy) = squareCenter(num, cell)
            val x = cx - cell / 2f + cell * 0.12f
            val y = cy - cell / 2f + cell * 0.12f + textPaint.textSize * 0.8f
            val label = num.toString()
            textPaint.style = Paint.Style.STROKE
            textPaint.strokeWidth = cell * 0.07f
            textPaint.color = android.graphics.Color.argb(230, 8, 12, 24)
            drawContext.canvas.nativeCanvas.drawText(label, x, y, textPaint)
            textPaint.style = Paint.Style.FILL
            textPaint.color =
              when (num) {
                100 -> android.graphics.Color.rgb(255, 224, 130)
                1 -> android.graphics.Color.rgb(120, 255, 180)
                else -> android.graphics.Color.rgb(190, 202, 230)
              }
            drawContext.canvas.nativeCanvas.drawText(label, x, y, textPaint)
          }
        }
        // Moving tokens: separate layer so they never force the board to redraw.
        Canvas(modifier = Modifier.fillMaxSize().graphicsLayer { }.padding(7.dp)) {
          val cell = size.width / 10f
          positions.indices.forEach { idx ->
            val a = tokenAnims[idx]
            val sq = positions[idx]
            val offsetAngle = (idx * 90.0) * Math.PI / 180.0
            val off = if (positions.count { it == sq } > 1) cell * 0.17f else 0f
            val moving = a.isRunning
            val lift = if (moving) cell * 0.10f else 0f
            drawGlossyToken(
              center =
                Offset(
                  a.value.x * cell + (cos(offsetAngle) * off).toFloat(),
                  a.value.y * cell + (sin(offsetAngle) * off).toFloat() - lift,
                ),
              radius = cell * 0.24f,
              baseColor = playerColorFor(idx),
              isHighlighted = idx == currentTurn && winnerIndex == -1,
            )
          }
        }
      }

      GlassGradientCard(
        modifier = Modifier.fillMaxWidth(),
        accentColor = activeColor,
        cornerRadius = 16.dp,
      ) {
        androidx.compose.animation.Crossfade(targetState = eventBanner, animationSpec = androidx.compose.animation.core.tween(220), label = "snakeStatus") { msg ->
          Text(
            text = msg,
            style = MaterialTheme.typography.bodyMedium,
            color = TextPrimary,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
          )
        }
      }

      if (winnerIndex != -1) {
        WinCelebrationBanner(
          winnerTitle = "${playerName(winnerIndex)} برنده شد!",
          subtitle = "به خانه ۱۰۰ رسید",
          accent = playerColorFor(winnerIndex),
          onRematch = { resetGame() },
          onExit = onBack,
        )
      } else {
        val canHumanRoll =
          !isRolling &&
            (playMode != PlayMode.VS_AI || currentTurn == 0) &&
            (playMode != PlayMode.ONLINE_ROOM || currentTurn == myOnlineSide)

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          AnimatedGameDice(
            value = diceValue,
            isRolling = isRolling,
            accentColor = activeColor,
          )

          RollDiceButton(
            title = if (canHumanRoll) "انداختن تاس" else "نوبت حریف...",
            subtitle = if (canHumanRoll) "نوبت ${playerName(currentTurn)}" else null,
            enabled = canHumanRoll,
            accent = activeColor,
            onClick = { scope.launch { performRollAndMove(currentTurn) } },
            modifier = Modifier.weight(1f).testTag("snakes_roll_button"),
          )
        }
      }
    }
  }
}

private fun squareCenter(num: Int, cellSize: Float): Offset {
  val n = num.coerceIn(1, 100) - 1
  val rowFromBottom = n / 10
  val colInRow = n % 10
  val col = if (rowFromBottom % 2 == 0) colInRow else 9 - colInRow
  val rowFromTop = 9 - rowFromBottom
  return Offset((col + 0.5f) * cellSize, (rowFromTop + 0.5f) * cellSize)
}

private val SnakePalette =
  listOf(
    Color(0xFFFB7185) to Color(0xFFFECDD3),
    Color(0xFF2DD4BF) to Color(0xFF99F6E4),
    Color(0xFFFBBF24) to Color(0xFFFDE68A),
    Color(0xFFA78BFA) to Color(0xFFDDD6FE),
    Color(0xFF4ADE80) to Color(0xFFBBF7D0),
  )

private fun DrawScope.drawLadder(p1: Offset, p2: Offset, cell: Float) {
  val dx = p2.x - p1.x
  val dy = p2.y - p1.y
  val len = hypot(dx, dy).coerceAtLeast(1f)
  val ux = dx / len
  val uy = dy / len
  val half = cell * 0.15f
  val nx = -uy * half
  val ny = ux * half
  val shadow = Offset(2.5f, 3.5f)
  val rail = Color(0xFFC98B3C)
  val railLight = Color(0xFFF1C27D)
  val rung = Color(0xFFE2AE62)
  val railW = cell * 0.075f

  // shadow
  for (sgn in listOf(-1f, 1f)) {
    drawLine(
      Color.Black.copy(alpha = 0.35f),
      Offset(p1.x + nx * sgn + shadow.x, p1.y + ny * sgn + shadow.y),
      Offset(p2.x + nx * sgn + shadow.x, p2.y + ny * sgn + shadow.y),
      strokeWidth = railW,
      cap = StrokeCap.Round,
    )
  }
  // rungs
  val rungs = (len / (cell * 0.38f)).toInt().coerceIn(3, 14)
  for (r in 1 until rungs) {
    val t = r.toFloat() / rungs
    val cx = p1.x + dx * t
    val cy = p1.y + dy * t
    drawLine(
      Color.Black.copy(alpha = 0.30f),
      Offset(cx + nx + shadow.x, cy + ny + shadow.y),
      Offset(cx - nx + shadow.x, cy - ny + shadow.y),
      strokeWidth = railW * 0.8f,
      cap = StrokeCap.Round,
    )
    drawLine(
      rung,
      Offset(cx + nx, cy + ny),
      Offset(cx - nx, cy - ny),
      strokeWidth = railW * 0.8f,
      cap = StrokeCap.Round,
    )
  }
  // rails (dark base + light highlight)
  for (sgn in listOf(-1f, 1f)) {
    val a = Offset(p1.x + nx * sgn, p1.y + ny * sgn)
    val b = Offset(p2.x + nx * sgn, p2.y + ny * sgn)
    drawLine(rail, a, b, strokeWidth = railW, cap = StrokeCap.Round)
    drawLine(railLight, a, b, strokeWidth = railW * 0.35f, cap = StrokeCap.Round)
  }
}

private fun DrawScope.drawSnake(
  head: Offset,
  tail: Offset,
  cell: Float,
  colors: Pair<Color, Color>,
  seed: Int,
) {
  val (base, light) = colors
  val dx = tail.x - head.x
  val dy = tail.y - head.y
  val len = hypot(dx, dy).coerceAtLeast(1f)
  val ux = dx / len
  val uy = dy / len
  val nx = -uy
  val ny = ux
  val waves = (len / (cell * 2.2f)).coerceIn(1.5f, 4f)
  val phase = if (seed % 2 == 0) 1f else -1f
  val steps = (len / (cell * 0.09f)).toInt().coerceIn(24, 160)

  fun pointAt(t: Float): Offset {
    val env = kotlin.math.sin(Math.PI * t.toDouble()).toFloat().coerceAtLeast(0f)
    val w = kotlin.math.sin(t * waves * 2f * Math.PI.toFloat()) * cell * 0.34f * env * phase
    return Offset(head.x + dx * t + nx * w, head.y + dy * t + ny * w)
  }

  val pts = List(steps + 1) { pointAt(it.toFloat() / steps) }
  fun radiusAt(t: Float) = cell * (0.20f - 0.15f * t)

  // shadow
  pts.forEachIndexed { i, p ->
    drawCircle(Color.Black.copy(alpha = 0.28f), radiusAt(i.toFloat() / steps), Offset(p.x + 2.5f, p.y + 3.5f))
  }
  // body, tail -> head so the head overlaps
  for (i in steps downTo 0) {
    val t = i.toFloat() / steps
    val band = (i / 4) % 2 == 0
    drawCircle(if (band) base else base.copy(alpha = 0.78f), radiusAt(t), pts[i])
  }
  // belly highlight stripe
  for (i in 0..steps step 2) {
    val t = i.toFloat() / steps
    drawCircle(light.copy(alpha = 0.55f), radiusAt(t) * 0.38f, Offset(pts[i].x - 1.2f, pts[i].y - 1.6f))
  }

  // head
  val hp = pts[0]
  val dir = Offset(hp.x - pts[3].x, hp.y - pts[3].y).let { v ->
    val l = hypot(v.x, v.y).coerceAtLeast(1f)
    Offset(v.x / l, v.y / l)
  }
  val side = Offset(-dir.y, dir.x)
  val hr = cell * 0.25f
  val headC = Offset(hp.x + dir.x * hr * 0.25f, hp.y + dir.y * hr * 0.25f)
  // tongue
  val tongueBase = Offset(headC.x + dir.x * hr * 0.9f, headC.y + dir.y * hr * 0.9f)
  val tongueTip = Offset(headC.x + dir.x * hr * 1.7f, headC.y + dir.y * hr * 1.7f)
  val tw = cell * 0.025f
  drawLine(Color(0xFFF43F5E), tongueBase, tongueTip, strokeWidth = tw * 1.4f, cap = StrokeCap.Round)
  drawLine(Color(0xFFF43F5E), tongueTip, Offset(tongueTip.x + dir.x * hr * 0.35f + side.x * hr * 0.3f, tongueTip.y + dir.y * hr * 0.35f + side.y * hr * 0.3f), strokeWidth = tw, cap = StrokeCap.Round)
  drawLine(Color(0xFFF43F5E), tongueTip, Offset(tongueTip.x + dir.x * hr * 0.35f - side.x * hr * 0.3f, tongueTip.y + dir.y * hr * 0.35f - side.y * hr * 0.3f), strokeWidth = tw, cap = StrokeCap.Round)
  drawCircle(Color.Black.copy(alpha = 0.3f), hr, Offset(headC.x + 2.5f, headC.y + 3.5f))
  drawCircle(base, hr, headC)
  drawCircle(light.copy(alpha = 0.35f), hr * 0.55f, Offset(headC.x - dir.x * hr * 0.15f, headC.y - dir.y * hr * 0.15f))
  // eyes
  for (sgn in listOf(-1f, 1f)) {
    val e = Offset(headC.x + dir.x * hr * 0.25f + side.x * hr * 0.5f * sgn, headC.y + dir.y * hr * 0.25f + side.y * hr * 0.5f * sgn)
    drawCircle(Color.White, hr * 0.30f, e)
    drawCircle(Color(0xFF0B1020), hr * 0.15f, Offset(e.x + dir.x * hr * 0.07f, e.y + dir.y * hr * 0.07f))
  }
}
