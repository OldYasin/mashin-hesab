package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val CyberArcadeColorScheme =
  darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color(0xFF06202E),
    primaryContainer = Color(0xFF0C3A52),
    onPrimaryContainer = NeonCyan,
    secondary = VioletPulse,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF2E1F5C),
    onSecondaryContainer = Color(0xFFDDD6FE),
    tertiary = CyberGold,
    onTertiary = Color(0xFF1F1400),
    tertiaryContainer = Color(0xFF422D05),
    onTertiaryContainer = CyberGold,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = CarbonSurface,
    onSurface = TextPrimary,
    surfaceVariant = ElevatedCard,
    onSurfaceVariant = TextSecondary,
    outline = ElevatedCardStroke,
    error = CrimsonMagenta,
    onError = Color.White,
  )

val BaziShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
  )

@Composable
fun BaziroxTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = CyberArcadeColorScheme,
    typography = Typography,
    shapes = BaziShapes,
    content = content,
  )
}
