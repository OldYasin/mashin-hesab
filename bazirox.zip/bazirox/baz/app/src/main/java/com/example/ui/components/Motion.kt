package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay

/*
 * Shared motion helpers. Everything animates through graphicsLayer, so values are read in the draw
 * phase: no recomposition and no re-layout per frame, which keeps the games smooth even on weak phones.
 */

/** Springy "squish" while the finger is down. Pass the same InteractionSource the clickable uses. */
fun Modifier.pressScale(source: InteractionSource, pressed: Float = 0.93f): Modifier = composed {
  val isPressed by source.collectIsPressedAsState()
  val s by
    animateFloatAsState(
      targetValue = if (isPressed) pressed else 1f,
      animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
      label = "pressScale",
    )
  graphicsLayer {
    scaleX = s
    scaleY = s
  }
}

/** One-shot entrance: fades in while sliding up a little. Use [delayMs] to stagger siblings. */
fun Modifier.appear(delayMs: Int = 0, fromY: Float = 28f): Modifier = composed {
  val p = remember { Animatable(0f) }
  LaunchedEffect(Unit) {
    if (delayMs > 0) delay(delayMs.toLong())
    p.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
  }
  graphicsLayer {
    alpha = p.value
    translationY = (1f - p.value) * fromY
  }
}

/** Bouncy pop whenever [key] changes (e.g. a new move or a revealed hand). */
fun Modifier.popIn(key: Any?, from: Float = 0.4f, skipInitial: Boolean = false): Modifier = composed {
  val p = remember { Animatable(1f) }
  val first = remember { booleanArrayOf(true) }
  LaunchedEffect(key) {
    if (skipInitial && first[0]) {
      first[0] = false
      return@LaunchedEffect
    }
    first[0] = false
    p.snapTo(from)
    p.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMediumLow))
  }
  graphicsLayer {
    val v = p.value
    scaleX = v
    scaleY = v
    alpha = v.coerceIn(0f, 1f)
  }
}
