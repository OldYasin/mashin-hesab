package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Unified modern dark palette: slate surfaces + sky / emerald / amber / rose / violet accents
val ObsidianBg = Color(0xFF0B1020)
val CarbonSurface = Color(0xFF111A2E)
val ElevatedCard = Color(0xFF182238)
val ElevatedCardStroke = Color(0xFF2A3654)

val NeonCyan = Color(0xFF38BDF8)
val NeonCyanDim = Color(0xFF0284C7)
val ElectricEmerald = Color(0xFF34D399)
val CyberGold = Color(0xFFFBBF24)
val CrimsonMagenta = Color(0xFFFB7185)
val VioletPulse = Color(0xFF8B5CF6)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFFCBD5E1)
val TextMuted = Color(0xFF94A3B8)

// Player colors for Ludo / Snakes & Ladders / Connect 4
val PlayerRed = Color(0xFFF87171)
val PlayerGreen = Color(0xFF34D399)
val PlayerYellow = Color(0xFFFACC15)
val PlayerBlue = Color(0xFF60A5FA)
