package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.paint
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import com.example.data.AvatarImage
import com.example.data.RoomChatMessage
import com.example.data.RoomPlayerInfo
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import com.example.data.OnlineRoom

private const val BUBBLE_VISIBLE_MS = 6_000L

internal data class ChatBubble(val id: String, val text: String)

/** Lets GameTopBar show extra content (the room's player avatars) right under the game header. */
val LocalGameTopExtra = androidx.compose.runtime.compositionLocalOf<(@Composable () -> Unit)?> { null }

/**
 * Live turn/score info that the running game publishes so the players strip (the avatar cards) can show
 * whose turn it is. This replaces the duplicate "turn" cards the games used to draw themselves.
 */
class GameHudState {
  /** Lower-cased usernames whose turn it is (one for turn games, several for simultaneous picks). */
  var active by mutableStateOf<Set<String>>(emptySet())
  var scores by mutableStateOf<Map<String, String>>(emptyMap())
  var labelMe by mutableStateOf("نوبت شماست")
  var labelOther by mutableStateOf("نوبت او")
  /** Optional piece colour per seat (Ludo / Snakes & Ladders), drawn as a small dot on the card. */
  var colors by mutableStateOf<Map<String, Color>>(emptyMap())
}

/** Non-null only while an online room is open; offline games keep their own cards. */
val LocalGameHud = androidx.compose.runtime.compositionLocalOf<GameHudState?> { null }

/** Seats in a stable order: host first, then everybody else in join order. */
fun roomSeats(room: OnlineRoom): List<String> =
  (listOf(room.hostUsername) + room.players).distinctBy { it.lowercase() }

/**
 * Called by every game: [activeSeat] is the index of the player whose turn it is (host = 0), -1 for nobody;
 * [scores] are optional short texts per seat shown on the player's card. Does nothing offline.
 */
@Composable
fun PublishRoomHud(
  room: OnlineRoom?,
  activeSeat: Int,
  scores: List<String> = emptyList(),
  activeSeats: Set<Int> = if (activeSeat >= 0) setOf(activeSeat) else emptySet(),
  labelMe: String = "نوبت شماست",
  labelOther: String = "نوبت او",
  colors: List<Color> = emptyList(),
) {
  val hud = LocalGameHud.current
  if (hud != null && room != null) {
    val seats = roomSeats(room)
    val active = activeSeats.mapNotNull { seats.getOrNull(it)?.lowercase() }.toSet()
    val scoreMap = HashMap<String, String>()
    seats.forEachIndexed { i, u -> scores.getOrNull(i)?.let { scoreMap[u.lowercase()] = it } }
    val colorMap = HashMap<String, Color>()
    seats.forEachIndexed { i, u -> colors.getOrNull(i)?.let { colorMap[u.lowercase()] = it } }
    SideEffect {
      hud.colors = colorMap
      hud.active = active
      hud.scores = scoreMap
      hud.labelMe = labelMe
      hud.labelOther = labelOther
    }
    DisposableEffect(hud) {
      onDispose {
        hud.active = emptySet()
        hud.scores = emptyMap()
        hud.colors = emptyMap()
      }
    }
  }
}

/**
 * Top strip (under the game header): one card per seat. I am always on the RIGHT edge, the other
 * players follow towards the LEFT edge, and seats nobody has taken yet show a placeholder, so nothing
 * jumps around when somebody joins. New chat lines pop up as a speech bubble right under the sender.
 */
@Composable
internal fun RoomPlayersStrip(
  state: RoomChatUiState,
  players: List<String>,
  playerInfo: Map<String, RoomPlayerInfo>,
  avatars: Map<String, AvatarImage>,
  me: String,
  capacity: Int = 2,
  hud: GameHudState? = null,
) {
  val ordered = players.filter { it.equals(me, ignoreCase = true) } + players.filterNot { it.equals(me, ignoreCase = true) }
  val seats = maxOf(capacity, ordered.size, 2)
  val compact = seats > 2
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .background(Color(0xFF0E1626))
        .padding(horizontal = 8.dp, vertical = 4.dp),
    // RTL layout: the first child sits on the right edge.
    horizontalArrangement = Arrangement.spacedBy(6.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    for (i in 0 until seats) {
      val username = ordered.getOrNull(i)
      if (username == null) {
        EmptySeat(compact = compact, modifier = Modifier.weight(1f))
      } else {
        val info = playerInfo[username]
        PlayerSlot(
          name = info?.displayName?.ifBlank { null } ?: username,
          colorIndex = info?.colorIndex ?: username.hashCode(),
          image = avatars[username.lowercase()]?.bitmap,
          isMe = username.equals(me, ignoreCase = true),
          bubble = state.bubbles[username.lowercase()],
          isTurn = hud?.active?.contains(username.lowercase()) == true,
          turnLabel = if (username.equals(me, ignoreCase = true)) hud?.labelMe ?: "نوبت شماست" else hud?.labelOther ?: "نوبت او",
          scoreText = hud?.scores?.get(username.lowercase()),
          tokenColor = hud?.colors?.get(username.lowercase()),
          compact = compact,
          onClick = { state.panelOpen = true },
          modifier = Modifier.weight(1f),
        )
      }
    }
  }
}

private val SeatShape = RoundedCornerShape(16.dp)

@Composable
private fun EmptySeat(compact: Boolean, modifier: Modifier = Modifier) {
  Surface(
    modifier = modifier.heightIn(min = 44.dp),
    shape = SeatShape,
    color = Color.White.copy(alpha = 0.03f),
    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)),
  ) {
    val seatContent: @Composable () -> Unit = {
      Box(
        modifier = Modifier.size(30.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.05f)),
        contentAlignment = Alignment.Center,
      ) {
        Text("؟", style = MaterialTheme.typography.titleMedium, color = TextMuted, fontWeight = FontWeight.ExtraBold)
      }
      Text(
        "در انتظار...",
        style = MaterialTheme.typography.labelMedium,
        color = TextMuted,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
    if (compact) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(1.dp),
      ) { seatContent() }
    } else {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) { seatContent() }
    }
  }
}

/** Bottom bar: fixed-height wide pill that looks like a chat input and opens the chat. Never changes size. */
@Composable
internal fun RoomChatBar(
  state: RoomChatUiState,
  playerInfo: Map<String, RoomPlayerInfo>,
  avatars: Map<String, AvatarImage>,
  messages: List<RoomChatMessage>,
  me: String,
  onSend: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier = modifier.fillMaxWidth().background(ObsidianBg).padding(horizontal = 12.dp, vertical = 8.dp),
  ) {
    ChatToggleButton(
      open = state.panelOpen,
      unread = state.unread,
      onClick = { state.panelOpen = !state.panelOpen },
    )
  }
}

/** Chat history + input: floats over the bottom of the game area instead of pushing the game up. */
@Composable
internal fun RoomChatOverlay(
  state: RoomChatUiState,
  playerInfo: Map<String, RoomPlayerInfo>,
  avatars: Map<String, AvatarImage>,
  messages: List<RoomChatMessage>,
  me: String,
  onSend: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  AnimatedVisibility(
    visible = state.panelOpen,
    enter = fadeIn() + expandVertically(expandFrom = Alignment.Bottom),
    exit = fadeOut() + shrinkVertically(shrinkTowards = Alignment.Bottom),
    modifier = modifier.fillMaxWidth().padding(horizontal = 10.dp),
  ) {
    ChatPanel(
      messages = messages,
      playerInfo = playerInfo,
      avatars = avatars,
      me = me,
      onSend = onSend,
      onClose = { state.panelOpen = false },
    )
  }
}

private class BelowAnchorPositionProvider : PopupPositionProvider {
  override fun calculatePosition(
    anchorBounds: IntRect,
    windowSize: IntSize,
    layoutDirection: LayoutDirection,
    popupContentSize: IntSize,
  ): IntOffset {
    val x = (anchorBounds.center.x - popupContentSize.width / 2)
      .coerceIn(8, (windowSize.width - popupContentSize.width - 8).coerceAtLeast(8))
    return IntOffset(x, anchorBounds.bottom + 2)
  }
}

@Composable
private fun PlayerSlot(
  name: String,
  colorIndex: Int,
  image: androidx.compose.ui.graphics.ImageBitmap?,
  isMe: Boolean,
  bubble: ChatBubble?,
  isTurn: Boolean,
  turnLabel: String,
  scoreText: String?,
  tokenColor: Color?,
  compact: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val accent = avatarColorFor(colorIndex)
  var show by remember { mutableStateOf(false) }
  // Each new bubble id restarts the timer; the bubble disappears by itself.
  LaunchedEffect(bubble?.id) {
    if (bubble != null) {
      show = true
      delay(BUBBLE_VISIBLE_MS)
      show = false
    }
  }
  val positionProvider = remember { BelowAnchorPositionProvider() }
  val pulse by
    rememberInfiniteTransition(label = "seatPulse")
      .animateFloat(0.45f, 1f, infiniteRepeatable(tween(850), RepeatMode.Reverse), label = "seatPulseA")
  val ringAlpha = if (isTurn) pulse else 0f
  val fillAlpha by
    androidx.compose.animation.core.animateFloatAsState(
      if (isTurn) 0.30f else if (isMe) 0.14f else 0.07f,
      androidx.compose.animation.core.tween(250),
      label = "seatFill",
    )
  val seatScale by
    androidx.compose.animation.core.animateFloatAsState(
      if (isTurn) 1.03f else 1f,
      androidx.compose.animation.core.spring(dampingRatio = 0.6f, stiffness = 400f),
      label = "seatScale",
    )
  val idleLabel = if (isMe) "شما" else "حریف"

  Box(modifier = modifier.graphicsLayer { scaleX = seatScale; scaleY = seatScale }) {
    Surface(
      onClick = onClick,
      modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
      shape = SeatShape,
      color = accent.copy(alpha = fillAlpha),
      border =
        BorderStroke(
          if (isTurn) 2.dp else if (isMe) 1.5.dp else 1.dp,
          if (isTurn) accent.copy(alpha = ringAlpha) else accent.copy(alpha = if (isMe) 0.7f else 0.35f),
        ),
    ) {
      val nameStyle = MaterialTheme.typography.labelLarge
      @Composable
      fun Avatar(size: androidx.compose.ui.unit.Dp) {
        Box(
          modifier = Modifier.size(size + 8.dp).border(2.dp, accent.copy(alpha = ringAlpha), CircleShape),
          contentAlignment = Alignment.Center,
        ) {
          AvatarBadge(name = name, colorIndex = colorIndex, size = size, image = image)
        }
      }
      if (compact) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 3.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(1.dp),
        ) {
          Avatar(28.dp)
          Text(
            text = if (isMe) "شما" else name,
            style = nameStyle,
            color = if (isMe) NeonCyan else TextPrimary,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          if (isTurn || scoreText != null) {
            Text(
              text = listOfNotNull(if (isTurn) "نوبت" else null, scoreText).joinToString(" · "),
              style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
              color = if (isTurn) accent else TextMuted,
              fontWeight = FontWeight.ExtraBold,
              maxLines = 1,
            )
          }
        }
      } else {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Avatar(32.dp)
          Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text(
              text = name,
              style = nameStyle,
              color = TextPrimary,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              text = if (isTurn) turnLabel else idleLabel,
              style = MaterialTheme.typography.labelSmall,
              color = if (isTurn) accent else if (isMe) NeonCyan else TextMuted,
              fontWeight = if (isTurn) FontWeight.ExtraBold else FontWeight.Normal,
              maxLines = 1,
            )
          }
          if (scoreText != null) {
            Box(
              modifier =
                Modifier.clip(RoundedCornerShape(10.dp))
                  .background(accent.copy(alpha = 0.22f))
                  .padding(horizontal = 9.dp, vertical = 3.dp),
              contentAlignment = Alignment.Center,
            ) {
              Text(
                text = scoreText,
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
              )
            }
          }
        }
      }
    }
    if (tokenColor != null) {
      Box(
        modifier =
          Modifier.align(Alignment.TopStart)
            .padding(5.dp)
            .size(11.dp)
            .clip(CircleShape)
            .background(tokenColor)
            .border(1.5.dp, Color.White.copy(alpha = 0.85f), CircleShape)
      )
    }
    if (show && bubble != null) {
      // Speech bubble floats under the card: it never resizes the strip or pushes the game.
      Popup(popupPositionProvider = positionProvider) {
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = Color(0xFF1B2A41),
          border = BorderStroke(1.dp, accent),
          shadowElevation = 6.dp,
          modifier = Modifier.widthIn(max = 240.dp),
        ) {
          Text(
            text = bubble.text,
            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
            color = TextPrimary,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
          )
        }
      }
    }
  }
}

@Composable
private fun ChatToggleButton(open: Boolean, unread: Int, onClick: () -> Unit) {
  Surface(
    onClick = onClick,
    modifier = Modifier.fillMaxWidth().height(46.dp).testTag("room_chat_toggle"),
    shape = RoundedCornerShape(23.dp),
    color = if (open) NeonCyan.copy(alpha = 0.16f) else Color(0xFF17212B),
    border = BorderStroke(1.dp, if (open) NeonCyan else Color.White.copy(alpha = 0.14f)),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Icon(
        imageVector = BaziIcons.Forum,
        contentDescription = null,
        tint = NeonCyan,
        modifier = Modifier.size(20.dp),
      )
      Text(
        text = if (open) "بستن چت" else "چت بازی",
        style = MaterialTheme.typography.labelLarge,
        color = if (open) NeonCyan else TextSecondary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.weight(1f),
      )
      if (unread > 0 && !open) {
        Box(
          modifier = Modifier.size(22.dp).clip(CircleShape).background(CrimsonMagenta),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = if (unread > 9) "9+" else unread.toString(),
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
            color = Color.White,
            fontWeight = FontWeight.ExtraBold,
          )
        }
      }
    }
  }
}

private fun roomClock(ts: Long): String =
  java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ts))

private val QuickReplies = listOf("👍", "😂", "🔥", "😮", "GG", "دمت گرم")

@Composable
private fun ChatPanel(
  messages: List<RoomChatMessage>,
  playerInfo: Map<String, RoomPlayerInfo>,
  avatars: Map<String, AvatarImage>,
  me: String,
  onSend: (String) -> Unit,
  onClose: () -> Unit,
) {
  val listState = rememberLazyListState()
  var draft by remember { mutableStateOf("") }
  val shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp, bottomStart = 6.dp, bottomEnd = 6.dp)

  LaunchedEffect(messages.size) {
    if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
  }

  fun send(text: String) {
    val t = text.trim()
    if (t.isEmpty()) return
    onSend(t)
    com.example.data.SoundManager.play(com.example.data.Sfx.MSG_SEND)
  }
  fun submit() {
    send(draft)
    draft = ""
  }

  // Fixed share of the game area (header on top, input pinned to the bottom, messages fill the middle).
  // The wallpaper must NOT size the panel: sizeToIntrinsics = false (the old bug stretched it over the whole screen).
  Column(
    modifier =
      Modifier.fillMaxWidth()
        .fillMaxHeight(0.72f)
        .padding(bottom = 4.dp)
        .clip(shape)
        .background(Color(0xFF0E1621))
        .paint(
          androidx.compose.ui.res.painterResource(com.example.R.drawable.bg_chat_cats),
          contentScale = androidx.compose.ui.layout.ContentScale.Crop,
          sizeToIntrinsics = false,
        )
        .border(1.dp, Color.White.copy(alpha = 0.10f), shape)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth().background(Color(0xFF17212B)).padding(start = 16.dp, end = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(BaziIcons.Forum, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
        Text("چت بازی", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
      }
      Surface(
        onClick = onClose,
        modifier = Modifier.padding(vertical = 4.dp).size(40.dp),
        shape = CircleShape,
        color = Color.Transparent,
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(Icons.Rounded.Close, contentDescription = "بستن چت", tint = TextSecondary, modifier = Modifier.size(20.dp))
        }
      }
    }

    // Messages: take all the remaining height, newest line sits right above the input.
    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
      if (messages.isEmpty()) {
        Column(
          modifier = Modifier.align(Alignment.Center).clip(RoundedCornerShape(16.dp)).background(Color(0xCC17212B)).padding(horizontal = 18.dp, vertical = 12.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
          Text("👋", style = MaterialTheme.typography.headlineSmall)
          Text("هنوز پیامی نیست؛ سلام کن!", style = MaterialTheme.typography.bodySmall, color = TextSecondary, textAlign = TextAlign.Center)
        }
      } else {
        LazyColumn(
          state = listState,
          modifier = Modifier.fillMaxSize().testTag("room_chat_list"),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp, Alignment.Bottom),
        ) {
          items(messages, key = { it.id }) { m ->
            val info = playerInfo[m.sender]
            val mine = m.sender.equals(me, ignoreCase = true)
            val name = info?.displayName?.ifBlank { null } ?: m.sender
            val colorIdx = info?.colorIndex ?: m.sender.hashCode()
            val bubbleShape =
              RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp, bottomStart = if (mine) 14.dp else 4.dp, bottomEnd = if (mine) 4.dp else 14.dp)
            // RTL layout: Start = right side (my messages), End = left side (others).
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = if (mine) Arrangement.Start else Arrangement.End,
              verticalAlignment = Alignment.Bottom,
            ) {
              Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Column(
                  modifier =
                    Modifier.widthIn(min = 64.dp, max = 250.dp)
                      .clip(bubbleShape)
                      .background(if (m.failed) Color(0xFF4A1D2B) else if (mine) Color(0xFF2B5278) else Color(0xFF182533))
                      .padding(horizontal = 10.dp, vertical = 5.dp),
                  verticalArrangement = Arrangement.spacedBy(1.dp),
                ) {
                  if (!mine) {
                    Text(
                      text = name,
                      style = MaterialTheme.typography.labelSmall,
                      color = avatarColorFor(colorIdx),
                      fontWeight = FontWeight.ExtraBold,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                  }
                  Text(
                    text = m.text,
                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
                    color = TextPrimary,
                  )
                  Row(
                    modifier = Modifier.align(Alignment.End),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    if (m.failed) {
                      Text("ارسال نشد", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = CrimsonMagenta)
                    }
                    Text(
                      text = roomClock(m.timestamp),
                      style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                      color = if (mine) Color(0xFF9CC4E8) else TextMuted,
                    )
                  }
                }
                if (!mine) {
                  AvatarBadge(name = name, colorIndex = colorIdx, size = 34.dp, image = avatars[m.sender.lowercase()]?.bitmap)
                }
              }
            }
          }
        }
      }
    }

    // Quick reactions
    Row(
      modifier = Modifier.fillMaxWidth().background(Color(0xFF17212B)).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 5.dp),
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      QuickReplies.forEach { q ->
        Surface(
          onClick = { send(q) },
          shape = RoundedCornerShape(50),
          color = Color.White.copy(alpha = 0.07f),
          border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
        ) {
          Text(q, style = MaterialTheme.typography.labelLarge, color = TextPrimary, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
        }
      }
    }

    // Input (always pinned at the bottom)
    Row(
      modifier = Modifier.fillMaxWidth().background(Color(0xFF17212B)).padding(horizontal = 8.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      BasicTextField(
        value = draft,
        onValueChange = { if (it.length <= 200) draft = it },
        singleLine = true,
        textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
        cursorBrush = SolidColor(NeonCyan),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
        keyboardActions = KeyboardActions(onSend = { submit() }),
        modifier = Modifier.weight(1f).testTag("room_chat_input"),
        decorationBox = { inner ->
          Box(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF0E1621))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            contentAlignment = Alignment.CenterStart,
          ) {
            if (draft.isEmpty()) {
              Text("پیام بنویس...", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            }
            inner()
          }
        },
      )
      Surface(
        onClick = { submit() },
        enabled = draft.isNotBlank(),
        modifier = Modifier.size(42.dp).testTag("room_chat_send"),
        shape = CircleShape,
        color = if (draft.isNotBlank()) Color(0xFF2B95E8) else Color.White.copy(alpha = 0.08f),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.Send,
            contentDescription = "ارسال",
            tint = if (draft.isNotBlank()) Color.White else TextMuted,
            modifier = Modifier.size(20.dp),
          )
        }
      }
    }
  }
}
