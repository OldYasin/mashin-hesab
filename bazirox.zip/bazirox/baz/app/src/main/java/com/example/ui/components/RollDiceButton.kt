package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

/**
 * Modern "roll the dice" button shared by Ludo and Snakes & Ladders: dark glass pill with an
 * accent rim, a soft breathing glow while it is your turn, a dice badge and a two-line label.
 * Glow + press squish are drawn / transformed in the draw phase only, so it costs no recomposition.
 */
@Composable
fun RollDiceButton(
  title: String,
  subtitle: String?,
  enabled: Boolean,
  accent: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val src = remember { MutableInteractionSource() }
  val shape = RoundedCornerShape(20.dp)
  val inf = rememberInfiniteTransition(label = "rollGlow")
  val glow by
    inf.animateFloat(
      initialValue = 0.25f,
      targetValue = 0.8f,
      animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
      label = "glow",
    )
  val fill =
    if (enabled) Brush.horizontalGradient(listOf(accent.copy(alpha = 0.26f), accent.copy(alpha = 0.10f)))
    else Brush.horizontalGradient(listOf(Color.White.copy(alpha = 0.05f), Color.White.copy(alpha = 0.03f)))
  val rim = if (enabled) accent.copy(alpha = 0.9f) else Color.White.copy(alpha = 0.10f)

  Box(
    modifier =
      modifier
        .height(62.dp)
        .pressScale(src, 0.96f)
        .drawBehind {
          if (enabled) {
            val r = 20.dp.toPx()
            for (i in 1..3) {
              val grow = i * 3.dp.toPx()
              drawRoundRect(
                color = accent.copy(alpha = glow * 0.12f / i),
                topLeft = Offset(-grow, -grow),
                size = Size(size.width + grow * 2, size.height + grow * 2),
                cornerRadius = CornerRadius(r + grow),
              )
            }
          }
        }
        .clip(shape)
        .background(ObsidianBg)
        .background(fill)
        .border(1.4.dp, rim, shape)
        .clickable(interactionSource = src, indication = null, enabled = enabled, role = Role.Button, onClick = onClick),
    contentAlignment = Alignment.Center,
  ) {
    // Specular strip along the top edge.
    Box(
      Modifier.fillMaxWidth()
        .height(22.dp)
        .align(Alignment.TopCenter)
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = if (enabled) 0.10f else 0.04f), Color.Transparent)))
    )
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
    ) {
      Box(
        modifier = Modifier.size(38.dp).clip(CircleShape).background(if (enabled) accent else Color.White.copy(alpha = 0.08f)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = BaziIcons.Dice,
          contentDescription = null,
          tint = if (enabled) ObsidianBg else TextMuted,
          modifier = Modifier.size(22.dp),
        )
      }
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium,
          color = if (enabled) TextPrimary else TextMuted,
          fontWeight = FontWeight.ExtraBold,
          textAlign = TextAlign.Center,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        if (subtitle != null) {
          Text(
            text = subtitle,
            style = MaterialTheme.typography.labelMedium,
            color = if (enabled) accent else TextMuted.copy(alpha = 0.8f),
            fontWeight = FontWeight.Bold,
            maxLines = 1,
          )
        }
      }
    }
  }
}
