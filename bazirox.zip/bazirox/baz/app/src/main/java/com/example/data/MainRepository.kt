package com.example.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.asImageBitmap
import android.util.Base64
import android.util.LruCache
import com.example.security.CryptoManager
import java.io.File
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Coordinates local encrypted SecureVault and remote Iranian cPanel API.
 * Instant local-first UX with zero lag, plus live cPanel sync whenever configured.
 */
class MainRepository(
  private val vault: SecureVault,
  private val api: CPanelApiClient = CPanelApiClient(),
  private val imageDir: File? = null,
  private val avatarDir: File? = null,
) {

  /** Latest per-user read marks of the last fetched chat (drives double blue ticks). */
  @Volatile var lastReads: Map<String, Long> = emptyMap()
    private set

  private fun imageFile(messageId: String): File? =
    imageDir?.let { File(it, "$messageId.jpg") }

  private fun serverOn(config: CPanelConfig) = config.apiBaseUrl.isNotBlank() && config.isConnected

  fun setSessionExpiredListener(listener: () -> Unit) {
    api.onSessionExpired = listener
  }

  /** Keeps the saved profile numbers in step with the server's (the leaderboard is the source). */
  fun syncSessionStats(totalScore: Int, wins: Int, gamesPlayed: Int): UserAccount? {
    val sess = vault.loadSession() ?: return null
    if (sess.totalScore == totalScore && sess.wins == wins && sess.gamesPlayed == gamesPlayed) return null
    val next = sess.copy(totalScore = totalScore, wins = wins, gamesPlayed = gamesPlayed)
    vault.saveSession(next)
    return next
  }

  fun loadConfig(): CPanelConfig = vault.loadCPanelConfig()

  fun saveConfig(config: CPanelConfig) = vault.saveCPanelConfig(config)

  suspend fun testCPanelConnection(config: CPanelConfig): PingResult {
    val result = api.ping(config)
    val updated =
      config.copy(
        lastTestStatus = result.message,
        lastTestLatencyMs = result.latencyMs,
        isConnected = result.success,
      )
    vault.saveCPanelConfig(updated)
    return result
  }

  fun loadSession(): UserAccount? =
    vault.loadSession()?.also { api.authToken = it.authToken }

  fun logout() {
    api.authToken = ""
    vault.saveSession(null)
  }

  /** Device-local admin gate (slow PBKDF2 + lockout); nothing about it is stored in the APK. */
  /**
   * Admin gate. Connected: the admin password is registered on (and checked by) the server, so it
   * works on every device and nobody can create their own admin. Not connected: only the
   * first-setup password opens the panel.
   */
  suspend fun adminAuth(password: String): AdminAuthResult {
    val config = vault.loadCPanelConfig()
    // Not connected yet: only the first-setup (bootstrap) password opens the panel, so the
    // server address can be entered. Once connected, only the server-registered password works.
    // Release builds ship with the server baked in: always use the server-side admin password,
    // never the local bootstrap one.
    val serverBaked = ServerConfig.isBaked
    if (config.apiBaseUrl.isBlank() || (!config.isConnected && !serverBaked)) {
      val ok =
        withContext(Dispatchers.Default) { CryptoManager.verifyBootstrapAdminPassword(password) }
      return if (ok) AdminAuthResult.Granted else AdminAuthResult.Wrong
    }
    if (password.length < 10) return AdminAuthResult.TooWeak
    val verifier =
      withContext(Dispatchers.Default) {
        CryptoManager.deriveLoginVerifier(CryptoManager.ADMIN_TRIGGER_USER, password)
      }
    val res = api.adminGateRemote(config, verifier)
    return res.fold(
      onSuccess = { created -> if (created) AdminAuthResult.Created else AdminAuthResult.Granted },
      onFailure = { e ->
        if (e.message.orEmpty().contains("تلاش‌های ناموفق")) AdminAuthResult.Locked(300)
        else AdminAuthResult.Wrong
      },
    )
  }

  /** Decrypts group name/preview with the local group key and builds the full invite code. */
  private fun decorateGroup(g: ChatGroup): ChatGroup {
    // Private chat: derive its key from the shared origin group's key (once, then stored like any group key).
    if (g.isDm && g.dmOrigin.isNotBlank() && vault.loadGroupKey(g.id) == null) {
      vault.loadGroupKey(g.dmOrigin)?.let { vault.saveGroupKey(g.id, CryptoManager.deriveDmKey(it, g.id)) }
    }
    val key = vault.loadGroupKey(g.id)
    if (key == null) {
      return g.copy(
        name = if (g.name.startsWith("e1:")) "گروه رمزنگاری‌شده" else g.name,
        lastMessagePreview = if (g.lastMessagePreview.startsWith("e1:")) "" else g.lastMessagePreview,
        description = if (g.description.startsWith("e1:")) "" else g.description,
      )
    }
    val name =
      if (g.name.startsWith("e1:")) {
        CryptoManager.e2eeDecrypt(g.name, key, CPanelApiClient.AAD_GROUP_NAME) ?: "گروه رمزنگاری‌شده"
      } else g.name
    val preview =
      if (g.lastMessagePreview.startsWith("e1:")) {
        CryptoManager.e2eeDecrypt(g.lastMessagePreview, key, CPanelApiClient.AAD_PREVIEW) ?: ""
      } else g.lastMessagePreview
    val description =
      if (g.description.startsWith("e1:")) {
        CryptoManager.e2eeDecrypt(g.description, key, CPanelApiClient.AAD_GROUP_DESC) ?: ""
      } else g.description
    return g.copy(
      name = name,
      lastMessagePreview = preview,
      description = description,
      shareCode = if (g.isDm) "" else g.inviteCode + "." + CryptoManager.encodeKey(key),
    )
  }

  suspend fun register(
    username: String,
    password: String,
    displayName: String,
    avatarColorIndex: Int,
  ): Result<UserAccount> {
    val cleanUser = username.trim()
    if (cleanUser.length < 3) {
      return Result.failure(IllegalArgumentException("نام کاربری باید حداقل ۳ کاراکتر باشد"))
    }
    if (password.length < 6) {
      return Result.failure(IllegalArgumentException("رمز عبور باید حداقل ۶ کاراکتر باشد"))
    }
    val config = vault.loadCPanelConfig()
    // A server address exists: accounts live only on the server (no local-only accounts, and no
    // dependence on the background connection test having finished yet).
    if (config.apiBaseUrl.isNotBlank()) {
      val verifier =
        withContext(Dispatchers.Default) { CryptoManager.deriveLoginVerifier(cleanUser, password) }
      val remote =
        api.registerRemote(config, cleanUser, verifier, displayName.ifBlank { cleanUser }, avatarColorIndex)
      if (remote.isSuccess) {
        val acc = remote.getOrThrow()
        api.authToken = acc.authToken
        vault.saveSession(acc)
        return Result.success(acc)
      }
      return remote
    }
    return vault.registerLocalUser(cleanUser, password, displayName, avatarColorIndex)
  }

  suspend fun login(username: String, password: String): Result<UserAccount> {
    val cleanUser = username.trim()
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank()) {
      val verifier =
        withContext(Dispatchers.Default) { CryptoManager.deriveLoginVerifier(cleanUser, password) }
      val remote = api.loginRemote(config, cleanUser, verifier)
      if (remote.isSuccess) {
        val acc = remote.getOrThrow()
        api.authToken = acc.authToken
        vault.saveSession(acc)
        return Result.success(acc)
      }
      return remote
    }
    return vault.loginLocalUser(cleanUser, password)
  }

  // Vault (Android KeyStore) decrypt/encrypt + JSON work must never run on the main thread.
  suspend fun recordMatchResult(
    gameType: GameType,
    deltaScore: Int,
    didWin: Boolean,
  ): UserAccount? = withContext(Dispatchers.IO) { recordMatchResultImpl(gameType, deltaScore, didWin) }

  private suspend fun recordMatchResultImpl(
    gameType: GameType,
    deltaScore: Int,
    didWin: Boolean,
  ): UserAccount? {
    val session = vault.loadSession() ?: return null
    val updated = vault.updateUserStats(session.username, deltaScore, didWin, gameType)
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      api.submitScore(config, session.authToken, session.username, gameType, deltaScore, didWin)
    }
    return updated
  }

  // Vault (Android KeyStore) decrypt/encrypt + JSON work must never run on the main thread.
  suspend fun getLeaderboard(currentUsername: String?): List<LeaderboardEntry> =
    withContext(Dispatchers.IO) { getLeaderboardImpl(currentUsername) }

  private suspend fun getLeaderboardImpl(currentUsername: String?): List<LeaderboardEntry> {
    if (currentUsername.isNullOrBlank()) return emptyList()
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank()) {
      // Server is the single source of truth: never show fake local rankings.
      return api.fetchLeaderboard(config, currentUsername).getOrDefault(emptyList())
    }
    return vault.getLocalLeaderboard(currentUsername)
  }

  // --- Chat Groups & Invites ---

  // Vault (Android KeyStore) decrypt/encrypt + JSON work must never run on the main thread.
  suspend fun getChatGroups(username: String?): List<ChatGroup> =
    withContext(Dispatchers.IO) { getChatGroupsImpl(username) }

  private suspend fun getChatGroupsImpl(username: String?): List<ChatGroup> {
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected && !username.isNullOrBlank()) {
      val remote = api.fetchGroups(config, username)
      if (remote.isSuccess) {
        val list = remote.getOrThrow().map { decorateGroup(it) }
        vault.saveChatGroups(list)
        return list
      }
    }
    val local = vault.loadChatGroups()
    return if (username.isNullOrBlank()) local
    else local.filter { it.members.any { m -> m.equals(username, ignoreCase = true) } || it.ownerUsername.equals(username, ignoreCase = true) }
  }

  // Vault (Android KeyStore) decrypt/encrypt + JSON work must never run on the main thread.
  suspend fun createGroup(name: String, ownerUsername: String): Result<ChatGroup> =
    withContext(Dispatchers.IO) { createGroupImpl(name, ownerUsername) }

  private suspend fun createGroupImpl(name: String, ownerUsername: String): Result<ChatGroup> {
    val cleanName = name.trim()
    if (cleanName.length < 2) {
      return Result.failure(IllegalArgumentException("نام گروه باید حداقل ۲ حرف باشد"))
    }
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      val key = CryptoManager.generateGroupKey()
      val encName = CryptoManager.e2eeEncrypt(cleanName, key, CPanelApiClient.AAD_GROUP_NAME)
      val remote = api.createOrJoinGroup(config, "group_create", ownerUsername, encName)
      if (remote.isSuccess) {
        val created = remote.getOrThrow()
        vault.saveGroupKey(created.id, key)
        val g = decorateGroup(created)
        vault.saveChatGroups(listOf(g) + vault.loadChatGroups().filterNot { it.id == g.id })
        return Result.success(g)
      }
      return remote
    }
    val inviteCode = CryptoManager.generateSaltHex(3).uppercase()
    val newGroup =
      ChatGroup(
        id = "grp_" + UUID.randomUUID().toString().take(8),
        name = cleanName,
        inviteCode = inviteCode,
        ownerUsername = ownerUsername,
        members = listOf(ownerUsername),
        lastMessagePreview = "گروه ساخته شد",
        lastMessageTime = System.currentTimeMillis(),
      )
    vault.saveChatGroups(listOf(newGroup) + vault.loadChatGroups())
    return Result.success(newGroup)
  }

  // Vault (Android KeyStore) decrypt/encrypt + JSON work must never run on the main thread.
  suspend fun joinGroupByCode(inviteCode: String, username: String): Result<JoinResult> =
    withContext(Dispatchers.IO) { joinGroupByCodeImpl(inviteCode, username) }

  private suspend fun joinGroupByCodeImpl(inviteCode: String, username: String): Result<JoinResult> {
    val cleanCode = inviteCode.trim().uppercase()
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      val sep = inviteCode.trim().indexOf('.')
      val serverCode =
        (if (sep > 0) inviteCode.trim().substring(0, sep) else inviteCode.trim()).trim().uppercase()
      val key = if (sep > 0) CryptoManager.decodeKey(inviteCode.trim().substring(sep + 1).trim()) else null
      if (key == null) {
        return Result.failure(
          IllegalArgumentException("کد دعوت کامل را وارد کن (کد و کلید رمزنگاری، با یک نقطه بینشان)")
        )
      }
      val remote = api.joinGroup(config, serverCode)
      if (remote.isSuccess) {
        val (joined, pending) = remote.getOrThrow()
        val plainName = CryptoManager.e2eeDecrypt(joined.name, key, CPanelApiClient.AAD_GROUP_NAME)
        if (plainName == null) {
          return Result.failure(IllegalArgumentException("کلید رمزنگاری در کد دعوت اشتباه است"))
        }
        // The key stays on this device so the chat works right away once the owner approves.
        vault.saveGroupKey(joined.id, key)
        if (pending) return Result.success(JoinResult.Pending(plainName))
        val g = decorateGroup(joined)
        vault.saveChatGroups(listOf(g) + vault.loadChatGroups().filterNot { it.id == g.id })
        return Result.success(JoinResult.Joined(g))
      }
      return Result.failure(remote.exceptionOrNull() ?: IllegalStateException("ورود به گروه ناموفق بود"))
    }
    val existing = vault.loadChatGroups().toMutableList()
    val idx = existing.indexOfFirst { it.inviteCode.equals(cleanCode, ignoreCase = true) }
    if (idx < 0) {
      return Result.failure(IllegalArgumentException("گروهی با این کد دعوت پیدا نشد"))
    }
    val grp = existing[idx]
    val updated =
      if (grp.members.any { it.equals(username, ignoreCase = true) }) grp
      else grp.copy(members = grp.members + username)
    existing[idx] = updated
    vault.saveChatGroups(existing)
    return Result.success(JoinResult.Joined(updated))
  }

  /** Pending join requests of a group (owner only, server mode). */
  suspend fun getJoinRequests(groupId: String): Result<List<JoinRequest>> =
    withContext(Dispatchers.IO) {
      val config = vault.loadCPanelConfig()
      if (!serverOn(config)) Result.success(emptyList()) else api.fetchJoinRequests(config, groupId)
    }

  suspend fun resolveJoinRequest(groupId: String, username: String, approve: Boolean): Result<ChatGroup> =
    withContext(Dispatchers.IO) {
      val config = vault.loadCPanelConfig()
      if (!serverOn(config)) {
        return@withContext Result.failure(IllegalStateException("اتصال به سرور برقرار نیست"))
      }
      val remote = api.resolveJoinRequest(config, groupId, username, approve)
      if (remote.isFailure) return@withContext remote
      val g = decorateGroup(remote.getOrThrow())
      vault.saveChatGroups(vault.loadChatGroups().map { if (it.id == groupId) g else it })
      Result.success(g)
    }

  // Vault (Android KeyStore) decrypt/encrypt + JSON work must never run on the main thread.
  suspend fun inviteMemberToGroup(groupId: String, targetUsername: String): Result<ChatGroup> =
    withContext(Dispatchers.IO) { inviteMemberToGroupImpl(groupId, targetUsername) }

  private suspend fun inviteMemberToGroupImpl(groupId: String, targetUsername: String): Result<ChatGroup> {
    val cleanTarget = targetUsername.trim()
    if (cleanTarget.length < 2) {
      return Result.failure(IllegalArgumentException("نام کاربری معتبر نیست"))
    }
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      val remote = api.inviteMemberToGroup(config, groupId, cleanTarget)
      if (remote.isSuccess) {
        val g = decorateGroup(remote.getOrThrow())
        vault.saveChatGroups(vault.loadChatGroups().map { if (it.id == groupId) g else it })
        return Result.success(g)
      }
      return remote
    }
    val existing = vault.loadChatGroups().toMutableList()
    val idx = existing.indexOfFirst { it.id == groupId }
    if (idx < 0) return Result.failure(IllegalArgumentException("گروه یافت نشد"))
    val grp = existing[idx]
    val updated =
      if (grp.members.any { it.equals(cleanTarget, ignoreCase = true) }) grp
      else grp.copy(members = grp.members + cleanTarget)
    existing[idx] = updated
    vault.saveChatGroups(existing)
    return Result.success(updated)
  }

  // Leave a group (any member). If the owner leaves, the server hands ownership to the next member.
  suspend fun leaveGroup(groupId: String, username: String): Result<Unit> =
    withContext(Dispatchers.IO) { leaveGroupImpl(groupId, username) }

  private suspend fun leaveGroupImpl(groupId: String, username: String): Result<Unit> {
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      val remote = api.leaveGroup(config, groupId)
      if (remote.isFailure) return remote
      vault.saveChatGroups(vault.loadChatGroups().filterNot { it.id == groupId })
      vault.removeGroupLocalData(groupId)
      return Result.success(Unit)
    }
    val existing = vault.loadChatGroups()
    val grp = existing.firstOrNull { it.id == groupId }
      ?: return Result.failure(IllegalArgumentException("گروه یافت نشد"))
    val remaining = grp.members.filterNot { it.equals(username, ignoreCase = true) }
    if (remaining.isEmpty()) {
      vault.saveChatGroups(existing.filterNot { it.id == groupId })
      vault.removeGroupLocalData(groupId)
    } else {
      val newOwner =
        if (grp.ownerUsername.equals(username, ignoreCase = true)) remaining.first() else grp.ownerUsername
      vault.saveChatGroups(
        existing.map { if (it.id == groupId) it.copy(members = remaining, ownerUsername = newOwner) else it }
      )
    }
    return Result.success(Unit)
  }

  // --- Public profiles + private chats (server mode only) ---
  suspend fun getUserProfile(username: String): Result<UserProfile> =
    withContext(Dispatchers.IO) {
      val config = vault.loadCPanelConfig()
      if (!serverOn(config)) Result.failure(IllegalStateException("اتصال به سرور برقرار نیست"))
      else api.getProfile(config, username)
    }

  suspend fun setBio(bio: String): Result<String> =
    withContext(Dispatchers.IO) {
      val config = vault.loadCPanelConfig()
      if (!serverOn(config)) Result.failure(IllegalStateException("اتصال به سرور برقرار نیست"))
      else api.setBio(config, bio.trim().take(300))
    }

  suspend fun openDirectChat(targetUsername: String, originGroupId: String): Result<ChatGroup> =
    withContext(Dispatchers.IO) {
      val config = vault.loadCPanelConfig()
      if (!serverOn(config)) {
        return@withContext Result.failure(IllegalStateException("برای پیام خصوصی باید به سرور وصل باشی"))
      }
      if (vault.loadGroupKey(originGroupId) == null) {
        return@withContext Result.failure(IllegalStateException("کلید این گروه روی این دستگاه نیست"))
      }
      val remote = api.openDm(config, targetUsername, originGroupId)
      if (remote.isFailure) return@withContext remote
      val g = decorateGroup(remote.getOrThrow())
      if (vault.loadGroupKey(g.id) == null) {
        return@withContext Result.failure(
          IllegalStateException("کلید این گفتگو روی دستگاه تو نیست (گروه مشترکی که با آن شروع شده را ترک کرده‌ای)")
        )
      }
      vault.saveChatGroups(listOf(g) + vault.loadChatGroups().filterNot { it.id == g.id })
      Result.success(g)
    }

  // Change group name / description (owner only). Both are encrypted with the group key.
  suspend fun updateGroup(
    groupId: String,
    username: String,
    newName: String,
    newDescription: String,
  ): Result<ChatGroup> = withContext(Dispatchers.IO) {
    val cleanName = newName.trim().take(36)
    val cleanDesc = newDescription.trim().take(200)
    if (cleanName.length < 2) {
      return@withContext Result.failure(IllegalArgumentException("نام گروه باید حداقل ۲ حرف باشد"))
    }
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      val key = vault.loadGroupKey(groupId)
        ?: return@withContext Result.failure(IllegalStateException("کلید گروه روی این دستگاه نیست"))
      val encName = CryptoManager.e2eeEncrypt(cleanName, key, CPanelApiClient.AAD_GROUP_NAME)
      val encDesc =
        if (cleanDesc.isEmpty()) "" else CryptoManager.e2eeEncrypt(cleanDesc, key, CPanelApiClient.AAD_GROUP_DESC)
      val remote = api.updateGroup(config, groupId, encName, encDesc)
      if (remote.isFailure) return@withContext remote
      val g = decorateGroup(remote.getOrThrow())
      vault.saveChatGroups(vault.loadChatGroups().map { if (it.id == groupId) g else it })
      return@withContext Result.success(g)
    }
    val existing = vault.loadChatGroups()
    val grp = existing.firstOrNull { it.id == groupId }
      ?: return@withContext Result.failure(IllegalArgumentException("گروه یافت نشد"))
    if (!grp.ownerUsername.equals(username, ignoreCase = true)) {
      return@withContext Result.failure(IllegalArgumentException("فقط سازنده‌ی گروه می‌تواند مشخصات را تغییر دهد"))
    }
    val updated = grp.copy(name = cleanName, description = cleanDesc)
    vault.saveChatGroups(existing.map { if (it.id == groupId) updated else it })
    Result.success(updated)
  }

  // Delete a group for everybody (owner only).
  suspend fun deleteGroup(groupId: String, username: String): Result<Unit> =
    withContext(Dispatchers.IO) { deleteGroupImpl(groupId, username) }

  private suspend fun deleteGroupImpl(groupId: String, username: String): Result<Unit> {
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      val remote = api.deleteGroup(config, groupId)
      if (remote.isFailure) return remote
    } else {
      val grp = vault.loadChatGroups().firstOrNull { it.id == groupId }
        ?: return Result.failure(IllegalArgumentException("گروه یافت نشد"))
      if (!grp.ownerUsername.equals(username, ignoreCase = true)) {
        return Result.failure(IllegalArgumentException("فقط سازنده‌ی گروه می‌تواند آن را حذف کند"))
      }
    }
    vault.saveChatGroups(vault.loadChatGroups().filterNot { it.id == groupId })
    vault.removeGroupLocalData(groupId)
    return Result.success(Unit)
  }

  // Vault (Android KeyStore) decrypt/encrypt + JSON work must never run on the main thread.
  suspend fun getMessages(groupId: String, viewer: String? = null): List<ChatMessage> =
    withContext(Dispatchers.IO) { getMessagesImpl(groupId, viewer) }

  private suspend fun getMessagesImpl(groupId: String, viewer: String?): List<ChatMessage> {
    val config = vault.loadCPanelConfig()
    if (serverOn(config)) {
      val remote = api.fetchMessages(config, groupId, vault.loadGroupKey(groupId))
      if (remote.isSuccess) {
        val page = remote.getOrThrow()
        lastReads = page.reads
        val remoteIds = page.messages.mapTo(HashSet()) { it.id }
        // keep my not-yet-delivered / failed messages so they never "disappear" while polling
        val pending =
          vault.loadChatMessages(groupId).filter {
            it.sendState != SendState.SENT && it.id !in remoteIds
          }
        val merged = (page.messages + pending).sortedBy { it.timestamp }
        vault.saveChatMessages(groupId, merged)
        return merged
      }
    }
    return vault.loadChatMessages(groupId)
  }

  /** Saves the message locally right away (clock tick); [deliverMessage] then uploads it. */
  fun queueMessage(
    groupId: String,
    senderUsername: String,
    senderColorIndex: Int,
    text: String,
    gameInvite: GameInvite? = null,
    draftImage: File? = null,
    replyTo: ChatMessage? = null,
  ): Pair<ChatMessage, List<ChatMessage>> {
    val id = "msg_" + UUID.randomUUID().toString().take(10)
    var hasImage = false
    if (draftImage != null && draftImage.exists()) {
      val dest = imageFile(id)
      if (dest != null) {
        dest.parentFile?.mkdirs()
        draftImage.copyTo(dest, overwrite = true)
        draftImage.delete()
        hasImage = true
      }
    }
    val msg =
      ChatMessage(
        id = id,
        groupId = groupId,
        senderUsername = senderUsername,
        senderColorIndex = senderColorIndex,
        text = text.trim(),
        timestamp = System.currentTimeMillis(),
        gameInvite = gameInvite,
        hasImage = hasImage,
        replyToId = replyTo?.id,
        replyToSender = replyTo?.senderUsername,
        replyToText =
          replyTo?.let { (if (it.hasImage && it.text.isBlank()) "📷 عکس" else it.text).take(80) },
        sendState = if (serverOn(vault.loadCPanelConfig())) SendState.SENDING else SendState.SENT,
      )
    val current = vault.loadChatMessages(groupId) + msg
    vault.saveChatMessages(groupId, current)
    vault.saveChatGroups(
      vault.loadChatGroups().map { g ->
        if (g.id == groupId)
          g.copy(lastMessagePreview = previewOf(msg), lastMessageTime = msg.timestamp)
        else g
      }
    )
    return msg to current
  }

  // Vault (Android KeyStore) decrypt/encrypt + JSON work must never run on the main thread.
  suspend fun deliverMessage(msg: ChatMessage): List<ChatMessage> =
    withContext(Dispatchers.IO) { deliverMessageImpl(msg) }

  private suspend fun deliverMessageImpl(msg: ChatMessage): List<ChatMessage> {
    val config = vault.loadCPanelConfig()
    if (!serverOn(config)) return vault.loadChatMessages(msg.groupId)
    // Never send plaintext: without the group key the message stays "failed" on this device.
    val key = vault.loadGroupKey(msg.groupId)
      ?: return setSendState(msg.groupId, msg.id, SendState.FAILED)
    val encImage =
      if (msg.hasImage) {
        withContext(Dispatchers.IO) {
          imageFile(msg.id)?.takeIf { it.exists() }?.let {
            CryptoManager.e2eeEncryptBytes(it.readBytes(), key, "${msg.groupId}|${msg.id}|img")
          }
        }
      } else null
    val ok = api.sendMessage(config, msg, encImage, key, previewOf(msg)).isSuccess
    return setSendState(msg.groupId, msg.id, if (ok) SendState.SENT else SendState.FAILED)
  }

  fun setSendState(groupId: String, messageId: String, state: Int): List<ChatMessage> {
    val updated =
      vault.loadChatMessages(groupId).map { if (it.id == messageId) it.copy(sendState = state) else it }
    vault.saveChatMessages(groupId, updated)
    return updated
  }

  /**
   * Deletes a message for everybody (sender, or the group owner on the server).
   * Messages that never reached the server (sending/failed) are only removed locally.
   */
  suspend fun deleteMessage(msg: ChatMessage): Result<List<ChatMessage>> =
    withContext(Dispatchers.IO) {
      val config = vault.loadCPanelConfig()
      if (serverOn(config) && msg.sendState == SendState.SENT) {
        val remote = api.deleteMessage(config, msg.id)
        if (remote.isFailure) {
          return@withContext Result.failure(remote.exceptionOrNull() ?: IllegalStateException("حذف پیام ناموفق بود"))
        }
      }
      val updated = vault.loadChatMessages(msg.groupId).filterNot { it.id == msg.id }
      vault.saveChatMessages(msg.groupId, updated)
      if (msg.hasImage) imageFile(msg.id)?.delete()
      val last = updated.lastOrNull()
      vault.saveChatGroups(
        vault.loadChatGroups().map { g ->
          if (g.id == msg.groupId && g.lastMessageTime == msg.timestamp) {
            g.copy(lastMessagePreview = last?.let { previewOf(it) } ?: "", lastMessageTime = last?.timestamp ?: 0L)
          } else g
        }
      )
      Result.success(updated)
    }

  fun findMessage(groupId: String, messageId: String): ChatMessage? =
    vault.loadChatMessages(groupId).firstOrNull { it.id == messageId }

  /** Convenience used for game invites: queue + deliver in one go. */
  suspend fun sendMessage(
    groupId: String,
    senderUsername: String,
    senderColorIndex: Int,
    text: String,
    gameInvite: GameInvite? = null,
  ): List<ChatMessage> {
    val (msg, _) = queueMessage(groupId, senderUsername, senderColorIndex, text, gameInvite)
    return deliverMessage(msg).ifEmpty { vault.loadChatMessages(groupId) }
  }

  private fun previewOf(m: ChatMessage): String =
    if (m.hasImage) "📷 " + m.text.ifBlank { "عکس" } else m.text

  fun newDraftFile(cacheDir: File): File = File(cacheDir, "draft_${System.currentTimeMillis()}.jpg")

  /** Loads (and caches) the bitmap of an image message; downloads it from the server if needed. */
  suspend fun loadImage(msg: ChatMessage, maxDim: Int = 900): Bitmap? =
    withContext(Dispatchers.IO) {
      val key = "${msg.id}@$maxDim"
      imageCache.get(key)?.let { return@withContext it }
      val file = imageFile(msg.id) ?: return@withContext null
      if (!file.exists() && msg.hasImage) {
        val config = vault.loadCPanelConfig()
        if (serverOn(config)) {
          val res = api.fetchMessageImage(config, msg.id)
          val enc = res.getOrNull().orEmpty()
          val key = vault.loadGroupKey(msg.groupId)
          if (enc.isNotEmpty() && key != null) {
            val bytes = CryptoManager.e2eeDecryptBytes(enc, key, "${msg.groupId}|${msg.id}|img")
            if (bytes != null) {
              try {
                file.parentFile?.mkdirs()
                file.writeBytes(bytes)
              } catch (_: Throwable) {}
            }
          }
        }
      }
      val bmp = ChatImageUtils.decodeSampled(file, maxDim)
      if (bmp != null) imageCache.put(key, bmp)
      bmp
    }

  // --- Profile: display name + avatar photo ---

  private fun avatarKey(username: String): String =
    java.net.URLEncoder.encode(username.trim().lowercase(), "UTF-8")

  private fun avatarFile(username: String): File? = avatarDir?.let { File(it, avatarKey(username) + ".jpg") }

  private fun avatarVerFile(username: String): File? = avatarDir?.let { File(it, avatarKey(username) + ".ver") }

  private fun loadAvatarFromDisk(username: String): AvatarImage? {
    val f = avatarFile(username) ?: return null
    if (!f.exists()) return null
    val bmp = BitmapFactory.decodeFile(f.absolutePath) ?: return null
    val ver = avatarVerFile(username)?.takeIf { it.exists() }?.readText()?.trim()?.toLongOrNull() ?: 0L
    return AvatarImage(ver, bmp.asImageBitmap())
  }

  private fun storeAvatar(username: String, jpeg: ByteArray, ver: Long) {
    val f = avatarFile(username) ?: return
    f.parentFile?.mkdirs()
    f.writeBytes(jpeg)
    avatarVerFile(username)?.writeText(ver.toString())
  }

  private fun dropAvatar(username: String) {
    avatarFile(username)?.delete()
    avatarVerFile(username)?.delete()
  }

  /**
   * Loads the cached photos of [usernames] and refreshes them from the server (only changed photos
   * are downloaded). Returns every photo that exists, keyed by lowercase username.
   */
  suspend fun syncAvatars(usernames: List<String>): Map<String, AvatarImage> =
    withContext(Dispatchers.IO) {
      val names = usernames.map { it.trim().lowercase() }.filter { it.isNotEmpty() }.distinct().take(8)
      val result = mutableMapOf<String, AvatarImage>()
      names.forEach { n -> loadAvatarFromDisk(n)?.let { result[n] = it } }
      val config = vault.loadCPanelConfig()
      if (names.isNotEmpty() && serverOn(config)) {
        api.getAvatars(config, names, result.mapValues { it.value.ver }).onSuccess { list ->
          list.forEach { a ->
            val key = a.username.trim().lowercase()
            if (a.imageB64.isEmpty()) {
              dropAvatar(key)
              result.remove(key)
            } else {
              val bytes = try { Base64.decode(a.imageB64, Base64.DEFAULT) } catch (_: Throwable) { null }
              if (bytes != null) {
                storeAvatar(key, bytes, a.ver)
                loadAvatarFromDisk(key)?.let { result[key] = it }
              }
            }
          }
        }
      }
      result
    }

  suspend fun uploadAvatar(username: String, jpeg: ByteArray): Result<Unit> =
    withContext(Dispatchers.IO) {
      val config = vault.loadCPanelConfig()
      if (!serverOn(config)) return@withContext Result.failure(IllegalStateException("برای تغییر عکس باید به سرور وصل باشید"))
      api.setAvatar(config, Base64.encodeToString(jpeg, Base64.NO_WRAP)).map { ver -> storeAvatar(username, jpeg, ver) }
    }

  suspend fun uploadGroupAvatar(groupId: String, jpeg: ByteArray): Result<Unit> =
    withContext(Dispatchers.IO) {
      val config = vault.loadCPanelConfig()
      if (!serverOn(config)) return@withContext Result.failure(IllegalStateException("برای تغییر عکس باید به سرور وصل باشید"))
      api.setGroupAvatar(config, groupId, Base64.encodeToString(jpeg, Base64.NO_WRAP)).map { ver ->
        storeAvatar("g:$groupId", jpeg, ver)
      }
    }

  suspend fun removeGroupAvatar(groupId: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      val config = vault.loadCPanelConfig()
      if (!serverOn(config)) return@withContext Result.failure(IllegalStateException("برای تغییر عکس باید به سرور وصل باشید"))
      api.setGroupAvatar(config, groupId, "").map { dropAvatar("g:$groupId") }
    }

  suspend fun removeAvatar(username: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      val config = vault.loadCPanelConfig()
      if (!serverOn(config)) return@withContext Result.failure(IllegalStateException("برای تغییر عکس باید به سرور وصل باشید"))
      api.setAvatar(config, "").map { dropAvatar(username) }
    }

  suspend fun updateDisplayName(name: String): Result<UserAccount> =
    withContext(Dispatchers.IO) {
      val config = vault.loadCPanelConfig()
      if (!serverOn(config)) return@withContext Result.failure(IllegalStateException("برای تغییر نام باید به سرور وصل باشید"))
      val res = api.updateProfile(config, name)
      val newName = res.getOrNull() ?: return@withContext Result.failure(res.exceptionOrNull() ?: IllegalStateException("خطا"))
      val sess = vault.loadSession() ?: return@withContext Result.failure(IllegalStateException("نشست یافت نشد"))
      val next = sess.copy(displayName = newName)
      vault.saveSession(next)
      Result.success(next)
    }

  // --- Online Game Rooms ---

  suspend fun createOnlineRoom(gameType: GameType, username: String): Result<OnlineRoom> {
    val code = "BZ" + CryptoManager.generateSaltHex(5).uppercase()
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      return api.createOrJoinRoom(config, "room_create", code, gameType, username)
    }
    // Local lobby preview mode when cPanel server is not yet attached
    return Result.success(
      OnlineRoom(
        roomCode = code,
        gameType = gameType,
        hostUsername = username,
        players = listOf(username),
        status = "waiting",
        version = 1,
      )
    )
  }

  suspend fun joinOnlineRoom(roomCode: String, gameType: GameType, username: String): Result<OnlineRoom> {
    val cleanCode = roomCode.trim().uppercase()
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      return api.createOrJoinRoom(config, "room_join", cleanCode, gameType, username)
    }
    return Result.failure(
      IllegalStateException("برای پیوستن به اتاق دوستان آنلاین، ابتدا هاست سی‌پنل ایران را در پنل مدیریت متصل کنید")
    )
  }

  suspend fun syncOnlineRoom(roomCode: String, gameType: GameType, username: String): Result<OnlineRoom> {
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      return api.createOrJoinRoom(config, "room_sync", roomCode, gameType, username)
    }
    return Result.failure(IllegalStateException("آفلاین"))
  }

  /** Cheap change-token check; takes an already-loaded config (no Keystore decrypt per poll). */
  suspend fun peekOnlineRoom(config: CPanelConfig, roomCode: String): Result<RoomTokens> =
    api.peekRoom(config, roomCode)

  suspend fun sendRoomChat(config: CPanelConfig, roomCode: String, id: String, text: String): Result<Unit> =
    api.sendRoomChat(config, roomCode, id, text)

  suspend fun listRoomChat(config: CPanelConfig, roomCode: String, since: Long): Result<RoomChatPage> =
    api.listRoomChat(config, roomCode, since)

  suspend fun pushOnlineMove(
    roomCode: String,
    username: String,
    stateJson: String,
    status: String,
    version: Int,
  ): Result<OnlineRoom> {
    val config = vault.loadCPanelConfig()
    if (config.apiBaseUrl.isNotBlank() && config.isConnected) {
      return api.pushRoomMove(config, roomCode, username, stateJson, status, version)
    }
    return Result.failure(IllegalStateException("آفلاین"))
  }

  private companion object {
    val imageCache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
      override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
  }
}
