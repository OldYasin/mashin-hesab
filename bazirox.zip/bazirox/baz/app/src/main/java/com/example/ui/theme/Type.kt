package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.Hyphens
import androidx.compose.ui.text.style.LineBreak
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.unit.sp
import com.example.R

// Vazirmatn: modern Persian/Arabic + Latin font, bundled offline in res/font.
val VazirmatnFamily =
  FontFamily(
    Font(R.font.vazirmatn_regular, FontWeight.Normal),
    Font(R.font.vazirmatn_medium, FontWeight.Medium),
    Font(R.font.vazirmatn_semibold, FontWeight.SemiBold),
    Font(R.font.vazirmatn_bold, FontWeight.Bold),
    Font(R.font.vazirmatn_extrabold, FontWeight.ExtraBold),
  )

val AppFontFamily = VazirmatnFamily

private fun style(
  weight: FontWeight,
  size: Int,
  line: Int,
) =
  TextStyle(
    fontFamily = AppFontFamily,
    fontWeight = weight,
    fontSize = size.sp,
    lineHeight = line.sp,
    letterSpacing = 0.sp, // letter-spacing breaks Arabic-script letter joining
    lineHeightStyle =
      LineHeightStyle(
        alignment = LineHeightStyle.Alignment.Center,
        trim = LineHeightStyle.Trim.None,
      ),
    platformStyle = PlatformTextStyle(includeFontPadding = false),
    lineBreak = LineBreak.Paragraph,
    hyphens = Hyphens.None,
  )

// Every M3 slot is set so no text falls back to the system font.
val Typography =
  Typography(
    displayLarge = style(FontWeight.ExtraBold, 40, 52),
    displayMedium = style(FontWeight.ExtraBold, 34, 46),
    displaySmall = style(FontWeight.ExtraBold, 28, 40),
    headlineLarge = style(FontWeight.Bold, 26, 38),
    headlineMedium = style(FontWeight.Bold, 22, 34),
    headlineSmall = style(FontWeight.Bold, 19, 30),
    titleLarge = style(FontWeight.Bold, 18, 28),
    titleMedium = style(FontWeight.SemiBold, 16, 26),
    titleSmall = style(FontWeight.SemiBold, 14, 22),
    bodyLarge = style(FontWeight.Normal, 16, 26),
    bodyMedium = style(FontWeight.Normal, 14, 23),
    bodySmall = style(FontWeight.Normal, 12, 19),
    labelLarge = style(FontWeight.SemiBold, 14, 22),
    labelMedium = style(FontWeight.Medium, 12, 19),
    labelSmall = style(FontWeight.Medium, 11, 17),
  )
