package com.example.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Custom lightweight Material-style gaming vector icons.
 * Keeps APK ultra-small (< 20MB) while providing sharp custom gaming iconography.
 */
object BaziIcons {
  private fun svg(name: String, d: String): ImageVector =
    ImageVector.Builder(
        name = name,
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f,
      )
      .addPath(pathData = addPathNodes(d), fill = SolidColor(Color.Black))
      .build()

  val Photo: ImageVector by lazy {
    svg(
      "Photo",
      "M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z",
    )
  }

  val Reply: ImageVector by lazy { svg("Reply", "M10 9V5l-7 7 7 7v-4.1c5 0 8.5 1.6 11 5.1-1-5-4-10-11-11z") }

  val ArrowDown: ImageVector by lazy {
    svg("ArrowDown", "M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6z")
  }
  private fun vec(name: String, block: ImageVector.Builder.() -> Unit): ImageVector =
    ImageVector.Builder(
        name = name,
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f,
      )
      .apply(block)
      .build()

  val SportsEsports: ImageVector by lazy {
    vec("SportsEsports") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(21.58f, 16.09f)
        lineTo(20.51f, 8.58f)
        curveTo(20.23f, 6.53f, 18.48f, 5f, 16.41f, 5f)
        horizontalLineTo(7.59f)
        curveTo(5.52f, 5f, 3.77f, 6.53f, 3.49f, 8.58f)
        lineTo(2.42f, 16.09f)
        curveTo(2.19f, 17.71f, 3.45f, 19.16f, 5.09f, 19.16f)
        curveTo(5.92f, 19.16f, 6.72f, 18.78f, 7.23f, 18.12f)
        lineTo(9.1f, 15.72f)
        horizontalLineTo(14.9f)
        lineTo(16.77f, 18.12f)
        curveTo(17.28f, 18.78f, 18.08f, 19.16f, 18.91f, 19.16f)
        curveTo(20.55f, 19.16f, 21.81f, 17.71f, 21.58f, 16.09f)
        close()
        moveTo(11f, 11f)
        horizontalLineTo(9f)
        verticalLineTo(13f)
        horizontalLineTo(8f)
        verticalLineTo(11f)
        horizontalLineTo(6f)
        verticalLineTo(10f)
        horizontalLineTo(8f)
        verticalLineTo(8f)
        horizontalLineTo(9f)
        verticalLineTo(10f)
        horizontalLineTo(11f)
        verticalLineTo(11f)
        close()
        moveTo(15f, 10f)
        curveTo(14.45f, 10f, 14f, 9.55f, 14f, 9f)
        curveTo(14f, 8.45f, 14.45f, 8f, 15f, 8f)
        curveTo(15.55f, 8f, 16f, 8.45f, 16f, 9f)
        curveTo(16f, 9.55f, 15.55f, 10f, 15f, 10f)
        close()
        moveTo(17f, 13f)
        curveTo(16.45f, 13f, 16f, 12.55f, 16f, 12f)
        curveTo(16f, 11.45f, 16.45f, 11f, 17f, 11f)
        curveTo(17.55f, 11f, 18f, 11.45f, 18f, 12f)
        curveTo(18f, 12.55f, 17.55f, 13f, 17f, 13f)
        close()
      }
    }
  }

  val Crown: ImageVector by lazy {
    vec("Crown") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(5f, 16f)
        lineTo(3f, 5f)
        lineTo(8.5f, 10f)
        lineTo(12f, 4f)
        lineTo(15.5f, 10f)
        lineTo(21f, 5f)
        lineTo(19f, 16f)
        horizontalLineTo(5f)
        close()
        moveTo(19f, 19f)
        curveTo(19f, 19.6f, 18.6f, 20f, 18f, 20f)
        horizontalLineTo(6f)
        curveTo(5.4f, 20f, 5f, 19.6f, 5f, 19f)
        verticalLineTo(18f)
        horizontalLineTo(19f)
        verticalLineTo(19f)
        close()
      }
    }
  }

  val Flame: ImageVector by lazy {
    vec("Flame") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(13.5f, 0.67f)
        curveTo(13.5f, 0.67f, 14.24f, 3.32f, 14.24f, 5.47f)
        curveTo(14.24f, 7.53f, 12.89f, 9.2f, 10.83f, 9.2f)
        curveTo(8.76f, 9.2f, 7.2f, 7.53f, 7.2f, 5.47f)
        lineTo(7.23f, 5.11f)
        curveTo(5.21f, 7.51f, 4f, 10.62f, 4f, 14f)
        curveTo(4f, 18.42f, 7.58f, 22f, 12f, 22f)
        curveTo(16.42f, 22f, 20f, 18.42f, 20f, 14f)
        curveTo(20f, 8.61f, 17.41f, 3.8f, 13.5f, 0.67f)
        close()
        moveTo(11.71f, 19f)
        curveTo(9.93f, 19f, 8.49f, 17.6f, 8.49f, 15.86f)
        curveTo(8.49f, 14.24f, 9.54f, 13.1f, 11.3f, 12.74f)
        curveTo(13.07f, 12.38f, 14.9f, 11.53f, 15.92f, 10.16f)
        curveTo(16.31f, 11.45f, 16.51f, 12.81f, 16.51f, 14.2f)
        curveTo(16.51f, 16.85f, 14.36f, 19f, 11.71f, 19f)
        close()
      }
    }
  }

  val Forum: ImageVector by lazy {
    vec("Forum") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(21f, 6f)
        horizontalLineTo(19f)
        verticalLineTo(15f)
        horizontalLineTo(6f)
        verticalLineTo(17f)
        curveTo(6f, 17.55f, 6.45f, 18f, 7f, 18f)
        horizontalLineTo(18f)
        lineTo(22f, 22f)
        verticalLineTo(7f)
        curveTo(22f, 6.45f, 21.55f, 6f, 21f, 6f)
        close()
        moveTo(17f, 12f)
        verticalLineTo(3f)
        curveTo(17f, 2.45f, 16.55f, 2f, 16f, 2f)
        horizontalLineTo(3f)
        curveTo(2.45f, 2f, 2f, 2.45f, 2f, 3f)
        verticalLineTo(17f)
        lineTo(6f, 13f)
        horizontalLineTo(16f)
        curveTo(16.55f, 13f, 17f, 12.55f, 17f, 12f)
        close()
      }
    }
  }

  val Trophy: ImageVector by lazy {
    vec("Trophy") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(19f, 5f)
        horizontalLineTo(17f)
        verticalLineTo(3f)
        horizontalLineTo(7f)
        verticalLineTo(5f)
        horizontalLineTo(5f)
        curveTo(3.9f, 5f, 3f, 5.9f, 3f, 7f)
        verticalLineTo(8f)
        curveTo(3f, 10.55f, 4.92f, 12.63f, 7.39f, 12.94f)
        curveTo(8.02f, 14.44f, 9.37f, 15.57f, 11f, 15.9f)
        verticalLineTo(19f)
        horizontalLineTo(7f)
        verticalLineTo(21f)
        horizontalLineTo(17f)
        verticalLineTo(19f)
        horizontalLineTo(13f)
        verticalLineTo(15.9f)
        curveTo(14.63f, 15.57f, 15.98f, 14.44f, 16.61f, 12.94f)
        curveTo(19.08f, 12.63f, 21f, 10.55f, 21f, 8f)
        verticalLineTo(7f)
        curveTo(21f, 5.9f, 20.1f, 5f, 19f, 5f)
        close()
        moveTo(5f, 8f)
        verticalLineTo(7f)
        horizontalLineTo(7f)
        verticalLineTo(10.82f)
        curveTo(5.84f, 10.4f, 5f, 9.3f, 5f, 8f)
        close()
        moveTo(19f, 8f)
        curveTo(19f, 9.3f, 18.16f, 10.4f, 17f, 10.82f)
        verticalLineTo(7f)
        horizontalLineTo(19f)
        verticalLineTo(8f)
        close()
      }
    }
  }

  val Dice: ImageVector by lazy {
    vec("Dice") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(19f, 3f)
        horizontalLineTo(5f)
        curveTo(3.9f, 3f, 3f, 3.9f, 3f, 5f)
        verticalLineTo(19f)
        curveTo(3f, 20.1f, 3.9f, 21f, 5f, 21f)
        horizontalLineTo(19f)
        curveTo(20.1f, 21f, 21f, 20.1f, 21f, 19f)
        verticalLineTo(5f)
        curveTo(21f, 3.9f, 20.1f, 3f, 19f, 3f)
        close()
        moveTo(7.5f, 18f)
        curveTo(6.67f, 18f, 6f, 17.33f, 6f, 16.5f)
        curveTo(6f, 15.67f, 6.67f, 15f, 7.5f, 15f)
        curveTo(8.33f, 15f, 9f, 15.67f, 9f, 16.5f)
        curveTo(9f, 17.33f, 8.33f, 18f, 7.5f, 18f)
        close()
        moveTo(7.5f, 9f)
        curveTo(6.67f, 9f, 6f, 8.33f, 6f, 7.5f)
        curveTo(6f, 6.67f, 6.67f, 6f, 7.5f, 6f)
        curveTo(8.33f, 6f, 9f, 6.67f, 9f, 7.5f)
        curveTo(9f, 8.33f, 8.33f, 9f, 7.5f, 9f)
        close()
        moveTo(12f, 13.5f)
        curveTo(11.17f, 13.5f, 10.5f, 12.83f, 10.5f, 12f)
        curveTo(10.5f, 11.17f, 11.17f, 10.5f, 12f, 10.5f)
        curveTo(12.83f, 10.5f, 13.5f, 11.17f, 13.5f, 12f)
        curveTo(13.5f, 12.83f, 12.83f, 13.5f, 12f, 13.5f)
        close()
        moveTo(16.5f, 18f)
        curveTo(15.67f, 18f, 15f, 17.33f, 15f, 16.5f)
        curveTo(15f, 15.67f, 15.67f, 15f, 16.5f, 15f)
        curveTo(17.33f, 15f, 18f, 15.67f, 18f, 16.5f)
        curveTo(18f, 17.33f, 17.33f, 18f, 16.5f, 18f)
        close()
        moveTo(16.5f, 9f)
        curveTo(15.67f, 9f, 15f, 8.33f, 15f, 7.5f)
        curveTo(15f, 6.67f, 15.67f, 6f, 16.5f, 6f)
        curveTo(17.33f, 6f, 18f, 6.67f, 18f, 7.5f)
        curveTo(18f, 8.33f, 17.33f, 9f, 16.5f, 9f)
        close()
      }
    }
  }

  val Shield: ImageVector by lazy {
    vec("Shield") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(12f, 2f)
        lineTo(4f, 5f)
        verticalLineTo(11.09f)
        curveTo(4f, 16.14f, 7.41f, 20.85f, 12f, 22f)
        curveTo(16.59f, 20.85f, 20f, 16.14f, 20f, 11.09f)
        verticalLineTo(5f)
        lineTo(12f, 2f)
        close()
      }
    }
  }

  val Cloud: ImageVector by lazy {
    vec("Cloud") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(19.35f, 10.04f)
        curveTo(18.67f, 6.59f, 15.64f, 4f, 12f, 4f)
        curveTo(9.11f, 4f, 6.6f, 5.64f, 5.35f, 8.04f)
        curveTo(2.34f, 8.36f, 0f, 10.91f, 0f, 14f)
        curveTo(0f, 17.31f, 2.69f, 20f, 6f, 20f)
        horizontalLineTo(19f)
        curveTo(21.76f, 20f, 24f, 17.76f, 24f, 15f)
        curveTo(24f, 12.36f, 21.95f, 10.22f, 19.35f, 10.04f)
        close()
      }
    }
  }

  val Groups: ImageVector by lazy {
    vec("Groups") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(16f, 11f)
        curveTo(17.66f, 11f, 18.99f, 9.66f, 18.99f, 8f)
        curveTo(18.99f, 6.34f, 17.66f, 5f, 16f, 5f)
        curveTo(14.34f, 5f, 13f, 6.34f, 13f, 8f)
        curveTo(13f, 9.66f, 14.34f, 11f, 16f, 11f)
        close()
        moveTo(8f, 11f)
        curveTo(9.66f, 11f, 10.99f, 9.66f, 10.99f, 8f)
        curveTo(10.99f, 6.34f, 9.66f, 5f, 8f, 5f)
        curveTo(6.34f, 5f, 5f, 6.34f, 5f, 8f)
        curveTo(5f, 9.66f, 6.34f, 11f, 8f, 11f)
        close()
        moveTo(8f, 13f)
        curveTo(5.67f, 13f, 1f, 14.17f, 1f, 16.5f)
        verticalLineTo(19f)
        horizontalLineTo(15f)
        verticalLineTo(16.5f)
        curveTo(15f, 14.17f, 10.33f, 13f, 8f, 13f)
        close()
        moveTo(16f, 13f)
        curveTo(15.71f, 13f, 15.38f, 13.02f, 15.03f, 13.05f)
        curveTo(16.19f, 13.89f, 17f, 15.02f, 17f, 16.5f)
        verticalLineTo(19f)
        horizontalLineTo(23f)
        verticalLineTo(16.5f)
        curveTo(23f, 14.17f, 18.33f, 13f, 16f, 13f)
        close()
      }
    }
  }

  val PersonAdd: ImageVector by lazy {
    vec("PersonAdd") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(15f, 12f)
        curveTo(17.21f, 12f, 19f, 10.21f, 19f, 8f)
        curveTo(19f, 5.79f, 17.21f, 4f, 15f, 4f)
        curveTo(12.79f, 4f, 11f, 5.79f, 11f, 8f)
        curveTo(11f, 10.21f, 12.79f, 12f, 15f, 12f)
        close()
        moveTo(6f, 10f)
        verticalLineTo(7f)
        horizontalLineTo(4f)
        verticalLineTo(10f)
        horizontalLineTo(1f)
        verticalLineTo(12f)
        horizontalLineTo(4f)
        verticalLineTo(15f)
        horizontalLineTo(6f)
        verticalLineTo(12f)
        horizontalLineTo(9f)
        verticalLineTo(10f)
        horizontalLineTo(6f)
        close()
        moveTo(15f, 14f)
        curveTo(12.33f, 14f, 7f, 15.34f, 7f, 18f)
        verticalLineTo(20f)
        horizontalLineTo(23f)
        verticalLineTo(18f)
        curveTo(23f, 15.34f, 17.67f, 14f, 15f, 14f)
        close()
      }
    }
  }

  val PublicGlobe: ImageVector by lazy {
    vec("PublicGlobe") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(12f, 2f)
        curveTo(6.48f, 2f, 2f, 6.48f, 2f, 12f)
        curveTo(2f, 17.52f, 6.48f, 22f, 12f, 22f)
        curveTo(17.52f, 22f, 22f, 17.52f, 22f, 12f)
        curveTo(22f, 6.48f, 17.52f, 2f, 12f, 2f)
        close()
        moveTo(11f, 19.93f)
        curveTo(7.05f, 19.44f, 4f, 16.08f, 4f, 12f)
        curveTo(4f, 11.38f, 4.08f, 10.79f, 4.21f, 10.21f)
        lineTo(9f, 15f)
        verticalLineTo(16f)
        curveTo(9f, 17.1f, 9.9f, 18f, 11f, 18f)
        verticalLineTo(19.93f)
        close()
        moveTo(17.9f, 17.39f)
        curveTo(17.64f, 16.58f, 16.9f, 16f, 16f, 16f)
        horizontalLineTo(15f)
        verticalLineTo(13f)
        curveTo(15f, 12.45f, 14.55f, 12f, 14f, 12f)
        horizontalLineTo(8f)
        verticalLineTo(10f)
        horizontalLineTo(10f)
        curveTo(10.55f, 10f, 11f, 9.55f, 11f, 9f)
        verticalLineTo(7f)
        horizontalLineTo(13f)
        curveTo(14.1f, 7f, 15f, 6.1f, 15f, 5f)
        verticalLineTo(4.59f)
        curveTo(17.93f, 5.78f, 20f, 8.65f, 20f, 12f)
        curveTo(20f, 14.08f, 19.2f, 15.97f, 17.9f, 17.39f)
        close()
      }
    }
  }

  val Bolt: ImageVector by lazy {
    vec("Bolt") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(11f, 21f)
        horizontalLineTo(10f)
        lineTo(11f, 14f)
        horizontalLineTo(7.5f)
        curveTo(6.92f, 14f, 6.67f, 13.68f, 6.86f, 13.34f)
        lineTo(13f, 3f)
        horizontalLineTo(14f)
        lineTo(13f, 10f)
        horizontalLineTo(16.5f)
        curveTo(16.99f, 10f, 17.31f, 10.33f, 17.13f, 10.67f)
        lineTo(11f, 21f)
        close()
      }
    }
  }

  val VolumeUp: ImageVector by lazy {
    svg(
      "VolumeUp",
      "M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z",
    )
  }

  val VolumeOff: ImageVector by lazy {
    svg(
      "VolumeOff",
      "M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z",
    )
  }

  val Copy: ImageVector by lazy {
    vec("Copy") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(16f, 1f)
        horizontalLineTo(4f)
        curveTo(2.9f, 1f, 2f, 1.9f, 2f, 3f)
        verticalLineTo(17f)
        horizontalLineTo(4f)
        verticalLineTo(3f)
        horizontalLineTo(16f)
        verticalLineTo(1f)
        close()
        moveTo(19f, 5f)
        horizontalLineTo(8f)
        curveTo(6.9f, 5f, 6f, 5.9f, 6f, 7f)
        verticalLineTo(21f)
        curveTo(6f, 22.1f, 6.9f, 23f, 8f, 23f)
        horizontalLineTo(19f)
        curveTo(20.1f, 23f, 21f, 22.1f, 21f, 21f)
        verticalLineTo(7f)
        curveTo(21f, 5.9f, 20.1f, 5f, 19f, 5f)
        close()
        moveTo(19f, 21f)
        horizontalLineTo(8f)
        verticalLineTo(7f)
        horizontalLineTo(19f)
        verticalLineTo(21f)
        close()
      }
    }
  }

  val Code: ImageVector by lazy {
    vec("Code") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(9.4f, 16.6f)
        lineTo(4.8f, 12f)
        lineTo(9.4f, 7.4f)
        lineTo(8f, 6f)
        lineTo(2f, 12f)
        lineTo(8f, 18f)
        lineTo(9.4f, 16.6f)
        close()
        moveTo(14.6f, 16.6f)
        lineTo(19.2f, 12f)
        lineTo(14.6f, 7.4f)
        lineTo(16f, 6f)
        lineTo(22f, 12f)
        lineTo(16f, 18f)
        lineTo(14.6f, 16.6f)
        close()
      }
    }
  }

  val Key: ImageVector by lazy {
    vec("Key") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(12.65f, 10f)
        curveTo(11.83f, 7.67f, 9.61f, 6f, 7f, 6f)
        curveTo(3.69f, 6f, 1f, 8.69f, 1f, 12f)
        curveTo(1f, 15.31f, 3.69f, 18f, 7f, 18f)
        curveTo(9.61f, 18f, 11.83f, 16.33f, 12.65f, 14f)
        horizontalLineTo(17f)
        verticalLineTo(18f)
        horizontalLineTo(21f)
        verticalLineTo(14f)
        horizontalLineTo(23f)
        verticalLineTo(10f)
        horizontalLineTo(12.65f)
        close()
        moveTo(7f, 14f)
        curveTo(5.9f, 14f, 5f, 13.1f, 5f, 12f)
        curveTo(5f, 10.9f, 5.9f, 10f, 7f, 10f)
        curveTo(8.1f, 10f, 9f, 10.9f, 9f, 12f)
        curveTo(9f, 13.1f, 8.1f, 14f, 7f, 14f)
        close()
      }
    }
  }

  val Visibility: ImageVector by lazy {
    vec("Visibility") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(12f, 4.5f)
        curveTo(7f, 4.5f, 2.73f, 7.61f, 1f, 12f)
        curveTo(2.73f, 16.39f, 7f, 19.5f, 12f, 19.5f)
        curveTo(17f, 19.5f, 21.27f, 16.39f, 23f, 12f)
        curveTo(21.27f, 7.61f, 17f, 4.5f, 12f, 4.5f)
        close()
        moveTo(12f, 17f)
        curveTo(9.24f, 17f, 7f, 14.76f, 7f, 12f)
        curveTo(7f, 9.24f, 9.24f, 7f, 12f, 7f)
        curveTo(14.76f, 7f, 17f, 9.24f, 17f, 12f)
        curveTo(17f, 14.76f, 14.76f, 17f, 12f, 17f)
        close()
        moveTo(12f, 9f)
        curveTo(10.34f, 9f, 9f, 10.34f, 9f, 12f)
        curveTo(9f, 13.66f, 10.34f, 15f, 12f, 15f)
        curveTo(13.66f, 15f, 15f, 13.66f, 15f, 12f)
        curveTo(15f, 10.34f, 13.66f, 9f, 12f, 9f)
        close()
      }
    }
  }

  val Logout: ImageVector by lazy {
    vec("Logout") {
      path(fill = SolidColor(Color.Black)) {
        moveTo(17f, 7f)
        lineTo(15.59f, 8.41f)
        lineTo(18.17f, 11f)
        horizontalLineTo(8f)
        verticalLineTo(13f)
        horizontalLineTo(18.17f)
        lineTo(15.59f, 15.58f)
        lineTo(17f, 17f)
        lineTo(22f, 12f)
        lineTo(17f, 7f)
        close()
        moveTo(4f, 5f)
        horizontalLineTo(12f)
        verticalLineTo(3f)
        horizontalLineTo(4f)
        curveTo(2.9f, 3f, 2f, 3.9f, 2f, 5f)
        verticalLineTo(19f)
        curveTo(2f, 20.1f, 2.9f, 21f, 4f, 21f)
        horizontalLineTo(12f)
        verticalLineTo(19f)
        horizontalLineTo(4f)
        verticalLineTo(5f)
        close()
      }
    }
  }
}
