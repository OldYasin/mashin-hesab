package com.example.data

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap

enum class GameType(
  val id: String,
  val titleFa: String,
  val subtitleFa: String,
  val playersRangeFa: String,
) {
  LUDO("ludo", "منچ", "رقابت کلاسیک چهارنفره", "۲ تا ۴ نفر"),
  TIC_TAC_TOE("tictactoe", "دوز", "نبرد سریع هوش و تاکتیک", "۲ نفره"),
  CONNECT_FOUR("connect4", "چهار خط", "چینش ۴ مهره هم‌رنگ", "۲ نفره"),
  SNAKES_LADDERS("snakes", "مار و پله", "صعود از پله و فرار از مار", "۲ تا ۴ نفر"),
  GUESS_NUMBER("guess", "حدس عدد", "عدد مخفی را قبل از حریف پیدا کن", "۲ نفره"),
  ROCK_PAPER_SCISSORS("rps", "سنگ کاغذ قیچی", "مشتت را قایم کن و حریف را ببر", "۲ نفره"),
}

enum class PlayMode(val titleFa: String) {
  VS_AI("بازی با هوش مصنوعی"),
  LOCAL_PASS_AND_PLAY("دو/چند نفره آفلاین"),
  ONLINE_ROOM("بازی آنلاین با دوستان"),
}

enum class MainTab(val titleFa: String) {
  GAMES("بازی‌ها"),
  CHAT("چت"),
  LEADERBOARD("لیدربرد"),
  PROFILE("پروفایل"),
}

@Immutable
data class UserAccount(
  val username: String,
  val displayName: String,
  val avatarColorIndex: Int = 0,
  val totalScore: Int = 0,
  val wins: Int = 0,
  val gamesPlayed: Int = 0,
  val authToken: String = "",
) {
  val level: Int
    get() = 1 + (totalScore / 150)

  val winRatePercent: Int
    get() = if (gamesPlayed <= 0) 0 else ((wins * 100f) / gamesPlayed).toInt().coerceIn(0, 100)
}

@Immutable
data class LeaderboardEntry(
  val rank: Int,
  val username: String,
  val displayName: String,
  val avatarColorIndex: Int,
  val totalScore: Int,
  val wins: Int,
  val gamesPlayed: Int,
  val favoriteGame: GameType = GameType.LUDO,
  val isCurrentUser: Boolean = false,
) {
  val winRatePercent: Int
    get() = if (gamesPlayed <= 0) 0 else ((wins * 100f) / gamesPlayed).toInt().coerceIn(0, 100)
}

@Immutable
data class GameInvite(
  val gameType: GameType,
  val roomCode: String,
  val hostUsername: String,
)

@Immutable
data class ChatGroup(
  val id: String,
  val name: String,
  val inviteCode: String,
  val ownerUsername: String,
  val members: List<String>,
  val lastMessagePreview: String = "",
  val lastMessageTime: Long = 0L,
  /** Full invite = server code + "." + group encryption key. The key never reaches the server. */
  val shareCode: String = "",
  /** Pending join requests; only filled by the server for groups owned by the current user. */
  val pendingCount: Int = 0,
  /** Optional group description (end-to-end encrypted on the server, decrypted locally). */
  val description: String = "",
  /** Private chats only: the shared group whose key the DM key is derived from. */
  val dmOrigin: String = "",
) {
  /** Private chats are 2-member "groups" whose id starts with dm_. */
  val isDm: Boolean get() = id.startsWith("dm_")
}

/** Name shown in lists/headers: the other person for a private chat, the group name otherwise. */
fun ChatGroup.titleFor(me: String): String =
  if (isDm) members.firstOrNull { !it.equals(me, ignoreCase = true) } ?: "گفتگوی خصوصی" else name

@Immutable
data class UserProfile(
  val username: String,
  val displayName: String,
  val avatarColorIndex: Int,
  val bio: String,
  val totalScore: Int,
  val wins: Int,
  val gamesPlayed: Int,
)

@Immutable
data class JoinRequest(val username: String, val requestedAt: Long)

sealed interface JoinResult {
  data class Joined(val group: ChatGroup) : JoinResult
  /** The owner has to approve the request before the user becomes a member. */
  data class Pending(val groupName: String) : JoinResult
}

/** Result of the device-local admin gate (no credentials are stored inside the APK). */
sealed interface AdminAuthResult {
  data object Granted : AdminAuthResult
  data object Created : AdminAuthResult
  data object Wrong : AdminAuthResult
  data object TooWeak : AdminAuthResult
  data object NoServer : AdminAuthResult
  data class Locked(val seconds: Long) : AdminAuthResult
}

@Immutable
data class ChatMessage(
  val id: String,
  val groupId: String,
  val senderUsername: String,
  val senderColorIndex: Int,
  val text: String,
  val timestamp: Long,
  val gameInvite: GameInvite? = null,
  val hasImage: Boolean = false,
  val replyToId: String? = null,
  val replyToSender: String? = null,
  val replyToText: String? = null,
  val sendState: Int = SendState.SENT,
)

object SendState {
  const val SENDING = 0
  const val SENT = 1
  const val FAILED = 2
}

/** Messages of one chat plus per-user "read up to" timestamps (for double-tick read receipts). */
data class MessagesPage(val messages: List<ChatMessage>, val reads: Map<String, Long>)

/** A user's profile photo (square JPEG, decoded) together with the server version it came from. */
@Immutable
data class AvatarImage(val ver: Long, val bitmap: ImageBitmap)

/** One avatar as returned by the server; an empty [imageB64] means the user removed the photo. */
data class RemoteAvatar(val username: String, val ver: Long, val imageB64: String)

/** One short chat line inside an online game room (shown as a bubble under the sender's avatar). */
@Immutable
data class RoomChatMessage(
  val id: String,
  val sender: String,
  val text: String,
  val timestamp: Long,
  val failed: Boolean = false,
)

@Immutable
data class RoomPlayerInfo(
  val username: String,
  val displayName: String,
  val colorIndex: Int,
)

/** Chat lines + player avatar info returned by the server for one room. */
data class RoomChatPage(val messages: List<RoomChatMessage>, val players: List<RoomPlayerInfo>)

@Immutable
data class OnlineRoom(
  val roomCode: String,
  val gameType: GameType,
  val hostUsername: String,
  val players: List<String>,
  val status: String = "waiting", // waiting | playing | finished
  val version: Int = 1,
  val stateJson: String = "{}",
)

@Immutable
data class CPanelConfig(
  val apiBaseUrl: String = "",
  val dbHost: String = "localhost",
  val dbName: String = "",
  val dbUser: String = "",
  val dbPassword: String = "",
  val apiSecret: String = "",
  val hmacEnabled: Boolean = true,
  val e2eeEnabled: Boolean = true,
  val maintenanceMode: Boolean = false,
  val pollingIntervalMs: Int = 1800,
  val lastTestStatus: String = "تنظیم نشده",
  val lastTestLatencyMs: Long = -1L,
  val isConnected: Boolean = false,
)
