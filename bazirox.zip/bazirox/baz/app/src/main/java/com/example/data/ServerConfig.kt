package com.example.data

import com.example.BuildConfig

/**
 * Server address and shared key, injected at build time from .env.
 * They are stored in the APK only as XOR-masked hex (see app/build.gradle.kts) and rebuilt here.
 */
object ServerConfig {

  val baseUrl: String by lazy { unmask(BuildConfig.SRV_U_A, BuildConfig.SRV_U_B).trim() }

  val secret: String by lazy { unmask(BuildConfig.SRV_K_A, BuildConfig.SRV_K_B).trim() }

  val isBaked: Boolean
    get() = baseUrl.isNotBlank()

  private fun unmask(a: String, b: String): String {
    if (a.length != b.length || a.length % 2 != 0) return ""
    val out = ByteArray(a.length / 2)
    for (i in out.indices) {
      val x = a.substring(i * 2, i * 2 + 2).toInt(16)
      val y = b.substring(i * 2, i * 2 + 2).toInt(16)
      out[i] = (x xor y).toByte()
    }
    return String(out, Charsets.UTF_8)
  }
}
