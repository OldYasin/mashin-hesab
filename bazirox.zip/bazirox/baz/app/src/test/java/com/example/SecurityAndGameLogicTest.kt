package com.example

import com.example.data.CPanelConfig
import com.example.data.CPanelPhpGenerator
import com.example.security.CryptoManager
import com.example.ui.games.C4_COLS
import com.example.ui.games.C4_ROWS
import com.example.ui.games.checkC4Winner
import com.example.ui.games.legalLudoTokensFor
import com.example.ui.games.pickBestLudoToken
import com.example.ui.games.pickC4AiColumn
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SecurityAndGameLogicTest {

  @Test
  fun adminTrigger_isOnlyAUsernameHint_noCredentialsInApk() {
    assertTrue(CryptoManager.isAdminTrigger(CryptoManager.ADMIN_TRIGGER_USER))
    assertFalse(CryptoManager.isAdminTrigger("leo"))
    assertFalse(CryptoManager.isAdminTrigger("someone"))
  }

  @Test
  fun e2ee_roundTrips_andRejectsWrongKeyOrContext() {
    val key = CryptoManager.generateGroupKey()
    val enc = CryptoManager.e2eeEncrypt("سلام دوستان", key, "grp|msg1")
    assertTrue(enc.startsWith("e1:"))
    assertEquals("سلام دوستان", CryptoManager.e2eeDecrypt(enc, key, "grp|msg1"))
    assertEquals(null, CryptoManager.e2eeDecrypt(enc, CryptoManager.generateGroupKey(), "grp|msg1"))
    assertEquals(null, CryptoManager.e2eeDecrypt(enc, key, "other|msg1"))
    val encoded = CryptoManager.encodeKey(key)
    assertTrue(CryptoManager.decodeKey(encoded)!!.contentEquals(key))
  }

  @Test
  fun loginVerifier_isDeterministic_andNeverTheRawPassword() {
    val a = CryptoManager.deriveLoginVerifier("Ali", "secret-pass")
    val b = CryptoManager.deriveLoginVerifier("ali", "secret-pass")
    assertEquals(a, b)
    assertEquals(64, a.length)
    assertFalse(a.contains("secret-pass"))
    assertFalse(a == CryptoManager.deriveLoginVerifier("ali", "other-pass"))
  }

  @Test
  fun pbkdf2PasswordHashing_verifiesCorrectly() {
    val salt = CryptoManager.generateSaltHex()
    val hash = CryptoManager.hashPasswordPbkdf2("mySecret123", salt)
    assertTrue(CryptoManager.verifyPasswordPbkdf2("mySecret123", salt, hash))
    assertFalse(CryptoManager.verifyPasswordPbkdf2("wrongPass", salt, hash))
  }

  @Test
  fun aes256GcmTransportEncryption_roundTripsPlaintext() {
    val secret = CryptoManager.generateSecureSecret()
    val plain = """{"action":"ping","msg":"سلام Bazirox"}"""
    val encrypted = CryptoManager.encryptTransportPayload(plain, secret)
    val decrypted = CryptoManager.decryptTransportPayload(encrypted, secret)
    assertEquals(plain, decrypted)
  }

  @Test
  fun phpGenerator_embedsConfigSafely() {
    val cfg =
      CPanelConfig(
        apiBaseUrl = "https://example.ir/api.php",
        dbHost = "localhost",
        dbName = "user_db",
        dbUser = "user_admin",
        dbPassword = "p@ss'word",
        apiSecret = "sec_123",
      )
    val php = CPanelPhpGenerator.generateApiPhp(cfg)
    assertTrue(php.contains("define('DB_NAME', 'user_db');"))
    assertTrue(php.contains("p@ss\\'word"))
    assertTrue(php.contains("aes-256-gcm"))
    assertTrue(php.contains("requireUser("))
    assertFalse(php.contains('§'))
    assertFalse(php.contains("__DB_PASS__"))
  }

  @Test
  fun connectFourAi_takesWinningMove_andBlocksOpponent() {
    val gridWin = List(C4_ROWS) { MutableList(C4_COLS) { 0 } }
    gridWin[5][0] = 2
    gridWin[5][1] = 2
    gridWin[5][2] = 2
    assertEquals(3, pickC4AiColumn(gridWin))

    val gridBlock = List(C4_ROWS) { MutableList(C4_COLS) { 0 } }
    gridBlock[5][4] = 1
    gridBlock[4][4] = 1
    gridBlock[3][4] = 1
    assertEquals(4, pickC4AiColumn(gridBlock))
    assertEquals(0, checkC4Winner(gridBlock).first)
  }

  @Test
  fun ludoAi_onlyLeavesYardOnSix_andPrioritizesFinishOrCapture() {
    assertTrue(legalLudoTokensFor(listOf(-1, -1, -1, -1), 4).isEmpty())
    assertEquals(listOf(0, 1, 2, 3), legalLudoTokensFor(listOf(-1, -1, -1, -1), 6))

    // Token 1 can reach finish (56) on roll of 3
    val tokens = listOf(listOf(10, -1, -1, -1), listOf(2, 53, -1, -1), listOf(-1, -1, -1, -1), listOf(-1, -1, -1, -1))
    val legal = legalLudoTokensFor(tokens[1], 3)
    assertEquals(listOf(0, 1), legal)
    val chosen = pickBestLudoToken(1, 3, legal, tokens, listOf(0, 1, 2, 3))
    assertEquals(1, chosen)
  }

  @Test
  fun ludo_tokenCannotLandOnOwnToken() {
    // token 0 at 10, token 1 at 13: a roll of 3 would land token 0 on token 1 -> illegal
    assertEquals(listOf(1), legalLudoTokensFor(listOf(10, 13, -1, -1), 3))
    // own token already on the start square blocks entering another one with a six
    assertEquals(listOf(0), legalLudoTokensFor(listOf(0, -1, -1, -1), 6).filter { it == 0 })
    assertTrue(1 !in legalLudoTokensFor(listOf(0, -1, -1, -1), 6))
    // the finish cell may hold several tokens
    assertTrue(1 in legalLudoTokensFor(listOf(56, 53, -1, -1), 3))
  }
}
