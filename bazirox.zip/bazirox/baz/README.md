# Bazirox

Android app (Kotlin + Jetpack Compose) with a PHP/MySQL backend on a cPanel host.

## راه‌اندازی

1. فایل `.env` کنار پروژه بساز (فایل `.env.example` نمونه است):
   ```
   API_BASE_URL=https://your-domain/v1/api.php
   API_SECRET=<همان مقدار API_SECRET داخل api.php>
   ```
2. روی هاست، `api.php` را ویرایش کن و `define('API_SECRET', '...')` را دقیقاً با همان مقدار بگذار.
3. جدول‌های دیتابیس را با `schema.sql` بساز.
4. بیلد کامل بگیر و نصب کن (مقادیر `.env` موقع بیلد داخل اپ قرار می‌گیرند).

## نکته‌ها

- ورود اجباری است؛ حساب‌ها فقط روی سرور ساخته می‌شوند.
- فایل `.env` و کلید `my-upload-key.jks` را هرگز به اشتراک نگذار.
