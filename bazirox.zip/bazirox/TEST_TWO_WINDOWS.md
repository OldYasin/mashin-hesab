# Two-window online test on ONE phone (username yasinm only)

Why not two emulators inside one screen: the native core (LibretroDroid + the FBNeo/Genesis core) and the lockstep
state are global per process, so two instances in one process would corrupt each other. A second ACTIVITY in a
second PROCESS is a clean copy of everything = same as a second phone, and uses the same EmulatorScreen code.

## 1) AndroidManifest.xml (inside <application>)
```xml
<activity
    android:name="com.example.ui.games.EmulatorTestActivity"
    android:process=":p2"
    android:exported="false"
    android:resizeableActivity="true"
    android:taskAffinity="com.example.bazirox.p2"
    android:configChanges="orientation|screenSize|smallestScreenSize|screenLayout|keyboardHidden|density"
    android:theme="@android:style/Theme.DeviceDefault.NoActionBar" />
```
(If your app's other activities already use a theme with no action bar, you can use that theme instead.)

## 2) Use
1. Put the app in split-screen (Recents -> app icon -> Split screen / Multi-window).
2. In window 1 (login yasinm): lobby -> button "🧪 پنجرهٔ دوم" -> window 2 opens next to it.
   If your phone opens it full screen, open Recents and drag/split it next to window 1.
3. Window 1: online mode, create a room. Window 2 (named yasinm_p2): enter the code. First to enter = P1, second = P2
   (swap who creates the room to test as P1 or as P2). Pick the same ROM in both.
4. Each window has its own on-screen pad. In window 1 press "🔴 لاگ Lockstep": both windows are logged and you get one BOTH file.

## Notes
- Window 2 keeps its own saves/prefs (saves_p2, bazirox_emu_p2), so it can't overwrite window 1's save-states.
- Both windows play sound; lower the volume or test with one muted.
- Same phone = ~0 ms network between windows to the phone itself, but the traffic still goes through the real relay
  (telemio.ir/netplay), so ping/stall numbers are the real relay round trip.
- It's one CPU/GPU for two emulators: fps can be lower than on two phones. Don't judge LOW_FPS from this test.
- The normal app is unchanged: EmuInstance.suffix is "" there.
