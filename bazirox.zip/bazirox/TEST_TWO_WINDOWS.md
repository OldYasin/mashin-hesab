# Two players on ONE screen (username yasinm only)

Button in the emulator lobby: "🧪 تست دونفره: دو بازیکن روی یک صفحه".

- Left/top half = the normal emulator screen (production code, normal process).
- Right/bottom half = a second, independent emulator in its own process (":p2" = own native core + own lockstep state,
  like a second phone), drawn INTO the same window with SurfaceControlViewHost (needs Android 11 / API 30+).
  Below Android 11 the button falls back to the old separate-window mode (EmulatorTestActivity).
- One window = MIUI can't pause/freeze one half. Touches on each half go to that player's pad.

## Use
1. Add the game once in the normal lobby (ROM list). The second half uses the same ROM library (its file picker does nothing).
2. Press the button. In one half: online mode -> create room. In the other half: online mode -> enter the code.
   First in the room = P1, second = P2 (swap the halves to test the other role). Pick the same game in both.
3. Auto log (yasinm half) starts when the game screen opens; leaving the game stops both and writes
   `lockstep_BOTH_...txt` to Download/Bazirox.

## Notes / limits
- Same phone = two emulators on one CPU/GPU: fps lower than on two phones, don't judge LOW_FPS here.
- Traffic still goes through the real relay (telemio.ir/netplay), so ping/stall/desync numbers are real.
- Dialogs (AlertDialog) opened inside the second half can't show (no Activity window); everything else works.
- Both halves play sound.
- The second half keeps its own saves/prefs (saves_p2, bazirox_emu_p2).
- Old separate-window mode: manifest has EmulatorTestActivity (":p2") for Android < 11 only.
