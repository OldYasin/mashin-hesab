package com.example.data

import android.content.Context
import android.os.SystemClock
import android.util.Log
import java.io.File
import java.io.FileWriter
import java.io.PrintWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue

object LockstepLogger {
    private const val TAG = "LockstepDiagnostic"
    private const val MAX_LOGS = 500

    @Volatile
    var isRecording = false
        private set

    private val logBuffer = ConcurrentLinkedQueue<String>()
    private val df = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private var startTimeMs = 0L
    private var currentLogFile: File? = null
    private var writer: PrintWriter? = null

    fun start(context: Context, username: String, room: String, slot: Int, core: String): String {
        stop()
        startTimeMs = SystemClock.elapsedRealtime()
        isRecording = true
        logBuffer.clear()

        val logDir = File(context.filesDir, "lockstep_logs").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "lockstep_${username}_${room}_${timeStamp}.txt"
        val file = File(logDir, fileName)
        currentLogFile = file

        try {
            writer = PrintWriter(FileWriter(file, true), true)
            val header = """
                ============================================================
                BAZIROX LOCKSTEP FULL DIAGNOSTIC LOG
                User: $username | Room: $room | Slot: $slot | Core: $core
                Started At: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}
                ============================================================
            """.trimIndent()
            writer?.println(header)
            log("INFO", "Diagnostic session initialized. Slot=$slot, Room=$room, User=$username")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create log file", e)
        }
        return file.absolutePath
    }

    fun log(tag: String, msg: String) {
        if (!isRecording) return
        val elapsed = SystemClock.elapsedRealtime() - startTimeMs
        val nowStr = df.format(Date())
        val line = "[$nowStr | +${elapsed}ms] [$tag] $msg"
        
        Log.d(TAG, line)
        try {
            writer?.println(line)
        } catch (_: Exception) {}

        logBuffer.add(line)
        while (logBuffer.size > MAX_LOGS) {
            logBuffer.poll()
        }
    }

    fun stop(): File? {
        if (!isRecording) return currentLogFile
        isRecording = false
        log("INFO", "Diagnostic session stopped.")
        try {
            writer?.flush()
            writer?.close()
        } catch (_: Exception) {}
        writer = null
        val res = currentLogFile
        return res
    }

    fun getRecentLogs(): List<String> {
        return logBuffer.toList()
    }

    fun getCurrentLogFilePath(): String? = currentLogFile?.absolutePath
}
