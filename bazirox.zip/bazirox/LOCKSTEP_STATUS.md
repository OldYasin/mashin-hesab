# Lockstep Netplay – Implementation & Fix Status

## Overview
All bugs identified during architectural review have been addressed and resolved. The project contains the complete LibretroDroid 0.13.0 native core with all submodules, thread-safe FIFO packet queues, frame-aligned CRC32 verification, display refresh pacing (60/90/120Hz), and a paused handshake sequence for zero-drift startup and recovery.

---

### Phase 0 – Vendored Module & Build System ✅
- **Complete upstream LibretroDroid 0.13.0** vendored with all submodules:
  - `oboe` (google/oboe 1.5-stable)
  - `libretro-common` (VFS, rtime, utf-8 encoding)
  - All renderers (ES2, ES3), resamplers, shaders, and VFS wrappers (1,639 files total).
- Modernized `libretrodroid/build.gradle.kts` using Kotlin DSL and version catalog (`libs.versions.toml`).
- ABI target configured for `arm64-v8a`.

### Phase 1 – C++ Core & JNI Linkage ✅
- **JNI Scope**: Correct `extern "C"` and `namespace libretrodroid` linkage for all `Java_com_swordfish_libretrodroid_LibretroDroid_ls*` methods in `libretrodroidjni.cpp` and `libretrodroidjni.h`.
- **Atomic Ring Buffer & Step Logic**:
  - `lockstep.h` and `lockstep.cpp` implement a 2048-slot input ring buffer.
  - Granular frame execution: `applyInput(frame) -> core->retro_run()` runs individually for each frame.
  - Multi-element FIFO queue (`takeSendQueue`) guarantees that all scheduled local inputs (including `F+D` and `F+D+1`) are transmitted without loss.
  - Native CRC32 calculation at exact frame boundaries (`f % 120 == 0`) stored and compared deterministically against peer hashes.
- **Refresh Rate & Pacing**:
  - `FPSSync::advanceFrames()` and `FPSSync::wait()` are respected in lockstep mode, preventing excessive speedup on 90Hz/120Hz screens.

### Phase 2 – Protocol & Kotlin Integration ✅
- Binary packets:
  - `type=2`: `[2][frame:4 LE][mask:2 LE]` (input mask)
  - `type=3`: `[3][frame:4 LE][hash:4 LE]` (frame-aligned CRC32 hash)
- High-frequency poll loop drains `lsTakeSend()` and `lsTakeHashes()` at ~120Hz.
- Touch input mapped to libretro bitmask via `LockstepMask.withKey()`.

### Phase 3 – Server Relay (`public/app.js`) ✅
- WebSocket relay preserves type=2 and type=3 packets without buffering drops.

### Phase 4 – Frame-Aligned Desync Recovery ✅
- Desync detection evaluates CRC32 for matching frame indices only.
- On true mismatch:
  - Host initiates `lspause` and captures clean save-state.
  - Guest loads state and acknowledges with `lsready`.
  - Both sides resume with `lsgo` from frame 0 with synchronized initial buffers.

### Phase 5 – UX & Visual Feedback ✅
- `GLRetroView.isPaused` flag freezes GL thread rendering cleanly during state synchronization.
- Status overlay reflects ping, delay (D), frame counter, stall count, and desync count.
