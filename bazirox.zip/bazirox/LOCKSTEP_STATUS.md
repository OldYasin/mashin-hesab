# Lockstep Netplay – Implementation & Fix Status

## Overview
All bugs identified during architectural review have been addressed and resolved. The project contains the complete LibretroDroid 0.13.0 native core with all submodules, thread-safe FIFO packet queues, frame-aligned CRC32 verification, display refresh pacing (60/90/120Hz), and a paused handshake sequence for zero-drift startup and recovery.

---

### Phase 0 – Vendored Module & Build System ✅
- **Complete upstream LibretroDroid 0.13.0** vendored with all submodules:
  - `oboe` (google/oboe 1.5-stable)
  - `libretro-common` (VFS, rtime, utf-8 encoding)
  - All renderers (ES2, ES3), resamplers, shaders, and VFS wrappers (1,639 files total).
- Modernized `libretrodroid/build.gradle.kts` using Kotlin DSL and version catalog (`libs.versions.toml`).
- ABI target configured for `arm64-v8a`.

### Phase 1 – C++ Core & JNI Linkage ✅
- **JNI Scope**: Correct `extern "C"` and `namespace libretrodroid` linkage for all `Java_com_swordfish_libretrodroid_LibretroDroid_ls*` methods in `libretrodroidjni.cpp` and `libretrodroidjni.h`.
- **Atomic Ring Buffer & Step Logic**:
  - `lockstep.h` and `lockstep.cpp` implement a 2048-slot input ring buffer.
  - Granular frame execution: `applyInput(frame) -> core->retro_run()` runs individually for each frame.
  - Multi-element FIFO queue (`takeSendQueue`) guarantees that all scheduled local inputs (including `F+D` and `F+D+1`) are transmitted without loss.
  - Native CRC32 calculation at exact frame boundaries (`f % 120 == 0`) stored and compared deterministically against peer hashes.
- **Refresh Rate & Pacing**:
  - `FPSSync::advanceFrames()` and `FPSSync::wait()` are respected in lockstep mode, preventing excessive speedup on 90Hz/120Hz screens.

### Phase 2 – Protocol & Kotlin Integration ✅
- Binary packets:
  - `type=2`: `[2][session:1][frame:4 BE][mask:2 LE]` (input mask)
  - `type=3`: `[3][session:1][frame:4 BE][hash:4 BE]` (frame-aligned CRC32 hash)
- High-frequency poll loop drains `lsTakeSend()` and `lsTakeHashes()` at ~120Hz.
- Touch input mapped to libretro bitmask via `LockstepMask.withKey()`.

### Phase 3 – Server Relay (`public/app.js`) ✅
- WebSocket relay preserves type=2 and type=3 packets without buffering drops.

### Phase 4 – Frame-Aligned Desync Recovery ✅
- Desync detection evaluates CRC32 for matching frame indices only.
- On true mismatch:
  - Host initiates `lspause` and captures clean save-state.
  - Guest loads state and acknowledges with `lsready`.
  - Both sides resume with `lsgo` from frame 0 with synchronized initial buffers.

### Phase 5 – UX & Visual Feedback ✅
- `GLRetroView.isPaused` flag freezes GL thread rendering cleanly during state synchronization.
- Status overlay reflects ping, delay (D), frame counter, stall count, and desync count.

---

## Diagnostic log (button "🔴 لاگ Lockstep")

Tap once to start, tap again to stop. On stop the file is copied to **Download/Bazirox/** (Android 10+; older phones: `Android/data/<app>/files/lockstep_logs`) and the toast shows where. Send that file.

**One tap is enough:** pressing the button on your phone also starts logging on the other phone (command `lslogstart`); pressing it again stops both (`lslogstop`), the other phone sends its log over the same WebSocket (deflate+base64 text frames, the relay forwards them unchanged) and you get ONE file `lockstep_BOTH_<room>_<time>.txt` with a combined summary on top and both full logs below. Both phones must run this version; if the other phone is old/disconnected the file just says `NOT RECEIVED` for it.

| Tag | Meaning |
|---|---|
| `METRICS` (1 line/s) | `fps` real emulation speed · `diff` how far the peer is ahead · `stalls=+n(tot)` / `stallMs` time spent waiting for the peer · `rxGapMax` longest silence between peer packets · `ping/oneWay/jitter` · `wsQueue` bytes stuck in our socket · `catchUp` double-steps |
| `WARN` | a bad moment: `LOW_FPS`, `STALL`, `STUCK`, `RX_GAP`, `PING_SPIKE`, `SEND_BACKLOG`, `CATCH_UP`, `RESYNC_TIMEOUT`, `CONNECTION_CLOSED`, `STATE_LOAD_FAILED` |
| `CMD_TX/RX` + `HANDSHAKE DONE` | resync timeline (lspause → lsinit → lsready → lsgo) with ms since the start |
| `STATE_TX/RX` | state size and how long it took to send / load |
| `DESYNC`, `DELAY`, `SAVE`, `LOAD`, `PEER`, `STATE` | events |
| `SUMMARY` + `DIAGNOSIS` | written at the end: totals, ping p50/p95, stall %, and the most likely cause (NETWORK / DEVICE / D TOO LOW / DESYNC / HICCUPS) |

Per-packet lines (`INPUT_TX/RX`, `HASH_*`) are off by default; set `LockstepLogger.verbose = true` for a deep dive.

---

## Round 2 fixes (from lockstep_BOTH_MTCT4_20261118 log) - part 1

1. **D too low** - D came from the quietest recent pings (oneWay 53ms -> D=5) while the route later drifted to ~100ms, so
   D=5 stalled ~8-10x/s (fps ~40). D now uses the 75th percentile of the last ~30 pings + 2x jitter + 10ms slack,
   rises at once to that estimate, clamp 2..10 (NetplayClient.delayRttMs / rttJitterMs, EmulatorScreen.delayFramesEst).
2. **Hash compare hardened** (lockstep.cpp) - when the peer hash arrived first the mismatch was only counted natively and
   never triggered a recovery; local entries were also kept after a match so a late/duplicate packet with the same frame
   label could be compared again and raise a bogus DESYNC. Both entries are now dropped on compare, out-of-window hashes
   are ignored, and a Kotlin watchdog polls the native desync counter (handleDesync(..., "native")).
3. **Key state cleared on lockstep start** (Input::releaseAllKeys from lsStart) - a key still held from the pre-handshake
   path existed on one phone only.
4. **Frozen host watchdog** - host stuck >3.5s at one frame while the peer is online -> host restarts the handshake
   itself (10s cooldown). The log showed 12+ s frozen at frame 1153 with the guest INACTIVE.

5. **No more 60 s hash pause** (log M2SWG) - after a 2nd desync within a minute the old code switched hash checking off for 60 s,
   so the game ran desynchronised (NPCs in different places) and the hashes queued meanwhile were flushed later (that is why
   labels like frame=1500 showed up at cur=2551). Every real desync now triggers a resync (4 s guard against stale packets).
