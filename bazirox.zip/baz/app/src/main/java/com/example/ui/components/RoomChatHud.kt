package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import com.example.data.AvatarImage
import com.example.data.RoomChatMessage
import com.example.data.RoomPlayerInfo
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

private const val BUBBLE_VISIBLE_MS = 6_000L

private data class ChatBubble(val id: String, val text: String)

/**
 * Bottom strip for ONLINE game rooms:
 *  - one avatar per player in the room,
 *  - a new chat line pops up as a small notification bubble right under its sender's avatar,
 *  - a chat button opens a full chat box (history + input).
 */
@Composable
fun RoomChatHud(
  players: List<String>,
  playerInfo: Map<String, RoomPlayerInfo>,
  avatars: Map<String, AvatarImage>,
  messages: List<RoomChatMessage>,
  ready: Boolean,
  me: String,
  onSend: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  var panelOpen by remember { mutableStateOf(false) }
  var unread by remember { mutableIntStateOf(0) }
  val bubbles = remember { mutableStateMapOf<String, ChatBubble>() }
  val seen = remember { HashSet<String>() }
  var armed by remember { mutableStateOf(false) }

  // History that was already in the room when we joined must not pop up as bubbles.
  LaunchedEffect(ready) {
    if (ready && !armed) {
      messages.forEach { seen.add(it.id) }
      armed = true
    }
  }
  LaunchedEffect(messages, armed) {
    if (!armed) return@LaunchedEffect
    messages.forEach { m ->
      if (seen.add(m.id)) {
        bubbles[m.sender.lowercase()] = ChatBubble(m.id, m.text)
        if (!panelOpen && !m.sender.equals(me, ignoreCase = true)) unread++
        if (!m.sender.equals(me, ignoreCase = true)) com.example.data.SoundManager.play(com.example.data.Sfx.MSG_RECEIVE)
      }
    }
  }
  LaunchedEffect(panelOpen) { if (panelOpen) unread = 0 }

  Column(
    modifier =
      modifier
        .fillMaxWidth()
        .background(Brush.verticalGradient(listOf(Color.Transparent, ObsidianBg.copy(alpha = 0.96f))))
        .padding(horizontal = 10.dp)
        .padding(top = 4.dp, bottom = 6.dp)
  ) {
    AnimatedVisibility(
      visible = panelOpen,
      enter = fadeIn() + expandVertically(),
      exit = fadeOut() + shrinkVertically(),
    ) {
      ChatPanel(
        messages = messages,
        playerInfo = playerInfo,
        avatars = avatars,
        me = me,
        onSend = onSend,
        onClose = { panelOpen = false },
      )
    }

    Row(verticalAlignment = Alignment.Top, modifier = Modifier.fillMaxWidth()) {
      Row(modifier = Modifier.weight(1f)) {
        players.forEach { username ->
          val info = playerInfo[username]
          PlayerSlot(
            name = info?.displayName?.ifBlank { null } ?: username,
            colorIndex = info?.colorIndex ?: username.hashCode(),
            image = avatars[username.lowercase()]?.bitmap,
            isMe = username.equals(me, ignoreCase = true),
            bubble = bubbles[username.lowercase()],
            onClick = { panelOpen = true },
            modifier = Modifier.weight(1f),
          )
        }
      }
      Spacer(Modifier.width(6.dp))
      ChatToggleButton(
        open = panelOpen,
        unread = unread,
        onClick = { panelOpen = !panelOpen },
      )
    }
  }
}

@Composable
private fun PlayerSlot(
  name: String,
  colorIndex: Int,
  image: androidx.compose.ui.graphics.ImageBitmap?,
  isMe: Boolean,
  bubble: ChatBubble?,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val accent = avatarColorFor(colorIndex)
  var show by remember { mutableStateOf(false) }
  // Each new bubble id restarts the timer; the bubble fades out by itself.
  LaunchedEffect(bubble?.id) {
    if (bubble != null) {
      show = true
      delay(BUBBLE_VISIBLE_MS)
      show = false
    }
  }

  Column(
    modifier =
      modifier
        .padding(horizontal = 2.dp)
        .clickable(
          interactionSource = remember { MutableInteractionSource() },
          indication = null,
          onClick = onClick,
        ),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    AvatarBadge(name = name, colorIndex = colorIndex, size = 38.dp, image = image)
    Text(
      text = if (isMe) "شما" else name,
      style = MaterialTheme.typography.labelSmall,
      color = if (isMe) NeonCyan else TextSecondary,
      fontWeight = if (isMe) FontWeight.Bold else FontWeight.Medium,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
    // Fixed-height slot: the game above never jumps when a bubble appears or disappears.
    Box(modifier = Modifier.fillMaxWidth().height(48.dp), contentAlignment = Alignment.TopCenter) {
      AnimatedVisibility(
        visible = show && bubble != null,
        enter = fadeIn() + scaleIn(initialScale = 0.7f),
        exit = fadeOut() + scaleOut(targetScale = 0.9f),
      ) {
        if (bubble != null) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(modifier = Modifier.size(width = 12.dp, height = 6.dp)) {
              val path =
                Path().apply {
                  moveTo(size.width / 2f, 0f)
                  lineTo(size.width, size.height)
                  lineTo(0f, size.height)
                  close()
                }
              drawPath(path, accent)
            }
            Box(
              modifier =
                Modifier.fillMaxWidth()
                  .clip(RoundedCornerShape(10.dp))
                  .background(ElevatedCard)
                  .border(1.2.dp, accent, RoundedCornerShape(10.dp))
                  .padding(horizontal = 6.dp, vertical = 3.dp),
              contentAlignment = Alignment.Center,
            ) {
              Text(
                text = bubble.text,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, lineHeight = 14.sp),
                color = TextPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ChatToggleButton(open: Boolean, unread: Int, onClick: () -> Unit) {
  Box(contentAlignment = Alignment.TopEnd) {
    Surface(
      onClick = onClick,
      modifier = Modifier.padding(top = 2.dp).size(42.dp).testTag("room_chat_toggle"),
      shape = CircleShape,
      color = if (open) NeonCyan.copy(alpha = 0.22f) else ElevatedCard,
      border = BorderStroke(1.4.dp, if (open) NeonCyan else ElevatedCardStroke),
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(
          imageVector = BaziIcons.Forum,
          contentDescription = "چت بازی",
          tint = if (open) NeonCyan else TextSecondary,
          modifier = Modifier.size(22.dp),
        )
      }
    }
    if (unread > 0 && !open) {
      Box(
        modifier = Modifier.size(18.dp).clip(CircleShape).background(CrimsonMagenta),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = if (unread > 9) "9+" else unread.toString(),
          style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
          color = Color.White,
          fontWeight = FontWeight.ExtraBold,
        )
      }
    }
  }
}

@Composable
private fun ChatPanel(
  messages: List<RoomChatMessage>,
  playerInfo: Map<String, RoomPlayerInfo>,
  avatars: Map<String, AvatarImage>,
  me: String,
  onSend: (String) -> Unit,
  onClose: () -> Unit,
) {
  val listState = rememberLazyListState()
  var draft by remember { mutableStateOf("") }
  val shape = RoundedCornerShape(18.dp)

  LaunchedEffect(messages.size) {
    if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
  }

  fun submit() {
    val t = draft.trim()
    if (t.isEmpty()) return
    onSend(t)
    com.example.data.SoundManager.play(com.example.data.Sfx.MSG_SEND)
    draft = ""
  }

  Column(
    modifier =
      Modifier.fillMaxWidth()
        .padding(bottom = 6.dp)
        .clip(shape)
        .background(ElevatedCard.copy(alpha = 0.97f))
        .border(1.dp, ElevatedCardStroke, shape)
  ) {
    if (messages.isEmpty()) {
      Box(
        modifier = Modifier.fillMaxWidth().height(64.dp),
        contentAlignment = Alignment.Center,
      ) {
        Text("هنوز پیامی نیست؛ سلام کن 👋", style = MaterialTheme.typography.bodySmall, color = TextMuted)
      }
    } else {
      LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxWidth().heightIn(max = 170.dp).testTag("room_chat_list"),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        items(messages, key = { it.id }) { m ->
          val info = playerInfo[m.sender]
          val mine = m.sender.equals(me, ignoreCase = true)
          Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            AvatarBadge(
              name = info?.displayName?.ifBlank { null } ?: m.sender,
              colorIndex = info?.colorIndex ?: m.sender.hashCode(),
              size = 26.dp,
              image = avatars[m.sender.lowercase()]?.bitmap,
            )
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = if (mine) "شما" else (info?.displayName?.ifBlank { null } ?: m.sender),
                style = MaterialTheme.typography.labelSmall,
                color = if (mine) NeonCyan else TextSecondary,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = m.text,
                style = MaterialTheme.typography.bodySmall,
                color = if (m.failed) CrimsonMagenta else TextPrimary,
              )
              if (m.failed) {
                Text("ارسال نشد", style = MaterialTheme.typography.labelSmall, color = CrimsonMagenta)
              }
            }
          }
        }
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      BasicTextField(
        value = draft,
        onValueChange = { if (it.length <= 200) draft = it },
        singleLine = true,
        textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
        cursorBrush = SolidColor(NeonCyan),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
        keyboardActions = KeyboardActions(onSend = { submit() }),
        modifier = Modifier.weight(1f).testTag("room_chat_input"),
        decorationBox = { inner ->
          Box(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color.White.copy(alpha = 0.06f))
                .border(1.dp, ElevatedCardStroke, RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            contentAlignment = Alignment.CenterStart,
          ) {
            if (draft.isEmpty()) {
              Text("پیام بنویس...", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            }
            inner()
          }
        },
      )
      Surface(
        onClick = { submit() },
        enabled = draft.isNotBlank(),
        modifier = Modifier.size(40.dp).testTag("room_chat_send"),
        shape = CircleShape,
        color = if (draft.isNotBlank()) NeonCyan else Color.White.copy(alpha = 0.08f),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.Send,
            contentDescription = "ارسال",
            tint = if (draft.isNotBlank()) ObsidianBg else TextMuted,
            modifier = Modifier.size(20.dp),
          )
        }
      }
    }
  }
}
