package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import com.example.data.AvatarImage
import com.example.data.RoomChatMessage
import com.example.data.RoomPlayerInfo
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

private const val BUBBLE_VISIBLE_MS = 6_000L

internal data class ChatBubble(val id: String, val text: String)

/** Lets GameTopBar show extra content (the room's player avatars) right under the game header. */
val LocalGameTopExtra = androidx.compose.runtime.compositionLocalOf<(@Composable () -> Unit)?> { null }

internal class RoomChatUiState {
  var panelOpen by mutableStateOf(false)
  var unread by mutableIntStateOf(0)
  val bubbles = mutableStateMapOf<String, ChatBubble>()
}

@Composable
internal fun rememberRoomChatState(
  messages: List<RoomChatMessage>,
  ready: Boolean,
  me: String,
): RoomChatUiState {
  val st = remember { RoomChatUiState() }
  val seen = remember { HashSet<String>() }
  var armed by remember { mutableStateOf(false) }

  // History that was already in the room when we joined must not pop up as bubbles.
  LaunchedEffect(ready) {
    if (ready && !armed) {
      messages.forEach { seen.add(it.id) }
      armed = true
    }
  }
  LaunchedEffect(messages, armed) {
    if (!armed) return@LaunchedEffect
    messages.forEach { m ->
      if (seen.add(m.id)) {
        st.bubbles[m.sender.lowercase()] = ChatBubble(m.id, m.text)
        val mine = m.sender.equals(me, ignoreCase = true)
        if (!st.panelOpen && !mine) st.unread++
        if (!mine) com.example.data.SoundManager.play(com.example.data.Sfx.MSG_RECEIVE)
      }
    }
  }
  LaunchedEffect(st.panelOpen) { if (st.panelOpen) st.unread = 0 }
  return st
}

/** Top strip (under the game header): one avatar per player; new chat lines pop up right under their sender. */
@Composable
internal fun RoomPlayersStrip(
  state: RoomChatUiState,
  players: List<String>,
  playerInfo: Map<String, RoomPlayerInfo>,
  avatars: Map<String, AvatarImage>,
  me: String,
) {
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .background(Color(0xFF243180))
        .padding(horizontal = 10.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceEvenly,
    verticalAlignment = Alignment.Top,
  ) {
    players.forEach { username ->
      val info = playerInfo[username]
      PlayerSlot(
        name = info?.displayName?.ifBlank { null } ?: username,
        colorIndex = info?.colorIndex ?: username.hashCode(),
        image = avatars[username.lowercase()]?.bitmap,
        isMe = username.equals(me, ignoreCase = true),
        bubble = state.bubbles[username.lowercase()],
        onClick = { state.panelOpen = true },
        modifier = Modifier.weight(1f),
      )
    }
  }
}

/** Bottom bar: "game chat" button; the chat box (history + input) opens right above it. */
@Composable
internal fun RoomChatBar(
  state: RoomChatUiState,
  playerInfo: Map<String, RoomPlayerInfo>,
  avatars: Map<String, AvatarImage>,
  messages: List<RoomChatMessage>,
  me: String,
  onSend: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier =
      modifier
        .fillMaxWidth()
        .background(ObsidianBg)
        .padding(horizontal = 10.dp)
        .padding(top = 4.dp, bottom = 6.dp)
  ) {
    AnimatedVisibility(
      visible = state.panelOpen,
      enter = fadeIn() + expandVertically(),
      exit = fadeOut() + shrinkVertically(),
    ) {
      ChatPanel(
        messages = messages,
        playerInfo = playerInfo,
        avatars = avatars,
        me = me,
        onSend = onSend,
        onClose = { state.panelOpen = false },
      )
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
      ChatToggleButton(
        open = state.panelOpen,
        unread = state.unread,
        onClick = { state.panelOpen = !state.panelOpen },
      )
    }
  }
}

private class BelowAnchorPositionProvider : PopupPositionProvider {
  override fun calculatePosition(
    anchorBounds: IntRect,
    windowSize: IntSize,
    layoutDirection: LayoutDirection,
    popupContentSize: IntSize,
  ): IntOffset {
    val x = (anchorBounds.center.x - popupContentSize.width / 2)
      .coerceIn(8, (windowSize.width - popupContentSize.width - 8).coerceAtLeast(8))
    return IntOffset(x, anchorBounds.bottom + 2)
  }
}

@Composable
private fun PlayerSlot(
  name: String,
  colorIndex: Int,
  image: androidx.compose.ui.graphics.ImageBitmap?,
  isMe: Boolean,
  bubble: ChatBubble?,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val accent = avatarColorFor(colorIndex)
  var show by remember { mutableStateOf(false) }
  // Each new bubble id restarts the timer; the bubble disappears by itself.
  LaunchedEffect(bubble?.id) {
    if (bubble != null) {
      show = true
      delay(BUBBLE_VISIBLE_MS)
      show = false
    }
  }

  Column(
    modifier =
      modifier
        .padding(horizontal = 2.dp)
        .clickable(
          interactionSource = remember { MutableInteractionSource() },
          indication = null,
          onClick = onClick,
        ),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    AvatarBadge(name = name, colorIndex = colorIndex, size = 40.dp, image = image)
    Text(
      text = if (isMe) "شما" else name,
      style = MaterialTheme.typography.labelSmall,
      color = if (isMe) NeonCyan else TextSecondary,
      fontWeight = if (isMe) FontWeight.Bold else FontWeight.Medium,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
    // Floating bubble under the avatar: overlays the game, never pushes it around.
    if (show && bubble != null) {
      Popup(popupPositionProvider = BelowAnchorPositionProvider()) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Canvas(modifier = Modifier.size(width = 12.dp, height = 6.dp)) {
            val path =
              Path().apply {
                moveTo(size.width / 2f, 0f)
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
              }
            drawPath(path, accent)
          }
          Box(
            modifier =
              Modifier.widthIn(max = 220.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(ElevatedCard)
                .border(1.2.dp, accent, RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center,
          ) {
            Text(
              text = bubble.text,
              style = MaterialTheme.typography.labelMedium.copy(lineHeight = 16.sp),
              color = TextPrimary,
              maxLines = 3,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ChatToggleButton(open: Boolean, unread: Int, onClick: () -> Unit) {
  Box(contentAlignment = Alignment.TopEnd) {
    Surface(
      onClick = onClick,
      modifier = Modifier.padding(top = 4.dp).height(42.dp).testTag("room_chat_toggle"),
      shape = RoundedCornerShape(50),
      color = if (open) NeonCyan.copy(alpha = 0.22f) else NeonCyan,
      border = BorderStroke(1.4.dp, NeonCyan),
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          imageVector = BaziIcons.Forum,
          contentDescription = null,
          tint = if (open) NeonCyan else ObsidianBg,
          modifier = Modifier.size(20.dp),
        )
        Text(
          text = "چت بازی",
          style = MaterialTheme.typography.labelLarge,
          color = if (open) NeonCyan else ObsidianBg,
          fontWeight = FontWeight.Bold,
        )
      }
    }
    if (unread > 0 && !open) {
      Box(
        modifier = Modifier.size(18.dp).clip(CircleShape).background(CrimsonMagenta),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = if (unread > 9) "9+" else unread.toString(),
          style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
          color = Color.White,
          fontWeight = FontWeight.ExtraBold,
        )
      }
    }
  }
}

@Composable
private fun ChatPanel(
  messages: List<RoomChatMessage>,
  playerInfo: Map<String, RoomPlayerInfo>,
  avatars: Map<String, AvatarImage>,
  me: String,
  onSend: (String) -> Unit,
  onClose: () -> Unit,
) {
  val listState = rememberLazyListState()
  var draft by remember { mutableStateOf("") }
  val shape = RoundedCornerShape(18.dp)

  LaunchedEffect(messages.size) {
    if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
  }

  fun submit() {
    val t = draft.trim()
    if (t.isEmpty()) return
    onSend(t)
    com.example.data.SoundManager.play(com.example.data.Sfx.MSG_SEND)
    draft = ""
  }

  Column(
    modifier =
      Modifier.fillMaxWidth()
        .padding(bottom = 4.dp)
        .clip(shape)
        .background(ElevatedCard.copy(alpha = 0.97f))
        .border(1.dp, ElevatedCardStroke, shape)
  ) {
    if (messages.isEmpty()) {
      Box(
        modifier = Modifier.fillMaxWidth().height(64.dp),
        contentAlignment = Alignment.Center,
      ) {
        Text("هنوز پیامی نیست؛ سلام کن 👋", style = MaterialTheme.typography.bodySmall, color = TextMuted)
      }
    } else {
      LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxWidth().heightIn(max = 120.dp).testTag("room_chat_list"),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        items(messages, key = { it.id }) { m ->
          val info = playerInfo[m.sender]
          val mine = m.sender.equals(me, ignoreCase = true)
          Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            AvatarBadge(
              name = info?.displayName?.ifBlank { null } ?: m.sender,
              colorIndex = info?.colorIndex ?: m.sender.hashCode(),
              size = 26.dp,
              image = avatars[m.sender.lowercase()]?.bitmap,
            )
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = if (mine) "شما" else (info?.displayName?.ifBlank { null } ?: m.sender),
                style = MaterialTheme.typography.labelSmall,
                color = if (mine) NeonCyan else TextSecondary,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = m.text,
                style = MaterialTheme.typography.bodySmall,
                color = if (m.failed) CrimsonMagenta else TextPrimary,
              )
              if (m.failed) {
                Text("ارسال نشد", style = MaterialTheme.typography.labelSmall, color = CrimsonMagenta)
              }
            }
          }
        }
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      BasicTextField(
        value = draft,
        onValueChange = { if (it.length <= 200) draft = it },
        singleLine = true,
        textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
        cursorBrush = SolidColor(NeonCyan),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
        keyboardActions = KeyboardActions(onSend = { submit() }),
        modifier = Modifier.weight(1f).testTag("room_chat_input"),
        decorationBox = { inner ->
          Box(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color.White.copy(alpha = 0.06f))
                .border(1.dp, ElevatedCardStroke, RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            contentAlignment = Alignment.CenterStart,
          ) {
            if (draft.isEmpty()) {
              Text("پیام بنویس...", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            }
            inner()
          }
        },
      )
      Surface(
        onClick = { submit() },
        enabled = draft.isNotBlank(),
        modifier = Modifier.size(40.dp).testTag("room_chat_send"),
        shape = CircleShape,
        color = if (draft.isNotBlank()) NeonCyan else Color.White.copy(alpha = 0.08f),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.Send,
            contentDescription = "ارسال",
            tint = if (draft.isNotBlank()) ObsidianBg else TextMuted,
            modifier = Modifier.size(20.dp),
          )
        }
      }
    }
  }
}
