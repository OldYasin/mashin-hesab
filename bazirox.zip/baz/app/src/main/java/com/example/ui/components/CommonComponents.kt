package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameType
import com.example.data.PlayMode
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlayerBlue
import com.example.ui.theme.PlayerGreen
import com.example.ui.theme.PlayerRed
import com.example.ui.theme.PlayerYellow
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPulse
import kotlin.math.ceil
import kotlin.random.Random
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.composed

/** Fades + slides a composable in once (stays shown while scrolling), staggered by [index]. */
fun Modifier.fadeSlideIn(index: Int = 0): Modifier = composed {
  var shown by rememberSaveable { mutableStateOf(false) }
  LaunchedEffect(Unit) {
    if (!shown) delay(index.coerceIn(0, 10) * 70L)
    shown = true
  }
  val alpha by animateFloatAsState(if (shown) 1f else 0f, tween(420), label = "fsAlpha")
  val rise by
    animateFloatAsState(if (shown) 0f else 1f, tween(420, easing = FastOutSlowInEasing), label = "fsRise")
  graphicsLayer {
    this.alpha = alpha
    translationY = rise * 40f
  }
}

/** Counts up from 0 to [target] the first time it is shown, then follows changes smoothly. */
@Composable
fun rememberCountUp(target: Int, durationMs: Int = 900): Int {
  var goal by remember { mutableIntStateOf(0) }
  LaunchedEffect(target) { goal = target }
  val value by animateIntAsState(goal, tween(durationMs, easing = FastOutSlowInEasing), label = "countUp")
  return value
}

val AvatarPalette = listOf(NeonCyan, VioletPulse, CyberGold, ElectricEmerald, CrimsonMagenta, PlayerBlue)

fun avatarColorFor(index: Int): Color = AvatarPalette[index.mod(AvatarPalette.size)]

fun playerColorFor(index: Int): Color =
  when (index.mod(4)) {
    0 -> PlayerRed
    1 -> PlayerGreen
    2 -> PlayerYellow
    else -> PlayerBlue
  }

/**
 * Frosted Glassmorphic Gradient container with specular top-left rim and soft inner tint.
 */
@Composable
fun GlassGradientCard(
  modifier: Modifier = Modifier,
  accentColor: Color = NeonCyan,
  cornerRadius: Dp = 22.dp,
  onClick: (() -> Unit)? = null,
  content: @Composable BoxScope.() -> Unit,
) {
  val shape: Shape = RoundedCornerShape(cornerRadius)
  val interaction = remember { MutableInteractionSource() }
  val pressed by interaction.collectIsPressedAsState()
  val pressScale by
    animateFloatAsState(
      targetValue = if (onClick != null && pressed) 0.96f else 1f,
      animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
      label = "glassPressScale",
    )
  // Brushes are cached per accent colour: no allocation on every recomposition.
  val borderBrush =
    remember(accentColor) {
      Brush.linearGradient(
        colors =
          listOf(
            Color.White.copy(alpha = 0.28f),
            accentColor.copy(alpha = 0.38f),
            Color.White.copy(alpha = 0.06f),
          )
      )
    }
  val fillBrush =
    remember(accentColor) {
      Brush.linearGradient(
        colors =
          listOf(
            Color(0xE6334499),
            Color(0xE62B3A8C),
            accentColor.copy(alpha = 0.12f),
          )
      )
    }

  Box(
    modifier =
      modifier
        .graphicsLayer {
          scaleX = pressScale
          scaleY = pressScale
        }
        .clip(shape)
        .background(fillBrush)
        .border(1.2.dp, borderBrush, shape)
        .then(
          if (onClick != null) {
            Modifier.clickable(
              interactionSource = interaction,
              indication = LocalIndication.current,
              onClick = onClick,
            )
          } else Modifier
        ),
    content = content,
  )
}

/**
 * Deep aurora gradient backdrop used across all screens for a cohesive glassmorphic vibe.
 */
fun Modifier.auroraGamingBackdrop(
  primaryGlow: Color = NeonCyan,
  secondaryGlow: Color = VioletPulse,
): Modifier =
  this.drawWithCache {
    // Gradients are built once per size / colour instead of on every draw pass.
    val base =
      Brush.verticalGradient(
        colors = listOf(Color(0xFF5568D6), Color(0xFF4556BE), Color(0xFF3A49A8))
      )
    val glow1 =
      Brush.radialGradient(
        colors = listOf(primaryGlow.copy(alpha = 0.18f), Color.Transparent),
        center = Offset(size.width * 0.18f, size.height * 0.10f),
        radius = size.width * 0.72f,
      )
    val glow2 =
      Brush.radialGradient(
        colors = listOf(secondaryGlow.copy(alpha = 0.16f), Color.Transparent),
        center = Offset(size.width * 0.86f, size.height * 0.48f),
        radius = size.width * 0.68f,
      )
    onDrawBehind {
      drawRect(brush = base)
      drawRect(brush = glow1)
      drawRect(brush = glow2)
    }
  }

/**
 * Clean modern gaming backdrop used by every main screen and every game screen.
 *
 * Everything (gradients, glow blooms, light beams, dot grid) is built ONCE inside drawWithCache and
 * only replayed on draw. There is no animation and no per-frame work, so it never costs a frame
 * while scrolling or playing. [tint] softly follows the active player's colour.
 */
fun Modifier.gamingBackdrop(tint: Color = Color(0xFF00E5FF)): Modifier =
  this.drawWithCache {
    val w = size.width
    val h = size.height

    // Clean, bright indigo gradient: no dots, beams or dark vignette.
    val base =
      Brush.verticalGradient(
        listOf(Color(0xFF5568D6), Color(0xFF4556BE), Color(0xFF3A49A8))
      )
    val glowTop =
      Brush.radialGradient(
        listOf(Color.White.copy(alpha = 0.16f), Color.Transparent),
        center = Offset(w * 0.25f, h * 0.0f),
        radius = w * 1.0f,
      )
    val glowTint =
      Brush.radialGradient(
        listOf(tint.copy(alpha = 0.22f), Color.Transparent),
        center = Offset(w * 0.85f, h * 0.95f),
        radius = w * 0.95f,
      )

    onDrawBehind {
      drawRect(brush = base)
      drawRect(brush = glowTop)
      drawRect(brush = glowTint)
    }
  }

/** Kept for the game screens that already call it: same clean gaming backdrop. */
fun Modifier.oceanGameBackdrop(tint: Color = Color(0xFF00E5FF)): Modifier = gamingBackdrop(tint)

/**
 * Draws a rich, 3D-beveled glossy game token/pawn on Canvas with drop shadow,
 * inner metallic ring, and top-left specular glare.
 */
fun DrawScope.drawGlossyToken(
  center: Offset,
  radius: Float,
  baseColor: Color,
  isHighlighted: Boolean = false,
  pulseFactor: Float = 1f,
) {
  if (isHighlighted) {
    drawCircle(
      color = Color.White.copy(alpha = 0.30f),
      radius = radius * (1.42f + 0.18f * pulseFactor),
      center = center,
    )
    drawCircle(
      color = CyberGold,
      radius = radius * 1.28f,
      center = center,
      style = Stroke(width = (radius * 0.18f).coerceAtLeast(2.5f)),
    )
  }

  drawCircle(
    color = Color.Black.copy(alpha = 0.55f),
    radius = radius * 1.06f,
    center = Offset(center.x + radius * 0.10f, center.y + radius * 0.18f),
  )

  drawCircle(color = ObsidianBg, radius = radius * 1.04f, center = center)

  drawCircle(
    brush =
      Brush.radialGradient(
        colors = listOf(Color.White.copy(alpha = 0.88f), baseColor, baseColor.copy(alpha = 0.62f)),
        center = Offset(center.x - radius * 0.28f, center.y - radius * 0.28f),
        radius = radius * 1.32f,
      ),
    radius = radius * 0.92f,
    center = center,
  )

  drawCircle(
    color = Color.White.copy(alpha = 0.45f),
    radius = radius * 0.62f,
    center = center,
    style = Stroke(width = (radius * 0.10f).coerceAtLeast(1.5f)),
  )

  drawCircle(
    color = Color.White.copy(alpha = 0.75f),
    radius = radius * 0.22f,
    center = Offset(center.x - radius * 0.30f, center.y - radius * 0.30f),
  )
}

/**
 * Smooth 3D-tumbling dice. All motion runs on Animatables read inside graphicsLayer / draw
 * lambdas, so rolling never recomposes the parent game screen (no lag). Only the face value
 * changes via local state (~14 fps) while the dice tumbles; on stop it settles with a spring.
 */
@Composable
fun AnimatedGameDice(
  value: Int,
  isRolling: Boolean,
  accentColor: Color,
  modifier: Modifier = Modifier,
) {
  var tumbleFace by remember { mutableIntStateOf(value.coerceIn(1, 6)) }
  val spinZ = remember { Animatable(0f) }
  val spinX = remember { Animatable(0f) }
  val spinY = remember { Animatable(0f) }
  val hop = remember { Animatable(0f) }
  val pop = remember { Animatable(1f) }
  val tilt = remember { Animatable(0f) } // 1 = corner view while tumbling, 0 = flat, readable face

  LaunchedEffect(isRolling) {
    if (isRolling) {
      coroutineScope {
        launch { pop.animateTo(1.14f, tween(120, easing = FastOutSlowInEasing)) }
        launch { tilt.animateTo(1f, tween(150)) }
        launch {
          while (isActive) spinZ.animateTo(spinZ.value + 360f, tween(520, easing = LinearEasing))
        }
        launch {
          while (isActive) spinX.animateTo(spinX.value + 360f, tween(680, easing = LinearEasing))
        }
        launch {
          while (isActive) spinY.animateTo(spinY.value + 360f, tween(860, easing = LinearEasing))
        }
        launch {
          while (isActive) {
            hop.animateTo(1f, tween(170, easing = FastOutSlowInEasing))
            hop.animateTo(0f, tween(150, easing = FastOutLinearInEasing))
          }
        }
        launch {
          while (isActive) {
            delay(70)
            var n: Int
            do {
              n = Random.nextInt(1, 7)
            } while (n == tumbleFace)
            tumbleFace = n
          }
        }
      }
    } else {
      val settle = spring<Float>(dampingRatio = 0.55f, stiffness = Spring.StiffnessMediumLow)
      coroutineScope {
        launch { spinZ.animateTo(ceil(spinZ.value / 360f) * 360f, settle) }
        launch { spinX.animateTo(ceil(spinX.value / 360f) * 360f, settle) }
        launch { spinY.animateTo(ceil(spinY.value / 360f) * 360f, settle) }
        launch { hop.animateTo(0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy)) }
        launch { pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy)) }
        launch { tilt.animateTo(0f, tween(380, easing = FastOutSlowInEasing)) }
      }
    }
  }

  val shown = if (isRolling) tumbleFace else value.coerceIn(1, 6)

  Box(modifier = modifier.size(72.dp), contentAlignment = Alignment.Center) {
    Canvas(modifier = Modifier.fillMaxSize().graphicsLayer { }) {
      val lift = hop.value
      val w = size.width * (0.62f - 0.12f * lift)
      val h = size.height * (0.12f - 0.03f * lift)
      drawOval(
        color = Color.Black.copy(alpha = 0.40f - 0.20f * lift),
        topLeft = Offset((size.width - w) / 2f, size.height * 0.90f - h / 2f),
        size = androidx.compose.ui.geometry.Size(w, h),
      )
    }
    // Real 3D cube: visible faces only, perspective, lighting, pips on every face.
    Canvas(
      modifier =
        Modifier.fillMaxSize().graphicsLayer {
          translationY = -hop.value * 12.dp.toPx()
          scaleX = pop.value
          scaleY = pop.value
        }
    ) {
      drawDiceCube(
        shown = shown,
        spinX = spinX.value,
        spinY = spinY.value,
        spinZ = spinZ.value,
        accent = accentColor,
        tilt = tilt.value,
      )
    }
  }
}

// ---- 3D dice math ---------------------------------------------------------------------------

private fun mul(a: FloatArray, b: FloatArray): FloatArray {
  val r = FloatArray(9)
  for (i in 0..2) for (j in 0..2) {
    var v = 0f
    for (k in 0..2) v += a[i * 3 + k] * b[k * 3 + j]
    r[i * 3 + j] = v
  }
  return r
}

private fun rotX(t: Float): FloatArray {
  val c = kotlin.math.cos(t)
  val s = kotlin.math.sin(t)
  return floatArrayOf(1f, 0f, 0f, 0f, c, -s, 0f, s, c)
}

private fun rotY(t: Float): FloatArray {
  val c = kotlin.math.cos(t)
  val s = kotlin.math.sin(t)
  return floatArrayOf(c, 0f, s, 0f, 1f, 0f, -s, 0f, c)
}

private fun rotZ(t: Float): FloatArray {
  val c = kotlin.math.cos(t)
  val s = kotlin.math.sin(t)
  return floatArrayOf(c, -s, 0f, s, c, 0f, 0f, 0f, 1f)
}

private fun transpose(m: FloatArray): FloatArray =
  floatArrayOf(m[0], m[3], m[6], m[1], m[4], m[7], m[2], m[5], m[8])

private fun applyMat(m: FloatArray, x: Float, y: Float, z: Float): FloatArray =
  floatArrayOf(
    m[0] * x + m[1] * y + m[2] * z,
    m[3] * x + m[4] * y + m[5] * z,
    m[6] * x + m[7] * y + m[8] * z,
  )

private val HalfPi = (Math.PI / 2).toFloat()

/** Rotation that brings die face [f] to the front (+Z). Opposite faces sum to 7. */
private fun faceToFront(f: Int): FloatArray =
  when (f) {
    1 -> rotX(0f)
    6 -> rotY(Math.PI.toFloat())
    2 -> rotY(-HalfPi)
    5 -> rotY(HalfPi)
    3 -> rotX(HalfPi)
    else -> rotX(-HalfPi)
  }

// Face rotation matrices never change: compute once instead of on every frame.
private val FaceFrontCache: Array<FloatArray> = Array(7) { f -> faceToFront(if (f == 0) 1 else f) }
private val FaceInvCache: Array<FloatArray> = Array(7) { f -> transpose(FaceFrontCache[f]) }

private fun pipLayout(n: Int): List<Pair<Float, Float>> {
  val a = 0.5f
  return when (n) {
    1 -> listOf(0f to 0f)
    2 -> listOf(-a to a, a to -a)
    3 -> listOf(-a to a, 0f to 0f, a to -a)
    4 -> listOf(-a to a, a to a, -a to -a, a to -a)
    5 -> listOf(-a to a, a to a, 0f to 0f, -a to -a, a to -a)
    else -> listOf(-a to a, a to a, -a to 0f, a to 0f, -a to -a, a to -a)
  }
}

private fun lerpColor(a: Color, b: Color, t: Float): Color =
  androidx.compose.ui.graphics.lerp(a, b, t.coerceIn(0f, 1f))

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawDiceCube(
  shown: Int,
  spinX: Float,
  spinY: Float,
  spinZ: Float,
  accent: Color,
  tilt: Float,
) {
  val rad = (Math.PI / 180.0).toFloat()
  val tiltM = mul(rotX(0.50f * tilt), rotY(-0.62f * tilt))
  val spin = mul(rotZ(spinZ * rad), mul(rotY(spinY * rad), rotX(spinX * rad)))
  val m = mul(tiltM, mul(spin, FaceFrontCache[shown.coerceIn(1, 6)]))

  val cx = size.width / 2f
  val cy = size.height / 2f
  val unit = size.minDimension * (0.255f + 0.08f * (1f - tilt))
  val cam = 6f

  fun project(p: FloatArray): Offset {
    val k = cam / (cam - p[2])
    return Offset(cx + p[0] * unit * k, cy - p[1] * unit * k)
  }

  val light = floatArrayOf(-0.35f, 0.65f, 0.67f)
  val bodyLit = Color(0xFFFFFBF2)
  val bodyDark = Color(0xFF7D86A3)
  val pipColor = Color(0xFF2A3886)

  // Collect faces that point toward the camera, draw far-to-near.
  class FaceInfo(val f: Int, val normalZ: Float, val bright: Float, val inv: FloatArray)

  val visible =
    (1..6)
      .map { f ->
        val inv = FaceInvCache[f]
        val nCube = applyMat(inv, 0f, 0f, 1f)
        val n = applyMat(m, nCube[0], nCube[1], nCube[2])
        val b = (n[0] * light[0] + n[1] * light[1] + n[2] * light[2]).coerceAtLeast(0f)
        FaceInfo(f, n[2], 0.42f + 0.58f * b, inv)
      }
      .filter { it.normalZ > 0.02f }
      .sortedBy { it.normalZ }

  for (face in visible) {
    fun pt(x: Float, y: Float): FloatArray {
      val c = applyMat(face.inv, x, y, 1f)
      return applyMat(m, c[0], c[1], c[2])
    }

    val corners = listOf(pt(-1f, 1f), pt(1f, 1f), pt(1f, -1f), pt(-1f, -1f)).map { project(it) }
    val path = Path().apply {
      moveTo(corners[0].x, corners[0].y)
      for (i in 1..3) lineTo(corners[i].x, corners[i].y)
      close()
    }
    val fill = lerpColor(bodyDark, bodyLit, face.bright)
    drawPath(path, color = fill)
    // Soft bevel: darker rounded edge line makes the cube read as solid.
    drawPath(
      path,
      color = lerpColor(Color(0xFF5566B3), accent, 0.35f).copy(alpha = 0.55f),
      style = Stroke(width = unit * 0.11f, join = StrokeJoin.Round),
    )

    // Pips as true projected circles (foreshortened with the face).
    val pipColorFace = if (face.f == 1) lerpColor(Color(0xFF8A1030), accent, 0.0f) else pipColor
    for ((px, py) in pipLayout(face.f)) {
      val pipPath = Path()
      val steps = 12
      for (s in 0 until steps) {
        val ang = s * (2f * Math.PI.toFloat() / steps)
        val q = project(pt(px + 0.19f * kotlin.math.cos(ang), py + 0.19f * kotlin.math.sin(ang)))
        if (s == 0) pipPath.moveTo(q.x, q.y) else pipPath.lineTo(q.x, q.y)
      }
      pipPath.close()
      drawPath(pipPath, color = pipColorFace.copy(alpha = 0.55f + 0.45f * face.bright))
    }
  }
}

@Composable
fun AvatarBadge(
  name: String,
  colorIndex: Int,
  size: Dp = 42.dp,
  modifier: Modifier = Modifier,
  /** Profile photo; when null the colored letter badge is drawn. */
  image: androidx.compose.ui.graphics.ImageBitmap? = null,
) {
  val bg = avatarColorFor(colorIndex)
  val letter = name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "ب"
  Box(
    modifier =
      modifier
        .size(size)
        .clip(CircleShape)
        .background(Brush.linearGradient(listOf(bg.copy(alpha = 0.92f), bg.copy(alpha = 0.35f))))
        .border(2.dp, bg, CircleShape),
    contentAlignment = Alignment.Center,
  ) {
    if (image != null) {
      androidx.compose.foundation.Image(
        bitmap = image,
        contentDescription = name,
        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
        modifier = Modifier.fillMaxSize(),
      )
    } else {
      Text(
        text = letter,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.ExtraBold,
        color = TextPrimary,
      )
    }
  }
}

@Composable
fun ServerStatusPill(isConnected: Boolean, modifier: Modifier = Modifier) {
  val color = if (isConnected) ElectricEmerald else CyberGold
  val infinite = rememberInfiniteTransition(label = "online_pulse")
  val dotAlpha by
    infinite.animateFloat(
      initialValue = 0.45f,
      targetValue = 1f,
      animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
      label = "dot_alpha",
    )

  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(50),
    color = color.copy(alpha = 0.14f),
    border = BorderStroke(1.dp, color.copy(alpha = 0.5f)),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Box(
        modifier =
          Modifier.size(8.dp)
            .clip(CircleShape)
            .graphicsLayer { alpha = if (isConnected) dotAlpha else 0.85f }
            .background(color)
      )
      Text(
        text = if (isConnected) "آنلاین" else "آفلاین",
        style = MaterialTheme.typography.labelSmall,
        color = color,
        fontWeight = FontWeight.Bold,
      )
    }
  }
}

@Composable
fun GameTopBar(
  title: String,
  subtitle: String,
  accentColor: Color,
  onBack: () -> Unit,
  copyText: String? = null,
  trailingContent: @Composable () -> Unit = {},
) {
  Column {
    GameTopBarSurface(title, subtitle, accentColor, onBack, copyText, trailingContent)
    LocalGameTopExtra.current?.invoke()
  }
}

@Composable
private fun GameTopBarSurface(
  title: String,
  subtitle: String,
  accentColor: Color,
  onBack: () -> Unit,
  copyText: String? = null,
  trailingContent: @Composable () -> Unit = {},
) {
  val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
  val ctx = androidx.compose.ui.platform.LocalContext.current
  Surface(
    color = Color(0xFF2A3888),
    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        IconButton(
          onClick = onBack,
          modifier = Modifier.size(48.dp).testTag("game_back_button"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
            contentDescription = "بازگشت",
            tint = TextPrimary,
          )
        }
        Spacer(Modifier.width(6.dp))
        Column {
          Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = accentColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          if (copyText != null) {
            // Visible, tappable room-code pill: tap anywhere on it to copy the code.
            Surface(
              onClick = {
                clipboard.setText(androidx.compose.ui.text.AnnotatedString(copyText))
                android.widget.Toast.makeText(ctx, "کد اتاق کپی شد", android.widget.Toast.LENGTH_SHORT).show()
              },
              shape = RoundedCornerShape(50),
              color = accentColor.copy(alpha = 0.16f),
              border = BorderStroke(1.dp, accentColor.copy(alpha = 0.6f)),
              modifier = Modifier.padding(top = 3.dp).testTag("copy_room_code_button"),
            ) {
              Row(
                modifier = Modifier.padding(start = 10.dp, end = 8.dp, top = 3.dp, bottom = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                Text(
                  text = "کد اتاق",
                  style = MaterialTheme.typography.labelSmall,
                  color = TextSecondary,
                  maxLines = 1,
                )
                Text(
                  text = copyText,
                  style =
                    MaterialTheme.typography.labelLarge.copy(
                      textDirection = androidx.compose.ui.text.style.TextDirection.Ltr,
                      letterSpacing = 0.5.sp,
                    ),
                  color = TextPrimary,
                  fontWeight = FontWeight.ExtraBold,
                  maxLines = 1,
                )
                Icon(
                  BaziIcons.Copy,
                  contentDescription = "کپی کد اتاق",
                  tint = accentColor,
                  modifier = Modifier.size(16.dp),
                )
              }
            }
          } else {
            Text(
              text = subtitle,
              style = MaterialTheme.typography.labelMedium,
              color = TextSecondary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }
      var soundOn by remember { mutableStateOf(com.example.data.SoundManager.enabled) }
      IconButton(
        onClick = {
          soundOn = !soundOn
          com.example.data.SoundManager.setEnabled(soundOn)
        },
        modifier = Modifier.size(44.dp).testTag("game_sound_toggle"),
      ) {
        Icon(
          imageVector = if (soundOn) BaziIcons.VolumeUp else BaziIcons.VolumeOff,
          contentDescription = if (soundOn) "قطع صدا" else "وصل صدا",
          tint = if (soundOn) accentColor else TextSecondary,
          modifier = Modifier.size(22.dp),
        )
      }
      trailingContent()
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameLobbyBottomSheet(
  gameType: GameType,
  isServerConnected: Boolean,
  statusMessage: String?,
  onDismiss: () -> Unit,
  onStartMode: (PlayMode, Int) -> Unit,
  onCreateOnlineRoom: () -> Unit,
  onJoinOnlineRoom: (String) -> Unit,
) {
  var selectedPlayers by remember(gameType) { mutableIntStateOf(if (gameType == GameType.LUDO || gameType == GameType.SNAKES_LADDERS) 4 else 2) }
  var roomCodeInput by remember { mutableStateOf("") }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = androidx.compose.material3.rememberModalBottomSheetState(skipPartiallyExpanded = true),
    containerColor = Color(0xFF2A3888),
    contentColor = TextPrimary,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = "شروع بازی ${gameType.titleFa}",
            style = MaterialTheme.typography.headlineSmall,
            color = NeonCyan,
          )
          Text(
            text = gameType.subtitleFa,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
          )
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Rounded.Close, contentDescription = "بستن", tint = TextSecondary)
        }
      }

      if (gameType == GameType.LUDO || gameType == GameType.SNAKES_LADDERS) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("تعداد بازیکن:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
          listOf(2, 3, 4).forEach { count ->
            val selected = selectedPlayers == count
            Surface(
              onClick = { selectedPlayers = count },
              shape = RoundedCornerShape(12.dp),
              color = if (selected) NeonCyan.copy(alpha = 0.2f) else ElevatedCard,
              border = BorderStroke(1.dp, if (selected) NeonCyan else ElevatedCardStroke),
              modifier = Modifier.testTag("player_count_$count"),
            ) {
              Text(
                text = "$count نفره",
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) NeonCyan else TextPrimary,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
              )
            }
          }
        }
      }

      LobbyModeCard(
        title = "بازی با هوش مصنوعی",
        subtitle = "رقابت سریع و روان با ربات هوشمند",
        icon = BaziIcons.SportsEsports,
        accent = ElectricEmerald,
        testTag = "mode_vs_ai",
        onClick = { onStartMode(PlayMode.VS_AI, selectedPlayers) },
      )

      LobbyModeCard(
        title = "دو/چند نفره آفلاین (یک گوشی)",
        subtitle = "بازی نوبتی در کنار دوستان بدون نیاز به اینترنت",
        icon = BaziIcons.Groups,
        accent = CyberGold,
        testTag = "mode_pass_play",
        onClick = { onStartMode(PlayMode.LOCAL_PASS_AND_PLAY, selectedPlayers) },
      )

      GlassGradientCard(accentColor = VioletPulse, cornerRadius = 18.dp) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(BaziIcons.PublicGlobe, contentDescription = null, tint = VioletPulse)
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "بازی آنلاین با دوستان",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
              )
              Text(
                text =
                  if (isServerConnected) "اتصال زنده آنلاین آماده است"
                  else "پیش‌نمایش اتاق دوستان",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
              )
            }
          }

          Button(
            onClick = onCreateOnlineRoom,
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("create_online_room_button"),
            colors = ButtonDefaults.buttonColors(containerColor = VioletPulse),
            shape = RoundedCornerShape(12.dp),
          ) {
            Text("ساخت اتاق جدید و دریافت کد دعوت", fontWeight = FontWeight.Bold)
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            OutlinedTextField(
              value = roomCodeInput,
              onValueChange = { roomCodeInput = it.uppercase().take(16) },
              placeholder = { Text("کد اتاق (مثلاً BZ1A2B)") },
              singleLine = true,
              modifier = Modifier.weight(1f).testTag("join_room_code_input"),
              colors =
                OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = NeonCyan,
                  unfocusedBorderColor = ElevatedCardStroke,
                  focusedContainerColor = ObsidianBg,
                  unfocusedContainerColor = ObsidianBg,
                ),
              shape = RoundedCornerShape(12.dp),
            )
            OutlinedButton(
              onClick = { if (roomCodeInput.isNotBlank()) onJoinOnlineRoom(roomCodeInput) },
              modifier = Modifier.height(52.dp).testTag("join_online_room_button"),
              border = BorderStroke(1.dp, NeonCyan),
              shape = RoundedCornerShape(12.dp),
            ) {
              Text("ورود", color = NeonCyan, fontWeight = FontWeight.Bold)
            }
          }

          if (!statusMessage.isNullOrBlank()) {
            Text(
              text = statusMessage,
              style = MaterialTheme.typography.bodyMedium,
              color = CyberGold,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun LobbyModeCard(
  title: String,
  subtitle: String,
  icon: ImageVector,
  accent: Color,
  testTag: String,
  onClick: () -> Unit,
) {
  GlassGradientCard(
    accentColor = accent,
    cornerRadius = 16.dp,
    onClick = onClick,
    modifier = Modifier.fillMaxWidth().testTag(testTag),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Box(
        modifier =
          Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(accent.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(24.dp))
      }
      Column(modifier = Modifier.weight(1f)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
      }
    }
  }
}

@Composable
fun WinCelebrationBanner(
  winnerTitle: String,
  subtitle: String,
  accent: Color,
  onRematch: () -> Unit,
  onExit: () -> Unit,
) {
  GlassGradientCard(
    modifier = Modifier.fillMaxWidth(),
    accentColor = accent,
    cornerRadius = 22.dp,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(18.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
        imageVector = BaziIcons.Crown,
        contentDescription = null,
        tint = CyberGold,
        modifier = Modifier.size(42.dp),
      )
      Text(winnerTitle, style = MaterialTheme.typography.headlineSmall, color = accent)
      Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
      Row(
        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Button(
          onClick = onRematch,
          modifier = Modifier.weight(1f).height(48.dp).testTag("rematch_button"),
          colors = ButtonDefaults.buttonColors(containerColor = accent),
          shape = RoundedCornerShape(12.dp),
        ) {
          Text("بازی مجدد", color = ObsidianBg, fontWeight = FontWeight.Bold)
        }
        OutlinedButton(
          onClick = onExit,
          modifier = Modifier.weight(1f).height(48.dp).testTag("exit_after_win_button"),
          border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
          shape = RoundedCornerShape(12.dp),
        ) {
          Text("خروج", color = TextPrimary)
        }
      }
    }
  }
}

@Composable
fun SecurityShieldBadge(label: String, modifier: Modifier = Modifier) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(10.dp),
    color = ElectricEmerald.copy(alpha = 0.12f),
    border = BorderStroke(1.dp, ElectricEmerald.copy(alpha = 0.35f)),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Icon(Icons.Rounded.Lock, contentDescription = null, tint = ElectricEmerald, modifier = Modifier.size(14.dp))
      Text(label, style = MaterialTheme.typography.labelSmall, color = ElectricEmerald)
    }
  }
}
