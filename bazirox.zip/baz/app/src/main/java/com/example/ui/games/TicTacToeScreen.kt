package com.example.ui.games

import com.example.ui.components.pressScale
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.GameType
import com.example.data.OnlineRoom
import com.example.data.PlayMode
import com.example.data.Sfx
import com.example.data.SoundManager
import com.example.ui.components.GameTopBar
import com.example.ui.components.LocalGameHud
import com.example.ui.components.PublishRoomHud
import com.example.ui.components.GameArea
import com.example.ui.components.GameTurnTimer
import com.example.ui.components.rememberTurnCountdown
import com.example.ui.components.fitBoard
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.WinCelebrationBanner
import com.example.ui.components.oceanGameBackdrop
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPulse
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

private val WinLines =
  listOf(
    listOf(0, 1, 2),
    listOf(3, 4, 5),
    listOf(6, 7, 8),
    listOf(0, 3, 6),
    listOf(1, 4, 7),
    listOf(2, 5, 8),
    listOf(0, 4, 8),
    listOf(2, 4, 6),
  )

@Composable
fun TicTacToeScreen(
  playMode: PlayMode,
  room: OnlineRoom?,
  currentUsername: String,
  onPushOnlineState: (String, String) -> Unit,
  onRecordResult: (Boolean, Int) -> Unit,
  onBack: () -> Unit,
) {
  BackHandler(onBack = onBack)

  var board by remember { mutableStateOf(List(9) { 0 }) } // 0=empty, 1=X, 2=O
  var currentTurn by remember { mutableIntStateOf(1) }
  var winner by remember { mutableIntStateOf(0) } // 0=ongoing, 1=X, 2=O, 3=draw
  var winningLine by remember { mutableStateOf<List<Int>?>(null) }
  var scoreX by remember { mutableIntStateOf(0) }
  var scoreO by remember { mutableIntStateOf(0) }
  var aiHardMode by remember { mutableStateOf(true) }
  var recordedThisRound by remember { mutableStateOf(false) }

  val myOnlineSide =
    remember(room, currentUsername) {
      if (room == null) 1
      else if (room.hostUsername.equals(currentUsername, ignoreCase = true)) 1 else 2
    }

  LaunchedEffect(room?.version, room?.stateJson) {
    if (playMode == PlayMode.ONLINE_ROOM && room != null && room.stateJson.length > 4) {
      try {
        val j = JSONObject(room.stateJson)
        val arr = j.optJSONArray("board")
        if (arr != null && arr.length() == 9) {
          board = List(9) { idx -> arr.getInt(idx) }
          currentTurn = j.optInt("turn", 1)
          val res = checkTttWinner(board)
          winner = res.first
          winningLine = res.second
        }
      } catch (_: Throwable) {}
    }
  }

  fun resetRound() {
    board = List(9) { 0 }
    currentTurn = 1
    winner = 0
    winningLine = null
    recordedThisRound = false
    if (playMode == PlayMode.ONLINE_ROOM && room != null) {
      val j = JSONObject().apply {
        put("board", JSONArray(board))
        put("turn", 1)
      }
      onPushOnlineState(j.toString(), "playing")
    }
  }

  fun makeMove(index: Int) {
    if (board[index] != 0 || winner != 0) return
    if (playMode == PlayMode.VS_AI && currentTurn != 1) return
    if (playMode == PlayMode.ONLINE_ROOM && currentTurn != myOnlineSide) return

    val next = board.toMutableList()
    next[index] = currentTurn
    board = next
    val (win, line) = checkTttWinner(next)
    winner = win
    winningLine = line
    if (win == 1) scoreX++ else if (win == 2) scoreO++
    val nextTurn = if (currentTurn == 1) 2 else 1
    if (win == 0) currentTurn = nextTurn

    if (playMode == PlayMode.ONLINE_ROOM && room != null) {
      val j = JSONObject().apply {
        put("board", JSONArray(next))
        put("turn", nextTurn)
      }
      onPushOnlineState(j.toString(), if (win == 0) "playing" else "finished")
    }
  }

  LaunchedEffect(board, currentTurn, winner, playMode) {
    if (playMode == PlayMode.VS_AI && currentTurn == 2 && winner == 0) {
      delay(340)
      val aiIndex = pickTttAiMove(board, hard = aiHardMode)
      if (aiIndex >= 0 && board[aiIndex] == 0) {
        val next = board.toMutableList()
        next[aiIndex] = 2
        board = next
        val (win, line) = checkTttWinner(next)
        winner = win
        winningLine = line
        if (win == 2) scoreO++
        if (win == 0) currentTurn = 1
      }
    }
  }

  // Sound: one tap per newly placed mark (covers me, the AI and online opponents).
  var lastFilled by remember { mutableIntStateOf(0) }
  LaunchedEffect(board) {
    val filled = board.count { it != 0 }
    if (filled > lastFilled) SoundManager.play(Sfx.TAP)
    lastFilled = filled
  }

  var resultSoundPlayed by remember { mutableStateOf(false) }
  LaunchedEffect(winner) {
    if (winner == 0) {
      resultSoundPlayed = false
    } else if (!resultSoundPlayed) {
      resultSoundPlayed = true
      val mySide = if (playMode == PlayMode.ONLINE_ROOM) myOnlineSide else 1
      delay(180)
      SoundManager.play(
        when (winner) {
          3 -> Sfx.DRAW
          mySide -> Sfx.WIN
          else -> Sfx.LOSE
        }
      )
    }
  }

  LaunchedEffect(winner) {
    if (winner != 0 && !recordedThisRound) {
      recordedThisRound = true
      when (winner) {
        1 -> onRecordResult(true, 25)
        2 -> onRecordResult(false, 5)
        3 -> onRecordResult(false, 10)
      }
    }
  }

  val winLineProgress by
    animateFloatAsState(
      targetValue = if (winningLine != null) 1f else 0f,
      animationSpec = tween(360, easing = FastOutSlowInEasing),
      label = "ttt_win_line",
    )

  val turnGlowColor = if (currentTurn == 1) NeonCyan else CrimsonMagenta
  val canHumanTap =
    winner == 0 &&
      (playMode != PlayMode.VS_AI || currentTurn == 1) &&
      (playMode != PlayMode.ONLINE_ROOM || currentTurn == myOnlineSide)

  Column(
    modifier =
      Modifier.fillMaxSize()
        .oceanGameBackdrop(turnGlowColor)
        .systemBarsPadding(),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    val turnLeft =
      rememberTurnCountdown(key = listOf(currentTurn, winner, board.count { it != 0 }), running = winner == 0) {
        if (canHumanTap) {
          val empty = board.indices.filter { board[it] == 0 }
          if (empty.isNotEmpty()) makeMove(empty.random())
        }
      }
    GameTopBar(
      title = GameType.TIC_TAC_TOE.titleFa,
      subtitle =
        when (playMode) {
          PlayMode.VS_AI -> if (aiHardMode) "در برابر هوش مصنوعی (حرفه‌ای)" else "در برابر هوش مصنوعی (آسان)"
          PlayMode.LOCAL_PASS_AND_PLAY -> "دو نفره آفلاین"
          PlayMode.ONLINE_ROOM -> "اتاق آنلاین: ${room?.roomCode ?: "-"}"
        },
      accentColor = NeonCyan,
      onBack = onBack,
      copyText = if (playMode == PlayMode.ONLINE_ROOM) room?.roomCode else null,
      trailingContent = {
        IconButton(onClick = { resetRound() }, modifier = Modifier.testTag("ttt_reset_button")) {
          Icon(Icons.Rounded.Refresh, contentDescription = "شروع مجدد", tint = NeonCyan)
        }
      },
    )

    val hudOn = LocalGameHud.current != null
    PublishRoomHud(
      room = room,
      activeSeat = if (winner == 0) currentTurn - 1 else -1,
      scores = listOf(scoreX.toString(), scoreO.toString()),
    )
    GameArea(maxWidth = 560.dp) {
      GameTurnTimer(turnLeft, turnGlowColor, active = winner == 0)
      if (!hudOn) Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        ScoreCard(
          label = if (playMode == PlayMode.VS_AI) "شما (X)" else "بازیکن ۱ (X)",
          score = scoreX,
          isActive = winner == 0 && currentTurn == 1,
          accent = NeonCyan,
          modifier = Modifier.weight(1f),
        )
        ScoreCard(
          label = if (playMode == PlayMode.VS_AI) "ربات (O)" else "بازیکن ۲ (O)",
          score = scoreO,
          isActive = winner == 0 && currentTurn == 2,
          accent = CrimsonMagenta,
          modifier = Modifier.weight(1f),
        )
      }

      if (playMode == PlayMode.VS_AI) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("سطح ربات:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
          listOf(false to "آسان", true to "حرفه‌ای").forEach { (hard, label) ->
            val selected = aiHardMode == hard
            Surface(
              onClick = {
                aiHardMode = hard
                resetRound()
              },
              shape = RoundedCornerShape(10.dp),
              color = if (selected) NeonCyan.copy(alpha = 0.2f) else ElevatedCard.copy(alpha = 0.7f),
              border = BorderStroke(1.dp, if (selected) NeonCyan else ElevatedCardStroke),
            ) {
              Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                color = if (selected) NeonCyan else TextSecondary,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp),
              )
            }
          }
        }
      }

      // 3x3 Frosted Glass Board
      GlassGradientCard(
        modifier = Modifier.fitBoard(232.dp),
        accentColor = turnGlowColor,
        cornerRadius = 22.dp,
      ) {
        Box(modifier = Modifier.fillMaxSize().padding(14.dp)) {
          Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            for (r in 0..2) {
              Row(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                for (c in 0..2) {
                  val idx = r * 3 + c
                  val cell = board[idx]
                  val isWinCell = winningLine?.contains(idx) == true
                  TttCell(
                    value = cell,
                    isWinning = isWinCell,
                    enabled = cell == 0 && canHumanTap,
                    modifier =
                      Modifier.weight(1f).fillMaxSize().graphicsLayer {
                        alpha = if (winningLine != null && !isWinCell) 0.4f else 1f
                      }.testTag("ttt_cell_$idx"),
                    onClick = { makeMove(idx) },
                  )
                }
              }
            }
          }

          winningLine?.let { line ->
            Canvas(modifier = Modifier.fillMaxSize()) {
              val startCell = line.first()
              val endCell = line.last()
              // Must match the cell Row/Column layout: 10.dp gaps between cells, and the
              // columns are mirrored when the layout direction is RTL (Persian UI).
              val gap = 10.dp.toPx()
              val cellW = (size.width - gap * 2f) / 3f
              val cellH = (size.height - gap * 2f) / 3f
              val rtl = layoutDirection == androidx.compose.ui.unit.LayoutDirection.Rtl
              fun cx(cell: Int): Float {
                val col = if (rtl) 2 - cell % 3 else cell % 3
                return col * (cellW + gap) + cellW / 2f
              }
              fun cy(cell: Int): Float = (cell / 3) * (cellH + gap) + cellH / 2f
              val sx = cx(startCell)
              val sy = cy(startCell)
              val ex = cx(endCell)
              val ey = cy(endCell)
              val curX = sx + (ex - sx) * winLineProgress
              val curY = sy + (ey - sy) * winLineProgress
              drawLine(
                color = CyberGold.copy(alpha = 0.38f),
                start = Offset(sx, sy),
                end = Offset(curX, curY),
                strokeWidth = 24f,
                cap = StrokeCap.Round,
              )
              drawLine(
                color = CyberGold,
                start = Offset(sx, sy),
                end = Offset(curX, curY),
                strokeWidth = 9f,
                cap = StrokeCap.Round,
              )
              drawCircle(color = Color.White, radius = 9f, center = Offset(sx, sy))
              drawCircle(color = Color.White, radius = 9f, center = Offset(curX, curY))
            }
          }
        }
      }

      if (winner != 0) {
        val title =
          when (winner) {
            1 -> "برنده: X!"
            2 -> if (playMode == PlayMode.VS_AI) "ربات برنده شد!" else "برنده: O!"
            else -> "مساوی!"
          }
        val sub =
          when (winner) {
            1 -> "۲۵ امتیاز به پروفایل شما اضافه شد"
            3 -> "بازی نزدیک و نفس‌گیر! ۱۰ امتیاز مشارکت"
            else -> "۵ امتیاز تلاش ثبت شد"
          }
        WinCelebrationBanner(
          winnerTitle = title,
          subtitle = sub,
          accent = if (winner == 1) NeonCyan else if (winner == 2) CrimsonMagenta else CyberGold,
          onRematch = { resetRound() },
          onExit = onBack,
        )
      } else if (!hudOn) {
        GlassGradientCard(accentColor = turnGlowColor, cornerRadius = 14.dp, modifier = Modifier.fillMaxWidth()) {
          Box(
            modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp),
            contentAlignment = Alignment.Center,
          ) {
            Text(
              text =
                if (playMode == PlayMode.ONLINE_ROOM && currentTurn != myOnlineSide)
                  "نوبت حریف آنلاین..."
                else if (playMode == PlayMode.VS_AI && currentTurn == 2) "ربات در حال فکر کردن..."
                else if (currentTurn == 1) "نوبت بازیکن X" else "نوبت بازیکن O",
              style = MaterialTheme.typography.titleMedium,
              color = turnGlowColor,
            )
          }
        }
      }

    }
  }
}

@Composable
private fun TttCell(
  value: Int,
  isWinning: Boolean,
  enabled: Boolean,
  modifier: Modifier = Modifier,
  onClick: () -> Unit,
) {
  val src = remember { MutableInteractionSource() }
  val anim = remember { Animatable(0f) }
  LaunchedEffect(value) {
    if (value != 0) {
      anim.snapTo(0f)
      anim.animateTo(1f, animationSpec = tween(220, easing = FastOutSlowInEasing))
    } else {
      anim.snapTo(0f)
    }
  }

  val borderColor =
    when {
      isWinning -> CyberGold
      value == 1 -> NeonCyan.copy(alpha = 0.65f)
      value == 2 -> CrimsonMagenta.copy(alpha = 0.65f)
      else -> Color.White.copy(alpha = 0.16f)
    }
  val fillBrush =
    when {
      isWinning -> Brush.linearGradient(listOf(CyberGold.copy(alpha = 0.24f), Color(0xAA1B2540)))
      value == 1 -> Brush.linearGradient(listOf(NeonCyan.copy(alpha = 0.14f), Color(0xCC1B2540)))
      value == 2 -> Brush.linearGradient(listOf(CrimsonMagenta.copy(alpha = 0.14f), Color(0xCC1B2540)))
      else -> Brush.linearGradient(listOf(Color(0x9924304F), Color(0x991B2540)))
    }

  Box(
    modifier =
      modifier
        .pressScale(src, 0.92f)
        .clip(RoundedCornerShape(18.dp))
        .background(fillBrush)
        .border(1.4.dp, borderColor, RoundedCornerShape(18.dp))
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick),
    contentAlignment = Alignment.Center,
  ) {
    if (value != 0) {
      Canvas(
        modifier =
          Modifier.fillMaxSize().padding(18.dp).graphicsLayer {
            val sc = 0.78f + 0.22f * anim.value
            scaleX = sc
            scaleY = sc
          }
      ) {
        val p = anim.value
        val stroke = 13f
        val glowStroke = 26f
        if (value == 1) {
          val p1 = (p * 2f).coerceIn(0f, 1f)
          val p2 = ((p - 0.4f) * 2f).coerceIn(0f, 1f)
          drawLine(
            color = NeonCyan.copy(alpha = 0.32f),
            start = Offset(0f, 0f),
            end = Offset(size.width * p1, size.height * p1),
            strokeWidth = glowStroke,
            cap = StrokeCap.Round,
          )
          drawLine(
            color = NeonCyan,
            start = Offset(0f, 0f),
            end = Offset(size.width * p1, size.height * p1),
            strokeWidth = stroke,
            cap = StrokeCap.Round,
          )
          if (p2 > 0f) {
            drawLine(
              color = NeonCyan.copy(alpha = 0.32f),
              start = Offset(size.width, 0f),
              end = Offset(size.width - size.width * p2, size.height * p2),
              strokeWidth = glowStroke,
              cap = StrokeCap.Round,
            )
            drawLine(
              color = NeonCyan,
              start = Offset(size.width, 0f),
              end = Offset(size.width - size.width * p2, size.height * p2),
              strokeWidth = stroke,
              cap = StrokeCap.Round,
            )
          }
        } else {
          drawArc(
            color = CrimsonMagenta.copy(alpha = 0.32f),
            startAngle = -90f,
            sweepAngle = 360f * p,
            useCenter = false,
            style = Stroke(width = glowStroke, cap = StrokeCap.Round),
          )
          drawArc(
            color = CrimsonMagenta,
            startAngle = -90f,
            sweepAngle = 360f * p,
            useCenter = false,
            style = Stroke(width = stroke, cap = StrokeCap.Round),
          )
        }
      }
    }
  }
}

@Composable
private fun ScoreCard(
  label: String,
  score: Int,
  isActive: Boolean,
  accent: Color,
  modifier: Modifier = Modifier,
) {
  GlassGradientCard(
    modifier = modifier,
    accentColor = if (isActive) accent else Color.White.copy(alpha = 0.14f),
    cornerRadius = 18.dp,
  ) {
    Row(
      modifier =
        Modifier.fillMaxWidth()
          .background(if (isActive) accent.copy(alpha = 0.14f) else Color.Transparent)
          .padding(horizontal = 14.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(label, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
      Text(
        score.toString(),
        style = MaterialTheme.typography.headlineSmall,
        color = accent,
        fontWeight = FontWeight.ExtraBold,
      )
    }
  }
}

private fun checkTttWinner(board: List<Int>): Pair<Int, List<Int>?> {
  for (line in WinLines) {
    val a = board[line[0]]
    if (a != 0 && a == board[line[1]] && a == board[line[2]]) {
      return a to line
    }
  }
  return if (board.none { it == 0 }) 3 to null else 0 to null
}

private fun pickTttAiMove(board: List<Int>, hard: Boolean): Int {
  val empty = board.indices.filter { board[it] == 0 }
  if (empty.isEmpty()) return -1
  if (!hard && Math.random() < 0.45) return empty.random()
  var bestScore = Int.MIN_VALUE
  var bestMove = empty.first()
  val mutable = board.toMutableList()
  for (idx in empty) {
    mutable[idx] = 2
    val score = minimaxTtt(mutable, 0, false)
    mutable[idx] = 0
    if (score > bestScore) {
      bestScore = score
      bestMove = idx
    }
  }
  return bestMove
}

private fun minimaxTtt(board: MutableList<Int>, depth: Int, isMax: Boolean): Int {
  val (win, _) = checkTttWinner(board)
  if (win == 2) return 10 - depth
  if (win == 1) return depth - 10
  if (win == 3) return 0

  var best = if (isMax) Int.MIN_VALUE else Int.MAX_VALUE
  for (i in 0..8) {
    if (board[i] == 0) {
      board[i] = if (isMax) 2 else 1
      val score = minimaxTtt(board, depth + 1, !isMax)
      board[i] = 0
      best = if (isMax) maxOf(best, score) else minOf(best, score)
    }
  }
  return best
}
