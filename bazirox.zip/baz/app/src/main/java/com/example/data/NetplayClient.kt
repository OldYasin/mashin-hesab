package com.example.data

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import java.util.zip.DeflaterOutputStream
import java.util.zip.InflaterInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import org.json.JSONObject

/**
 * Two-player relay client for the Cloudflare Worker (see netplay-worker/worker.js).
 * Sends key presses and (host only) compressed save-states; all callbacks run on the main thread.
 */
class NetplayClient(
  baseUrl: String,
  val room: String,
  @Volatile var romKey: String,
  @Volatile var listener: Listener,
) {
  interface Listener {
    fun onHello(slot: Int, peers: Int)

    fun onPeer(on: Boolean)

    fun onKey(code: Int, down: Boolean)

    fun onState(bytes: ByteArray)

    fun onRomMismatch()

    /** The other player has the same game as me. */
    fun onRomOk() {}

    /** Round trip to the relay server itself (needs the updated worker). */
    fun onServerPing(rttMs: Long) {}

    /** Save/load requests and results between the two players (save, load, saved, loaded, ...). */
    fun onCmd(action: String)

    fun onPing(rttMs: Long)

    fun onClosed(reason: String)
  }

  private val main = Handler(Looper.getMainLooper())
  private val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()

  @Volatile private var ws: WebSocket? = null

  @Volatile private var closed = false

  /** Measured one-way latency (ms), clamped to 15..100: used as the input delay on both sides. */
  @Volatile
  var oneWayMs: Long = 50L
    private set

  @Volatile private var t0 = 0L

  /** Time from connect() until the server said hello (ms); 0 until connected. */
  @Volatile
  var connectMs: Long = 0L
    private set

  private val wsUrl: String = normalize(baseUrl) + "/ws?room=" + room

  private fun normalize(u: String): String {
    val s = u.trim().trimEnd('/')
    return when {
      s.startsWith("https://") -> "wss://" + s.removePrefix("https://")
      s.startsWith("http://") -> "ws://" + s.removePrefix("http://")
      s.startsWith("wss://") || s.startsWith("ws://") -> s
      else -> "wss://$s"
    }
  }

  fun connect() {
    t0 = SystemClock.elapsedRealtime()
    ws =
      http.newWebSocket(
        Request.Builder().url(wsUrl).build(),
        object : WebSocketListener() {
          override fun onMessage(webSocket: WebSocket, text: String) {
            handleText(text)
          }

          override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            try {
              val raw = inflate(bytes.toByteArray())
              main.post { if (!closed) listener.onState(raw) }
            } catch (_: Throwable) {}
          }

          override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            fail("اتصال بسته شد")
          }

          override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            fail(if (response?.code == 409) "اتاق پر است" else "اتصال به سرور ناموفق بود")
          }
        },
      )
    main.postDelayed(pinger, 300)
  }

  private fun fail(reason: String) {
    if (closed) return
    closed = true
    main.removeCallbacks(pinger)
    main.post { listener.onClosed(reason) }
  }

  private fun handleText(text: String) {
    try {
      val j = JSONObject(text)
      when (j.optString("t")) {
        "hello" -> {
          connectMs = SystemClock.elapsedRealtime() - t0
          val slot = j.optInt("slot")
          val peers = j.optInt("peers")
          main.post { if (!closed) listener.onHello(slot, peers) }
        }
        "peer" -> {
          val on = j.optInt("on") == 1
          main.post { if (!closed) listener.onPeer(on) }
        }
        "k" -> {
          val c = j.optInt("c")
          val d = j.optInt("d") == 1
          main.post { if (!closed) listener.onKey(c, d) }
        }
        "p" -> ws?.send("""{"t":"q","ts":${j.optLong("ts")}}""")
        "s" -> {
          val rtt = SystemClock.elapsedRealtime() - j.optLong("ts")
          main.post { if (!closed) listener.onServerPing(rtt) }
        }
        "q" -> {
          val rtt = SystemClock.elapsedRealtime() - j.optLong("ts")
          val ow = (rtt / 2).coerceIn(15L, 100L)
          oneWayMs = (oneWayMs + ow) / 2
          main.post { if (!closed) listener.onPing(rtt) }
        }
        "cmd" -> {
          val a = j.optString("a")
          main.post { if (!closed) listener.onCmd(a) }
        }
        "r" ->
          if (romKey.isNotEmpty()) {
            // (I have no game yet -> ignore; the friend's check happens when I pick one.)
            if (j.optString("k") != romKey) main.post { if (!closed) listener.onRomMismatch() }
            else main.post { if (!closed) listener.onRomOk() }
            if (!j.optBoolean("re")) sendRom(true) // answer once so the sender gets my game too
          }
      }
    } catch (_: Throwable) {}
  }

  private val pinger =
    object : Runnable {
      override fun run() {
        if (closed) return
        ws?.send("""{"t":"p","ts":${SystemClock.elapsedRealtime()}}""")
        main.postDelayed(this, 1000)
      }
    }

  fun sendKey(code: Int, down: Boolean) {
    ws?.send("""{"t":"k","c":$code,"d":${if (down) 1 else 0}}""")
  }

  fun sendCmd(action: String) {
    ws?.send("""{"t":"cmd","a":"$action"}""")
  }

  fun sendRom(reply: Boolean = false) {
    if (romKey.isEmpty()) return
    ws?.send("""{"t":"r","k":"$romKey"${if (reply) ""","re":true""" else ""}}""")
  }

  fun sendState(raw: ByteArray) {
    ws?.send(deflate(raw).toByteString())
  }

  fun close() {
    closed = true
    main.removeCallbacks(pinger)
    try {
      ws?.close(1000, "bye")
    } catch (_: Throwable) {}
    http.dispatcher.executorService.shutdown()
  }

  private fun deflate(b: ByteArray): ByteArray {
    val o = ByteArrayOutputStream()
    DeflaterOutputStream(o).use { it.write(b) }
    return o.toByteArray()
  }

  private fun inflate(b: ByteArray): ByteArray = InflaterInputStream(ByteArrayInputStream(b)).use { it.readBytes() }
}

/**
 * Measures the relay regions. The first letter of a room code tells the worker where to place the
 * room (see worker.js: M = Middle East, W = Western Europe, E = Eastern Europe).
 */
object NetplayProbe {
  /** ms = median round trip, jitterMs = average change between samples, lossPct = failed requests. */
  class Result(val letter: Char, val name: String, val ms: Long?, val jitterMs: Long, val lossPct: Int) {
    /** Lower is better: latency plus a heavy penalty for instability and loss. */
    val score: Long get() = if (ms == null) Long.MAX_VALUE else ms + jitterMs * 3 + lossPct * 8L
  }

  private val regions = listOf('M' to "خاورمیانه", 'W' to "اروپای غربی", 'E' to "اروپای شرقی")
  private val keys = mapOf('M' to "me", 'W' to "weur", 'E' to "eeur")
  private const val SAMPLES = 8

  fun regionName(code: String): String? = regions.firstOrNull { it.first == code.firstOrNull() }?.second

  /** Latency + stability of every region. Run off the main thread (takes a few seconds). */
  suspend fun measure(baseUrl: String): List<Result> =
    withContext(Dispatchers.IO) {
      val base = baseUrl.trim().trimEnd('/')
      val client =
        OkHttpClient.Builder()
          .connectTimeout(4, TimeUnit.SECONDS)
          .readTimeout(3, TimeUnit.SECONDS)
          .build() // one client = one kept-alive connection, so we measure the round trip, not TLS setup

      fun hit(letter: Char): Long? {
        val t0 = SystemClock.elapsedRealtime()
        return try {
          val req = Request.Builder().url("$base/probe?r=${keys[letter]}&n=${System.nanoTime()}").build()
          client.newCall(req).execute().use { if (!it.isSuccessful) return null }
          SystemClock.elapsedRealtime() - t0
        } catch (_: Throwable) {
          null
        }
      }

      hit('M') // open the connection (not counted)
      regions.map { (letter, name) ->
        hit(letter) // wake the room object in that region (not counted)
        val samples = (1..SAMPLES).map { hit(letter) }
        val ok = samples.filterNotNull()
        val median = ok.sorted().getOrNull(ok.size / 2)
        val jitter = if (ok.size < 2) 0L else ok.zipWithNext { a, b -> kotlin.math.abs(a - b) }.average().toLong()
        val loss = (samples.size - ok.size) * 100 / samples.size
        Result(letter, name, median, jitter, loss)
      }
    }

  /** The most stable region (best score), or null if none answered. */
  fun best(results: List<Result>): Result? = results.filter { it.ms != null }.minByOrNull { it.score }
}
