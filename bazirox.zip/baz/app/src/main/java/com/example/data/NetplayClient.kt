package com.example.data

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import java.util.zip.DeflaterOutputStream
import java.util.zip.InflaterInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import org.json.JSONObject

/**
 * Two-player relay client for the Cloudflare Worker (see netplay-worker/worker.js).
 * Sends key presses and (host only) compressed save-states; all callbacks run on the main thread.
 */
class NetplayClient(
  baseUrl: String,
  val room: String,
  @Volatile var romKey: String,
  @Volatile var listener: Listener,
) {
  interface Listener {
    fun onHello(slot: Int, peers: Int)

    fun onPeer(on: Boolean)

    fun onKey(code: Int, down: Boolean)

    fun onState(bytes: ByteArray)

    fun onRomMismatch()

    /** The other player has the same game as me. */
    fun onRomOk() {}

    /** Round trip to the relay server itself (needs the updated worker). */
    fun onServerPing(rttMs: Long) {}

    /** Save/load requests and results between the two players (save, load, saved, loaded, ...). */
    fun onCmd(action: String)

    fun onPing(rttMs: Long)

    /** A chat message from the other player. */
    fun onChat(text: String) {}

    /** The other player's display name. */
    fun onPeerName(name: String) {}

    fun onClosed(reason: String)
  }

  private val main = Handler(Looper.getMainLooper())
  private val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()

  @Volatile private var ws: WebSocket? = null

  @Volatile private var closed = false

  /** Measured one-way latency (ms), clamped to 15..100: used as the input delay on both sides. */
  @Volatile
  var oneWayMs: Long = 50L
    private set

  @Volatile private var t0 = 0L

  /** Time from connect() until the server said hello (ms); 0 until connected. */
  @Volatile
  var connectMs: Long = 0L
    private set

  private val wsUrl: String = normalize(baseUrl) + "/ws?room=" + room

  private fun normalize(u: String): String {
    val s = u.trim().trimEnd('/')
    return when {
      s.startsWith("https://") -> "wss://" + s.removePrefix("https://")
      s.startsWith("http://") -> "ws://" + s.removePrefix("http://")
      s.startsWith("wss://") || s.startsWith("ws://") -> s
      else -> "wss://$s"
    }
  }

  fun connect() {
    t0 = SystemClock.elapsedRealtime()
    ws =
      http.newWebSocket(
        Request.Builder().url(wsUrl).build(),
        object : WebSocketListener() {
          override fun onMessage(webSocket: WebSocket, text: String) {
            handleText(text)
          }

          override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            try {
              val raw = inflate(bytes.toByteArray())
              main.post { if (!closed) listener.onState(raw) }
            } catch (_: Throwable) {}
          }

          override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            fail("اتصال بسته شد")
          }

          override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            fail(if (response?.code == 409) "سشن پر است" else "اتصال به سرور ناموفق بود")
          }
        },
      )
    main.postDelayed(pinger, 300)
  }

  private fun fail(reason: String) {
    if (closed) return
    closed = true
    main.removeCallbacks(pinger)
    main.post { listener.onClosed(reason) }
  }

  private fun handleText(text: String) {
    try {
      val j = JSONObject(text)
      when (j.optString("t")) {
        "hello" -> {
          connectMs = SystemClock.elapsedRealtime() - t0
          val slot = j.optInt("slot")
          val peers = j.optInt("peers")
          main.post { if (!closed) listener.onHello(slot, peers) }
        }
        "peer" -> {
          val on = j.optInt("on") == 1
          main.post { if (!closed) listener.onPeer(on) }
        }
        "k" -> {
          val c = j.optInt("c")
          val d = j.optInt("d") == 1
          main.post { if (!closed) listener.onKey(c, d) }
        }
        "p" -> ws?.send("""{"t":"q","ts":${j.optLong("ts")}}""")
        "s" -> {
          val rtt = SystemClock.elapsedRealtime() - j.optLong("ts")
          main.post { if (!closed) listener.onServerPing(rtt) }
        }
        "q" -> {
          val rtt = SystemClock.elapsedRealtime() - j.optLong("ts")
          val ow = (rtt / 2).coerceIn(15L, 100L)
          oneWayMs = (oneWayMs + ow) / 2
          main.post { if (!closed) listener.onPing(rtt) }
        }
        "nm" -> {
          val nm = j.optString("n")
          if (nm.isNotBlank()) main.post { if (!closed) listener.onPeerName(nm) }
        }
        "chat" -> {
          val m = j.optString("m")
          if (m.isNotBlank()) main.post { if (!closed) listener.onChat(m) }
        }
        "cmd" -> {
          val a = j.optString("a")
          main.post { if (!closed) listener.onCmd(a) }
        }
        "r" ->
          if (romKey.isNotEmpty()) {
            // (I have no game yet -> ignore; the friend's check happens when I pick one.)
            if (j.optString("k") != romKey) main.post { if (!closed) listener.onRomMismatch() }
            else main.post { if (!closed) listener.onRomOk() }
            if (!j.optBoolean("re")) sendRom(true) // answer once so the sender gets my game too
          }
      }
    } catch (_: Throwable) {}
  }

  private val pinger =
    object : Runnable {
      override fun run() {
        if (closed) return
        ws?.send("""{"t":"p","ts":${SystemClock.elapsedRealtime()}}""")
        main.postDelayed(this, 1000)
      }
    }

  fun sendKey(code: Int, down: Boolean) {
    ws?.send("""{"t":"k","c":$code,"d":${if (down) 1 else 0}}""")
  }

  fun sendCmd(action: String) {
    ws?.send("""{"t":"cmd","a":"$action"}""")
  }

  fun sendName(name: String) {
    ws?.send(JSONObject().put("t", "nm").put("n", name.take(20)).toString())
  }

  fun sendChat(text: String) {
    ws?.send(JSONObject().put("t", "chat").put("m", text.take(300)).toString())
  }

  fun sendRom(reply: Boolean = false) {
    if (romKey.isEmpty()) return
    ws?.send("""{"t":"r","k":"$romKey"${if (reply) ""","re":true""" else ""}}""")
  }

  fun sendState(raw: ByteArray) {
    ws?.send(deflate(raw).toByteString())
  }

  fun close() {
    closed = true
    main.removeCallbacks(pinger)
    try {
      ws?.close(1000, "bye")
    } catch (_: Throwable) {}
    http.dispatcher.executorService.shutdown()
  }

  private fun deflate(b: ByteArray): ByteArray {
    val o = ByteArrayOutputStream()
    DeflaterOutputStream(o).use { it.write(b) }
    return o.toByteArray()
  }

  private fun inflate(b: ByteArray): ByteArray = InflaterInputStream(ByteArrayInputStream(b)).use { it.readBytes() }
}

/**
 * Measures the relay regions. The first letter of a room code tells the worker where to place the
 * room (see worker.js: M = Middle East, W = Western Europe, E = Eastern Europe).
 */
object NetplayProbe {
  /** ms = median round trip, jitterMs = average change between samples, lossPct = failed requests. */
  class Result(val letter: Char, val name: String, val ms: Long?, val jitterMs: Long, val lossPct: Int) {
    /** Lower is better: latency plus a heavy penalty for instability and loss. */
    val score: Long get() = if (ms == null) Long.MAX_VALUE else ms + jitterMs * 3 + lossPct * 8L
  }

  // Middle East only. (Rooms whose code starts with another letter still connect: the worker routes by that letter.)
  private val regions = listOf('M' to "خاورمیانه")
  private val keys = mapOf('M' to "me")
  private const val SAMPLES = 3
  private const val WS_SAMPLES = 5

  fun regionName(code: String): String? = regions.firstOrNull { it.first == code.firstOrNull() }?.second

  /** The regions in display order (letter to name), so the UI can list them before any result arrives. */
  fun regionList(): List<Pair<Char, String>> = regions

  /**
   * Latency + stability of every region. All regions are measured in parallel and each result is
   * reported through [onResult] (on the main thread) the moment it is ready, so the list fills in
   * within a second or two instead of after one long sequential run.
   */
  suspend fun measure(baseUrl: String, onResult: (Result) -> Unit = {}): List<Result> =
    withContext(Dispatchers.IO) {
      val base = baseUrl.trim().trimEnd('/')
      kotlinx.coroutines.coroutineScope {
        regions.map { (letter, name) ->
          async {
            // Own client per region = own kept-alive connection, so samples measure the round
            // trip and not TLS setup.
            val client =
              OkHttpClient.Builder()
                .connectTimeout(3, TimeUnit.SECONDS)
                .readTimeout(2, TimeUnit.SECONDS)
                .build()

            fun hit(): Long? {
              val t0 = SystemClock.elapsedRealtime()
              return try {
                val req = Request.Builder().url("$base/probe?r=${keys[letter]}&n=${System.nanoTime()}").build()
                client.newCall(req).execute().use { if (!it.isSuccessful) return null }
                SystemClock.elapsedRealtime() - t0
              } catch (_: Throwable) {
                null
              }
            }

            // Real ping = WebSocket round trip, exactly what the room shows once it is created.
            // (The plain HTTP request is only a fallback: it carries extra Worker overhead and reads too high.)
            val samples: List<Long?> =
              wsRtts(base, letter, WS_SAMPLES) ?: run {
                hit() // open the connection + wake the room object (not counted)
                (1..SAMPLES).map { hit() }
              }
            val ok = samples.filterNotNull()
            val median = ok.sorted().getOrNull(ok.size / 2)
            val jitter = if (ok.size < 2) 0L else ok.zipWithNext { x, y -> kotlin.math.abs(x - y) }.average().toLong()
            val loss = (samples.size - ok.size) * 100 / samples.size
            val r = Result(letter, name, median, jitter, loss)
            withContext(Dispatchers.Main) { onResult(r) }
            r
          }
        }.awaitAll()
      }
    }

  /**
   * Opens a throw-away WebSocket to a random room of the region and times [n] ping/echo round trips
   * (the first one is a warm-up and not counted). null = the socket could not be used (caller falls back to HTTP).
   */
  private fun wsRtts(base: String, letter: Char, n: Int): List<Long?>? {
    val wsBase =
      when {
        base.startsWith("https://") -> "wss://" + base.removePrefix("https://")
        base.startsWith("http://") -> "ws://" + base.removePrefix("http://")
        else -> base
      }
    val chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
    val code = letter.toString() + (1..4).map { chars.random() }.joinToString("")
    val client = OkHttpClient.Builder().connectTimeout(4, TimeUnit.SECONDS).readTimeout(0, TimeUnit.MILLISECONDS).build()
    val opened = java.util.concurrent.CountDownLatch(1)
    val echoes = java.util.concurrent.LinkedBlockingQueue<Long>()
    val ok = java.util.concurrent.atomic.AtomicBoolean(false)
    val ws =
      client.newWebSocket(
        Request.Builder().url("$wsBase/ws?room=$code").build(),
        object : WebSocketListener() {
          override fun onOpen(webSocket: WebSocket, response: Response) {
            ok.set(true)
            opened.countDown()
          }

          override fun onMessage(webSocket: WebSocket, text: String) {
            try {
              val j = JSONObject(text)
              if (j.optString("t") == "s") echoes.offer(SystemClock.elapsedRealtime() - j.optLong("ts"))
            } catch (_: Throwable) {}
          }

          override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            opened.countDown()
          }
        },
      )
    return try {
      if (!opened.await(5, TimeUnit.SECONDS) || !ok.get()) return null
      val out = ArrayList<Long?>()
      var gotAny = false
      for (i in 0..n) {
        echoes.clear()
        ws.send("""{"t":"p","ts":${SystemClock.elapsedRealtime()}}""")
        val v = echoes.poll(1500, TimeUnit.MILLISECONDS)
        if (v != null) gotAny = true
        if (i > 0) out.add(v)
      }
      if (!gotAny) null else out
    } catch (_: Throwable) {
      null
    } finally {
      try {
        ws.close(1000, "probe")
      } catch (_: Throwable) {}
      client.dispatcher.executorService.shutdown()
    }
  }

  /** The most stable region (best score), or null if none answered. */
  fun best(results: List<Result>): Result? = results.filter { it.ms != null }.minByOrNull { it.score }
}
