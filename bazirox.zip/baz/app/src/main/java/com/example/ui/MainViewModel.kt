package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AdminAuthResult
import com.example.data.CPanelConfig
import com.example.data.ChatGroup
import com.example.data.UserProfile
import com.example.data.ChatImageUtils
import com.example.data.ChatMessage
import com.example.data.SendState
import com.example.data.GameInvite
import com.example.data.GameType
import com.example.data.JoinRequest
import com.example.data.JoinResult
import com.example.data.LeaderboardEntry
import com.example.data.MainRepository
import com.example.data.MainTab
import com.example.data.AvatarImage
import com.example.data.OnlineRoom
import com.example.data.RoomChatMessage
import com.example.data.RoomPlayerInfo
import com.example.data.PingResult
import com.example.data.PlayMode
import com.example.data.SecureVault
import com.example.data.UserAccount
import com.example.security.CryptoManager
import java.io.File
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class ActiveGameSession(
  val gameType: GameType,
  val playMode: PlayMode,
  val playerCount: Int = 2,
  val room: OnlineRoom? = null,
)

data class AppUiState(
  val activeTab: MainTab = MainTab.GAMES,
  val currentUser: UserAccount? = null,
  /** False until the saved login has been read from the encrypted vault (avoids a login-screen flash). */
  val sessionLoaded: Boolean = false,
  val authLoading: Boolean = false,
  val authError: String? = null,
  val cPanelConfig: CPanelConfig = CPanelConfig(),
  val pingLoading: Boolean = false,
  val pingResult: PingResult? = null,
  val showAdminPanel: Boolean = false,
  val lobbyGameType: GameType? = null,
  val activeGameSession: ActiveGameSession? = null,
  val leaderboard: List<LeaderboardEntry> = emptyList(),
  val leaderboardFilter: GameType? = null,
  val chatGroups: List<ChatGroup> = emptyList(),
  val selectedGroup: ChatGroup? = null,
  val chatMessages: List<ChatMessage> = emptyList(),
  val chatFeedback: String? = null,
  val chatReads: Map<String, Long> = emptyMap(),
  val chatDraftImage: String? = null,
  val chatReplyTo: ChatMessage? = null,
  val chatImageBusy: Boolean = false,
  val joinRequests: List<JoinRequest> = emptyList(),
  val roomStatusMessage: String? = null,
  /** Chat lines of the current online game room (empty for offline games). */
  val roomChat: List<RoomChatMessage> = emptyList(),
  /** Avatar info (display name + color) per username for the current online room. */
  val roomPlayers: Map<String, RoomPlayerInfo> = emptyMap(),
  /** True after the first server fetch of the room chat, so old history doesn't pop up as bubbles. */
  val roomChatReady: Boolean = false,
  /** Profile photos by lowercase username (own + players of the current room). */
  val avatars: Map<String, AvatarImage> = emptyMap(),
  /** Display names of chat senders by lowercase username (the server only sends usernames with messages). */
  val senderNames: Map<String, String> = emptyMap(),
  val profileBusy: Boolean = false,
  val profileMessage: String? = null,
  /** Public profile opened from a chat (viewedUser = who, viewedProfile = loaded data). */
  val viewedUser: String? = null,
  val viewedProfile: UserProfile? = null,
  val viewedProfileError: String? = null,
  val myBio: String = "",
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

  private val appContext = application.applicationContext
  private val repository =
    MainRepository(
      SecureVault(appContext),
      imageDir = File(appContext.filesDir, "chat_images"),
      avatarDir = File(appContext.filesDir, "avatars"),
    )

  private val _uiState = MutableStateFlow(AppUiState())
  val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()

  private var chatPollingJob: Job? = null
  private var roomPollingJob: Job? = null

  init {
    repository.setSessionExpiredListener {
      viewModelScope.launch {
        if (_uiState.value.currentUser != null) {
          logout()
          _uiState.update { it.copy(authError = "نشست شما منقضی شده است؛ دوباره وارد شوید") }
        }
      }
    }
    // Vault decryption (Android KeyStore) is slow on first use: do it off the main thread so
    // the first frame appears immediately instead of after a long blank screen.
    viewModelScope.launch {
      val (session, config) =
        withContext(kotlinx.coroutines.Dispatchers.IO) { repository.loadSession() to repository.loadConfig() }
      _uiState.update { it.copy(currentUser = session, cPanelConfig = config, sessionLoaded = true) }
      // A baked-in server must be checked automatically: "connected" used to be set only after
      // the admin pressed "test connection", so every fresh install showed "offline".
      if (config.apiBaseUrl.isNotBlank()) autoConnect(config)
      refreshLeaderboard()
      refreshGroups()
      session?.let { syncAvatarsFor(listOf(it.username)); loadMyBio() }
    }
  }

  private var autoConnectJob: Job? = null

  /** Pings the server now; while it is unreachable keeps retrying every 20s until it connects. */
  private fun autoConnect(initial: CPanelConfig) {
    autoConnectJob?.cancel()
    autoConnectJob =
      viewModelScope.launch {
        var config = initial
        while (isActive) {
          val res = withContext(kotlinx.coroutines.Dispatchers.IO) { repository.testCPanelConnection(config) }
          val reloaded = withContext(kotlinx.coroutines.Dispatchers.IO) { repository.loadConfig() }
          _uiState.update { it.copy(cPanelConfig = reloaded) }
          if (res.success) {
            refreshLeaderboard()
            refreshGroups()
            _uiState.value.currentUser?.let { syncAvatarsFor(listOf(it.username)); loadMyBio() }
            return@launch
          }
          delay(20_000)
          config = reloaded
        }
      }
  }

  fun selectTab(tab: MainTab) {
    _uiState.update { it.copy(activeTab = tab, authError = null, chatFeedback = null) }
    when (tab) {
      MainTab.LEADERBOARD -> refreshLeaderboard()
      MainTab.CHAT -> refreshGroups()
      else -> {}
    }
  }

  // --- Auth (Username + Password, or the device-local admin gate) ---

  /**
   * The admin gate lives only on this device: the first time, the password typed here becomes the
   * admin password (min 10 chars); afterwards it is verified with a slow hash and a lockout.
   * Nothing about it is stored inside the APK.
   */
  private fun tryAdminEntry(username: String, password: String): Boolean {
    if (!CryptoManager.isAdminTrigger(username)) return false
    viewModelScope.launch {
      _uiState.update { it.copy(authLoading = true, authError = null) }
      val res = withContext(Dispatchers.Default) { repository.adminAuth(password) }
      _uiState.update {
        when (res) {
          AdminAuthResult.Granted,
          AdminAuthResult.Created -> it.copy(authLoading = false, authError = null, showAdminPanel = true)
          is AdminAuthResult.Locked ->
            it.copy(
              authLoading = false,
              authError = "تلاش‌های ناموفق زیاد است؛ ${res.seconds} ثانیه دیگر دوباره امتحان کن",
            )
          AdminAuthResult.NoServer ->
            it.copy(authLoading = false, authError = "نام کاربری یا رمز عبور اشتباه است")
          else ->
            it.copy(authLoading = false, authError = "نام کاربری یا رمز عبور اشتباه است")
        }
      }
    }
    return true
  }

  fun login(username: String, password: String) {
    if (tryAdminEntry(username, password)) return
    viewModelScope.launch {
      _uiState.update { it.copy(authLoading = true, authError = null) }
      val result = repository.login(username, password)
      result.fold(
        onSuccess = { acc ->
          _uiState.update { it.copy(currentUser = acc, authLoading = false, authError = null) }
          refreshGroups()
          refreshLeaderboard()
          syncAvatarsFor(listOf(acc.username)); loadMyBio()
        },
        onFailure = { err ->
          _uiState.update {
            it.copy(authLoading = false, authError = err.message ?: "خطا در ورود")
          }
        },
      )
    }
  }

  fun register(username: String, password: String, displayName: String, avatarColorIndex: Int) {
    if (tryAdminEntry(username, password)) return
    viewModelScope.launch {
      _uiState.update { it.copy(authLoading = true, authError = null) }
      val result = repository.register(username, password, displayName, avatarColorIndex)
      result.fold(
        onSuccess = { acc ->
          _uiState.update { it.copy(currentUser = acc, authLoading = false, authError = null) }
          refreshGroups()
          refreshLeaderboard()
          syncAvatarsFor(listOf(acc.username)); loadMyBio()
        },
        onFailure = { err ->
          _uiState.update {
            it.copy(authLoading = false, authError = err.message ?: "خطا در ثبت‌نام")
          }
        },
      )
    }
  }

  fun logout() {
    chatPollingJob?.cancel()
    roomPollingJob?.cancel()
    repository.logout()
    _uiState.update {
      it.copy(
        currentUser = null,
        selectedGroup = null,
        activeGameSession = null,
        leaderboard = emptyList(),
        chatGroups = emptyList(),
        chatMessages = emptyList(),
        avatars = emptyMap(),
        senderNames = emptyMap(),
        myBio = "",
        viewedUser = null,
        viewedProfile = null,
        viewedProfileError = null,
        profileMessage = null,
        activeTab = MainTab.GAMES,
        authError = null,
      )
    }
  }

  // --- Admin Panel & cPanel Config ---

  fun closeAdminPanel() {
    _uiState.update { it.copy(showAdminPanel = false) }
  }

  fun saveCPanelConfig(config: CPanelConfig) {
    repository.saveConfig(config)
    _uiState.update { it.copy(cPanelConfig = config) }
  }

  fun testCPanelConnection(config: CPanelConfig) {
    viewModelScope.launch {
      _uiState.update { it.copy(pingLoading = true, pingResult = null) }
      repository.saveConfig(config)
      val res = repository.testCPanelConnection(config)
      val reloaded = repository.loadConfig()
      _uiState.update {
        it.copy(pingLoading = false, pingResult = res, cPanelConfig = reloaded)
      }
    }
  }

  // --- Games & Online Rooms ---

  fun openGameLobby(gameType: GameType) {
    _uiState.update { it.copy(lobbyGameType = gameType, roomStatusMessage = null) }
  }

  fun dismissGameLobby() {
    _uiState.update { it.copy(lobbyGameType = null, roomStatusMessage = null) }
  }

  fun startGame(gameType: GameType, mode: PlayMode, playerCount: Int = 2) {
    _uiState.update {
      it.copy(
        lobbyGameType = null,
        activeGameSession = ActiveGameSession(gameType, mode, playerCount, null),
        roomStatusMessage = null,
      )
    }
  }

  fun createOnlineRoomAndPlay(gameType: GameType) {
    val username = _uiState.value.currentUser?.username ?: "بازیکن"
    viewModelScope.launch {
      _uiState.update { it.copy(roomStatusMessage = "در حال ساخت اتاق امن...") }
      val res = repository.createOnlineRoom(gameType, username)
      res.fold(
        onSuccess = { room ->
          _uiState.update {
            it.copy(
              lobbyGameType = null,
              activeGameSession = ActiveGameSession(gameType, PlayMode.ONLINE_ROOM, 2, room),
              roomStatusMessage = null,
            )
          }
          startRoomPolling(room.roomCode, gameType)
        },
        onFailure = { err ->
          _uiState.update { it.copy(roomStatusMessage = err.message ?: "خطا در ساخت اتاق") }
        },
      )
    }
  }

  fun joinOnlineRoomAndPlay(roomCode: String, gameType: GameType) {
    val username = _uiState.value.currentUser?.username ?: "مهمان"
    viewModelScope.launch {
      _uiState.update { it.copy(roomStatusMessage = "در حال اتصال به اتاق $roomCode...") }
      val res = repository.joinOnlineRoom(roomCode, gameType, username)
      res.fold(
        onSuccess = { room ->
          _uiState.update {
            it.copy(
              lobbyGameType = null,
              activeGameSession = ActiveGameSession(room.gameType, PlayMode.ONLINE_ROOM, 2, room),
              roomStatusMessage = null,
            )
          }
          startRoomPolling(room.roomCode, room.gameType)
        },
        onFailure = { err ->
          _uiState.update { it.copy(roomStatusMessage = err.message ?: "اتاق یافت نشد") }
        },
      )
    }
  }

  fun pushOnlineGameState(stateJson: String, status: String = "playing") {
    val session = _uiState.value.activeGameSession ?: return
    val room = session.room ?: return
    val username = _uiState.value.currentUser?.username ?: "بازیکن"
    lastRoomActivity = System.currentTimeMillis()
    viewModelScope.launch {
      val nextVersion = room.version + 1
      val res = repository.pushOnlineMove(room.roomCode, username, stateJson, status, nextVersion)
      res.onSuccess { updatedRoom ->
        _uiState.update { st ->
          if (st.activeGameSession?.room?.roomCode == updatedRoom.roomCode) {
            st.copy(activeGameSession = st.activeGameSession.copy(room = updatedRoom))
          } else st
        }
      }
    }
  }

  @Volatile private var lastRoomActivity = System.currentTimeMillis()

  @Volatile private var roomChatSince = 0L

  private fun resetRoomChat() {
    roomChatSince = 0L
    _uiState.update { it.copy(roomChat = emptyList(), roomPlayers = emptyMap(), roomChatReady = false) }
  }

  private suspend fun fetchRoomChat(config: CPanelConfig, roomCode: String): Boolean {
    val res = repository.listRoomChat(config, roomCode, roomChatSince)
    res.onSuccess { page ->
      page.messages.maxOfOrNull { it.timestamp }?.let { if (it > roomChatSince) roomChatSince = it }
      _uiState.update { st ->
        if (st.activeGameSession?.room?.roomCode != roomCode) st
        else {
          val serverIds = page.messages.map { it.id }.toSet()
          // Keep not-yet-confirmed local lines (sending / failed); the server copy replaces same-id ones.
          val kept = st.roomChat.filter { it.id !in serverIds }
          st.copy(
            roomChat = (kept + page.messages).sortedBy { it.timestamp }.takeLast(80),
            roomPlayers = if (page.players.isEmpty()) st.roomPlayers else page.players.associateBy { it.username },
            roomChatReady = true,
          )
        }
      }
    }
    return res.isSuccess
  }

  fun sendRoomChat(text: String) {
    val clean = text.trim().take(200)
    if (clean.isEmpty()) return
    val st = _uiState.value
    val room = st.activeGameSession?.room ?: return
    val me = st.currentUser?.username ?: return
    val config = st.cPanelConfig
    val id = UUID.randomUUID().toString().replace("-", "").take(24)
    val local = RoomChatMessage(id, me, clean, System.currentTimeMillis())
    _uiState.update { it.copy(roomChat = (it.roomChat + local).takeLast(80)) }
    viewModelScope.launch {
      val res = repository.sendRoomChat(config, room.roomCode, id, clean)
      if (res.isFailure) {
        _uiState.update { s ->
          s.copy(roomChat = s.roomChat.map { if (it.id == id) it.copy(failed = true) else it })
        }
      }
    }
  }

  private fun startRoomPolling(roomCode: String, gameType: GameType) {
    roomPollingJob?.cancel()
    resetRoomChat()
    val config = _uiState.value.cPanelConfig
    if (!config.isConnected || config.apiBaseUrl.isBlank()) return
    val username = _uiState.value.currentUser?.username ?: "بازیکن"
    roomPollingJob =
      viewModelScope.launch {
        fun apply(synced: OnlineRoom) {
          _uiState.update { st ->
            val current = st.activeGameSession
            if (current != null && current.room?.roomCode == synced.roomCode) {
              if (synced.version > (current.room.version) || synced.players != current.room.players) {
                st.copy(activeGameSession = current.copy(room = synced))
              } else st
            } else st
          }
        }
        var lastTok: String? = null
        var lastCTok: String? = null
        var chatFetched = false
        var infoPlayers = -1
        lastRoomActivity = System.currentTimeMillis()
        while (isActive) {
          // 1) tiny file-based check (no MySQL on the server), 2) full sync only when something changed.
          val tokens = repository.peekOnlineRoom(config, roomCode).getOrNull()
          val tok = tokens?.tok
          val ctok = tokens?.ctok
          val tokOk = !tok.isNullOrEmpty()
          if (!tokOk || tok != lastTok) {
            val synced = repository.syncOnlineRoom(roomCode, gameType, username)
            synced.onSuccess { apply(it) }
            if (tokOk && synced.isSuccess) lastTok = tok
            lastRoomActivity = System.currentTimeMillis()
          }
          // Room chat: fetch once at start, when someone new joins (avatar info), and when the chat token changes.
          val playersNow = _uiState.value.activeGameSession?.room?.players?.size ?: 0
          if (!chatFetched || playersNow != infoPlayers || (!ctok.isNullOrEmpty() && ctok != lastCTok)) {
            if (fetchRoomChat(config, roomCode)) {
              chatFetched = true
              if (playersNow != infoPlayers) {
                // New player in the room: load their profile photos (only changed ones are downloaded).
                _uiState.value.activeGameSession?.room?.players?.let { syncAvatarsFor(it) }
              }
              infoPlayers = playersNow
            }
            if (!ctok.isNullOrEmpty()) {
              lastCTok = ctok
              lastRoomActivity = System.currentTimeMillis()
            }
          }
          val idle = System.currentTimeMillis() - lastRoomActivity
          delay(
            when {
              !tokOk -> config.pollingIntervalMs.toLong() // old api.php / no token file: legacy polling
              idle < 20_000L -> 400L
              idle < 60_000L -> 1_000L
              else -> 2_000L
            }
          )
        }
      }
  }

  fun exitActiveGame() {
    roomPollingJob?.cancel()
    resetRoomChat()
    _uiState.update { it.copy(activeGameSession = null) }
    refreshLeaderboard()
  }

  fun recordGameFinish(gameType: GameType, didWin: Boolean, points: Int) {
    viewModelScope.launch {
      val updated = repository.recordMatchResult(gameType, points, didWin)
      if (updated != null) {
        _uiState.update { it.copy(currentUser = updated) }
      }
      refreshLeaderboard()
    }
  }

  // --- Profile: avatar photo + display name ---

  private val avatarTried = mutableSetOf<String>()

  /** Loads profile photos of people who wrote in the open chat (each name is tried once per session). */
  private fun syncSenderAvatars(msgs: List<ChatMessage>) {
    val me = _uiState.value.currentUser?.username?.lowercase()
    val fresh = msgs.map { it.senderUsername.lowercase() }.distinct().filter { it != me && avatarTried.add(it) }
    fresh.chunked(8).forEach { syncAvatarsFor(it) }
    syncNamesFor(fresh)
  }

  private val nameTried = mutableSetOf<String>()

  /** Looks up the display name of each person once (public profile) so the UI can show it instead of the username. */
  private fun syncNamesFor(usernames: List<String>) {
    val me = _uiState.value.currentUser?.username?.lowercase()
    val todo = usernames.map { it.trim().lowercase() }.filter { it.isNotEmpty() && it != me && nameTried.add(it) }
    if (todo.isEmpty()) return
    viewModelScope.launch {
      todo.forEach { name ->
        repository.getUserProfile(name).fold(
          onSuccess = { p ->
            if (p.displayName.isNotBlank()) {
              _uiState.update { st -> st.copy(senderNames = st.senderNames + (name to p.displayName)) }
            }
          },
          onFailure = { nameTried.remove(name) }, // network hiccup: try again next time
        )
      }
    }
  }

  private fun syncAvatarsFor(usernames: List<String>) {
    viewModelScope.launch {
      val names = usernames.map { it.trim().lowercase() }.filter { it.isNotEmpty() }.distinct().take(8)
      val found = repository.syncAvatars(names)
      _uiState.update { st -> st.copy(avatars = (st.avatars - names.toSet()) + found) }
    }
  }

  fun clearProfileMessage() {
    _uiState.update { it.copy(profileMessage = null) }
  }

  fun setAvatarFromUri(uri: Uri) {
    val me = _uiState.value.currentUser?.username ?: return
    viewModelScope.launch {
      _uiState.update { it.copy(profileBusy = true, profileMessage = null) }
      val bytes =
        withContext(Dispatchers.IO) { ChatImageUtils.avatarJpeg(appContext.contentResolver, uri) }
      if (bytes == null) {
        _uiState.update { it.copy(profileBusy = false, profileMessage = "بارگذاری عکس ناموفق بود") }
        return@launch
      }
      val res = repository.uploadAvatar(me, bytes)
      _uiState.update {
        it.copy(
          profileBusy = false,
          profileMessage = if (res.isSuccess) "عکس پروفایل ذخیره شد" else (res.exceptionOrNull()?.message ?: "خطا در ذخیره عکس"),
        )
      }
      if (res.isSuccess) syncAvatarsFor(listOf(me))
    }
  }

  fun removeAvatar() {
    val me = _uiState.value.currentUser?.username ?: return
    viewModelScope.launch {
      _uiState.update { it.copy(profileBusy = true, profileMessage = null) }
      val res = repository.removeAvatar(me)
      _uiState.update {
        it.copy(
          profileBusy = false,
          profileMessage = if (res.isSuccess) "عکس پروفایل حذف شد" else (res.exceptionOrNull()?.message ?: "خطا"),
        )
      }
      if (res.isSuccess) syncAvatarsFor(listOf(me))
    }
  }

  fun loadMyBio() {
    val me = _uiState.value.currentUser?.username ?: return
    viewModelScope.launch {
      repository.getUserProfile(me).onSuccess { p -> _uiState.update { it.copy(myBio = p.bio) } }
    }
  }

  fun saveBio(bio: String) {
    viewModelScope.launch {
      _uiState.update { it.copy(profileBusy = true, profileMessage = null) }
      val res = repository.setBio(bio)
      _uiState.update { st ->
        st.copy(
          profileBusy = false,
          myBio = res.getOrNull() ?: st.myBio,
          profileMessage = if (res.isSuccess) "بیوگرافی ذخیره شد" else (res.exceptionOrNull()?.message ?: "ذخیره‌ی بیوگرافی ناموفق بود"),
        )
      }
    }
  }

  // --- Public profile + private chat (opened from a group chat) ---

  fun openUserProfile(username: String) {
    _uiState.update { it.copy(viewedUser = username, viewedProfile = null, viewedProfileError = null) }
    syncAvatarsFor(listOf(username))
    viewModelScope.launch {
      repository.getUserProfile(username).fold(
        onSuccess = { p ->
          _uiState.update { st -> if (st.viewedUser.equals(username, ignoreCase = true)) st.copy(viewedProfile = p) else st }
        },
        onFailure = { e ->
          _uiState.update { st ->
            if (st.viewedUser.equals(username, ignoreCase = true)) st.copy(viewedProfileError = e.message ?: "بارگذاری پروفایل ناموفق بود") else st
          }
        },
      )
    }
  }

  fun closeUserProfile() {
    _uiState.update { it.copy(viewedUser = null, viewedProfile = null, viewedProfileError = null) }
  }

  /** Starts (or reopens) a private chat; the currently open group is the shared group the key comes from. */
  fun startDirectMessage(target: String) {
    val origin = _uiState.value.selectedGroup ?: return
    viewModelScope.launch {
      repository.openDirectChat(target, origin.id).fold(
        onSuccess = { dm ->
          _uiState.update {
            it.copy(chatGroups = listOf(dm) + it.chatGroups.filterNot { g -> g.id == dm.id })
          }
          syncNamesFor(dm.members)
          openGroupChat(dm)
        },
        onFailure = { e -> _uiState.update { it.copy(viewedProfileError = e.message ?: "باز کردن گفتگو ناموفق بود") } },
      )
    }
  }

  fun updateDisplayName(name: String) {
    val clean = name.trim().take(32)
    if (clean.isEmpty()) {
      _uiState.update { it.copy(profileMessage = "نام نمی‌تواند خالی باشد") }
      return
    }
    viewModelScope.launch {
      _uiState.update { it.copy(profileBusy = true, profileMessage = null) }
      val res = repository.updateDisplayName(clean)
      _uiState.update { st ->
        val acc = res.getOrNull()
        st.copy(
          profileBusy = false,
          currentUser = acc ?: st.currentUser,
          profileMessage = if (acc != null) "نام شما تغییر کرد" else (res.exceptionOrNull()?.message ?: "خطا در تغییر نام"),
        )
      }
    }
  }

  // --- Leaderboard ---

  fun setLeaderboardFilter(filter: GameType?) {
    _uiState.update { it.copy(leaderboardFilter = filter) }
  }

  fun refreshLeaderboard() {
    viewModelScope.launch {
      val currentUser = _uiState.value.currentUser?.username
      val list = repository.getLeaderboard(currentUser)
      val me = list.firstOrNull { it.isCurrentUser }
      val synced =
        if (me != null) {
          withContext(Dispatchers.IO) { repository.syncSessionStats(me.totalScore, me.wins, me.gamesPlayed) }
        } else null
      _uiState.update { st ->
        // Ignore a result that arrives after logout.
        if (st.currentUser == null) st
        else st.copy(leaderboard = list, currentUser = synced ?: st.currentUser)
      }
      // Load profile photos for everyone on the board (the sync call takes up to 8 names at a time).
      list.map { it.username }.distinct().chunked(8).forEach { syncAvatarsFor(it) }
    }
  }

  // --- Chat & Group Invites ---

  fun refreshGroups() {
    viewModelScope.launch {
      val groups = repository.getChatGroups(_uiState.value.currentUser?.username)
      _uiState.update { st ->
        val updatedSelected =
          st.selectedGroup?.let { sel -> groups.firstOrNull { it.id == sel.id } ?: sel }
        st.copy(chatGroups = groups, selectedGroup = updatedSelected)
      }
      syncGroupAvatars(groups)
      syncNamesFor(groups.flatMap { it.members })
    }
  }

  private val groupAvatarTried = mutableSetOf<String>()

  /** Group photos are cached on disk; each group is checked once per session (and after the owner changes it). */
  private fun syncGroupAvatars(groups: List<ChatGroup>) {
    val keys = groups.filter { !it.isDm && groupAvatarTried.add(it.id) }.map { "g:${it.id}" }
    keys.chunked(8).forEach { syncAvatarsFor(it) }
  }

  fun setGroupAvatarFromUri(groupId: String, uri: Uri) {
    viewModelScope.launch {
      _uiState.update { it.copy(chatFeedback = "در حال ذخیره‌ی عکس گروه...") }
      val bytes = withContext(Dispatchers.IO) { ChatImageUtils.avatarJpeg(appContext.contentResolver, uri) }
      if (bytes == null) {
        _uiState.update { it.copy(chatFeedback = "بارگذاری عکس ناموفق بود") }
        return@launch
      }
      val res = repository.uploadGroupAvatar(groupId, bytes)
      _uiState.update {
        it.copy(chatFeedback = if (res.isSuccess) "عکس گروه ذخیره شد" else (res.exceptionOrNull()?.message ?: "خطا در ذخیره‌ی عکس"))
      }
      if (res.isSuccess) syncAvatarsFor(listOf("g:$groupId"))
    }
  }

  fun removeGroupAvatar(groupId: String) {
    viewModelScope.launch {
      val res = repository.removeGroupAvatar(groupId)
      _uiState.update {
        it.copy(chatFeedback = if (res.isSuccess) "عکس گروه حذف شد" else (res.exceptionOrNull()?.message ?: "خطا"))
      }
      if (res.isSuccess) syncAvatarsFor(listOf("g:$groupId"))
    }
  }

  fun createGroup(name: String) {
    val username = _uiState.value.currentUser?.username
    if (username == null) {
      _uiState.update { it.copy(chatFeedback = "ابتدا از تب پروفایل وارد شوید") }
      return
    }
    viewModelScope.launch {
      val res = repository.createGroup(name, username)
      res.fold(
        onSuccess = { grp ->
          _uiState.update {
            it.copy(
              chatGroups = listOf(grp) + it.chatGroups.filterNot { g -> g.id == grp.id },
              selectedGroup = grp,
              chatFeedback = "گروه «${grp.name}» ساخته شد | کد دعوت: ${grp.shareCode.ifBlank { grp.inviteCode }}",
            )
          }
          openGroupChat(grp)
        },
        onFailure = { err -> _uiState.update { it.copy(chatFeedback = err.message) } },
      )
    }
  }

  fun joinGroupByCode(code: String) {
    val username = _uiState.value.currentUser?.username
    if (username == null) {
      _uiState.update { it.copy(chatFeedback = "ابتدا از تب پروفایل وارد شوید") }
      return
    }
    viewModelScope.launch {
      val res = repository.joinGroupByCode(code, username)
      res.fold(
        onSuccess = { result ->
          when (result) {
            is JoinResult.Joined -> {
              val grp = result.group
              _uiState.update {
                it.copy(
                  chatGroups = listOf(grp) + it.chatGroups.filterNot { g -> g.id == grp.id },
                  selectedGroup = grp,
                  chatFeedback = null,
                )
              }
              openGroupChat(grp)
            }
            is JoinResult.Pending ->
              _uiState.update {
                it.copy(chatFeedback = "درخواست عضویت در «${result.groupName}» ارسال شد. بعد از تأیید سازنده‌ی گروه وارد می‌شوی.")
              }
          }
        },
        onFailure = { err -> _uiState.update { it.copy(chatFeedback = err.message) } },
      )
    }
  }

  fun inviteMember(groupId: String, targetUsername: String) {
    viewModelScope.launch {
      val res = repository.inviteMemberToGroup(groupId, targetUsername)
      res.fold(
        onSuccess = { grp ->
          _uiState.update {
            it.copy(
              selectedGroup = grp,
              chatGroups = it.chatGroups.map { g -> if (g.id == grp.id) grp else g },
              chatFeedback = "کاربر «$targetUsername» به گروه دعوت شد",
            )
          }
        },
        onFailure = { err -> _uiState.update { it.copy(chatFeedback = err.message) } },
      )
    }
  }

  fun updateGroup(groupId: String, name: String, description: String) {
    val username = _uiState.value.currentUser?.username ?: return
    viewModelScope.launch {
      repository.updateGroup(groupId, username, name, description).fold(
        onSuccess = { grp ->
          _uiState.update {
            it.copy(
              selectedGroup = if (it.selectedGroup?.id == grp.id) grp else it.selectedGroup,
              chatGroups = it.chatGroups.map { g -> if (g.id == grp.id) grp else g },
              chatFeedback = "مشخصات گروه به‌روز شد",
            )
          }
        },
        onFailure = { err -> _uiState.update { it.copy(chatFeedback = err.message ?: "ذخیره‌ی تغییرات ناموفق بود") } },
      )
    }
  }

  fun leaveGroup(groupId: String) {
    val username = _uiState.value.currentUser?.username ?: return
    viewModelScope.launch {
      repository.leaveGroup(groupId, username).fold(
        onSuccess = { onGroupGone(groupId, "از گروه خارج شدی") },
        onFailure = { err -> _uiState.update { it.copy(chatFeedback = err.message) } },
      )
    }
  }

  fun deleteGroup(groupId: String) {
    val username = _uiState.value.currentUser?.username ?: return
    viewModelScope.launch {
      repository.deleteGroup(groupId, username).fold(
        onSuccess = { onGroupGone(groupId, "گروه حذف شد") },
        onFailure = { err -> _uiState.update { it.copy(chatFeedback = err.message) } },
      )
    }
  }

  private fun onGroupGone(groupId: String, message: String) {
    val wasOpen = _uiState.value.selectedGroup?.id == groupId
    if (wasOpen) {
      chatPollingJob?.cancel()
      _uiState.value.chatDraftImage?.let { File(it).delete() }
    }
    _uiState.update { st ->
      val rest = st.chatGroups.filterNot { it.id == groupId }
      if (wasOpen) {
        st.copy(
          chatGroups = rest,
          selectedGroup = null,
          chatMessages = emptyList(),
          chatReplyTo = null,
          chatDraftImage = null,
          chatFeedback = message,
        )
      } else {
        st.copy(chatGroups = rest, chatFeedback = message)
      }
    }
  }

  private fun isOwnerOf(group: ChatGroup?): Boolean {
    val me = _uiState.value.currentUser?.username ?: return false
    return group != null && !group.isDm && group.ownerUsername.equals(me, ignoreCase = true)
  }

  private suspend fun refreshJoinRequests(group: ChatGroup) {
    if (!isOwnerOf(group)) return
    repository.getJoinRequests(group.id).onSuccess { list ->
      _uiState.update { st -> if (st.selectedGroup?.id == group.id && st.joinRequests != list) st.copy(joinRequests = list) else st }
    }
  }

  fun resolveJoinRequest(username: String, approve: Boolean) {
    val group = _uiState.value.selectedGroup ?: return
    viewModelScope.launch {
      repository.resolveJoinRequest(group.id, username, approve).fold(
        onSuccess = { updated ->
          _uiState.update { st ->
            st.copy(
              joinRequests = st.joinRequests.filterNot { it.username.equals(username, ignoreCase = true) },
              selectedGroup = if (st.selectedGroup?.id == group.id) updated else st.selectedGroup,
              chatGroups = st.chatGroups.map { g -> if (g.id == group.id) updated else g },
              chatFeedback = if (approve) "«$username» به گروه اضافه شد" else "درخواست «$username» رد شد",
            )
          }
        },
        onFailure = { err -> _uiState.update { it.copy(chatFeedback = err.message ?: "عملیات ناموفق بود") } },
      )
    }
  }

  fun openGroupChat(group: ChatGroup) {
    _uiState.update {
      it.copy(selectedGroup = group, chatFeedback = null, chatReplyTo = null, chatDraftImage = null, joinRequests = emptyList(), viewedUser = null, viewedProfile = null, viewedProfileError = null)
    }
    // Member photos for the group profile screen (the sync call takes up to 8 names at a time).
    group.members.distinct().chunked(8).forEach { syncAvatarsFor(it) }
    viewModelScope.launch {
      val msgs = repository.getMessages(group.id, _uiState.value.currentUser?.username)
      _uiState.update { it.copy(chatMessages = msgs, chatReads = repository.lastReads) }
      syncSenderAvatars(msgs)
      refreshJoinRequests(group)
    }
    startChatPolling(group.id)
  }

  fun closeGroupChat() {
    chatPollingJob?.cancel()
    _uiState.value.chatDraftImage?.let { File(it).delete() }
    _uiState.update {
      it.copy(selectedGroup = null, chatMessages = emptyList(), chatReplyTo = null, chatDraftImage = null, joinRequests = emptyList(), viewedUser = null, viewedProfile = null, viewedProfileError = null)
    }
    refreshGroups()
  }

  fun sendGroupMessage(text: String) {
    val st = _uiState.value
    val group = st.selectedGroup ?: return
    val user = st.currentUser ?: return
    val draft = st.chatDraftImage?.let { File(it) }?.takeIf { it.exists() }
    if (text.isBlank() && draft == null) return
    val reply = st.chatReplyTo
    val (msg, local) =
      repository.queueMessage(
        groupId = group.id,
        senderUsername = user.username,
        senderColorIndex = user.avatarColorIndex,
        text = text,
        draftImage = draft,
        replyTo = reply,
      )
    _uiState.update {
      it.copy(chatMessages = local, chatReplyTo = null, chatDraftImage = null)
    }
    deliver(msg)
  }

  private fun deliver(msg: ChatMessage) {
    viewModelScope.launch {
      val updated = repository.deliverMessage(msg)
      _uiState.update { st ->
        if (st.selectedGroup?.id == msg.groupId) st.copy(chatMessages = updated) else st
      }
    }
  }

  fun retryMessage(msg: ChatMessage) {
    val updated = repository.setSendState(msg.groupId, msg.id, SendState.SENDING)
    _uiState.update { st ->
      if (st.selectedGroup?.id == msg.groupId) st.copy(chatMessages = updated) else st
    }
    deliver(msg.copy(sendState = SendState.SENDING))
  }

  fun deleteChatMessage(msg: ChatMessage) {
    viewModelScope.launch {
      repository.deleteMessage(msg).fold(
        onSuccess = { updated ->
          _uiState.update { st ->
            if (st.selectedGroup?.id == msg.groupId) {
              st.copy(
                chatMessages = updated,
                chatReplyTo = st.chatReplyTo?.takeIf { it.id != msg.id },
                chatFeedback = "پیام حذف شد",
              )
            } else st
          }
        },
        onFailure = { err -> _uiState.update { it.copy(chatFeedback = err.message ?: "حذف پیام ناموفق بود") } },
      )
    }
  }

  fun setChatReply(msg: ChatMessage?) {
    _uiState.update { it.copy(chatReplyTo = msg) }
  }

  fun pickChatImage(uri: Uri) {
    viewModelScope.launch {
      _uiState.update { it.copy(chatImageBusy = true) }
      val out = repository.newDraftFile(appContext.cacheDir)
      val ok =
        withContext(Dispatchers.IO) { ChatImageUtils.compressToFile(appContext.contentResolver, uri, out) }
      _uiState.update { st ->
        st.chatDraftImage?.takeIf { ok }?.let { File(it).delete() }
        if (ok) st.copy(chatDraftImage = out.absolutePath, chatImageBusy = false)
        else st.copy(chatImageBusy = false, chatFeedback = "بارگذاری عکس ناموفق بود")
      }
    }
  }

  fun clearChatDraftImage() {
    _uiState.value.chatDraftImage?.let { File(it).delete() }
    _uiState.update { it.copy(chatDraftImage = null) }
  }

  suspend fun loadChatImage(msg: ChatMessage, maxDim: Int = 900): Bitmap? =
    repository.loadImage(msg, maxDim)

  fun sendGameInviteToGroup(gameType: GameType) {
    val group = _uiState.value.selectedGroup ?: return
    val user = _uiState.value.currentUser ?: return
    viewModelScope.launch {
      val roomRes = repository.createOnlineRoom(gameType, user.username)
      val roomCode = roomRes.getOrNull()?.roomCode
      if (roomCode == null) {
        _uiState.update { it.copy(chatFeedback = roomRes.exceptionOrNull()?.message ?: "ساخت اتاق ناموفق بود") }
        return@launch
      }
      val invite = GameInvite(gameType = gameType, roomCode = roomCode, hostUsername = user.username)
      val updated =
        repository.sendMessage(
          groupId = group.id,
          senderUsername = user.username,
          senderColorIndex = user.avatarColorIndex,
          text = "دعوت به بازی ${gameType.titleFa} (کد اتاق: $roomCode)",
          gameInvite = invite,
        )
      _uiState.update { it.copy(chatMessages = updated) }
    }
  }

  fun clearChatFeedback() {
    _uiState.update { it.copy(chatFeedback = null) }
  }

  private fun startChatPolling(groupId: String) {
    chatPollingJob?.cancel()
    val config = _uiState.value.cPanelConfig
    if (!config.isConnected || config.apiBaseUrl.isBlank()) return
    chatPollingJob =
      viewModelScope.launch {
        while (isActive) {
          delay(config.pollingIntervalMs.toLong())
          val msgs = repository.getMessages(groupId, _uiState.value.currentUser?.username)
          val reads = repository.lastReads
          _uiState.update { st ->
            if (st.selectedGroup?.id == groupId && (msgs != st.chatMessages || reads != st.chatReads)) {
              st.copy(chatMessages = msgs, chatReads = reads)
            } else st
          }
          syncSenderAvatars(msgs)
          _uiState.value.selectedGroup?.takeIf { it.id == groupId }?.let { refreshJoinRequests(it) }
        }
      }
  }
}
