package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber-Arcade Gaming Palette
val ObsidianBg = Color(0xFF1E2868)
val CarbonSurface = Color(0xFF26337A)
val ElevatedCard = Color(0xFF2B3A85)
val ElevatedCardStroke = Color(0xFF4C5FB0)

val NeonCyan = Color(0xFF00E5FF)
val NeonCyanDim = Color(0xFF0099B8)
val ElectricEmerald = Color(0xFF3DE08A)
val CyberGold = Color(0xFFFFB300)
val CrimsonMagenta = Color(0xFFFF3D71)
val VioletPulse = Color(0xFF7C4DFF)

val TextPrimary = Color(0xFFF4F7FF)
val TextSecondary = Color(0xFFC3CCEC)
val TextMuted = Color(0xFF9AA6D6)

// Player colors for Ludo / Snakes & Ladders / Connect 4
val PlayerRed = Color(0xFFFF5C7A)
val PlayerGreen = Color(0xFF3DE08A)
val PlayerYellow = Color(0xFFFFD43B)
val PlayerBlue = Color(0xFF4D9BFF)
