package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber-Arcade Gaming Palette
val ObsidianBg = Color(0xFF0B0E17)
val CarbonSurface = Color(0xFF141A29)
val ElevatedCard = Color(0xFF1C2438)
val ElevatedCardStroke = Color(0xFF2B3654)

val NeonCyan = Color(0xFF00E5FF)
val NeonCyanDim = Color(0xFF0099B8)
val ElectricEmerald = Color(0xFF00E676)
val CyberGold = Color(0xFFFFB300)
val CrimsonMagenta = Color(0xFFFF3D71)
val VioletPulse = Color(0xFF7C4DFF)

val TextPrimary = Color(0xFFF4F7FF)
val TextSecondary = Color(0xFF9BA8C7)
val TextMuted = Color(0xFF63708F)

// Player colors for Ludo / Snakes & Ladders / Connect 4
val PlayerRed = Color(0xFFFF3D5A)
val PlayerGreen = Color(0xFF00E676)
val PlayerYellow = Color(0xFFFFC400)
val PlayerBlue = Color(0xFF2979FF)
