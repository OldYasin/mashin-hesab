package com.example.ui.games

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.data.GameType
import com.example.data.OnlineRoom
import com.example.data.PlayMode
import com.example.data.Sfx
import com.example.data.SoundManager
import com.example.ui.components.GameTopBar
import com.example.ui.components.LocalGameHud
import com.example.ui.components.PublishRoomHud
import com.example.ui.components.GameArea
import com.example.ui.components.GameTurnTimer
import com.example.ui.components.rememberTurnCountdown
import com.example.ui.components.fitBoard
import com.example.ui.components.boardWidth
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.WinCelebrationBanner
import com.example.ui.components.oceanGameBackdrop
import com.example.ui.components.drawGlossyToken
import com.example.ui.theme.CyberGold
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PlayerRed
import com.example.ui.theme.PlayerYellow
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

internal const val C4_ROWS = 6
internal const val C4_COLS = 7

@Composable
fun ConnectFourScreen(
  playMode: PlayMode,
  room: OnlineRoom?,
  currentUsername: String,
  onPushOnlineState: (String, String) -> Unit,
  onRecordResult: (Boolean, Int) -> Unit,
  onBack: () -> Unit,
) {
  BackHandler(onBack = onBack)

  // grid[row][col], 0=empty, 1=Red, 2=Yellow
  var grid by remember { mutableStateOf(List(C4_ROWS) { List(C4_COLS) { 0 } }) }
  var currentTurn by remember { mutableIntStateOf(1) }
  var winner by remember { mutableIntStateOf(0) } // 0=ongoing, 1, 2, 3=draw
  var winningCells by remember { mutableStateOf<Set<Pair<Int, Int>>>(emptySet()) }
  var lastDropCell by remember { mutableStateOf<Pair<Int, Int>?>(null) }
  var isDropping by remember { mutableStateOf(false) }
  var recorded by remember { mutableStateOf(false) }
  var roundId by remember { mutableIntStateOf(0) }

  val scope = rememberCoroutineScope()
  val dropProgress = remember { Animatable(1f) }
  // Ripple ring that plays around the last dropped disc (0 -> 1), 1 = idle
  val ringAnim = remember { Animatable(1f) }

  val myOnlineSide =
    remember(room, currentUsername) {
      if (room == null) 1
      else if (room.hostUsername.equals(currentUsername, ignoreCase = true)) 1 else 2
    }

  LaunchedEffect(room?.version, room?.stateJson) {
    if (playMode == PlayMode.ONLINE_ROOM && room != null && room.stateJson.length > 4) {
      try {
        val j = JSONObject(room.stateJson)
        val arr = j.optJSONArray("grid")
        if (arr != null && arr.length() == C4_ROWS) {
          val parsed =
            List(C4_ROWS) { r ->
              val rowArr = arr.getJSONArray(r)
              List(C4_COLS) { c -> rowArr.getInt(c) }
            }
          val oldGrid = grid
          val added = mutableListOf<Pair<Int, Int>>()
          for (r in 0 until C4_ROWS) for (c in 0 until C4_COLS) {
            if (oldGrid[r][c] == 0 && parsed[r][c] != 0) added.add(r to c)
          }
          val newTurn = j.optInt("turn", 1)
          val res = checkC4Winner(parsed)
          if (added.size == 1) {
            // Opponent's move: animate the drop + ring so it is noticeable
            try {
              grid = parsed
              currentTurn = newTurn
              lastDropCell = added[0]
              dropProgress.snapTo(0f)
              dropProgress.animateTo(
                targetValue = 1f,
                animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMedium),
              )
              scope.launch {
                ringAnim.snapTo(0f)
                ringAnim.animateTo(1f, tween(1100, easing = FastOutSlowInEasing))
              }
            } finally {
              winner = res.first
              winningCells = res.second
            }
          } else {
            if (!isDropping) dropProgress.snapTo(1f)
            grid = parsed
            currentTurn = newTurn
            if (parsed.all { row -> row.all { it == 0 } }) lastDropCell = null
            winner = res.first
            winningCells = res.second
          }
        }
      } catch (_: Throwable) {}
    }
  }

  fun resetGame() {
    grid = List(C4_ROWS) { List(C4_COLS) { 0 } }
    currentTurn = 1
    winner = 0
    winningCells = emptySet()
    lastDropCell = null
    isDropping = false
    recorded = false
    roundId++
    if (playMode == PlayMode.ONLINE_ROOM && room != null) {
      val jsonGrid = JSONArray(grid.map { JSONArray(it) })
      onPushOnlineState(
        JSONObject().apply { put("grid", jsonGrid); put("turn", 1) }.toString(),
        "playing",
      )
    }
  }

  suspend fun dropInColumnAnimated(col: Int, player: Int) {
    if (isDropping || winner != 0 || col !in 0 until C4_COLS) return
    val targetRow = (C4_ROWS - 1 downTo 0).firstOrNull { r -> grid[r][col] == 0 } ?: return
    isDropping = true
    try {
      val next = grid.map { it.toMutableList() }
      next[targetRow][col] = player
      val immutable = next.map { it.toList() }
      grid = immutable
      lastDropCell = targetRow to col
      dropProgress.snapTo(0f)
      dropProgress.animateTo(
        targetValue = 1f,
        animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMedium),
      )
      scope.launch {
        ringAnim.snapTo(0f)
        ringAnim.animateTo(1f, tween(1100, easing = FastOutSlowInEasing))
      }

      val (win, cells) = checkC4Winner(immutable)
      winner = win
      winningCells = cells
      val nextTurn = if (player == 1) 2 else 1
      if (win == 0) currentTurn = nextTurn

      if (playMode == PlayMode.ONLINE_ROOM && room != null) {
        val jsonGrid = JSONArray(immutable.map { JSONArray(it) })
        onPushOnlineState(
          JSONObject().apply { put("grid", jsonGrid); put("turn", nextTurn) }.toString(),
          if (win == 0) "playing" else "finished",
        )
      }
    } finally {
      isDropping = false
    }
  }

  fun handleHumanColumnTap(col: Int) {
    if (isDropping || winner != 0 || col !in 0 until C4_COLS) return
    if (grid[0][col] != 0) return
    if (playMode == PlayMode.VS_AI && currentTurn != 1) return
    if (playMode == PlayMode.ONLINE_ROOM && currentTurn != myOnlineSide) return
    scope.launch {
      dropInColumnAnimated(col, currentTurn)
    }
  }

  val latestTapHandler by rememberUpdatedState(::handleHumanColumnTap)

  // AI Turn — key omits isDropping so animation never cancels the coroutine
  LaunchedEffect(currentTurn, winner, playMode, roundId) {
    if (playMode == PlayMode.VS_AI && currentTurn == 2 && winner == 0) {
      delay(340)
      while (isDropping) {
        delay(30)
      }
      if (currentTurn == 2 && winner == 0) {
        val aiCol = pickC4AiColumn(grid)
        if (aiCol >= 0) {
          dropInColumnAnimated(aiCol, 2)
        }
      }
    }
  }

  // Sound: disc landing (covers me, the AI and online opponents).
  var lastDiscs by remember { mutableIntStateOf(0) }
  LaunchedEffect(grid) {
    val discs = grid.sumOf { row -> row.count { it != 0 } }
    if (discs > lastDiscs) SoundManager.play(Sfx.DROP)
    lastDiscs = discs
  }

  var resultSoundPlayed by remember { mutableStateOf(false) }
  LaunchedEffect(winner) {
    if (winner == 0) {
      resultSoundPlayed = false
    } else if (!resultSoundPlayed) {
      resultSoundPlayed = true
      val mySide = if (playMode == PlayMode.ONLINE_ROOM) myOnlineSide else 1
      delay(350)
      SoundManager.play(
        when (winner) {
          3 -> Sfx.DRAW
          mySide -> Sfx.WIN
          else -> Sfx.LOSE
        }
      )
    }
  }

  LaunchedEffect(winner) {
    if (winner != 0 && !recorded) {
      recorded = true
      when (winner) {
        1 -> onRecordResult(true, 35)
        2 -> onRecordResult(false, 8)
        3 -> onRecordResult(false, 12)
      }
    }
  }

  val activeTurnColor = if (currentTurn == 1) PlayerRed else PlayerYellow
  // Win pulse only runs once somebody has actually won (was an always-on infinite animation
  // that forced a full board redraw every frame for the whole game).
  val winPulseAnim = remember { Animatable(0f) }
  LaunchedEffect(winner) {
    if (winner != 0 && winner != 3) {
      while (isActive) {
        winPulseAnim.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
        winPulseAnim.animateTo(0f, tween(650, easing = FastOutSlowInEasing))
      }
    } else {
      winPulseAnim.snapTo(0f)
    }
  }

  Column(
    modifier =
      Modifier.fillMaxSize()
        .oceanGameBackdrop(activeTurnColor)
        .systemBarsPadding(),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    val turnLeft =
      rememberTurnCountdown(key = listOf(currentTurn, winner, roundId), running = winner == 0) {
        val mine =
          winner == 0 && !isDropping &&
            (playMode != PlayMode.VS_AI || currentTurn == 1) &&
            (playMode != PlayMode.ONLINE_ROOM || currentTurn == myOnlineSide)
        if (mine) {
          val open = (0 until C4_COLS).filter { grid[0][it] == 0 }
          if (open.isNotEmpty()) handleHumanColumnTap(open.random())
        }
      }
    GameTopBar(
      title = GameType.CONNECT_FOUR.titleFa,
      subtitle =
        when (playMode) {
          PlayMode.VS_AI -> "چهار مهره هم‌رنگ بسازید (در برابر ربات)"
          PlayMode.LOCAL_PASS_AND_PLAY -> "دو نفره آفلاین"
          PlayMode.ONLINE_ROOM -> "اتاق آنلاین: ${room?.roomCode ?: "-"}"
        },
      accentColor = CyberGold,
      onBack = onBack,
      copyText = if (playMode == PlayMode.ONLINE_ROOM) room?.roomCode else null,
      trailingContent = {
        IconButton(onClick = { resetGame() }, modifier = Modifier.testTag("c4_reset_button")) {
          Icon(Icons.Rounded.Refresh, contentDescription = "شروع مجدد", tint = CyberGold)
        }
      },
    )

    val hudOn = LocalGameHud.current != null
    PublishRoomHud(room = room, activeSeat = if (winner == 0) currentTurn - 1 else -1)
    GameArea(maxWidth = 580.dp) {
      GameTurnTimer(turnLeft, activeTurnColor, active = winner == 0)
      // Turn indicator pills (online rooms show the turn on the avatar cards instead)
      if (!hudOn) Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        PlayerTurnBadge(
          title = if (playMode == PlayMode.VS_AI) "شما (قرمز)" else "بازیکن ۱ (قرمز)",
          color = PlayerRed,
          active = winner == 0 && currentTurn == 1,
          modifier = Modifier.weight(1f),
        )
        PlayerTurnBadge(
          title = if (playMode == PlayMode.VS_AI) "ربات (طلایی)" else "بازیکن ۲ (طلایی)",
          color = PlayerYellow,
          active = winner == 0 && currentTurn == 2,
          modifier = Modifier.weight(1f),
        )
      }

      // Force LTR for BOTH board and quick-drop buttons so columns 1..7 match physical left-to-right!
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          GlassGradientCard(
            modifier = Modifier.fitBoard(197.dp, aspect = 7f / 6.3f),
            accentColor = activeTurnColor,
            cornerRadius = 24.dp,
          ) {
            Box(
              modifier =
                Modifier.fillMaxSize()
                  .padding(10.dp)
                  .pointerInput(Unit) {
                    detectTapGestures { offset ->
                      val col = ((offset.x / size.width) * C4_COLS).toInt().coerceIn(0, C4_COLS - 1)
                      latestTapHandler(col)
                    }
                  }
                  .testTag("c4_board_canvas")
            ) {
              // Static frame + holes: own layer, drawn once.
              Canvas(modifier = Modifier.fillMaxSize().graphicsLayer { }) {
                val cellW = size.width / C4_COLS
                val cellH = size.height / C4_ROWS
                val radius = minOf(cellW, cellH) * 0.39f

                // Frosted sapphire glass board
                drawRoundRect(
                  brush =
                    Brush.verticalGradient(
                      listOf(Color(0xD92563EB), Color(0xD91D4ED8), Color(0xE61E40AF))
                    ),
                  cornerRadius = CornerRadius(24f, 24f),
                )
                drawRoundRect(
                  brush =
                    Brush.linearGradient(
                      listOf(Color.White.copy(alpha = 0.28f), NeonCyan.copy(alpha = 0.35f))
                    ),
                  cornerRadius = CornerRadius(24f, 24f),
                  style = Stroke(width = 3f),
                )

                for (r in 0 until C4_ROWS) {
                  for (c in 0 until C4_COLS) {
                    val cx = (c + 0.5f) * cellW
                    val cy = (r + 0.5f) * cellH
                    drawCircle(
                      color = Color(0xFF3B82F6).copy(alpha = 0.45f),
                      radius = radius * 1.06f,
                      center = Offset(cx, cy + 2f),
                    )
                    drawCircle(
                      color = ObsidianBg.copy(alpha = 0.94f),
                      radius = radius,
                      center = Offset(cx, cy),
                    )
                  }
                }
              }
              // Dynamic discs: separate layer, only this one is redrawn while dropping.
              Canvas(modifier = Modifier.fillMaxSize().graphicsLayer { }) {
                val cellW = size.width / C4_COLS
                val cellH = size.height / C4_ROWS
                val radius = minOf(cellW, cellH) * 0.39f
                for (r in 0 until C4_ROWS) {
                  for (c in 0 until C4_COLS) {
                    val cx = (c + 0.5f) * cellW
                    val cy = (r + 0.5f) * cellH
                    val value = grid[r][c]
                    if (value != 0) {
                      val isAnimCell = lastDropCell == (r to c)
                      val drawY =
                        if (isAnimCell) {
                          val startY = -radius * 1.4f
                          startY + (cy - startY) * dropProgress.value
                        } else cy

                      val discColor = if (value == 1) PlayerRed else PlayerYellow
                      val isWin = winningCells.contains(r to c)
                      drawGlossyToken(
                        center = Offset(cx, drawY),
                        radius = radius * 0.94f,
                        baseColor = discColor,
                        isHighlighted = isWin,
                        pulseFactor = winPulseAnim.value,
                      )
                      if (isAnimCell) {
                        val ringColor = if (value == 1) PlayerRed else PlayerYellow
                        val center = Offset(cx, drawY)
                        // Steady ring marks the last move until the next one
                        drawCircle(
                          color = Color.White.copy(alpha = 0.9f),
                          radius = radius * 1.12f,
                          center = center,
                          style = Stroke(width = 3.5f),
                        )
                        // Two expanding ripples after landing
                        val rp = ringAnim.value
                        if (rp < 1f) {
                          for (k in 0..1) {
                            val t = ((rp - k * 0.3f) / 0.7f).coerceIn(0f, 1f)
                            if (t > 0f && t < 1f) {
                              drawCircle(
                                color = ringColor.copy(alpha = (1f - t) * 0.85f),
                                radius = radius * (1.1f + 0.9f * t),
                                center = center,
                                style = Stroke(width = 7f * (1f - t) + 2f),
                              )
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }

          // Quick column drop buttons aligned 1..7 left-to-right with board columns
          Row(
            modifier = Modifier.width(boardWidth(197.dp, 7f / 6.3f)),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
          ) {
            val isHumanTurn =
              winner == 0 &&
                !isDropping &&
                (playMode != PlayMode.VS_AI || currentTurn == 1) &&
                (playMode != PlayMode.ONLINE_ROOM || currentTurn == myOnlineSide)

            for (c in 0 until C4_COLS) {
              val canDrop = grid[0][c] == 0 && isHumanTurn
              val colBorderColor = if (canDrop) activeTurnColor.copy(alpha = 0.65f) else Color.White.copy(alpha = 0.08f)
              val colFill =
                if (canDrop) {
                  Brush.verticalGradient(
                    listOf(activeTurnColor.copy(alpha = 0.28f), Color(0x991B2540))
                  )
                } else {
                  Brush.verticalGradient(listOf(Color(0x55141D33), Color(0x550A101D)))
                }
              Surface(
                modifier =
                  Modifier.weight(1f)
                    .height(38.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(colFill)
                    .clickable(enabled = canDrop) { handleHumanColumnTap(c) }
                    .testTag("c4_col_$c"),
                color = Color.Transparent,
                border = BorderStroke(1.dp, colBorderColor),
                shape = RoundedCornerShape(12.dp),
              ) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                  Text(
                    text = "↓ ${c + 1}",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (canDrop) TextPrimary else TextSecondary.copy(alpha = 0.35f),
                  )
                }
              }
            }
          }
        }
      }

      if (winner != 0) {
        val title =
          when (winner) {
            1 -> "قرمز برنده شد!"
            2 -> if (playMode == PlayMode.VS_AI) "ربات طلایی برنده شد!" else "طلایی برنده شد!"
            else -> "تساوی!"
          }
        WinCelebrationBanner(
          winnerTitle = title,
          subtitle = if (winner == 1) "۳۵ امتیاز عالی ثبت شد" else "بازی تمام شد",
          accent = if (winner == 1) PlayerRed else CyberGold,
          onRematch = { resetGame() },
          onExit = onBack,
        )
      } else if (!hudOn) {
        GlassGradientCard(accentColor = activeTurnColor, cornerRadius = 14.dp, modifier = Modifier.fillMaxWidth()) {
          Box(
            modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp, horizontal = 14.dp),
            contentAlignment = Alignment.Center,
          ) {
            Text(
              text =
                when {
                  playMode == PlayMode.VS_AI && currentTurn == 2 -> "ربات در حال انتخاب ستون..."
                  playMode == PlayMode.ONLINE_ROOM && currentTurn != myOnlineSide -> "نوبت حریف آنلاین..."
                  currentTurn == 1 -> "روی ستون دلخواه یا دکمه‌های پایین ضربه بزنید"
                  else -> "نوبت بازیکن ۲ (طلایی)"
                },
              style = MaterialTheme.typography.bodyMedium,
              color = TextPrimary,
            )
          }
        }
      }

    }
  }
}

@Composable
private fun PlayerTurnBadge(
  title: String,
  color: Color,
  active: Boolean,
  modifier: Modifier = Modifier,
) {
  val badgeScale by
    androidx.compose.animation.core.animateFloatAsState(
      if (active) 1.05f else 1f,
      androidx.compose.animation.core.spring(dampingRatio = 0.55f, stiffness = 400f),
      label = "c4BadgeScale",
    )
  GlassGradientCard(
    modifier = modifier.graphicsLayer { scaleX = badgeScale; scaleY = badgeScale },
    accentColor = if (active) color else Color.White.copy(alpha = 0.15f),
    cornerRadius = 16.dp,
  ) {
    Box(
      modifier =
        Modifier.fillMaxWidth()
          .background(if (active) color.copy(alpha = 0.18f) else Color.Transparent)
          .padding(vertical = 6.dp, horizontal = 12.dp),
      contentAlignment = Alignment.Center,
    ) {
      Text(
        title,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = if (active) FontWeight.ExtraBold else FontWeight.Medium,
        color = if (active) color else TextPrimary,
      )
    }
  }
}

internal fun checkC4Winner(grid: List<List<Int>>): Pair<Int, Set<Pair<Int, Int>>> {
  val dirs = listOf(0 to 1, 1 to 0, 1 to 1, 1 to -1)
  for (r in 0 until C4_ROWS) {
    for (c in 0 until C4_COLS) {
      val p = grid[r][c]
      if (p == 0) continue
      for ((dr, dc) in dirs) {
        val cells = mutableListOf(r to c)
        for (step in 1..3) {
          val nr = r + dr * step
          val nc = c + dc * step
          if (nr in 0 until C4_ROWS && nc in 0 until C4_COLS && grid[nr][nc] == p) {
            cells.add(nr to nc)
          } else break
        }
        if (cells.size == 4) return p to cells.toSet()
      }
    }
  }
  val full = (0 until C4_COLS).all { grid[0][it] != 0 }
  return if (full) 3 to emptySet() else 0 to emptySet()
}

internal fun pickC4AiColumn(grid: List<List<Int>>): Int {
  val validCols = (0 until C4_COLS).filter { grid[0][it] == 0 }
  if (validCols.isEmpty()) return -1

  // 1. Immediate win for AI (2)
  for (c in validCols) {
    val r = (C4_ROWS - 1 downTo 0).first { grid[it][c] == 0 }
    val copy = grid.map { it.toMutableList() }
    copy[r][c] = 2
    if (checkC4Winner(copy).first == 2) return c
  }
  // 2. Block player (1) immediate win
  for (c in validCols) {
    val r = (C4_ROWS - 1 downTo 0).first { grid[it][c] == 0 }
    val copy = grid.map { it.toMutableList() }
    copy[r][c] = 1
    if (checkC4Winner(copy).first == 1) return c
  }
  // 3. Avoid gifting opponent an immediate win right above our drop
  val safeCols =
    validCols.filter { c ->
      val r = (C4_ROWS - 1 downTo 0).first { grid[it][c] == 0 }
      if (r == 0) true
      else {
        val copy = grid.map { it.toMutableList() }
        copy[r][c] = 2
        copy[r - 1][c] = 1
        checkC4Winner(copy).first != 1
      }
    }
  val pool = if (safeCols.isNotEmpty()) safeCols else validCols

  // 4. Score heuristic: prefer creating threats / center control
  val centerOrder = listOf(3, 2, 4, 1, 5, 0, 6)
  return pool.sortedBy { centerOrder.indexOf(it) }.firstOrNull() ?: pool.first()
}
