package com.example.ui.games

import android.view.KeyEvent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/*
 * Touch controls drawn like the real pads:
 *  - Mega Drive / Genesis: black plus-shaped D-pad with a dish in the middle, dished round A B C / X Y Z buttons.
 *  - Neo Geo AES: arcade stick with a red ball, glossy round A (red) B (yellow) C (green) D (blue) buttons.
 *  - Both: small rubber START / MODE (COIN) buttons.
 * Face buttons, the Genesis D-pad and the START/MODE pill are bitmap sprites (res/drawable-nodpi/pad_*.webp, cut from the
 * button asset sheet); the Neo Geo stick is drawn in code. Pressed = the sprite sinks and darkens.
 */

private fun lighten(c: Color, t: Float): Color = androidx.compose.ui.graphics.lerp(c, Color.White, t)

private fun darken(c: Color, t: Float): Color = androidx.compose.ui.graphics.lerp(c, Color.Black, t)

// ---------------------------------------------------------------------------------------------
// Round button ("dome"): convex glossy cap (Neo Geo) or dished cap (Genesis) sitting in a socket.
// ---------------------------------------------------------------------------------------------
private fun DrawScope.dome(c: Offset, r: Float, base: Color, press: Float, concave: Boolean, well: Boolean) {
  val q = 1f - press
  // soft shadow under the button (smaller when pressed)
  val ks = floatArrayOf(1.16f, 1.08f, 1.0f)
  val ka = floatArrayOf(0.10f, 0.14f, 0.24f)
  for (i in 0..2) {
    drawCircle(Color.Black.copy(alpha = ka[i] * (1f - 0.6f * press)), r * ks[i], Offset(c.x, c.y + r * (0.20f * q + 0.05f)))
  }
  if (well) {
    // recessed socket: dark on top, lit at the bottom edge
    drawCircle(
      Brush.verticalGradient(0f to Color(0xFF040405), 1f to Color(0xFF5A5A66), startY = c.y - r, endY = c.y + r),
      r,
      c,
    )
  }
  val cy = c.y + (press - 0.5f) * r * 0.12f
  val r2 = r * (if (well) 0.88f else 1f) * (1f - 0.03f * press)
  if (!concave) {
    val b = if (press > 0.5f) darken(base, 0.18f) else base
    drawCircle(
      Brush.radialGradient(
        0f to lighten(b, 0.55f),
        0.35f to b,
        1f to darken(b, 0.6f),
        center = Offset(c.x - 0.28f * r2, cy - 0.38f * r2),
        radius = 1.5f * r2,
      ),
      r2,
      Offset(c.x, cy),
    )
    drawCircle(
      Brush.verticalGradient(
        0f to Color.White.copy(alpha = 0.55f),
        0.5f to Color.White.copy(alpha = 0f),
        1f to Color.Black.copy(alpha = 0.35f),
        startY = cy - r2,
        endY = cy + r2,
      ),
      r2 - 0.6f,
      Offset(c.x, cy),
      style = Stroke(width = maxOf(1f, r * 0.05f)),
    )
    // glossy highlight on the top of the dome
    val sa = 0.55f * (1f - press)
    drawOval(
      Brush.verticalGradient(
        0f to Color.White.copy(alpha = sa),
        1f to Color.White.copy(alpha = 0f),
        startY = cy - 0.72f * r2,
        endY = cy - 0.12f * r2,
      ),
      topLeft = Offset(c.x - 0.62f * r2, cy - 0.42f * r2 - 0.30f * r2),
      size = Size(1.24f * r2, 0.60f * r2),
    )
  } else {
    val b = if (press > 0.5f) darken(base, 0.2f) else base
    drawCircle(
      Brush.radialGradient(
        0f to darken(b, 0.1f),
        0.78f to b,
        1f to lighten(b, 0.30f),
        center = Offset(c.x, cy),
        radius = r2,
      ),
      r2,
      Offset(c.x, cy),
    )
    drawCircle(
      Brush.verticalGradient(
        0f to Color.White.copy(alpha = 0.35f),
        0.5f to Color.White.copy(alpha = 0.05f),
        1f to Color.Black.copy(alpha = 0.4f),
        startY = cy - r2,
        endY = cy + r2,
      ),
      r2 - 0.6f,
      Offset(c.x, cy),
      style = Stroke(width = maxOf(1f, r * 0.05f)),
    )
    // the dish: shadow on the upper inside edge, light on the lower one
    drawCircle(
      Brush.verticalGradient(
        0f to Color.Black.copy(alpha = 0.55f),
        0.55f to Color.Black.copy(alpha = 0.05f),
        1f to Color.White.copy(alpha = 0.14f),
        startY = cy - r2 * 0.72f,
        endY = cy + r2 * 0.72f,
      ),
      r2 * 0.72f,
      Offset(c.x, cy),
    )
  }
}

// ---------------------------------------------------------------------------------------------
// Face buttons: one touch area for the whole cluster, so the thumb can roll from one button to the
// next (and two buttons can be held together) instead of each button being its own tiny target.
// ---------------------------------------------------------------------------------------------
internal class FaceSpec(
  val label: String,
  val key: Int,
  val color: Color,
  val labelColor: Color,
  /** Centre and radius in dp at scale 1. */
  val x: Float,
  val y: Float,
  val r: Float,
  @androidx.annotation.DrawableRes val sprite: Int,
)

private val SegaBase = Color(0xFF2E2E35)
private val SegaLabel = Color(0xFFCFCFD8)

// Genesis 6-button pad: A B C on a rising line, X Y Z above them.
private val SEGA_FACES =
  listOf(
    FaceSpec("X", KeyEvent.KEYCODE_BUTTON_L1, SegaBase, SegaLabel, 30f, 54f, 27f, R.drawable.pad_btn_sega_x),
    FaceSpec("Y", KeyEvent.KEYCODE_BUTTON_X, SegaBase, SegaLabel, 96f, 44f, 27f, R.drawable.pad_btn_sega_y),
    FaceSpec("Z", KeyEvent.KEYCODE_BUTTON_R1, SegaBase, SegaLabel, 162f, 34f, 27f, R.drawable.pad_btn_sega_z),
    FaceSpec("A", KeyEvent.KEYCODE_BUTTON_Y, SegaBase, SegaLabel, 30f, 114f, 27f, R.drawable.pad_btn_sega_a),
    FaceSpec("B", KeyEvent.KEYCODE_BUTTON_B, SegaBase, SegaLabel, 96f, 104f, 27f, R.drawable.pad_btn_sega_b),
    FaceSpec("C", KeyEvent.KEYCODE_BUTTON_A, SegaBase, SegaLabel, 162f, 94f, 27f, R.drawable.pad_btn_sega_c),
  )
private const val SEGA_W = 192f
private const val SEGA_H = 147f

// Neo Geo AES colours: A red, B yellow, C green, D blue (FBNeo fire 1..4 = RetroPad B, A, Y, X).
private val NEO_FACES =
  listOf(
    FaceSpec("A", KeyEvent.KEYCODE_BUTTON_B, Color(0xFFD9202E), Color.White, 30f, 106f, 27f, R.drawable.pad_btn_neo_a),
    FaceSpec("B", KeyEvent.KEYCODE_BUTTON_A, Color(0xFFF2C318), Color(0xFF3B2D00), 94f, 92f, 27f, R.drawable.pad_btn_neo_b),
    FaceSpec("C", KeyEvent.KEYCODE_BUTTON_Y, Color(0xFF1BA84A), Color.White, 58f, 40f, 27f, R.drawable.pad_btn_neo_c),
    FaceSpec("D", KeyEvent.KEYCODE_BUTTON_X, Color(0xFF2B6FDB), Color.White, 122f, 26f, 27f, R.drawable.pad_btn_neo_d),
  )
private const val NEO_W = 152f
private const val NEO_H = 135f

@Composable
internal fun SegaFaces(modifier: Modifier, scale: Float, onKey: (Int, Boolean) -> Unit) =
  FaceCluster(SEGA_FACES, SEGA_W, SEGA_H, scale, concave = true, modifier = modifier, onKey = onKey)

@Composable
internal fun NeoFaces(modifier: Modifier, scale: Float, onKey: (Int, Boolean) -> Unit) =
  FaceCluster(NEO_FACES, NEO_W, NEO_H, scale, concave = false, modifier = modifier, onKey = onKey)

@Composable
private fun FaceCluster(
  specs: List<FaceSpec>,
  width: Float,
  height: Float,
  scale: Float,
  concave: Boolean,
  modifier: Modifier,
  onKey: (Int, Boolean) -> Unit,
) {
  val counts = remember(specs.size) { mutableStateListOf<Int>().also { l -> repeat(specs.size) { l.add(0) } } }
  val haptic = LocalHapticFeedback.current
  val onKeyState = rememberUpdatedState(onKey)

  Box(
    modifier =
      modifier
        .size((width * scale).dp, (height * scale).dp)
        .pointerInput(specs, scale) {
          val dens = density
          awaitEachGesture {
            val owner = HashMap<Long, Int>() // pointer id -> button it is on

            fun hit(p: Offset): Int {
              var best = -1
              var bd = Float.MAX_VALUE
              for (i in specs.indices) {
                val s = specs[i]
                val d = (p - Offset(s.x * scale * dens, s.y * scale * dens)).getDistance()
                if (d <= s.r * scale * dens * 1.3f && d < bd) {
                  bd = d
                  best = i
                }
              }
              return best
            }

            fun down(i: Int) {
              counts[i] = counts[i] + 1
              if (counts[i] == 1) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onKeyState.value(specs[i].key, true)
              }
            }

            fun up(i: Int) {
              counts[i] = maxOf(0, counts[i] - 1)
              if (counts[i] == 0) onKeyState.value(specs[i].key, false)
            }

            fun handle(id: Long, pressed: Boolean, pos: Offset) {
              val cur = owner[id]
              if (!pressed) {
                if (cur != null) {
                  owner.remove(id)
                  up(cur)
                }
                return
              }
              val idx = hit(pos)
              val now = if (idx >= 0) idx else null
              if (now != cur) {
                if (cur != null) up(cur)
                if (now != null) {
                  owner[id] = now
                  down(now)
                } else {
                  owner.remove(id)
                }
              }
            }

            val first = awaitFirstDown(requireUnconsumed = false)
            handle(first.id.value, true, first.position)
            while (true) {
              val ev = awaitPointerEvent()
              for (ch in ev.changes) {
                handle(ch.id.value, ch.pressed, ch.position)
                if (ch.pressed) ch.consume()
              }
              if (ev.changes.none { it.pressed }) break
            }
            for (i in owner.values.toList()) up(i)
            owner.clear()
          }
        },
  ) {
    specs.forEachIndexed { i, s -> FaceVisual(s, counts[i] > 0, scale) }
  }
}

/** Darkens a sprite a little while its button is held (RGB x 0.78, alpha untouched). */
private val PressFilter =
  ColorFilter.colorMatrix(
    ColorMatrix(
      floatArrayOf(
        0.78f, 0f, 0f, 0f, 0f,
        0f, 0.78f, 0f, 0f, 0f,
        0f, 0f, 0.78f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f,
      )
    )
  )

@Composable
private fun FaceVisual(s: FaceSpec, held: Boolean, scale: Float) {
  val p by animateFloatAsState(if (held) 1f else 0f, animationSpec = tween(70), label = "facePress")
  val img = ImageBitmap.imageResource(s.sprite)
  val r = s.r * scale
  val pad = r * 0.4f
  Box(
    modifier = Modifier.offset(x = (s.x * scale - r - pad).dp, y = (s.y * scale - r - pad).dp).size((2f * (r + pad)).dp),
  ) {
    Canvas(Modifier.fillMaxSize()) {
      val rr = r.dp.toPx()
      val q = 1f - p
      // soft shadow under the button (smaller when pressed)
      drawCircle(Color.Black.copy(alpha = 0.30f * (1f - 0.6f * p)), rr * 1.04f, Offset(center.x, center.y + rr * (0.16f * q + 0.05f)))
      // the sprite includes its black rim, so it is drawn slightly larger than the touch circle
      val d = (rr * 2f * 1.06f * (1f - 0.05f * p)).roundToInt()
      val top = (center.y + p * rr * 0.07f - d / 2f).roundToInt()
      drawImage(
        img,
        srcOffset = IntOffset.Zero,
        srcSize = IntSize(img.width, img.height),
        dstOffset = IntOffset((center.x - d / 2f).roundToInt(), top),
        dstSize = IntSize(d, d),
        colorFilter = if (p > 0.5f) PressFilter else null,
        filterQuality = FilterQuality.High,
      )
    }
  }
}

// ---------------------------------------------------------------------------------------------
// Direction input shared by the D-pad and the stick: 8 directions, small diagonal zones so that a
// plain "left" or "down" does not turn into a diagonal by accident.
// ---------------------------------------------------------------------------------------------
private fun computeDirs(p: Offset, w: Float, h: Float, out: BooleanArray) {
  val dx = p.x - w / 2f
  val dy = p.y - h / 2f
  val dead = minOf(w, h) * 0.11f
  val ax = abs(dx)
  val ay = abs(dy)
  val vert = ay > dead && ay >= ax * 0.45f
  val horz = ax > dead && ax >= ay * 0.45f
  out[0] = vert && dy < 0f
  out[1] = vert && dy > 0f
  out[2] = horz && dx < 0f
  out[3] = horz && dx > 0f
}

/** [onDirs] gets (up, down, left, right), the finger position (null = released) and the touch area size. */
private fun Modifier.dirTouch(onDirs: (BooleanArray, Offset?, Float, Float) -> Unit): Modifier =
  pointerInput(Unit) {
    val dirs = BooleanArray(4)
    awaitEachGesture {
      val down = awaitFirstDown(requireUnconsumed = false)
      val w = size.width.toFloat()
      val h = size.height.toFloat()
      computeDirs(down.position, w, h, dirs)
      onDirs(dirs, down.position, w, h)
      while (true) {
        val ev = awaitPointerEvent()
        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
        if (!ch.pressed) break
        computeDirs(ch.position, w, h, dirs)
        onDirs(dirs, ch.position, w, h)
        ch.consume()
      }
      java.util.Arrays.fill(dirs, false)
      onDirs(dirs, null, w, h)
    }
  }

private val DIR_KEYS =
  intArrayOf(KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT)

// ---------------------------------------------------------------------------------------------
// Genesis D-pad: black plus with a dish in the middle and embossed arrows.
// ---------------------------------------------------------------------------------------------
/** Draws the D-pad sprite and shades the arm(s) that are pressed (arm boxes are fractions of the sprite). */
private fun DrawScope.drawDpadSprite(img: ImageBitmap, act: List<Boolean>) {
  val s = size.minDimension
  val ox = (size.width - s) / 2f
  val oy = (size.height - s) / 2f
  drawImage(
    img,
    srcOffset = IntOffset.Zero,
    srcSize = IntSize(img.width, img.height),
    dstOffset = IntOffset(ox.roundToInt(), oy.roundToInt()),
    dstSize = IntSize(s.roundToInt(), s.roundToInt()),
    filterQuality = FilterQuality.High,
  )
  val c = 0.5f
  val hw = 0.10f
  val a = 0.18f
  val b = 0.82f
  val corner = CornerRadius(s * 0.03f)
  val arms =
    listOf(
      Offset(c - hw, a) to Size(2f * hw, c - a), // up
      Offset(c - hw, c) to Size(2f * hw, b - c), // down
      Offset(a, c - hw) to Size(c - a, 2f * hw), // left
      Offset(c, c - hw) to Size(b - c, 2f * hw), // right
    )
  for (i in 0..3) {
    if (!act[i]) continue
    val (o, sz) = arms[i]
    drawRoundRect(Color.Black.copy(alpha = 0.34f), Offset(ox + o.x * s, oy + o.y * s), Size(sz.width * s, sz.height * s), corner)
  }
}

@Composable
internal fun SegaDPad(modifier: Modifier, size: Dp, onKey: (Int, Boolean) -> Unit) {
  val act = remember { mutableStateListOf(false, false, false, false) }
  val haptic = LocalHapticFeedback.current
  val onKeyState = rememberUpdatedState(onKey)
  Box(
    modifier =
      modifier.size(size).dirTouch { d, _, _, _ ->
        for (i in 0..3) {
          if (act[i] != d[i]) {
            act[i] = d[i]
            if (d[i]) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onKeyState.value(DIR_KEYS[i], d[i])
          }
        }
      },
  ) {
    val sprite = ImageBitmap.imageResource(R.drawable.pad_dpad_round)
    Canvas(Modifier.fillMaxSize()) { drawDpadSprite(sprite, act) }
  }
}

// ---------------------------------------------------------------------------------------------
// Neo Geo AES stick: round base, 8-way gate marks, metal shaft and a glossy red ball that follows the thumb.
// ---------------------------------------------------------------------------------------------
@Composable
internal fun NeoStick(modifier: Modifier, size: Dp, onKey: (Int, Boolean) -> Unit) {
  val act = remember { mutableStateListOf(false, false, false, false) }
  var kx by remember { mutableStateOf(0f) } // ball offset as a fraction of the stick size
  var ky by remember { mutableStateOf(0f) }
  var touching by remember { mutableStateOf(false) }
  val haptic = LocalHapticFeedback.current
  val onKeyState = rememberUpdatedState(onKey)
  val spec = if (touching) spring<Float>(dampingRatio = 1f, stiffness = 3000f) else spring<Float>(dampingRatio = 0.5f, stiffness = 500f)
  val ax by animateFloatAsState(kx, animationSpec = spec, label = "stickX")
  val ay by animateFloatAsState(ky, animationSpec = spec, label = "stickY")

  Box(
    modifier =
      modifier.size(size).dirTouch { d, p, w, h ->
        for (i in 0..3) {
          if (act[i] != d[i]) {
            act[i] = d[i]
            if (d[i]) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onKeyState.value(DIR_KEYS[i], d[i])
          }
        }
        touching = p != null
        if (p == null) {
          kx = 0f
          ky = 0f
        } else {
          val dx = (p.x - w / 2f) / w
          val dy = (p.y - h / 2f) / h
          val len = kotlin.math.sqrt(dx * dx + dy * dy)
          val m = 0.2f
          val f = if (len > m) m / len else 1f
          kx = dx * f
          ky = dy * f
        }
      },
  ) {
    Canvas(Modifier.fillMaxSize()) { drawStick(ax, ay) }
  }
}

private fun DrawScope.drawStick(kx: Float, ky: Float) {
  val s = size.minDimension
  val c = center
  // base plate
  drawCircle(Color.Black.copy(alpha = 0.28f), s * 0.5f, Offset(c.x, c.y + s * 0.03f))
  drawCircle(
    Brush.verticalGradient(0f to Color(0xFF6B6B76), 1f to Color(0xFF1D1D23), startY = c.y - s / 2f, endY = c.y + s / 2f),
    s * 0.48f,
    c,
  )
  drawCircle(
    Brush.radialGradient(0f to Color(0xFF3C3C45), 1f to Color(0xFF121216), center = Offset(c.x - s * 0.1f, c.y - s * 0.14f), radius = s * 0.7f),
    s * 0.45f,
    c,
  )
  for (i in 0 until 8) {
    val an = i * Math.PI.toFloat() / 4f
    drawCircle(Color.White.copy(alpha = 0.25f), s * 0.018f, Offset(c.x + cos(an) * s * 0.37f, c.y + sin(an) * s * 0.37f))
  }
  drawCircle(
    Brush.verticalGradient(0f to Color.Black, 1f to Color(0xFF35353D), startY = c.y - s * 0.12f, endY = c.y + s * 0.12f),
    s * 0.12f,
    c,
  )
  // shaft + ball
  val ball = Offset(c.x + kx * s, c.y + ky * s - s * 0.04f)
  drawLine(Color(0xFF70707C), c, ball, strokeWidth = s * 0.075f, cap = StrokeCap.Round)
  drawLine(Color(0xCCD8D8E0), Offset(c.x - s * 0.015f, c.y), Offset(ball.x - s * 0.015f, ball.y), strokeWidth = s * 0.025f, cap = StrokeCap.Round)
  val r = s * 0.23f
  drawCircle(Color.Black.copy(alpha = 0.35f), r * 0.95f, Offset(ball.x + kx * s * 0.12f, ball.y + r * 0.55f + s * 0.035f))
  dome(ball, r, Color(0xFFD9202E), 0f, concave = false, well = false)
}

// ---------------------------------------------------------------------------------------------
// START / MODE / COIN: small rubber buttons.
// ---------------------------------------------------------------------------------------------
@Composable
internal fun SystemButton(label: String, keyCode: Int, press: (Int, Boolean) -> Unit, scale: Float = 1f) {
  var held by remember { mutableStateOf(false) }
  val haptic = LocalHapticFeedback.current
  val p by animateFloatAsState(if (held) 1f else 0f, animationSpec = tween(70), label = "sysPress")
  val w = 82f * scale
  val h = 30f * scale
  val pill = ImageBitmap.imageResource(R.drawable.pad_pill)
  Box(
    modifier =
      Modifier.size(w.dp, (w * 72f / 141f + 4f).dp).pointerInput(keyCode) {
        detectTapGestures(
          onPress = {
            held = true
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            press(keyCode, true)
            try {
              tryAwaitRelease()
            } finally {
              held = false
              press(keyCode, false)
            }
          }
        )
      },
    contentAlignment = Alignment.Center,
  ) {
    Canvas(Modifier.fillMaxSize()) {
      val iw = size.width.roundToInt()
      val ih = (size.width * pill.height / pill.width).roundToInt()
      val top = ((size.height - ih) / 2f + p * 2.dp.toPx()).roundToInt()
      drawImage(
        pill,
        srcOffset = IntOffset.Zero,
        srcSize = IntSize(pill.width, pill.height),
        dstOffset = IntOffset(0, top),
        dstSize = IntSize(iw, ih),
        colorFilter = if (p > 0.5f) PressFilter else null,
        filterQuality = FilterQuality.High,
      )
    }
    Text(
      label,
      color = Color.White.copy(alpha = 0.85f),
      fontSize = (h * 0.38f).sp,
      fontWeight = FontWeight.ExtraBold,
      style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 2f), 3f)),
      modifier = Modifier.offset(y = (-3f + 2f * p).dp),
    )
  }
}

// ---------------------------------------------------------------------------------------------
// All pads of the emulator screen, placed where the HTML overlay's layout expects them
// (portrait: centred at 58% of the control zone under the game picture; landscape: vertically centred).
// ---------------------------------------------------------------------------------------------
@Composable
internal fun EmuPads(
  neo: Boolean,
  maxW: Dp,
  maxH: Dp,
  insetTop: Float,
  insetBottom: Float,
  onKey: (Int, Boolean) -> Unit,
) {
  val w = maxW.value
  val h = maxH.value
  val land = w > h
  val u = (w / 350f).coerceIn(0.8f, 1.15f)
  val px = if (land) 20f else 12f
  val ctrlH = if (land) h - insetTop - insetBottom else maxOf(h - insetTop - w * (224f / 320f) - insetBottom - 36f, 260f)
  val ctrlTop = if (land) insetTop else h - insetBottom - ctrlH
  val cy = ctrlTop + ctrlH * (if (land) 0.5f else 0.58f)
  val padSize = 150f * u
  val faceW = (if (neo) NEO_W else SEGA_W) * u
  val faceH = (if (neo) NEO_H else SEGA_H) * u
  Box(Modifier.fillMaxSize()) {
    Box(Modifier.offset(x = px.dp, y = (cy - padSize / 2f).dp)) {
      if (neo) NeoStick(Modifier, padSize.dp, onKey) else SegaDPad(Modifier, padSize.dp, onKey)
    }
    Box(Modifier.offset(x = (w - px - faceW).dp, y = (cy - faceH / 2f).dp)) {
      if (neo) NeoFaces(Modifier, u, onKey) else SegaFaces(Modifier, u, onKey)
    }
    Row(
      Modifier.align(Alignment.BottomCenter).padding(bottom = insetBottom.dp),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      SystemButton(if (neo) "COIN" else "MODE", KeyEvent.KEYCODE_BUTTON_SELECT, onKey, u)
      SystemButton("START", KeyEvent.KEYCODE_BUTTON_START, onKey, u)
    }
  }
}
