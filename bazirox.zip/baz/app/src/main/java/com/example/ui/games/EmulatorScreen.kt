package com.example.ui.games

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.data.NetplayClient
import com.example.data.NetplayProbe
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextSecondary
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Name of the Genesis Plus GX libretro core inside jniLibs (downloaded by the `fetchGenesisCore` Gradle task). */
private const val GENESIS_CORE = "libgenesis_plus_gx_libretro_android.so"

/** FBNeo libretro core (Neo Geo arcade/AES). Needs neogeo.zip (BIOS) in <filesDir>/fbneo/. */
private const val NEOGEO_CORE = "libfbneo_libretro_android.so"

/**
 * The FBNeo core is big, so it is NOT bundled in the APK: it is downloaded once (arm64 only) into
 * <filesDir>/cores/ and loaded from there by absolute path.
 */
private const val NEOGEO_CORE_URL = "https://buildbot.libretro.com/nightly/android/latest/arm64-v8a/fbneo_libretro_android.so.zip"

private fun neoCoreFile(context: android.content.Context): File = File(File(context.filesDir, "cores"), NEOGEO_CORE)

// ---------------------------------------------------------------------------------------------
// Game library: every game that was added stays on the phone until the player deletes it.
// ---------------------------------------------------------------------------------------------
private class LibGame(val file: File, val romKey: String, val title: String, val neo: Boolean)

private fun thumbFile(context: android.content.Context, romKey: String): File =
  File(File(context.filesDir, "thumbs").apply { mkdirs() }, "$romKey.jpg")

/** Games added earlier. Sega ROMs live in roms/, Neo Geo zips in roms/neogeo/ (romKey = same rule as the picker). */
private fun loadLibrary(context: android.content.Context, neo: Boolean): List<LibGame> {
  val out = ArrayList<LibGame>()
  if (neo) {
    File(context.filesDir, "roms/neogeo").listFiles()?.forEach { f ->
      val n = f.name.lowercase()
      if (f.isFile && n.endsWith(".zip") && n != "neogeo.zip" && f.length() >= 64 * 1024) {
        val base = f.name.removeSuffix(".zip")
        out.add(LibGame(f, "ng_" + base.take(56), base, true))
      }
    }
  } else {
    File(context.filesDir, "roms").listFiles()?.forEach { f ->
      if (f.isFile && f.extension.lowercase() in ROM_EXTENSIONS && f.length() >= 64 * 1024) {
        out.add(LibGame(f, f.nameWithoutExtension, f.nameWithoutExtension.replace('_', ' '), false))
      }
    }
  }
  return out.sortedBy { it.title.lowercase() }
}

/** Removes the game, its preview and every save that belongs to it. */
private fun deleteLibGame(context: android.content.Context, g: LibGame) {
  runCatching { g.file.delete() }
  thumbFile(context, g.romKey).delete()
  File(context.filesDir, "saves").listFiles { x ->
    x.name.startsWith(g.romKey + ".") || (x.name.startsWith("room_") && x.name.endsWith("_" + g.romKey + ".auto.state"))
  }?.forEach { it.delete() }
}

/** Saves a small picture of the running game (what the player sees) as the game's preview. */
private fun captureThumb(view: android.view.View, out: File) {
  try {
    val sv = view as? android.view.SurfaceView ?: return
    val w = sv.width
    val h = sv.height
    if (w <= 0 || h <= 0) return
    val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
    android.view.PixelCopy.request(
      sv,
      bmp,
      { res ->
        try {
          if (res == android.view.PixelCopy.SUCCESS) {
            val tw = 360
            val th = (h * tw / w).coerceAtLeast(1)
            val small = android.graphics.Bitmap.createScaledBitmap(bmp, tw, th, true)
            val tmp = File(out.path + ".tmp")
            tmp.outputStream().use { small.compress(android.graphics.Bitmap.CompressFormat.JPEG, 82, it) }
            tmp.renameTo(out)
            if (small !== bmp) small.recycle()
          }
        } catch (_: Throwable) {
        } finally {
          bmp.recycle()
        }
      },
      Handler(Looper.getMainLooper()),
    )
  } catch (_: Throwable) {}
}

@Composable
private fun GameTile(title: String, neo: Boolean, thumb: File, selected: Boolean, onClick: () -> Unit, onDelete: () -> Unit, modifier: Modifier = Modifier) {
  val shape = RoundedCornerShape(16.dp)
  val stamp = thumb.lastModified()
  val img: ImageBitmap? = remember(thumb.path, stamp) { runCatching { android.graphics.BitmapFactory.decodeFile(thumb.path)?.asImageBitmap() }.getOrNull() }
  Box(
    modifier
      .aspectRatio(1f)
      .clip(shape)
      .background(Color(0xFF0E1426))
      .border(if (selected) 2.dp else 1.dp, if (selected) NeonCyan else Color.White.copy(alpha = 0.14f), shape)
      .clickable(onClick = onClick),
  ) {
    if (img != null) {
      Image(bitmap = img, contentDescription = title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
    } else {
      Text(
        if (neo) "NEO GEO" else "SEGA",
        color = Color.White.copy(alpha = 0.22f),
        fontSize = 15.sp,
        fontWeight = FontWeight.ExtraBold,
        modifier = Modifier.align(Alignment.Center),
      )
    }
    Box(
      Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth()
        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))))
        .padding(horizontal = 6.dp, vertical = 6.dp),
    ) {
      Text(title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    Box(
      Modifier.align(Alignment.TopEnd).padding(5.dp).size(26.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.6f)).clickable(onClick = onDelete),
      contentAlignment = Alignment.Center,
    ) {
      Text("✕", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
  }
}

/** The Neo Geo BIOS (neogeo.zip) ships inside the APK (assets/neogeo.zip); copy it where FBNeo looks for it. */
private fun ensureNeoBios(context: android.content.Context) {
  val sys = File(context.filesDir, "fbneo").apply { mkdirs() }
  val roms = File(context.filesDir, "roms/neogeo").apply { mkdirs() }
  val a = File(sys, "neogeo.zip")
  val b = File(roms, "neogeo.zip")
  if (a.length() > 0 && b.length() > 0) return
  context.assets.open("neogeo.zip").use { input -> a.outputStream().use { input.copyTo(it) } }
  a.copyTo(b, overwrite = true)
}

/** Downloads + unzips the FBNeo core. Returns null on success, otherwise a message for the user. */
private fun downloadNeoCore(context: android.content.Context, onProgress: (Int) -> Unit): String? {
  if (android.os.Build.SUPPORTED_64_BIT_ABIS.none { it == "arm64-v8a" }) return "نئوجئو فقط روی گوشی‌های ۶۴ بیتی (arm64) کار می‌کند"
  val target = neoCoreFile(context)
  val tmp = File(target.parentFile, "$NEOGEO_CORE.part")
  return try {
    target.parentFile?.mkdirs()
    val con = java.net.URL(NEOGEO_CORE_URL).openConnection() as java.net.HttpURLConnection
    con.connectTimeout = 15_000
    con.readTimeout = 30_000
    if (con.responseCode != 200) return "دانلود هسته ناموفق بود (کد ${con.responseCode})"
    val total = con.contentLengthLong
    var got = 0L
    val counting =
      object : java.io.FilterInputStream(con.inputStream.buffered()) {
        override fun read(b: ByteArray, off: Int, len: Int): Int {
          val n = super.read(b, off, len)
          if (n > 0) {
            got += n
            if (total > 0) onProgress(((got * 100) / total).toInt().coerceIn(0, 100))
          }
          return n
        }
      }
    var found = false
    java.util.zip.ZipInputStream(counting).use { zip ->
      var e = zip.nextEntry
      while (e != null) {
        if (e.name.endsWith(".so")) {
          tmp.outputStream().use { zip.copyTo(it) }
          found = true
          break
        }
        e = zip.nextEntry
      }
    }
    if (!found || tmp.length() < 1_000_000L) {
      tmp.delete()
      return "فایل هسته درست دانلود نشد، دوباره امتحان کن"
    }
    target.delete()
    if (!tmp.renameTo(target)) {
      tmp.delete()
      return "ذخیره‌ی هسته ناموفق بود"
    }
    target.setReadOnly()
    null
  } catch (t: Throwable) {
    tmp.delete()
    "دانلود هسته ناموفق بود: اینترنت را بررسی کن"
  }
}

/** Old-style romset prefixes (mslug_c1.rom) -> FBNeo/MAME ids (201-c1.c1). Add more games here. */
private val NEOGEO_IDS = mapOf(
  "mslug" to "201", "mslug2" to "241", "mslug3" to "256", "mslug4" to "263", "mslug5" to "268",
  "mslugx" to "250", "kof98" to "242", "kof99" to "251", "kof2000" to "257", "kof2001" to "262",
  "kof2002" to "265", "samsho" to "045", "samsho2" to "063", "samsho3" to "087", "garou" to "253",
)

/**
 * Rewrites an old-named Neo Geo zip (e.g. mslug_c1.rom) into the layout FBNeo expects
 * (201-c1.c1), flattening folders and dropping readme files. Zips that already use the new
 * names are left untouched. Renaming only fixes names: contents must still match FBNeo's CRCs.
 */
private fun normalizeNeoGeoZip(zipFile: File, setName: String) {
  val id = NEOGEO_IDS[setName] ?: return
  val old = Regex("^" + Regex.escape(setName) + "_([a-z]+\\d+)\\.rom$")
  val tmp = File(zipFile.parentFile, zipFile.name + ".tmp")
  var renamed = 0
  java.util.zip.ZipFile(zipFile).use { zf ->
    if (zf.entries().asSequence().none { old.matches(it.name.substringAfterLast('/').lowercase()) }) return
    java.util.zip.ZipOutputStream(tmp.outputStream().buffered()).use { out ->
      for (e in zf.entries()) {
        if (e.isDirectory) continue
        val base = e.name.substringAfterLast('/').lowercase()
        val m = old.matchEntire(base)
        val newName = when {
          m != null -> { renamed++; "$id-${m.groupValues[1]}.${m.groupValues[1]}" }
          base.endsWith(".html") || base.endsWith(".txt") -> continue
          else -> base
        }
        out.putNextEntry(java.util.zip.ZipEntry(newName))
        zf.getInputStream(e).use { it.copyTo(out) }
        out.closeEntry()
      }
    }
  }
  if (renamed > 0) { zipFile.delete(); tmp.renameTo(zipFile) } else tmp.delete()
}

/** Netplay relay (Node.js on cPanel host). Change here if the worker address ever changes. */
/** Max delay (ms) applied to my own input in online play; keeps the pad responsive on slow links. */
private const val LOCAL_INPUT_DELAY_MAX_MS = 175L

private const val NETPLAY_URL = "https://telemio.ir/netplay"

/** Extra age (ms) of a state snapshot on top of the one-way latency (serialize + compress + transfer + load). Tune if the guest still jumps. */
private const val STATE_AGE_EXTRA_MS = 40L

private fun copyText(context: android.content.Context, text: String) {
  val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
  cm.setPrimaryClip(android.content.ClipData.newPlainText("room", text))
  Toast.makeText(context, "کد کپی شد", Toast.LENGTH_SHORT).show()
}

/** One line of the in-game chat. */
private class ChatMsg(val slot: Int, val text: String) // slot 1 = P1 (left), 2 = P2 (right)

private val P1Color = Color(0xFF38BDF8)
private val P2Color = Color(0xFFFF7AB6)

private val PadBase = Color(0xFF111A33)

private fun padBrush(tint: Color, held: Boolean) =
  if (held) androidx.compose.ui.graphics.Brush.verticalGradient(listOf(tint.copy(alpha = 0.70f), tint.copy(alpha = 0.42f)))
  else androidx.compose.ui.graphics.Brush.verticalGradient(listOf(tint.copy(alpha = 0.28f), PadBase.copy(alpha = 0.74f)))

/** A saved online session (phone-side): code + game. The autosave file is room_<code>_<romKey>.auto.state. */
private class EmuSession(val code: String, val romKey: String, val game: String, val neo: Boolean, val ts: Long)

private object EmuSessions {
  private const val KEY = "sessions"
  private const val MAX = 12

  fun load(p: android.content.SharedPreferences): List<EmuSession> =
    try {
      val a = org.json.JSONArray(p.getString(KEY, "[]"))
      (0 until a.length())
        .map {
          val o = a.getJSONObject(it)
          EmuSession(o.getString("c"), o.optString("r"), o.optString("g"), o.optBoolean("n"), o.optLong("t"))
        }
        .sortedByDescending { it.ts }
    } catch (_: Throwable) {
      emptyList()
    }

  private fun save(p: android.content.SharedPreferences, list: List<EmuSession>) {
    val a = org.json.JSONArray()
    list.sortedByDescending { it.ts }.take(MAX).forEach {
      a.put(org.json.JSONObject().put("c", it.code).put("r", it.romKey).put("g", it.game).put("n", it.neo).put("t", it.ts))
    }
    p.edit().putString(KEY, a.toString()).apply()
  }

  fun upsert(p: android.content.SharedPreferences, s: EmuSession) = save(p, load(p).filter { it.code != s.code } + s)

  fun remove(p: android.content.SharedPreferences, code: String) = save(p, load(p).filter { it.code != code })
}

private fun autoSaveFile(context: android.content.Context, code: String, romKey: String): File =
  File(File(context.filesDir, "saves"), "room_${code}_$romKey.auto.state")

private fun agoText(ts: Long): String {
  val m = (System.currentTimeMillis() - ts) / 60_000
  return when {
    ts <= 0 -> ""
    m < 1 -> "همین الان"
    m < 60 -> "$m دقیقه پیش"
    m < 60 * 24 -> "${m / 60} ساعت پیش"
    else -> "${m / (60 * 24)} روز پیش"
  }
}

private fun shareText(context: android.content.Context, text: String) {
  val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
    type = "text/plain"
    putExtra(android.content.Intent.EXTRA_TEXT, text)
  }
  context.startActivity(android.content.Intent.createChooser(i, null))
}

private fun newRoomCode(): String {
  val chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
  return (1..5).map { chars.random() }.joinToString("")
}

private val ROM_EXTENSIONS = setOf("md", "bin", "gen", "smd", "sms", "gg", "sg")

private val GlassFill = Color.White.copy(alpha = 0.10f)
private val GlassFillPressed = Color.White.copy(alpha = 0.32f)
private val GlassBorder = Color.White.copy(alpha = 0.28f)
private val GlassText = Color.White.copy(alpha = 0.75f)

/**
 * Sega Genesis / Mega Drive emulator screen (libretro Genesis Plus GX via LibretroDroid).
 * The player picks his own ROM file; nothing is bundled in the app.
 */
@Composable
fun EmulatorScreen(playerName: String = "", onBack: () -> Unit) {
  // The rest of the app is RTL; a game pad must always be LTR (left button = left).
  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
    EmulatorContent(playerName, onBack)
  }
}

@Composable
private fun EmulatorContent(playerName: String, onBack: () -> Unit) {
  val context = LocalContext.current
  var romPath by rememberSaveable { mutableStateOf<String?>(null) }
  var romKey by rememberSaveable { mutableStateOf("game") }
  var errorMsg by remember { mutableStateOf<String?>(null) }
  // Online room chosen BEFORE the game starts; the player screen joins it automatically.
  var pendingRoom by rememberSaveable { mutableStateOf<String?>(null) }
  var joinCode by remember { mutableStateOf("") }
  // Offline (one phone) or online (2 phones). Online: the game starts only after the lobby is complete.
  var online by rememberSaveable { mutableStateOf(false) }
  var pickedPath by rememberSaveable { mutableStateOf<String?>(null) }
  var pickedName by rememberSaveable { mutableStateOf<String?>(null) }
  // Lobby state (online): connection, my slot (given by the server by arrival order), friend, game check.
  var net by remember { mutableStateOf<NetplayClient?>(null) }
  var netSlot by remember { mutableStateOf(0) }
  var peerOn by remember { mutableStateOf(false) }
  var peerRomOk by remember { mutableStateOf(false) }
  var romBad by remember { mutableStateOf(false) }
  var lobbyErr by remember { mutableStateOf<String?>(null) }
  var countdown by remember { mutableStateOf(0) }
  val scope = rememberCoroutineScope()
  // Upscaler (GPU shader, no extra lag): 0 CUT (light), 1 CUT2 (balanced), 2 CUT3 (sharpest). Remembered between launches.
  val emuPrefs = remember { context.getSharedPreferences("bazirox_emu", android.content.Context.MODE_PRIVATE) }
  var gfx by remember { mutableStateOf(emuPrefs.getInt("gfx2", 1).coerceIn(0, 2)) }
  var findingServer by remember { mutableStateOf(false) }
  var probeInfo by remember { mutableStateOf<String?>(null) }
  var lobbyPing by remember { mutableStateOf(0L) } // WebSocket round trip (same as in-game), median of the last few samples
  val pingWin = remember { ArrayList<Long>() }

  fun lobbyDisconnect() {
    net?.close()
    net = null
    netSlot = 0
    peerOn = false
    peerRomOk = false
    romBad = false
    countdown = 0
    lobbyPing = 0L
    pingWin.clear()
  }

  fun leaveGame() {
    lobbyDisconnect()
    pendingRoom = null
    romPath = null
  }

  fun onGamePicked(path: String, name: String) {
    pickedPath = path
    pickedName = name
    if (!online) romPath = path // offline: straight into the game
  }
  // false = Sega (Genesis Plus GX), true = Neo Geo (FBNeo, zip romsets + neogeo.zip BIOS)
  var neoGeo by rememberSaveable { mutableStateOf(false) }
  var neoCore by remember { mutableStateOf(neoCoreFile(context).exists()) }
  var coreProgress by remember { mutableStateOf(-1) } // -1 = idle, 0..100 = downloading the Neo Geo core
  var libTick by remember { mutableStateOf(0) } // bumped when a game is added / deleted
  var deleteTarget by remember { mutableStateOf<LibGame?>(null) }

  val picker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
      if (uri == null) return@rememberLauncherForActivityResult
      try {
        val displayName =
          context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
          } ?: (uri.lastPathSegment ?: "game")
        if (neoGeo) {
          // Neo Geo romsets must stay zipped under their original name (e.g. mslug.zip).
          val low = displayName.lowercase().replace(Regex("[^a-z0-9_.-]"), "_")
          if (!low.endsWith(".zip")) {
            errorMsg = "برای نئوجئو فایل زیپ لازم است (مثلا mslug.zip)"
            return@rememberLauncherForActivityResult
          }
          val romDir = File(context.filesDir, "roms/neogeo").apply { mkdirs() }
          if (low == "neogeo.zip") {
            errorMsg = "BIOS داخل خود اپ هست؛ فایل zip بازی را انتخاب کن"
            return@rememberLauncherForActivityResult
          }
          ensureNeoBios(context)
          val game = File(romDir, low)
          context.contentResolver.openInputStream(uri)?.use { input ->
            game.outputStream().use { input.copyTo(it) }
          } ?: throw java.io.IOException("open")
          if (game.length() < 64 * 1024) {
            errorMsg = "فایل بازی معتبر نیست"
            return@rememberLauncherForActivityResult
          }
          runCatching { normalizeNeoGeoZip(game, low.removeSuffix(".zip")) }
          errorMsg = null
          romKey = "ng_" + low.removeSuffix(".zip").take(56)
          libTick++
          onGamePicked(game.absolutePath, low)
          return@rememberLauncherForActivityResult
        }
        val key = displayName.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_").take(60).ifBlank { "game" }
        val dir = File(context.filesDir, "roms").apply { mkdirs() }
        var ext = displayName.substringAfterLast('.', "").lowercase()
        var out = File(dir, "$key.$ext")
        if (ext == "zip") {
          // The emulator core can crash on zip files: extract the ROM inside ourselves.
          var found = false
          java.util.zip.ZipInputStream(context.contentResolver.openInputStream(uri)?.buffered() ?: throw java.io.IOException("open")).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
              val eExt = e.name.substringAfterLast('.', "").lowercase()
              if (!e.isDirectory && eExt in ROM_EXTENSIONS) {
                ext = eExt
                out = File(dir, "$key.$ext")
                out.outputStream().use { zip.copyTo(it) }
                found = true
                break
              }
              e = zip.nextEntry
            }
          }
          if (!found) {
            errorMsg = "داخل زیپ فایل بازی (.md .bin .gen .smd) پیدا نشد"
            return@rememberLauncherForActivityResult
          }
        } else {
          if (ext !in ROM_EXTENSIONS) {
            errorMsg = "این فرمت پشتیبانی نمی‌شود (.md .bin .gen .smd)"
            return@rememberLauncherForActivityResult
          }
          context.contentResolver.openInputStream(uri)?.use { input ->
            out.outputStream().use { input.copyTo(it) }
          } ?: throw java.io.IOException("cannot open file")
        }
        if (out.length() < 64 * 1024) {
          errorMsg = "فایل بازی معتبر نیست"
          return@rememberLauncherForActivityResult
        }
        errorMsg = null
        romKey = key
        libTick++
        onGamePicked(out.absolutePath, out.name)
      } catch (t: Throwable) {
        errorMsg = "خواندن فایل ناموفق بود"
      }
    }

  BackHandler(onBack = { if (romPath != null) leaveGame() else onBack() })

  // ---- Lobby: connect as soon as BOTH a room and a game are chosen ----
  LaunchedEffect(online, pendingRoom) {
    lobbyDisconnect()
    val room = pendingRoom
    if (!online || room == null) return@LaunchedEffect
    lobbyErr = null
    val client =
      NetplayClient(
        baseUrl = NETPLAY_URL,
        room = room,
        romKey = if (pickedPath != null) romKey else "",
        listener =
          object : NetplayClient.Listener {
            override fun onHello(slot: Int, peers: Int) {
              netSlot = slot
              peerOn = peers > 0
              if (peers > 0) net?.sendRom()
            }
            override fun onPeer(on: Boolean) {
              peerOn = on
              if (on) net?.sendRom() else { peerRomOk = false; romBad = false }
            }
            override fun onKey(code: Int, down: Boolean) {}
            override fun onState(bytes: ByteArray) {}
            override fun onRomMismatch() { romBad = true; peerRomOk = false }
            override fun onRomOk() { romBad = false; peerRomOk = true }
            override fun onCmd(action: String) {}
            override fun onPing(rttMs: Long) { if (lobbyPing == 0L) lobbyPing = rttMs }
            override fun onServerPing(rttMs: Long) {
              pingWin.add(rttMs)
              if (pingWin.size > 5) pingWin.removeAt(0)
              lobbyPing = pingWin.sorted()[pingWin.size / 2]
            }
            override fun onClosed(reason: String) {
              lobbyErr = reason
              net = null
              netSlot = 0
              peerOn = false
              peerRomOk = false
              countdown = 0
            }
          },
      )
    net = client
    client.connect()
  }

  // Remember this session on the phone (code + game + last played) so it can be continued later.
  var sessionsTick by remember { mutableStateOf(0) }
  LaunchedEffect(online, pendingRoom, pickedPath, romKey, romPath) {
    val code = pendingRoom ?: return@LaunchedEffect
    if (!online || pickedPath == null) return@LaunchedEffect
    EmuSessions.upsert(emuPrefs, EmuSession(code, romKey, pickedName ?: romKey, neoGeo, System.currentTimeMillis()))
    sessionsTick++
  }

  // Game picked/changed while already in the room: update the check without reconnecting.
  LaunchedEffect(pickedPath, romKey) {
    val c = net ?: return@LaunchedEffect
    c.romKey = if (pickedPath != null) romKey else ""
    peerRomOk = false
    romBad = false
    if (peerOn) c.sendRom()
  }

  // Both in the room + same game -> short countdown, then both phones start the game together.
  LaunchedEffect(online, net, peerOn, peerRomOk, netSlot, romPath) {
    countdown = 0
    if (!online || net == null || !peerOn || !peerRomOk || netSlot == 0 || romPath != null) return@LaunchedEffect
    val p = pickedPath ?: return@LaunchedEffect
    for (i in 3 downTo 1) {
      countdown = i
      delay(1_000)
    }
    countdown = 0
    romPath = p
  }

  Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
    val path = romPath
    if (path == null) {
      val room = pendingRoom
      val canPickGame = !neoGeo || neoCore
      Column(
        modifier =
          Modifier.fillMaxSize()
            .background(ObsidianBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        // ---- Header + console switch ----
        androidx.compose.foundation.Image(
          painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.img_emulator_banner),
          contentDescription = "بخش امولاتور",
          contentScale = androidx.compose.ui.layout.ContentScale.FillWidth,
          modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)),
        )
        // ---- Settings: console / mode / picture, one tidy card ----
        SettingsCard {
          SettingLabel("کنسول")
          SegGroup {
            SegTab("سگا · Genesis", !neoGeo, Modifier.weight(1f)) { neoGeo = false; errorMsg = null }
            SegTab("نئوجئو · Neo Geo", neoGeo, Modifier.weight(1f)) { neoGeo = true; errorMsg = null }
          }
          SettingLabel("حالت بازی")
          SegGroup {
            SegTab("آفلاین · یک گوشی", !online, Modifier.weight(1f)) { online = false; pendingRoom = null; errorMsg = null }
            SegTab("آنلاین · دو نفره", online, Modifier.weight(1f)) { online = true; errorMsg = null }
          }
          SettingLabel("کیفیت تصویر")
          SegGroup {
            listOf("آپ‌اسکیل ۱ · سبک", "آپ‌اسکیل ۲ ✨", "آپ‌اسکیل ۳ · تیز").forEachIndexed { i, label ->
              SegTab(label, gfx == i, Modifier.weight(1f)) { gfx = i; emuPrefs.edit().putInt("gfx2", i).apply() }
            }
          }
        }

        // ---- Step 1: Neo Geo core (the BIOS is bundled in the app) ----
        if (neoGeo) {
          StepCard(
            number = "۱",
            title = "هسته نئوجئو",
            badge = if (neoCore) "✓ آماده" else "لازم است",
            badgeOk = neoCore,
          ) {
            if (!neoCore) {
              Text("هسته‌ی نئوجئو داخل اپ نیست و باید یک‌بار دانلود شود (اینترنت لازم است).", color = TextSecondary, fontSize = 12.sp)
              Spacer(Modifier.size(8.dp))
              PrimaryButton(if (coreProgress >= 0) "در حال دانلود… $coreProgress٪" else "دانلود هسته نئوجئو", enabled = coreProgress < 0) {
                errorMsg = null
                coreProgress = 0
                scope.launch {
                  val err = withContext(Dispatchers.IO) { downloadNeoCore(context) { coreProgress = it } }
                  coreProgress = -1
                  if (err == null) neoCore = true else errorMsg = err
                }
              }
            } else {
              Text("هسته و BIOS نئوجئو آماده‌اند.", color = TextSecondary, fontSize = 12.sp)
            }
          }
        }

        // ---- Step 2: game ----
        StepCard(
          number = if (neoGeo) "۲" else "۱",
          title = "انتخاب بازی",
          badge = if (canPickGame) "آماده" else "اول هسته",
          badgeOk = canPickGame,
        ) {
          Text(
            if (neoGeo) "فایل zip بازی را انتخاب کن، مثلا mslug.zip (اسم فایل را عوض نکن)."
            else "فایل ROM خودت را انتخاب کن. فرمت‌ها: .md .bin .gen .smd",
            color = TextSecondary,
            fontSize = 12.sp,
          )
          Spacer(Modifier.size(8.dp))
          val library = remember(libTick, neoGeo) { loadLibrary(context, neoGeo) }
          if (library.isNotEmpty()) {
            Text("بازی‌های من (یک‌بار اضافه می‌شوند و می‌مانند):", color = TextSecondary, fontSize = 12.sp)
            Spacer(Modifier.size(6.dp))
            library.chunked(3).forEach { rowGames ->
              Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowGames.forEach { g ->
                  GameTile(
                    title = g.title,
                    neo = g.neo,
                    thumb = thumbFile(context, g.romKey),
                    selected = pickedPath == g.file.absolutePath,
                    modifier = Modifier.weight(1f),
                    onClick = {
                      if (!canPickGame) {
                        errorMsg = "اول هسته‌ی نئوجئو را دانلود کن"
                      } else {
                        errorMsg = null
                        if (neoGeo) ensureNeoBios(context)
                        romKey = g.romKey
                        onGamePicked(g.file.absolutePath, g.file.name)
                      }
                    },
                    onDelete = { deleteTarget = g },
                  )
                }
                repeat(3 - rowGames.size) { Spacer(Modifier.weight(1f)) }
              }
              Spacer(Modifier.size(8.dp))
            }
          }
          PrimaryButton(
            if (library.isNotEmpty()) (if (neoGeo) "افزودن بازی جدید (zip)" else "افزودن بازی جدید") else (if (neoGeo) "انتخاب بازی (zip)" else "انتخاب بازی"),
            enabled = canPickGame,
          ) { picker.launch(arrayOf("*/*")) }
          if (online) {
            Spacer(Modifier.size(6.dp))
            Text(
              pickedName?.let { "بازی انتخاب‌شده: $it" } ?: "بعد از انتخاب بازی و ساخت/ورود به سشن، بازی وقتی هر دو نفر آماده باشند شروع می‌شود.",
              color = NeonCyan,
              fontSize = 12.sp,
            )
          }
        }

        deleteTarget?.let { g ->
          AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("حذف بازی") },
            text = { Text("«${g.title}» و ذخیره‌هایش از روی این گوشی پاک شود؟") },
            confirmButton = {
              TextButton(onClick = {
                if (pickedPath == g.file.absolutePath) { pickedPath = null; pickedName = null }
                deleteLibGame(context, g)
                deleteTarget = null
                libTick++
              }) { Text("حذف", color = Color(0xFFFF8A8A)) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("انصراف") } },
          )
        }

        // ---- Step 3: online room (only in online mode) ----
        if (online) StepCard(
          number = if (neoGeo) "۳" else "۲",
          title = "سشن آنلاین ۲ نفره",
          badge = if (room != null) (if (netSlot != 0) "تو P$netSlot" else "…") else "لازم است",
          badgeOk = room != null && netSlot != 0,
        ) {
          if (room == null) {
            // Server ping starts by itself the moment this step shows (Middle East only).
            val probeResults = remember { mutableStateMapOf<Char, NetplayProbe.Result>() }
            var probeRun by remember { mutableStateOf(0) }
            LaunchedEffect(probeRun) {
              probeResults.clear()
              findingServer = true
              NetplayProbe.measure(NETPLAY_URL) { probeResults[it.letter] = it }
              findingServer = false
            }
            val best = if (findingServer) null else NetplayProbe.best(probeResults.values.toList())
            // ---- My sessions (saved on this phone) ----
            val mySessions = remember(sessionsTick, pendingRoom) { EmuSessions.load(emuPrefs).filter { it.neo == neoGeo } }
            if (mySessions.isNotEmpty()) {
              Text("سشن‌های من (روی همین گوشی ذخیره شده‌اند):", color = TextSecondary, fontSize = 12.sp)
              Spacer(Modifier.size(6.dp))
              mySessions.forEach { ses ->
                val hasSave = autoSaveFile(context, ses.code, ses.romKey).let { it.exists() && it.length() > 0 }
                val sameGame = pickedPath != null && romKey == ses.romKey
                SessionRow(
                  title = ses.game.ifBlank { ses.romKey },
                  sub = "کد ${ses.code} · " + (NetplayProbe.regionName(ses.code) ?: "") + " · " + agoText(ses.ts) +
                    (if (hasSave) " · ● ذخیره دارد" else " · ○ جدید"),
                  canContinue = sameGame,
                  hint = "اول همین بازی را انتخاب کن",
                  onContinue = { pendingRoom = ses.code },
                  onDelete = {
                    EmuSessions.remove(emuPrefs, ses.code)
                    File(context.filesDir, "saves").listFiles { x -> x.name.startsWith("room_${ses.code}_") }?.forEach { it.delete() }
                    sessionsTick++
                  },
                )
                Spacer(Modifier.size(6.dp))
              }
              Spacer(Modifier.size(6.dp))
            }
            Text("ساخت سشن جدید (سرور خاورمیانه):", color = TextSecondary, fontSize = 12.sp)
            Spacer(Modifier.size(6.dp))
            NetplayProbe.regionList().forEach { (letter, name) ->
              val r = probeResults[letter]
              ServerRow(
                name = name,
                ms = r?.ms,
                pending = r == null,
                best = r != null && r === best,
                unstable = (r?.lossPct ?: 0) > 0,
                onClick = {
                  if (r != null) {
                    pendingRoom = r.letter.toString() + newRoomCode().take(4)
                  }
                },
              )
              Spacer(Modifier.size(6.dp))
            }
            TextButton(enabled = !findingServer, onClick = { probeRun++ }) { Text("سنجش دوباره", color = TextSecondary) }
            Spacer(Modifier.size(10.dp))
            Text("یا کد سشن دوستت را وارد کن:", color = TextSecondary, fontSize = 12.sp)
            Spacer(Modifier.size(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(
                value = joinCode,
                onValueChange = { joinCode = it.uppercase().filter { ch -> ch.isLetterOrDigit() }.take(8) },
                label = { Text("کد سشن") },
                singleLine = true,
                modifier = Modifier.weight(1f),
              )
              Button(enabled = joinCode.length >= 4, onClick = { pendingRoom = joinCode }) { Text("ورود") }
            }
          } else {
            val roomPing = lobbyPing.takeIf { net != null && it > 0 }
            val status: String
            val statusColor: Color
            when {
              lobbyErr != null -> { status = lobbyErr ?: ""; statusColor = Color(0xFFFF8A8A) }
              net == null || netSlot == 0 -> { status = "در حال اتصال به سشن…"; statusColor = Color(0xFFFFB84D) }
              pickedPath == null -> { status = "وصل شدی (تو بازیکن $netSlot). حالا بازی را انتخاب کن؛ هر دو نفر باید یک بازی را انتخاب کنید."; statusColor = Color(0xFFFFB84D) }
              !peerOn -> { status = "تو بازیکن $netSlot هستی. منتظر ورود دوستت…"; statusColor = Color(0xFFFFB84D) }
              romBad -> { status = "بازی دو طرف یکی نیست! هر دو باید دقیقا یک بازی را انتخاب کنید."; statusColor = Color(0xFFFF8A8A) }
              countdown > 0 -> { status = "هر دو آماده‌اید ✓  شروع بازی در $countdown…"; statusColor = Color(0xFF4ADE80) }
              else -> { status = "دوستت وصل شد؛ در حال بررسی بازی…"; statusColor = NeonCyan }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
              Text("کد سشن", color = TextSecondary, fontSize = 12.sp)
              SelectionContainer {
                Text(room, color = NeonCyan, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
              }
              Text(
                roomPing?.let { "پینگ سرور: $it ms" }
                  ?: net?.connectMs?.takeIf { it > 0 }?.let { "زمان اتصال: $it ms (پینگ بعد از آپدیت ورکر نشان داده می‌شود)" }
                  ?: "پینگ سرور: …",
                color = if ((roomPing ?: 999L) <= 150L) NeonCyan else Color(0xFFFFB84D),
                fontSize = 12.sp,
              )
              NetplayProbe.regionName(room)?.let {
                Text("منطقه سرور: $it", color = TextSecondary, fontSize = 12.sp)
              }
              Spacer(Modifier.size(8.dp))
              Text(status, color = statusColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
              Spacer(Modifier.size(6.dp))
              Text(
                "بازی فقط وقتی شروع می‌شود که هر دو نفر در سشن باشند و بازی یکی باشد. پیشرفت بازی هر ۶ ثانیه روی گوشی ذخیره می‌شود؛ هر وقت با همین کد برگردید، از همان‌جا ادامه می‌دهید.",
                color = TextSecondary,
                fontSize = 12.sp,
              )
              Spacer(Modifier.size(6.dp))
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { copyText(context, room) }) { Text("کپی کد") }
                Button(
                  onClick = { shareText(context, "بیا با هم بازی کنیم! کد سشن بازیروکس: $room") },
                  colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.12f), contentColor = Color.White),
                ) { Text("اشتراک") }
                TextButton(onClick = { pendingRoom = null }) { Text("خروج از سشن", color = TextSecondary) }
              }
            }
          }
        }

        errorMsg?.let {
          Box(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFFFF6B6B).copy(alpha = 0.14f))
                .border(1.dp, Color(0xFFFF6B6B).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(12.dp),
          ) {
            Text(it, color = Color(0xFFFF8A8A), fontSize = 13.sp)
          }
        }

        TextButton(onClick = onBack) { Text("بازگشت", color = TextSecondary) }
      }
    } else {
      // Online but the connection is gone (e.g. app restarted): back to the lobby.
      val live = net
      if (online && (live == null || netSlot == 0)) {
        LaunchedEffect(Unit) { leaveGame() }
      } else {
        EmulatorPlayer(romPath = path, romKey = romKey, neoGeo = neoGeo, gfx = gfx, net = if (online) live else null, slot = if (online) netSlot else 0, playerName = playerName, onExit = { leaveGame() })
      }
    }
  }
}

@Composable
private fun EmulatorPlayer(romPath: String, romKey: String, neoGeo: Boolean, gfx: Int, net: NetplayClient?, slot: Int, playerName: String, onExit: () -> Unit) {
  val context = LocalContext.current
  val activity = context as ComponentActivity
  val scope = rememberCoroutineScope()

  val savesDir = remember { File(context.filesDir, "saves").apply { mkdirs() } }
  val sramFile = File(savesDir, "$romKey.srm")
  // Save-state slots 1..5 (slot 1 also reads the old single-slot file so earlier saves still load).
  var saveSlot by rememberSaveable { mutableStateOf(1) }
  fun stateFileFor(n: Int): File {
    val f = File(savesDir, "$romKey.s$n.state")
    if (n == 1 && !f.exists()) {
      val legacy = File(savesDir, "$romKey.state")
      if (legacy.exists()) return legacy
    }
    return f
  }
  var saveTick by remember { mutableStateOf(0) } // bumped after each save so the slot label refreshes
  fun slotStatus(): String {
    saveTick.let { }
    val f = stateFileFor(saveSlot)
    if (!f.exists()) return "خالی"
    return java.text.SimpleDateFormat("MM/dd HH:mm", java.util.Locale.US).format(java.util.Date(f.lastModified()))
  }

  val retroView =
    remember(romPath) {
      if (neoGeo) runCatching { ensureNeoBios(context) }
      val data =
        GLRetroViewData(context).apply {
          coreFilePath = if (neoGeo) neoCoreFile(context).absolutePath else GENESIS_CORE
          gameFilePath = romPath
          shader =
            when (gfx) {
              0 -> ShaderConfig.CUT()
              2 -> ShaderConfig.CUT3()
              else -> ShaderConfig.CUT2() // balanced: smooth edges, crisp pixels
            }
          systemDirectory = context.filesDir.absolutePath
          savesDirectory = savesDir.absolutePath
          // Restore in-game save (battery RAM) if one exists.
          if (sramFile.exists()) saveRAMState = sramFile.readBytes()
        }
      GLRetroView(context, data)
    }

  fun saveSram() {
    scope.launch(Dispatchers.IO) {
      try {
        val bytes = retroView.serializeSRAM()
        if (bytes.isNotEmpty()) sramFile.writeBytes(bytes)
      } catch (_: Throwable) {}
    }
  }

  DisposableEffect(retroView) {
    activity.lifecycle.addObserver(retroView)
    val saver = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_PAUSE) saveSram() }
    activity.lifecycle.addObserver(saver)
    onDispose {
      saveSram()
      activity.lifecycle.removeObserver(saver)
      activity.lifecycle.removeObserver(retroView)
    }
  }

  // Auto-save in-game saves every few seconds.
  LaunchedEffect(retroView) {
    while (true) {
      delay(8_000)
      saveSram()
    }
  }

  // ---- Online (room) mode ----
  // `net`/`slot` come from the lobby: slot 0 = offline, 1 = host (player 1), 2 = guest (player 2).
  var localP2 by remember { mutableStateOf(false) } // offline, one phone: false = controls drive player 1, true = player 2
  var peerOn by remember { mutableStateOf(net != null) }
  var resumed by remember { mutableStateOf(false) } // this room continued from its autosave
  var pingMs by remember { mutableStateOf(0L) }
  val lastDue = remember { longArrayOf(0L) }
  val lastInput = remember { longArrayOf(0L) } // last key event (mine or the peer's)
  val lastPush = remember { longArrayOf(0L) } // host: last time a state was sent
  val syncReq = remember { Channel<Unit>(Channel.CONFLATED) } // host: "send a state now"
  val ffJob = remember { arrayOfNulls<Job>(1) } // guest: catch-up after loading a state
  // Autosave exchange: both phones tell each other how old their save is; the newer one is used.
  val myAuto = remember { longArrayOf(-1L) }
  val peerAuto = remember { longArrayOf(-1L) }
  val autoSent = remember { booleanArrayOf(false) }
  val adoptNext = remember { booleanArrayOf(false) } // host: the next state from the guest is a newer save to adopt
  // In-game chat (online only): drawn by the HTML overlay (assets/emu_ui/index.html).
  var chatOpen by remember { mutableStateOf(false) } // chat sheet open (so Back closes it first)
  var peerName by remember { mutableStateOf("") }
  val ui = remember { EmuUi(context) }
  DisposableEffect(ui) {
    val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_PAUSE) ui.releaseKeys() }
    activity.lifecycle.addObserver(o)
    onDispose { activity.lifecycle.removeObserver(o) }
  }

  @Suppress("UNUSED_PARAMETER")
  fun addMsg(m: ChatMsg, mine: Boolean) = ui.addMsg(m.slot, m.text)
  val exitRef = remember { arrayOfNulls<() -> Unit>(1) } // set below: "save the autosave, then leave"

  fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

  fun press(code: Int, down: Boolean) {
    lastInput[0] = SystemClock.elapsedRealtime()
    val action = if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP
    val n = net
    if (n != null && slot != 0 && peerOn) {
      n.sendKey(code, down)
      // Apply my own input after ~one-way latency so both phones see the same timing.
      val now = SystemClock.elapsedRealtime()
      // Cap the self-delay so the pad never feels heavy; order of my own keys is still preserved via lastDue.
      val due = maxOf(now + minOf(n.oneWayMs + NetplayClient.JITTER_BUFFER_MS, LOCAL_INPUT_DELAY_MAX_MS), lastDue[0])
      lastDue[0] = due
      val port = slot - 1
      if (due <= now) {
        // no delay needed: send instantly, skip the coroutine hop
        retroView.sendKeyEvent(action, code, port)
      } else {
        scope.launch {
          delay(due - now)
          retroView.sendKeyEvent(action, code, port)
        }
      }
    } else {
      retroView.sendKeyEvent(action, code, if (slot == 2 || (slot == 0 && localP2)) 1 else 0)
    }
  }

  // ---- Save / load (online: the host's state is the shared one) ----
  suspend fun saveLocal(): Boolean =
    withContext(Dispatchers.IO) {
      try {
        val sf = File(savesDir, "$romKey.s$saveSlot.state")
        sf.writeBytes(retroView.serializeState())
        captureThumb(retroView, thumbFile(context, romKey)) // the game's preview = last manual save
        saveTick++
        true
      } catch (_: Throwable) {
        false
      }
    }

  /** 1 = loaded, 0 = failed, -1 = nothing saved yet. */
  suspend fun loadLocal(): Int {
    if (!stateFileFor(saveSlot).exists()) return -1
    return withContext(Dispatchers.IO) {
      try {
        if (retroView.unserializeState(stateFileFor(saveSlot).readBytes())) 1 else 0
      } catch (_: Throwable) {
        0
      }
    }
  }

  fun saveState() {
    val n = net
    scope.launch {
      if (n != null && peerOn && slot == 2) {
        n.sendCmd("save") // the host saves; both players get the result
        return@launch
      }
      val ok = saveLocal()
      toast(if (ok) "ذخیره شد" else "ذخیره ناموفق بود")
      if (n != null && peerOn) n.sendCmd(if (ok) "saved" else "savefail")
    }
  }

  fun loadState() {
    val n = net
    scope.launch {
      if (n != null && peerOn && slot == 2) {
        n.sendCmd("load") // the host loads and pushes the state to both
        return@launch
      }
      val r = loadLocal()
      toast(
        when (r) {
          1 -> "بارگذاری شد"
          -1 -> "هنوز چیزی ذخیره نکردی"
          else -> "بارگذاری ناموفق بود"
        },
      )
      if (n != null && peerOn) {
        when (r) {
          1 -> {
            n.sendCmd("loaded")
            syncReq.trySend(Unit) // guest gets the loaded state right away
          }
          -1 -> n.sendCmd("nosave")
          else -> n.sendCmd("loadfail")
        }
      }
    }
  }

  val netListener =
    object : NetplayClient.Listener {
      override fun onHello(s: Int, peers: Int) {
        peerOn = peers > 0
      }
      override fun onPeer(on: Boolean) {
        peerOn = on
      }
      override fun onKey(c: Int, d: Boolean) {
        lastInput[0] = SystemClock.elapsedRealtime()
        val port = if (slot == 1) 1 else 0
        retroView.sendKeyEvent(if (d) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, c, port)
      }
      override fun onState(bytes: ByteArray) {
        if (slot == 1) {
          if (!adoptNext[0]) return
          adoptNext[0] = false
          scope.launch {
            val ok =
              withContext(Dispatchers.IO) {
                try {
                  retroView.unserializeState(bytes)
                } catch (_: Throwable) {
                  false
                }
              }
            if (ok) {
              resumed = true
              toast("ادامه از ذخیره‌ی جدیدتر دوستت ✓")
              syncReq.trySend(Unit)
            }
          }
          return
        }
        if (slot != 2) return
        val age = ((net?.oneWayMs ?: 50L) + STATE_AGE_EXTRA_MS).coerceIn(30L, 250L)
        ffJob[0]?.cancel()
        ffJob[0] =
          scope.launch {
            val ok =
              withContext(Dispatchers.IO) {
                try {
                  retroView.unserializeState(bytes)
                } catch (_: Throwable) {
                  false
                }
              }
            if (ok) {
              // The snapshot is already `age` ms old: run faster for that long so this
              // screen catches up with the host instead of jumping back in time.
              try {
                retroView.frameSpeed = 2
                delay(age)
              } finally {
                retroView.frameSpeed = 1
              }
            }
          }
      }
      override fun onCmd(action: String) {
        when (action) {
          "save" -> if (slot == 1) saveState()
          "load" -> if (slot == 1) loadState()
          "resumed" -> { resumed = true; toast("ادامه از آخرین ذخیره‌ی این سشن ✓") }
          "saved" -> toast("ذخیره شد")
          "savefail" -> toast("ذخیره ناموفق بود")
          "loaded" -> toast("بارگذاری شد")
          "nosave" -> toast("هنوز چیزی ذخیره نشده")
          "loadfail" -> toast("بارگذاری ناموفق بود")
          "adopt" -> adoptNext[0] = true
          "needfull" -> if (slot == 1) syncReq.trySend(Unit)
          else ->
            if (action.startsWith("auto:")) {
              peerAuto[0] = action.removePrefix("auto:").toLongOrNull() ?: 0L
              if (!autoSent[0] && myAuto[0] >= 0) {
                autoSent[0] = true
                net?.sendCmd("auto:${myAuto[0]}")
              }
            }
        }
      }
      override fun onRomMismatch() = toast("بازی دو طرف یکی نیست!")
      override fun onChat(text: String) {
        addMsg(ChatMsg(if (slot == 1) 2 else 1, text.take(300)), false)
      }
      override fun onPeerName(name: String) {
        peerName = name.take(20)
      }
      override fun onPing(rttMs: Long) {
        pingMs = rttMs
      }
      override fun onClosed(reason: String) {
        toast(reason)
        (exitRef[0] ?: onExit)() // connection lost: save, then back to the menu
      }
    }

  // Take over the lobby's connection (same socket, same slot) for the game.
  DisposableEffect(net) {
    net?.listener = netListener
    onDispose {}
  }

  suspend fun pushState(n: NetplayClient) {
    withContext(Dispatchers.IO) {
      try {
        n.sendState(retroView.serializeState())
      } catch (_: Throwable) {}
    }
    lastPush[0] = SystemClock.elapsedRealtime()
  }

  // Host: send a state when the guest joins, on load, when play settles after button presses
  // (so the correction is invisible), and rarely as a safety net while play never stops.
  LaunchedEffect(net, slot, peerOn) {
    val n = net
    if (n == null || !peerOn) return@LaunchedEffect
    n.sendRom()
    if (slot != 1) return@LaunchedEffect
    delay(2_500) // both phones just started the game: let it boot before the first state is sent
    pushState(n)
    while (true) {
      delay(150)
      val now = SystemClock.elapsedRealtime()
      val dirty = lastInput[0] > lastPush[0]
      val requested = syncReq.tryReceive().isSuccess
      // Each state is big (hundreds of KB): while it travels, the guest's pings and key presses wait
      // behind it (ping jumps up) and loading it makes his screen hitch. So send them rarely, and on a
      // slow link even more rarely.
      val slow = pingMs > 140L
      val gapOk = now - lastPush[0] >= (if (slow) 10_000L else 5_000L)
      val settled = dirty && gapOk && now - lastInput[0] >= (if (slow) 2_000L else 1_000L)
      val busy = dirty && now - lastPush[0] >= (if (slow) 30_000L else 15_000L)
      val heartbeat = now - lastPush[0] >= (if (slow) 60_000L else 30_000L)
      if (requested || settled || busy || heartbeat) pushState(n)
    }
  }

  // ---- Room autosave: same room code + same game -> continue where you left off ----
  // Both phones write the state every few seconds (the guest's copy is the host's, synced), so
  // whoever becomes player 1 next time has it. The host loads it right after the game boots.
  val autoFile = remember(net) { net?.let { File(savesDir, "room_${it.room}_$romKey.auto.state") } }

  suspend fun saveAutoNow() {
    val f = autoFile ?: return
    if (slot == 0) return
    withContext(Dispatchers.IO) {
      try {
        val tmp = File(f.path + ".tmp")
        tmp.writeBytes(retroView.serializeState())
        tmp.renameTo(f) // write-then-rename: a crash never leaves a half file
      } catch (_: Throwable) {}
    }
  }

  // Leaving (back button, exit chip, lost connection): write the autosave first, so nothing since the last 6 s tick is lost.
  fun exitSaving() {
    scope.launch {
      saveAutoNow()
      // No preview yet (never pressed save): use the last frame so the game still gets a picture.
      val tf = thumbFile(context, romKey)
      if (!tf.exists()) {
        captureThumb(retroView, tf)
        delay(250)
      }
      onExit()
    }
  }
  exitRef[0] = { exitSaving() }
  BackHandler(onBack = { exitSaving() })
  BackHandler(enabled = chatOpen) { ui.closeChat() } // registered later = wins: back closes the chat first

  fun sendChat(t: String) {
    val x = t.trim().take(300)
    val n = net ?: return
    if (x.isEmpty()) return
    if (!peerOn) {
      toast("دوستت الان در سشن نیست")
      return
    }
    n.sendChat(x)
    addMsg(ChatMsg(slot, x), true)
  }

  // Names above the screen: mine from the account, the friend's arrives over the relay.
  val myShown = playerName.ifBlank { "P$slot" }
  val name1 = if (slot == 1) myShown else peerName.ifBlank { "P1" }
  val name2 = if (slot == 2) myShown else peerName.ifBlank { "P2" }
  LaunchedEffect(net, peerOn) {
    val n = net ?: return@LaunchedEffect
    if (!peerOn || playerName.isBlank()) return@LaunchedEffect
    n.sendName(playerName) // sent three times: the friend's screen may still be starting up
    delay(1_500)
    n.sendName(playerName)
    delay(3_000)
    n.sendName(playerName)
  }


  LaunchedEffect(net, slot) {
    val f = autoFile ?: return@LaunchedEffect
    if (slot == 0) return@LaunchedEffect
    withContext(Dispatchers.IO) {
      try {
        if (f.exists()) f.copyTo(File(f.path + ".bak"), overwrite = true) // safety copy of the previous session
        // Keep the folder small: only the 12 newest session autosaves.
        savesDir.listFiles { x -> x.name.startsWith("room_") && x.name.endsWith(".auto.state") }
          ?.sortedByDescending { it.lastModified() }?.drop(12)?.forEach { it.delete(); File(it.path + ".bak").delete() }
      } catch (_: Throwable) {}
    }
    delay(1_500) // let the core boot
    // Tell the friend how old my save is and wait (max 3 s) for theirs: the NEWER save wins, whoever has it.
    val myTs = if (f.exists() && f.length() > 0) f.lastModified() else 0L
    myAuto[0] = myTs
    if (!autoSent[0] && net != null) {
      autoSent[0] = true
      net.sendCmd("auto:$myTs")
    }
    var waited = 0
    while (peerAuto[0] < 0 && peerOn && waited < 3_000) {
      delay(100)
      waited += 100
    }
    val peerTs = peerAuto[0].coerceAtLeast(0L)
    // Phone clocks can differ a little: saves within 20 s of each other count as the same.
    val iAmNewer = myTs > 0 && myTs - peerTs > 20_000
    val peerNewer = peerTs > 0 && peerTs - myTs > 20_000
    if (slot == 1 && myTs > 0 && !peerNewer) {
      val ok =
        withContext(Dispatchers.IO) {
          try {
            retroView.unserializeState(f.readBytes())
          } catch (_: Throwable) {
            false
          }
        }
      if (ok) {
        resumed = true
        toast("ادامه از آخرین ذخیره‌ی این سشن ✓")
        net?.sendCmd("resumed")
        syncReq.trySend(Unit) // the guest gets this state right away
      }
    } else if (slot == 2 && iAmNewer) {
      // My save is newer than the host's (or he has none): load it and hand it to the host.
      val ok =
        withContext(Dispatchers.IO) {
          try {
            retroView.unserializeState(f.readBytes())
          } catch (_: Throwable) {
            false
          }
        }
      if (ok) {
        resumed = true
        toast("ادامه از آخرین ذخیره‌ی این سشن ✓")
        val n = net
        if (n != null && peerOn) {
          n.sendCmd("adopt")
          pushState(n)
        }
      }
    }
    while (true) {
      delay(6_000)
      saveAutoNow()
    }
  }

  // Neo Geo two-player: once both players are in the room, each side inserts a coin and presses
  // its own START (host = P1, guest = P2), so the game starts in 2-player mode by itself.
  var autoStarted by remember { mutableStateOf(false) }

  // One coin + my own START (P1 on the host, P2 on the guest). Used by the auto-start and the button.
  suspend fun insertCoinAndStart() {
    press(KeyEvent.KEYCODE_BUTTON_SELECT, true)
    delay(120)
    press(KeyEvent.KEYCODE_BUTTON_SELECT, false)
    delay(1_200)
    press(KeyEvent.KEYCODE_BUTTON_START, true)
    delay(120)
    press(KeyEvent.KEYCODE_BUTTON_START, false)
  }

  LaunchedEffect(net, slot, peerOn) {
    if (!neoGeo || net == null || !peerOn || slot == 0 || autoStarted) return@LaunchedEffect
    autoStarted = true
    toast("هر دو بازیکن آماده‌اند... شروع خودکار")
    delay(6_000) // both phones started together: wait for the BIOS/intro, host's first state reaches the guest
    if (resumed) return@LaunchedEffect // continuing a saved game: no coin/START needed
    insertCoinAndStart()
  }

  // ---- HTML overlay wiring ----
  // Mask bit order (assets/emu_ui/index.html BIT): U D L R A B C X Y Z D(neo) START MODE/COIN
  ui.keys =
    if (neoGeo)
      intArrayOf(
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
        KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_Y, -1, -1, -1,
        KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT,
      )
    else
      intArrayOf(
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
        KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_A,
        KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_R1, -1,
        KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT,
      )
  ui.onKey = { code, down -> press(code, down) }
  ui.onChat = { sendChat(it) }
  ui.onChatOpen = { chatOpen = it }
  ui.onAct = { act ->
    when (act) {
      "copy" -> net?.let { copyText(context, it.room) }
      "swap" ->
        if (net == null) {
          // Release everything first so no key stays "stuck" on the previous player.
          for (port in 0..1) for (k in listOf(
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
            KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT,
          )) retroView.sendKeyEvent(KeyEvent.ACTION_UP, k, port)
          localP2 = !localP2
        }
      "duo" -> if (neoGeo && net != null && peerOn) scope.launch { insertCoinAndStart() }
      "slot" -> saveSlot = if (saveSlot >= 5) 1 else saveSlot + 1
      "save" -> saveState()
      "load" -> loadState()
      "exit" -> exitSaving()
    }
  }

  val density = LocalDensity.current
  val insetTop = with(density) { WindowInsets.statusBars.getTop(this).toDp().value }
  val insetBottom = with(density) { WindowInsets.navigationBars.getBottom(this).toDp().value }
  val stateJson =
    org.json.JSONObject()
      .put("neo", neoGeo)
      .put("net", net != null)
      .put("room", net?.room ?: "")
      .put("slot", slot)
      .put("peerOn", peerOn)
      .put("ping", pingMs)
      .put("p2", localP2)
      .put("slotNo", saveSlot)
      .put("slotFull", slotStatus() != "خالی")
      .put("name1", name1)
      .put("name2", name2)
      .put("sat", insetTop.toDouble())
      .put("sab", insetBottom.toDouble())
      .toString()
  SideEffect { ui.push(stateJson) }

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val landscape = maxWidth > maxHeight

    // Background art behind the game, pads and chips (shows in the black areas around the game picture).
    androidx.compose.foundation.Image(
      painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.bg_emulator_game),
      contentDescription = null,
      contentScale = androidx.compose.ui.layout.ContentScale.Crop,
      modifier = Modifier.fillMaxSize(),
    )
    // Dark scrim so the pads and buttons stay readable over the art.
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.25f)))

    // One single emulator view for both orientations (a view can't be re-parented).
    AndroidView(
      factory = { retroView },
      modifier =
        if (landscape) Modifier.align(Alignment.Center).fillMaxHeight().aspectRatio(320f / 224f)
        else Modifier.align(Alignment.TopCenter).statusBarsPadding().fillMaxWidth().aspectRatio(320f / 224f),
    )

    // Chips, names and chat: HTML/CSS on top of the game.
    EmuOverlay(ui, Modifier.fillMaxSize().imePadding())

    // Pads and system buttons: native sprites above the overlay (touch goes straight to the game, no WebView hop).
    if (!ui.padsHidden) {
      EmuPads(neoGeo, maxWidth, maxHeight, insetTop, insetBottom) { code, down -> ui.key(code, down) }
    }
  }
}

@Composable
private fun SegGroup(content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) {
  Row(
    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.08f)).padding(4.dp),
    horizontalArrangement = Arrangement.spacedBy(4.dp),
    content = content,
  )
}

@Composable
private fun SettingLabel(text: String) {
  Text(text, color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
  val shape = RoundedCornerShape(20.dp)
  Column(
    modifier =
      Modifier.fillMaxWidth()
        .clip(shape)
        .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.09f), Color.White.copy(alpha = 0.04f))))
        .border(1.dp, Color.White.copy(alpha = 0.14f), shape)
        .padding(14.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    content()
  }
}

@Composable
private fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
  Button(onClick = onClick, enabled = enabled, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().height(48.dp)) {
    Text(text, fontWeight = FontWeight.Bold)
  }
}

@Composable
private fun ServerRow(name: String, ms: Long?, pending: Boolean, best: Boolean, unstable: Boolean, onClick: () -> Unit) {
  val shape = RoundedCornerShape(14.dp)
  val enabled = !pending && ms != null
  val dot =
    when {
      !enabled -> Color(0xFF6B7280)
      ms!! <= 120 -> Color(0xFF4ADE80)
      ms <= 220 -> Color(0xFFFFB84D)
      else -> Color(0xFFFF6B6B)
    }
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .clip(shape)
        .background(if (best) NeonCyan.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.06f))
        .border(1.dp, if (best) NeonCyan else Color.White.copy(alpha = 0.14f), shape)
        .then(if (enabled) Modifier.pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) } else Modifier)
        .padding(horizontal = 14.dp, vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(dot))
    Text(
      (if (best) "★ " else "") + name,
      color = if (enabled || pending) Color.White else GlassText,
      fontSize = 14.sp,
      fontWeight = FontWeight.Bold,
      modifier = Modifier.weight(1f),
    )
    Text(
      when {
        pending -> "در حال سنجش…"
        ms == null -> "در دسترس نیست"
        else -> "\u2066${ms}ms\u2069" + (if (unstable) " · ناپایدار" else "")
      },
      color = if (enabled) dot else TextSecondary,
      fontSize = 13.sp,
      fontWeight = FontWeight.Medium,
    )
  }
}

@Composable
private fun SessionRow(
  title: String,
  sub: String,
  canContinue: Boolean,
  hint: String,
  onContinue: () -> Unit,
  onDelete: () -> Unit,
) {
  val shape = RoundedCornerShape(14.dp)
  var confirm by remember { mutableStateOf(false) }
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .clip(shape)
        .background(Color.White.copy(alpha = 0.06f))
        .border(1.dp, Color.White.copy(alpha = 0.14f), shape)
        .padding(horizontal = 14.dp, vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
      Text(sub, color = TextSecondary, fontSize = 11.sp)
      if (!canContinue) Text(hint, color = Color(0xFFFFB84D), fontSize = 11.sp)
    }
    if (canContinue) Button(onClick = onContinue, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 4.dp)) { Text("ادامه") }
    TextButton(onClick = { if (confirm) onDelete() else confirm = true }) {
      Text(if (confirm) "مطمئنی؟" else "حذف", color = if (confirm) Color(0xFFFF8A8A) else TextSecondary, fontSize = 12.sp)
    }
  }
}

@Composable
private fun SegTab(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
  val shape = RoundedCornerShape(10.dp)
  Box(
    modifier =
      modifier
        .clip(shape)
        .background(if (selected) NeonCyan else Color.Transparent)
        .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) }
        .padding(horizontal = 8.dp, vertical = 10.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      label,
      color = if (selected) ObsidianBg else TextSecondary,
      fontSize = 13.sp,
      fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium,
      maxLines = 1,
    )
  }
}

@Composable
private fun StepCard(
  number: String,
  title: String,
  badge: String,
  badgeOk: Boolean,
  content: @Composable () -> Unit,
) {
  val shape = RoundedCornerShape(20.dp)
  Column(
    modifier =
      Modifier.fillMaxWidth()
        .clip(shape)
        .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.09f), Color.White.copy(alpha = 0.04f))))
        .border(1.dp, Color.White.copy(alpha = 0.14f), shape)
        .padding(16.dp),
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      Box(
        modifier = Modifier.size(28.dp).clip(CircleShape).background(NeonCyan),
        contentAlignment = Alignment.Center,
      ) {
        Text(number, color = ObsidianBg, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
      }
      Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
      Text(
        badge,
        color = if (badgeOk) Color(0xFF4ADE80) else Color(0xFFFFB84D),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
      )
    }
    Spacer(Modifier.size(10.dp))
    content()
  }
}
