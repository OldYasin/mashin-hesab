package com.example.ui.games

import android.net.Uri
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.data.NetplayClient
import com.example.data.NetplayProbe
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextSecondary
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Name of the Genesis Plus GX libretro core inside jniLibs (downloaded by the `fetchGenesisCore` Gradle task). */
private const val GENESIS_CORE = "libgenesis_plus_gx_libretro_android.so"

/** FBNeo libretro core (Neo Geo arcade/AES). Needs neogeo.zip (BIOS) in <filesDir>/fbneo/. */
private const val NEOGEO_CORE = "libfbneo_libretro_android.so"

/** Old-style romset prefixes (mslug_c1.rom) -> FBNeo/MAME ids (201-c1.c1). Add more games here. */
private val NEOGEO_IDS = mapOf(
  "mslug" to "201", "mslug2" to "241", "mslug3" to "256", "mslug4" to "263", "mslug5" to "268",
  "mslugx" to "250", "kof98" to "242", "kof99" to "251", "kof2000" to "257", "kof2001" to "262",
  "kof2002" to "265", "samsho" to "045", "samsho2" to "063", "samsho3" to "087", "garou" to "253",
)

/**
 * Rewrites an old-named Neo Geo zip (e.g. mslug_c1.rom) into the layout FBNeo expects
 * (201-c1.c1), flattening folders and dropping readme files. Zips that already use the new
 * names are left untouched. Renaming only fixes names: contents must still match FBNeo's CRCs.
 */
private fun normalizeNeoGeoZip(zipFile: File, setName: String) {
  val id = NEOGEO_IDS[setName] ?: return
  val old = Regex("^" + Regex.escape(setName) + "_([a-z]+\\d+)\\.rom$")
  val tmp = File(zipFile.parentFile, zipFile.name + ".tmp")
  var renamed = 0
  java.util.zip.ZipFile(zipFile).use { zf ->
    if (zf.entries().asSequence().none { old.matches(it.name.substringAfterLast('/').lowercase()) }) return
    java.util.zip.ZipOutputStream(tmp.outputStream().buffered()).use { out ->
      for (e in zf.entries()) {
        if (e.isDirectory) continue
        val base = e.name.substringAfterLast('/').lowercase()
        val m = old.matchEntire(base)
        val newName = when {
          m != null -> { renamed++; "$id-${m.groupValues[1]}.${m.groupValues[1]}" }
          base.endsWith(".html") || base.endsWith(".txt") -> continue
          else -> base
        }
        out.putNextEntry(java.util.zip.ZipEntry(newName))
        zf.getInputStream(e).use { it.copyTo(out) }
        out.closeEntry()
      }
    }
  }
  if (renamed > 0) { zipFile.delete(); tmp.renameTo(zipFile) } else tmp.delete()
}

/** Netplay relay (Cloudflare Worker). Change here if the worker address ever changes. */
private const val NETPLAY_URL = "https://bazirox-netplay.yasinzzero3.workers.dev"

/** Extra age (ms) of a state snapshot on top of the one-way latency (serialize + compress + transfer + load). Tune if the guest still jumps. */
private const val STATE_AGE_EXTRA_MS = 40L

private fun copyText(context: android.content.Context, text: String) {
  val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
  cm.setPrimaryClip(android.content.ClipData.newPlainText("room", text))
  Toast.makeText(context, "کد کپی شد", Toast.LENGTH_SHORT).show()
}

private fun newRoomCode(): String {
  val chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
  return (1..5).map { chars.random() }.joinToString("")
}

private val ROM_EXTENSIONS = setOf("md", "bin", "gen", "smd", "sms", "gg", "sg")

private val GlassFill = Color.White.copy(alpha = 0.10f)
private val GlassFillPressed = Color.White.copy(alpha = 0.32f)
private val GlassBorder = Color.White.copy(alpha = 0.28f)
private val GlassText = Color.White.copy(alpha = 0.75f)

/**
 * Sega Genesis / Mega Drive emulator screen (libretro Genesis Plus GX via LibretroDroid).
 * The player picks his own ROM file; nothing is bundled in the app.
 */
@Composable
fun EmulatorScreen(onBack: () -> Unit) {
  // The rest of the app is RTL; a game pad must always be LTR (left button = left).
  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
    EmulatorContent(onBack)
  }
}

@Composable
private fun EmulatorContent(onBack: () -> Unit) {
  val context = LocalContext.current
  var romPath by rememberSaveable { mutableStateOf<String?>(null) }
  var romKey by rememberSaveable { mutableStateOf("game") }
  var errorMsg by remember { mutableStateOf<String?>(null) }
  // Online room chosen BEFORE the game starts; the player screen joins it automatically.
  var pendingRoom by rememberSaveable { mutableStateOf<String?>(null) }
  var joinCode by remember { mutableStateOf("") }
  // Offline (one phone) or online (2 phones). Online: the game starts only after the lobby is complete.
  var online by rememberSaveable { mutableStateOf(false) }
  var pickedPath by rememberSaveable { mutableStateOf<String?>(null) }
  var pickedName by rememberSaveable { mutableStateOf<String?>(null) }
  // Lobby state (online): connection, my slot (given by the server by arrival order), friend, game check.
  var net by remember { mutableStateOf<NetplayClient?>(null) }
  var netSlot by remember { mutableStateOf(0) }
  var peerOn by remember { mutableStateOf(false) }
  var peerRomOk by remember { mutableStateOf(false) }
  var romBad by remember { mutableStateOf(false) }
  var lobbyErr by remember { mutableStateOf<String?>(null) }
  var countdown by remember { mutableStateOf(0) }
  val scope = rememberCoroutineScope()
  // Picture filter (GPU shader, no extra lag): 0 standard, 1 smooth/sharp, 2 CRT, 3 LCD. Remembered between launches.
  val emuPrefs = remember { context.getSharedPreferences("bazirox_emu", android.content.Context.MODE_PRIVATE) }
  var gfx by remember { mutableStateOf(emuPrefs.getInt("gfx", 1)) }
  var findingServer by remember { mutableStateOf(false) }
  var probeInfo by remember { mutableStateOf<String?>(null) }
  var lobbyPing by remember { mutableStateOf(0L) } // WebSocket round trip (same as in-game)

  fun lobbyDisconnect() {
    net?.close()
    net = null
    netSlot = 0
    peerOn = false
    peerRomOk = false
    romBad = false
    countdown = 0
    lobbyPing = 0L
  }

  fun leaveGame() {
    lobbyDisconnect()
    pendingRoom = null
    romPath = null
  }

  fun onGamePicked(path: String, name: String) {
    pickedPath = path
    pickedName = name
    if (!online) romPath = path // offline: straight into the game
  }
  // false = Sega (Genesis Plus GX), true = Neo Geo (FBNeo, zip romsets + neogeo.zip BIOS)
  var neoGeo by rememberSaveable { mutableStateOf(false) }
  var neoBios by remember { mutableStateOf(File(context.filesDir, "fbneo/neogeo.zip").exists()) }

  val picker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
      if (uri == null) return@rememberLauncherForActivityResult
      try {
        val displayName =
          context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
          } ?: (uri.lastPathSegment ?: "game")
        if (neoGeo) {
          // Neo Geo romsets must stay zipped under their original name (e.g. mslug.zip).
          val low = displayName.lowercase().replace(Regex("[^a-z0-9_.-]"), "_")
          if (!low.endsWith(".zip")) {
            errorMsg = "برای نئوجئو فایل زیپ لازم است (مثلا mslug.zip)"
            return@rememberLauncherForActivityResult
          }
          val sysDir = File(context.filesDir, "fbneo").apply { mkdirs() }
          val romDir = File(context.filesDir, "roms/neogeo").apply { mkdirs() }
          val bios = File(sysDir, "neogeo.zip")
          if (low == "neogeo.zip") {
            context.contentResolver.openInputStream(uri)?.use { input ->
              bios.outputStream().use { input.copyTo(it) }
            } ?: throw java.io.IOException("open")
            bios.copyTo(File(romDir, "neogeo.zip"), overwrite = true)
            neoBios = true
            errorMsg = null
            Toast.makeText(context, "BIOS ذخیره شد", Toast.LENGTH_SHORT).show()
            return@rememberLauncherForActivityResult
          }
          if (!bios.exists()) {
            errorMsg = "اول BIOS نئوجئو (neogeo.zip) را انتخاب کن"
            return@rememberLauncherForActivityResult
          }
          val game = File(romDir, low)
          context.contentResolver.openInputStream(uri)?.use { input ->
            game.outputStream().use { input.copyTo(it) }
          } ?: throw java.io.IOException("open")
          if (game.length() < 64 * 1024) {
            errorMsg = "فایل بازی معتبر نیست"
            return@rememberLauncherForActivityResult
          }
          if (!File(romDir, "neogeo.zip").exists()) bios.copyTo(File(romDir, "neogeo.zip"), overwrite = true)
          runCatching { normalizeNeoGeoZip(game, low.removeSuffix(".zip")) }
          errorMsg = null
          romKey = "ng_" + low.removeSuffix(".zip").take(56)
          onGamePicked(game.absolutePath, low)
          return@rememberLauncherForActivityResult
        }
        val key = displayName.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_").take(60).ifBlank { "game" }
        val dir = File(context.filesDir, "roms").apply { mkdirs() }
        var ext = displayName.substringAfterLast('.', "").lowercase()
        var out = File(dir, "$key.$ext")
        if (ext == "zip") {
          // The emulator core can crash on zip files: extract the ROM inside ourselves.
          var found = false
          java.util.zip.ZipInputStream(context.contentResolver.openInputStream(uri)?.buffered() ?: throw java.io.IOException("open")).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
              val eExt = e.name.substringAfterLast('.', "").lowercase()
              if (!e.isDirectory && eExt in ROM_EXTENSIONS) {
                ext = eExt
                out = File(dir, "$key.$ext")
                out.outputStream().use { zip.copyTo(it) }
                found = true
                break
              }
              e = zip.nextEntry
            }
          }
          if (!found) {
            errorMsg = "داخل زیپ فایل بازی (.md .bin .gen .smd) پیدا نشد"
            return@rememberLauncherForActivityResult
          }
        } else {
          if (ext !in ROM_EXTENSIONS) {
            errorMsg = "این فرمت پشتیبانی نمی‌شود (.md .bin .gen .smd)"
            return@rememberLauncherForActivityResult
          }
          context.contentResolver.openInputStream(uri)?.use { input ->
            out.outputStream().use { input.copyTo(it) }
          } ?: throw java.io.IOException("cannot open file")
        }
        if (out.length() < 64 * 1024) {
          errorMsg = "فایل بازی معتبر نیست"
          return@rememberLauncherForActivityResult
        }
        errorMsg = null
        romKey = key
        onGamePicked(out.absolutePath, out.name)
      } catch (t: Throwable) {
        errorMsg = "خواندن فایل ناموفق بود"
      }
    }

  BackHandler(onBack = { if (romPath != null) leaveGame() else onBack() })

  // ---- Lobby: connect as soon as BOTH a room and a game are chosen ----
  LaunchedEffect(online, pendingRoom) {
    lobbyDisconnect()
    val room = pendingRoom
    if (!online || room == null) return@LaunchedEffect
    lobbyErr = null
    val client =
      NetplayClient(
        baseUrl = NETPLAY_URL,
        room = room,
        romKey = if (pickedPath != null) romKey else "",
        listener =
          object : NetplayClient.Listener {
            override fun onHello(slot: Int, peers: Int) {
              netSlot = slot
              peerOn = peers > 0
              if (peers > 0) net?.sendRom()
            }
            override fun onPeer(on: Boolean) {
              peerOn = on
              if (on) net?.sendRom() else { peerRomOk = false; romBad = false }
            }
            override fun onKey(code: Int, down: Boolean) {}
            override fun onState(bytes: ByteArray) {}
            override fun onRomMismatch() { romBad = true; peerRomOk = false }
            override fun onRomOk() { romBad = false; peerRomOk = true }
            override fun onCmd(action: String) {}
            override fun onPing(rttMs: Long) { if (lobbyPing == 0L) lobbyPing = rttMs }
            override fun onServerPing(rttMs: Long) { lobbyPing = rttMs }
            override fun onClosed(reason: String) {
              lobbyErr = reason
              net = null
              netSlot = 0
              peerOn = false
              peerRomOk = false
              countdown = 0
            }
          },
      )
    net = client
    client.connect()
  }

  // Game picked/changed while already in the room: update the check without reconnecting.
  LaunchedEffect(pickedPath, romKey) {
    val c = net ?: return@LaunchedEffect
    c.romKey = if (pickedPath != null) romKey else ""
    peerRomOk = false
    romBad = false
    if (peerOn) c.sendRom()
  }

  // Both in the room + same game -> short countdown, then both phones start the game together.
  LaunchedEffect(online, net, peerOn, peerRomOk, netSlot, romPath) {
    countdown = 0
    if (!online || net == null || !peerOn || !peerRomOk || netSlot == 0 || romPath != null) return@LaunchedEffect
    val p = pickedPath ?: return@LaunchedEffect
    for (i in 3 downTo 1) {
      countdown = i
      delay(1_000)
    }
    countdown = 0
    romPath = p
  }

  Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
    val path = romPath
    if (path == null) {
      val room = pendingRoom
      val canPickGame = !neoGeo || neoBios
      Column(
        modifier =
          Modifier.fillMaxSize()
            .background(ObsidianBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        // ---- Header + console switch ----
        Text("کنسول بازی", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Row(
          modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.08f)).padding(4.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          SegTab("سگا · Genesis", !neoGeo) { neoGeo = false; errorMsg = null }
          SegTab("نئوجئو · Neo Geo", neoGeo) { neoGeo = true; errorMsg = null }
        }
        // Offline / online switch
        Row(
          modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.08f)).padding(4.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          SegTab("آفلاین", !online) { online = false; pendingRoom = null; errorMsg = null }
          SegTab("آنلاین", online) { online = true; errorMsg = null }
        }
        // Picture quality
        Text("کیفیت تصویر", color = TextSecondary, fontSize = 12.sp)
        Row(
          modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.08f)).padding(4.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          listOf("استاندارد", "نرم ✨", "CRT", "LCD").forEachIndexed { i, label ->
            SegTab(label, gfx == i) { gfx = i; emuPrefs.edit().putInt("gfx", i).apply() }
          }
        }

        // ---- Step 1: BIOS (Neo Geo only) ----
        if (neoGeo) {
          StepCard(
            number = "۱",
            title = "BIOS نئوجئو",
            badge = if (neoBios) "✓ آماده" else "لازم است",
            badgeOk = neoBios,
          ) {
            Text("فایل neogeo.zip را (بدون باز کردن) انتخاب کن. فقط یک‌بار لازم است.", color = TextSecondary, fontSize = 12.sp)
            Spacer(Modifier.size(8.dp))
            if (neoBios) TextButton(onClick = { neoBios = false }) { Text("تعویض BIOS", color = NeonCyan) }
            else Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("انتخاب BIOS (neogeo.zip)") }
          }
        }

        // ---- Step 2: game ----
        StepCard(
          number = if (neoGeo) "۲" else "۱",
          title = "انتخاب بازی",
          badge = if (canPickGame) "آماده" else "اول BIOS",
          badgeOk = canPickGame,
        ) {
          Text(
            if (neoGeo) "فایل zip بازی را انتخاب کن، مثلا mslug.zip (اسم فایل را عوض نکن)."
            else "فایل ROM خودت را انتخاب کن. فرمت‌ها: .md .bin .gen .smd",
            color = TextSecondary,
            fontSize = 12.sp,
          )
          Spacer(Modifier.size(8.dp))
          Button(enabled = canPickGame, onClick = { picker.launch(arrayOf("*/*")) }) {
            Text(if (neoGeo) "انتخاب بازی (zip)" else "انتخاب ROM")
          }
          if (online) {
            Spacer(Modifier.size(6.dp))
            Text(
              pickedName?.let { "بازی انتخاب‌شده: $it" } ?: "بعد از انتخاب بازی و ساخت/ورود به اتاق، بازی وقتی هر دو نفر آماده باشند شروع می‌شود.",
              color = NeonCyan,
              fontSize = 12.sp,
            )
          }
        }

        // ---- Step 3: online room (only in online mode) ----
        if (online) StepCard(
          number = if (neoGeo) "۳" else "۲",
          title = "اتاق آنلاین ۲ نفره",
          badge = if (room != null) (if (netSlot != 0) "تو P$netSlot" else "…") else "لازم است",
          badgeOk = room != null && netSlot != 0,
        ) {
          if (room == null) {
            var probeResults by remember { mutableStateOf<List<NetplayProbe.Result>?>(null) }
            val shown = probeResults
            if (shown == null) {
              Button(
                enabled = !findingServer,
                onClick = {
                  findingServer = true
                  probeInfo = null
                  scope.launch {
                    probeResults = NetplayProbe.measure(NETPLAY_URL)
                    findingServer = false
                  }
                },
                modifier = Modifier.fillMaxWidth(),
              ) {
                Text(if (findingServer) "در حال سنجش سرورها… (چند ثانیه)" else "ساخت اتاق")
              }
            } else {
              val best = NetplayProbe.best(shown)
              Text("سرور اتاق را انتخاب کن (پایدارتر = بهتر):", color = TextSecondary, fontSize = 12.sp)
              Spacer(Modifier.size(6.dp))
              shown.forEach { r ->
                val isBest = r === best
                Button(
                  enabled = r.ms != null,
                  onClick = {
                    probeInfo = "پینگ ${r.ms}ms · نوسان ${r.jitterMs}ms · افت ${r.lossPct}٪"
                    pendingRoom = r.letter.toString() + newRoomCode().take(4)
                    probeResults = null
                  },
                  modifier = Modifier.fillMaxWidth(),
                  colors =
                    if (isBest) ButtonDefaults.buttonColors()
                    else ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.12f), contentColor = Color.White),
                ) {
                  Text(
                    (if (isBest) "★ " else "") + r.name + " · " +
                      (if (r.ms == null) "در دسترس نیست" else "${r.ms}ms · نوسان ${r.jitterMs} · افت ${r.lossPct}٪"),
                    fontSize = 13.sp,
                  )
                }
                Spacer(Modifier.size(6.dp))
              }
              TextButton(onClick = { probeResults = null }) { Text("سنجش دوباره", color = TextSecondary) }
            }
            Spacer(Modifier.size(10.dp))
            Text("یا کد اتاق دوستت را وارد کن:", color = TextSecondary, fontSize = 12.sp)
            Spacer(Modifier.size(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(
                value = joinCode,
                onValueChange = { joinCode = it.uppercase().filter { ch -> ch.isLetterOrDigit() }.take(8) },
                label = { Text("کد اتاق") },
                singleLine = true,
                modifier = Modifier.weight(1f),
              )
              Button(enabled = joinCode.length >= 4, onClick = { pendingRoom = joinCode }) { Text("ورود") }
            }
          } else {
            val roomPing = lobbyPing.takeIf { net != null && it > 0 }
            val status: String
            val statusColor: Color
            when {
              lobbyErr != null -> { status = lobbyErr ?: ""; statusColor = Color(0xFFFF8A8A) }
              net == null || netSlot == 0 -> { status = "در حال اتصال به اتاق…"; statusColor = Color(0xFFFFB84D) }
              pickedPath == null -> { status = "وصل شدی (تو بازیکن $netSlot). حالا بازی را انتخاب کن؛ هر دو نفر باید یک بازی را انتخاب کنید."; statusColor = Color(0xFFFFB84D) }
              !peerOn -> { status = "تو بازیکن $netSlot هستی. منتظر ورود دوستت…"; statusColor = Color(0xFFFFB84D) }
              romBad -> { status = "بازی دو طرف یکی نیست! هر دو باید دقیقا یک بازی را انتخاب کنید."; statusColor = Color(0xFFFF8A8A) }
              countdown > 0 -> { status = "هر دو آماده‌اید ✓  شروع بازی در $countdown…"; statusColor = Color(0xFF4ADE80) }
              else -> { status = "دوستت وصل شد؛ در حال بررسی بازی…"; statusColor = NeonCyan }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
              Text("کد اتاق", color = TextSecondary, fontSize = 12.sp)
              SelectionContainer {
                Text(room, color = NeonCyan, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
              }
              Text(
                roomPing?.let { "پینگ سرور: $it ms" }
                  ?: net?.connectMs?.takeIf { it > 0 }?.let { "زمان اتصال: $it ms (پینگ بعد از آپدیت ورکر نشان داده می‌شود)" }
                  ?: "پینگ سرور: …",
                color = if ((roomPing ?: 999L) <= 150L) NeonCyan else Color(0xFFFFB84D),
                fontSize = 12.sp,
              )
              NetplayProbe.regionName(room)?.let {
                Text("منطقه سرور: $it", color = TextSecondary, fontSize = 12.sp)
              }
              probeInfo?.let { Text(it, color = TextSecondary, fontSize = 11.sp) }
              Spacer(Modifier.size(8.dp))
              Text(status, color = statusColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
              Spacer(Modifier.size(6.dp))
              Text(
                "بازی فقط وقتی شروع می‌شود که هر دو نفر در اتاق باشند و بازی یکی باشد. سکه و START هم خودکار زده می‌شود.",
                color = TextSecondary,
                fontSize = 12.sp,
              )
              Spacer(Modifier.size(6.dp))
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { copyText(context, room) }) { Text("کپی کد") }
                TextButton(onClick = { pendingRoom = null }) { Text("لغو اتاق", color = TextSecondary) }
              }
            }
          }
        }

        errorMsg?.let {
          Box(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFFFF6B6B).copy(alpha = 0.14f))
                .border(1.dp, Color(0xFFFF6B6B).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(12.dp),
          ) {
            Text(it, color = Color(0xFFFF8A8A), fontSize = 13.sp)
          }
        }

        TextButton(onClick = onBack) { Text("بازگشت", color = TextSecondary) }
      }
    } else {
      // Online but the connection is gone (e.g. app restarted): back to the lobby.
      val live = net
      if (online && (live == null || netSlot == 0)) {
        LaunchedEffect(Unit) { leaveGame() }
      } else {
        EmulatorPlayer(romPath = path, romKey = romKey, neoGeo = neoGeo, gfx = gfx, net = if (online) live else null, slot = if (online) netSlot else 0, onExit = { leaveGame() })
      }
    }
  }
}

@Composable
private fun EmulatorPlayer(romPath: String, romKey: String, neoGeo: Boolean, gfx: Int, net: NetplayClient?, slot: Int, onExit: () -> Unit) {
  val context = LocalContext.current
  val activity = context as ComponentActivity
  val scope = rememberCoroutineScope()

  val savesDir = remember { File(context.filesDir, "saves").apply { mkdirs() } }
  val sramFile = File(savesDir, "$romKey.srm")
  // Save-state slots 1..5 (slot 1 also reads the old single-slot file so earlier saves still load).
  var saveSlot by rememberSaveable { mutableStateOf(1) }
  fun stateFileFor(n: Int): File {
    val f = File(savesDir, "$romKey.s$n.state")
    if (n == 1 && !f.exists()) {
      val legacy = File(savesDir, "$romKey.state")
      if (legacy.exists()) return legacy
    }
    return f
  }
  var saveTick by remember { mutableStateOf(0) } // bumped after each save so the slot label refreshes
  fun slotStatus(): String {
    saveTick.let { }
    val f = stateFileFor(saveSlot)
    if (!f.exists()) return "خالی"
    return java.text.SimpleDateFormat("MM/dd HH:mm", java.util.Locale.US).format(java.util.Date(f.lastModified()))
  }

  val retroView =
    remember(romPath) {
      val data =
        GLRetroViewData(context).apply {
          coreFilePath = if (neoGeo) NEOGEO_CORE else GENESIS_CORE
          gameFilePath = romPath
          shader =
            when (gfx) {
              0 -> ShaderConfig.Default
              2 -> ShaderConfig.CRT
              3 -> ShaderConfig.LCD
              else -> ShaderConfig.Sharp // smooth edges, crisp pixels, no blur
            }
          systemDirectory = context.filesDir.absolutePath
          savesDirectory = savesDir.absolutePath
          // Restore in-game save (battery RAM) if one exists.
          if (sramFile.exists()) saveRAMState = sramFile.readBytes()
        }
      GLRetroView(context, data)
    }

  fun saveSram() {
    scope.launch(Dispatchers.IO) {
      try {
        val bytes = retroView.serializeSRAM()
        if (bytes.isNotEmpty()) sramFile.writeBytes(bytes)
      } catch (_: Throwable) {}
    }
  }

  DisposableEffect(retroView) {
    activity.lifecycle.addObserver(retroView)
    val saver = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_PAUSE) saveSram() }
    activity.lifecycle.addObserver(saver)
    onDispose {
      saveSram()
      activity.lifecycle.removeObserver(saver)
      activity.lifecycle.removeObserver(retroView)
    }
  }

  // Auto-save in-game saves every few seconds.
  LaunchedEffect(retroView) {
    while (true) {
      delay(8_000)
      saveSram()
    }
  }

  // ---- Online (room) mode ----
  // `net`/`slot` come from the lobby: slot 0 = offline, 1 = host (player 1), 2 = guest (player 2).
  var localP2 by remember { mutableStateOf(false) } // offline, one phone: false = controls drive player 1, true = player 2
  var peerOn by remember { mutableStateOf(net != null) }
  var resumed by remember { mutableStateOf(false) } // this room continued from its autosave
  var pingMs by remember { mutableStateOf(0L) }
  val lastDue = remember { longArrayOf(0L) }
  val lastInput = remember { longArrayOf(0L) } // last key event (mine or the peer's)
  val lastPush = remember { longArrayOf(0L) } // host: last time a state was sent
  val syncReq = remember { Channel<Unit>(Channel.CONFLATED) } // host: "send a state now"
  val ffJob = remember { arrayOfNulls<Job>(1) } // guest: catch-up after loading a state

  fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

  fun press(code: Int, down: Boolean) {
    lastInput[0] = SystemClock.elapsedRealtime()
    val action = if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP
    val n = net
    if (n != null && slot != 0 && peerOn) {
      n.sendKey(code, down)
      // Apply my own input after ~one-way latency so both phones see the same timing.
      val now = SystemClock.elapsedRealtime()
      val due = maxOf(now + n.oneWayMs, lastDue[0])
      lastDue[0] = due
      val port = slot - 1
      scope.launch {
        delay(due - now)
        retroView.sendKeyEvent(action, code, port)
      }
    } else {
      retroView.sendKeyEvent(action, code, if (slot == 2 || (slot == 0 && localP2)) 1 else 0)
    }
  }

  // ---- Save / load (online: the host's state is the shared one) ----
  suspend fun saveLocal(): Boolean =
    withContext(Dispatchers.IO) {
      try {
        val sf = File(savesDir, "$romKey.s$saveSlot.state")
        sf.writeBytes(retroView.serializeState())
        saveTick++
        true
      } catch (_: Throwable) {
        false
      }
    }

  /** 1 = loaded, 0 = failed, -1 = nothing saved yet. */
  suspend fun loadLocal(): Int {
    if (!stateFileFor(saveSlot).exists()) return -1
    return withContext(Dispatchers.IO) {
      try {
        if (retroView.unserializeState(stateFileFor(saveSlot).readBytes())) 1 else 0
      } catch (_: Throwable) {
        0
      }
    }
  }

  fun saveState() {
    val n = net
    scope.launch {
      if (n != null && peerOn && slot == 2) {
        n.sendCmd("save") // the host saves; both players get the result
        return@launch
      }
      val ok = saveLocal()
      toast(if (ok) "ذخیره شد" else "ذخیره ناموفق بود")
      if (n != null && peerOn) n.sendCmd(if (ok) "saved" else "savefail")
    }
  }

  fun loadState() {
    val n = net
    scope.launch {
      if (n != null && peerOn && slot == 2) {
        n.sendCmd("load") // the host loads and pushes the state to both
        return@launch
      }
      val r = loadLocal()
      toast(
        when (r) {
          1 -> "بارگذاری شد"
          -1 -> "هنوز چیزی ذخیره نکردی"
          else -> "بارگذاری ناموفق بود"
        },
      )
      if (n != null && peerOn) {
        when (r) {
          1 -> {
            n.sendCmd("loaded")
            syncReq.trySend(Unit) // guest gets the loaded state right away
          }
          -1 -> n.sendCmd("nosave")
          else -> n.sendCmd("loadfail")
        }
      }
    }
  }

  val netListener =
    object : NetplayClient.Listener {
      override fun onHello(s: Int, peers: Int) {
        peerOn = peers > 0
      }
      override fun onPeer(on: Boolean) {
        peerOn = on
      }
      override fun onKey(c: Int, d: Boolean) {
        lastInput[0] = SystemClock.elapsedRealtime()
        val port = if (slot == 1) 1 else 0
        retroView.sendKeyEvent(if (d) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, c, port)
      }
      override fun onState(bytes: ByteArray) {
        if (slot != 2) return
        val age = ((net?.oneWayMs ?: 50L) + STATE_AGE_EXTRA_MS).coerceIn(30L, 250L)
        ffJob[0]?.cancel()
        ffJob[0] =
          scope.launch {
            val ok =
              withContext(Dispatchers.IO) {
                try {
                  retroView.unserializeState(bytes)
                } catch (_: Throwable) {
                  false
                }
              }
            if (ok) {
              // The snapshot is already `age` ms old: run faster for that long so this
              // screen catches up with the host instead of jumping back in time.
              try {
                retroView.frameSpeed = 2
                delay(age)
              } finally {
                retroView.frameSpeed = 1
              }
            }
          }
      }
      override fun onCmd(action: String) {
        when (action) {
          "save" -> if (slot == 1) saveState()
          "load" -> if (slot == 1) loadState()
          "resumed" -> { resumed = true; toast("ادامه از آخرین ذخیره‌ی خودکار این اتاق ✓") }
          "saved" -> toast("ذخیره شد")
          "savefail" -> toast("ذخیره ناموفق بود")
          "loaded" -> toast("بارگذاری شد")
          "nosave" -> toast("هنوز چیزی ذخیره نشده")
          "loadfail" -> toast("بارگذاری ناموفق بود")
        }
      }
      override fun onRomMismatch() = toast("بازی دو طرف یکی نیست!")
      override fun onPing(rttMs: Long) {
        pingMs = rttMs
      }
      override fun onClosed(reason: String) {
        toast(reason)
        onExit() // connection lost: back to the menu (the room is closed there)
      }
    }

  // Take over the lobby's connection (same socket, same slot) for the game.
  DisposableEffect(net) {
    net?.listener = netListener
    onDispose {}
  }

  suspend fun pushState(n: NetplayClient) {
    withContext(Dispatchers.IO) {
      try {
        n.sendState(retroView.serializeState())
      } catch (_: Throwable) {}
    }
    lastPush[0] = SystemClock.elapsedRealtime()
  }

  // Host: send a state when the guest joins, on load, when play settles after button presses
  // (so the correction is invisible), and rarely as a safety net while play never stops.
  LaunchedEffect(net, slot, peerOn) {
    val n = net
    if (n == null || !peerOn) return@LaunchedEffect
    n.sendRom()
    if (slot != 1) return@LaunchedEffect
    delay(2_500) // both phones just started the game: let it boot before the first state is sent
    pushState(n)
    while (true) {
      delay(150)
      val now = SystemClock.elapsedRealtime()
      val dirty = lastInput[0] > lastPush[0]
      val requested = syncReq.tryReceive().isSuccess
      val settled = dirty && now - lastInput[0] >= 700
      val busy = dirty && now - lastPush[0] >= 12_000
      val heartbeat = now - lastPush[0] >= 30_000
      if (requested || settled || busy || heartbeat) pushState(n)
    }
  }

  // ---- Room autosave: same room code + same game -> continue where you left off ----
  // Both phones write the state every few seconds (the guest's copy is the host's, synced), so
  // whoever becomes player 1 next time has it. The host loads it right after the game boots.
  val autoFile = remember(net) { net?.let { File(savesDir, "room_${it.room}_$romKey.auto.state") } }
  LaunchedEffect(net, slot) {
    val f = autoFile ?: return@LaunchedEffect
    if (slot == 0) return@LaunchedEffect
    withContext(Dispatchers.IO) {
      try {
        if (f.exists()) f.copyTo(File(f.path + ".bak"), overwrite = true) // safety copy of the previous session
        // Keep the folder small: only the 8 newest room autosaves.
        savesDir.listFiles { x -> x.name.startsWith("room_") && x.name.endsWith(".auto.state") }
          ?.sortedByDescending { it.lastModified() }?.drop(8)?.forEach { it.delete(); File(it.path + ".bak").delete() }
      } catch (_: Throwable) {}
    }
    delay(1_500) // let the core boot
    if (slot == 1 && f.exists() && f.length() > 0) {
      val ok =
        withContext(Dispatchers.IO) {
          try {
            retroView.unserializeState(f.readBytes())
          } catch (_: Throwable) {
            false
          }
        }
      if (ok) {
        resumed = true
        toast("ادامه از آخرین ذخیره‌ی خودکار این اتاق ✓")
        net?.sendCmd("resumed")
        syncReq.trySend(Unit) // the guest gets this state right away
      }
    }
    while (true) {
      delay(6_000)
      withContext(Dispatchers.IO) {
        try {
          val tmp = File(f.path + ".tmp")
          tmp.writeBytes(retroView.serializeState())
          tmp.renameTo(f) // write-then-rename: a crash never leaves a half file
        } catch (_: Throwable) {}
      }
    }
  }

  // Neo Geo two-player: once both players are in the room, each side inserts a coin and presses
  // its own START (host = P1, guest = P2), so the game starts in 2-player mode by itself.
  var autoStarted by remember { mutableStateOf(false) }

  // One coin + my own START (P1 on the host, P2 on the guest). Used by the auto-start and the button.
  suspend fun insertCoinAndStart() {
    press(KeyEvent.KEYCODE_BUTTON_SELECT, true)
    delay(120)
    press(KeyEvent.KEYCODE_BUTTON_SELECT, false)
    delay(1_200)
    press(KeyEvent.KEYCODE_BUTTON_START, true)
    delay(120)
    press(KeyEvent.KEYCODE_BUTTON_START, false)
  }

  LaunchedEffect(net, slot, peerOn) {
    if (!neoGeo || net == null || !peerOn || slot == 0 || autoStarted) return@LaunchedEffect
    autoStarted = true
    toast("هر دو بازیکن آماده‌اند... شروع خودکار")
    delay(6_000) // both phones started together: wait for the BIOS/intro, host's first state reaches the guest
    if (resumed) return@LaunchedEffect // continuing a saved game: no coin/START needed
    insertCoinAndStart()
  }

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val landscape = maxWidth > maxHeight
    val gameHeight: Dp = maxWidth * (224f / 320f)

    // One single emulator view for both orientations (a view can't be re-parented).
    AndroidView(
      factory = { retroView },
      modifier =
        if (landscape) Modifier.align(Alignment.Center).fillMaxHeight().aspectRatio(320f / 224f)
        else Modifier.align(Alignment.TopCenter).statusBarsPadding().fillMaxWidth().aspectRatio(320f / 224f),
    )

    val controlsModifier =
      if (landscape) Modifier.fillMaxSize().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp)
      else
        Modifier.align(Alignment.BottomCenter)
          .fillMaxWidth()
          .height((maxHeight - gameHeight - 36.dp).coerceAtLeast(260.dp))
          .navigationBarsPadding()
          .padding(12.dp)

    Box(modifier = controlsModifier) {
      // Top menu: save / load / exit
      Row(
        modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
      ) {
        val n = net
        if (n != null) {
          GlassChip(
            "${n.room} · " + (if (slot == 2) "P2" else "P1") + (if (peerOn) " ✓ " else " … ") + (if (pingMs > 0) "${pingMs}ms" else ""),
          ) { copyText(context, n.room) }
        }
        if (n == null) GlassChip(if (localP2) "بازیکن ۲" else "بازیکن ۱") {
          // Release everything first so no key stays "stuck" on the previous player.
          for (port in 0..1) for (k in listOf(
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
            KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT,
          )) retroView.sendKeyEvent(KeyEvent.ACTION_UP, k, port)
          localP2 = !localP2
        }
        if (neoGeo && n != null && peerOn) GlassChip("شروع دونفره") { scope.launch { insertCoinAndStart() } }
        GlassChip("اسلات $saveSlot " + (if (slotStatus() == "خالی") "○" else "●")) { saveSlot = if (saveSlot >= 5) 1 else saveSlot + 1 }
        GlassChip("ذخیره") { saveState() }
        GlassChip("بارگذاری") { loadState() }
        GlassChip("خروج") { onExit() }
      }

      DPad(
        modifier = Modifier.align(Alignment.CenterStart),
        size = 150.dp,
        onKey = ::press,
      )

      // Sega-style face buttons: A B C on a rising arc, X Y Z (6-button pad) above them.
      Column(
        modifier = Modifier.align(Alignment.CenterEnd),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        if (neoGeo) {
          // Neo Geo A B C D -> FBNeo fire 1..4 = RetroPad B, A, Y, X (LibretroDroid maps keys 1:1).
          Row {
            FaceButton("C", KeyEvent.KEYCODE_BUTTON_Y, ::press, size = 56.dp, lift = 4.dp)
            FaceButton("D", KeyEvent.KEYCODE_BUTTON_X, ::press, size = 56.dp, lift = (-4).dp)
          }
          Spacer(Modifier.size(6.dp))
          Row {
            FaceButton("A", KeyEvent.KEYCODE_BUTTON_B, ::press, size = 62.dp, lift = 4.dp)
            FaceButton("B", KeyEvent.KEYCODE_BUTTON_A, ::press, size = 62.dp, lift = (-4).dp)
          }
        } else {
          Row {
            FaceButton("X", KeyEvent.KEYCODE_BUTTON_L1, ::press, size = 44.dp, lift = 6.dp)
            FaceButton("Y", KeyEvent.KEYCODE_BUTTON_X, ::press, size = 44.dp, lift = 0.dp)
            FaceButton("Z", KeyEvent.KEYCODE_BUTTON_R1, ::press, size = 44.dp, lift = (-6).dp)
          }
          Spacer(Modifier.size(6.dp))
          Row {
            FaceButton("A", KeyEvent.KEYCODE_BUTTON_Y, ::press, size = 62.dp, lift = 12.dp)
            FaceButton("B", KeyEvent.KEYCODE_BUTTON_B, ::press, size = 62.dp, lift = 0.dp)
            FaceButton("C", KeyEvent.KEYCODE_BUTTON_A, ::press, size = 62.dp, lift = (-12).dp)
          }
        }
      }

      Row(
        modifier = Modifier.align(Alignment.BottomCenter),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        PillButton(if (neoGeo) "COIN" else "MODE", KeyEvent.KEYCODE_BUTTON_SELECT, ::press)
        PillButton("START", KeyEvent.KEYCODE_BUTTON_START, ::press)
      }
    }

  }
}

/** 8-direction glass D-pad: slide the thumb to change direction, diagonals work. */
@Composable
private fun DPad(modifier: Modifier, size: Dp, onKey: (Int, Boolean) -> Unit) {
  // 0=up 1=down 2=left 3=right
  val active = remember { mutableStateListOf(false, false, false, false) }
  val codes =
    remember {
      intArrayOf(KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT)
    }

  fun set(i: Int, v: Boolean) {
    if (active[i] != v) {
      active[i] = v
      onKey(codes[i], v)
    }
  }

  Box(
    modifier =
      modifier
        .size(size)
        .clip(CircleShape)
        .background(GlassFill)
        .border(1.dp, GlassBorder, CircleShape)
        .pointerInput(Unit) {
          awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            fun update(p: Offset) {
              val cx = this.size.width / 2f
              val cy = this.size.height / 2f
              val dead = minOf(cx, cy) * 0.26f
              val dx = p.x - cx
              val dy = p.y - cy
              set(0, dy < -dead)
              set(1, dy > dead)
              set(2, dx < -dead)
              set(3, dx > dead)
            }
            update(down.position)
            while (true) {
              val event = awaitPointerEvent()
              val change = event.changes.firstOrNull { it.id == down.id } ?: break
              if (!change.pressed) break
              update(change.position)
              change.consume()
            }
            for (i in 0..3) set(i, false)
          }
        },
    contentAlignment = Alignment.Center,
  ) {
    val s = size
    ArrowMark("▲", active[0], Modifier.align(Alignment.TopCenter).padding(top = s * 0.08f))
    ArrowMark("▼", active[1], Modifier.align(Alignment.BottomCenter).padding(bottom = s * 0.08f))
    ArrowMark("◀", active[2], Modifier.align(Alignment.CenterStart).padding(start = s * 0.10f))
    ArrowMark("▶", active[3], Modifier.align(Alignment.CenterEnd).padding(end = s * 0.10f))
  }
}

@Composable
private fun ArrowMark(glyph: String, on: Boolean, modifier: Modifier) {
  Text(glyph, color = if (on) Color.White else GlassText.copy(alpha = 0.5f), fontSize = 20.sp, modifier = modifier)
}

@Composable
private fun FaceButton(
  label: String,
  keyCode: Int,
  press: (Int, Boolean) -> Unit,
  size: Dp,
  lift: Dp,
) {
  var held by remember { mutableStateOf(false) }
  Box(
    modifier =
      Modifier.padding(horizontal = 4.dp)
        .offset(y = -lift)
        .size(size)
        .clip(CircleShape)
        .background(if (held) GlassFillPressed else GlassFill)
        .border(1.dp, GlassBorder, CircleShape)
        .pointerInput(keyCode) {
          detectTapGestures(
            onPress = {
              held = true
              press(keyCode, true)
              try {
                tryAwaitRelease()
              } finally {
                held = false
                press(keyCode, false)
              }
            }
          )
        },
    contentAlignment = Alignment.Center,
  ) {
    Text(label, color = GlassText, fontSize = if (size >= 60.dp) 18.sp else 13.sp, fontWeight = FontWeight.Bold)
  }
}

@Composable
private fun PillButton(label: String, keyCode: Int, press: (Int, Boolean) -> Unit) {
  var held by remember { mutableStateOf(false) }
  val shape = RoundedCornerShape(12.dp)
  Box(
    modifier =
      Modifier.size(width = 76.dp, height = 34.dp)
        .clip(shape)
        .background(if (held) GlassFillPressed else GlassFill)
        .border(1.dp, GlassBorder, shape)
        .pointerInput(keyCode) {
          detectTapGestures(
            onPress = {
              held = true
              press(keyCode, true)
              try {
                tryAwaitRelease()
              } finally {
                held = false
                press(keyCode, false)
              }
            }
          )
        },
    contentAlignment = Alignment.Center,
  ) {
    Text(label, color = GlassText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
  }
}

@Composable
private fun SegTab(label: String, selected: Boolean, onClick: () -> Unit) {
  val shape = RoundedCornerShape(10.dp)
  Box(
    modifier =
      Modifier.clip(shape)
        .background(if (selected) NeonCyan else Color.Transparent)
        .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) }
        .padding(horizontal = 16.dp, vertical = 9.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      label,
      color = if (selected) ObsidianBg else TextSecondary,
      fontSize = 13.sp,
      fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium,
    )
  }
}

@Composable
private fun StepCard(
  number: String,
  title: String,
  badge: String,
  badgeOk: Boolean,
  content: @Composable () -> Unit,
) {
  val shape = RoundedCornerShape(18.dp)
  Column(
    modifier =
      Modifier.fillMaxWidth()
        .clip(shape)
        .background(Color.White.copy(alpha = 0.06f))
        .border(1.dp, Color.White.copy(alpha = 0.14f), shape)
        .padding(16.dp),
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      Box(
        modifier = Modifier.size(26.dp).clip(CircleShape).background(NeonCyan.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center,
      ) {
        Text(number, color = NeonCyan, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
      }
      Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
      Text(
        badge,
        color = if (badgeOk) Color(0xFF4ADE80) else Color(0xFFFFB84D),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
      )
    }
    Spacer(Modifier.size(10.dp))
    content()
  }
}

@Composable
private fun GlassChip(label: String, onClick: () -> Unit) {
  val shape = RoundedCornerShape(10.dp)
  Box(
    modifier =
      Modifier.clip(shape)
        .background(GlassFill)
        .border(1.dp, GlassBorder, shape)
        .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) }
        .padding(horizontal = 12.dp, vertical = 6.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(label, color = GlassText, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false)
  }
}
