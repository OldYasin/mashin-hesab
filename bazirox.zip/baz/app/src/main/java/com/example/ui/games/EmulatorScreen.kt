package com.example.ui.games

import android.net.Uri
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.data.NetplayClient
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextSecondary
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Name of the Genesis Plus GX libretro core inside jniLibs (downloaded by the `fetchGenesisCore` Gradle task). */
private const val GENESIS_CORE = "libgenesis_plus_gx_libretro_android.so"

/** FBNeo libretro core (Neo Geo arcade/AES). Needs neogeo.zip (BIOS) in <filesDir>/fbneo/. */
private const val NEOGEO_CORE = "libfbneo_libretro_android.so"

/** Netplay relay (Cloudflare Worker). Change here if the worker address ever changes. */
private const val NETPLAY_URL = "https://bazirox-netplay.yasinzzero3.workers.dev"

/** Extra age (ms) of a state snapshot on top of the one-way latency (serialize + compress + transfer + load). Tune if the guest still jumps. */
private const val STATE_AGE_EXTRA_MS = 40L

private fun copyText(context: android.content.Context, text: String) {
  val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
  cm.setPrimaryClip(android.content.ClipData.newPlainText("room", text))
  Toast.makeText(context, "کد کپی شد", Toast.LENGTH_SHORT).show()
}

private fun newRoomCode(): String {
  val chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
  return (1..5).map { chars.random() }.joinToString("")
}

private val ROM_EXTENSIONS = setOf("md", "bin", "gen", "smd", "sms", "gg", "sg")

private val GlassFill = Color.White.copy(alpha = 0.10f)
private val GlassFillPressed = Color.White.copy(alpha = 0.32f)
private val GlassBorder = Color.White.copy(alpha = 0.28f)
private val GlassText = Color.White.copy(alpha = 0.75f)

/**
 * Sega Genesis / Mega Drive emulator screen (libretro Genesis Plus GX via LibretroDroid).
 * The player picks his own ROM file; nothing is bundled in the app.
 */
@Composable
fun EmulatorScreen(onBack: () -> Unit) {
  // The rest of the app is RTL; a game pad must always be LTR (left button = left).
  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
    EmulatorContent(onBack)
  }
}

@Composable
private fun EmulatorContent(onBack: () -> Unit) {
  val context = LocalContext.current
  var romPath by rememberSaveable { mutableStateOf<String?>(null) }
  var romKey by rememberSaveable { mutableStateOf("game") }
  var errorMsg by remember { mutableStateOf<String?>(null) }
  // Online room chosen BEFORE the game starts; the player screen joins it automatically.
  var pendingRoom by rememberSaveable { mutableStateOf<String?>(null) }
  var joinCode by remember { mutableStateOf("") }
  // false = Sega (Genesis Plus GX), true = Neo Geo (FBNeo, zip romsets + neogeo.zip BIOS)
  var neoGeo by rememberSaveable { mutableStateOf(false) }
  var neoBios by remember { mutableStateOf(File(context.filesDir, "fbneo/neogeo.zip").exists()) }

  val picker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
      if (uri == null) return@rememberLauncherForActivityResult
      try {
        val displayName =
          context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
          } ?: (uri.lastPathSegment ?: "game")
        if (neoGeo) {
          // Neo Geo romsets must stay zipped under their original name (e.g. mslug.zip).
          val low = displayName.lowercase().replace(Regex("[^a-z0-9_.-]"), "_")
          if (!low.endsWith(".zip")) {
            errorMsg = "برای نئوجئو فایل زیپ لازم است (مثلا mslug.zip)"
            return@rememberLauncherForActivityResult
          }
          val sysDir = File(context.filesDir, "fbneo").apply { mkdirs() }
          val romDir = File(context.filesDir, "roms/neogeo").apply { mkdirs() }
          val bios = File(sysDir, "neogeo.zip")
          if (low == "neogeo.zip") {
            context.contentResolver.openInputStream(uri)?.use { input ->
              bios.outputStream().use { input.copyTo(it) }
            } ?: throw java.io.IOException("open")
            bios.copyTo(File(romDir, "neogeo.zip"), overwrite = true)
            neoBios = true
            errorMsg = null
            Toast.makeText(context, "BIOS ذخیره شد", Toast.LENGTH_SHORT).show()
            return@rememberLauncherForActivityResult
          }
          if (!bios.exists()) {
            errorMsg = "اول BIOS نئوجئو (neogeo.zip) را انتخاب کن"
            return@rememberLauncherForActivityResult
          }
          val game = File(romDir, low)
          context.contentResolver.openInputStream(uri)?.use { input ->
            game.outputStream().use { input.copyTo(it) }
          } ?: throw java.io.IOException("open")
          if (game.length() < 64 * 1024) {
            errorMsg = "فایل بازی معتبر نیست"
            return@rememberLauncherForActivityResult
          }
          if (!File(romDir, "neogeo.zip").exists()) bios.copyTo(File(romDir, "neogeo.zip"), overwrite = true)
          errorMsg = null
          romKey = "ng_" + low.removeSuffix(".zip").take(56)
          romPath = game.absolutePath
          return@rememberLauncherForActivityResult
        }
        val key = displayName.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_").take(60).ifBlank { "game" }
        val dir = File(context.filesDir, "roms").apply { mkdirs() }
        var ext = displayName.substringAfterLast('.', "").lowercase()
        var out = File(dir, "$key.$ext")
        if (ext == "zip") {
          // The emulator core can crash on zip files: extract the ROM inside ourselves.
          var found = false
          java.util.zip.ZipInputStream(context.contentResolver.openInputStream(uri)?.buffered() ?: throw java.io.IOException("open")).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
              val eExt = e.name.substringAfterLast('.', "").lowercase()
              if (!e.isDirectory && eExt in ROM_EXTENSIONS) {
                ext = eExt
                out = File(dir, "$key.$ext")
                out.outputStream().use { zip.copyTo(it) }
                found = true
                break
              }
              e = zip.nextEntry
            }
          }
          if (!found) {
            errorMsg = "داخل زیپ فایل بازی (.md .bin .gen .smd) پیدا نشد"
            return@rememberLauncherForActivityResult
          }
        } else {
          if (ext !in ROM_EXTENSIONS) {
            errorMsg = "این فرمت پشتیبانی نمی‌شود (.md .bin .gen .smd)"
            return@rememberLauncherForActivityResult
          }
          context.contentResolver.openInputStream(uri)?.use { input ->
            out.outputStream().use { input.copyTo(it) }
          } ?: throw java.io.IOException("cannot open file")
        }
        if (out.length() < 64 * 1024) {
          errorMsg = "فایل بازی معتبر نیست"
          return@rememberLauncherForActivityResult
        }
        errorMsg = null
        romKey = key
        romPath = out.absolutePath
      } catch (t: Throwable) {
        errorMsg = "خواندن فایل ناموفق بود"
      }
    }

  BackHandler(onBack = { if (romPath != null) romPath = null else onBack() })

  Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
    val path = romPath
    if (path == null) {
      Column(
        modifier = Modifier.fillMaxSize().background(ObsidianBg).statusBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          if (!neoGeo) Button(onClick = {}) { Text("سگا") }
          else TextButton(onClick = { neoGeo = false; errorMsg = null }) { Text("سگا") }
          if (neoGeo) Button(onClick = {}) { Text("نئوجئو") }
          else TextButton(onClick = { neoGeo = true; errorMsg = null }) { Text("نئوجئو") }
        }
        Spacer(Modifier.size(12.dp))
        Text(
          if (neoGeo) "امولاتور نئوجئو (Neo Geo)" else "امولاتور سگا (Genesis / Mega Drive)",
          color = NeonCyan,
          fontSize = 20.sp,
          fontWeight = FontWeight.ExtraBold,
        )
        Spacer(Modifier.size(8.dp))
        Text(
          if (neoGeo) "فایل بازی را به‌صورت zip انتخاب کن (مثلا mslug.zip). برای اولین بار BIOS (neogeo.zip) هم لازم است."
          else "فایل بازی (ROM) خودت را انتخاب کن. فرمت‌ها: .md .bin .gen .smd",
          color = TextSecondary,
          fontSize = 13.sp,
        )
        Spacer(Modifier.size(20.dp))
        val room = pendingRoom
        if (room == null) {
          Text("بازی آنلاین ۲ نفره (اختیاری)", color = TextSecondary, fontSize = 13.sp)
          Spacer(Modifier.size(8.dp))
          Button(onClick = { pendingRoom = newRoomCode() }) { Text("ساخت اتاق") }
          Spacer(Modifier.size(8.dp))
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = joinCode,
              onValueChange = { joinCode = it.uppercase().filter { ch -> ch.isLetterOrDigit() }.take(8) },
              label = { Text("کد اتاق") },
              singleLine = true,
              modifier = Modifier.width(150.dp),
            )
            TextButton(enabled = joinCode.length >= 4, onClick = { pendingRoom = joinCode }) { Text("ورود به اتاق") }
          }
        } else {
          Text("اتاق شما", color = TextSecondary, fontSize = 13.sp)
          SelectionContainer {
            Text(room, color = NeonCyan, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
          }
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { copyText(context, room) }) { Text("کپی کد") }
            TextButton(onClick = { pendingRoom = null }) { Text("لغو اتاق", color = TextSecondary) }
          }
          Text(
            "کد را به دوستت بده؛ او هم همین کد را وارد کند. هر دو ROM یکسان را انتخاب کنید.",
            color = TextSecondary,
            fontSize = 12.sp,
          )
        }
        Spacer(Modifier.size(16.dp))
        if (neoGeo && !neoBios) {
          Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("انتخاب BIOS (neogeo.zip)") }
        } else {
          Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text(if (neoGeo) "انتخاب بازی (zip)" else "انتخاب ROM") }
          if (neoGeo) TextButton(onClick = { neoBios = false }) { Text("تعویض BIOS", color = TextSecondary) }
        }
        errorMsg?.let {
          Spacer(Modifier.size(10.dp))
          Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp)
        }
        Spacer(Modifier.size(10.dp))
        TextButton(onClick = onBack) { Text("بازگشت", color = TextSecondary) }
      }
    } else {
      EmulatorPlayer(romPath = path, romKey = romKey, neoGeo = neoGeo, autoRoom = pendingRoom, onExit = { romPath = null })
    }
  }
}

@Composable
private fun EmulatorPlayer(romPath: String, romKey: String, neoGeo: Boolean, autoRoom: String?, onExit: () -> Unit) {
  val context = LocalContext.current
  val activity = context as ComponentActivity
  val scope = rememberCoroutineScope()

  val savesDir = remember { File(context.filesDir, "saves").apply { mkdirs() } }
  val sramFile = File(savesDir, "$romKey.srm")
  val stateFile = File(savesDir, "$romKey.state")

  val retroView =
    remember(romPath) {
      val data =
        GLRetroViewData(context).apply {
          coreFilePath = if (neoGeo) NEOGEO_CORE else GENESIS_CORE
          gameFilePath = romPath
          systemDirectory = context.filesDir.absolutePath
          savesDirectory = savesDir.absolutePath
          // Restore in-game save (battery RAM) if one exists.
          if (sramFile.exists()) saveRAMState = sramFile.readBytes()
        }
      GLRetroView(context, data)
    }

  fun saveSram() {
    scope.launch(Dispatchers.IO) {
      try {
        val bytes = retroView.serializeSRAM()
        if (bytes.isNotEmpty()) sramFile.writeBytes(bytes)
      } catch (_: Throwable) {}
    }
  }

  DisposableEffect(retroView) {
    activity.lifecycle.addObserver(retroView)
    val saver = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_PAUSE) saveSram() }
    activity.lifecycle.addObserver(saver)
    onDispose {
      saveSram()
      activity.lifecycle.removeObserver(saver)
      activity.lifecycle.removeObserver(retroView)
    }
  }

  // Auto-save in-game saves every few seconds.
  LaunchedEffect(retroView) {
    while (true) {
      delay(8_000)
      saveSram()
    }
  }

  // ---- Online (room) mode ----
  var net by remember { mutableStateOf<NetplayClient?>(null) }
  var slot by remember { mutableStateOf(0) } // 0 = offline, 1 = host (player 1), 2 = guest (player 2)
  var peerOn by remember { mutableStateOf(false) }
  var pingMs by remember { mutableStateOf(0L) }
  var showNetDialog by remember { mutableStateOf(false) }
  val lastDue = remember { longArrayOf(0L) }
  val lastInput = remember { longArrayOf(0L) } // last key event (mine or the peer's)
  val lastPush = remember { longArrayOf(0L) } // host: last time a state was sent
  val syncReq = remember { Channel<Unit>(Channel.CONFLATED) } // host: "send a state now"
  val ffJob = remember { arrayOfNulls<Job>(1) } // guest: catch-up after loading a state

  fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

  fun press(code: Int, down: Boolean) {
    lastInput[0] = SystemClock.elapsedRealtime()
    val action = if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP
    val n = net
    if (n != null && slot != 0 && peerOn) {
      n.sendKey(code, down)
      // Apply my own input after ~one-way latency so both phones see the same timing.
      val now = SystemClock.elapsedRealtime()
      val due = maxOf(now + n.oneWayMs, lastDue[0])
      lastDue[0] = due
      val port = slot - 1
      scope.launch {
        delay(due - now)
        retroView.sendKeyEvent(action, code, port)
      }
    } else {
      retroView.sendKeyEvent(action, code, if (slot == 2) 1 else 0)
    }
  }

  // ---- Save / load (online: the host's state is the shared one) ----
  suspend fun saveLocal(): Boolean =
    withContext(Dispatchers.IO) {
      try {
        stateFile.writeBytes(retroView.serializeState())
        true
      } catch (_: Throwable) {
        false
      }
    }

  /** 1 = loaded, 0 = failed, -1 = nothing saved yet. */
  suspend fun loadLocal(): Int {
    if (!stateFile.exists()) return -1
    return withContext(Dispatchers.IO) {
      try {
        if (retroView.unserializeState(stateFile.readBytes())) 1 else 0
      } catch (_: Throwable) {
        0
      }
    }
  }

  fun saveState() {
    val n = net
    scope.launch {
      if (n != null && peerOn && slot == 2) {
        n.sendCmd("save") // the host saves; both players get the result
        return@launch
      }
      val ok = saveLocal()
      toast(if (ok) "ذخیره شد" else "ذخیره ناموفق بود")
      if (n != null && peerOn) n.sendCmd(if (ok) "saved" else "savefail")
    }
  }

  fun loadState() {
    val n = net
    scope.launch {
      if (n != null && peerOn && slot == 2) {
        n.sendCmd("load") // the host loads and pushes the state to both
        return@launch
      }
      val r = loadLocal()
      toast(
        when (r) {
          1 -> "بارگذاری شد"
          -1 -> "هنوز چیزی ذخیره نکردی"
          else -> "بارگذاری ناموفق بود"
        },
      )
      if (n != null && peerOn) {
        when (r) {
          1 -> {
            n.sendCmd("loaded")
            syncReq.trySend(Unit) // guest gets the loaded state right away
          }
          -1 -> n.sendCmd("nosave")
          else -> n.sendCmd("loadfail")
        }
      }
    }
  }

  fun disconnectNet() {
    net?.close()
    net = null
    slot = 0
    peerOn = false
  }

  fun connectNet(url: String, code: String) {
    disconnectNet()
    val client =
      NetplayClient(
        baseUrl = url,
        room = code,
        romKey = romKey,
        listener =
          object : NetplayClient.Listener {
            override fun onHello(s: Int, peers: Int) {
              slot = s
              peerOn = peers > 0
            }
            override fun onPeer(on: Boolean) {
              peerOn = on
            }
            override fun onKey(c: Int, d: Boolean) {
              lastInput[0] = SystemClock.elapsedRealtime()
              val port = if (slot == 1) 1 else 0
              retroView.sendKeyEvent(if (d) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, c, port)
            }
            override fun onState(bytes: ByteArray) {
              if (slot != 2) return
              val age = ((net?.oneWayMs ?: 50L) + STATE_AGE_EXTRA_MS).coerceIn(30L, 250L)
              ffJob[0]?.cancel()
              ffJob[0] =
                scope.launch {
                  val ok =
                    withContext(Dispatchers.IO) {
                      try {
                        retroView.unserializeState(bytes)
                      } catch (_: Throwable) {
                        false
                      }
                    }
                  if (ok) {
                    // The snapshot is already `age` ms old: run faster for that long so this
                    // screen catches up with the host instead of jumping back in time.
                    try {
                      retroView.frameSpeed = 2
                      delay(age)
                    } finally {
                      retroView.frameSpeed = 1
                    }
                  }
                }
            }
            override fun onCmd(action: String) {
              when (action) {
                "save" -> if (slot == 1) saveState()
                "load" -> if (slot == 1) loadState()
                "saved" -> toast("ذخیره شد")
                "savefail" -> toast("ذخیره ناموفق بود")
                "loaded" -> toast("بارگذاری شد")
                "nosave" -> toast("هنوز چیزی ذخیره نشده")
                "loadfail" -> toast("بارگذاری ناموفق بود")
              }
            }
            override fun onRomMismatch() = toast("بازی دو طرف یکی نیست!")
            override fun onPing(rttMs: Long) {
              pingMs = rttMs
            }
            override fun onClosed(reason: String) {
              toast(reason)
              net = null
              slot = 0
              peerOn = false
            }
          },
      )
    net = client
    client.connect()
  }

  suspend fun pushState(n: NetplayClient) {
    withContext(Dispatchers.IO) {
      try {
        n.sendState(retroView.serializeState())
      } catch (_: Throwable) {}
    }
    lastPush[0] = SystemClock.elapsedRealtime()
  }

  // Host: send a state when the guest joins, on load, when play settles after button presses
  // (so the correction is invisible), and rarely as a safety net while play never stops.
  LaunchedEffect(net, slot, peerOn) {
    val n = net
    if (n == null || !peerOn) return@LaunchedEffect
    n.sendRom()
    if (slot != 1) return@LaunchedEffect
    pushState(n)
    while (true) {
      delay(150)
      val now = SystemClock.elapsedRealtime()
      val dirty = lastInput[0] > lastPush[0]
      val requested = syncReq.tryReceive().isSuccess
      val settled = dirty && now - lastInput[0] >= 700
      val busy = dirty && now - lastPush[0] >= 12_000
      val heartbeat = now - lastPush[0] >= 30_000
      if (requested || settled || busy || heartbeat) pushState(n)
    }
  }

  // Joined a room on the start screen: connect as soon as the game is up.
  LaunchedEffect(romPath) { autoRoom?.let { connectNet(NETPLAY_URL, it) } }

  DisposableEffect(Unit) { onDispose { net?.close() } }

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val landscape = maxWidth > maxHeight
    val gameHeight: Dp = maxWidth * (224f / 320f)

    // One single emulator view for both orientations (a view can't be re-parented).
    AndroidView(
      factory = { retroView },
      modifier =
        if (landscape) Modifier.align(Alignment.Center).fillMaxHeight().aspectRatio(320f / 224f)
        else Modifier.align(Alignment.TopCenter).statusBarsPadding().fillMaxWidth().aspectRatio(320f / 224f),
    )

    val controlsModifier =
      if (landscape) Modifier.fillMaxSize().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp)
      else
        Modifier.align(Alignment.BottomCenter)
          .fillMaxWidth()
          .height((maxHeight - gameHeight - 36.dp).coerceAtLeast(260.dp))
          .navigationBarsPadding()
          .padding(12.dp)

    Box(modifier = controlsModifier) {
      // Top menu: save / load / exit
      Row(
        modifier = Modifier.align(Alignment.TopCenter),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        val n = net
        GlassChip(
          if (n == null) "آنلاین" else "${n.room} " + (if (peerOn) "✓ ${pingMs}ms" else "…"),
        ) { if (n == null) showNetDialog = true else copyText(context, n.room) }
        GlassChip("ذخیره") { saveState() }
        GlassChip("بارگذاری") { loadState() }
        GlassChip("خروج") { onExit() }
      }

      DPad(
        modifier = Modifier.align(Alignment.CenterStart),
        size = 150.dp,
        onKey = ::press,
      )

      // Sega-style face buttons: A B C on a rising arc, X Y Z (6-button pad) above them.
      Column(
        modifier = Modifier.align(Alignment.CenterEnd),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        if (neoGeo) {
          // Neo Geo A B C D -> FBNeo fire 1..4 = RetroPad B, A, Y, X (LibretroDroid maps keys 1:1).
          Row {
            FaceButton("C", KeyEvent.KEYCODE_BUTTON_Y, ::press, size = 56.dp, lift = 4.dp)
            FaceButton("D", KeyEvent.KEYCODE_BUTTON_X, ::press, size = 56.dp, lift = (-4).dp)
          }
          Spacer(Modifier.size(6.dp))
          Row {
            FaceButton("A", KeyEvent.KEYCODE_BUTTON_B, ::press, size = 62.dp, lift = 4.dp)
            FaceButton("B", KeyEvent.KEYCODE_BUTTON_A, ::press, size = 62.dp, lift = (-4).dp)
          }
        } else {
          Row {
            FaceButton("X", KeyEvent.KEYCODE_BUTTON_L1, ::press, size = 44.dp, lift = 6.dp)
            FaceButton("Y", KeyEvent.KEYCODE_BUTTON_X, ::press, size = 44.dp, lift = 0.dp)
            FaceButton("Z", KeyEvent.KEYCODE_BUTTON_R1, ::press, size = 44.dp, lift = (-6).dp)
          }
          Spacer(Modifier.size(6.dp))
          Row {
            FaceButton("A", KeyEvent.KEYCODE_BUTTON_Y, ::press, size = 62.dp, lift = 12.dp)
            FaceButton("B", KeyEvent.KEYCODE_BUTTON_B, ::press, size = 62.dp, lift = 0.dp)
            FaceButton("C", KeyEvent.KEYCODE_BUTTON_A, ::press, size = 62.dp, lift = (-12).dp)
          }
        }
      }

      Row(
        modifier = Modifier.align(Alignment.BottomCenter),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        PillButton(if (neoGeo) "COIN" else "MODE", KeyEvent.KEYCODE_BUTTON_SELECT, ::press)
        PillButton("START", KeyEvent.KEYCODE_BUTTON_START, ::press)
      }
    }

    if (showNetDialog) {
      NetplayDialog(
        onDismiss = { showNetDialog = false },
        onConnect = { code ->
          showNetDialog = false
          connectNet(NETPLAY_URL, code)
        },
      )
    }
  }
}

@Composable
private fun NetplayDialog(onDismiss: () -> Unit, onConnect: (String) -> Unit) {
  var code by remember { mutableStateOf("") }
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("بازی آنلاین ۲ نفره") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("هر دو نفر باید یک ROM یکسان انتخاب کرده باشند.", fontSize = 12.sp)
        OutlinedTextField(
          value = code,
          onValueChange = { code = it.uppercase().filter { ch -> ch.isLetterOrDigit() }.take(8) },
          label = { Text("کد اتاق (برای ورود)") },
          singleLine = true,
        )
      }
    },
    confirmButton = {
      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        TextButton(
          enabled = code.length >= 4,
          onClick = { onConnect(code) },
        ) { Text("ورود به اتاق") }
        TextButton(
          onClick = {
            val chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
            onConnect((1..5).map { chars.random() }.joinToString(""))
          },
        ) { Text("ساخت اتاق") }
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text("بستن") } },
  )
}

/** 8-direction glass D-pad: slide the thumb to change direction, diagonals work. */
@Composable
private fun DPad(modifier: Modifier, size: Dp, onKey: (Int, Boolean) -> Unit) {
  // 0=up 1=down 2=left 3=right
  val active = remember { mutableStateListOf(false, false, false, false) }
  val codes =
    remember {
      intArrayOf(KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT)
    }

  fun set(i: Int, v: Boolean) {
    if (active[i] != v) {
      active[i] = v
      onKey(codes[i], v)
    }
  }

  Box(
    modifier =
      modifier
        .size(size)
        .clip(CircleShape)
        .background(GlassFill)
        .border(1.dp, GlassBorder, CircleShape)
        .pointerInput(Unit) {
          awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            fun update(p: Offset) {
              val cx = this.size.width / 2f
              val cy = this.size.height / 2f
              val dead = minOf(cx, cy) * 0.26f
              val dx = p.x - cx
              val dy = p.y - cy
              set(0, dy < -dead)
              set(1, dy > dead)
              set(2, dx < -dead)
              set(3, dx > dead)
            }
            update(down.position)
            while (true) {
              val event = awaitPointerEvent()
              val change = event.changes.firstOrNull { it.id == down.id } ?: break
              if (!change.pressed) break
              update(change.position)
              change.consume()
            }
            for (i in 0..3) set(i, false)
          }
        },
    contentAlignment = Alignment.Center,
  ) {
    val s = size
    ArrowMark("▲", active[0], Modifier.align(Alignment.TopCenter).padding(top = s * 0.08f))
    ArrowMark("▼", active[1], Modifier.align(Alignment.BottomCenter).padding(bottom = s * 0.08f))
    ArrowMark("◀", active[2], Modifier.align(Alignment.CenterStart).padding(start = s * 0.10f))
    ArrowMark("▶", active[3], Modifier.align(Alignment.CenterEnd).padding(end = s * 0.10f))
  }
}

@Composable
private fun ArrowMark(glyph: String, on: Boolean, modifier: Modifier) {
  Text(glyph, color = if (on) Color.White else GlassText.copy(alpha = 0.5f), fontSize = 20.sp, modifier = modifier)
}

@Composable
private fun FaceButton(
  label: String,
  keyCode: Int,
  press: (Int, Boolean) -> Unit,
  size: Dp,
  lift: Dp,
) {
  var held by remember { mutableStateOf(false) }
  Box(
    modifier =
      Modifier.padding(horizontal = 4.dp)
        .offset(y = -lift)
        .size(size)
        .clip(CircleShape)
        .background(if (held) GlassFillPressed else GlassFill)
        .border(1.dp, GlassBorder, CircleShape)
        .pointerInput(keyCode) {
          detectTapGestures(
            onPress = {
              held = true
              press(keyCode, true)
              try {
                tryAwaitRelease()
              } finally {
                held = false
                press(keyCode, false)
              }
            }
          )
        },
    contentAlignment = Alignment.Center,
  ) {
    Text(label, color = GlassText, fontSize = if (size >= 60.dp) 18.sp else 13.sp, fontWeight = FontWeight.Bold)
  }
}

@Composable
private fun PillButton(label: String, keyCode: Int, press: (Int, Boolean) -> Unit) {
  var held by remember { mutableStateOf(false) }
  val shape = RoundedCornerShape(12.dp)
  Box(
    modifier =
      Modifier.size(width = 76.dp, height = 34.dp)
        .clip(shape)
        .background(if (held) GlassFillPressed else GlassFill)
        .border(1.dp, GlassBorder, shape)
        .pointerInput(keyCode) {
          detectTapGestures(
            onPress = {
              held = true
              press(keyCode, true)
              try {
                tryAwaitRelease()
              } finally {
                held = false
                press(keyCode, false)
              }
            }
          )
        },
    contentAlignment = Alignment.Center,
  ) {
    Text(label, color = GlassText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
  }
}

@Composable
private fun GlassChip(label: String, onClick: () -> Unit) {
  val shape = RoundedCornerShape(10.dp)
  Box(
    modifier =
      Modifier.clip(shape)
        .background(GlassFill)
        .border(1.dp, GlassBorder, shape)
        .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) }
        .padding(horizontal = 12.dp, vertical = 6.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(label, color = GlassText, fontSize = 12.sp, fontWeight = FontWeight.Medium)
  }
}
