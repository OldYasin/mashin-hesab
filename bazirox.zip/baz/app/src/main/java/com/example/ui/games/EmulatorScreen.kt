package com.example.ui.games

import android.net.Uri
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextSecondary
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import java.io.File

/** Name of the Genesis Plus GX libretro core inside jniLibs (downloaded by the `fetchGenesisCore` Gradle task). */
private const val GENESIS_CORE = "libgenesis_plus_gx_libretro_android.so"

/**
 * Sega Genesis / Mega Drive emulator screen (libretro Genesis Plus GX via LibretroDroid).
 * The player picks his own ROM file; nothing is bundled in the app.
 */
@Composable
fun EmulatorScreen(onBack: () -> Unit) {
  val context = LocalContext.current
  var romPath by remember { mutableStateOf<String?>(null) }
  var errorMsg by remember { mutableStateOf<String?>(null) }

  val picker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
      if (uri == null) return@rememberLauncherForActivityResult
      try {
        val dir = File(context.filesDir, "roms").apply { mkdirs() }
        val ext = (uri.lastPathSegment ?: "").substringAfterLast('.', "bin").lowercase().take(5)
        val out = File(dir, "current.$ext")
        context.contentResolver.openInputStream(uri)?.use { input ->
          out.outputStream().use { input.copyTo(it) }
        } ?: throw java.io.IOException("cannot open file")
        errorMsg = null
        romPath = out.absolutePath
      } catch (t: Throwable) {
        errorMsg = "خواندن فایل ناموفق بود"
      }
    }

  BackHandler(onBack = { if (romPath != null) romPath = null else onBack() })

  Box(modifier = Modifier.fillMaxSize().background(ObsidianBg)) {
    val path = romPath
    if (path == null) {
      Column(
        modifier = Modifier.fillMaxSize().statusBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
      ) {
        Text("امولاتور سگا (Genesis / Mega Drive)", color = NeonCyan, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.size(8.dp))
        Text(
          "فایل بازی (ROM) خودت را انتخاب کن. فرمت‌ها: .md .bin .gen .smd",
          color = TextSecondary,
          fontSize = 13.sp,
        )
        Spacer(Modifier.size(20.dp))
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("انتخاب ROM") }
        errorMsg?.let {
          Spacer(Modifier.size(10.dp))
          Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp)
        }
        Spacer(Modifier.size(10.dp))
        TextButton(onClick = onBack) { Text("بازگشت", color = TextSecondary) }
      }
    } else {
      EmulatorPlayer(romPath = path)
    }
  }
}

@Composable
private fun EmulatorPlayer(romPath: String) {
  val context = LocalContext.current
  val activity = context as ComponentActivity

  val retroView =
    remember(romPath) {
      val data =
        GLRetroViewData(context).apply {
          coreFilePath = GENESIS_CORE
          gameFilePath = romPath
          systemDirectory = context.filesDir.absolutePath
          savesDirectory = File(context.filesDir, "saves").apply { mkdirs() }.absolutePath
        }
      GLRetroView(context, data)
    }

  DisposableEffect(retroView) {
    activity.lifecycle.addObserver(retroView)
    onDispose { activity.lifecycle.removeObserver(retroView) }
  }

  fun press(code: Int, down: Boolean) {
    retroView.sendKeyEvent(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 0)
  }

  Column(modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
    // Genesis output is 4:3-ish (320x224).
    AndroidView(
      factory = { retroView },
      modifier = Modifier.fillMaxWidth().aspectRatio(320f / 224f),
    )

    Box(modifier = Modifier.fillMaxSize().padding(12.dp)) {
      // D-pad (left)
      Column(
        modifier = Modifier.align(Alignment.CenterStart),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        PadButton("▲", KeyEvent.KEYCODE_DPAD_UP, ::press)
        Row {
          PadButton("◀", KeyEvent.KEYCODE_DPAD_LEFT, ::press)
          Spacer(Modifier.size(52.dp))
          PadButton("▶", KeyEvent.KEYCODE_DPAD_RIGHT, ::press)
        }
        PadButton("▼", KeyEvent.KEYCODE_DPAD_DOWN, ::press)
      }

      // Face buttons (right). Genesis Plus GX RetroPad mapping:
      // MD A=Y, B=B, C=A, X=L1, Y=X, Z=R1. Street Fighter II SCE: X/Y/Z punches, A/B/C kicks.
      Column(modifier = Modifier.align(Alignment.CenterEnd), horizontalAlignment = Alignment.CenterHorizontally) {
        Row {
          PadButton("X", KeyEvent.KEYCODE_BUTTON_L1, ::press)
          PadButton("Y", KeyEvent.KEYCODE_BUTTON_X, ::press)
          PadButton("Z", KeyEvent.KEYCODE_BUTTON_R1, ::press)
        }
        Row {
          PadButton("A", KeyEvent.KEYCODE_BUTTON_Y, ::press)
          PadButton("B", KeyEvent.KEYCODE_BUTTON_B, ::press)
          PadButton("C", KeyEvent.KEYCODE_BUTTON_A, ::press)
        }
      }

      Row(
        modifier = Modifier.align(Alignment.BottomCenter),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        PadButton("MODE", KeyEvent.KEYCODE_BUTTON_SELECT, ::press, wide = true)
        PadButton("START", KeyEvent.KEYCODE_BUTTON_START, ::press, wide = true)
      }
    }
  }
}

@Composable
private fun PadButton(
  label: String,
  keyCode: Int,
  press: (Int, Boolean) -> Unit,
  wide: Boolean = false,
) {
  var held by remember { mutableStateOf(false) }
  Box(
    modifier =
      Modifier.padding(4.dp)
        .size(width = if (wide) 72.dp else 52.dp, height = if (wide) 36.dp else 52.dp)
        .clip(if (wide) RoundedCornerShape(12.dp) else CircleShape)
        .background(if (held) NeonCyan.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.12f))
        .pointerInput(keyCode) {
          detectTapGestures(
            onPress = {
              held = true
              press(keyCode, true)
              try {
                tryAwaitRelease()
              } finally {
                held = false
                press(keyCode, false)
              }
            }
          )
        },
    contentAlignment = Alignment.Center,
  ) {
    Text(label, color = Color.White, fontSize = if (wide) 11.sp else 15.sp, fontWeight = FontWeight.Bold)
  }
}
