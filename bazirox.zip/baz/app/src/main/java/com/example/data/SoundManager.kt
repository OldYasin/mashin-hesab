package com.example.data

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/** Every sound effect in the app. They are synthesized in code, so no audio files are needed. */
enum class Sfx {
  TAP, // placing a piece (tic-tac-toe)
  DROP, // disc landing (connect four)
  STEP, // a token hops one square
  DICE, // dice rattle
  CAPTURE, // a token is knocked home
  LADDER,
  SNAKE,
  WIN,
  LOSE,
  DRAW,
  MSG_SEND,
  MSG_RECEIVE,
}

/**
 * Tiny sound engine: each effect is rendered once into a PCM buffer and replayed through a static
 * AudioTrack. All work happens on a background thread and every call is wrapped in try/catch, so a
 * device without audio can never crash a game.
 */
object SoundManager {
  private const val RATE = 22050
  private const val PREFS = "bazirox_sound"
  private const val KEY_ENABLED = "enabled"

  private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "sfx").apply { isDaemon = true } }
  private val tracks = HashMap<Sfx, AudioTrack>()
  private var prefs: android.content.SharedPreferences? = null

  @Volatile var enabled: Boolean = true
    private set

  fun init(context: Context) {
    if (prefs != null) return
    prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    enabled = prefs?.getBoolean(KEY_ENABLED, true) ?: true
    worker.execute { runCatching { Sfx.values().forEach { trackFor(it) } } } // pre-render
  }

  fun setEnabled(value: Boolean) {
    enabled = value
    prefs?.edit()?.putBoolean(KEY_ENABLED, value)?.apply()
    if (value) play(Sfx.TAP)
  }

  fun play(sfx: Sfx) {
    if (!enabled) return
    worker.execute {
      runCatching {
        val t = trackFor(sfx)
        t.stop()
        t.reloadStaticData()
        t.play()
      }
    }
  }

  fun release() {
    worker.execute {
      runCatching { tracks.values.forEach { it.release() } }
      tracks.clear()
    }
  }

  // ---------------------------------------------------------------- synthesis

  private fun trackFor(sfx: Sfx): AudioTrack =
    tracks.getOrPut(sfx) {
      val pcm = render(sfx)
      val track =
        AudioTrack.Builder()
          .setAudioAttributes(
            AudioAttributes.Builder()
              .setUsage(AudioAttributes.USAGE_GAME)
              .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
              .build()
          )
          .setAudioFormat(
            AudioFormat.Builder()
              .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
              .setSampleRate(RATE)
              .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
              .build()
          )
          .setBufferSizeInBytes(pcm.size * 2)
          .setTransferMode(AudioTrack.MODE_STATIC)
          .build()
      track.write(pcm, 0, pcm.size)
      track
    }

  /** One note: [freq] Hz (glides to [freqEnd] if > 0), [ms] long, starting at [startMs]. */
  private class Note(
    val freq: Float,
    val ms: Int,
    val startMs: Int = 0,
    val vol: Float = 0.5f,
    val freqEnd: Float = 0f,
    val square: Boolean = false,
    val noise: Boolean = false,
  )

  private fun render(sfx: Sfx): ShortArray {
    val notes: List<Note> =
      when (sfx) {
        Sfx.TAP -> listOf(Note(520f, 70, vol = 0.5f, freqEnd = 380f))
        Sfx.DROP -> listOf(Note(300f, 90, freqEnd = 120f, vol = 0.6f), Note(0f, 40, startMs = 70, vol = 0.25f, noise = true))
        Sfx.STEP -> listOf(Note(700f, 45, vol = 0.3f))
        Sfx.DICE ->
          (0 until 7).map { i -> Note(0f, 28, startMs = i * 45, vol = 0.35f, noise = true) } +
            listOf(Note(420f, 60, startMs = 330, vol = 0.4f))
        Sfx.CAPTURE -> listOf(Note(500f, 160, freqEnd = 130f, vol = 0.55f, square = true), Note(0f, 70, vol = 0.35f, noise = true))
        Sfx.LADDER -> listOf(523f, 659f, 784f, 1047f).mapIndexed { i, f -> Note(f, 110, startMs = i * 90, vol = 0.45f) }
        Sfx.SNAKE -> listOf(Note(520f, 520, freqEnd = 110f, vol = 0.5f, square = true))
        Sfx.WIN ->
          listOf(523f, 659f, 784f, 1047f, 784f, 1047f).mapIndexed { i, f ->
            Note(f, if (i == 5) 420 else 130, startMs = i * 130, vol = 0.5f)
          }
        Sfx.LOSE -> listOf(392f, 349f, 311f, 262f).mapIndexed { i, f -> Note(f, 200, startMs = i * 170, vol = 0.45f, square = true) }
        Sfx.DRAW -> listOf(Note(440f, 150, vol = 0.45f), Note(440f, 150, startMs = 190, vol = 0.45f))
        Sfx.MSG_SEND -> listOf(Note(660f, 60, vol = 0.4f), Note(880f, 80, startMs = 55, vol = 0.4f))
        Sfx.MSG_RECEIVE -> listOf(Note(988f, 80, vol = 0.45f), Note(740f, 140, startMs = 85, vol = 0.45f))
      }

    val totalMs = notes.maxOf { it.startMs + it.ms } + 20
    val out = FloatArray(RATE * totalMs / 1000)
    val rnd = Random(7)
    for (n in notes) {
      val start = RATE * n.startMs / 1000
      val len = RATE * n.ms / 1000
      var phase = 0.0
      for (i in 0 until len) {
        val idx = start + i
        if (idx >= out.size) break
        val t = i.toFloat() / len
        val f = if (n.freqEnd > 0f) n.freq + (n.freqEnd - n.freq) * t else n.freq
        phase += 2.0 * PI * f / RATE
        val raw =
          when {
            n.noise -> rnd.nextFloat() * 2f - 1f
            n.square -> if (sin(phase) >= 0) 0.6f else -0.6f
            else -> sin(phase).toFloat()
          }
        // short attack + exponential decay: avoids clicks and gives a "plucked" feel
        val attack = minOf(1f, i / (RATE * 0.004f))
        val env = attack * exp(-3.2f * t)
        out[idx] += raw * env * n.vol
      }
    }
    return ShortArray(out.size) { (out[it].coerceIn(-1f, 1f) * 32000f).toInt().toShort() }
  }
}
