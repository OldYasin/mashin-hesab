package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Edit
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import kotlinx.coroutines.delay
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.CPanelConfig
import com.example.data.UserAccount
import com.example.ui.components.AvatarBadge
import com.example.ui.components.AvatarPalette
import com.example.ui.components.BaziIcons
import com.example.ui.components.GlassGradientCard
import com.example.ui.components.ServerStatusPill
import com.example.ui.components.auroraGamingBackdrop
import com.example.ui.theme.CrimsonMagenta
import com.example.ui.theme.CyberGold
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.ElevatedCardStroke
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPulse
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.graphicsLayer
import com.example.ui.components.fadeSlideIn
import com.example.ui.components.rememberCountUp

@Composable
fun AuthAndProfileScreen(
  currentUser: UserAccount?,
  cPanelConfig: CPanelConfig,
  authLoading: Boolean,
  authError: String?,
  onLogin: (String, String) -> Unit,
  onRegister: (String, String, String, Int) -> Unit,
  onLogout: () -> Unit,
  modifier: Modifier = Modifier,
  avatar: ImageBitmap? = null,
  profileBusy: Boolean = false,
  profileMessage: String? = null,
  onPickAvatar: (Uri) -> Unit = {},
  onRemoveAvatar: () -> Unit = {},
  onChangeName: (String) -> Unit = {},
  onClearProfileMessage: () -> Unit = {},
  myBio: String = "",
  onSaveBio: (String) -> Unit = {},
) {
  Column(
    modifier =
      modifier.fillMaxSize()
        .auroraGamingBackdrop(VioletPulse, NeonCyan)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 14.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    if (currentUser == null) {
      AuthFormCard(
        authLoading = authLoading,
        authError = authError,
        onLogin = onLogin,
        onRegister = onRegister,
      )
    } else {
      ProfileDashboardCard(
        user = currentUser,
        cPanelConfig = cPanelConfig,
        onLogout = onLogout,
        avatar = avatar,
        busy = profileBusy,
        message = profileMessage,
        onPickAvatar = onPickAvatar,
        onRemoveAvatar = onRemoveAvatar,
        onChangeName = onChangeName,
        onClearMessage = onClearProfileMessage,
        myBio = myBio,
        onSaveBio = onSaveBio,
      )
    }

    Spacer(Modifier.height(12.dp))
  }
}

@Composable
private fun AuthFormCard(
  authLoading: Boolean,
  authError: String?,
  onLogin: (String, String) -> Unit,
  onRegister: (String, String, String, Int) -> Unit,
) {
  var isRegisterMode by remember { mutableStateOf(false) }
  var username by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var displayName by remember { mutableStateOf("") }
  var selectedColor by remember { mutableIntStateOf(0) }
  var showPassword by remember { mutableStateOf(false) }
  val usernameOk = Regex("^[\\p{L}\\p{N}_.-]{3,32}\$").matches(username.trim())

  GlassGradientCard(
    modifier = Modifier.fillMaxWidth().widthIn(max = 560.dp).fadeSlideIn(0),
    accentColor = NeonCyan,
    cornerRadius = 24.dp,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        listOf(false to "ورود به حساب", true to "ثبت‌نام سریع").forEach { (reg, label) ->
          val active = isRegisterMode == reg
          Surface(
            onClick = { isRegisterMode = reg },
            modifier = Modifier.weight(1f).height(44.dp).testTag(if (reg) "auth_tab_register" else "auth_tab_login"),
            shape = RoundedCornerShape(12.dp),
            color = if (active) NeonCyan.copy(alpha = 0.2f) else ElevatedCard.copy(alpha = 0.6f),
            border = BorderStroke(1.dp, if (active) NeonCyan else ElevatedCardStroke),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Text(
                label,
                style = MaterialTheme.typography.labelLarge,
                color = if (active) NeonCyan else TextSecondary,
              )
            }
          }
        }
      }

      Text(
        text = "بدون نیاز به شماره موبایل یا ایمیل — فقط نام کاربری و رمز عبور",
        style = MaterialTheme.typography.bodyMedium,
        color = TextSecondary,
      )

      OutlinedTextField(
        value = username,
        onValueChange = { username = it.take(32) },
        label = { Text("نام کاربری (Username)") },
        leadingIcon = { Icon(Icons.Rounded.Person, contentDescription = null, tint = NeonCyan) },
        singleLine = true,
        isError = isRegisterMode && username.isNotBlank() && !usernameOk,
        supportingText =
          if (isRegisterMode) {
            { Text("حروف، عدد و _ . - (۳ تا ۳۲ کاراکتر)") }
          } else null,
        modifier = Modifier.fillMaxWidth().testTag("auth_username_input"),
        colors =
          OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonCyan,
            unfocusedBorderColor = Color.White.copy(alpha = 0.14f),
            focusedContainerColor = Color(0x991E2868),
            unfocusedContainerColor = Color(0x881E2868),
          ),
        shape = RoundedCornerShape(14.dp),
      )

      AnimatedVisibility(
        visible = isRegisterMode,
        enter = fadeIn(tween(220)) + expandVertically(tween(260)),
        exit = fadeOut(tween(150)) + shrinkVertically(tween(200)),
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        OutlinedTextField(
          value = displayName,
          onValueChange = { displayName = it.take(32) },
          label = { Text("نام نمایشی در بازی (اختیاری)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("auth_displayname_input"),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = NeonCyan,
              unfocusedBorderColor = Color.White.copy(alpha = 0.14f),
              focusedContainerColor = Color(0x991E2868),
              unfocusedContainerColor = Color(0x881E2868),
            ),
          shape = RoundedCornerShape(14.dp),
        )

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Text("رنگ آواتار:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
          AvatarPalette.forEachIndexed { idx, col ->
            val sel = selectedColor == idx
            Box(
              modifier =
                Modifier.size(32.dp)
                  .clip(CircleShape)
                  .background(col)
                  .border(if (sel) 2.5.dp else 0.dp, TextPrimary, CircleShape)
                  .clickable { selectedColor = idx },
              contentAlignment = Alignment.Center,
            ) {
              if (sel) Icon(Icons.Rounded.Check, contentDescription = null, tint = ObsidianBg, modifier = Modifier.size(18.dp))
            }
          }
        }
        }
      }

      OutlinedTextField(
        value = password,
        onValueChange = { password = it },
        label = { Text("رمز عبور") },
        leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null, tint = NeonCyan) },
        trailingIcon = {
          IconButton(onClick = { showPassword = !showPassword }) {
            Icon(
              BaziIcons.Visibility,
              contentDescription = "نمایش رمز",
              tint = TextSecondary,
            )
          }
        },
        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("auth_password_input"),
        colors =
          OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonCyan,
            unfocusedBorderColor = Color.White.copy(alpha = 0.14f),
            focusedContainerColor = Color(0x991E2868),
            unfocusedContainerColor = Color(0x881E2868),
          ),
        shape = RoundedCornerShape(14.dp),
      )

      val shake = remember { Animatable(0f) }
      LaunchedEffect(authError) {
        if (!authError.isNullOrBlank()) {
          repeat(3) {
            shake.animateTo(10f, tween(50))
            shake.animateTo(-10f, tween(50))
          }
          shake.animateTo(0f, tween(50))
        }
      }
      AnimatedVisibility(
        visible = !authError.isNullOrBlank(),
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
      ) {
        Text(
          text = authError.orEmpty(),
          style = MaterialTheme.typography.bodyMedium,
          color = CrimsonMagenta,
          modifier = Modifier.graphicsLayer { translationX = shake.value },
        )
      }

      Button(
        onClick = {
          if (isRegisterMode) onRegister(username, password, displayName, selectedColor)
          else onLogin(username, password)
        },
        enabled = !authLoading && username.isNotBlank() && password.isNotBlank() && (!isRegisterMode || usernameOk),
        modifier = Modifier.fillMaxWidth().height(52.dp).testTag("auth_submit_button"),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = NeonCyan,
            disabledContainerColor = Color(0xFF4455A8),
            disabledContentColor = TextSecondary,
          ),
        shape = RoundedCornerShape(14.dp),
      ) {
        if (authLoading) {
          CircularProgressIndicator(modifier = Modifier.size(22.dp), color = ObsidianBg, strokeWidth = 2.5.dp)
        } else {
          Text(
            text = if (isRegisterMode) "ساخت حساب و ورود" else "ورود به Bazirox",
            color = androidx.compose.material3.LocalContentColor.current,
            fontWeight = FontWeight.ExtraBold,
          )
        }
      }
    }
  }
}

@Composable
private fun ProfileDashboardCard(
  user: UserAccount,
  cPanelConfig: CPanelConfig,
  onLogout: () -> Unit,
  avatar: ImageBitmap?,
  busy: Boolean,
  message: String?,
  onPickAvatar: (Uri) -> Unit,
  onRemoveAvatar: () -> Unit,
  onChangeName: (String) -> Unit,
  onClearMessage: () -> Unit,
  myBio: String,
  onSaveBio: (String) -> Unit,
) {
  var showEdit by remember { mutableStateOf(false) }
  val photoPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
      if (uri != null) onPickAvatar(uri)
    }
  LaunchedEffect(message) {
    if (message != null) {
      delay(3500)
      onClearMessage()
    }
  }

  if (showEdit) {
    EditProfileDialog(
      user = user,
      avatar = avatar,
      busy = busy,
      onPickPhoto = { photoPicker.launch("image/*") },
      onRemovePhoto = onRemoveAvatar,
      onSaveName = { onChangeName(it) },
      bio = myBio,
      onSaveBio = onSaveBio,
      onDismiss = { showEdit = false },
    )
  }

  GlassGradientCard(
    modifier = Modifier.fillMaxWidth().widthIn(max = 560.dp).fadeSlideIn(0),
    accentColor = NeonCyan,
    cornerRadius = 24.dp,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          Box(
            modifier = Modifier.size(62.dp).clickable { showEdit = true }.testTag("profile_avatar"),
            contentAlignment = Alignment.Center,
          ) {
            AvatarBadge(name = user.displayName, colorIndex = user.avatarColorIndex, size = 58.dp, image = avatar)
            Box(
              modifier =
                Modifier.align(Alignment.BottomEnd)
                  .size(22.dp)
                  .clip(CircleShape)
                  .background(NeonCyan)
                  .border(2.dp, ObsidianBg, CircleShape),
              contentAlignment = Alignment.Center,
            ) {
              Icon(Icons.Rounded.Edit, contentDescription = "ویرایش پروفایل", tint = ObsidianBg, modifier = Modifier.size(14.dp))
            }
          }
          Column {
            Text(user.displayName, style = MaterialTheme.typography.headlineSmall, color = TextPrimary)
            Text("\u2066@${user.username}\u2069 • سطح ${user.level}", style = MaterialTheme.typography.bodyMedium, color = NeonCyan)
            if (myBio.isNotBlank()) {
              Text(myBio, style = MaterialTheme.typography.bodySmall, color = TextSecondary, maxLines = 3)
            }
          }
        }
        ServerStatusPill(isConnected = cPanelConfig.isConnected)
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        StatBox("امتیاز کل", rememberCountUp(user.totalScore).toString(), CyberGold, Modifier.weight(1f))
        StatBox("پیروزی", rememberCountUp(user.wins).toString(), ElectricEmerald, Modifier.weight(1f))
        StatBox("نرخ برد", "${rememberCountUp(user.winRatePercent)}%", NeonCyan, Modifier.weight(1f))
      }

      OutlinedButton(
        onClick = { showEdit = true },
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("edit_profile_button"),
        border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.6f)),
        shape = RoundedCornerShape(14.dp),
      ) {
        Icon(Icons.Rounded.Edit, contentDescription = null, tint = NeonCyan)
        Spacer(Modifier.width(8.dp))
        Text("ویرایش پروفایل", color = NeonCyan, fontWeight = FontWeight.Bold)
      }

      if (message != null) {
        Text(
          text = message,
          style = MaterialTheme.typography.bodyMedium,
          color = if (message.contains("ناموفق") || message.contains("خطا") || message.contains("باید") || message.contains("نمی")) CrimsonMagenta else ElectricEmerald,
          modifier = Modifier.fillMaxWidth(),
        )
      }

      OutlinedButton(
        onClick = onLogout,
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("logout_button"),
        border = BorderStroke(1.dp, CrimsonMagenta.copy(alpha = 0.6f)),
        shape = RoundedCornerShape(14.dp),
      ) {
        Icon(BaziIcons.Logout, contentDescription = null, tint = CrimsonMagenta)
        Spacer(Modifier.width(8.dp))
        Text("خروج از حساب کاربری", color = CrimsonMagenta, fontWeight = FontWeight.Bold)
      }
    }
  }
}

@Composable
private fun EditProfileDialog(
  user: UserAccount,
  avatar: ImageBitmap?,
  busy: Boolean,
  onPickPhoto: () -> Unit,
  onRemovePhoto: () -> Unit,
  onSaveName: (String) -> Unit,
  bio: String,
  onSaveBio: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  var name by remember { mutableStateOf(user.displayName) }
  var bioDraft by remember { mutableStateOf(bio) }
  val nameChanged = name.trim().isNotEmpty() && name.trim() != user.displayName
  val bioChanged = bioDraft.trim() != bio.trim()
  val changed = nameChanged || bioChanged
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = ElevatedCard,
    title = { Text("ویرایش پروفایل", color = TextPrimary, fontWeight = FontWeight.Bold) },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Box(
          modifier = Modifier.size(102.dp).clickable(enabled = !busy) { onPickPhoto() },
          contentAlignment = Alignment.Center,
        ) {
          AvatarBadge(name = name.ifBlank { user.displayName }, colorIndex = user.avatarColorIndex, size = 96.dp, image = avatar)
          Box(
            modifier =
              Modifier.align(Alignment.BottomEnd)
                .size(30.dp)
                .clip(CircleShape)
                .background(NeonCyan)
                .border(2.dp, ElevatedCard, CircleShape),
            contentAlignment = Alignment.Center,
          ) {
            if (busy) {
              CircularProgressIndicator(color = ObsidianBg, strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
            } else {
              Icon(Icons.Rounded.Edit, contentDescription = null, tint = ObsidianBg, modifier = Modifier.size(18.dp))
            }
          }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          TextButton(onClick = onPickPhoto, enabled = !busy) { Text("انتخاب عکس", color = NeonCyan) }
          if (avatar != null) {
            TextButton(onClick = onRemovePhoto, enabled = !busy) { Text("حذف عکس", color = CrimsonMagenta) }
          }
        }
        OutlinedTextField(
          value = name,
          onValueChange = { if (it.length <= 32) name = it },
          singleLine = true,
          label = { Text("نام نمایشی") },
          modifier = Modifier.fillMaxWidth().testTag("edit_name_field"),
          shape = RoundedCornerShape(14.dp),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = NeonCyan,
              unfocusedBorderColor = ElevatedCardStroke,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary,
              focusedLabelColor = NeonCyan,
              unfocusedLabelColor = TextSecondary,
              cursorColor = NeonCyan,
            ),
        )
        OutlinedTextField(
          value = bioDraft,
          onValueChange = { if (it.length <= 300) bioDraft = it },
          minLines = 2,
          maxLines = 4,
          label = { Text("بیوگرافی") },
          supportingText = { Text("${bioDraft.length}/300", color = TextSecondary) },
          modifier = Modifier.fillMaxWidth().testTag("edit_bio_field"),
          shape = RoundedCornerShape(14.dp),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = NeonCyan,
              unfocusedBorderColor = ElevatedCardStroke,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary,
              focusedLabelColor = NeonCyan,
              unfocusedLabelColor = TextSecondary,
              cursorColor = NeonCyan,
            ),
        )
      }
    },
    confirmButton = {
      TextButton(
        onClick = {
          if (nameChanged) onSaveName(name.trim())
          if (bioChanged) onSaveBio(bioDraft.trim())
          onDismiss()
        },
        enabled = !busy,
        modifier = Modifier.testTag("edit_profile_save"),
      ) {
        Text(if (changed) "ذخیره" else "بستن", color = NeonCyan, fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      if (changed) TextButton(onClick = onDismiss) { Text("لغو", color = TextSecondary) }
    },
  )
}

@Composable
private fun StatBox(
  label: String,
  value: String,
  accent: Color,
  modifier: Modifier = Modifier,
) {
  GlassGradientCard(
    modifier = modifier,
    accentColor = accent,
    cornerRadius = 16.dp,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(value, style = MaterialTheme.typography.headlineSmall, color = accent, fontWeight = FontWeight.ExtraBold)
      Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    }
  }
}
