package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val CyberArcadeColorScheme =
  darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color(0xFF04131A),
    primaryContainer = Color(0xFF093545),
    onPrimaryContainer = NeonCyan,
    secondary = VioletPulse,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF251D4D),
    onSecondaryContainer = Color(0xFFD7C8FF),
    tertiary = CyberGold,
    onTertiary = Color(0xFF1F1400),
    tertiaryContainer = Color(0xFF3E2B00),
    onTertiaryContainer = CyberGold,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = CarbonSurface,
    onSurface = TextPrimary,
    surfaceVariant = ElevatedCard,
    onSurfaceVariant = TextSecondary,
    outline = ElevatedCardStroke,
    error = CrimsonMagenta,
    onError = Color.White,
  )

val BaziShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
  )

@Composable
fun BaziroxTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = CyberArcadeColorScheme,
    typography = Typography,
    shapes = BaziShapes,
    content = content,
  )
}
