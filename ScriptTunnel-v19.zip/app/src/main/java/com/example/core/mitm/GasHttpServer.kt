package com.example.core.mitm

import com.example.core.logging.LogCategory
import com.example.core.logging.TunnelLogger
import com.example.network.GasRelayResponse
import com.example.network.ParallelTunnelEngine
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream

/**
 * Minimal HTTP/1.1 server that reads sequential keep-alive requests from a decrypted stream
 * (or plain HTTP on port 80), relays them through [ParallelTunnelEngine.relayHttpViaGasPool]
 * without following redirects, and writes the full HTTP response (status, headers, body) back.
 */
class GasHttpServer(
    private val engine: ParallelTunnelEngine,
    private val defaultHost: String,
    private val scheme: String = "https",
    private val input: InputStream,
    private val output: OutputStream
) {
    suspend fun serve() {
        while (true) {
            val req = readHttpRequest() ?: break
            if (req.isWebSocket) {
                // GAS cannot carry WebSocket; fail fast instead of relaying it as a plain GET
                TunnelLogger.w(LogCategory.GAS, "MITM-WS", "WebSocket از مسیر GAS پشتیبانی نمی‌شود: ${req.url}")
                output.write(
                    ("HTTP/1.1 501 Not Implemented\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
                        .toByteArray(Charsets.US_ASCII)
                )
                output.flush()
                break
            }
            if (isTelegramHttpTransport(req.url)) {
                val probe = req.method.equals("POST", true) && (req.body == null || req.body.isEmpty())
                val preflight = req.method.equals("OPTIONS", true)
                if (probe || preflight) {
                    com.example.core.logging.TunnelStats.inc("gas.saved")
                    // Telegram Web probes the HTTP transport with a 2s timeout; a ~2s Apps Script round trip would always lose
                    val origin = req.headers.entries.firstOrNull { it.key.equals("origin", true) }?.value ?: "*"
                    val local = StringBuilder()
                    local.append(if (preflight) "HTTP/1.1 204 No Content\r\n" else "HTTP/1.1 200 OK\r\n")
                    local.append("Access-Control-Allow-Origin: $origin\r\n")
                    local.append("Access-Control-Allow-Methods: POST, OPTIONS\r\n")
                    local.append("Access-Control-Allow-Headers: *\r\n")
                    local.append("Content-Length: 0\r\n")
                    local.append("Connection: ${if (req.closeConnection) "close" else "keep-alive"}\r\n\r\n")
                    output.write(local.toString().toByteArray(Charsets.US_ASCII))
                    output.flush()
                    if (req.closeConnection) break else continue
                }
            }
            val isTg = isTelegramHttpTransport(req.url)
            val tgHost = if (isTg) (try { java.net.URI(req.url).host?.lowercase() } catch (e: Exception) { null }) else null
            // DC2/DC4 "-1" (media) hosts answer 404 over HTTP; the plain host serves the same MTProto packets
            var sendUrl = if (tgHost != null && tgHost in TG_BASE_FALLBACK) req.url.replace("-1.web.telegram.org", ".web.telegram.org") else req.url
            var res = engine.relayHttpViaGasPool(
                targetUrl = sendUrl,
                method = req.method,
                headers = req.headers,
                bodyBytes = req.body,
                followRedirects = false
            )
            val isMissingHostErr = !res.ok && (res.error?.contains("آدرس موجود نیست") == true || res.error?.contains("Address unavailable", true) == true)
            if (isTg && tgHost != null && tgHost.endsWith("-1.web.telegram.org") && sendUrl == req.url && ((res.ok && res.statusCode == 404) || isMissingHostErr)) {
                val alt = req.url.replace("-1.web.telegram.org", ".web.telegram.org")
                val res2 = engine.relayHttpViaGasPool(
                    targetUrl = alt,
                    method = req.method,
                    headers = req.headers,
                    bodyBytes = req.body,
                    followRedirects = false
                )
                if (res2.ok && res2.statusCode == 200) {
                    TG_BASE_FALLBACK.add(tgHost)
                    TunnelLogger.i(LogCategory.GAS, "MITM-TG-HOST", "$tgHost → میزبان اصلی (۴۰۴ روی نسخه -1)")
                    res = res2
                }
            }
            // some Google/Telegram asset responses make UrlFetchApp throw on the Vary header; retry once with a minimal header set
            if (!res.ok && res.error?.contains("Header:Vary") == true) {
                val minimal = LinkedHashMap<String, String>()
                for ((k, v) in req.headers) {
                    when (k.lowercase()) {
                        "user-agent", "accept", "accept-language", "referer" -> minimal[k] = v
                    }
                }
                val retry = engine.relayHttpViaGasPool(
                    targetUrl = req.url,
                    method = req.method,
                    headers = minimal,
                    bodyBytes = req.body,
                    followRedirects = false
                )
                if (retry.ok) res = retry
            }

            val respBuf = ByteArrayOutputStream()
            val statusLine = "HTTP/1.1 ${res.statusCode} ${reasonPhrase(res.statusCode)}\r\n"
            respBuf.write(statusLine.toByteArray(Charsets.US_ASCII))

            if (res.ok) {
                for ((k, v) in res.headers) {
                    val lk = k.lowercase()
                    if (lk in STRIPPED_RESPONSE_HEADERS) continue
                    val cleanVal = v.replace("\r", "").replace("\n", " ")
                    respBuf.write("$k: $cleanVal\r\n".toByteArray(Charsets.ISO_8859_1))
                }
            } else {
                respBuf.write("Content-Type: text/plain; charset=utf-8\r\n".toByteArray(Charsets.US_ASCII))
            }

            if (res.ok && req.method.equals("GET", true)) engine.prefetchModuleDeps(req.url, req.headers, res)
            var bodyOut = if (res.ok) res.bodyBytes else (res.error ?: "Relay Error").toByteArray(Charsets.UTF_8)
            if (res.ok) bodyOut = ensureMobileViewport(req, res, bodyOut)
            val sendBody = !req.method.equals("HEAD", ignoreCase = true)
            val contentLength = bodyOut.size
            respBuf.write("Content-Length: $contentLength\r\n".toByteArray(Charsets.US_ASCII))
            val closeAfter = req.closeConnection || !res.ok
            respBuf.write("Connection: ${if (closeAfter) "close" else "keep-alive"}\r\n".toByteArray(Charsets.US_ASCII))
            respBuf.write("\r\n".toByteArray(Charsets.US_ASCII))
            if (sendBody && bodyOut.isNotEmpty()) {
                respBuf.write(bodyOut)
            }

            output.write(respBuf.toByteArray())
            output.flush()

            TunnelLogger.d(
                LogCategory.GAS,
                "MITM-HTTP",
                "${req.method} ${req.url} -> ${res.statusCode} (${bodyOut.size}B)"
            )

            if (closeAfter) break
        }
    }

    private fun isTelegramHttpTransport(url: String): Boolean {
        val uri = try { java.net.URI(url) } catch (e: Exception) { return false }
        val host = uri.host?.lowercase() ?: return false
        return host.endsWith(".web.telegram.org") && (uri.path ?: "").startsWith("/apiw")
    }

    /** If the browser is mobile but the page came back without a viewport tag (relay changed the UA), Chrome falls back to a 980px desktop layout. */
    private fun ensureMobileViewport(req: ParsedHttpRequest, res: GasRelayResponse, body: ByteArray): ByteArray {
        if (body.isEmpty() || body.size > 3_000_000) return body
        val ua = req.headers.entries.firstOrNull { it.key.equals("user-agent", true) }?.value ?: return body
        if (!ua.contains("Mobile", ignoreCase = true)) return body
        val ct = res.headers.firstOrNull { it.first.equals("content-type", true) }?.second ?: return body
        if (!ct.contains("text/html", ignoreCase = true)) return body
        val html = String(body, Charsets.ISO_8859_1)
        if (html.contains("name=\"viewport\"", true) || html.contains("name='viewport'", true)) return body
        val idx = html.indexOf("<head", ignoreCase = true)
        if (idx < 0) return body
        val close = html.indexOf('>', idx)
        if (close < 0) return body
        val tag = "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
        return (html.substring(0, close + 1) + tag + html.substring(close + 1)).toByteArray(Charsets.ISO_8859_1)
    }

    private data class ParsedHttpRequest(
        val method: String,
        val url: String,
        val headers: Map<String, String>,
        val body: ByteArray?,
        val closeConnection: Boolean,
        val isWebSocket: Boolean = false
    )

    private fun readHttpRequest(): ParsedHttpRequest? {
        val requestLine = readLineCrlf() ?: return null
        if (requestLine.isBlank()) return null
        val parts = requestLine.split(" ")
        if (parts.size < 2) return null
        val method = parts[0].trim().uppercase()
        val target = parts[1].trim()
        val httpVersion = parts.getOrNull(2)?.trim()?.uppercase() ?: "HTTP/1.1"

        var host = defaultHost
        var contentLength = -1
        var isChunked = false
        var closeConn = httpVersion == "HTTP/1.0"
        var expectContinue = false
        var isWebSocket = false
        val forwardHeaders = LinkedHashMap<String, String>()

        while (true) {
            val line = readLineCrlf() ?: return null
            if (line.isEmpty()) break
            val colon = line.indexOf(':')
            if (colon <= 0) continue
            val key = line.substring(0, colon).trim()
            val value = line.substring(colon + 1).trim()
            val lk = key.lowercase()
            when (lk) {
                "host" -> host = value
                "content-length" -> contentLength = value.toIntOrNull() ?: -1
                "transfer-encoding" -> if (value.contains("chunked", ignoreCase = true)) isChunked = true
                "connection" -> {
                    if (value.contains("close", ignoreCase = true)) closeConn = true
                    else if (value.contains("keep-alive", ignoreCase = true)) closeConn = false
                }
                "expect" -> if (value.contains("100-continue", ignoreCase = true)) expectContinue = true
                "upgrade" -> if (value.contains("websocket", ignoreCase = true)) isWebSocket = true
            }
            if (lk !in STRIPPED_REQUEST_HEADERS) {
                val existing = forwardHeaders[key]
                forwardHeaders[key] = if (existing == null) value else "$existing, $value"
            }
        }

        if (expectContinue) {
            output.write("HTTP/1.1 100 Continue\r\n\r\n".toByteArray(Charsets.US_ASCII))
            output.flush()
        }

        val body: ByteArray? = when {
            isChunked -> readChunkedBody()
            contentLength > 0 -> readExactBytes(contentLength)
            else -> null
        }

        val fullUrl = if (target.startsWith("http://") || target.startsWith("https://")) {
            target
        } else {
            val path = if (target.startsWith("/")) target else "/$target"
            "$scheme://$host$path"
        }

        return ParsedHttpRequest(
            method = method,
            url = fullUrl,
            headers = forwardHeaders,
            body = body,
            closeConnection = closeConn,
            isWebSocket = isWebSocket
        )
    }

    private fun readLineCrlf(): String? {
        val buf = ByteArrayOutputStream(128)
        while (true) {
            val b = input.read()
            if (b == -1) {
                return if (buf.size() == 0) null else buf.toString(Charsets.ISO_8859_1.name())
            }
            if (b == '\n'.code) {
                val bytes = buf.toByteArray()
                val len = if (bytes.isNotEmpty() && bytes.last() == '\r'.code.toByte()) bytes.size - 1 else bytes.size
                return String(bytes, 0, len, Charsets.ISO_8859_1)
            }
            buf.write(b)
            if (buf.size() > 64 * 1024) {
                throw IllegalStateException("HTTP header line too long")
            }
        }
    }

    private fun readExactBytes(n: Int): ByteArray {
        val out = ByteArray(n)
        var off = 0
        while (off < n) {
            val r = input.read(out, off, n - off)
            if (r < 0) throw EOFException("Unexpected EOF while reading HTTP body")
            off += r
        }
        return out
    }

    private fun readChunkedBody(): ByteArray {
        val out = ByteArrayOutputStream()
        while (true) {
            val sizeLine = readLineCrlf() ?: throw EOFException("Unexpected EOF in chunked body")
            val semi = sizeLine.indexOf(';')
            val hex = (if (semi >= 0) sizeLine.substring(0, semi) else sizeLine).trim()
            val chunkSize = hex.toIntOrNull(16) ?: throw IllegalStateException("Invalid chunk size: $hex")
            if (chunkSize == 0) {
                while (true) {
                    val trailer = readLineCrlf() ?: break
                    if (trailer.isEmpty()) break
                }
                break
            }
            out.write(readExactBytes(chunkSize))
            readLineCrlf() // trailing CRLF after chunk data
        }
        return out.toByteArray()
    }

    companion object {
        private val TG_BASE_FALLBACK: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

        private val STRIPPED_REQUEST_HEADERS = setOf(
            "host",
            "connection",
            "keep-alive",
            "proxy-connection",
            "transfer-encoding",
            "te",
            "trailer",
            "upgrade",
            "content-length",
            "expect",
            "accept-encoding"
        )

        private val STRIPPED_RESPONSE_HEADERS = setOf(
            "transfer-encoding",
            "content-encoding",
            "content-length",
            "connection",
            "keep-alive",
            "alt-svc"
        )

        private fun reasonPhrase(code: Int): String = when (code) {
            200 -> "OK"
            201 -> "Created"
            204 -> "No Content"
            206 -> "Partial Content"
            301 -> "Moved Permanently"
            302 -> "Found"
            304 -> "Not Modified"
            307 -> "Temporary Redirect"
            308 -> "Permanent Redirect"
            400 -> "Bad Request"
            401 -> "Unauthorized"
            403 -> "Forbidden"
            404 -> "Not Found"
            500 -> "Internal Server Error"
            502 -> "Bad Gateway"
            503 -> "Service Unavailable"
            else -> "OK"
        }
    }
}
