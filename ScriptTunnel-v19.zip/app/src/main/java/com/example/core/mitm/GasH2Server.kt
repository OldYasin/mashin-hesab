package com.example.core.mitm

import com.example.core.logging.LogCategory
import com.example.core.logging.TunnelLogger
import com.example.network.GasRelayResponse
import com.example.network.ParallelTunnelEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.ConcurrentHashMap

/**
 * Separate HTTP/2 (h2) MITM server negotiated via ALPN when enabled in Settings.
 * Multiplexes concurrent streams over a single TLS connection into [ParallelTunnelEngine.relayHttpViaGasPool],
 * bypassing Chrome's 6-connection-per-host HTTP/1.1 limit.
 */
class GasH2Server(
    private val engine: ParallelTunnelEngine,
    private val defaultHost: String,
    private val input: InputStream,
    private val output: OutputStream
) {
    private val hpack = HpackCodec()
    private val writeLock = Any()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private class StreamState(
        val id: Int,
        val headerBuf: ByteArrayOutputStream = ByteArrayOutputStream(),
        val bodyBuf: ByteArrayOutputStream = ByteArrayOutputStream(),
        var headersComplete: Boolean = false,
        var endStream: Boolean = false,
        var decodedHeaders: List<Pair<String, String>> = emptyList()
    )

    private val streams = ConcurrentHashMap<Int, StreamState>()

    suspend fun serve() {
        try {
            if (!readClientPreface()) {
                TunnelLogger.w(LogCategory.GAS, "MITM-H2", "پیشوند HTTP/2 نامعتبر برای $defaultHost")
                return
            }
            sendServerSettings()

            var continuingStreamId = 0
            while (true) {
                val hdr = readExactlyOrNull(9) ?: break
                val length = ((hdr[0].toInt() and 0xFF) shl 16) or
                    ((hdr[1].toInt() and 0xFF) shl 8) or
                    (hdr[2].toInt() and 0xFF)
                val type = hdr[3].toInt() and 0xFF
                val flags = hdr[4].toInt() and 0xFF
                val streamId = ((hdr[5].toInt() and 0x7F) shl 24) or
                    ((hdr[6].toInt() and 0xFF) shl 16) or
                    ((hdr[7].toInt() and 0xFF) shl 8) or
                    (hdr[8].toInt() and 0xFF)

                if (length > MAX_FRAME_SIZE_ALLOWED) {
                    TunnelLogger.w(LogCategory.GAS, "MITM-H2", "فریم بیش از حد بزرگ ($length) روی $defaultHost")
                    break
                }
                val payload = if (length > 0) readExactlyOrNull(length) ?: break else ByteArray(0)

                when (type) {
                    FRAME_SETTINGS -> {
                        if ((flags and FLAG_ACK) == 0) {
                            writeFrame(FRAME_SETTINGS, FLAG_ACK, 0, ByteArray(0))
                        }
                    }
                    FRAME_PING -> {
                        if ((flags and FLAG_ACK) == 0 && payload.size == 8) {
                            writeFrame(FRAME_PING, FLAG_ACK, 0, payload)
                        }
                    }
                    FRAME_WINDOW_UPDATE -> {
                        // Server responses are written directly without strict per-stream blocking
                    }
                    FRAME_RST_STREAM -> {
                        streams.remove(streamId)
                    }
                    FRAME_GOAWAY -> {
                        break
                    }
                    FRAME_HEADERS -> {
                        if (streamId == 0) continue
                        val st = streams.getOrPut(streamId) { StreamState(streamId) }
                        var off = 0
                        var end = payload.size
                        if ((flags and FLAG_PADDED) != 0 && payload.isNotEmpty()) {
                            val padLen = payload[0].toInt() and 0xFF
                            off += 1
                            end = (end - padLen).coerceAtLeast(off)
                        }
                        if ((flags and FLAG_PRIORITY) != 0) {
                            off += 5
                        }
                        if (off < end) {
                            st.headerBuf.write(payload, off, end - off)
                        }
                        if ((flags and FLAG_END_STREAM) != 0) {
                            st.endStream = true
                        }
                        if ((flags and FLAG_END_HEADERS) != 0) {
                            st.decodedHeaders = hpack.decode(st.headerBuf.toByteArray())
                            st.headersComplete = true
                            continuingStreamId = 0
                            if (st.endStream) dispatchStream(st)
                        } else {
                            continuingStreamId = streamId
                        }
                    }
                    FRAME_CONTINUATION -> {
                        val sid = if (streamId != 0) streamId else continuingStreamId
                        val st = streams[sid] ?: continue
                        if (payload.isNotEmpty()) st.headerBuf.write(payload)
                        if ((flags and FLAG_END_HEADERS) != 0) {
                            st.decodedHeaders = hpack.decode(st.headerBuf.toByteArray())
                            st.headersComplete = true
                            continuingStreamId = 0
                            if (st.endStream) dispatchStream(st)
                        }
                    }
                    FRAME_DATA -> {
                        if (streamId == 0) continue
                        val st = streams[streamId] ?: continue
                        var off = 0
                        var end = payload.size
                        if ((flags and FLAG_PADDED) != 0 && payload.isNotEmpty()) {
                            val padLen = payload[0].toInt() and 0xFF
                            off += 1
                            end = (end - padLen).coerceAtLeast(off)
                        }
                        val dataLen = (end - off).coerceAtLeast(0)
                        if (dataLen > 0) {
                            st.bodyBuf.write(payload, off, dataLen)
                            sendWindowUpdate(0, dataLen)
                            sendWindowUpdate(streamId, dataLen)
                        }
                        if ((flags and FLAG_END_STREAM) != 0) {
                            st.endStream = true
                            if (st.headersComplete) dispatchStream(st)
                        }
                    }
                    else -> {
                        // PRIORITY or unknown frame: ignore safely
                    }
                }
            }
        } catch (_: EOFException) {
            // Normal close
        } finally {
            scope.cancel()
        }
    }

    private fun dispatchStream(st: StreamState) {
        streams.remove(st.id)
        scope.launch {
            handleStream(st.id, st.decodedHeaders, st.bodyBuf.toByteArray())
        }
    }

    private suspend fun handleStream(
        streamId: Int,
        rawHeaders: List<Pair<String, String>>,
        bodyBytes: ByteArray
    ) {
        var method = "GET"
        var path = "/"
        var authority = defaultHost
        var scheme = "https"
        val reqHeaders = LinkedHashMap<String, String>()

        for ((k, v) in rawHeaders) {
            when (k) {
                ":method" -> method = v.uppercase()
                ":path" -> path = v
                ":authority" -> authority = v
                ":scheme" -> scheme = v
                else -> if (!k.startsWith(":")) {
                    val prev = reqHeaders[k]
                    reqHeaders[k] = if (prev == null) v else "$prev; $v"
                }
            }
        }
        val url = if (path.startsWith("http://") || path.startsWith("https://")) {
            path
        } else {
            val cleanPath = if (path.startsWith("/")) path else "/$path"
            "$scheme://$authority$cleanPath"
        }

        if (isTelegramHttpTransport(url)) {
            val probe = method == "POST" && bodyBytes.isEmpty()
            val preflight = method == "OPTIONS"
            if (probe || preflight) {
                com.example.core.logging.TunnelStats.inc("gas.saved")
                val origin = reqHeaders.entries.firstOrNull { it.key.equals("origin", true) }?.value ?: "*"
                val localHdrs = listOf(
                    "access-control-allow-origin" to origin,
                    "access-control-allow-methods" to "POST, OPTIONS",
                    "access-control-allow-headers" to "*",
                    "content-length" to "0"
                )
                sendResponse(streamId, if (preflight) 204 else 200, localHdrs, ByteArray(0), sendBody = false)
                return
            }
        }

        val isTg = isTelegramHttpTransport(url)
        val tgHost = if (isTg) (try { java.net.URI(url).host?.lowercase() } catch (_: Exception) { null }) else null
        val sendUrl = if (tgHost != null && tgHost in TG_BASE_FALLBACK) {
            url.replace("-1.web.telegram.org", ".web.telegram.org")
        } else {
            url
        }

        var res = engine.relayHttpViaGasPool(
            targetUrl = sendUrl,
            method = method,
            headers = reqHeaders,
            bodyBytes = if (bodyBytes.isEmpty()) null else bodyBytes,
            followRedirects = false
        )

        val isMissingHostErr = !res.ok && (res.error?.contains("آدرس موجود نیست") == true || res.error?.contains("Address unavailable", true) == true)
        if (isTg && tgHost != null && tgHost.endsWith("-1.web.telegram.org") && sendUrl == url && ((res.ok && res.statusCode == 404) || isMissingHostErr)) {
            val alt = url.replace("-1.web.telegram.org", ".web.telegram.org")
            val res2 = engine.relayHttpViaGasPool(
                targetUrl = alt,
                method = method,
                headers = reqHeaders,
                bodyBytes = if (bodyBytes.isEmpty()) null else bodyBytes,
                followRedirects = false
            )
            if (res2.ok && res2.statusCode == 200) {
                TG_BASE_FALLBACK.add(tgHost)
                TunnelLogger.i(LogCategory.GAS, "MITM-TG-HOST", "$tgHost → میزبان اصلی (۴۰۴ روی نسخه -1)")
                res = res2
            }
        }

        if (!res.ok && res.error?.contains("Header:Vary") == true) {
            val minimal = LinkedHashMap<String, String>()
            for ((k, v) in reqHeaders) {
                when (k.lowercase()) {
                    "user-agent", "accept", "accept-language", "referer" -> minimal[k] = v
                }
            }
            val retry = engine.relayHttpViaGasPool(
                targetUrl = url,
                method = method,
                headers = minimal,
                bodyBytes = if (bodyBytes.isEmpty()) null else bodyBytes,
                followRedirects = false
            )
            if (retry.ok) res = retry
        }

        if (res.ok && method == "GET") {
            engine.prefetchModuleDeps(url, reqHeaders, res)
        }

        var bodyOut = if (res.ok) res.bodyBytes else (res.error ?: "Relay Error").toByteArray(Charsets.UTF_8)
        if (res.ok) bodyOut = ensureMobileViewport(reqHeaders, res, bodyOut)

        val outHeaders = ArrayList<Pair<String, String>>()
        if (res.ok) {
            for ((k, v) in res.headers) {
                val lk = k.lowercase()
                if (lk in H2_STRIPPED_HEADERS) continue
                outHeaders.add(lk to v.replace("\r", "").replace("\n", " "))
            }
        } else {
            outHeaders.add("content-type" to "text/plain; charset=utf-8")
        }

        val sendBody = method != "HEAD" && res.statusCode != 204 && res.statusCode != 304
        if (res.statusCode != 204 && res.statusCode != 304) {
            outHeaders.add("content-length" to bodyOut.size.toString())
        }

        sendResponse(streamId, res.statusCode, outHeaders, bodyOut, sendBody)
        TunnelLogger.d(LogCategory.GAS, "MITM-H2", "$method $url -> ${res.statusCode} (${bodyOut.size}B)")
    }

    private fun sendResponse(
        streamId: Int,
        statusCode: Int,
        headers: List<Pair<String, String>>,
        body: ByteArray,
        sendBody: Boolean
    ) {
        val headerBlock = HpackCodec.encodeResponse(statusCode, headers)
        val hasBody = sendBody && body.isNotEmpty()
        synchronized(writeLock) {
            try {
                var offset = 0
                var first = true
                while (offset < headerBlock.size || first) {
                    val chunk = minOf(FRAME_CHUNK_SIZE, headerBlock.size - offset)
                    val isLastHeader = (offset + chunk) >= headerBlock.size
                    var flags = 0
                    if (isLastHeader) flags = flags or FLAG_END_HEADERS
                    if (first && isLastHeader && !hasBody) flags = flags or FLAG_END_STREAM
                    val slice = if (chunk > 0) headerBlock.copyOfRange(offset, offset + chunk) else ByteArray(0)
                    writeFrameLocked(if (first) FRAME_HEADERS else FRAME_CONTINUATION, flags, streamId, slice)
                    offset += chunk
                    first = false
                }
                if (hasBody) {
                    var bOff = 0
                    while (bOff < body.size) {
                        val chunk = minOf(FRAME_CHUNK_SIZE, body.size - bOff)
                        val isLast = (bOff + chunk) >= body.size
                        val flags = if (isLast) FLAG_END_STREAM else 0
                        writeFrameLocked(FRAME_DATA, flags, streamId, body.copyOfRange(bOff, bOff + chunk))
                        bOff += chunk
                    }
                }
                output.flush()
            } catch (_: Exception) {
                // Connection closed by client
            }
        }
    }

    private fun sendServerSettings() {
        // SETTINGS_MAX_CONCURRENT_STREAMS (3) = 100, SETTINGS_INITIAL_WINDOW_SIZE (4) = 1048576
        val payload = byteArrayOf(
            0x00, 0x03, 0x00, 0x00, 0x00, 0x64,
            0x00, 0x04, 0x00, 0x10, 0x00, 0x00
        )
        synchronized(writeLock) {
            writeFrameLocked(FRAME_SETTINGS, 0, 0, payload)
            writeWindowUpdateLocked(0, 1_048_576 - 65_535)
            output.flush()
        }
    }

    private fun sendWindowUpdate(streamId: Int, increment: Int) {
        if (increment <= 0) return
        synchronized(writeLock) {
            runCatching {
                writeWindowUpdateLocked(streamId, increment)
                output.flush()
            }
        }
    }

    private fun writeWindowUpdateLocked(streamId: Int, increment: Int) {
        val b = byteArrayOf(
            ((increment ushr 24) and 0x7F).toByte(),
            ((increment ushr 16) and 0xFF).toByte(),
            ((increment ushr 8) and 0xFF).toByte(),
            (increment and 0xFF).toByte()
        )
        writeFrameLocked(FRAME_WINDOW_UPDATE, 0, streamId, b)
    }

    private fun writeFrame(type: Int, flags: Int, streamId: Int, payload: ByteArray) {
        synchronized(writeLock) {
            runCatching {
                writeFrameLocked(type, flags, streamId, payload)
                output.flush()
            }
        }
    }

    private fun writeFrameLocked(type: Int, flags: Int, streamId: Int, payload: ByteArray) {
        val len = payload.size
        val hdr = byteArrayOf(
            ((len ushr 16) and 0xFF).toByte(),
            ((len ushr 8) and 0xFF).toByte(),
            (len and 0xFF).toByte(),
            type.toByte(),
            flags.toByte(),
            ((streamId ushr 24) and 0x7F).toByte(),
            ((streamId ushr 16) and 0xFF).toByte(),
            ((streamId ushr 8) and 0xFF).toByte(),
            (streamId and 0xFF).toByte()
        )
        output.write(hdr)
        if (payload.isNotEmpty()) output.write(payload)
    }

    private fun readClientPreface(): Boolean {
        val buf = readExactlyOrNull(CLIENT_PREFACE.size) ?: return false
        return buf.contentEquals(CLIENT_PREFACE)
    }

    private fun readExactlyOrNull(n: Int): ByteArray? {
        val buf = ByteArray(n)
        var off = 0
        while (off < n) {
            val r = input.read(buf, off, n - off)
            if (r < 0) return if (off == 0) null else throw EOFException()
            off += r
        }
        return buf
    }

    private fun isTelegramHttpTransport(url: String): Boolean {
        val uri = try { java.net.URI(url) } catch (_: Exception) { return false }
        val host = uri.host?.lowercase() ?: return false
        return host.endsWith(".web.telegram.org") && (uri.path ?: "").startsWith("/apiw")
    }

    private fun ensureMobileViewport(reqHeaders: Map<String, String>, res: GasRelayResponse, body: ByteArray): ByteArray {
        if (body.isEmpty() || body.size > 3_000_000) return body
        val ua = reqHeaders.entries.firstOrNull { it.key.equals("user-agent", true) }?.value ?: return body
        if (!ua.contains("Mobile", ignoreCase = true)) return body
        val ct = res.headers.firstOrNull { it.first.equals("content-type", true) }?.second ?: return body
        if (!ct.contains("text/html", ignoreCase = true)) return body
        val html = String(body, Charsets.ISO_8859_1)
        if (html.contains("name=\"viewport\"", true) || html.contains("name='viewport'", true)) return body
        val idx = html.indexOf("<head", ignoreCase = true)
        if (idx < 0) return body
        val close = html.indexOf('>', idx)
        if (close < 0) return body
        val tag = "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
        return (html.substring(0, close + 1) + tag + html.substring(close + 1)).toByteArray(Charsets.ISO_8859_1)
    }

    companion object {
        private val CLIENT_PREFACE = "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n".toByteArray(Charsets.US_ASCII)
        private const val FRAME_DATA = 0
        private const val FRAME_HEADERS = 1
        private const val FRAME_RST_STREAM = 3
        private const val FRAME_SETTINGS = 4
        private const val FRAME_PING = 6
        private const val FRAME_GOAWAY = 7
        private const val FRAME_WINDOW_UPDATE = 8
        private const val FRAME_CONTINUATION = 9

        private const val FLAG_ACK = 0x1
        private const val FLAG_END_STREAM = 0x1
        private const val FLAG_END_HEADERS = 0x4
        private const val FLAG_PADDED = 0x8
        private const val FLAG_PRIORITY = 0x20

        private const val FRAME_CHUNK_SIZE = 16_384
        private const val MAX_FRAME_SIZE_ALLOWED = 1_048_576

        private val TG_BASE_FALLBACK = ConcurrentHashMap.newKeySet<String>()
        private val H2_STRIPPED_HEADERS = setOf(
            "connection", "keep-alive", "proxy-connection", "transfer-encoding",
            "upgrade", "te", "content-length", "content-encoding"
        )
    }
}
