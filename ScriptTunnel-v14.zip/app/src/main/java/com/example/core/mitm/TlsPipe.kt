package com.example.core.mitm

import android.os.Build
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLEngine
import javax.net.ssl.SSLEngineResult

/**
 * Bridges a raw encrypted TCP stream ([readNet] / [writeNet]) to plaintext streams
 * using [SSLEngine] in server mode (TLS 1.2 & TLS 1.3, ALPN http/1.1).
 */
class TlsPipe(
    sslContext: SSLContext,
    private val readNet: () -> ByteArray?,
    private val writeNet: (ByteArray) -> Unit
) {
    private val engine: SSLEngine = sslContext.createSSLEngine().apply {
        useClientMode = false
        val wanted = supportedProtocols.filter { it == "TLSv1.3" || it == "TLSv1.2" }
        if (wanted.isNotEmpty()) {
            enabledProtocols = wanted.toTypedArray()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val params = sslParameters
            params.applicationProtocols = arrayOf("http/1.1")
            sslParameters = params
        }
    }

    private val emptyBuf = ByteBuffer.allocate(0)
    private var netInBuf: ByteBuffer = ByteBuffer.allocate(maxOf(engine.session.packetBufferSize, 32 * 1024)).apply {
        flip()
    }
    private var netOutBuf: ByteBuffer = ByteBuffer.allocate(maxOf(engine.session.packetBufferSize, 32 * 1024))
    private var appInBuf: ByteBuffer = ByteBuffer.allocate(maxOf(engine.session.applicationBufferSize, 32 * 1024))

    @Volatile
    private var closed = false

    fun handshake(): Boolean {
        engine.beginHandshake()
        var status = engine.handshakeStatus
        while (status != SSLEngineResult.HandshakeStatus.FINISHED &&
            status != SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING
        ) {
            when (status) {
                SSLEngineResult.HandshakeStatus.NEED_TASK -> {
                    runDelegatedTasks()
                    status = engine.handshakeStatus
                }
                SSLEngineResult.HandshakeStatus.NEED_WRAP -> {
                    val res = wrapEmpty() ?: return false
                    status = res.handshakeStatus
                    if (res.status == SSLEngineResult.Status.CLOSED) return false
                }
                SSLEngineResult.HandshakeStatus.NEED_UNWRAP -> {
                    appInBuf.clear()
                    val res = engine.unwrap(netInBuf, appInBuf)
                    when (res.status) {
                        SSLEngineResult.Status.OK -> {
                            status = res.handshakeStatus
                        }
                        SSLEngineResult.Status.BUFFER_UNDERFLOW -> {
                            if (!appendNetData()) return false
                            status = engine.handshakeStatus
                        }
                        SSLEngineResult.Status.BUFFER_OVERFLOW -> {
                            appInBuf = ByteBuffer.allocate(maxOf(appInBuf.capacity() * 2, engine.session.applicationBufferSize))
                            status = engine.handshakeStatus
                        }
                        SSLEngineResult.Status.CLOSED -> return false
                    }
                }
                else -> {
                    // Handles Conscrypt/Android NEED_UNWRAP_AGAIN cleanly
                    appInBuf.clear()
                    val res = engine.unwrap(netInBuf, appInBuf)
                    status = when (res.status) {
                        SSLEngineResult.Status.BUFFER_UNDERFLOW -> {
                            if (!appendNetData()) return false
                            engine.handshakeStatus
                        }
                        SSLEngineResult.Status.BUFFER_OVERFLOW -> {
                            appInBuf = ByteBuffer.allocate(maxOf(appInBuf.capacity() * 2, engine.session.applicationBufferSize))
                            engine.handshakeStatus
                        }
                        SSLEngineResult.Status.CLOSED -> return false
                        else -> res.handshakeStatus
                    }
                }
            }
        }
        return true
    }

    fun readPlaintextChunk(): ByteArray? {
        while (!closed) {
            if (!netInBuf.hasRemaining()) {
                if (!appendNetData()) return null
            }
            appInBuf.clear()
            val res = engine.unwrap(netInBuf, appInBuf)
            if (res.handshakeStatus == SSLEngineResult.HandshakeStatus.NEED_TASK) {
                runDelegatedTasks()
            } else if (res.handshakeStatus == SSLEngineResult.HandshakeStatus.NEED_WRAP) {
                wrapEmpty()
            }
            when (res.status) {
                SSLEngineResult.Status.OK -> {
                    if (appInBuf.position() > 0) {
                        appInBuf.flip()
                        val out = ByteArray(appInBuf.remaining())
                        appInBuf.get(out)
                        return out
                    }
                }
                SSLEngineResult.Status.BUFFER_UNDERFLOW -> {
                    if (!appendNetData()) return null
                }
                SSLEngineResult.Status.BUFFER_OVERFLOW -> {
                    appInBuf = ByteBuffer.allocate(maxOf(appInBuf.capacity() * 2, engine.session.applicationBufferSize))
                }
                SSLEngineResult.Status.CLOSED -> return null
            }
        }
        return null
    }

    fun writePlaintext(data: ByteArray) {
        if (closed || data.isEmpty()) return
        val src = ByteBuffer.wrap(data)
        while (src.hasRemaining() && !closed) {
            netOutBuf.clear()
            val res = engine.wrap(src, netOutBuf)
            when (res.status) {
                SSLEngineResult.Status.OK -> flushNetOut()
                SSLEngineResult.Status.BUFFER_OVERFLOW -> {
                    netOutBuf = ByteBuffer.allocate(maxOf(netOutBuf.capacity() * 2, engine.session.packetBufferSize))
                }
                SSLEngineResult.Status.CLOSED -> {
                    flushNetOut()
                    break
                }
                SSLEngineResult.Status.BUFFER_UNDERFLOW -> break
            }
        }
    }

    fun inputStream(): InputStream = object : InputStream() {
        private var current: ByteArray? = null
        private var pos = 0

        override fun read(): Int {
            val single = ByteArray(1)
            val n = read(single, 0, 1)
            return if (n <= 0) -1 else single[0].toInt() and 0xFF
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (len == 0) return 0
            while (current == null || pos >= current!!.size) {
                val next = readPlaintextChunk() ?: return -1
                current = next
                pos = 0
            }
            val buf = current!!
            val avail = minOf(len, buf.size - pos)
            System.arraycopy(buf, pos, b, off, avail)
            pos += avail
            return avail
        }
    }

    fun outputStream(): OutputStream = object : OutputStream() {
        override fun write(b: Int) {
            writePlaintext(byteArrayOf(b.toByte()))
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            if (len <= 0) return
            val slice = if (off == 0 && len == b.size) b else b.copyOfRange(off, off + len)
            writePlaintext(slice)
        }
    }

    fun close() {
        if (closed) return
        closed = true
        runCatching {
            engine.closeOutbound()
            while (!engine.isOutboundDone) {
                netOutBuf.clear()
                val res = engine.wrap(emptyBuf, netOutBuf)
                flushNetOut()
                if (res.status == SSLEngineResult.Status.CLOSED || netOutBuf.position() == 0 && res.bytesProduced() == 0) {
                    break
                }
            }
        }
    }

    private fun runDelegatedTasks() {
        while (true) {
            val task = engine.delegatedTask ?: break
            task.run()
        }
    }

    private fun wrapEmpty(): SSLEngineResult? {
        while (true) {
            netOutBuf.clear()
            val res = engine.wrap(emptyBuf, netOutBuf)
            if (res.status == SSLEngineResult.Status.BUFFER_OVERFLOW) {
                netOutBuf = ByteBuffer.allocate(maxOf(netOutBuf.capacity() * 2, engine.session.packetBufferSize))
                continue
            }
            flushNetOut()
            return res
        }
    }

    private fun flushNetOut() {
        if (netOutBuf.position() > 0) {
            netOutBuf.flip()
            val out = ByteArray(netOutBuf.remaining())
            netOutBuf.get(out)
            writeNet(out)
        }
    }

    private fun appendNetData(): Boolean {
        val chunk = readNet() ?: return false
        if (chunk.isEmpty()) return true
        netInBuf.compact()
        if (netInBuf.remaining() < chunk.size) {
            val needed = netInBuf.position() + chunk.size
            val grown = ByteBuffer.allocate(maxOf(netInBuf.capacity() * 2, needed))
            netInBuf.flip()
            grown.put(netInBuf)
            netInBuf = grown
        }
        netInBuf.put(chunk)
        netInBuf.flip()
        return true
    }
}
