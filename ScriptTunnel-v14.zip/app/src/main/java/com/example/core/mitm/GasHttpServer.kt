package com.example.core.mitm

import com.example.core.logging.LogCategory
import com.example.core.logging.TunnelLogger
import com.example.network.ParallelTunnelEngine
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream

/**
 * Minimal HTTP/1.1 server that reads sequential keep-alive requests from a decrypted stream
 * (or plain HTTP on port 80), relays them through [ParallelTunnelEngine.relayHttpViaGasPool]
 * without following redirects, and writes the full HTTP response (status, headers, body) back.
 */
class GasHttpServer(
    private val engine: ParallelTunnelEngine,
    private val defaultHost: String,
    private val scheme: String = "https",
    private val input: InputStream,
    private val output: OutputStream
) {
    suspend fun serve() {
        while (true) {
            val req = readHttpRequest() ?: break
            val res = engine.relayHttpViaGasPool(
                targetUrl = req.url,
                method = req.method,
                headers = req.headers,
                bodyBytes = req.body,
                followRedirects = false
            )

            val respBuf = ByteArrayOutputStream()
            val statusLine = "HTTP/1.1 ${res.statusCode} ${reasonPhrase(res.statusCode)}\r\n"
            respBuf.write(statusLine.toByteArray(Charsets.US_ASCII))

            if (res.ok) {
                for ((k, v) in res.headers) {
                    val lk = k.lowercase()
                    if (lk in STRIPPED_RESPONSE_HEADERS) continue
                    val cleanVal = v.replace("\r", "").replace("\n", " ")
                    respBuf.write("$k: $cleanVal\r\n".toByteArray(Charsets.ISO_8859_1))
                }
            } else {
                respBuf.write("Content-Type: text/plain; charset=utf-8\r\n".toByteArray(Charsets.US_ASCII))
            }

            val bodyOut = if (res.ok) res.bodyBytes else (res.error ?: "Relay Error").toByteArray(Charsets.UTF_8)
            val sendBody = !req.method.equals("HEAD", ignoreCase = true)
            val contentLength = if (res.ok) res.bodyBytes.size else bodyOut.size
            respBuf.write("Content-Length: $contentLength\r\n".toByteArray(Charsets.US_ASCII))
            val closeAfter = req.closeConnection || !res.ok
            respBuf.write("Connection: ${if (closeAfter) "close" else "keep-alive"}\r\n".toByteArray(Charsets.US_ASCII))
            respBuf.write("\r\n".toByteArray(Charsets.US_ASCII))
            if (sendBody && bodyOut.isNotEmpty()) {
                respBuf.write(bodyOut)
            }

            output.write(respBuf.toByteArray())
            output.flush()

            TunnelLogger.d(
                LogCategory.GAS,
                "MITM-HTTP",
                "${req.method} ${req.url} -> ${res.statusCode} (${bodyOut.size}B)"
            )

            if (closeAfter) break
        }
    }

    private data class ParsedHttpRequest(
        val method: String,
        val url: String,
        val headers: Map<String, String>,
        val body: ByteArray?,
        val closeConnection: Boolean
    )

    private fun readHttpRequest(): ParsedHttpRequest? {
        val requestLine = readLineCrlf() ?: return null
        if (requestLine.isBlank()) return null
        val parts = requestLine.split(" ")
        if (parts.size < 2) return null
        val method = parts[0].trim().uppercase()
        val target = parts[1].trim()
        val httpVersion = parts.getOrNull(2)?.trim()?.uppercase() ?: "HTTP/1.1"

        var host = defaultHost
        var contentLength = -1
        var isChunked = false
        var closeConn = httpVersion == "HTTP/1.0"
        var expectContinue = false
        val forwardHeaders = LinkedHashMap<String, String>()

        while (true) {
            val line = readLineCrlf() ?: return null
            if (line.isEmpty()) break
            val colon = line.indexOf(':')
            if (colon <= 0) continue
            val key = line.substring(0, colon).trim()
            val value = line.substring(colon + 1).trim()
            val lk = key.lowercase()
            when (lk) {
                "host" -> host = value
                "content-length" -> contentLength = value.toIntOrNull() ?: -1
                "transfer-encoding" -> if (value.contains("chunked", ignoreCase = true)) isChunked = true
                "connection" -> {
                    if (value.contains("close", ignoreCase = true)) closeConn = true
                    else if (value.contains("keep-alive", ignoreCase = true)) closeConn = false
                }
                "expect" -> if (value.contains("100-continue", ignoreCase = true)) expectContinue = true
            }
            if (lk !in STRIPPED_REQUEST_HEADERS) {
                val existing = forwardHeaders[key]
                forwardHeaders[key] = if (existing == null) value else "$existing, $value"
            }
        }

        if (expectContinue) {
            output.write("HTTP/1.1 100 Continue\r\n\r\n".toByteArray(Charsets.US_ASCII))
            output.flush()
        }

        val body: ByteArray? = when {
            isChunked -> readChunkedBody()
            contentLength > 0 -> readExactBytes(contentLength)
            else -> null
        }

        val fullUrl = if (target.startsWith("http://") || target.startsWith("https://")) {
            target
        } else {
            val path = if (target.startsWith("/")) target else "/$target"
            "$scheme://$host$path"
        }

        return ParsedHttpRequest(
            method = method,
            url = fullUrl,
            headers = forwardHeaders,
            body = body,
            closeConnection = closeConn
        )
    }

    private fun readLineCrlf(): String? {
        val buf = ByteArrayOutputStream(128)
        while (true) {
            val b = input.read()
            if (b == -1) {
                return if (buf.size() == 0) null else buf.toString(Charsets.ISO_8859_1.name())
            }
            if (b == '\n'.code) {
                val bytes = buf.toByteArray()
                val len = if (bytes.isNotEmpty() && bytes.last() == '\r'.code.toByte()) bytes.size - 1 else bytes.size
                return String(bytes, 0, len, Charsets.ISO_8859_1)
            }
            buf.write(b)
            if (buf.size() > 64 * 1024) {
                throw IllegalStateException("HTTP header line too long")
            }
        }
    }

    private fun readExactBytes(n: Int): ByteArray {
        val out = ByteArray(n)
        var off = 0
        while (off < n) {
            val r = input.read(out, off, n - off)
            if (r < 0) throw EOFException("Unexpected EOF while reading HTTP body")
            off += r
        }
        return out
    }

    private fun readChunkedBody(): ByteArray {
        val out = ByteArrayOutputStream()
        while (true) {
            val sizeLine = readLineCrlf() ?: throw EOFException("Unexpected EOF in chunked body")
            val semi = sizeLine.indexOf(';')
            val hex = (if (semi >= 0) sizeLine.substring(0, semi) else sizeLine).trim()
            val chunkSize = hex.toIntOrNull(16) ?: throw IllegalStateException("Invalid chunk size: $hex")
            if (chunkSize == 0) {
                while (true) {
                    val trailer = readLineCrlf() ?: break
                    if (trailer.isEmpty()) break
                }
                break
            }
            out.write(readExactBytes(chunkSize))
            readLineCrlf() // trailing CRLF after chunk data
        }
        return out.toByteArray()
    }

    companion object {
        private val STRIPPED_REQUEST_HEADERS = setOf(
            "host",
            "connection",
            "keep-alive",
            "proxy-connection",
            "transfer-encoding",
            "te",
            "trailer",
            "upgrade",
            "content-length",
            "expect",
            "accept-encoding"
        )

        private val STRIPPED_RESPONSE_HEADERS = setOf(
            "transfer-encoding",
            "content-encoding",
            "content-length",
            "connection",
            "keep-alive",
            "alt-svc"
        )

        private fun reasonPhrase(code: Int): String = when (code) {
            200 -> "OK"
            201 -> "Created"
            204 -> "No Content"
            206 -> "Partial Content"
            301 -> "Moved Permanently"
            302 -> "Found"
            304 -> "Not Modified"
            307 -> "Temporary Redirect"
            308 -> "Permanent Redirect"
            400 -> "Bad Request"
            401 -> "Unauthorized"
            403 -> "Forbidden"
            404 -> "Not Found"
            500 -> "Internal Server Error"
            502 -> "Bad Gateway"
            503 -> "Service Unavailable"
            else -> "OK"
        }
    }
}
