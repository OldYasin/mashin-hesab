package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.core.scripts.ScriptTemplates
import com.example.data.local.CleanIpEntity
import com.example.data.local.ServerEndpointEntity
import com.example.data.model.BypassSettings
import com.example.data.model.EndpointType
import com.example.data.model.IpProvider
import com.example.data.model.LoadBalanceMode
import com.example.data.model.ProxyIpCatalog
import com.example.data.model.SyncStatus
import com.example.network.ScanProgress
import com.example.ui.components.AppIcons
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.RoseError

@Composable
fun ServersScreen(
    servers: List<ServerEndpointEntity>,
    cleanIps: List<CleanIpEntity>,
    settings: BypassSettings,
    defaultSecret: String,
    scanProgress: ScanProgress,
    isTestingPool: Boolean,
    dnsResults: List<com.example.network.CleanIpScanner.DnsResolverStatus> = emptyList(),
    isTestingDns: Boolean = false,
    onTestDnsResolvers: () -> Unit = {},
    onLoadBalanceChange: (LoadBalanceMode) -> Unit,
    onAddOrUpdateServer: (Long, String, String, String, EndpointType, String, String, Int) -> Unit,
    onImportConfig: (String) -> Unit,
    onToggleParallel: (ServerEndpointEntity) -> Unit,
    onPingServer: (ServerEndpointEntity) -> Unit,
    onTestAllServers: () -> Unit,
    onDeleteServer: (Long) -> Unit,
    onStartCleanIpScan: (IpProvider, String, Int) -> Unit,
    onStopCleanIpScan: () -> Unit,
    onApplyCleanIp: (String, IpProvider) -> Unit,
    onSetProxyIp: (String, String) -> Unit,
    onExportBundle: () -> String,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var editingServer by remember { mutableStateOf<ServerEndpointEntity?>(null) }
    var deletingServer by remember { mutableStateOf<ServerEndpointEntity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var showImportDialog by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxSize()) {
        SingleChoiceSegmentedButtonRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            SegmentedButton(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                modifier = Modifier.testTag("tab_servers_pool")
            ) {
                Text("سرورهای موازی (${servers.size})")
            }
            SegmentedButton(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                modifier = Modifier.testTag("tab_clean_ip_scanner")
            ) {
                Text("اسکنر آی‌پی تمیز")
            }
        }

        if (selectedTab == 0) {
            ServersPoolContent(
                servers = servers,
                settings = settings,
                isTestingPool = isTestingPool,
                onLoadBalanceChange = onLoadBalanceChange,
                onAddClick = {
                    editingServer = null
                    showAddDialog = true
                },
                onImportClick = { showImportDialog = true },
                onTestAllClick = onTestAllServers,
                onEditServer = {
                    editingServer = it
                    showAddDialog = true
                },
                onToggleParallel = onToggleParallel,
                onPingServer = onPingServer,
                onDeleteClick = { deletingServer = it },
                onSetProxyIp = onSetProxyIp,
                onExportBundle = onExportBundle,
                onShowMessage = onShowMessage
            )
        } else {
            CleanIpScannerContent(
                cleanIps = cleanIps,
                settings = settings,
                scanProgress = scanProgress,
                dnsResults = dnsResults,
                isTestingDns = isTestingDns,
                onTestDnsResolvers = onTestDnsResolvers,
                onStartScan = onStartCleanIpScan,
                onStopScan = onStopCleanIpScan,
                onApplyCleanIp = onApplyCleanIp
            )
        }
    }

    if (showAddDialog) {
        AddEditServerDialog(
            initial = editingServer,
            defaultSecret = defaultSecret,
            onDismiss = { showAddDialog = false },
            onSave = { id, name, url, secret, type, sni, cleanIp, weight ->
                onAddOrUpdateServer(id, name, url, secret, type, sni, cleanIp, weight)
                showAddDialog = false
            }
        )
    }

    deletingServer?.let { target ->
        AlertDialog(
            onDismissRequest = { deletingServer = null },
            title = { Text("حذف سرور") },
            text = { Text("سرور «${target.name}» حذف شود؟") },
            confirmButton = {
                Button(onClick = {
                    onDeleteServer(target.id)
                    deletingServer = null
                }) { Text("حذف") }
            },
            dismissButton = {
                TextButton(onClick = { deletingServer = null }) { Text("لغو") }
            }
        )
    }

    if (showImportDialog) {
        ImportConfigDialog(
            onDismiss = { showImportDialog = false },
            onImport = { raw ->
                onImportConfig(raw)
                showImportDialog = false
            }
        )
    }
}

@Composable
private fun ServersPoolContent(
    servers: List<ServerEndpointEntity>,
    settings: BypassSettings,
    isTestingPool: Boolean,
    onLoadBalanceChange: (LoadBalanceMode) -> Unit,
    onAddClick: () -> Unit,
    onImportClick: () -> Unit,
    onTestAllClick: () -> Unit,
    onEditServer: (ServerEndpointEntity) -> Unit,
    onToggleParallel: (ServerEndpointEntity) -> Unit,
    onPingServer: (ServerEndpointEntity) -> Unit,
    onDeleteClick: (ServerEndpointEntity) -> Unit,
    onSetProxyIp: (String, String) -> Unit,
    onExportBundle: () -> String,
    onShowMessage: (String) -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var categoryFilter by remember { mutableStateOf<EndpointType?>(null) }
    val collapsedGroups = remember { androidx.compose.runtime.mutableStateMapOf<EndpointType, Boolean>() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ProxyIpCard(settings = settings, onSave = onSetProxyIp) }

        // Action Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onAddClick,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("add_server_button")
                ) {
                    Icon(AppIcons.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("افزودن اسکریپت")
                }
                OutlinedButton(
                    onClick = onImportClick,
                    modifier = Modifier.testTag("import_config_button")
                ) {
                    Icon(AppIcons.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ایمپورت")
                }
                OutlinedButton(
                    onClick = {
                        val b = onExportBundle()
                        if (b.isNotBlank()) {
                            clipboard.setText(AnnotatedString(b))
                            onShowMessage("بکاپ کل پروفایل (scriptvpnbundle://) کپی شد")
                        }
                    }
                ) {
                    Icon(AppIcons.Share, contentDescription = "خروجی کل پروفایل", modifier = Modifier.size(18.dp))
                }
                OutlinedButton(
                    onClick = onTestAllClick,
                    enabled = !isTestingPool,
                    modifier = Modifier.testTag("test_all_servers_button")
                ) {
                    Icon(AppIcons.Speed, contentDescription = null, modifier = Modifier.size(18.dp))
                }
            }
        }

        // Load Balancing Selector
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "استراتژی مصرف موازی چند اسکریپت",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LoadBalanceMode.entries.forEach { mode ->
                            FilterChip(
                                selected = settings.loadBalanceMode == mode,
                                onClick = { onLoadBalanceChange(mode) },
                                label = { Text(mode.titleFa) }
                            )
                        }
                    }
                    Text(
                        text = settings.loadBalanceMode.descFa,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (isTestingPool) {
            item {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
        }

        if (servers.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = AppIcons.ShieldOutlined,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(40.dp)
                        )
                        Text(
                            text = "هنوز اسکریپت یا ورکری اضافه نشده است",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "از تب «کد و راهنما» کد اسکریپت گوگل را کپی کرده و پس از دیپلوی، لینک آن را اینجا اضافه کنید. می‌توانید چند اسکریپت را هم‌زمان موازی مصرف کنید.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            val categories = listOf(EndpointType.GAS_SCRIPT, EndpointType.CF_WORKER_WS, EndpointType.DNSTT)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = categoryFilter == null,
                        onClick = { categoryFilter = null },
                        label = { Text("همه (${servers.size})") }
                    )
                    categories.forEach { cat ->
                        val cnt = servers.count { it.endpointType == cat }
                        if (cnt > 0 || categoryFilter == cat) {
                            FilterChip(
                                selected = categoryFilter == cat,
                                onClick = { categoryFilter = if (categoryFilter == cat) null else cat },
                                label = { Text("${cat.badge} ($cnt)") }
                            )
                        }
                    }
                }
            }

            val visibleCategories = if (categoryFilter != null) listOf(categoryFilter!!) else categories
            visibleCategories.forEach { cat ->
                val groupServers = servers.filter { it.endpointType == cat }
                if (groupServers.isNotEmpty()) {
                    val catColor = when (cat) {
                        EndpointType.CF_WORKER_WS -> CyanSecondary
                        EndpointType.DNSTT -> AmberWarning
                        else -> EmeraldPrimary
                    }
                    val isCollapsed = collapsedGroups[cat] == true
                    item(key = "hdr_${cat.name}") {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { collapsedGroups[cat] = !isCollapsed },
                            shape = RoundedCornerShape(10.dp),
                            color = catColor.copy(alpha = 0.10f),
                            border = BorderStroke(1.dp, catColor.copy(alpha = 0.30f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = cat.labelFa,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = catColor
                                    )
                                    Text(
                                        text = "(${groupServers.count { it.isParallelActive }}/${groupServers.size} فعال)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = if (isCollapsed) "باز کردن ▾" else "جمع کردن ▴",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = catColor
                                )
                            }
                        }
                    }

                    if (!isCollapsed) {
                        items(groupServers, key = { it.id }) { server ->
                            val badgeColor = when (server.endpointType) {
                                EndpointType.CF_WORKER_WS -> CyanSecondary
                                EndpointType.DNSTT -> AmberWarning
                                else -> EmeraldPrimary
                            }
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = MaterialTheme.shapes.medium,
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(
                                    1.dp,
                                    if (server.isParallelActive) badgeColor.copy(alpha = 0.45f)
                                    else MaterialTheme.colorScheme.outline
                                )
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1f),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = badgeColor.copy(alpha = 0.16f)
                                            ) {
                                                Text(
                                                    text = server.endpointType.badge,
                                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                                    color = badgeColor,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                                )
                                            }
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = server.name,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                                    Text(
                                                        text = server.url,
                                                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                            }
                                        }
                                        Switch(
                                            checked = server.isParallelActive,
                                            onCheckedChange = { onToggleParallel(server) }
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            val pingText = if (server.lastLatencyMs > 0) "${server.lastLatencyMs}ms" else "تست‌نشده"
                                            val pingColor = when {
                                                server.lastLatencyMs <= 0 -> MaterialTheme.colorScheme.onSurfaceVariant
                                                server.isHealthy && server.lastLatencyMs < 350 -> EmeraldPrimary
                                                server.isHealthy -> AmberWarning
                                                else -> RoseError
                                            }
                                            Text(
                                                text = pingText,
                                                style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                                                color = pingColor
                                            )
                                            Text(
                                                text = "• ${server.uptimePercent}%",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(0.dp), verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(onClick = { onPingServer(server) }, modifier = Modifier.size(34.dp)) {
                                                Icon(AppIcons.Speed, contentDescription = "تست پینگ", modifier = Modifier.size(16.dp))
                                            }
                                            IconButton(
                                                onClick = {
                                                    clipboard.setText(AnnotatedString(ScriptTemplates.encodeShareUri(server)))
                                                    onShowMessage("لینک اشتراک scriptvpn:// کپی شد")
                                                },
                                                modifier = Modifier.size(34.dp)
                                            ) {
                                                Icon(AppIcons.Share, contentDescription = "کپی کانفیگ اشتراک", modifier = Modifier.size(16.dp))
                                            }
                                            IconButton(onClick = { onEditServer(server) }, modifier = Modifier.size(34.dp)) {
                                                Icon(AppIcons.Edit, contentDescription = "ویرایش سرور", modifier = Modifier.size(16.dp))
                                            }
                                            IconButton(onClick = { onDeleteClick(server) }, modifier = Modifier.size(34.dp)) {
                                                Icon(AppIcons.Delete, contentDescription = "حذف سرور", tint = RoseError, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CleanIpScannerContent(
    cleanIps: List<CleanIpEntity>,
    settings: BypassSettings,
    scanProgress: ScanProgress,
    dnsResults: List<com.example.network.CleanIpScanner.DnsResolverStatus>,
    isTestingDns: Boolean,
    onTestDnsResolvers: () -> Unit,
    onStartScan: (IpProvider, String, Int) -> Unit,
    onStopScan: () -> Unit,
    onApplyCleanIp: (String, IpProvider) -> Unit
) {
    var selectedProvider by remember { mutableStateOf(IpProvider.GOOGLE) }
    var customPrefix by remember { mutableStateOf("") }
    var selectedRanges by remember(selectedProvider) { mutableStateOf<Set<String>>(emptySet()) }
    var scanCountText by remember { mutableStateOf("240") }

    val filteredIps = remember(cleanIps, selectedProvider) {
        cleanIps.filter { it.providerEnum == selectedProvider }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "استخراج خودکار آی‌پی تمیز",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "برنامه به صورت هم‌زمان رنج‌های رسمی گوگل و کلودفلر را با هندشیک واقعی TLS SNI اسکن کرده و سریع‌ترین آی‌پی بدون فیلتر را جایگزین می‌کند.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IpProvider.entries.forEach { prov ->
                            FilterChip(
                                selected = selectedProvider == prov,
                                onClick = { selectedProvider = prov },
                                label = { Text(prov.titleFa) }
                            )
                        }
                    }

                    val providerRanges = remember(selectedProvider) {
                        com.example.network.CleanIpScanner.defaultRangesFor(selectedProvider)
                    }
                    Text(
                        text = "انتخاب رنج‌های ${selectedProvider.titleFa} (خالی = همه رنج‌های رسمی):",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = selectedRanges.isEmpty(),
                            onClick = { selectedRanges = emptySet() },
                            label = { Text("همه (${providerRanges.size} رنج)") }
                        )
                        providerRanges.forEach { cidr ->
                            val isSel = cidr in selectedRanges
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    selectedRanges = if (isSel) selectedRanges - cidr else selectedRanges + cidr
                                },
                                label = {
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        Text(cidr, style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily))
                                    }
                                }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = customPrefix,
                        onValueChange = { customPrefix = it },
                        label = {
                            Text(
                                if (selectedProvider == IpProvider.GOOGLE)
                                    "رنج یا CIDR دلخواه گوگل (مثلاً 142.250.0.0/15, 172.217.0.0/16)"
                                else
                                    "رنج یا CIDR دلخواه کلودفلر (مثلاً 104.16.0.0/13, 172.64.0.0/13)"
                            )
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "تعداد آی‌پی برای اسکن:",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(100, 240, 500, 1000, 2000).forEach { preset ->
                            FilterChip(
                                selected = scanCountText.toIntOrNull() == preset,
                                onClick = { scanCountText = preset.toString() },
                                label = { Text("$preset") }
                            )
                        }
                        OutlinedTextField(
                            value = scanCountText,
                            onValueChange = { v -> scanCountText = v.filter { it.isDigit() }.take(4) },
                            label = { Text("دلخواه") },
                            singleLine = true,
                            modifier = Modifier.width(96.dp)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (scanProgress.isScanning) onStopScan()
                                else {
                                    val combinedRanges = (selectedRanges.toList() + customPrefix.split(',', ';', '\n').map { it.trim() }.filter { it.isNotBlank() })
                                        .distinct()
                                        .joinToString(",")
                                    val count = scanCountText.toIntOrNull()?.coerceIn(10, 5000) ?: 240
                                    onStartScan(selectedProvider, combinedRanges, count)
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("scan_clean_ip_button")
                        ) {
                            Icon(AppIcons.Radar, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (scanProgress.isScanning) "توقف اسکن" else "شروع استخراج آی‌پی تمیز")
                        }
                    }

                    if (scanProgress.isScanning) {
                        val frac = if (scanProgress.totalCount > 0) {
                            scanProgress.scannedCount.toFloat() / scanProgress.totalCount.toFloat()
                        } else 0f
                        LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
                        Text(
                            text = "بررسی ${scanProgress.scannedCount} از ${scanProgress.totalCount} آی‌پی • یافت‌شده سالم: ${scanProgress.foundCount}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanSecondary
                        )
                    }

                    val activeIp = if (selectedProvider == IpProvider.GOOGLE) settings.activeCleanGoogleIp else settings.activeCleanCfIp
                    if (activeIp.isNotBlank()) {
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "آی‌پی فعال فعلی:",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                    Text(
                                        text = activeIp,
                                        style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "تست ریکرسورهای DNS (DoH / UDP)",
                            style = MaterialTheme.typography.titleSmall
                        )
                        OutlinedButton(
                            onClick = onTestDnsResolvers,
                            enabled = !isTestingDns,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(if (isTestingDns) "در حال تست..." else "تست سلامت DNS")
                        }
                    }
                    if (dnsResults.isNotEmpty()) {
                        dnsResults.forEach { d ->
                            val stColor = when {
                                d.ok -> EmeraldPrimary
                                d.poisoned -> AmberWarning
                                else -> RoseError
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(d.name, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = when {
                                        d.ok -> "سالم (${d.latencyMs}ms)"
                                        d.poisoned -> "مسموم (10.10.34.x)"
                                        else -> "قطع"
                                    },
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                    color = stColor
                                )
                            }
                        }
                    }
                }
            }
        }

        items(filteredIps, key = { it.ip }) { item ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onApplyCleanIp(item.ip, selectedProvider) },
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(
                    1.dp,
                    if (item.isSelected) EmeraldPrimary else MaterialTheme.colorScheme.outline
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(
                            imageVector = AppIcons.CheckCircle,
                            contentDescription = null,
                            tint = if (item.isSelected) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                Text(
                                    text = item.ip,
                                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Text(
                                text = "نوسان ${item.jitterMs} ms • TLS SNI تاییدشده",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "${item.latencyMs} ms",
                            style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = if (item.latencyMs < 220) EmeraldPrimary else AmberWarning
                        )
                        if (!item.isSelected) {
                            TextButton(onClick = { onApplyCleanIp(item.ip, selectedProvider) }) {
                                Text("اعمال")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddEditServerDialog(
    initial: ServerEndpointEntity?,
    defaultSecret: String,
    onDismiss: () -> Unit,
    onSave: (Long, String, String, String, EndpointType, String, String, Int) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var url by remember { mutableStateOf(initial?.url ?: "") }
    var secret by remember { mutableStateOf(initial?.secretKey ?: defaultSecret) }
    var type by remember { mutableStateOf(initial?.endpointType ?: EndpointType.GAS_SCRIPT) }
    var sni by remember { mutableStateOf(initial?.customSniHost ?: "") }
    var cleanIp by remember { mutableStateOf(initial?.customCleanIp ?: "") }
    var weightText by remember { mutableStateOf((initial?.weight ?: 1).toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "افزودن اسکریپت یا ورکر" else "ویرایش سرور") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(EndpointType.GAS_SCRIPT, EndpointType.CF_WORKER_WS, EndpointType.DNSTT).forEach { t ->
                        FilterChip(
                            selected = type == t,
                            onClick = { type = t },
                            label = { Text(t.labelFa) }
                        )
                    }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("نام دلخواه (مثلاً اسکریپت ۱)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = {
                        Text(
                            when (type) {
                                EndpointType.GAS_SCRIPT -> "لینک Web App گوگل (.../exec)"
                                EndpointType.CF_WORKER_WS -> "آدرس ورکر کلودفلر (wss://...workers.dev)"
                                EndpointType.DNSTT -> "دامنه NS (مثلاً t.example.com)"
                                else -> "آدرس سرور"
                            }
                        )
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = secret,
                    onValueChange = { secret = it },
                    label = { Text(if (type == EndpointType.DNSTT) "Public Key (Hex)" else "کلید امنیتی (TUNNEL_SECRET)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = cleanIp,
                    onValueChange = { cleanIp = it },
                    label = { Text("آی‌پی تمیز اختصاصی (اختیاری)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sni,
                        onValueChange = { sni = it },
                        label = { Text(if (type == EndpointType.DNSTT) "DoH / DoT / UDP" else "SNI جعلی (اختیاری)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = weightText,
                        onValueChange = { weightText = it.filter { c -> c.isDigit() } },
                        label = { Text("وزن موازی") },
                        singleLine = true,
                        modifier = Modifier.width(90.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        initial?.id ?: 0L,
                        name,
                        url,
                        secret,
                        type,
                        sni,
                        cleanIp,
                        weightText.toIntOrNull() ?: 1
                    )
                }
            ) {
                Text("ذخیره")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@Composable
private fun ImportConfigDialog(
    onDismiss: () -> Unit,
    onImport: (String) -> Unit
) {
    var raw by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("وارد کردن کانفیگ اشتراک") },
        text = {
            OutlinedTextField(
                value = raw,
                onValueChange = { raw = it },
                label = { Text("scriptvpn:// ، dnstt:// ، dns:// ، JSON یا دستور DNSTT") },
                minLines = 3,
                maxLines = 5,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(onClick = { onImport(raw) }) { Text("افزودن") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("لغو") }
        }
    )
}

@Composable
private fun ProxyIpCard(
    settings: BypassSettings,
    onSave: (String, String) -> Unit
) {
    var country by remember(settings.proxyIpCountry) { mutableStateOf(settings.proxyIpCountry) }
    var custom by remember(settings.proxyIpCustom) { mutableStateOf(settings.proxyIpCustom) }
    val dirty = country != settings.proxyIpCountry || custom.trim() != settings.proxyIpCustom

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("ProxyIP ورکر کلودفلر", style = MaterialTheme.typography.titleMedium)
            Text(
                "برای مقصدهایی که پشت کلودفلر هستن، ورکر از این ProxyIP استفاده می‌کنه. کشور دلخواه رو انتخاب کن یا آی‌پی/دامنه خودت رو بنویس.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = country == "AUTO",
                    onClick = { country = "AUTO" },
                    label = { Text("خودکار") }
                )
                ProxyIpCatalog.countries.forEach { c ->
                    FilterChip(
                        selected = country == c.code,
                        onClick = { country = c.code },
                        label = { Text(c.flag + " " + c.nameFa) }
                    )
                }
            }
            OutlinedTextField(
                value = custom,
                onValueChange = { custom = it },
                label = { Text("ProxyIP دلخواه (اختیاری، با کاما جدا کن؛ مثلاً 1.2.3.4:443)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                text = "فعال: " + ProxyIpCatalog.resolve(settings.copy(proxyIpCountry = country, proxyIpCustom = custom)).ifBlank { "لیست پیش‌فرض ورکر" },
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                color = CyanSecondary
            )
            Button(
                onClick = { onSave(country, custom) },
                enabled = dirty,
                modifier = Modifier.fillMaxWidth()
            ) { Text("ذخیره ProxyIP") }
        }
    }
}
