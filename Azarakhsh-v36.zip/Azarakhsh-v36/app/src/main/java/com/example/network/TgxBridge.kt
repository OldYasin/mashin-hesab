package com.example.network

import com.example.core.logging.LogCategory
import com.example.core.logging.TunnelLogger
import com.example.core.logging.TunnelStats
import com.example.data.model.EndpointType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.net.URLEncoder
import java.security.SecureRandom
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * TGX: raw TCP session tunnel  app -> Google Apps Script (HTTP) -> Cloudflare Worker -> Telegram DC.
 *
 * Unlike [MtProtoHttpBridge] this does NOT parse MTProto: the Telegram client's own obfuscated2 stream is piped
 * byte for byte, the Worker keeps one real TCP socket per session. Everything uses byte offsets + acks, so a
 * retried call (any GAS node) can never duplicate or lose data.
 *
 * Calls (all relayed through GAS, see tgx/worker.js):
 *   POST /__tgx/o  open session (+ first upstream bytes)
 *   POST /__tgx/x  send upstream bytes at offset `uo` and fetch downstream bytes from offset `dn` (long-poll `w` ms)
 *   POST /__tgx/c  close
 * Reply body: flags(1) | upAck(8, BE) | dnStart(8, BE) | data
 */
object TgxBridge {

    const val FLAG_EOF = 1
    const val FLAG_ERR = 2
    const val FLAG_NOSESS = 4
    const val FLAG_GAP = 8
    private const val HDR = 17

    private const val UP_CHUNK = 128 * 1024
    private const val DN_MAX = 256 * 1024
    private const val POLL_ACTIVE_MS = 8_000
    private const val POLL_IDLE_MS = 20_000
    private const val MAX_CONSECUTIVE_FAILS = 6
    private const val SLOTS_PER_NODE = 20
    private const val SLOTS_MAX = 150

    private const val GENERIC_MAX_SESSIONS = 60
    private val inFlight = AtomicInteger(0)
    private val genericSessions = AtomicInteger(0)
    private val rnd = SecureRandom()

    class Reply(val flags: Int, val upAck: Long, val dnStart: Long, val data: ByteArray)

    /** Telegram DC hosts only (no generic port rule: the Worker refuses anything else anyway). */
    fun isTelegramHost(host: String): Boolean {
        val h = host.trim().lowercase()
        if (h.endsWith(".telegram.org") || h == "telegram.org" || h.endsWith(".t.me")) return true
        if (h.startsWith("149.154.") || h.startsWith("91.108.") || h.startsWith("95.161.") || h.startsWith("185.76.151.")) return true
        return h.startsWith("2001:b28:f23") || h.startsWith("2001:67c:4e8")
    }

    fun normalizeBase(url: String): String {
        var u = url.trim().trimEnd('/')
        if (u.startsWith("wss://")) u = "https://" + u.removePrefix("wss://")
        if (u.startsWith("ws://")) u = "http://" + u.removePrefix("ws://")
        if (u.isNotEmpty() && !u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
        return u
    }

    internal fun parseReply(body: ByteArray): Reply? {
        if (body.size < HDR) return null
        fun rd(o: Int): Long {
            var v = 0L
            for (i in 0 until 8) v = (v shl 8) or (body[o + i].toLong() and 0xFF)
            return v
        }
        return Reply(
            flags = body[0].toInt() and 0xFF,
            upAck = rd(1),
            dnStart = rd(9),
            data = if (body.size > HDR) body.copyOfRange(HDR, body.size) else ByteArray(0)
        )
    }

    /** Bytes of [data] (which starts at downstream offset [start]) that are new for a reader that already has [rx]. */
    internal fun newDownstream(rx: Long, start: Long, data: ByteArray): ByteArray {
        if (data.isEmpty() || start > rx) return ByteArray(0)
        val end = start + data.size
        if (end <= rx) return ByteArray(0)
        val skip = (rx - start).toInt()
        return if (skip == 0) data else data.copyOfRange(skip, data.size)
    }

    /** Upstream bytes not yet acknowledged by the Worker. Thread safe. */
    internal class UpBuffer {
        private var buf = ByteArray(0)
        private var head = 0              // index in buf of the first unacked byte
        private var acked = 0L            // stream offset of buf[head]
        private var total = 0L            // stream offset after the last byte

        @Synchronized fun append(b: ByteArray, len: Int = b.size) {
            if (len <= 0) return
            val live = (total - acked).toInt()
            if (head > 0 && (head >= buf.size / 2 || head + live + len > buf.size)) {
                System.arraycopy(buf, head, buf, 0, live)
                head = 0
            }
            if (head + live + len > buf.size) {
                buf = buf.copyOf(maxOf(buf.size * 2, head + live + len, 4096))
            }
            System.arraycopy(b, 0, buf, head + live, len)
            total += len
        }

        @Synchronized fun ackedOffset(): Long = acked
        @Synchronized fun hasPending(): Boolean = total > acked

        /** Atomic (offset, bytes) snapshot so the offset always matches the bytes even if an ack lands meanwhile. */
        @Synchronized fun snapshot(max: Int): Pair<Long, ByteArray> {
            val n = minOf(max.toLong(), total - acked).toInt()
            return acked to buf.copyOfRange(head, head + n)
        }

        /** Move the acked offset forward to [upAck] (never backwards, never past what we appended). */
        @Synchronized fun ackTo(upAck: Long) {
            val target = minOf(upAck, total)
            if (target <= acked) return
            head += (target - acked).toInt()
            acked = target
        }
    }

    private fun slotLimit(engine: ParallelTunnelEngine): Int =
        (engine.selectOrderedCandidates(EndpointType.GAS_SCRIPT).size.coerceAtLeast(1) * SLOTS_PER_NODE).coerceAtMost(SLOTS_MAX)

    private fun newSid(): String {
        val b = ByteArray(12)
        rnd.nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    private suspend fun call(
        engine: ParallelTunnelEngine,
        base: String,
        secret: String,
        path: String,
        body: ByteArray?,
        low: Boolean = false
    ): Reply? {
        // non-Telegram (generic) traffic may only use 2/3 of the slots so Telegram never starves
        while (inFlight.get() >= (if (low) slotLimit(engine) * 2 / 3 else slotLimit(engine)).coerceAtLeast(1)) delay(50L)
        inFlight.incrementAndGet()
        try {
            val res = engine.relayHttpViaGasPool(
                targetUrl = "$base/__tgx/$path",
                method = "POST",
                headers = mapOf("X-Tunnel-Auth" to secret, "Content-Type" to "application/octet-stream"),
                bodyBytes = body,
                followRedirects = false
            )
            if (!res.ok || res.statusCode != 200) {
                TunnelLogger.d(LogCategory.GAS, "TGX-ERR", "خطای TGX (${path.substringBefore('?')}): HTTP ${res.statusCode}", res.error)
                return null
            }
            return parseReply(res.bodyBytes)
        } finally {
            inFlight.decrementAndGet()
        }
    }

    /**
     * Pipes one SOCKS5 TCP stream through TGX. Returns false only if the session could not be opened (nothing was
     * written to the client yet) so the caller can fall back to another bridge; true once the stream was served.
     */
    suspend fun bridgeStream(
        engine: ParallelTunnelEngine,
        targetHost: String,
        targetPort: Int,
        initialBytes: ByteArray,
        clientIn: InputStream,
        clientOut: OutputStream,
        workerUrl: String,
        secret: String,
        generic: Boolean = false
    ): Boolean = withContext(Dispatchers.IO) {
        val base = normalizeBase(workerUrl)
        if (base.isEmpty() || secret.isBlank()) return@withContext false
        if (generic) {
            if (genericSessions.incrementAndGet() > GENERIC_MAX_SESSIONS) {
                genericSessions.decrementAndGet()
                TunnelStats.inc("tgx.genericRejected")
                return@withContext false
            }
        }
        try {
        val low = generic
        val sid = newSid()
        val hostQ = URLEncoder.encode(targetHost, "UTF-8")

        var opened: Reply? = null
        for (attempt in 0 until 2) {
            val r = call(engine, base, secret, "o?sid=$sid&h=$hostQ&p=$targetPort", initialBytes, low)
            if (r != null) { opened = r; break }
        }
        if (opened == null || (opened.flags and FLAG_ERR) != 0) {
            val why = opened?.data?.let { String(it, Charsets.UTF_8) } ?: "no reply"
            TunnelLogger.w(LogCategory.GAS, "TGX-OPEN", "باز کردن نشست TGX ناموفق بود", "$targetHost:$targetPort -> $why")
            TunnelStats.inc("tgx.openFail")
            return@withContext false
        }
        TunnelStats.inc("tgx.sessions")
        TunnelLogger.i(LogCategory.GAS, "TGX-OPEN", "نشست TGX باز شد", "$targetHost:$targetPort sid=$sid")
        engine.recordTraffic(upBytes = initialBytes.size.toLong(), downBytes = 0L)

        val up = UpBuffer()
        up.append(initialBytes)
        up.ackTo(opened.upAck)

        val writeLock = Any()
        var rx = 0L
        val finished = CompletableDeferred<Unit>()
        val fails = AtomicInteger(0)
        val wake = Channel<Unit>(Channel.CONFLATED)
        val clientEof = AtomicBoolean(false)
        val lastActivity = AtomicLong(System.currentTimeMillis())

        fun deliver(r: Reply): Boolean {
            // returns true when the session is over
            if (r.data.isNotEmpty()) {
                synchronized(writeLock) {
                    val fresh = newDownstream(rx, r.dnStart, r.data)
                    if (fresh.isNotEmpty()) {
                        clientOut.write(fresh)
                        clientOut.flush()
                        rx += fresh.size
                        engine.recordTraffic(upBytes = 0L, downBytes = fresh.size.toLong())
                        lastActivity.set(System.currentTimeMillis())
                    }
                }
            }
            return (r.flags and FLAG_EOF) != 0
        }

        suspend fun exchange(uo: Long, body: ByteArray, waitMs: Int): Reply? {
            val dn = synchronized(writeLock) { rx }
            return call(engine, base, secret, "x?sid=$sid&uo=$uo&dn=$dn&w=$waitMs&m=$DN_MAX", if (body.isEmpty()) null else body, low)
        }

        fun handle(r: Reply?): Boolean {
            if (r == null) {
                if (fails.incrementAndGet() >= MAX_CONSECUTIVE_FAILS) finished.complete(Unit)
                return false
            }
            fails.set(0)
            up.ackTo(r.upAck)
            val over = deliver(r)
            if ((r.flags and FLAG_NOSESS) != 0 || (r.flags and FLAG_ERR) != 0 || over) {
                finished.complete(Unit)
                return true
            }
            return false
        }

        try {
            coroutineScope {
                // client -> buffer
                val readerJob = launch(Dispatchers.IO) {
                    val buf = ByteArray(16 * 1024)
                    try {
                        while (!finished.isCompleted) {
                            val n = clientIn.read(buf)
                            if (n <= 0) break
                            up.append(buf, n)
                            engine.recordTraffic(upBytes = n.toLong(), downBytes = 0L)
                            lastActivity.set(System.currentTimeMillis())
                            wake.trySend(Unit)
                        }
                    } catch (_: Exception) {
                    }
                    clientEof.set(true)
                    wake.trySend(Unit)
                }
                // buffer -> worker (sequential, batched: everything that piled up during one call goes in the next)
                val senderJob = launch(Dispatchers.IO) {
                    try {
                        while (!finished.isCompleted) {
                            if (!up.hasPending()) {
                                if (clientEof.get()) { finished.complete(Unit); break }
                                wake.receive()
                                continue
                            }
                            val (uo, chunk) = up.snapshot(UP_CHUNK)
                            val r = exchange(uo, chunk, 0)
                            if (r == null) delay(300L * fails.get().coerceAtLeast(1))
                            handle(r)
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        finished.complete(Unit)
                    }
                }
                // worker -> client (always one long-poll outstanding)
                val pollerJob = launch(Dispatchers.IO) {
                    try {
                        while (!finished.isCompleted) {
                            val idle = System.currentTimeMillis() - lastActivity.get() > 30_000L
                            val r = exchange(up.ackedOffset(), ByteArray(0), if (idle) POLL_IDLE_MS else POLL_ACTIVE_MS)
                            if (r == null) delay(300L * fails.get().coerceAtLeast(1))
                            handle(r)
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        finished.complete(Unit)
                    }
                }
                finished.await()
                readerJob.cancel(); senderJob.cancel(); pollerJob.cancel()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
        } finally {
            runCatching { clientIn.close() }
            // best effort: tell the Worker to drop the socket (not awaited by the client)
            runCatching {
                withContext(kotlinx.coroutines.NonCancellable) {
                    kotlinx.coroutines.withTimeoutOrNull(5_000L) { call(engine, base, secret, "c?sid=$sid", null, low) }
                }
            }
            TunnelLogger.d(LogCategory.GAS, "TGX-END", "نشست TGX بسته شد", "sid=$sid rx=$rx")
        }
        true
        } finally {
            if (generic) genericSessions.decrementAndGet()
        }
    }
}
